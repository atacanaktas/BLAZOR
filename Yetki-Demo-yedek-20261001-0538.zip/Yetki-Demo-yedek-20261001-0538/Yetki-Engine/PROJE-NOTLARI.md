# Yetki Motoru (Yetki-Engine) — Proje Notları

> Bu dosya projeye daha sonra dönüldüğünde (insan veya AI asistan) genel resmi, detayları, dikkat edilmesi gerekenleri ve TODO'ları hızlıca hatırlamak içindir.
> Web yönetim paneli: `../Yetki-Web/PROJE-NOTLARI.md` · İlk gereksinim dokümanı: `../authorization-engine-prototype-context.md`
> **2026-09-25:** Proje sektör standartlarına göre baştan kuruldu (hibrit RBAC + filtreli grup + hedefli ABAC policy). Önceki sürüm: `../Yetki-Demo-yedek-2026-09-25.zip`.
> **2026-09-25 (2):** "Hybrid Authorization Model" dokümanına hizalandı: Organization → **Tenant** (izolasyon + miras), Client ve uygulama tenant'a ait, istek `{tenant, client, subject, resource, action, context}`, karar sırası **1 Tenant → 2 Client → 3 Resource+Action → 4 RBAC → 5 Policy/Rule**, **Rule = sağlanması gereken tek koşul** (Effect kaldırıldı). Önceki hali: `../../Yetki-Demo-yedek-20260925-1508`.

---

## 1. Özet: hibrit model (RBAC + Policy)

| Kavram | Sorumluluk | Demoda | Standart karşılığı |
|---|---|---|---|
| **Tenant** | İzolasyon sınırı | `Tenant` (ABANK → BISTIRAK); kullanıcı, birim, rol, grup, policy, client, uygulama bir tenant'a ait | Hiyerarşik multi-tenancy (Entra tenant, Keycloak realm) |
| **Client** | Yetki isteyen uygulama/sistem | `Client` + `ClientPermissionGrant` (allowed permissions) + token `scope` | OAuth 2.0 client (`azp`/`client_id`) ve granted scopes |
| **Resource** | Korunan varlık | Katalog: Uygulama → Domain → Modül → Alt modül (action'ı olan düğüm = resource) → API → Endpoint · UI öğesi | Resource server/type hiyerarşisi, OpenAPI |
| **Action / Permission** | Resource üzerindeki işlem | `Permission` = Resource + Action (`anka.nakit.cekim.gise:create`) | Hiyerarşik permission adlandırma (GCP/AWS/Azure) |
| **User** | İşlemi yapan kimlik | `User` (Person / ServiceAccount) | Subject |
| **Role** | İş rolüyle permission paketi | `Role` → `RolePermission`, `UserRole` (süreli) | NIST RBAC (ANSI/INCITS 359) |
| **Group** | Operasyonel gruplama (filtreli kitle) | `Group` = açık üyeler ∪ Include filtreleri − Exclude → rol + permission | Entra dynamic groups / Okta group rules |
| **Policy** | Permission'ın kullanım koşulları | `Policy` → katalog hedefi (miras) + karar stratejisi + Mode | NIST ABAC (SP 800-162), XACML kavramları (implementasyon DEĞİL) |
| **Rule** | Tek değerlendirilebilir koşul | `Rule` = sağlanması gereken koşul ifadesi (+ neden kodu) | XACML Rule / Cedar condition |
| **Karar API'si** | PDP | `POST /api/v1/authorize` + OpenID **AuthZEN** `/access/v1/evaluation(s)` | OpenID AuthZEN Authorization API 1.0 |

**Üç soru ayrı cevaplanır:** (1) *Kullanıcı ne yapabilir?* → RBAC: User → Role/Group → Permission. (2) *Hangi koşullarda?* → Policy → Rule (saat, limit, IP, izin). (3) *Nihai karar* → RBAC DENY ise DENY (policy'ye geçilmez); RBAC PERMIT ∧ tüm Enforce policy'ler PERMIT → PERMIT; bir policy DENY → DENY; belirsizlik → INDETERMINATE (izin yok). ReportOnly policy'ler değerlendirilir ama kararı etkilemez.

**Tenant kuralı (tek kural):** bir tenant KENDİ ve ÜST tenant'larının tanımlarını kullanır (policy, uygulama, client; rol için ayrıca `IsInheritable`). Kullanıcı başka tenant adına işlem yapamaz, başka tenant'ın kaydına (`resource.properties.Tenant`) erişemez; üst tenant alt tenant'ın uygulamasını kullanamaz.

Stack: .NET 9 Web API (controllers), EF Core 9 **SQLite** (`src/Yetki.Api/yetki.db`, migration'lı; testlerde InMemory), Swashbuckle, xUnit. XACML/OPA/Cedar paketi **yok**; davranış C# handler'larda.

---

## 2. Çalıştırma

```bash
dotnet run --project src/Yetki.Api                    # http://localhost:5100/swagger
dotnet run --project samples/Anka.NakitService        # http://localhost:5200 (SDK'lı örnek mikroservis)
dotnet test                                           # 41 test
```
- "Out of memory" alınırsa: `dotnet build` sonra `src/Yetki.Api/bin/Debug/net9.0/Yetki.Api.exe --urls http://localhost:5100`.
- Ayarlar (`appsettings.json`): `Persistence:Provider` (`Sqlite` | `InMemory`), `ConnectionStrings:Yetki` (varsayılan `Data Source=yetki.db`; göreli yol API proje klasörüne göre çözülür), `AuthorizationEngine:RequireClient` (varsayılan false), `Cors:Origins` (web 5180).

### 2.1 Veritabanı: `yetki.db` (çalışan) ve `yedek.db` (örnek veri)

| Dosya | Ne | Kim yazar |
|---|---|---|
| `src/Yetki.Api/yetki.db` | API'nin kullandığı veritabanı. Yoksa açılışta **boş** oluşturulur (şema + condition tipi kataloğu, veri yok). Yönetim ekranlarından yapılan her şey buraya kalıcı yazılır. | API |
| `src/Yetki.Api/yedek.db` | Sade demo verisi (A Bankası → B İştiraki, Anka/Nextral/Mobil Şube, 24 kullanıcı, 10 policy …). **Uygulama kodunda seed yoktur**; bu dosya ayrı bir araçla üretilir. | `tools/Yetki.SampleData` |

- **Örnek veriye dönmek / sıfırlamak:** API'yi **durdur** → `yedek.db`'yi aynı klasöre `yetki.db` adıyla kopyala (üzerine yaz) → API'yi başlat. Boş başlamak için `yetki.db`'yi sil.
  ```powershell
  Copy-Item src\Yetki.Api\yedek.db src\Yetki.Api\yetki.db -Force
  Remove-Item src\Yetki.Api\yetki.db-wal, src\Yetki.Api\yetki.db-shm -ErrorAction SilentlyContinue
  ```
  **Dikkat:** hedefin yanında eski `-wal`/`-shm` dosyası kalırsa SQLite onu yeni kopyaya uygular ve dosya bozulur ("malformed database schema"). Motor tek dosya (DELETE journal) modunda çalıştığı için normalde bu dosyalar oluşmaz; ama elle kopyalarken yine de silin.
- **yedek.db'yi yeniden üretmek:** `dotnet run --project tools/Yetki.SampleData` (Yetki-Engine klasöründen). Dosyayı siler, migration'ları uygular, örnek veriyi `SampleDataBuilder` ile yazar. `yetki.db`'yi hedeflemeyi reddeder. Başka dosyaya: `... -- C:\yol\ornek.db`.
- **Model/örnek veri değiştiğinde** (entity, migration, `SampleDataBuilder`) `yedek.db` yeniden üretilmeli; testler de aynı `SampleDataBuilder`'ı kullanır (yani testler örnek veriyi de doğrular).
- SQLite **DELETE journal** modunda çalışır (tek dosya, `-wal/-shm` yok) → dosya kopyalamak güvenlidir. Yine de kopyalamayı API kapalıyken yapın.
- **Şema değişikliği:** entity/konfig değiştirince migration ekleyin; API açılışta `Migrate` eder (mevcut `yetki.db` verisi korunur):
  ```bash
  dotnet ef migrations add <Ad> --project src/Yetki.Infrastructure --startup-project src/Yetki.Api --output-dir Persistence/Migrations
  ```
  (`dotnet-ef` 9.x global araç; tasarım zamanı için `DesignTimeDbContextFactory`.)
- İnceleme: `yetki.db` herhangi bir SQLite aracıyla (DB Browser for SQLite, VS Code SQLite eklentisi) açılabilir; API açıkken yalnızca okuyun.
- Build öncesi çalışan API'yi durdur (DLL kilidi). PowerShell 5.1 Türkçe JSON gövdelerini bozar; testte `curl --data-binary @dosya.json` kullan.

---

## 3. Katmanlar ve klasörler

```
src/
├─ Yetki.Domain          Entity'ler (davranış yok)
│   Tenants/        Tenant (ParentId), OrgUnit (ağaç)
│   Identity/       User (Kind: Person|ServiceAccount), UserOrgUnit
│   Catalog/        CatalogApplication, CatalogNode (Path), Permission, ApiResource, ApiEndpoint, UiElement
│   Clients/        OAuth Client, ClientPermissionGrant (allowed permission hedefi + action filtresi)
│   Rbac/           Role (IsInheritable), RolePermission, UserRole (ValidFrom/Until), UserPermission (legacy)
│   Groups/         Group, GroupMember (süreli), GroupFilter (Include/Exclude) → GroupFilterCriterion → GroupFilterValue, GroupRole, GroupPermission
│   Policies/       Policy (Mode, TenantId), PolicyTarget, Rule, RuleCondition (ağaç), ConditionParameter, SharedCondition, ConditionType
│   Governance/     SodRule/Member/Violation, ExternalSystem/Permission/Mapping, OutboxEvent, ProvisioningAction, AuditLog
├─ Yetki.Application
│   Model/          ★ Bellek içi yetki modeli (AuthorizationModel), ModelData (ham satırlar), ChangeSets (What-If),
│                   GroupCriteria (grup kriteri handler'ları), PolicyCompiler (+ ConditionTreeResolver), ModelProvider (sürüm önbelleği)
│   PolicyEngine/   PolicyEvaluator (Kleene 3-değerli), Combining (Deny/Permit-overrides, First-applicable), Attributes, Conditions/*
│   Evaluation/     AuthorizationEvaluator (PDP), EntitlementService (toplu yetki)
│   Changes/        AuthorizationChangeService (etki analizi + uygulama), AssignmentService (tüm RBAC/grup işlemleri)
│   Definitions/    PolicyManagementService, SharedConditionService, CatalogService (+ manifest içe aktarma), ClientService, TenantService, GovernanceService
│   Simulation/     PolicyImpactService, SimulationService
│   Governance/     SodService (+ SodEvaluator)
│   Events/ Audit/  OutboxWriter, ProvisioningEventHandler, AuditWriter
├─ Yetki.Infrastructure  YetkiDbContext (+ Migrations, DesignTimeDbContextFactory), DependencyInjection (Sqlite/InMemory, InitializeYetkiDatabaseAsync: migrate + condition tipi senkronu, seed YOK), Services (clock, versiyon, dummy RACF/LDAP adaptörü, OutboxProcessor)
├─ Yetki.Api             Controllers: Authorization (+AuthZEN), Identity (org/kullanıcı/rol/grup), Catalog (katalog/permission/API/client), Policy, Operations (SoD, dış sistem, what-if, olay, audit, seçim listeleri)
└─ Yetki.Sdk             [RequiresPermission], [AuthContext], YetkiAuthorizationFilter (PEP), MapYetkiManifest()
samples/Anka.NakitService   SDK'lı örnek mikroservis (ANKA/NAKIT/CEKIM/GISE)
tools/Yetki.SampleData       yedek.db üreticisi (SampleDataBuilder = sade demo verisi)
tests/Yetki.Tests            41 test; her test InMemory DB + SampleDataBuilder (senaryo, grup/org, katalog/client, what-if/entitlement/SoD/audit, motor)
```

---

## 4. Bellek içi yetki modeli (çekirdek tasarım kararı)

- `AuthorizationModelProvider.GetCurrentAsync()` tüm yetki verisini (org, birim, kullanıcı, katalog, client, rol, grup, policy, condition) **tek seferde** yükler, `AuthorizationModel.Build` ile indeksler. `IAuthorizationVersion` değişmedikçe aynı model kullanılır (yetkiyi etkileyen her `SaveChanges` versiyonu artırır; audit/outbox/SoD/dış sistem değişiklikleri artırmaz).
- **What-If**: `BuildWhatIfAsync(rbacChanges, policyChanges)` = güncel `ModelData.Clone().Apply(changes)` + aynı `Build`. Gerçek karar ve simülasyon **aynı kod yolu**.
- Model üzerinde: etkin yetki (`GetEffective`, dakika hassasiyetinde önbellek), grup üyeliği (`ComputeMemberships`), policy uygulanabilirliği (`GetApplicablePolicies`, önbellek), client kapsamı (`ClientAllows`), endpoint eşleme (`MatchEndpoint`), sahipler (`HoldersOf`).
- **Ölçek notu:** Prototip hacminde (≈40 kullanıcı, ≈470 permission, 231 API, 675 endpoint) model < 100 ms kurulur. 20K+ kullanıcıda: katalog/policy/grup tanımları paylaşılan modelde, kullanıcı atamaları kullanıcı bazlı dilimlerde yüklenmeli; grup üyeliği `GroupMembers` materialize tablosuna alınmalı (TODO).

---

## 5. Karar akışı (`AuthorizationEvaluator`)

**İstek** (`POST /api/v1/authorize`):
```json
{ "tenant": "ABANK", "client": "nextral-desktop", "subject": { "id": "ahmet.kaya" },
  "resource": { "type": "ANKA/NAKIT/CEKIM/GISE", "id": "TR12...", "properties": { "Tenant": "ABANK", "BranchCode": "101", "CustomerId": "C-555" } },
  "action": "create",
  "context": { "TransactionAmount": "75000", "IpAddress": "10.20.30.40" } }
```
`resource.type` katalog yolu (`ANKA/NAKIT/CEKIM/GISE`) veya kod biçimi (`anka.nakit.cekim.gise`); `action` büyük/küçük harf duyarsız. Alternatifler: `permission` kodu (`anka.nakit.cekim.gise:create`) veya `endpoint` {api|audience, method, path} (gateway). `resource.properties` bağlama eklenir. `tenant` boşsa kullanıcının tenant'ı. Zaman (`Time`) motorun saatidir.

```
0 Subject    kullanıcı var/aktif mi? (Service client + kullanıcı yoksa → client'ın servis hesabı; client credentials)
1 Tenant     istek tenant'ı var/aktif mi (TENANT_UNKNOWN/INACTIVE), kullanıcı bu tenant'a mı ait (TENANT_MISMATCH),
             kaydın tenant'ı aynı mı (RESOURCE_TENANT_MISMATCH)
2 Client     kayıtlı/aktif mi (CLIENT_UNKNOWN), bu tenant'ta veya üst tenant'ta kayıtlı mı (CLIENT_TENANT_MISMATCH);
             client yoksa RequireClient ayarına göre CLIENT_REQUIRED / atla
3 Resource   resource + action | permission | endpoint → permission (PERMISSION_UNKNOWN, ENDPOINT_UNKNOWN/NOT_MAPPED, PERMISSION_INACTIVE);
             uygulama bu tenant'ta kullanılabilir mi (RESOURCE_NOT_IN_TENANT); client bu resource/action'a erişebilir mi (CLIENT_NOT_ALLOWED)
4 RBAC       User → Role / Group → Permission (doğrudan rol, grup→rol, grup→permission, doğrudan permission). Yoksa PERMISSION_NOT_GRANTED
             ve POLICY DEĞERLENDİRİLMEZ.
5 Policy     aktif + tenant'ı istek tenant'ının zincirinde + Include hedefi eşleşen + Exclude hedefi eşleşmeyen policy'ler.
             Her policy → Rule'lar (sağlandı / sağlanmadı / belirsiz) → karar stratejisi → Permit / Deny / Indeterminate.
   Karar     tüm Enforce policy'ler Permit → PERMIT (policy yoksa PERMIT_NO_POLICY); biri Deny → DENY (rule'un ReasonCode'u);
             belirsizlik → INDETERMINATE (fail-closed, MISSING_ATTRIBUTE / EVALUATION_ERROR)
```
Açıklamada: `Steps` (Subject, Tenant, Client, Resource, Client Permission, OAuth Scope, RBAC, `Policy X`), `PermissionSources`, `ClientAllowedPermission`, `GrantedScopes`, `MatchedScope`, policy/rule sonuçları ve kanıtlar bulunur.

**Reason code'lar:** `CLIENT_IS_INTERMEDIARY`, `INTERMEDIARY_UNKNOWN`, `INTERMEDIARY_TENANT_MISMATCH`, `INTERMEDIARY_NOT_ALLOWED`, `USER_NOT_FOUND`, `USER_INACTIVE`, `TENANT_UNKNOWN`, `TENANT_INACTIVE`, `TENANT_MISMATCH`, `RESOURCE_TENANT_MISMATCH`, `CLIENT_UNKNOWN`, `CLIENT_TENANT_MISMATCH`, `CLIENT_REQUIRED`, `RESOURCE_REQUIRED`, `PERMISSION_UNKNOWN`, `ENDPOINT_UNKNOWN`, `ENDPOINT_NOT_MAPPED`, `PERMISSION_INACTIVE`, `RESOURCE_NOT_IN_TENANT`, `CLIENT_NOT_ALLOWED`, `PERMISSION_NOT_GRANTED`, `PERMIT_NO_POLICY`, `PERMIT`, rule'un `ReasonCode`'u (ör. `OUTSIDE_BUSINESS_HOURS`, `AMOUNT_EXCEEDS_USER_LIMIT`), `MISSING_ATTRIBUTE`, `EVALUATION_ERROR`, `ENGINE_ERROR`.

---

## 6. Kavramların detayı

### 6.1 Katalog = resource hiyerarşisi (miras)
- `CatalogApplication` bir tenant'a aittir (`TenantId`); o tenant ve alt tenant'larında kullanılabilir. Rol/grup/kullanıcıya başka tenant'ın uygulamasından permission verilemez (`AssignmentService.EnsurePermissionInTenantAsync`); eski veride varsa etkin hesapta yok sayılır (`IgnoredAssignments`).
- `CatalogNode.Path` = `ANKA/NAKIT/CEKIM/GISE`. Tip derinlikten gelir (Domain → Module → SubModule, en fazla 3). Action'ı (permission'ı) olan düğüm **resource**'tur. Kod değiştirilemez (Path ve permission kodu kararlılığı).
- Permission ayrı bir kullanıcı kodu değildir; `Resource + Action` ilişkisidir. Yönetim ekranında Resource ve Action ayrı gösterilir. `{resource}:{action}` biçimindeki küçük harfli değer yalnızca sistem üretimli canonical key, audit ve entegrasyon referansıdır. `CatalogService.PermissionCodeFor`, `AuthorizationModel.FindPermission(resource, action)`.
- `PolicyTarget` ve `ClientPermissionGrant` aynı hedef mantığını kullanır: `All | Application | CatalogNode | Permission`. `PolicyTarget.Actions` boşsa hedefteki tüm action'ları, doluysa yalnızca seçilen action'ları kapsar; katalog düğümü mirasıyla policy/rule tekrarı önlenir.
- Üst seviyedeki Deny alt seviyede Permit ile **ezilemez** (AWS SCP gibi); istisna açık `Exclude`.
- **Kırılım: Uygulama → Domain → Modül → Alt modül → API → Endpoint.** API (`ApiResource`) sadece alt modülün altına eklenir (`CreateApiAsync` reddeder); manifest `CatalogPath` tam 3 seviye olmalı. `GET /api/catalog/tree` alt modüllerin `apiList`'ini (endpoint'ler + eşlenen permission) döner.
- Endpoint ≠ Permission (N:1). Eşlenmemiş endpoint motor tarafından reddedilir ve `/api/catalog/unmapped-endpoints` denetim listesinde görünür.
- **Servis manifesti:** SDK `MapYetkiManifest()` → `GET /.well-known/yetki-manifest`; motor `POST /api/catalog/import` ile içe aktarır (eksik düğüm/permission oluşturur, endpoint eşler, idempotent). 200+ API'nin eşlemesi elle girilmez.

### 6.2 Grup = kitle kuralı
- Üyeler = (açık üyeler, süreli olabilir) ∪ Include filtreleri − Exclude filtreleri. Filtre içindeki kriterler **VE**, filtreler arası **VEYA**. Kriteri olmayan / bilinmeyen kriterli filtre eşleşmez (güvenli taraf).
- Kriterler (C# `IGroupCriterionHandler`): `ROLE` (sadece **doğrudan** roller → gruplar arası zincir/döngü yok), `ORG_UNIT`, `ORG_UNIT_TREE` (birim veya alt birimi), `ORG_UNIT_TYPE`, `TITLE`, `TENANT` (alt tenant'lar dahil), `USER`, `USER_KIND`. Yeni kriter = yeni handler + DI.
- Grup, kendi tenant'ı ve **alt tenant'larının** kullanıcılarını kapsar. Grup rol ve/veya permission verir. Rol ve permission verilirken tenant kuralı (miras alınabilir rol, tenant'ta kullanılabilir uygulama) kontrol edilir.
- Üyelik statik → etkin yetki, RACF/LDAP aktarımı, SoD ve What-If'te görünür. Saat/IP/tutar gibi bağlam kontrolleri gruba değil policy'ye yazılır.

### 6.3 Tenant mirası ve izolasyonu
- Policy: tenant'ı istek tenant'ının zincirinde olan policy uygulanır (A'nın policy'si B'ye; B'nin policy'si sadece B'ye).
- Uygulama ve client: sahibi tenant ve alt tenant'ları kullanır (`AuthorizationModel.IsAvailableIn`, `TenantHierarchy.IsAvailableAsync`).
- İzolasyon: istek tenant'ı = kullanıcının tenant'ı; `resource.properties.Tenant` verilirse o da aynı olmalı.
- Rol: aynı tenant'ta veya üst tenant'ın `IsInheritable=true` rolü. Uygun olmayan atama API'de reddedilir; eski veride varsa etkin hesapta yok sayılır ve `IgnoredAssignments`'ta açıklanır.
- Birim kodları tenant içinde tekildir; rol/grup/policy kodları global tekildir.

### 6.4 Client (OAuth)
- Client bir tenant'a kayıtlıdır (`TenantId`, sonradan değiştirilemez); o tenant ve alt tenant'larının isteklerinde kullanılabilir (ör. `nextral-desktop` ABANK'ın → BISTIRAK da kullanır; `b-portal-web` BISTIRAK'ın → ABANK kullanamaz). Servis hesabı client ile aynı tenant'ta olmalı; client kapsamına başka tenant'ın uygulaması eklenemez.
- Runtime karar = User entitlement ∩ Client allowed permissions ∩ token granted scopes ∩ Enforce policies. Client `Confidential | Public | Service` olabilir.
- Client kimliği üretimde token'dan (`azp`/`client_id`) gelir; gateway kullanıcı token'ını iletirken orijinal client korunmalı. Prototipte SDK `X-Client-Id` header'ını okur (`AllowDemoHeaders`).

### 6.4.1 Kanal: aynı endpoint, farklı client'lar (Nextral / Anka Web / Mobil)
- **Tek permission** kalır (kanal başına permission veya endpoint açılmaz). Kanal farkı 3 katmanda: **client kapsamı** (statik: mobil ANKA/MUSTERI sadece `read`), **kanal hedefli policy** (bağlamsal: mobilde cihaz uyumlu), **yükümlülük** (yanıt şekli: mobilde TCKN maskele). Nihai = RBAC ∩ client kapsamı ∩ kanal policy'leri (+ yükümlülükler PEP'te).
- **Aracı (Intermediary)** — `client` orijinal client'tır; `via` RFC 8693 `act` zinciridir. Her aracı için kayıtlı `ClientPermissionGrant` ayrıca doğrulanır.
- **Kanal hedefi** (`PolicyClientTarget`, Conditional Access "client apps" karşılığı): Include client varsa policy SADECE o client'lardan gelen isteğe uygulanır (client'sız istek de dahil değil); Exclude client için uygulanmaz ("Client X" olarak hariç listesinde görünür). Katalog hedefiyle VE. `AuthorizationModel.GetApplicablePolicies(perm, tenant, client)`. Aracı kanal hedefi olamaz. What-If: `PolicyChangeSet.AddedClientTargets / RemovedClientTargetIds`.
- **Yükümlülük** (`PolicyObligation` + parametreler, XACML obligation): tipler KODDA (`ObligationTypes`: `MASK_FIELDS(Fields, KeepLast?)`, `LIMIT_RESULTS(Max)`, `LOG_ACCESS(Category?)`), DB'de serbest davranış yok; parametreler doğrulanır. `FulfillOn` Permit/Deny. Kararda: Permit ise karara katılan (Deny/belirsiz olmayan) Enforce policy'lerin Permit yükümlülükleri; Deny ise Deny yükümlülükleri; ReportOnly üretmez. Rule'suz policy = koşulsuz yükümlülük (ör. WEB_KANAL_MASKE). Karar/AuthZEN `obligations` alanı. **SDK (PEP)**: tanımadığı yükümlülükte erişimi REDDEDER (`OBLIGATION_NOT_SUPPORTED`); `MASK_FIELDS` / `LIMIT_RESULTS` action'ın `ObjectResult` değerine uygulanır (iç içe, alan adı duyarsız), `LOG_ACCESS` hassas erişim loguna yazar, `X-Yetki-Obligations` başlığı eklenir.

### 6.5 Policy
- `Mode`: `Enforce | ReportOnly` (Azure CA "report-only" karşılığı; yeni policy'yi önce ReportOnly açıp etkisini izleyin).
- **Rule = sağlanması gereken tek koşul** (dokümandaki anlam): ifade ağacı (Predicate / AllOf / AnyOf / Not / Reference) + `ReasonCode`. TRUE → sağlandı (Permit), FALSE → sağlanmadı (Deny, ReasonCode döner), eksik değer/hata → belirsiz (Indeterminate). Pasif rule → NotApplicable. Kleene mantığı. Effect alanı YOK.
- **Karar stratejisi** (`CombiningAlgorithm`): `AllRulesMustPass` (varsayılan; biri sağlanmazsa Deny, biri belirsizse Indeterminate, hepsi sağlanırsa Permit) · `AnyRuleMustPass` (biri sağlanırsa Permit). Örnek (NAKIT_CEKIM_LIMIT): `TRANSACTION_LIMIT` = NOT AMOUNT_EXCEEDS_SUBJECT_LIMIT, `NOT_SELF_TRANSACTION` = NOT CUSTOMER_IS_SELF. İstisna koşul içinde yazılır: `APPROVAL_LIMIT` = @CREDIT_BRANCH_APPROVAL_LIMIT OR SUBJECT_HAS_ROLE(GM850...).
- Ortak koşullar (`SharedCondition`, `@BANK_NETWORK`): tanım tek yerde, rule'lar referansla bağlanır; kullanımdaki ortak koşul pasifleştirilemez/silinemez; değişiklik kullanan tüm policy'lerin versiyonunu artırır; döngü reddedilir.
- Koşul tipleri (C# handler): `ALWAYS`, `TIME_WINDOW`, `IP_IN_RANGE`, `CHANNEL_IN`, `PLATFORM_IN`, `CLIENT_IN`, `DEVICE_COMPLIANT`, `AMOUNT_EXCEEDS_SUBJECT_LIMIT`, `AMOUNT_GREATER_THAN`, `BRANCH_IN_USER_SCOPE` (veri kapsamı: birim + alt birimler), `SUBJECT_IN_UNIT` (opsiyonel alt birimler), `SUBJECT_HAS_ROLE`, `SUBJECT_IN_GROUP`, `USER_ON_LEAVE`, `CUSTOMER_IS_SELF`. `IsSubjectOnly` = sadece kullanıcı attribute'u okur (önceden hesaplanabilir).
- Attribute kaynakları: `RequestContextAttributeProvider` (Environment/Context/Action/Resource), `ModelSubjectAttributeProvider` (Subject.*: limit, izin, birimler, birim kapsamı/ataları, etkin roller/gruplar). Üretimde HR/limit servisi provider'ı öne eklenir.
- Zaman ve client otoritesi motordur (`CurrentTime`, `ClientId` motor tarafından yazılır; çağıranın zamanı `CallerTime` olarak saklanır).

---

### 6.6 Dış sistem (RACF / LDAP) bağımlılıkları ve provisioning
- **Kimlik yayılımı:** kullanıcı kendi mainframe token'ını CICS'e iletir → CICS'te **çağıran kullanıcının** RACF yetkisi aranır. Bu yüzden katalogdaki bir işlem yetkisi, dış sistemde de **kişiye** yetki açılmasını gerektirir (servis hesabına değil).
- **Tanım bilginin doğduğu yerde** (`ExternalDependency`, tam olarak biri dolu): **API** → tüm endpoint'leri (ör. `musteri-api` → `RACF:CICSMUS (APPL)`), **endpoint** → sadece o endpoint (ör. `GET /v1/customers/{id}` → `MUS1`, `HSP1` TCICSTRN), **permission** → endpoint'i olmayan işlemler (Nextral ekranı → LDAP grubu). **Zincir** (`ExternalPermissionRequirement`, döngü reddedilir): `MUS1 → BNK.MUSTERI.MASTER (DATASET)`.
- **Erişim seviyesi** (`ExternalAccessLevel`: READ < UPDATE < CONTROL < ALTER; LDAP gibi `HasAccessLevels=false` sistemlerde yok): bağımlılıkta verilmemişse permission'ın action'ından (read/view/export/print/list/search → READ, diğerleri → UPDATE). Zincirde verilmemişse üstünkiyle aynı. Aynı dış yetki birden fazla yerden gelirse **en yüksek** seviye.
- **Hesap** (`ExternalRequirementCatalog`): kullanıcılar endpoint'e değil permission'a yetkilendirilir → permission'ın gereksinimi = doğrudan + eşlenen endpoint'ler + onların API'leri + zincir (neden metinleriyle). Kullanıcının **olması gereken** durumu = etkin permission'larının gereksinimlerinin birleşimi; pasif kullanıcı → boş.
- **Provisioning = mutabakat** (`ExternalProvisioningService`): olması gereken − `UserExternalGrant` (adaptörün başarıyla uyguladığı son durum) → **Grant / Modify / Revoke**. Başka bir permission'dan dolayı hâlâ gereken dış yetki **geri alınmaz** (eski "permission kaybedilince eşlemesini revoke et" hatası giderildi); seviye düşer (UPDATE → READ). İdempotent; başarısız aksiyon bir sonraki mutabakatta tekrar denenir. Tetikleyiciler: `EffectivePermissionsChanged` (kullanıcı), `ExternalRequirementsChanged` (bağımlılık/zincir/manifest değişikliği; boş liste = herkes).
- **Baseline:** ilk kurulumda (veya RACF'ten mevcut durum içe aktarılınca) `POST /api/external/baseline` mevcut durumu olması gerekene eşitler, komut göndermez. Örnek veri aracı ve testler baseline alır.
- **Etki önizlemesi:** bağımlılık/zincir ekleme-silme uçları `?dryRun=true` ile kimde ne açılır/değişir/kapanır döner. What-If ve atama analizleri (`UserImpact.ExternalGrants/Revokes`) aynı hesabı kullanır.
- **Manifest/SDK:** `[RequiresExternal("RACF", "MUS1", ResourceClass = "TCICSTRN")]` (endpoint) ve `o.ApiExternalDependencies` (API) → manifest → içe aktarma bağımlılıkları ekler (idempotent; sistem yoksa uyarı, dış yetki yoksa oluşturur + uyarı).
- **Adaptör** (`DummyProvisioningAdapter`): `PERMIT MUS1 CLASS(TCICSTRN) ID(AYSE.YILMAZ) ACCESS(READ)` / `... DELETE`; LDAP `ADD member ...`. Gerçek RACF adaptörü aynı `IProvisioningAdapter` arayüzüyle eklenir.

## 7. What-If ve değişiklik akışı

- `AuthorizationChangeSet` (RBAC): kullanıcı rol/permission/birim, kullanıcı güncelleme (unvan, izin, limit, aktiflik), rol permission, rol güncelleme (aktiflik/miras), grup üye/yetki/kitle kuralları/aktiflik.
- `PolicyChangeSet`: aktiflik, mod, algoritma, **hedef ekle/çıkar**, rule override/ekle/çıkar/değiştir, predicate parametresi, ortak koşul tanımı.
- `AuthorizationChangeService.AnalyzeAsync`: önce/sonra modelde **tüm kullanıcılar** için etkin yetki karşılaştırması → kazanır / kaybeder / başka kaynaktan korunur, rol ve grup değişimi, yeni SoD çakışması (Block → 409, Warn → uygula + ihlal), RACF/LDAP gereksinimi. `ApplyAsync`: aynı analiz + entity değişikliği + outbox (`EffectivePermissionsChanged` kullanıcı başına) + audit, tek transaction.
- `PolicyImpactService`: her permission × tenant için uygulanan policy imzası (mod, algoritma, rule'lar, ortak koşul içerikleri açılmış) önce/sonra karşılaştırılır; sahipler bulunur; senaryolarla (context + client) önce/sonra karar (AYNI evaluator). Yeni gerekli attribute ve "kısıtsız kalan" permission uyarıları.

---

## 8. API uçları (özet)

| Alan | Uçlar |
|---|---|
| Karar | `POST /api/v1/authorize`, `POST /api/v1/authorize/batch`, `GET /api/v1/entitlements/{user}?client&application&evaluate&ip` (ETag/304), `POST /api/v1/entitlements` |
| AuthZEN | `GET /.well-known/authzen-configuration`, `POST /access/v1/evaluation`, `POST /access/v1/evaluations` (`evaluations_semantic`) |
| Tenant | `GET/POST /api/tenants` (kendi/miras uygulama, client, policy, rol), `GET/POST /api/org-units` |
| Kullanıcı | `GET /api/users`, `GET /api/users/{id}` · `/effective` · `/entitlements`, `POST /api/users`, `PUT /api/users/{id}`, `POST/DELETE /api/users/{id}/roles[/{roleId}]`, `/permissions`, `/units/{unitId}` |
| Rol | `GET/POST /api/roles`, `GET/PUT /api/roles/{id}`, `POST/DELETE /api/roles/{id}/permissions/{pid}` |
| Grup | `GET/POST /api/groups`, `GET/PUT /api/groups/{id}`, `PUT /api/groups/{id}/filters`, `POST /api/groups/preview`, `POST/DELETE .../members/{userId}`, `.../roles/{roleId}`, `.../permissions/{pid}`, `GET /api/group-criteria` |
| Katalog | `GET /api/catalog/tree`, `GET /api/catalog/applications`, `GET /api/catalog/nodes/{id}`, `POST/PUT /api/catalog/applications`, `/nodes`, `POST /api/catalog/import`, `GET /api/catalog/unmapped-endpoints` |
| Permission | `GET /api/permissions?q&application&nodeId`, `GET /api/permissions/{id}` · `/holders` · `/external` (dış gereksinim + nedenleri), `POST/PUT /api/permissions` |
| API/UI | `GET/POST /api/apis`, `GET /api/apis/{id}`, `POST /api/apis/{id}/endpoints`, `PUT/DELETE /api/endpoints/{id}`, `GET/POST/PUT /api/ui-elements` |
| Client | `GET/POST /api/clients`, `PUT /api/clients/{id}`, `POST /api/clients/{id}/grants`, `DELETE /api/client-grants/{id}` |
| Policy | `GET/POST /api/policies`, `GET/PUT /api/policies/{id}`, `POST /api/policies/{id}/targets`, `DELETE /api/policy-targets/{id}`, `POST /api/policies/{id}/clients` (kanal hedefi), `DELETE /api/policy-clients/{id}`, `POST /api/policies/{id}/obligations`, `DELETE /api/policy-obligations/{id}`, `GET /api/obligation-types`, `POST /api/policies/{id}/rules`, `PUT/DELETE /api/rules/{id}`, `GET /api/rules`, `GET /api/condition-types` |
| Ortak koşul | `GET/POST /api/shared-conditions`, `GET/PUT/DELETE /api/shared-conditions/{id}` |
| What-If | `POST /api/simulation/changes`, `/evaluate`, `/policy-impact`, `/sod-rule` |
| Yönetişim | `GET/POST /api/sod/rules`, `PUT /api/sod/rules/{id}`, `GET /api/sod/violations`, `PUT /api/sod/violations/{id}`, `POST /api/sod/scan` |
| Dış sistem | `GET/POST /api/external/systems`, `POST /api/external/permissions`, `POST/DELETE /api/external/permissions/{id}/requires[/{requiredId}]` (zincir), `GET /api/external/dependencies?apiId&endpointId&permissionId&forApi`, `POST /api/external/dependencies`, `DELETE /api/external/dependencies/{id}` (hepsi `?dryRun=true` ile etki), `GET /api/external/drift`, `POST /api/external/reconcile`, `POST /api/external/baseline`, `GET /api/users/{id}/external`, `POST /api/users/{id}/external/reconcile` |
| İzleme | `GET /api/dashboard`, `GET /api/version`, `GET /api/events`, `POST /api/events/process`, `GET /api/provisioning`, `GET /api/audit`, `GET /api/audit/{id}`, `GET /api/options/{kind}` (… `resources`, `tenants`) |

Yönetim işlemleri `X-Actor` header'ı ile audit'lenir (prototip).

---

## 9. SDK (`Yetki.Sdk`) ve örnek mikroservis

```csharp
builder.Services.AddYetkiAuthorization(o => { o.EngineBaseUrl = "..."; o.Application = "ANKA"; o.CatalogPath = "NAKIT/CEKIM/GISE"; o.ApiCode = "nakit-cekim-gise-api"; });
app.MapYetkiManifest();   // GET /.well-known/yetki-manifest

[RequiresPermission("anka.nakit.cekim.gise:create", ResourceType = "account")]
public IActionResult Create(CashWithdrawalRequest r)   // DTO'da [AuthContext(AuthContextType.TransactionAmount)] Tutar ...
```
- Filter (PEP) model binding'den sonra çalışır: kullanıcı (token veya demo `X-User`), client (`azp/client_id` veya demo `X-Client-Id`), tenant (`tenant`/`tid` claim'i veya demo `X-Tenant-Id`), IP/kanal/platform/cihaz header'ları, DTO'daki `[AuthContext]` değerleri → `POST /api/v1/authorize`. Permit dışı → 403 (ProblemDetails: decisionId, reasonCode, decidingPolicy/rule, missingAttributes); motora ulaşılamazsa 503 (fail-closed).
- `[AllowWithoutPermission]`: bilinçli korumasız endpoint (health); manifestte bulgu üretmez.
- `samples/Anka.NakitService` (5200): çekim oluştur/sorgula/iptal + kasıtlı eşlenmemiş `receipt` endpoint'i.

---

## 10. Örnek veri senaryoları (`yedek.db` / `SampleDataBuilder`)

**Tenant:** `ABANK` (GM → 928, 850, BLG_IST → 1114, 737, 101) → `BISTIRAK` (B_GM → B_OPS, B_01).
**Katalog (resource):** `ANKA` (NAKIT, ODEME, KREDI, MUSTERI, HESAP, RAPOR, YATIRIM[FON/BILGI, FON/ALIM_SATIM, HISSE/EMIR]), `NEXTRAL` (ekran/buton), `MOBIL_SUBE` (3 API) → **ABANK**'ın; `B_PORTAL` (YATIRIMCI/RAPOR/PORTFOY) → **BISTIRAK**'ın (A Bankası erişemez). Toplam: 4 uygulama, 63 düğüm, 55 permission, 25 API, 53 endpoint, 24 UI öğesi.
**Client'lar:** ABANK'ın: `nextral-desktop` (NEXTRAL + ANKA/NAKIT,ODEME,HESAP,KREDI,MUSTERI,RAPOR), `anka-web` (ANKA/MUSTERI, ANKA/HESAP, ANKA/NAKIT `[read]`), `mobil-sube-tablet` (MOBIL_SUBE + ANKA/MUSTERI,HESAP **sadece read**), `eod-batch` (Service; svc.eod-batch), `yetki-konsol` (Tümü); **aracı** `anka-gateway` (Intermediary; iletebileceği: ANKA) — BISTIRAK da kullanır (miras). BISTIRAK'ın: `b-portal-web`.

| Kullanıcı | Birim / rol | Gösterdiği |
|---|---|---|
| **ahmet.kaya** | 101 GISEYTK (Gişe Yetkilisi), limit 100k | **dokümandaki örnek**: ANKA/NAKIT/CEKIM/GISE : create, 75.000, 14:35, banka IP → PERMIT (saat · limit · IP · izin rule'ları sağlandı) |
| ayse.yilmaz | 101 GISEAST, limit 50k, müşteri C-1001 | çekim, limit aşımı, kendi hesabı; GISE_101_AST grubu → kampanya |
| mert.kaya | 101 GISEAST, unvan "Stajyer Gişe Asistanı" | grubun **hariç** kuralı |
| deniz.koc / fatma.celik | 737 / 1114 GISEAST | grup dışı (kampanya yok) |
| zeynep.acar | 101 GISEYTK | EFT; mobil tabletten EFT → CLIENT_NOT_ALLOWED |
| selin.aydin | 101 GISEYTK, izinde | IZINLI_PERSONEL |
| ali.demir / emre.yildiz / kemal.sari | şube müdürleri | IST_SUBE_MUDURLERI (ORG_UNIT_TREE); ali KREDI_KOMITESI (VEYA) |
| burak.arslan | 737 BRYSLYTK + SUBEMDR_VEKALET_737 (1 yıl) | süreli açık üyelik → grup rol verir |
| hakan.tekin | 101 TICRIYTK | SoD Warn (başvuru + onay) taramada |
| murat.aksoy | BLG_IST BOLGE_MDR | veri kapsamı: bölgedeki tüm şubelerin müşterisi |
| gul.yuce, tolga.kurt, nazan.er / sibel.ates, levent.oz, derya.gok | GM 928 / 850 | kredi onayı 1M üstü sadece GM850 yetkili/yönetici |
| svc.eod-batch | servis hesabı | client credentials |
| berk.yaman, nil.sezer | B İştiraki (B_OPERASYON / B_PORTFOY) | fon/hisse işlemleri; B_MESAI (sadece B'ye), ABANK policy mirası, PERSONEL mirası |

**Gruplar:** `GISE_101_AST` (ROLE∈GISEAST ∧ ORG_UNIT∈101 − TITLE∈Stajyer → kampanya), `TUM_PERSONEL` (Person ∧ TENANT∈ABANK → PERSONEL rolü, B dahil), `IST_SUBE_MUDURLERI` (SUBEMDR ∧ ORG_UNIT_TREE∈BLG_IST → GM operasyon raporu), `SUBEMDR_VEKALET_737` (açık süreli üye → SUBEMDR rolü), `KREDI_KOMITESI` (GM850 yetkili/yönetici ∪ (SUBEMDR ∧ 101) → kullandırım), `B_TUM_PERSONEL` (→ fon bilgi okuma).
**Policy'ler** (rule = sağlanması gereken koşul): `KURUMSAL_AG` (Tümü − MOBIL_SUBE, **kanal hariç mobil-sube-tablet**; BANK_NETWORK), `MOBIL_KANAL` (ANKA/MUSTERI + ANKA/HESAP, **sadece mobil-sube-tablet**; cihaz uyumlu; yükümlülük MASK_FIELDS tckn/telefon/email, LIMIT_RESULTS 20, LOG_ACCESS KVKK), `WEB_KANAL_MASKE` (cekim.gise:read, **sadece anka-web**; rule yok; MASK_FIELDS hesapNo/musteriTckn), `IZINLI_PERSONEL` (Tümü; NOT_ON_LEAVE), `NAKIT_MESAI` (ANKA/NAKIT − ANKA/NAKIT/CEKIM/ATM; WORKING_HOURS), `NAKIT_CEKIM_LIMIT` (cekim.gise:create; TRANSACTION_LIMIT + NOT_SELF_TRANSACTION), `EFT_KURALLARI` (eft.giden:create), `KREDI_ONAY` (onay:approve; limit + kapsam), `MUSTERI_VERI_KAPSAMI` (ANKA/MUSTERI; BRANCH_IN_USER_SCOPE), `MOBIL_CIHAZ` (MOBIL_SUBE; MDM), `RAPOR_MESAI_DENEME` (**ReportOnly**, ANKA/RAPOR), `B_MESAI` (BISTIRAK, Tümü).
**SoD:** `SOD_KREDI_BASVURU_ONAY` (Warn), `SOD_GISE_SUBE_MUDURU` (Block, roller). **Dış sistem:** RACF (seviyeli) — `musteri-api` → API: `CICSMUS (APPL) READ`; `GET /v1/customers/{id}` → `MUS1`, `HSP1`; `PUT` → `MUS2`; zincir `MUS1/MUS2 → BNK.MUSTERI.MASTER`, `HSP1 → BNK.HESAP.MASTER (READ)`. `nakit-cekim-gise-api` → `CICSNKT`, `NKC1/NKS1/NKI1` → `BNK.KASA.HAREKET`. `KGS1`, `EFT1`, `KRD9` endpoint'lerde. LDAP (seviyesiz) — Nextral ekran permission'ları → `CN=NEXTRAL_*`. Başlangıçta baseline (164 kullanıcı dış yetkisi).
**Kasıtlı bulgu:** `GET /v1/cash-withdrawals/{id}/receipt` eşlenmemiş.

---

## 11. Dikkat edilmesi gerekenler

1. **Policy kısıttır, yetki vermez.** Yetki RBAC/grup ile verilir; policy'nin rule'ları sağlanması gereken koşullardır ("Deny when" değil "must be true" yazın: `WORKING_HOURS` = mesai içinde). Kişi adı yazan policy kuralı anti-pattern (grup + `SUBJECT_IN_GROUP` kullanın).
2. **Grup kriterleri statik olmalı.** Bağlama (saat/IP/tutar) bakan kriter eklemeyin; bu RACF/LDAP aktarımını ve SoD'yi bozar.
3. **Kök hedefler güçlüdür:** `Tümü` / uygulama hedefli policy yeni eklenen her şeye uygulanır. UI hedef değişikliklerini etki önizlemesi olmadan uygulatmaz; API tarafında da aynı disiplin (CI'da What-If) önerilir.
4. **KURUMSAL_AG her istekte IP ister.** IP göndermeyen çağrılar Indeterminate olur (fail-closed). SDK IP'yi otomatik toplar; test/araçlarda IP verin.
5. **Endpoint eşlemesi zorunlu.** Eşlenmemiş endpoint reddedilir; manifest/CI ile kataloğa kaydedin.
6. **Client doğrulaması** prototipte header'dan; üretimde token (azp/client_id) + gateway'in orijinal client'ı koruması şart.
7. **Model önbelleği tek instance.** Çok instance'ta `IAuthorizationVersion` Redis/DB tabanlı olmalı.
8. **Rol kriteri doğrudan rollere bakar.** Grup→rol başka grubun ROLE kriterini tetiklemez (bilinçli: zincir/döngü yok).
9. **Kod değiştirilemez alanlar:** düğüm kodu/Path, permission kodu (değişirse policy hedefleri, SDK attribute'ları, dış bağımlılıklar kırılır).
10. Türkçe kültür: kodlar Invariant ile normalize edilir (`Codes.Normalize/Lower`); API `InvariantCulture` ile çalışır.
11. **Tenant izolasyonu istekten gelir.** Üretimde tenant token'dan (`tenant`/`tid` claim) alınmalı; SDK'daki `X-Tenant-Id` başlığı sadece demo içindir. Kayıt tenant'ı (`resource.properties.Tenant`) servis tarafından veriden doldurulmalı (istemciden değil).
12. **Uygulama/client sahipliği değiştirilemez.** `TenantId` oluştururken seçilir; değiştirmek mevcut rol/grup/client kapsamlarını geçersiz kılar (TODO: taşıma sihirbazı + What-If).
13. **RACF'e tek otorite motor olmalı.** Mutabakat "olması gereken − açık olan" farkını gönderir; RACF'te elle verilen yetkiler motorun bilmediği durumdur (baseline/mutabakat onları kapatabilir). Üretimde RACF'teki mevcut durum düzenli okunmalı (drift raporu).

---

## 12. TODO

- [ ] Kimlik doğrulama (OIDC) + yönetim API'lerinin kendisinin yetkilendirilmesi (`yetki.admin.*` permission'ları, 4-göz onay akışı)
- [ ] Üretim için SQL Server'a geçiş (provider + migration seti; model SQLite/SQL Server uyumlu); `CatalogNodes.Path` üzerinde prefix index; `GroupMembers` materialize tablosu + değişiklikte artımlı yeniden hesap
- [ ] 20K+ kullanıcı için model dilimleme (kullanıcı bazlı atamalar), etki analizinin asenkron job'a taşınması (senkron sadece SoD Block)
- [ ] Dağıtık versiyon (Redis) ve karar önbelleği olmayan PDP'nin yatay ölçeklenmesi; SDK tarafında entitlement önbelleği (ETag)
- [ ] AuthZEN arama API'leri (subject/resource/action search) ve PEP'ler için metadata
- [ ] Gerçek RACF/LDAP adaptörleri (RACF komut kuyruğu / IRRDBU00 ile mevcut durum okuma → baseline yerine gerçek mutabakat), idempotency key
- [ ] Dış yetki için sahip ekip onayı (manifestten gelen yeni dış yetki "onay bekliyor" durumunda)
- [ ] Katalog: düğüm taşıma (move) + What-If etkisi; manifest'in CI'dan imzalı yüklenmesi; OpenAPI'den otomatik manifest
- [ ] Policy/ortak koşul versiyon geçmişi (eski tanımı saklama), zamanlanmış devreye alma (ReportOnly → Enforce tarihi)
- [ ] Yetki gözden geçirme (access review/recertification) kampanyaları: rol/grup/doğrudan atama sahiplerine periyodik onay
- [ ] Controller seviyesinde entegrasyon testleri (WebApplicationFactory) ve AuthZEN uyumluluk testleri
- [ ] Legacy yetki sisteminden içe aktarma (eski rol/grup → Role/Group + kitle kuralı önerisi)
- [ ] Rol atamasında kapsam (Azure RBAC tarzı: kullanıcı/grup + rol + kapsam = tenant/birim/birim ağacı) → veri kapsamı policy'si (`BRANCH_IN_USER_SCOPE`) yerine atamada
- [x] OAuth granted scopes: SDK token `scope`/`scp` claim'ini PDP'ye taşır; Permission koduyla case-sensitive eşleşir. Client allowed permissions ayrı katmandır.
- [ ] Tenant'lar arası kontrollü erişim (ör. A Bankası denetçisinin B'nin kaydını okuması): açık delegation kaydı + audit
- [ ] Transaction düzeyinde maker-checker (4 göz) akışı; SoD şu an sadece atama düzeyinde
