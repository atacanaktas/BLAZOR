using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Common;
using Yetki.Domain.Catalog;
using Yetki.Domain.Clients;
using Yetki.Domain.Common;
using Yetki.Domain.Governance;
using Yetki.Domain.Groups;
using Yetki.Domain.Identity;
using Yetki.Domain.Tenants;
using Yetki.Domain.Policies;
using Yetki.Domain.Rbac;
using Yetki.Infrastructure.Persistence;

namespace Yetki.SampleData;

/// <summary>
/// ÖRNEK (demo) veri — uygulama kodunda DEĞİL, sadece bu araçta. yedek.db bu sınıfla üretilir; testler de kullanır.
/// Keycloak Authorization Services modeli + ABAC:
///  - Resource tipleri (yetki yönetiminin): ENDPOINT (HTTP), MENU, SCREEN, BUTTON
///  - ANKA (API platformu): resource'lar + URI eşlemeleri (METHOD + desen → scope). Tanımsız URI'ye istek → DENY
///  - NEXTRAL (masaüstü): menü → ekran → buton hiyerarşisi (üst kapalıysa alt kapalı); client nextral-api
///  - Envanter: ANKA Swagger + NEXTRAL ekran listesi (kapsama raporunun dört durumunu gösterir)
///  - Policy'ler: rol / grup / kullanıcı / kanal (client) / koşul (mesai, banka ağı, limit, izin, şube kapsamı) / aggregate
///  - Permission'lar: resource/scope ← policy'ler (Unanimous); maskeleme Advisory policy ile
///  - Dış sistem: RACF (CICS bölgesi + transaction + dataset zinciri), LDAP (Nextral grubu)
/// </summary>
public sealed class SampleDataBuilder(YetkiDbContext db, IClock clock)
{
    private readonly Dictionary<string, Resource> _resources = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, Scope> _scopes = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, Policy> _policies = new(StringComparer.OrdinalIgnoreCase);
    private Dictionary<string, ConditionType> _types = new();

    public async Task BuildAsync()
    {
        if (await db.Tenants.AnyAsync()) throw new InvalidOperationException("Veritabanı boş değil; örnek veri sadece boş veritabanına yazılır.");
        _types = await db.ConditionTypes.ToDictionaryAsync(t => t.Code, StringComparer.OrdinalIgnoreCase);
        var now = clock.UtcNow;

        // ================================ Kurum ================================
        var abank = new Tenant { Code = "ABANK", Name = "A Bankası", Type = TenantType.Bank };
        var bIstirak = new Tenant { Code = "BISTIRAK", Name = "B İştiraki (A Bankası)", Type = TenantType.Subsidiary, Parent = abank };
        db.Tenants.AddRange(abank, bIstirak);

        OrgUnit Unit(Tenant tenant, OrgUnit? parent, string code, string name, OrgUnitType type)
        {
            var u = new OrgUnit { Tenant = tenant, Parent = parent, Code = code, Name = name, Type = type };
            db.OrgUnits.Add(u);
            return u;
        }
        var gm = Unit(abank, null, "GM", "Genel Müdürlük", OrgUnitType.HeadOffice);
        var u928 = Unit(abank, gm, "928", "Operasyon Daire Başkanlığı", OrgUnitType.Department);
        var u850 = Unit(abank, gm, "850", "Krediler Daire Başkanlığı", OrgUnitType.Department);
        var ist = Unit(abank, gm, "BLG_IST", "İstanbul Bölge Müdürlüğü", OrgUnitType.Region);
        var u1114 = Unit(abank, ist, "1114", "Kadıköy Şubesi", OrgUnitType.Branch);
        var u737 = Unit(abank, ist, "737", "Beşiktaş Şubesi", OrgUnitType.Branch);
        var u101 = Unit(abank, ist, "101", "Merkez Şube", OrgUnitType.Branch);
        var bGm = Unit(bIstirak, null, "B_GM", "B İştiraki Genel Müdürlük", OrgUnitType.HeadOffice);
        var b01 = Unit(bIstirak, bGm, "B_01", "B Levent Şube", OrgUnitType.Branch);

        // ================================ Sahiplik ekipleri ================================
        var tPlatform = new OwnershipTeam { Tenant = abank, Code = "PLATFORM", Name = "Platform Ekibi" };
        var tSube = new OwnershipTeam { Tenant = abank, Code = "SUBE_KANALI", Name = "Şube Kanalı Ekibi" };
        var tB = new OwnershipTeam { Tenant = bIstirak, Code = "B_BT", Name = "B İştiraki BT" };
        db.OwnershipTeams.AddRange(tPlatform, tSube, tB);

        // ================================ Resource tipleri (yetki yönetimi tanımlar) ================================
        var tEndpoint = Type("ENDPOINT", "API Endpoint", "Gateway'den gelen HTTP isteği (METHOD + URI) ile eşleşen servis işlemleri.", true, false, "blue");
        var tMenu = Type("MENU", "Menü", "Uygulama menüsü; kapalıysa altındaki ekranlar da kapalı görünür.", false, true, "purple");
        var tScreen = Type("SCREEN", "Ekran", "Uygulama ekranı (form).", false, true, "geekblue");
        var tButton = Type("BUTTON", "Buton / İşlem", "Ekrandaki işlem butonu.", false, true, "gold");

        // ================================ Uygulamalar (resource server) ================================
        var anka = new CatalogApplication { Tenant = abank, Code = "ANKA", Name = "Anka Mikroservis Platformu", Type = ApplicationType.ApiPlatform, OwnershipTeam = tPlatform,
            Description = "Core banking mikroservisleri; gateway her isteği METHOD + URI ile motora sorar." };
        var nextral = new CatalogApplication { Tenant = abank, Code = "NEXTRAL", Name = "Nextral Şube Masaüstü", Type = ApplicationType.Desktop, OwnershipTeam = tSube,
            Description = "Şube masaüstü uygulaması; menü / ekran / buton görünürlüğü login'de entitlement ile gelir (istekleri Nextral-Api yapar)." };
        var bPortal = new CatalogApplication { Tenant = bIstirak, Code = "B_PORTAL", Name = "B Yatırımcı Portalı", Type = ApplicationType.Web, OwnershipTeam = tB,
            Description = "Sadece B İştiraki'nin uygulaması (tenant izolasyonu örneği)." };
        db.Applications.AddRange(anka, nextral, bPortal);

        foreach (var (code, name) in new[] { ("view", "Görüntüle"), ("create", "Oluştur"), ("update", "Güncelle"), ("cancel", "İptal"), ("close", "Kapat"),
                     ("approve", "Onayla"), ("execute", "Çalıştır"), ("export", "Dışa aktar") })
            ScopeOf(anka, code, name);
        foreach (var (code, name) in new[] { ("view", "Görüntüle"), ("print", "Yazdır"), ("execute", "Çalıştır") })
            ScopeOf(nextral, code, name);
        foreach (var (code, name) in new[] { ("view", "Görüntüle"), ("export", "Dışa aktar") })
            ScopeOf(bPortal, code, name);

        // ---- ANKA: HTTP resource'ları (kod = kalıcı kimlik; URI'ler değişebilir eşleştirme bilgisi)
        Res(anka, tEndpoint, "anka.nakitcekim", "Gişe nakit çekim",
            [("view", Severity.Low), ("create", Severity.High), ("cancel", Severity.High)],
            ("POST", "/v1/cash-withdrawals", "create"), ("GET", "/v1/cash-withdrawals", "view"), ("GET", "/v1/cash-withdrawals/{id}", "view"),
            ("POST", "/v1/cash-withdrawals/{id}/cancel", "cancel"));
        Res(anka, tEndpoint, "anka.vadelihesap", "Vadeli hesap",
            [("view", Severity.Low), ("create", Severity.Medium), ("close", Severity.High)],
            ("GET", "/v1/vadeli-hesap", "view"), ("GET", "/v1/vadeli-hesap/{hesapNo}", "view"), ("POST", "/v1/vadeli-hesap", "create"),
            ("POST", "/v1/vadeli-hesap/{hesapNo}/kapat", "close"));
        Res(anka, tEndpoint, "anka.eft", "Giden EFT",
            [("view", Severity.Low), ("create", Severity.High), ("cancel", Severity.High)],
            ("POST", "/v1/eft", "create"), ("GET", "/v1/eft/{id}", "view"), ("DELETE", "/v1/eft/{id}", "cancel"));
        Res(anka, tEndpoint, "anka.kredibasvuru", "Kredi başvurusu",
            [("view", Severity.Low), ("create", Severity.Medium)],
            ("POST", "/v1/kredi/basvuru", "create"), ("GET", "/v1/kredi/basvuru/{id}", "view"));
        Res(anka, tEndpoint, "anka.kredionay", "Kredi onay",
            [("view", Severity.Low), ("approve", Severity.Critical)],
            ("GET", "/v1/kredi/dosya/{id}", "view"), ("POST", "/v1/kredi/dosya/{id}/onay", "approve"));
        Res(anka, tEndpoint, "anka.kredikullandirim", "Kredi kullandırım",
            [("execute", Severity.Critical)],
            ("POST", "/v1/kredi/dosya/{id}/kullandir", "execute"));
        Res(anka, tEndpoint, "anka.musteri", "Müşteri profili",
            [("view", Severity.Low), ("update", Severity.Medium)],
            ("GET", "/v1/musteriler/{musteriNo}", "view"), ("PUT", "/v1/musteriler/{musteriNo}", "update"));
        Res(anka, tEndpoint, "anka.raporsube", "Şube günlük raporu",
            [("view", Severity.Low), ("export", Severity.Medium)],
            ("GET", "/v1/raporlar/sube/{subeKodu}", "view"), ("GET", "/v1/raporlar/sube/{subeKodu}/export", "export"));

        // ---- NEXTRAL: menü → ekran → buton (URI yok; login'de entitlement ile açılır/kapanır).
        //      Uygulama kodu (GVADAG00...) Nextral'in kendi ekran kodudur; envanter eşleştirmesinde kullanılır.
        var mGise = Ui(nextral, tMenu, "nextral.menu.gise", "Gişe menüsü", "MGISE", [("view", Severity.Low)]);
        var eNakit = Ui(nextral, tScreen, "nextral.ekran.nakit", "Nakit işlemleri ekranı", "GNAKIT00", [("view", Severity.Low), ("print", Severity.Low)], mGise);
        Ui(nextral, tButton, "nextral.buton.nakitcekim", "Para çek butonu", "GNAKIT00.CEK", [("execute", Severity.High)], eNakit);
        var eVadeli = Ui(nextral, tScreen, "nextral.ekran.vadeli", "Vadeli hesap ekranı", "GVADAG00", [("view", Severity.Low)], mGise);
        Ui(nextral, tButton, "nextral.buton.vadelikapat", "Vadeli kapat butonu", "GVADAG00.KPT", [("execute", Severity.High)], eVadeli);
        var mKredi = Ui(nextral, tMenu, "nextral.menu.kredi", "Kredi menüsü", "MKREDI", [("view", Severity.Low)]);
        Ui(nextral, tScreen, "nextral.ekran.kredionay", "Kredi onay ekranı", "GKRONY00", [("view", Severity.Low)], mKredi);
        var mRapor = Ui(nextral, tMenu, "nextral.menu.rapor", "Rapor menüsü", "MRAPOR", [("view", Severity.Low)]);
        Ui(nextral, tScreen, "nextral.ekran.suberapor", "Şube raporu ekranı", "GSBRPR00", [("view", Severity.Low)], mRapor);

        // ---- B_PORTAL
        Res(bPortal, tEndpoint, "b_portal.portfoyrapor", "Portföy raporu", [("view", Severity.Low), ("export", Severity.Medium)],
            ("GET", "/v1/portfoy/rapor", "view"), ("GET", "/v1/portfoy/rapor/export", "export"));
        await db.SaveChangesAsync();

        // ================================ Roller (HR / kimlik) ================================
        Role Role(Tenant tenant, string code, string name, bool inheritable = false)
        {
            var r = new Role { Tenant = tenant, Code = code, Name = name, IsInheritable = inheritable };
            db.Roles.Add(r);
            return r;
        }
        var rPersonel = Role(abank, "PERSONEL", "Tüm personel (temel)", true);
        var rGiseAst = Role(abank, "GISEAST", "Gişe Asistanı");
        var rGiseYtk = Role(abank, "GISEYTK", "Gişe Yetkilisi");
        var rBryslAst = Role(abank, "BRYSLAST", "Bireysel Portföy Asistanı");
        var rBryslYtk = Role(abank, "BRYSLYTK", "Bireysel Portföy Yetkilisi");
        var rTicriYtk = Role(abank, "TICRIYTK", "Ticari Portföy Yetkilisi");
        var rSubeMdr = Role(abank, "SUBEMDR", "Şube Müdürü");
        var rBolge = Role(abank, "BOLGE_MDR", "Bölge Müdürü");
        var r928 = Role(abank, "GM928UZYTK", "GM 928 Uzman Yetkili");
        var r850 = Role(abank, "GM850UZYTK", "GM 850 Uzman Yetkili");
        var rBatch = Role(abank, "BATCH_RAPOR", "Rapor batch servisi");
        var rBPortfoy = Role(bIstirak, "B_PORTFOY", "B İştiraki Portföy Yöneticisi");
        await db.SaveChangesAsync();

        // ================================ Kullanıcılar ================================
        User UserOf(Tenant tenant, OrgUnit unit, string userName, string fullName, string title, Role? role, decimal limit = 0,
            string? customerNo = null, bool onLeave = false, UserKind kind = UserKind.Person)
        {
            var u = new User
            {
                Tenant = tenant, UserName = userName, FullName = fullName, Title = title, Kind = kind, IsOnLeave = onLeave,
                CashWithdrawalLimit = limit, CustomerNo = customerNo, Email = kind == UserKind.Person ? $"{userName}@abank.com.tr" : null,
                EmployeeNo = kind == UserKind.Person ? $"P{10000 + db.ChangeTracker.Entries<User>().Count()}" : null
            };
            u.OrgUnits.Add(new UserOrgUnit { OrgUnit = unit, IsPrimary = true });
            db.Users.Add(u);
            if (role is not null) db.UserRoles.Add(new UserRole { User = u, Role = role });
            return u;
        }

        UserOf(abank, u101, "ayse.yilmaz", "Ayşe Yılmaz", "Gişe Asistanı", rGiseAst, 50_000, "C-1001");
        UserOf(abank, u101, "mert.kaya", "Mert Kaya", "Stajyer Gişe Asistanı", rGiseAst, 10_000);
        UserOf(abank, u101, "zeynep.acar", "Zeynep Acar", "Gişe Yetkilisi", rGiseYtk, 250_000);
        UserOf(abank, u101, "ali.demir", "Ali Demir", "Şube Müdürü", rSubeMdr, 500_000);
        UserOf(abank, u101, "elif.sahin", "Elif Şahin", "Bireysel Portföy Asistanı", rBryslAst);
        UserOf(abank, u101, "can.ozturk", "Can Öztürk", "Bireysel Portföy Yetkilisi", rBryslYtk, 0, "C-2002");
        UserOf(abank, u101, "selin.aydin", "Selin Aydın", "Gişe Yetkilisi", rGiseYtk, 250_000, onLeave: true);
        UserOf(abank, u101, "hakan.tekin", "Hakan Tekin", "Ticari Portföy Yetkilisi", rTicriYtk);
        UserOf(abank, u101, "ahmet.kaya", "Ahmet Kaya", "Gişe Yetkilisi", rGiseYtk, 100_000, "C-3003");
        UserOf(abank, u737, "deniz.koc", "Deniz Koç", "Gişe Asistanı", rGiseAst, 50_000);
        var burak = UserOf(abank, u737, "burak.arslan", "Burak Arslan", "Bireysel Portföy Yetkilisi", rBryslYtk);
        UserOf(abank, u737, "emre.yildiz", "Emre Yıldız", "Şube Müdürü", rSubeMdr, 500_000);
        UserOf(abank, u1114, "kemal.sari", "Kemal Sarı", "Şube Müdürü", rSubeMdr, 500_000);
        UserOf(abank, ist, "murat.aksoy", "Murat Aksoy", "Bölge Müdürü", rBolge);
        var gul = UserOf(abank, u928, "gul.yuce", "Gül Yüce", "Uzman Yetkili", r928);
        UserOf(abank, u850, "sibel.ates", "Sibel Ateş", "Uzman Yetkili", r850);
        var svc = UserOf(abank, gm, "svc.rapor-batch", "Rapor Batch Servisi", "Servis Hesabı", rBatch, kind: UserKind.ServiceAccount);
        UserOf(bIstirak, b01, "nil.sezer", "Nil Sezer", "Portföy Yöneticisi", rBPortfoy);
        await db.SaveChangesAsync();

        // ================================ Gruplar ================================
        Group GroupOf(Tenant tenant, string code, string name, string description)
        {
            var g = new Group { Tenant = tenant, Code = code, Name = name, Description = description };
            db.Groups.Add(g);
            return g;
        }
        void Filter(Group g, InclusionMode mode, string description, params (string Attr, string[] Values)[] criteria) =>
            g.Filters.Add(new GroupFilter
            {
                Mode = mode, Order = g.Filters.Count, Description = description,
                Criteria = criteria.Select((c, i) => new GroupFilterCriterion
                {
                    Attribute = c.Attr, Order = i, Values = c.Values.Select(v => new GroupFilterValue { Value = v }).ToList()
                }).ToList()
            });

        var gAll = GroupOf(abank, "TUM_PERSONEL", "Tüm Personel", "A Bankası ve alt kurumlarındaki tüm kişiler (servis hesapları hariç) → PERSONEL rolü.");
        Filter(gAll, InclusionMode.Include, "Kişi ve A Bankası (alt tenant dahil)", ("USER_KIND", ["Person"]), ("TENANT", ["ABANK"]));
        gAll.Roles.Add(new GroupRole { Role = rPersonel });

        var g101 = GroupOf(abank, "GISE_101_AST", "101 Şube Gişe Asistanları", "101 Merkez Şube'deki gişe asistanları; stajyerler hariç.");
        Filter(g101, InclusionMode.Include, "101'deki gişe asistanları", ("ROLE", ["GISEAST"]), ("ORG_UNIT", ["101"]));
        Filter(g101, InclusionMode.Exclude, "Stajyerler hariç", ("TITLE", ["Stajyer Gişe Asistanı"]));

        var gVekalet = GroupOf(abank, "SUBEMDR_VEKALET_737", "737 Şube Müdürü Vekaleti", "Süreli açık üyelik: vekil şube müdürü rolünü alır.");
        gVekalet.Members.Add(new GroupMember { User = burak, ValidUntil = now.AddYears(1) });
        gVekalet.Roles.Add(new GroupRole { Role = rSubeMdr });

        var gKredi = GroupOf(abank, "KREDI_KOMITESI", "Kredi Komitesi", "GM 850 yetkilileri VEYA Merkez Şube müdürü (filtreler arası VEYA).");
        Filter(gKredi, InclusionMode.Include, "GM 850 yetkili", ("ROLE", ["GM850UZYTK"]));
        Filter(gKredi, InclusionMode.Include, "101 şube müdürü", ("ROLE", ["SUBEMDR"]), ("ORG_UNIT", ["101"]));
        await db.SaveChangesAsync();

        // ================================ Client'lar ================================
        Client ClientOf(string id, string name, ClientType type, CatalogApplication? app, string description, User? serviceUser = null, Tenant? tenant = null)
        {
            var c = new Client { Tenant = tenant ?? abank, ClientId = id, Name = name, Type = type, Application = app, Description = description, ServiceAccountUser = serviceUser };
            db.Clients.Add(c);
            return c;
        }
        // Nextral masaüstü motora hiç doğrudan gelmez: tüm istekleri (ekran listesi dahil) sunucudaki Nextral-Api yapar.
        // Client = nextral-api; Nextral ekran / buton / bileşenleri NEXTRAL uygulamasında sadece resource'tur.
        var cNextral = ClientOf("nextral-api", "Nextral API (Nextral masaüstünün arka ucu)", ClientType.Confidential, nextral,
            "Nextral masaüstü adına tüm istekleri yapan sunucu uygulaması. Masaüstü ekranları client değil, NEXTRAL'daki resource'lardır.");
        var cWeb = ClientOf("anka-web", "Anka Web (şube web uygulaması)", ClientType.Confidential, null, "Tarayıcıdan çalışan şube web uygulaması.");
        var cMobil = ClientOf("mobil-sube-tablet", "Mobil Şube Tablet", ClientType.Public, null, "Sahada tablet; cihaz uyumluluğu zorunlu.");
        var cGateway = ClientOf("anka-gateway", "Anka API Gateway", ClientType.Intermediary, anka, "Aracı: kullanıcı token'ını ve orijinal client'ı (azp) iletir; PEP burada.");
        var cBatch = ClientOf("rapor-batch", "Rapor Batch", ClientType.Service, anka, "Client credentials; svc.rapor-batch servis hesabıyla çalışır.", svc);
        var cBPortal = ClientOf("b-portal-web", "B Yatırımcı Portalı (web)", ClientType.Public, bPortal, "B İştiraki'nin client'ı.", tenant: bIstirak);

        // Soru kapsamı: her client sadece izin verilen uygulamalar ve kurumlar hakkında motora soru sorabilir.
        // ABANK kapsamı alt kurumu BISTIRAK'ı da içerir. Aracı (gateway) sadece izin verilen client'lar adına konuşabilir.
        void Scope(Client c, CatalogApplication[] apps, Tenant[] tenants, Client[]? onBehalfOf = null, int? rateLimit = null)
        {
            foreach (var a in apps) c.QueryApplications.Add(new ClientQueryApplication { Application = a });
            foreach (var t in tenants) c.QueryTenants.Add(new ClientQueryTenant { Tenant = t });
            foreach (var o in onBehalfOf ?? []) c.Delegations.Add(new ClientDelegation { OnBehalfOf = o });
            c.RateLimitPerMinute = rateLimit;
            // DEMO secret'ı (bilinen değer: ysk_demo_<client_id>) — sadece örnek veri; gerçek secret'lar ekrandan üretilir
            db.ClientSecrets.Add(new ClientSecret
            {
                Client = c, SecretHash = Yetki.Application.Definitions.ClientCredentialService.Hash($"ysk_demo_{c.ClientId}"),
                Prefix = "ysk_demo", Description = "Demo secret (örnek veri): ysk_demo_<client_id>", CreatedAt = now, CreatedBy = "ornek-veri"
            });
        }
        Scope(cNextral, [nextral, anka], [abank]);
        Scope(cWeb, [anka], [abank]);
        Scope(cMobil, [anka], [abank], rateLimit: 120);
        Scope(cGateway, [anka], [abank], [cNextral, cWeb, cMobil]);
        Scope(cBatch, [anka], [abank], rateLimit: 60);
        Scope(cBPortal, [bPortal], [bIstirak]);
        await db.SaveChangesAsync();

        // ================================ Ortak koşullar ================================
        var mesai = Shared("MESAI_SAATI", "Mesai saati (09:00-18:00, hafta içi)",
            Pred("TIME_WINDOW", ("Start", "09:00"), ("End", "18:00"), ("Days", "MON,TUE,WED,THU,FRI"), ("TimeZone", "Europe/Istanbul")));
        var bankaAgi = Shared("BANKA_AGI", "Banka iç ağı",
            Pred("IP_IN_RANGE", ("Cidrs", "10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,127.0.0.1/32,::1/128")));
        await db.SaveChangesAsync();

        // ================================ Policy'ler: KİM? ================================
        PolicyOf(abank, "ROL_SUBE_PERSONELI", "Şube personeli", PolicyType.Role, "Gişe, portföy ve şube yönetimi rolleri.", [rGiseAst.Id, rGiseYtk.Id, rBryslAst.Id, rBryslYtk.Id, rSubeMdr.Id]);
        PolicyOf(abank, "ROL_GISE", "Gişe personeli", PolicyType.Role, "Nakit işlemlerini yapan roller.", [rGiseAst.Id, rGiseYtk.Id]);
        PolicyOf(abank, "ROL_GISE_YETKILI", "Gişe yetkilisi ve şube müdürü", PolicyType.Role, "İptal gibi yetkili işlemleri yapan roller.", [rGiseYtk.Id, rSubeMdr.Id]);
        PolicyOf(abank, "ROL_HESAP_ACAN", "Hesap açabilen roller", PolicyType.Role, null, [rBryslAst.Id, rBryslYtk.Id, rGiseYtk.Id]);
        PolicyOf(abank, "ROL_VADELI_KAPATAN", "Vadeli hesap kapatabilen roller", PolicyType.Role, null, [rSubeMdr.Id, rBryslYtk.Id]);
        PolicyOf(abank, "ROL_EFT", "EFT yapabilen roller", PolicyType.Role, null, [rGiseYtk.Id, rTicriYtk.Id]);
        PolicyOf(abank, "ROL_KREDI", "Kredi personeli", PolicyType.Role, "Kredi başvurusu açan / görüntüleyen roller.", [rBryslYtk.Id, rTicriYtk.Id, rSubeMdr.Id, r850.Id]);
        PolicyOf(abank, "ROL_KREDI_ONAY", "Kredi onaylayan roller", PolicyType.Role, null, [rTicriYtk.Id, rSubeMdr.Id, r850.Id]);
        PolicyOf(abank, "ROL_RAPOR", "Rapor kullanıcıları", PolicyType.Role, null, [rSubeMdr.Id, rBolge.Id, rBatch.Id]);
        PolicyOf(abank, "ROL_PERSONEL", "Tüm personel", PolicyType.Role, "PERSONEL rolü (TUM_PERSONEL grubundan gelir).", [rPersonel.Id]);
        PolicyOf(bIstirak, "ROL_B_PORTFOY", "B İştiraki portföy", PolicyType.Role, null, [rBPortfoy.Id]);
        PolicyOf(abank, "GRP_KREDI_KOMITESI", "Kredi komitesi üyeleri", PolicyType.Group, "Kredi kullandırımı sadece komite.", [gKredi.Id]);
        PolicyOf(abank, "USR_IC_DENETIM", "İç denetim (adıyla)", PolicyType.User, "Denetim süresince rapor görüntüleme istisnası.", [gul.Id]);
        PolicyOf(abank, "KANAL_NEXTRAL", "Sadece Nextral (Nextral-Api üzerinden)", PolicyType.Client, "Nakit çekim butonu sadece Nextral kanalında (istek Nextral-Api'den gelmeli).", [cNextral.Id]);

        // ================================ Policy'ler: HANGİ KOŞULDA? (ABAC) ================================
        var pAg = PolicyOf(abank, "KURUMSAL_AG", "Banka ağından", PolicyType.Condition, "İstek banka iç ağından gelmeli.");
        RuleOf(pAg, "BANK_NETWORK", "İstek banka ağından gelmeli", 10, "OUTSIDE_BANK_NETWORK", Ref(bankaAgi));

        var pMesai = PolicyOf(abank, "MESAI", "Mesai saatinde", PolicyType.Condition, "Hafta içi 09:00-18:00 (İstanbul).");
        RuleOf(pMesai, "WORKING_HOURS", "Mesai saatinde olmalı", 10, "OUTSIDE_BUSINESS_HOURS", Ref(mesai));

        var pLimit = PolicyOf(abank, "CEKIM_LIMITI", "Çekim limiti ve kendi hesabı", PolicyType.Condition, "Tutar kullanıcı limitini aşamaz; personel kendi hesabında işlem yapamaz.");
        RuleOf(pLimit, "TRANSACTION_LIMIT", "Tutar ≤ kullanıcının işlem limiti", 10, "AMOUNT_EXCEEDS_USER_LIMIT", Not(Pred("AMOUNT_EXCEEDS_SUBJECT_LIMIT")));
        RuleOf(pLimit, "NOT_SELF_TRANSACTION", "Personelin kendi hesabı olmamalı", 20, "SELF_TRANSACTION_NOT_ALLOWED", Not(Pred("CUSTOMER_IS_SELF")));

        var pIzin = PolicyOf(abank, "IZINLI", "Kullanıcı izinde", PolicyType.Condition, "NEGATİF logic ile kullanılır: izindeyse reddeder.", logic: PolicyLogic.Negative);
        RuleOf(pIzin, "ON_LEAVE", "Kullanıcı izinde", 10, "USER_ON_LEAVE", Pred("USER_ON_LEAVE"));

        var pKapsam = PolicyOf(abank, "SUBE_KAPSAMI", "Şube veri kapsamı", PolicyType.Condition, "İşlemin şubesi (BranchCode) kullanıcının kapsamında olmalı; GM 928 hepsini görür.",
            strategy: DecisionStrategy.Affirmative);
        RuleOf(pKapsam, "BRANCH_SCOPE", "Şube kullanıcının kapsamında", 10, "OUT_OF_BRANCH_SCOPE", Pred("BRANCH_IN_USER_SCOPE"));
        RuleOf(pKapsam, "HQ_928", "GM 928 personeli", 20, "OUT_OF_BRANCH_SCOPE", Pred("SUBJECT_IN_UNIT", ("Units", "928")));

        var pKrediLimit = PolicyOf(abank, "KREDI_SUBE_LIMITI", "Şube kredi onay limiti", PolicyType.Condition, "1.000.000 üzeri sadece GM 850.");
        RuleOf(pKrediLimit, "APPROVAL_LIMIT", "Tutar ≤ 1M veya onaylayan GM 850", 10, "APPROVAL_LIMIT_EXCEEDED",
            Any(Not(Pred("AMOUNT_GREATER_THAN", ("Threshold", "1000000"))), Pred("SUBJECT_HAS_ROLE", ("Roles", "GM850UZYTK"))));

        var pMobilDisi = PolicyOf(abank, "MOBIL_DISI_KANAL", "Mobil tablet DEĞİLSE", PolicyType.Client,
            "NEGATİF client policy: istek mobil tabletten gelmiyorsa izin verir.", [cMobil.Id], logic: PolicyLogic.Negative);
        var pCihaz = PolicyOf(abank, "CIHAZ_UYUMLU", "Cihaz MDM uyumlu", PolicyType.Condition, "Cihaz kurumsal cihaz yönetimine göre uyumlu.");
        RuleOf(pCihaz, "DEVICE_COMPLIANT", "Cihaz MDM uyumlu olmalı", 10, "DEVICE_NOT_COMPLIANT", Pred("DEVICE_COMPLIANT"));

        var pMaske = PolicyOf(abank, "WEB_MASKE", "Web kanalında maskele", PolicyType.Client,
            "Advisory: kararı etkilemez; istek Anka Web'den gelirse TCKN / telefon / hesap no maskelenir.", [cWeb.Id], mode: PolicyMode.Advisory);
        Obligation(pMaske, "MASK_FIELDS", ("Fields", "tckn,telefon,hesapNo"), ("KeepLast", "2"));

        var pRaporMesai = PolicyOf(abank, "RAPOR_MESAI_DENEME", "Rapor erişimi mesai saatinde (deneme)", PolicyType.Condition,
            "ReportOnly: kararı etkilemez; devreye almadan önce kim etkilenirdi görmek için.", mode: PolicyMode.ReportOnly);
        RuleOf(pRaporMesai, "REPORT_WORKING_HOURS", "Mesai saatinde", 10, "REPORT_OUTSIDE_HOURS", Ref(mesai));
        await db.SaveChangesAsync();

        // ---- Aggregate: tekrar kullanılan birleşik koşul / "şu VEYA bu" kimlik
        PolicyOf(abank, "GISE_GUVENLI_ISLEM", "Gişe güvenli işlem ortamı", PolicyType.Aggregate,
            "Banka ağı + mesai + izinde değil (hepsi sağlanmalı).", [pAg.Id, pMesai.Id, pIzin.Id]);
        PolicyOf(abank, "MOBIL_CIHAZ", "Mobil kanalda cihaz uyumlu", PolicyType.Aggregate,
            "Affirmative: mobil tablet DEĞİLSE serbest; mobil tabletse cihaz MDM uyumlu olmalı.", [pMobilDisi.Id, pCihaz.Id], strategy: DecisionStrategy.Affirmative);
        PolicyOf(abank, "RAPOR_KULLANICILARI", "Rapor rolleri veya iç denetim", PolicyType.Aggregate,
            "Affirmative: rapor rollerinden biri VEYA iç denetim istisnası yeterli.",
            [_policies["ROL_RAPOR"].Id, _policies["USR_IC_DENETIM"].Id], strategy: DecisionStrategy.Affirmative);
        await db.SaveChangesAsync();

        // ================================ Permission'lar: HANGİ resource/scope ← HANGİ policy'ler ================================
        Permission("ANKA", "NAKIT_CEKIM", "Nakit çekim yapma", ["anka.nakitcekim"], ["create"],
            ["ROL_GISE", "GISE_GUVENLI_ISLEM", "CEKIM_LIMITI"]);
        Permission("ANKA", "NAKIT_CEKIM_GORUNTULE", "Nakit çekim sorgulama", ["anka.nakitcekim"], ["view"],
            ["ROL_SUBE_PERSONELI", "WEB_MASKE"]);
        Permission("ANKA", "NAKIT_CEKIM_IPTAL", "Nakit çekim iptali", ["anka.nakitcekim"], ["cancel"],
            ["ROL_GISE_YETKILI", "GISE_GUVENLI_ISLEM"]);
        Permission("ANKA", "VADELI_GORUNTULE", "Vadeli hesap görüntüleme", ["anka.vadelihesap"], ["view"],
            ["ROL_SUBE_PERSONELI", "MESAI", "MOBIL_CIHAZ", "WEB_MASKE"]);
        Permission("ANKA", "VADELI_AC", "Vadeli hesap açma", ["anka.vadelihesap"], ["create"],
            ["ROL_HESAP_ACAN", "KURUMSAL_AG"]);
        Permission("ANKA", "VADELI_KAPAT", "Vadeli hesap kapatma", ["anka.vadelihesap"], ["close"],
            ["ROL_VADELI_KAPATAN", "GISE_GUVENLI_ISLEM"]);
        Permission("ANKA", "EFT", "EFT gönderme ve iptal", ["anka.eft"], ["create", "cancel"],
            ["ROL_EFT", "KURUMSAL_AG"]);
        Permission("ANKA", "EFT_GORUNTULE", "EFT sorgulama", ["anka.eft"], ["view"],
            ["ROL_SUBE_PERSONELI"]);
        Permission("ANKA", "KREDI_BASVURU", "Kredi başvurusu", ["anka.kredibasvuru"], [],
            ["ROL_KREDI"]);
        Permission("ANKA", "KREDI_ONAY", "Kredi onaylama", ["anka.kredionay"], ["approve"],
            ["ROL_KREDI_ONAY", "KURUMSAL_AG", "KREDI_SUBE_LIMITI"]);
        Permission("ANKA", "KREDI_DOSYA_GORUNTULE", "Kredi dosyası görüntüleme", ["anka.kredionay"], ["view"],
            ["ROL_KREDI"]);
        Permission("ANKA", "KREDI_KULLANDIRIM", "Kredi kullandırım", ["anka.kredikullandirim"], [],
            ["GRP_KREDI_KOMITESI", "KURUMSAL_AG"]);
        Permission("ANKA", "MUSTERI_GORUNTULE", "Müşteri görüntüleme", ["anka.musteri"], ["view"],
            ["ROL_PERSONEL", "WEB_MASKE"]);
        Permission("ANKA", "MUSTERI_GUNCELLE", "Müşteri güncelleme", ["anka.musteri"], ["update"],
            ["ROL_HESAP_ACAN", "KURUMSAL_AG"]);
        Permission("ANKA", "SUBE_RAPORU", "Şube raporu", ["anka.raporsube"], [],
            ["RAPOR_KULLANICILARI", "SUBE_KAPSAMI", "RAPOR_MESAI_DENEME"]);

        Permission("NEXTRAL", "NX_GISE_EKRANLARI", "Gişe menü ve ekranları", ["nextral.menu.gise", "nextral.ekran.nakit", "nextral.ekran.vadeli"], ["view", "print"],
            ["ROL_SUBE_PERSONELI"]);
        Permission("NEXTRAL", "NX_NAKIT_CEKIM_BUTONU", "Para çek butonu", ["nextral.buton.nakitcekim"], [],
            ["ROL_GISE", "KANAL_NEXTRAL"]);
        Permission("NEXTRAL", "NX_VADELI_KAPAT_BUTONU", "Vadeli kapat butonu", ["nextral.buton.vadelikapat"], [],
            ["ROL_VADELI_KAPATAN"]);
        Permission("NEXTRAL", "NX_KREDI_EKRANLARI", "Kredi menü ve ekranları", ["nextral.menu.kredi", "nextral.ekran.kredionay"], [],
            ["ROL_KREDI"]);
        Permission("NEXTRAL", "NX_RAPOR_EKRANLARI", "Rapor menü ve ekranları", ["nextral.menu.rapor", "nextral.ekran.suberapor"], [],
            ["ROL_RAPOR"]);

        Permission("B_PORTAL", "B_PORTFOY_RAPORU", "Portföy raporu", ["b_portal.portfoyrapor"], [],
            ["ROL_B_PORTFOY"]);
        await db.SaveChangesAsync();

        // ================================ Envanter (sadece bilgi; yetkiye etkisi yok) ================================
        // ANKA Swagger'ı: tanımlıların çoğu + tanımsız 2 endpoint (dekont, EFT listesi); kredi başvuru detayı Swagger'da yok (atıl örneği).
        Inventory(anka, InventoryKind.Endpoint, "Anka Swagger v1.8 (örnek)",
        [
            ("POST", "/v1/cash-withdrawals", "Nakit çekim"), ("GET", "/v1/cash-withdrawals", "Nakit çekim listesi"), ("GET", "/v1/cash-withdrawals/{id}", "Nakit çekim detayı"),
            ("POST", "/v1/cash-withdrawals/{id}/cancel", "Nakit çekim iptali"),
            ("GET", "/v1/vadeli-hesap", "Vadeli hesap listesi"), ("GET", "/v1/vadeli-hesap/{hesapNo}", "Vadeli hesap detayı"), ("POST", "/v1/vadeli-hesap", "Vadeli hesap aç"),
            ("POST", "/v1/vadeli-hesap/{hesapNo}/kapat", "Vadeli hesap kapat"), ("GET", "/v1/vadeli-hesap/{hesapNo}/dekont", "Vadeli hesap dekontu"),
            ("POST", "/v1/eft", "EFT gönder"), ("GET", "/v1/eft", "EFT listesi"), ("GET", "/v1/eft/{id}", "EFT detayı"), ("DELETE", "/v1/eft/{id}", "EFT iptal"),
            ("POST", "/v1/kredi/basvuru", "Kredi başvurusu"),
            ("GET", "/v1/kredi/dosya/{id}", "Kredi dosyası"), ("POST", "/v1/kredi/dosya/{id}/onay", "Kredi onayı"), ("POST", "/v1/kredi/dosya/{id}/kullandir", "Kredi kullandırım"),
            ("GET", "/v1/musteriler/{musteriNo}", "Müşteri profili"), ("PUT", "/v1/musteriler/{musteriNo}", "Müşteri güncelle"),
            ("GET", "/v1/raporlar/sube/{subeKodu}", "Şube raporu"), ("GET", "/v1/raporlar/sube/{subeKodu}/export", "Şube raporu dışa aktar")
        ]);
        // NEXTRAL ekran listesi: tanımlıların çoğu + tanımsız "Kredi limit" ekranı; şube raporu ekranı listede yok (atıl örneği).
        UiInventory(nextral, "Nextral ekran listesi (örnek)",
        [
            ("MGISE", "Gişe menüsü", null, "MENU"), ("GNAKIT00", "Nakit işlemleri", "MGISE", "SCREEN"), ("GNAKIT00.CEK", "Para çek", "GNAKIT00", "BUTTON"),
            ("GVADAG00", "Vadeli hesap", "MGISE", "SCREEN"), ("GVADAG00.KPT", "Vadeli kapat", "GVADAG00", "BUTTON"),
            ("MKREDI", "Kredi menüsü", null, "MENU"), ("GKRONY00", "Kredi onay", "MKREDI", "SCREEN"), ("GKRLMT00", "Kredi limit", "MKREDI", "SCREEN"),
            ("MRAPOR", "Rapor menüsü", null, "MENU")
        ]);
        await db.SaveChangesAsync();

        // ================================ SoD ================================
        db.SodRules.Add(new SodRule
        {
            Code = "SOD_KREDI_ONAY_KULLANDIRIM", Name = "Krediyi onaylayan kullandıramaz", Severity = Severity.High, Enforcement = SodEnforcement.Warn,
            Description = "Aynı kişi hem onaylayıp hem kullandırmamalı (4 göz).",
            Members =
            [
                new SodRuleMember { MemberType = SodMemberType.ResourceScope, MemberId = RS("anka.kredionay", "approve").Id },
                new SodRuleMember { MemberType = SodMemberType.ResourceScope, MemberId = RS("anka.kredikullandirim", "execute").Id }
            ]
        });
        db.SodRules.Add(new SodRule
        {
            Code = "SOD_GISE_SUBE_MUDURU", Name = "Gişe asistanı şube müdürü olamaz", Severity = Severity.Critical, Enforcement = SodEnforcement.Block,
            Description = "Kasa işlemini yapan ile onaylayan aynı kişi olamaz.",
            Members =
            [
                new SodRuleMember { MemberType = SodMemberType.Role, MemberId = rGiseAst.Id },
                new SodRuleMember { MemberType = SodMemberType.Role, MemberId = rSubeMdr.Id }
            ]
        });

        // ================================ Dış sistemler (RACF / LDAP) ================================
        var racf = new ExternalSystem { Code = "RACF", Name = "IBM RACF (z/OS)", Description = "CICS transaction, dataset ve uygulama profilleri", HasAccessLevels = true };
        var ldap = new ExternalSystem { Code = "LDAP", Name = "Kurumsal LDAP", Description = "Nextral uygulama grupları (üyelik)", HasAccessLevels = false };
        db.ExternalSystems.AddRange(racf, ldap);
        ExternalPermission Ext(ExternalSystem sys, string code, string cls, string name)
        {
            var e = new ExternalPermission { ExternalSystem = sys, Code = code, ResourceClass = cls, Name = name };
            db.ExternalPermissions.Add(e);
            return e;
        }
        void Requires(ExternalPermission from, ExternalPermission to, ExternalAccessLevel? level = null) =>
            db.ExternalPermissionRequirements.Add(new ExternalPermissionRequirement { ExternalPermission = from, RequiredExternalPermission = to, AccessLevel = level });
        void OnResource(string resource, ExternalPermission e, ExternalAccessLevel? level = null) =>
            db.ExternalDependencies.Add(new ExternalDependency { Resource = _resources[resource], ExternalPermission = e, AccessLevel = level });
        void OnAccess(string resource, string scope, ExternalPermission e, ExternalAccessLevel? level = null) =>
            db.ExternalDependencies.Add(new ExternalDependency { ResourceScope = RS(resource, scope), ExternalPermission = e, AccessLevel = level });

        var cicsVdl = Ext(racf, "CICSVDL", "APPL", "Vadeli hesap CICS bölgesi");
        var vdsr = Ext(racf, "VDSR", "TCICSTRN", "Vadeli sorgu transaction");
        var vdac = Ext(racf, "VDAC", "TCICSTRN", "Vadeli açılış transaction");
        var vdkp = Ext(racf, "VDKP", "TCICSTRN", "Vadeli kapama transaction");
        var vdlMaster = Ext(racf, "BNK.VADELI.MASTER", "DATASET", "Vadeli hesap ana dosyası");
        OnResource("anka.vadelihesap", cicsVdl, ExternalAccessLevel.Read);   // tüm scope'lar bölgeye bağlanır
        OnAccess("anka.vadelihesap", "view", vdsr);                          // seviye scope'tan: view → READ
        OnAccess("anka.vadelihesap", "create", vdac);                        // create → UPDATE
        OnAccess("anka.vadelihesap", "close", vdkp);                         // close → UPDATE
        Requires(vdsr, vdlMaster, ExternalAccessLevel.Read);
        Requires(vdac, vdlMaster);
        Requires(vdkp, vdlMaster);

        var cicsNkt = Ext(racf, "CICSNKT", "APPL", "Nakit CICS bölgesi");
        var nkc1 = Ext(racf, "NKC1", "TCICSTRN", "Nakit çekim transaction");
        var nki1 = Ext(racf, "NKI1", "TCICSTRN", "Nakit çekim iptal transaction");
        var kasa = Ext(racf, "BNK.KASA.HAREKET", "DATASET", "Kasa hareket dosyası");
        OnResource("anka.nakitcekim", cicsNkt, ExternalAccessLevel.Read);
        OnAccess("anka.nakitcekim", "create", nkc1);
        OnAccess("anka.nakitcekim", "cancel", nki1);
        Requires(nkc1, kasa);
        Requires(nki1, kasa);

        var krd9 = Ext(racf, "KRD9", "TCICSTRN", "Kredi onay transaction");
        OnAccess("anka.kredionay", "approve", krd9);
        OnResource("nextral.menu.gise", Ext(ldap, "CN=NEXTRAL_GISE", "GROUP", "Nextral gişe kullanıcıları"));
        await db.SaveChangesAsync();
    }

    // ================================ Yardımcılar ================================

    private ResourceType Type(string code, string name, string description, bool http, bool hierarchy, string color)
    {
        var t = new ResourceType { Code = code, Name = name, Description = description, MatchesHttp = http, SupportsHierarchy = hierarchy, Color = color };
        db.ResourceTypes.Add(t);
        return t;
    }

    private void ScopeOf(CatalogApplication app, string code, string name)
    {
        var s = new Scope { Application = app, Code = code, Name = name };
        db.Scopes.Add(s);
        _scopes[$"{app.Code}:{code}"] = s;
    }

    private Resource Res(CatalogApplication app, ResourceType type, string code, string name,
        (string Scope, Severity Risk)[] scopes, params (string Method, string Pattern, string Scope)[] uris)
    {
        var r = new Resource
        {
            Application = app, ResourceType = type, Code = code, Name = name, Order = _resources.Count,
            Scopes = scopes.Select(s => new ResourceScope { Scope = _scopes[$"{app.Code}:{s.Scope}"], RiskLevel = s.Risk }).ToList(),
            Uris = uris.Select(u => new ResourceUri { Method = u.Method, Pattern = u.Pattern, Scope = _scopes[$"{app.Code}:{u.Scope}"] }).ToList()
        };
        db.Resources.Add(r);
        _resources[code] = r;
        return r;
    }

    /// <summary>URI'siz UI resource'u (menü / ekran / buton); externalCode uygulamanın kendi kodu.</summary>
    private Resource Ui(CatalogApplication app, ResourceType type, string code, string name, string externalCode,
        (string Scope, Severity Risk)[] scopes, Resource? parent = null)
    {
        var r = Res(app, type, code, name, scopes);
        r.Parent = parent;
        r.ExternalCode = externalCode;
        return r;
    }

    private void Inventory(CatalogApplication app, InventoryKind kind, string source, (string Method, string Path, string Name)[] items) =>
        db.InventorySnapshots.Add(new InventorySnapshot
        {
            Application = app, Kind = kind, Source = source, ImportedAt = clock.UtcNow, ImportedBy = "ornek-veri",
            Items = items.Select(i => new InventoryItem { Method = i.Method, Path = i.Path, Name = i.Name }).ToList()
        });

    private void UiInventory(CatalogApplication app, string source, (string Code, string Name, string? Parent, string Type)[] items) =>
        db.InventorySnapshots.Add(new InventorySnapshot
        {
            Application = app, Kind = InventoryKind.UiElement, Source = source, ImportedAt = clock.UtcNow, ImportedBy = "ornek-veri",
            Items = items.Select(i => new InventoryItem { Code = i.Code, Name = i.Name, ParentCode = i.Parent, ElementType = i.Type }).ToList()
        });

    private ResourceScope RS(string resource, string scope) =>
        _resources[resource].Scopes.Single(s => s.Scope.Code == scope);

    private Policy PolicyOf(Tenant tenant, string code, string name, PolicyType type, string? description, int[]? members = null,
        PolicyLogic logic = PolicyLogic.Positive, DecisionStrategy strategy = DecisionStrategy.Unanimous, PolicyMode mode = PolicyMode.Enforce)
    {
        var p = new Policy
        {
            Tenant = tenant, Code = code, Name = name, Description = description, Type = type, Logic = logic, DecisionStrategy = strategy, Mode = mode,
            Members = (members ?? []).Select(m => new PolicyMember { MemberId = m }).ToList()
        };
        db.Policies.Add(p);
        _policies[code] = p;
        return p;
    }

    private void Permission(string app, string code, string name, string[] resources, string[] scopes, string[] policies,
        DecisionStrategy strategy = DecisionStrategy.Unanimous)
    {
        var application = db.Applications.Local.Single(a => a.Code == app);
        db.Permissions.Add(new Permission
        {
            // Kapsam açık: listelenen resource'lar; scope listesi boşsa bilinçli "tüm scope'lar"
            Application = application, Code = code, Name = name, DecisionStrategy = strategy,
            Target = PermissionTarget.Resources, AllScopes = scopes.Length == 0,
            Resources = resources.Select(r => new PermissionResource { Resource = _resources[r] }).ToList(),
            Scopes = scopes.Select(s => new PermissionScope { Scope = _scopes[$"{app}:{s}"] }).ToList(),
            Policies = policies.Select((p, i) => new PermissionPolicy { Policy = _policies[p], Order = i }).ToList()
        });
    }

    private static void Obligation(Policy p, string code, params (string Key, string Value)[] parameters) =>
        p.Obligations.Add(new PolicyObligation
        {
            Code = code, Order = p.Obligations.Count,
            Parameters = parameters.Select(x => new PolicyObligationParameter { Key = x.Key, Value = x.Value }).ToList()
        });

    private sealed record Spec(ConditionKind Kind, string? Type, (string Key, string Value)[] Params, Spec[] Children, SharedCondition? Ref = null);

    private static Spec Pred(string type, params (string, string)[] ps) => new(ConditionKind.Predicate, type, ps, []);
    private static Spec Not(Spec s) => new(ConditionKind.Not, null, [], [s]);
    private static Spec Any(params Spec[] s) => new(ConditionKind.AnyOf, null, [], s);
    private static Spec Ref(SharedCondition sc) => new(ConditionKind.Reference, null, [], [], sc);

    private void RuleOf(Policy p, string code, string name, int order, string? reason, Spec condition)
    {
        var r = new Rule { Policy = p, Code = code, Name = name, Order = order, ReasonCode = reason };
        db.Rules.Add(r);
        Build(condition, r, null, null, 0);
    }

    private SharedCondition Shared(string code, string name, Spec condition)
    {
        var sc = new SharedCondition { Code = code, Name = name };
        db.SharedConditions.Add(sc);
        Build(condition, null, sc, null, 0);
        return sc;
    }

    private void Build(Spec s, Rule? rule, SharedCondition? owner, RuleCondition? parent, int order)
    {
        var node = new RuleCondition
        {
            Rule = rule, SharedCondition = owner, Parent = parent, Kind = s.Kind, Order = order,
            ConditionType = s.Type is null ? null : _types.TryGetValue(s.Type, out var t) ? t : throw new InvalidOperationException($"Seed: condition tipi yok: {s.Type}"),
            ReferencedSharedCondition = s.Ref,
            Parameters = s.Params.Select(x => new ConditionParameter { Key = x.Key, Value = x.Value }).ToList()
        };
        db.RuleConditions.Add(node);
        for (var i = 0; i < s.Children.Length; i++) Build(s.Children[i], rule, owner, node, i);
    }
}
