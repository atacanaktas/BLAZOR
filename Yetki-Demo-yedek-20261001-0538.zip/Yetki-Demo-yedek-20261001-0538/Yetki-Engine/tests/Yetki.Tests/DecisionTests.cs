using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine;

namespace Yetki.Tests;

/// <summary>
/// Karar akışı (Keycloak modeli): gateway METHOD + URI → resource:scope → permission'lar → policy'ler (rol / grup / kullanıcı /
/// client / condition / aggregate, negatif logic, Advisory / ReportOnly) → karar.
/// </summary>
public class DecisionTests
{
    private static readonly (string, string?)[] Cekim20K = [("TransactionAmount", "20000"), ("CustomerId", "C-9999")];

    [Fact]
    public async Task Gateway_istegi_URI_deseniyle_yetkiye_cozulur_ve_izin_verilir()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await host.HttpAsync("ayse.yilmaz", "POST", "/v1/cash-withdrawals", null, Cekim20K);

        Assert.Equal(DecisionType.Permit, d.Decision);
        Assert.Equal("anka.nakitcekim:create", d.Permission);
        Assert.Equal("POST /v1/cash-withdrawals", d.MatchedUri);
        Assert.Equal("ENDPOINT", d.ResourceType);
        Assert.Contains(d.Permissions, p => p.Code == "NAKIT_CEKIM" && p.Result == DecisionType.Permit);
    }

    [Theory]
    [InlineData("GET", "/v1/bilinmeyen/1")]
    [InlineData("POST", "/v1/vadeli-hesap/TR1")]       // yol var ama METHOD tanımlı değil
    [InlineData("GET", "/v1/cash-withdrawals/1/extra")]
    public async Task Tanimsiz_URI_her_zaman_reddedilir(string method, string path)
    {
        await using var host = await TestHost.CreateAsync();
        var d = await host.HttpAsync("ali.demir", method, path);
        Assert.Equal(DecisionType.Deny, d.Decision);
        Assert.Equal("URI_NOT_REGISTERED", d.ReasonCode);
    }

    [Fact]
    public async Task Rol_policy_si_kimligi_sart_kosar()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await host.HttpAsync("elif.sahin", "POST", "/v1/cash-withdrawals", null, Cekim20K);
        Assert.Equal(DecisionType.Deny, d.Decision);
        Assert.Equal("ROLE_REQUIRED", d.ReasonCode);
        Assert.Equal("ROL_GISE", d.DecidingPolicy);
    }

    [Fact]
    public async Task Condition_policy_limiti_ve_kendi_hesabini_kontrol_eder()
    {
        await using var host = await TestHost.CreateAsync();
        var over = await host.EvaluateAsync("ayse.yilmaz", "anka.nakitcekim:create", null, ("TransactionAmount", "75000"), ("CustomerId", "C-9999"));
        Assert.Equal(DecisionType.Deny, over.Decision);
        Assert.Equal("AMOUNT_EXCEEDS_USER_LIMIT", over.ReasonCode);
        Assert.Equal("CEKIM_LIMITI", over.DecidingPolicy);

        var self = await host.EvaluateAsync("ayse.yilmaz", "anka.nakitcekim:create", null, ("TransactionAmount", "100"), ("CustomerId", "C-1001"));
        Assert.Equal("SELF_TRANSACTION_NOT_ALLOWED", self.ReasonCode);
    }

    [Fact]
    public async Task Negatif_logic_izindeki_personeli_aggregate_icinden_reddeder()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await host.EvaluateAsync("selin.aydin", "anka.nakitcekim:create", null, ("TransactionAmount", "1000"), ("CustomerId", "C-9"));
        Assert.Equal(DecisionType.Deny, d.Decision);
        Assert.Equal("USER_ON_LEAVE", d.ReasonCode);
        Assert.Equal("NAKIT_CEKIM", d.DecidingPermission);
        Assert.Equal("IZINLI", d.DecidingPolicy);           // GISE_GUVENLI_ISLEM aggregate'inin içinden
    }

    [Fact]
    public async Task Policy_nin_ihtiyac_duydugu_alan_gelmezse_fail_closed()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await host.EvaluateAsync("ayse.yilmaz", "anka.nakitcekim:create", null, ("CustomerId", "C-9"));
        Assert.Equal(DecisionType.Indeterminate, d.Decision);
        Assert.False(d.IsAllowed);
        Assert.Equal("MISSING_ATTRIBUTE", d.ReasonCode);
        Assert.Contains("Context.TransactionAmount", d.MissingAttributes);
    }

    [Fact]
    public async Task Mesai_disi_reddedilir()
    {
        await using var host = await TestHost.CreateAsync();
        host.Clock.UtcNow = new DateTime(2026, 9, 22, 16, 30, 0, DateTimeKind.Utc); // 19:30 İstanbul
        var d = await host.HttpAsync("ayse.yilmaz", "GET", "/v1/vadeli-hesap/TR1", "anka-web");
        Assert.Equal(DecisionType.Deny, d.Decision);
        Assert.Equal("OUTSIDE_BUSINESS_HOURS", d.ReasonCode);
    }

    [Fact]
    public async Task Negatif_client_policy_ve_affirmative_aggregate_ile_mobil_cihaz_kurali()
    {
        await using var host = await TestHost.CreateAsync();
        var web = await host.HttpAsync("ayse.yilmaz", "GET", "/v1/vadeli-hesap/TR1", "anka-web");
        var mobileUnknownDevice = await host.HttpAsync("ayse.yilmaz", "GET", "/v1/vadeli-hesap/TR1", "mobil-sube-tablet");
        var mobileCompliant = await host.HttpAsync("ayse.yilmaz", "GET", "/v1/vadeli-hesap/TR1", "mobil-sube-tablet", ("DeviceCompliant", "true"));

        Assert.Equal(DecisionType.Permit, web.Decision);                              // mobil değil → serbest
        Assert.Equal(DecisionType.Indeterminate, mobileUnknownDevice.Decision);      // mobil + cihaz bilgisi yok → fail-closed
        Assert.Contains("Environment.DeviceCompliant", mobileUnknownDevice.MissingAttributes);
        Assert.Equal(DecisionType.Permit, mobileCompliant.Decision);
    }

    [Fact]
    public async Task Advisory_policy_karari_etkilemez_kanala_gore_yukumluluk_ekler()
    {
        await using var host = await TestHost.CreateAsync();
        var web = await host.HttpAsync("ayse.yilmaz", "GET", "/v1/cash-withdrawals/42", "anka-web");
        var desktop = await host.HttpAsync("ayse.yilmaz", "GET", "/v1/cash-withdrawals/42", "nextral-api");

        Assert.Equal(DecisionType.Permit, web.Decision);
        var mask = Assert.Single(web.Obligations);
        Assert.Equal("MASK_FIELDS", mask.Code);
        Assert.Equal("WEB_MASKE", mask.Policy);
        Assert.Equal(DecisionType.Permit, desktop.Decision);
        Assert.Empty(desktop.Obligations);
    }

    [Fact]
    public async Task Client_policy_butonu_sadece_izinli_kanalda_acar()
    {
        await using var host = await TestHost.CreateAsync();
        var desktop = await host.EvaluateAsync("ayse.yilmaz", "nextral.buton.nakitcekim:execute", "nextral-api");
        var web = await host.EvaluateAsync("ayse.yilmaz", "nextral.buton.nakitcekim:execute", "anka-web");

        Assert.Equal(DecisionType.Permit, desktop.Decision);
        Assert.Equal(DecisionType.Deny, web.Decision);
        Assert.Equal("CLIENT_NOT_ALLOWED", web.ReasonCode);
        Assert.Equal("KANAL_NEXTRAL", web.DecidingPolicy);
    }

    [Fact]
    public async Task Group_policy_si_dinamik_grup_uyeligine_bakar()
    {
        await using var host = await TestHost.CreateAsync();
        var sibel = await host.HttpAsync("sibel.ates", "POST", "/v1/kredi/dosya/9/kullandir");
        var hakan = await host.HttpAsync("hakan.tekin", "POST", "/v1/kredi/dosya/9/kullandir");

        Assert.Equal(DecisionType.Permit, sibel.Decision);   // GM850UZYTK → KREDI_KOMITESI (kitle kuralı)
        Assert.Equal(DecisionType.Deny, hakan.Decision);
        Assert.Equal("GROUP_REQUIRED", hakan.ReasonCode);
    }

    [Fact]
    public async Task Affirmative_aggregate_rol_veya_kullanici_istisnasi_ve_sube_kapsami()
    {
        await using var host = await TestHost.CreateAsync();
        var auditor = await host.HttpAsync("gul.yuce", "GET", "/v1/raporlar/sube/101");                                     // rol yok ama USR_IC_DENETIM; GM 928 kapsamı
        var ownBranch = await host.HttpAsync("ali.demir", "GET", "/v1/raporlar/sube/101", null, ("BranchCode", "101"));
        var otherBranch = await host.HttpAsync("ali.demir", "GET", "/v1/raporlar/sube/737", null, ("BranchCode", "737"));
        var noBranch = await host.HttpAsync("ali.demir", "GET", "/v1/raporlar/sube/101");
        var noRole = await host.HttpAsync("ayse.yilmaz", "GET", "/v1/raporlar/sube/101", null, ("BranchCode", "101"));

        Assert.Equal(DecisionType.Permit, auditor.Decision);
        Assert.Equal(DecisionType.Permit, ownBranch.Decision);
        Assert.Equal("OUT_OF_BRANCH_SCOPE", otherBranch.ReasonCode);
        Assert.Equal(DecisionType.Indeterminate, noBranch.Decision);                // gateway şube bilgisini göndermedi
        Assert.Contains("Context.BranchCode", noBranch.MissingAttributes);
        Assert.Equal(DecisionType.Deny, noRole.Decision);
    }

    [Fact]
    public async Task ReportOnly_policy_karari_etkilemez_ama_raporlanir()
    {
        await using var host = await TestHost.CreateAsync();
        host.Clock.UtcNow = new DateTime(2026, 9, 22, 17, 0, 0, DateTimeKind.Utc); // 20:00 İstanbul
        var d = await host.HttpAsync("ali.demir", "GET", "/v1/raporlar/sube/101", null, ("BranchCode", "101"));
        Assert.Equal(DecisionType.Permit, d.Decision);
        Assert.Contains(d.ReportOnlyDenials, x => x.StartsWith("RAPOR_MESAI_DENEME"));
    }

    [Fact]
    public async Task Tenant_izolasyonu_baska_tenant_in_uygulamasi_gorunmez()
    {
        await using var host = await TestHost.CreateAsync();
        var nil = await host.HttpAsync("nil.sezer", "GET", "/v1/portfoy/rapor");
        var ayseHttp = await host.HttpAsync("ayse.yilmaz", "GET", "/v1/portfoy/rapor");
        var ayseKey = await host.EvaluateAsync("ayse.yilmaz", "b_portal.portfoyrapor:view");

        Assert.Equal(DecisionType.Permit, nil.Decision);
        Assert.Equal("URI_NOT_REGISTERED", ayseHttp.ReasonCode);        // ABANK'ta B_PORTAL URI'leri aday bile değil
        Assert.Equal("RESOURCE_NOT_IN_TENANT", ayseKey.ReasonCode);
    }

    [Fact]
    public async Task Resource_ve_scope_ile_istek_ayni_sonucu_verir()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await host.WithAsync(sp => sp.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(new AuthorizationRequest
        {
            Subject = new SubjectInfo { Id = "ali.demir" }, Resource = new ResourceInfo { Type = "anka.vadelihesap", Id = "TR1" }, Scope = "close",
            Context = new() { ["IpAddress"] = TestHost.BankIp }
        }, new EvaluationOptions { WriteAudit = false }));
        Assert.Equal(DecisionType.Permit, d.Decision);
        Assert.Equal("anka.vadelihesap:close", d.Permission);

        var unknownScope = await host.EvaluateAsync("ali.demir", "anka.vadelihesap:sil");
        Assert.Equal("PERMISSION_UNKNOWN", unknownScope.ReasonCode);
    }

    [Fact]
    public async Task Etkin_erisim_kosullu_ve_kosulsuz_ayrilir_advisory_policy_kosul_saymaz()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var ayse = m.GetEffective(m.UserIdByName["ayse.yilmaz"], host.Clock.UtcNow);

        var cekim = ayse.Find("anka.nakitcekim:create")!;
        Assert.True(cekim.Conditional);
        Assert.Contains(cekim.Conditions, c => c.StartsWith("CEKIM_LIMITI"));
        Assert.Contains(cekim.Sources, s => s.Policy == "ROL_GISE");

        var musteri = ayse.Find("anka.musteri:view")!;
        Assert.False(musteri.Conditional);                                  // WEB_MASKE Advisory → karara katılmaz
        Assert.Contains(musteri.Sources, s => s.Path.Contains("TUM_PERSONEL"));  // PERSONEL rolü gruptan

        Assert.Null(ayse.Find("anka.vadelihesap:close"));
        var nil = m.GetEffective(m.UserIdByName["nil.sezer"], host.Clock.UtcNow);
        Assert.NotNull(nil.Find("b_portal.portfoyrapor:view"));
        Assert.NotNull(nil.Find("anka.musteri:view"));                      // üst tenant'ın miras alınabilir rolü + uygulaması
    }

    [Fact]
    public async Task Sahipler_grup_kurali_uzerinden_hesaplanir()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var holders = m.HoldersOf(m.ResourceScopeIdByKey["anka.kredikullandirim:execute"], host.Clock.UtcNow).Select(h => h.User.UserName).ToHashSet();
        Assert.Equal(new HashSet<string> { "ali.demir", "sibel.ates" }, holders);
    }

    [Fact]
    public async Task Login_entitlement_menu_ekran_buton_hiyerarsisi()
    {
        await using var host = await TestHost.CreateAsync();
        var svc = (IServiceProvider sp) => sp.GetRequiredService<EntitlementService>();
        var ayse = await host.WithAsync(sp => svc(sp).GetAsync(new EntitlementRequest { User = "ayse.yilmaz", Application = "NEXTRAL", Client = "nextral-api" }));
        UiEntitlement Ui(EntitlementResult r, string code) => r.UiResources.Single(x => x.Code == code);

        Assert.True(Ui(ayse, "nextral.menu.gise").Enabled);
        Assert.True(Ui(ayse, "nextral.ekran.nakit").Enabled);
        Assert.True(Ui(ayse, "nextral.buton.nakitcekim").Enabled);
        Assert.False(Ui(ayse, "nextral.buton.vadelikapat").Enabled);
        Assert.False(Ui(ayse, "nextral.menu.rapor").Enabled);
        Assert.Equal("Üst menü/ekran kapalı.", Ui(ayse, "nextral.ekran.suberapor").Reason);

        var noClient = await host.WithAsync(sp => svc(sp).GetAsync(new EntitlementRequest { User = "ayse.yilmaz", Application = "NEXTRAL" }));
        Assert.Contains("koşul", Ui(noClient, "nextral.buton.nakitcekim").Scopes.Single().Reason);   // kanal çalışma anında belli olur

        var ali = await host.WithAsync(sp => svc(sp).GetAsync(new EntitlementRequest { User = "ali.demir", Application = "NEXTRAL", Client = "nextral-api" }));
        Assert.False(Ui(ali, "nextral.buton.nakitcekim").Enabled);
        Assert.True(Ui(ali, "nextral.buton.vadelikapat").Enabled);
        Assert.True(Ui(ali, "nextral.menu.rapor").Enabled);
        Assert.True(Ui(ali, "nextral.menu.kredi").Enabled);
    }
}
