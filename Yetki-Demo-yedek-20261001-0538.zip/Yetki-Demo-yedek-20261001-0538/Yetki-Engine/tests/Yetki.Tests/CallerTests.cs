using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Abstractions;
using Yetki.Application.Definitions;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine;

namespace Yetki.Tests;

/// <summary>
/// Soran (caller) güvenliği: client motora kendi secret'ıyla gelir; motor soranı soru kapsamıyla sınırlar.
/// Hatalı / ele geçirilmiş bir client sadece kendi kapsamını etkileyebilir.
/// </summary>
public class CallerTests
{
    private static AuthorizationRequest Http(string user, string method, string path, string? caller, string? client = null, string? app = null) => new()
    {
        Subject = new SubjectInfo { Id = user }, Http = new HttpRequestInfo { Application = app, Method = method, Path = path }, Client = client, Caller = caller
    };

    [Fact]
    public async Task Soran_kendi_kapsaminda_soru_sorabilir_client_soranin_kendisidir()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await host.DecideAsync(Http("ayse.yilmaz", "GET", "/v1/musteriler/C-555", caller: "nextral-api"));
        Assert.Equal(DecisionType.Permit, d.Decision);
        Assert.Equal("nextral-api", d.Client);       // istekte client yok → soranın kendisi
        Assert.Equal("nextral-api", d.Caller);
    }

    [Fact]
    public async Task Kapsam_disindaki_uygulama_ve_kurum_reddedilir()
    {
        await using var host = await TestHost.CreateAsync();
        // nextral-api B_PORTAL hakkında soru soramaz
        var app = await host.DecideAsync(Http("nil.sezer", "GET", "/v1/portfoy/rapor", caller: "nextral-api", app: "B_PORTAL"));
        Assert.Equal("CALLER_APP_SCOPE", app.ReasonCode);
        // b-portal-web sadece BISTIRAK kullanıcıları için sorabilir; ABANK kullanıcısı kapsam dışı
        var tenant = await host.DecideAsync(Http("ayse.yilmaz", "GET", "/v1/portfoy/rapor", caller: "b-portal-web", app: "B_PORTAL"));
        Assert.Equal("CALLER_TENANT_SCOPE", tenant.ReasonCode);
    }

    [Fact]
    public async Task Sadece_yetkili_araci_baska_client_adina_konusabilir()
    {
        await using var host = await TestHost.CreateAsync();
        // nextral-api, anka-web adına konuşamaz
        var spoof = await host.DecideAsync(Http("ayse.yilmaz", "GET", "/v1/musteriler/C-555", caller: "nextral-api", client: "anka-web"));
        Assert.Equal("CLIENT_ASSERTION_NOT_ALLOWED", spoof.ReasonCode);
        // anka-gateway (aracı) nextral-api adına konuşabilir; karar orijinal client'a göre verilir, aracı via'ya eklenir
        var viaGateway = await host.DecideAsync(Http("ayse.yilmaz", "GET", "/v1/musteriler/C-555", caller: "anka-gateway", client: "nextral-api"));
        Assert.Equal(DecisionType.Permit, viaGateway.Decision);
        Assert.Equal("nextral-api", viaGateway.Client);
        Assert.Contains("anka-gateway", viaGateway.Via);
        // aracı kendi adına soru soramaz
        var selfGateway = await host.DecideAsync(Http("ayse.yilmaz", "GET", "/v1/musteriler/C-555", caller: "anka-gateway"));
        Assert.Equal("CLIENT_REQUIRED", selfGateway.ReasonCode);
    }

    [Fact]
    public async Task Soran_yoksa_ic_cagri_kapsam_uygulanmaz_konsol_testi_icin()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await host.DecideAsync(Http("nil.sezer", "GET", "/v1/portfoy/rapor", caller: null, client: "b-portal-web", app: "B_PORTAL"));
        Assert.Equal(DecisionType.Permit, d.Decision);
        Assert.Contains(d.Steps, s => s.Step == "Caller" && s.Outcome == "Info");
    }

    [Fact]
    public async Task Entitlement_listesi_soranin_kapsamiyla_sinirlanir()
    {
        await using var host = await TestHost.CreateAsync();
        var svc = (IServiceProvider sp) => sp.GetRequiredService<EntitlementService>();
        var list = await host.WithAsync(sp => svc(sp).GetAsync(new EntitlementRequest { User = "ayse.yilmaz", Caller = "anka-web" }));
        Assert.All(list.Accesses, a => Assert.Equal("ANKA", a.Application));       // NEXTRAL kapsam dışı → listelenmez
        Assert.Equal("anka-web", list.Client);
        await Assert.ThrowsAsync<ForbiddenException>(() => host.WithAsync(sp => svc(sp).GetAsync(new EntitlementRequest { User = "ayse.yilmaz", Caller = "b-portal-web" })));
    }

    [Fact]
    public async Task Secret_dogrulama_iptal_ve_yanlis_secret()
    {
        await using var host = await TestHost.CreateAsync();
        var svc = (IServiceProvider sp) => sp.GetRequiredService<ClientCredentialService>();
        Assert.Equal("nextral-api", await host.WithAsync(sp => svc(sp).ValidateAsync("nextral-api", "ysk_demo_nextral-api", default)));
        Assert.Null(await host.WithAsync(sp => svc(sp).ValidateAsync("nextral-api", "yanlis", default)));
        Assert.Null(await host.WithAsync(sp => svc(sp).ValidateAsync("anka-web", "ysk_demo_nextral-api", default)));   // başka client'ın secret'ı

        var m = await host.ModelAsync();
        var clientPk = m.ClientsById["nextral-api"].Id;
        var created = await host.WithAsync(sp => svc(sp).CreateAsync(clientPk, new ClientSecretCreate { Description = "test" }, default));
        Assert.StartsWith("ysk_", created.Secret);
        Assert.Equal("nextral-api", await host.WithAsync(sp => svc(sp).ValidateAsync("nextral-api", created.Secret, default)));
        await host.WithAsync(async sp => { await svc(sp).RevokeAsync(clientPk, created.Id, default); return 0; });
        Assert.Null(await host.WithAsync(sp => svc(sp).ValidateAsync("nextral-api", created.Secret, default)));
    }
}
