using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Abstractions;
using Yetki.Application.Changes;
using Yetki.Application.Governance;
using Yetki.Application.Model;
using Yetki.Application.Simulation;
using Yetki.Domain.Common;
using Yetki.Infrastructure.Services;

namespace Yetki.Tests;

/// <summary>Grup kitle kuralları, kurum mirası, SoD, RACF/LDAP provisioning (outbox → mutabakat), What-If.</summary>
public class GovernanceTests
{
    [Fact]
    public async Task Filtreler_arasi_VEYA_filtre_ici_VE_haric_kurali()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var komite = m.GroupMembersOf(await host.GroupIdAsync("KREDI_KOMITESI"), host.Clock.UtcNow).Select(x => x.User.UserName).ToHashSet();
        Assert.Equal(new HashSet<string> { "ali.demir", "sibel.ates" }, komite);   // emre SUBEMDR ama 737; burak'ın SUBEMDR'si gruptan (ROLE sadece doğrudan)

        var gise101 = m.GroupMembersOf(await host.GroupIdAsync("GISE_101_AST"), host.Clock.UtcNow).Select(x => x.User.UserName).ToHashSet();
        Assert.Contains("ayse.yilmaz", gise101);
        Assert.DoesNotContain("mert.kaya", gise101);                                // stajyer: HARİÇ kuralı
    }

    [Fact]
    public async Task Miras_alinabilir_rol_alt_kuruma_gecer_miras_alinamaz_rol_atanamaz()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var nil = m.GetIdentity(m.UserIdByName["nil.sezer"], host.Clock.UtcNow);
        Assert.Contains(nil.Groups, g => g.Code == "TUM_PERSONEL");
        Assert.Contains(nil.Roles, r => r.Code == "PERSONEL" && r.Tenant == "ABANK");
        Assert.DoesNotContain(m.GetIdentity(m.UserIdByName["svc.rapor-batch"], host.Clock.UtcNow).Groups, g => g.Code == "TUM_PERSONEL");

        var ex = await Assert.ThrowsAsync<ValidationException>(() => host.WithAsync(sp =>
            sp.GetRequiredService<AssignmentService>().AssignRoleAsync(m.UserIdByName["nil.sezer"], m.RoleIdByCode["GISEAST"], null, null, default)));
        Assert.Contains("miras alınamaz", ex.Message);
    }

    [Fact]
    public async Task SoD_Block_rol_atamasini_engeller()
    {
        await using var host = await TestHost.CreateAsync();
        var ex = await Assert.ThrowsAsync<ConflictException>(async () => await host.WithAsync(async sp =>
            await sp.GetRequiredService<AssignmentService>().AssignRoleAsync(await host.UserIdAsync("ayse.yilmaz"), await host.RoleIdAsync("SUBEMDR"), null, null, default)));
        Assert.Contains("SoD", ex.Message);
    }

    [Fact]
    public async Task SoD_taramasi_yetki_uyelerini_etkin_erisimden_bulur()
    {
        await using var host = await TestHost.CreateAsync();
        var scan = await host.WithAsync(sp => sp.GetRequiredService<SodService>().ScanAsync(default));
        var users = scan.Details.Where(d => d.Conflicts.Any(c => c.Code == "SOD_KREDI_ONAY_KULLANDIRIM")).Select(d => d.UserName).ToHashSet();
        Assert.Equal(new HashSet<string> { "ali.demir", "sibel.ates" }, users);
    }

    [Fact]
    public async Task Rol_atamasi_RACF_mutabakatini_tetikler_zincirle_birlikte()
    {
        await using var host = await TestHost.CreateAsync();
        var elif = await host.UserIdAsync("elif.sahin");
        var impact = await host.WithAsync(async sp =>
            await sp.GetRequiredService<AssignmentService>().AssignRoleAsync(elif, await host.RoleIdAsync("GISEYTK"), null, "vekalet", default));

        var u = Assert.Single(impact.Users, x => x.UserName == "elif.sahin");
        Assert.Contains(u.AddedAccesses, a => a.Key == "anka.nakitcekim:create");
        Assert.Contains(u.ExternalGrants, g => g.Code == "NKC1" && g.Level == "UPDATE");
        Assert.Contains(u.ExternalGrants, g => g.Code == "BNK.KASA.HAREKET");                 // zincir
        Assert.DoesNotContain(u.ExternalGrants, g => g.Code == "CICSNKT");                    // görüntüleme yetkisinden zaten vardı

        await host.Services.GetRequiredService<OutboxProcessor>().ProcessBatchAsync(default);
        await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<IYetkiDbContext>();
            var actions = await db.ProvisioningActions.Where(a => a.UserId == elif).ToListAsync();
            Assert.Contains(actions, a => a.ExternalPermissionCode == "NKC1" && a.ActionType == ProvisioningActionType.Grant && a.Status == ProvisioningStatus.Completed);
            Assert.True(await db.UserExternalGrants.AnyAsync(g => g.UserId == elif && g.ExternalPermission.Code == "NKC1" && g.AccessLevel == ExternalAccessLevel.Update));
        });
    }

    [Fact]
    public async Task Kosul_What_If_mesai_saati_degisikligi_kimi_etkiler()
    {
        await using var host = await TestHost.CreateAsync();
        int conditionId = await host.WithAsync(async sp => await sp.GetRequiredService<IYetkiDbContext>().RuleConditions
            .Where(c => c.SharedCondition != null && c.SharedCondition.Code == "MESAI_SAATI" && c.Kind == ConditionKind.Predicate).Select(c => c.Id).SingleAsync());
        var changes = new PolicyChangeSet
        {
            ConditionOverrides = [new ConditionParameterOverride(conditionId, new() { ["Start"] = "09:00", ["End"] = "10:00", ["Days"] = "MON,TUE,WED,THU,FRI", ["TimeZone"] = "Europe/Istanbul" })]
        };
        var result = await host.WithAsync(sp => sp.GetRequiredService<PolicyImpactService>().AnalyzeAsync(new PolicyImpactRequest
        {
            Changes = changes,
            Scenarios = [new ImpactScenario { Name = "Şubeden 11:00", Client = "nextral-api", Context = new() { ["IpAddress"] = TestHost.BankIp } }]
        }, default));

        Assert.Contains(result.Accesses, a => a.Key == "anka.vadelihesap:view");
        Assert.True(result.NewlyDenied > 0);
        Assert.Contains(result.Rows, r => r.UserName == "ayse.yilmaz" && r.Permission == "anka.vadelihesap:view" && r.Change == "NEWLY_DENIED");
    }

    [Fact]
    public async Task Kimlik_What_If_rol_kaldirma_kaynagi_baska_yerden_korunan_yetkiyi_ayirir()
    {
        await using var host = await TestHost.CreateAsync();
        var burak = await host.UserIdAsync("burak.arslan");
        var changes = new AuthorizationChangeSet();
        changes.UserRoles.Add(new UserRoleChange(burak, await host.RoleIdAsync("BRYSLYTK"), false));
        var impact = await host.WithAsync(sp => sp.GetRequiredService<AuthorizationChangeService>().AnalyzeAsync(changes, true, default));

        var u = Assert.Single(impact.Users, x => x.UserName == "burak.arslan");
        Assert.Contains(u.RemovedAccesses, a => a.Key == "anka.vadelihesap:create");            // sadece portföy rolünden geliyordu
        Assert.DoesNotContain(u.RemovedAccesses, a => a.Key == "anka.vadelihesap:close");       // vekalet grubundaki SUBEMDR'den korunur
        Assert.Contains(u.RetainedAccesses, a => a.Key == "anka.vadelihesap:close");
    }
}
