using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Abstractions;
using Yetki.Application.Definitions;
using Yetki.Application.Inventory;
using Yetki.Application.Model;
using Yetki.Domain.Catalog;
using Yetki.Application.PolicyEngine;
using Yetki.Domain.Common;

namespace Yetki.Tests;

/// <summary>Tanım yönetimi: permission / policy (etki önizlemesi, SoD, uyarılar), katalog (resource tipi, resource, scope, URI).</summary>
public class DefinitionTests
{
    private static async Task<int> ScopeIdAsync(TestHost host, string app, string code)
    {
        var m = await host.ModelAsync();
        return m.Scopes.Values.Single(s => s.Code == code && m.Apps[s.ApplicationId].Code == app).Id;
    }

    [Fact]
    public async Task Policy_uyesi_degisince_etki_once_gorulur_dryRun_kaydetmez()
    {
        await using var host = await TestHost.CreateAsync();
        var id = await host.PolicyIdAsync("ROL_GISE");
        var m = await host.ModelAsync();
        var dto = new PolicyUpsert
        {
            TenantId = m.Policies[id].Row.TenantId, Code = "ROL_GISE", Name = "Gişe personeli", Type = PolicyType.Role,
            MemberIds = [.. m.Policies[id].OrderedMembers, m.RoleIdByCode["BRYSLAST"]]
        };

        var preview = await host.WithAsync(sp => sp.GetRequiredService<PolicyManagementService>().UpdatePolicyAsync(id, dto, dryRun: true, default));
        var elif = Assert.Single(preview.Impact.Users, u => u.UserName == "elif.sahin");
        Assert.Contains(elif.AddedAccesses, a => a.Key == "anka.nakitcekim:create" && a.Conditional);
        Assert.Contains(elif.ExternalGrants, g => g.Code == "NKC1");
        Assert.Null((await host.ModelAsync()).GetEffective(m.UserIdByName["elif.sahin"], host.Clock.UtcNow).Find("anka.nakitcekim:create"));

        await host.WithAsync(sp => sp.GetRequiredService<PolicyManagementService>().UpdatePolicyAsync(id, dto, dryRun: false, default));
        var after = await host.ModelAsync();
        Assert.NotNull(after.GetEffective(after.UserIdByName["elif.sahin"], host.Clock.UtcNow).Find("anka.nakitcekim:create"));
    }

    [Fact]
    public async Task Yeni_permission_SoD_uyarisi_ve_kimliksiz_permission_uyarisi_uretir()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var svc = (IServiceProvider sp) => sp.GetRequiredService<PermissionService>();
        var dto = new PermissionUpsert
        {
            ApplicationId = m.AppByCode["ANKA"].Id, Code = "KULLANDIRIM_ONAYCI", Name = "Onaycılar da kullandırsın",
            ResourceIds = [m.ResourceByCode["anka.kredikullandirim"].Id], AllScopes = true, PolicyIds = [await host.PolicyIdAsync("ROL_KREDI_ONAY")]
        };
        var preview = await host.WithAsync(sp => svc(sp).CreateAsync(dto, dryRun: true, default));

        Assert.Empty(preview.Warnings);
        // Unanimous: mevcut KREDI_KULLANDIRIM (komite) izni de sağlanmalı → onaycılar kazanmaz, komite dışı onaycı değişmez
        Assert.DoesNotContain(preview.Impact.Users, u => u.UserName == "hakan.tekin" && u.AddedAccesses.Count > 0);

        var view = await ScopeIdAsync(host, "ANKA", "view");
        var mesai = await host.PolicyIdAsync("MESAI");
        var conditionOnly = await host.WithAsync(sp => svc(sp).CreateAsync(new PermissionUpsert
        {
            ApplicationId = m.AppByCode["ANKA"].Id, Code = "EFT_MESAI", Name = "EFT sorgu mesai",
            ResourceIds = [m.ResourceByCode["anka.eft"].Id], ScopeIds = [view], PolicyIds = [mesai]
        }, dryRun: true, default));
        Assert.Contains(conditionOnly.Warnings, w => w.Contains("kimlik") || w.Contains("rol / grup"));
        Assert.Equal(0, conditionOnly.Impact.AffectedUserCount);                     // ek kısıt: kimse kazanmaz / kaybetmez
        Assert.Contains(conditionOnly.Impact.Users, u => u.RetainedAccesses.Any(r => r.Key == "anka.eft:view"));
    }

    [Fact]
    public async Task Permission_silme_etkisi_RACF_revoke_gosterir()
    {
        await using var host = await TestHost.CreateAsync();
        var id = await host.PermissionIdAsync("VADELI_KAPAT");
        var preview = await host.WithAsync(sp => sp.GetRequiredService<PermissionService>().DeleteAsync(id, dryRun: true, default));
        var ali = Assert.Single(preview.Impact.Users, u => u.UserName == "ali.demir");
        Assert.Contains(ali.RemovedAccesses, a => a.Key == "anka.vadelihesap:close");
        Assert.Contains(ali.ExternalRevokes, r => r.Code == "VDKP");
    }

    [Fact]
    public async Task Resource_listesi_bosalan_permission_atil_kalir_yetki_genislemez()
    {
        await using var host = await TestHost.CreateAsync();
        var id = await host.PermissionIdAsync("VADELI_KAPAT");
        var close = await ScopeIdAsync(host, "ANKA", "close");
        // Endpoint kalktı: resource listeden çıkarıldı, permission unutuldu (scope close, policy aynı)
        var dto = new PermissionUpsert
        {
            Code = "VADELI_KAPAT", Name = "Vadeli hesap kapatma", ResourceIds = [], ScopeIds = [close],
            PolicyIds = [await host.PolicyIdAsync("ROL_VADELI_KAPATAN"), await host.PolicyIdAsync("GISE_GUVENLI_ISLEM")]
        };
        var preview = await host.WithAsync(sp => sp.GetRequiredService<PermissionService>().UpdateAsync(id, dto, dryRun: true, default));

        Assert.Contains(preview.Warnings, w => w.Contains("atıl"));
        Assert.All(preview.Impact.Users, u => Assert.Empty(u.AddedAccesses));          // hiçbir yetki genişlemez
        Assert.Contains(preview.Impact.Users, u => u.UserName == "ali.demir" && u.RemovedAccesses.Any(a => a.Key == "anka.vadelihesap:close"));

        // Tüm uygulama ancak açık seçimle; tip hedefi tip olmadan kabul edilmez
        dto.Target = PermissionTarget.ResourceType;
        await Assert.ThrowsAsync<ValidationException>(() => host.WithAsync(sp => sp.GetRequiredService<PermissionService>().UpdateAsync(id, dto, dryRun: true, default)));
        dto.Target = PermissionTarget.Application;
        var wide = await host.WithAsync(sp => sp.GetRequiredService<PermissionService>().UpdateAsync(id, dto, dryRun: true, default));
        Assert.Contains(wide.Warnings, w => w.Contains("TÜM"));
    }

    [Fact]
    public async Task Kapsama_raporu_envanteri_yetki_tanimlariyla_carpistirir_ve_modeli_degistirmez()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var anka = m.AppByCode["ANKA"].Id;
        var svc = (IServiceProvider sp) => sp.GetRequiredService<InventoryService>();

        var report = await host.WithAsync(sp => svc(sp).CoverageAsync(anka, default));
        EndpointCoverage E(string method, string path) => report.EndpointItems.Single(x => x.Method == method && x.Path == path);
        Assert.Equal(CoverageStatus.Protected, E("POST", "/v1/vadeli-hesap/{hesapNo}/kapat").Status);
        Assert.Equal("anka.vadelihesap:close", E("POST", "/v1/vadeli-hesap/{hesapNo}/kapat").Key);
        var dekont = E("GET", "/v1/vadeli-hesap/{hesapNo}/dekont");
        Assert.Equal(CoverageStatus.Undefined, dekont.Status);                       // tanımsız → kapalı
        Assert.Equal("anka.vadelihesap", dekont.SuggestedResourceCode);               // aynı URL grubundaki resource önerilir
        Assert.Equal("view", dekont.SuggestedScope);
        Assert.Contains(report.StaleUris, u => u.Pattern == "/v1/kredi/basvuru/{id}"); // tanımlı ama Swagger'da yok → atıl olabilir

        var nextral = await host.WithAsync(sp => svc(sp).CoverageAsync(m.AppByCode["NEXTRAL"].Id, default));
        Assert.Equal(CoverageStatus.Protected, nextral.UiItems.Single(x => x.Code == "GVADAG00").Status);
        Assert.Equal(CoverageStatus.Undefined, nextral.UiItems.Single(x => x.Code == "GKRLMT00").Status);
        Assert.Contains(nextral.StaleUiResources, r => r.Code == "nextral.ekran.suberapor");

        // Yeniden içe aktarım öncekinin yerini alır; envanter yetki modelinin sürümünü değiştirmez
        var before = (await host.ModelAsync()).Version;
        await host.WithAsync(sp => svc(sp).ImportAsync(anka, InventoryKind.Endpoint,
            new InventoryImport { Source = "test", Content = "GET /v1/yeni-servis/{id} Yeni\n# yorum\nPOST /v1/vadeli-hesap" }, default));
        var after = await host.WithAsync(sp => svc(sp).CoverageAsync(anka, default));
        Assert.Equal(2, after.EndpointItems.Count);
        Assert.Equal(before, (await host.ModelAsync()).Version);
        Assert.Equal("anka.yeniservis", after.EndpointItems.Single(x => x.Status == CoverageStatus.Undefined).SuggestedCode);
    }

    [Fact]
    public async Task Kullanimdaki_policy_silinemez_aggregate_dongusu_reddedilir()
    {
        await using var host = await TestHost.CreateAsync();
        var svc = (IServiceProvider sp) => sp.GetRequiredService<PolicyManagementService>();
        await Assert.ThrowsAsync<ConflictException>(async () => await host.WithAsync(async sp => { await svc(sp).DeletePolicyAsync(await host.PolicyIdAsync("MESAI"), default); return 0; }));

        var agg = await host.PolicyIdAsync("GISE_GUVENLI_ISLEM");
        var m = await host.ModelAsync();
        var dto = new PolicyUpsert { Code = "GISE_GUVENLI_ISLEM", Name = "x", Type = PolicyType.Aggregate, MemberIds = [.. m.Policies[agg].OrderedMembers, agg] };
        var ex = await Assert.ThrowsAsync<ValidationException>(() => host.WithAsync(sp => svc(sp).UpdatePolicyAsync(agg, dto, dryRun: true, default)));
        Assert.Contains("Döngüsel", ex.Message);
    }

    [Fact]
    public async Task Yeni_resource_permission_baglanana_kadar_varsayilan_olarak_kapalidir()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var view = await ScopeIdAsync(host, "ANKA", "view");
        await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().CreateResourceAsync(new ResourceUpsert
        {
            ApplicationId = m.AppByCode["ANKA"].Id, ResourceTypeId = m.ResourceTypes.Values.Single(t => t.Code == "ENDPOINT").Id,
            Code = "anka.faiz", Name = "Faiz oranları", Scopes = [new ResourceScopeDraft { ScopeId = view }],
            Uris = [new UriUpsert { Method = "get", Pattern = "/v1/faiz/{urun}/" , ScopeId = view }]
        }, default));

        var noPermission = await host.HttpAsync("ali.demir", "GET", "/v1/faiz/vadeli");
        Assert.Equal("NO_PERMISSION", noPermission.ReasonCode);
        Assert.Equal("GET /v1/faiz/{urun}", noPermission.MatchedUri);                  // normalize edildi

        await host.WithAsync(async sp => (await sp.GetRequiredService<PermissionService>().CreateAsync(new PermissionUpsert
        {
            ApplicationId = m.AppByCode["ANKA"].Id, Code = "FAIZ_GORUNTULE", Name = "Faiz", ResourceIds = [(await host.ModelAsync()).ResourceByCode["anka.faiz"].Id],
            AllScopes = true, PolicyIds = [await host.PolicyIdAsync("ROL_PERSONEL")]
        }, false, default)).Id);
        Assert.Equal(DecisionType.Permit, (await host.HttpAsync("ali.demir", "GET", "/v1/faiz/vadeli")).Decision);
    }

    [Fact]
    public async Task URI_degisse_de_yetki_kimligi_ve_baglar_korunur()
    {
        await using var host = await TestHost.CreateAsync();
        await using (var scope = host.Scope())
        {
            var db = scope.ServiceProvider.GetRequiredService<IYetkiDbContext>();
            var uri = await db.ResourceUris.SingleAsync(u => u.Pattern == "/v1/vadeli-hesap/{hesapNo}/kapat");
            await scope.ServiceProvider.GetRequiredService<CatalogService>().UpdateUriAsync(uri.Id,
                new UriUpsert { Method = "POST", Pattern = "/v2/vadeli-hesaplar/{hesapNo}/kapanis", ScopeId = uri.ScopeId }, default);
        }
        Assert.Equal("URI_NOT_REGISTERED", (await host.HttpAsync("ali.demir", "POST", "/v1/vadeli-hesap/TR1/kapat")).ReasonCode);
        var d = await host.HttpAsync("ali.demir", "POST", "/v2/vadeli-hesaplar/TR1/kapanis");
        Assert.Equal(DecisionType.Permit, d.Decision);
        Assert.Equal("anka.vadelihesap:close", d.Permission);
    }

    [Fact]
    public async Task Katalog_kurallari_cakisan_URI_HTTP_disi_tip_ve_kullanimdaki_kayitlar()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var catalog = (IServiceProvider sp) => sp.GetRequiredService<CatalogService>();
        var eft = m.ResourceByCode["anka.eft"].Id;
        var create = await ScopeIdAsync(host, "ANKA", "create");

        await Assert.ThrowsAsync<ConflictException>(() => host.WithAsync(sp => catalog(sp).AddUriAsync(eft, new UriUpsert { Method = "POST", Pattern = "/v1/eft", ScopeId = create }, default)));
        var menu = m.ResourceByCode["nextral.menu.gise"].Id;
        var nxView = await ScopeIdAsync(host, "NEXTRAL", "view");
        await Assert.ThrowsAsync<ValidationException>(() => host.WithAsync(sp => catalog(sp).AddUriAsync(menu, new UriUpsert { Method = "GET", Pattern = "/x", ScopeId = nxView }, default)));

        async Task Conflict(Func<CatalogService, Task> action) =>
            await Assert.ThrowsAsync<ConflictException>(() => host.WithAsync(sp => action(catalog(sp))));
        await Conflict(c => c.DeleteResourceAsync(m.ResourceByCode["anka.vadelihesap"].Id, default));                 // permission + RACF bağımlılığı
        await Conflict(c => c.DeleteScopeAsync(create, default));
        await Conflict(c => c.DeleteResourceTypeAsync(m.ResourceTypes.Values.Single(t => t.Code == "ENDPOINT").Id, default));
        var view = await ScopeIdAsync(host, "ANKA", "view");
        await Conflict(c => c.UpdateResourceAsync(eft, new ResourceUpsert
        {
            ResourceTypeId = m.ResourceByCode["anka.eft"].ResourceTypeId, Code = "anka.eft", Name = "EFT",
            Scopes = [new ResourceScopeDraft { ScopeId = view }]              // create/cancel scope'larının URI'leri var
        }, default));
    }

    [Fact]
    public async Task Resource_tipi_CRUD()
    {
        await using var host = await TestHost.CreateAsync();
        var catalog = (IServiceProvider sp) => sp.GetRequiredService<CatalogService>();
        var t = await host.WithAsync(sp => catalog(sp).CreateResourceTypeAsync(new ResourceTypeUpsert { Code = "report", Name = "Rapor", SupportsHierarchy = false, Color = "cyan" }, default));
        Assert.Equal("REPORT", t.Code);
        await Assert.ThrowsAsync<ConflictException>(() => host.WithAsync(sp => catalog(sp).CreateResourceTypeAsync(new ResourceTypeUpsert { Code = "REPORT", Name = "x" }, default)));
        await host.WithAsync(sp => catalog(sp).UpdateResourceTypeAsync(t.Id, new ResourceTypeUpsert { Code = "REPORT", Name = "Rapor dosyası", MatchesHttp = true }, default));
        Assert.True((await host.ModelAsync()).ResourceTypes[t.Id].MatchesHttp);
        await host.WithAsync(async sp => { await catalog(sp).DeleteResourceTypeAsync(t.Id, default); return 0; });
        Assert.False((await host.ModelAsync()).ResourceTypes.ContainsKey(t.Id));
    }
}
