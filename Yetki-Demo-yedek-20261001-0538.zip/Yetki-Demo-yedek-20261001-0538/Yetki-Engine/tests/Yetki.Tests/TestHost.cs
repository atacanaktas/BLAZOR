using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Yetki.Application.Abstractions;
using Yetki.Application.Evaluation;
using Yetki.Application.Model;
using Yetki.Infrastructure;
using Yetki.Infrastructure.Persistence;
using Yetki.Infrastructure.Services;
using Yetki.SampleData;

namespace Yetki.Tests;

public sealed class FakeClock : IClock
{
    /// <summary>Varsayılan: Salı 2026-09-22 11:00 İstanbul (08:00 UTC) — mesai içi.</summary>
    public DateTime UtcNow { get; set; } = new(2026, 9, 22, 8, 0, 0, DateTimeKind.Utc);
}

/// <summary>Her test için izole InMemory veritabanı + örnek veri ile gerçek DI grafiği.</summary>
public sealed class TestHost : IAsyncDisposable
{
    public ServiceProvider Services { get; }
    public FakeClock Clock { get; } = new();
    private readonly IConfiguration _config;

    /// <summary>Banka ağı içi IP (KURUMSAL_AG policy'si).</summary>
    public const string BankIp = "10.20.30.40";

    private TestHost(Action<IServiceCollection>? configure)
    {
        _config = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["Persistence:Provider"] = "InMemory",
            ["Persistence:InMemoryDatabaseName"] = "test-" + Guid.NewGuid()
        }).Build();

        var services = new ServiceCollection();
        services.AddLogging();
        services.AddYetkiInfrastructure(_config);
        services.Replace(ServiceDescriptor.Singleton<IClock>(Clock));
        services.AddScoped<ICurrentActor>(_ => new SystemActor("test"));
        configure?.Invoke(services);
        Services = services.BuildServiceProvider();
    }

    /// <summary>Boş şema + condition tipleri + örnek veri (yedek.db ile aynı SampleDataBuilder) + RACF baseline.</summary>
    public static async Task<TestHost> CreateAsync(Action<IServiceCollection>? configure = null)
    {
        var host = new TestHost(configure);
        await host.Services.InitializeYetkiDatabaseAsync();
        await using var scope = host.Scope();
        await new SampleDataBuilder(scope.ServiceProvider.GetRequiredService<YetkiDbContext>(), host.Clock).BuildAsync();
        await scope.ServiceProvider.GetRequiredService<Yetki.Application.External.ExternalProvisioningService>().BaselineAsync(default);
        return host;
    }

    public AsyncServiceScope Scope() => Services.CreateAsyncScope();

    public async Task<T> WithAsync<T>(Func<IServiceProvider, Task<T>> action)
    {
        await using var scope = Scope();
        return await action(scope.ServiceProvider);
    }

    public async Task WithAsync(Func<IServiceProvider, Task> action)
    {
        await using var scope = Scope();
        await action(scope.ServiceProvider);
    }

    public Task<AuthorizationModel> ModelAsync() => WithAsync(sp => sp.GetRequiredService<AuthorizationModelProvider>().GetCurrentAsync());

    public async Task<int> UserIdAsync(string userName) => (await ModelAsync()).UserIdByName[userName];
    public async Task<int> RoleIdAsync(string code) => (await ModelAsync()).RoleIdByCode[code];
    public async Task<int> AccessIdAsync(string key) => (await ModelAsync()).ResourceScopeIdByKey[key];
    public async Task<int> GroupIdAsync(string code) => (await ModelAsync()).Groups.Values.Single(g => g.Code == code).Id;
    public async Task<int> PolicyIdAsync(string code) => (await ModelAsync()).Policies.Values.Single(p => p.Row.Code == code).Row.Id;
    public async Task<int> PermissionIdAsync(string code) => (await ModelAsync()).Permissions.Values.Single(p => p.Row.Code == code).Row.Id;
    public async Task<int> ResourceIdAsync(string code) => (await ModelAsync()).ResourceByCode[code].Id;

    /// <summary>Gerçek karar: yetki anahtarı (resource:scope) ile. Banka ağı IP'si varsayılan; context'e ek değerler verilebilir.</summary>
    public Task<AuthorizationDecision> EvaluateAsync(string user, string permission, string? client = null, params (string Key, string? Value)[] context) =>
        RunAsync(new AuthorizationRequest { Subject = new SubjectInfo { Id = user }, Permission = permission, Client = client }, context);

    /// <summary>Gateway kararı: METHOD + path ile.</summary>
    public Task<AuthorizationDecision> HttpAsync(string user, string method, string path, string? client = null, params (string Key, string? Value)[] context) =>
        RunAsync(new AuthorizationRequest { Subject = new SubjectInfo { Id = user }, Http = new HttpRequestInfo { Method = method, Path = path }, Client = client }, context);

    /// <summary>Tam istekle karar (ör. soran client'lı). Banka IP'si varsayılan bağlamdır.</summary>
    public Task<AuthorizationDecision> DecideAsync(AuthorizationRequest request, params (string Key, string? Value)[] context) => RunAsync(request, context);

    private Task<AuthorizationDecision> RunAsync(AuthorizationRequest request, (string Key, string? Value)[] context) =>
        WithAsync(sp =>
        {
            request.Context["IpAddress"] = BankIp;
            foreach (var (k, v) in context) request.Context[k] = v;
            return sp.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(request, new EvaluationOptions { WriteAudit = false });
        });

    public ValueTask DisposeAsync() => Services.DisposeAsync();
}
