using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Yetki.Application.Abstractions;
using Yetki.Application.Changes;
using Yetki.Application.Definitions;
using Yetki.Application.Identity;
using Yetki.Application.Model;
using Yetki.Infrastructure.Identity;

namespace Yetki.Tests;

public sealed class IdentityProviderTests
{
    [Fact]
    public async Task Local_search_scopes_tenant_and_preserves_assignment_metadata()
    {
        await using var host = await TestHost.CreateAsync();
        await host.WithAsync(async sp =>
        {
            var provider = sp.GetRequiredService<IIdentityProvider>();
            var snapshot = await provider.ReadSnapshotAsync(default);
            var user = snapshot.Users.First();
            var page = await provider.SearchUsersAsync(new(user.TenantId, PageSize: 1), default);
            Assert.Single(page.Items);
            Assert.Equal(snapshot.Users.Count(x => x.TenantId == user.TenantId), page.Total);
            Assert.All(page.Items, x => Assert.Equal(user.TenantId, x.TenantId));
            var assignment = snapshot.UserRoles.First();
            Assert.Equal(assignment, await provider.GetUserRoleAsync(assignment.UserId, assignment.RoleId, default));
            Assert.Equal("LocalDb", provider.Name);
        });
    }

    [Fact]
    public async Task Changed_source_updates_users_roles_links_and_model_version_without_local_writes()
    {
        var state = new SourceState();
        await using var host = await ExternalHost(state);
        var before = await host.ModelAsync();
        await host.WithAsync(async sp =>
        {
            var original = await sp.GetRequiredService<LocalIdentityProvider>().ReadSnapshotAsync(default);
            var user = original.Users.First();
            var role = original.Roles.First();
            state.Data = original with
            {
                Users = original.Users.Select(x => x.Id == user.Id ? x with { FullName = "HR name" } : x).ToArray(),
                Roles = original.Roles.Select(x => x.Id == role.Id ? x with { Name = "HR role" } : x).ToArray(),
                UserRoles = original.UserRoles.Where(x => x.UserId != user.Id).ToArray()
            };
            state.Revision++;
            var model = await sp.GetRequiredService<AuthorizationModelProvider>().GetCurrentAsync();
            Assert.True(model.Version > before.Version);
            Assert.Equal("HR name", model.Users[user.Id].FullName);
            Assert.Equal("HR role", model.Roles[role.Id].Name);
            Assert.DoesNotContain(model.Data.UserRoles, x => x.UserId == user.Id);
            Assert.Equal(original, await sp.GetRequiredService<LocalIdentityProvider>().ReadSnapshotAsync(default),
                new SnapshotComparer());
            var again = await sp.GetRequiredService<AuthorizationModelProvider>().GetCurrentAsync();
            Assert.Same(model, again);
        });
    }

    [Fact]
    public async Task Read_only_source_rejects_mutations_before_changing_local_data()
    {
        var state = new SourceState();
        await using var host = await ExternalHost(state);
        await host.WithAsync(async sp =>
        {
            var local = sp.GetRequiredService<LocalIdentityProvider>();
            var before = await local.ReadSnapshotAsync(default);
            var service = sp.GetRequiredService<AssignmentService>();
            var user = before.Users.First();
            await Assert.ThrowsAsync<ValidationException>(() => service.UpdateUserAsync(user.Id, new() { FullName = "Changed" }, default));
            await Assert.ThrowsAsync<ValidationException>(() => service.CreateRoleAsync(new() { Code = "HR" }, default));
            await Assert.ThrowsAsync<ValidationException>(() => service.AssignRoleAsync(user.Id, before.Roles.First().Id, null, null, default));
            Assert.Equal(before, await local.ReadSnapshotAsync(default), new SnapshotComparer());
        });
    }

    [Fact]
    public async Task Source_failure_does_not_return_cached_authorization_model()
    {
        var state = new SourceState();
        await using var host = await ExternalHost(state);
        await host.ModelAsync();
        state.Unavailable = true;
        await Assert.ThrowsAsync<InvalidOperationException>(() => host.ModelAsync());
    }

    private static Task<TestHost> ExternalHost(SourceState state) => TestHost.CreateAsync(services =>
    {
        services.AddScoped<LocalIdentityProvider>();
        services.Replace(ServiceDescriptor.Scoped<IIdentityProvider>(sp => new ExternalProvider(sp.GetRequiredService<LocalIdentityProvider>(), state)));
    });

    private sealed class SnapshotComparer : IEqualityComparer<IdentitySnapshot>
    {
        public bool Equals(IdentitySnapshot? a, IdentitySnapshot? b) => a is not null && b is not null
            && a.Users.SequenceEqual(b.Users) && a.Roles.SequenceEqual(b.Roles) && a.UserRoles.SequenceEqual(b.UserRoles);
        public int GetHashCode(IdentitySnapshot value) => 0;
    }
    private sealed class SourceState
    {
        public IdentitySnapshot? Data;
        public int Revision;
        public bool Unavailable;
    }
    private sealed class ExternalProvider(LocalIdentityProvider local, SourceState state) : IIdentityProvider
    {
        public string Name => "TestHR";
        public IdentityCapabilities Capabilities => new(false, false, false);
        public Task<string> GetRevisionAsync(CancellationToken ct) => state.Unavailable
            ? throw new InvalidOperationException("HR unavailable") : Task.FromResult(state.Revision.ToString());
        public async Task<IdentitySnapshot> ReadSnapshotAsync(CancellationToken ct) => state.Data ?? await local.ReadSnapshotAsync(ct);
        public async Task<IdentityUser?> GetUserAsync(int id, CancellationToken ct) => (await ReadSnapshotAsync(ct)).Users.FirstOrDefault(x => x.Id == id);
        public async Task<IdentityRole?> GetRoleAsync(int id, CancellationToken ct) => (await ReadSnapshotAsync(ct)).Roles.FirstOrDefault(x => x.Id == id);
        public async Task<IdentityUserRole?> GetUserRoleAsync(int userId, int roleId, CancellationToken ct) => (await ReadSnapshotAsync(ct)).UserRoles.FirstOrDefault(x => x.UserId == userId && x.RoleId == roleId);
        public async Task<IReadOnlyList<IdentityUserRole>> GetUserRolesAsync(int userId, CancellationToken ct) => (await ReadSnapshotAsync(ct)).UserRoles.Where(x => x.UserId == userId).ToArray();
        public async Task<bool> UserNameExistsAsync(string name, CancellationToken ct) => (await ReadSnapshotAsync(ct)).Users.Any(x => x.UserName == name);
        public async Task<bool> RoleCodeExistsAsync(string code, CancellationToken ct) => (await ReadSnapshotAsync(ct)).Roles.Any(x => x.Code == code);
        public async Task<IdentityPage<IdentityUser>> SearchUsersAsync(IdentityUserQuery query, CancellationToken ct)
        {
            var users = (await ReadSnapshotAsync(ct)).Users.Where(x => (query.TenantId is null || x.TenantId == query.TenantId)
                && (query.Search is null || x.FullName.Contains(query.Search) || x.UserName.Contains(query.Search))).OrderBy(x => x.UserName).ToArray();
            return new(users.Skip((query.Page - 1) * query.PageSize).Take(query.PageSize).ToArray(), users.Length, query.Page, query.PageSize);
        }
        public Task<IdentityUser> CreateUserAsync(IdentityUser user, int? primaryOrgUnitId, CancellationToken ct) => throw new NotSupportedException();
        public Task<IdentityRole> CreateRoleAsync(IdentityRole role, CancellationToken ct) => throw new NotSupportedException();
        public Task StageUserUpdateAsync(IdentityUser user, CancellationToken ct) => throw new NotSupportedException();
        public Task StageRoleUpdateAsync(IdentityRole role, CancellationToken ct) => throw new NotSupportedException();
        public Task StageAssignRoleAsync(IdentityUserRole assignment, CancellationToken ct) => throw new NotSupportedException();
        public Task StageRevokeRoleAsync(int userId, int roleId, CancellationToken ct) => throw new NotSupportedException();
    }
}
