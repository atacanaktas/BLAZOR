using Microsoft.Extensions.Logging.Abstractions;
using Yetki.Application.Context;
using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Domain.Common;

namespace Yetki.Tests;

/// <summary>Saf birim testleri: Keycloak karar stratejileri, negatif logic, üç değerli mantık, fail-closed, URI desen eşleştirme.</summary>
public class PolicyEngineTests
{
    private static PolicyEvaluator Evaluator() =>
        new(new ConditionHandlerRegistry([new AlwaysConditionHandler(), new AmountGreaterThanConditionHandler(), new IpInRangeConditionHandler()]), NullLogger<PolicyEvaluator>.Instance);

    private static AttributeResolver Resolver(Dictionary<string, string?> ctx)
    {
        var model = AuthorizationModel.Build(new ModelData(), null, new GroupCriterionRegistry([]), 1, false, DateTime.UtcNow);
        return new AttributeResolver([new RequestContextAttributeProvider()], new AttributeResolutionScope
        {
            Subject = new SubjectRef(1, "x"), Context = new AuthorizationContext(ctx), Action = "a", Model = model, Now = DateTime.UtcNow
        });
    }

    private static ConditionNode Pred(string type, params (string, string)[] ps) =>
        new(1, ConditionKind.Predicate, type, true, ps.ToDictionary(p => p.Item1, p => p.Item2), []);

    private const DecisionType P = DecisionType.Permit, D = DecisionType.Deny, I = DecisionType.Indeterminate, N = DecisionType.NotApplicable;

    [Theory]
    [InlineData(DecisionStrategy.Unanimous, new[] { P, P }, P)]
    [InlineData(DecisionStrategy.Unanimous, new[] { P, D }, D)]
    [InlineData(DecisionStrategy.Unanimous, new[] { P, I }, I)]
    [InlineData(DecisionStrategy.Unanimous, new[] { I, D }, D)]
    [InlineData(DecisionStrategy.Unanimous, new[] { P, N }, P)]          // etkisiz (ReportOnly/Advisory) yok sayılır
    [InlineData(DecisionStrategy.Affirmative, new[] { D, P }, P)]
    [InlineData(DecisionStrategy.Affirmative, new[] { D, I }, I)]
    [InlineData(DecisionStrategy.Affirmative, new[] { D, D }, D)]
    [InlineData(DecisionStrategy.Consensus, new[] { P, P, D }, P)]
    [InlineData(DecisionStrategy.Consensus, new[] { P, D }, D)]          // eşitlik → red
    [InlineData(DecisionStrategy.Consensus, new[] { P, P, I, D }, I)]    // belirsizlik sonucu değiştirebilir → izin yok
    [InlineData(DecisionStrategy.Unanimous, new[] { N }, N)]
    public void Karar_stratejileri(DecisionStrategy strategy, DecisionType[] inputs, DecisionType expected) =>
        Assert.Equal(expected, DecisionStrategies.Combine(strategy, inputs).Decision);

    [Theory]
    [InlineData(P, D)]
    [InlineData(D, P)]
    [InlineData(I, I)]
    [InlineData(N, N)]
    public void Negatif_logic_izni_ve_reddi_cevirir_belirsizligi_korur(DecisionType input, DecisionType expected) =>
        Assert.Equal(expected, DecisionStrategies.ApplyLogic(PolicyLogic.Negative, input));

    [Fact]
    public async Task Eksik_deger_NOT_altinda_da_belirsiz_kalir_ve_rule_Indeterminate_uretir()
    {
        var policy = new PolicyDefinition(1, "P", "P", 1, DecisionStrategy.Unanimous,
            [new RuleDefinition(1, "R", "R", null, 1, "X", true, new ConditionNode(2, ConditionKind.Not, null, true, new Dictionary<string, string>(), [Pred("IP_IN_RANGE", ("Cidrs", "10.0.0.0/8"))]))]);
        var result = await Evaluator().EvaluateAsync(policy, Resolver(new()), "p", default);
        Assert.Equal(DecisionType.Indeterminate, result.Result);
        Assert.Contains("Environment.IpAddress", result.Rules[0].MissingAttributes);
    }

    [Fact]
    public async Task VE_icinde_bir_FALSE_belirsizligi_bastirir()
    {
        var and = new ConditionNode(3, ConditionKind.AllOf, null, true, new Dictionary<string, string>(),
            [Pred("IP_IN_RANGE", ("Cidrs", "10.0.0.0/8")), Pred("AMOUNT_GREATER_THAN", ("Threshold", "1000"))]);
        var policy = new PolicyDefinition(1, "P", "P", 1, DecisionStrategy.Unanimous, [new RuleDefinition(1, "R", "R", null, 1, "LIMIT", true, and)]);
        var result = await Evaluator().EvaluateAsync(policy, Resolver(new() { ["TransactionAmount"] = "10" }), "p", default);
        Assert.Equal(DecisionType.Deny, result.Result);
        Assert.Equal("R", result.DecidingRule);
    }

    [Fact]
    public async Task Handleri_olmayan_kosul_cocuksuz_referans_ve_kuralsiz_policy_fail_closed()
    {
        var unknown = new PolicyDefinition(1, "P", "P", 1, DecisionStrategy.Unanimous, [new RuleDefinition(1, "R", "R", null, 1, null, true, Pred("YOK_BOYLE"))]);
        Assert.Equal(DecisionType.Indeterminate, (await Evaluator().EvaluateAsync(unknown, Resolver(new()), "p", default)).Result);

        var dangling = new PolicyDefinition(1, "P", "P", 1, DecisionStrategy.Unanimous,
            [new RuleDefinition(1, "R", "R", null, 1, null, true, new ConditionNode(5, ConditionKind.Reference, null, true, new Dictionary<string, string>(), [], "X"))]);
        Assert.Equal(DecisionType.Indeterminate, (await Evaluator().EvaluateAsync(dangling, Resolver(new()), "p", default)).Result);

        var empty = new PolicyDefinition(1, "P", "P", 1, DecisionStrategy.Unanimous, []);
        Assert.Equal(DecisionType.Indeterminate, (await Evaluator().EvaluateAsync(empty, Resolver(new()), "p", default)).Result);
    }

    [Theory]
    [InlineData("/v1/vadeli-hesap/{hesapNo}", "/v1/vadeli-hesap/TR12", true)]
    [InlineData("/v1/vadeli-hesap/{hesapNo}", "/v1/vadeli-hesap/TR12/kapat", false)]
    [InlineData("/v1/vadeli-hesap/*/kapat", "/v1/vadeli-hesap/TR12/kapat", true)]
    [InlineData("/v1/dosya/**", "/v1/dosya/a/b/c", true)]
    [InlineData("/v1/dosya/**", "/v1/dosya", true)]
    [InlineData("/V1/Vadeli-Hesap", "/v1/vadeli-hesap?x=1", true)]
    public void Uri_deseni_eslestirme(string pattern, string path, bool expected)
    {
        static string[] Split(string p) => p.Split('?')[0].Split('/', StringSplitOptions.RemoveEmptyEntries);
        Assert.Equal(expected, AuthorizationModel.TryMatch(Split(pattern), Split(path), out _));
    }

    [Fact]
    public void En_ozel_desen_kazanir_ayni_ozgullukte_farkli_yetki_belirsizdir()
    {
        var data = new ModelData
        {
            Tenants = [new TenantRow(1, "T", "T", TenantType.Bank, null, true)],
            Applications = [new AppRow(1, 1, "APP", "App", ApplicationType.ApiPlatform, DecisionStrategy.Unanimous, true)],
            ResourceTypes = [new ResourceTypeRow(1, "ENDPOINT", "Endpoint", true, false, null, true)],
            Resources = [new ResourceRow(1, 1, 1, null, "app.x", "X", null, 0, true), new ResourceRow(2, 1, 1, null, "app.y", "Y", null, 1, true)],
            Scopes = [new ScopeRow(1, 1, "view", "View"), new ScopeRow(2, 1, "summary", "Summary")],
            ResourceScopes = [new ResourceScopeRow(10, 1, 1, Severity.Low), new ResourceScopeRow(11, 1, 2, Severity.Low), new ResourceScopeRow(12, 2, 1, Severity.Low)],
            Uris = [new UriRow(1, 1, "GET", "/v1/x/{id}", 1), new UriRow(2, 1, "GET", "/v1/x/summary", 2), new UriRow(3, 2, "*", "/v1/y/{a}", 1), new UriRow(4, 1, "GET", "/v1/y/{b}", 1)]
        };
        var m = AuthorizationModel.Build(data, null, new GroupCriterionRegistry([]), 1, false, DateTime.UtcNow);

        Assert.Equal(11, m.MatchHttp(null, "GET", "/v1/x/summary?q=1", 1).Match!.Access.Id);   // sabit segment jokeri yener
        Assert.Equal(10, m.MatchHttp(null, "get", "/v1/x/42/", 1).Match!.Access.Id);
        Assert.Null(m.MatchHttp(null, "POST", "/v1/x/42", 1).Match);                           // METHOD eşleşmiyor → kayıtsız
        Assert.Equal(10, m.MatchHttp(null, "GET", "/v1/y/7", 1).Match!.Access.Id);            // GET tam eşleşme, * metoduna üstün
        Assert.Equal(12, m.MatchHttp(null, "DELETE", "/v1/y/7", 1).Match!.Access.Id);
    }

    [Theory]
    [InlineData(new[] { "/v1/vadeli-hesap", "/v1/vadeli-hesap/{hesapNo}/kapat" }, "/v1/vadeli-hesap")]
    [InlineData(new[] { "/v1/kredi/dosya/{id}", "/v1/kredi/dosya/{id}/onay" }, "/v1/kredi/dosya")]
    [InlineData(new[] { "/v1/eft", "/v2/transfer" }, "")]                       // ortak önek yok → uygulama kökü
    [InlineData(new[] { "/a-islemler/**" }, "/a-islemler")]
    public void URL_gruplamasi_ilk_parametrede_durur(string[] patterns, string expected) =>
        Assert.Equal(expected, AuthorizationModel.UrlGroup(patterns));
}
