using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
using Yetki.Application.Abstractions;
using Yetki.Application.Model;

namespace Yetki.Api.Infrastructure;

/// <summary>Motor API'sinin (karar uçları) kimlik doğrulama ayarları (appsettings: "EngineAuth").</summary>
public sealed class EngineAuthOptions
{
    /// <summary>Token imzalama anahtarı (base64, en az 32 bayt). ÜRETİMDE gizli yönetimden gelmeli.</summary>
    public string SigningKey { get; set; } = "";
    /// <summary>Token ömrü (dakika).</summary>
    public int TokenMinutes { get; set; } = 10;
    /// <summary>Client'ta tanımlı değilse dakikadaki en fazla karar isteği.</summary>
    public int DefaultRateLimitPerMinute { get; set; } = 600;
    public string Issuer { get; set; } = "yetki-engine";
}

/// <summary>Doğrulanmış soranın kimliği (istek boyunca HttpContext.Items'ta).</summary>
public static class CallerContext
{
    private const string Key = "yetki.caller";
    public static void Set(HttpContext ctx, string clientId) => ctx.Items[Key] = clientId;
    public static string Get(HttpContext ctx) => ctx.Items[Key] as string ?? throw new InvalidOperationException("Soran kimliği yok (RequireCaller filtresi uygulanmadı).");
}

/// <summary>
/// Motorun kendi kısa ömürlü token'ı (OAuth 2.0 client credentials sonucu). HMAC-SHA256 ile imzalı JWT:
/// { iss, sub = client_id, iat, exp, jti }. Bu token sadece BU motorun karar uçları içindir; kullanıcı kimliği taşımaz.
/// </summary>
public sealed class EngineTokenService(IOptions<EngineAuthOptions> options, IClock clock)
{
    private byte[] Key
    {
        get
        {
            var k = options.Value.SigningKey;
            byte[] bytes;
            try { bytes = Convert.FromBase64String(k); } catch (FormatException) { bytes = Encoding.UTF8.GetBytes(k); }
            if (bytes.Length < 32) throw new InvalidOperationException("EngineAuth:SigningKey en az 32 bayt olmalı.");
            return bytes;
        }
    }

    public (string Token, int ExpiresIn) Issue(string clientId)
    {
        var now = clock.UtcNow;
        var expiresIn = options.Value.TokenMinutes * 60;
        var header = B64(JsonSerializer.SerializeToUtf8Bytes(new { alg = "HS256", typ = "JWT" }));
        var payload = B64(JsonSerializer.SerializeToUtf8Bytes(new Dictionary<string, object>
        {
            ["iss"] = options.Value.Issuer, ["sub"] = clientId, ["iat"] = ToUnix(now), ["exp"] = ToUnix(now.AddSeconds(expiresIn)), ["jti"] = Guid.NewGuid().ToString("N")
        }));
        var signature = B64(HMACSHA256.HashData(Key, Encoding.ASCII.GetBytes($"{header}.{payload}")));
        return ($"{header}.{payload}.{signature}", expiresIn);
    }

    /// <summary>İmza, yayımlayan ve süre geçerliyse client_id döner; değilse null.</summary>
    public string? Validate(string token)
    {
        var parts = token.Split('.');
        if (parts.Length != 3) return null;
        var expected = HMACSHA256.HashData(Key, Encoding.ASCII.GetBytes($"{parts[0]}.{parts[1]}"));
        byte[] actual;
        try { actual = FromB64(parts[2]); } catch (FormatException) { return null; }
        if (!CryptographicOperations.FixedTimeEquals(expected, actual)) return null;
        try
        {
            using var doc = JsonDocument.Parse(FromB64(parts[1]));
            var root = doc.RootElement;
            if (root.GetProperty("iss").GetString() != options.Value.Issuer) return null;
            if (root.GetProperty("exp").GetInt64() <= ToUnix(clock.UtcNow)) return null;
            return root.GetProperty("sub").GetString();
        }
        catch (Exception e) when (e is JsonException or KeyNotFoundException or FormatException or InvalidOperationException) { return null; }
    }

    private static long ToUnix(DateTime utc) => new DateTimeOffset(DateTime.SpecifyKind(utc, DateTimeKind.Utc)).ToUnixTimeSeconds();
    private static string B64(byte[] b) => Convert.ToBase64String(b).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    private static byte[] FromB64(string s)
    {
        s = s.Replace('-', '+').Replace('_', '/');
        return Convert.FromBase64String(s.PadRight(s.Length + (4 - s.Length % 4) % 4, '='));
    }
}

/// <summary>
/// Karar uçlarını korur: Authorization: Bearer &lt;motor token'ı&gt; zorunlu. Soranın kimliği token'dan çıkar (gövdedeki değer yok sayılır).
/// Client pasifse reddeder; client başına dakikalık istek limiti uygular (bir tüketici motoru tıkayıp diğerlerini etkilemesin).
/// </summary>
public sealed class RequireCallerAttribute() : TypeFilterAttribute(typeof(RequireCallerFilter));

/// <summary>RequireCaller uygulanan controller'da kimlik istemeyen aksiyon (ör. keşif belgesi).</summary>
[AttributeUsage(AttributeTargets.Method)]
public sealed class AllowAnonymousCallerAttribute : Attribute;

public sealed class RequireCallerFilter(EngineTokenService tokens, AuthorizationModelProvider models, IOptions<EngineAuthOptions> options, IClock clock)
    : IAsyncActionFilter
{
    private static readonly ConcurrentDictionary<(string Client, long Minute), int> Windows = new();

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        if (context.ActionDescriptor.EndpointMetadata.OfType<AllowAnonymousCallerAttribute>().Any()) { await next(); return; }
        var header = context.HttpContext.Request.Headers.Authorization.ToString();
        var clientId = header.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase) ? tokens.Validate(header[7..].Trim()) : null;
        if (clientId is null)
        {
            context.HttpContext.Response.Headers.WWWAuthenticate = "Bearer error=\"invalid_token\"";
            context.Result = Problem(401, "Kimlik doğrulanmadı",
                "Geçerli bir motor token'ı gerekli: önce POST /api/v1/token (client_id + client_secret), sonra Authorization: Bearer <token>.");
            return;
        }
        var model = await models.GetCurrentAsync(context.HttpContext.RequestAborted);
        if (!model.ClientsById.TryGetValue(clientId, out var client) || !client.IsActive)
        {
            context.Result = Problem(401, "Client pasif veya silinmiş", $"'{clientId}' artık motoru kullanamaz.");
            return;
        }
        var limit = model.ScopeOf(client).RateLimitPerMinute ?? options.Value.DefaultRateLimitPerMinute;
        var minute = clock.UtcNow.Ticks / TimeSpan.TicksPerMinute;
        var count = Windows.AddOrUpdate((clientId, minute), 1, (_, c) => c + 1);
        if (Windows.Count > 10_000) foreach (var k in Windows.Keys.Where(k => k.Minute < minute)) Windows.TryRemove(k, out _);
        if (count > limit)
        {
            context.HttpContext.Response.Headers.RetryAfter = "60";
            context.Result = Problem(429, "İstek limiti aşıldı", $"'{clientId}' dakikada en fazla {limit} karar isteği gönderebilir.");
            return;
        }
        CallerContext.Set(context.HttpContext, clientId);
        await next();
    }

    private static ObjectResult Problem(int status, string title, string detail) =>
        new(new ProblemDetails { Status = status, Title = title, Detail = detail }) { StatusCode = status };
}
