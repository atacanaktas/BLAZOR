using System.Globalization;
using System.Text.Json.Serialization;
using Yetki.Api.Infrastructure;
using Yetki.Application.Abstractions;
using Yetki.Infrastructure;

// Türkçe kültürde sayı/tarih/büyük-küçük harf sürprizlerini önlemek için invariant.
CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.InvariantCulture;

var builder = WebApplication.CreateBuilder(args);

// Veritabanı: API klasöründeki yetki.db (SQLite). Göreli yol content root'a göre çözülür.
builder.Services.AddYetkiInfrastructure(builder.Configuration, builder.Environment.ContentRootPath);
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentActor, HttpCurrentActor>();

// Motor API kimlik doğrulaması: client secret → kısa ömürlü token. İmza anahtarı yoksa süreç başına rastgele üretilir
// (yeniden başlatınca eski token'lar geçersiz olur). ÜRETİMDE anahtar gizli yönetimden verilmeli.
builder.Services.Configure<EngineAuthOptions>(builder.Configuration.GetSection("EngineAuth"));
builder.Services.PostConfigure<EngineAuthOptions>(o =>
{
    if (string.IsNullOrWhiteSpace(o.SigningKey)) o.SigningKey = Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(32));
});
builder.Services.AddSingleton<EngineTokenService>();

builder.Services.AddControllers(o => o.Filters.Add<ApiExceptionFilter>())
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        o.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "Yetki Motoru API", Version = "v1", Description = "Hibrit yetkilendirme: RBAC + filtreli grup + hedefli ABAC policy · AuthZEN uyumlu PDP" });
    c.CustomSchemaIds(t => t.FullName!.Replace("+", "."));
    // Karar uçları (/api/v1, /access/v1) motor token'ı ister: POST /api/v1/token ile alınır
    c.AddSecurityDefinition("Bearer", new() { Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http, Scheme = "bearer", BearerFormat = "JWT",
        Description = "POST /api/v1/token (client_id + client_secret) ile alınan motor token'ı" });
    c.AddSecurityRequirement(new()
    {
        [new Microsoft.OpenApi.Models.OpenApiSecurityScheme { Reference = new() { Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme, Id = "Bearer" } }] = []
    });
});
builder.Services.AddCors(o => o.AddPolicy("web", p => p
    .WithOrigins(builder.Configuration.GetSection("Cors:Origins").Get<string[]>() ?? ["http://localhost:5180"])
    .AllowAnyHeader().AllowAnyMethod().WithExposedHeaders("ETag")));

var app = builder.Build();

await app.Services.InitializeYetkiDatabaseAsync(); // migration + condition tipi senkronu; seed YOK

app.UseSwagger();
app.UseSwaggerUI();
app.UseCors("web");
app.MapControllers();
app.MapGet("/", () => Results.Redirect("/swagger")).ExcludeFromDescription();

app.Run();

public partial class Program;
