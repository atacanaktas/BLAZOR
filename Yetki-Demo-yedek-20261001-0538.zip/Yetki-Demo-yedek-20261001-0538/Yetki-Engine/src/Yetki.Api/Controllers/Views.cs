using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Domain.Common;

namespace Yetki.Api.Controllers;

/// <summary>Condition ağacının UI gösterimi. Reference düğümünün Children'ı çözülmüş ortak koşul köküdür (What-If parametre değişikliği için id'li).</summary>
public sealed record ConditionView(int Id, ConditionKind Kind, string? ConditionType, IReadOnlyDictionary<string, string> Parameters,
    IReadOnlyList<ConditionView> Children, string? SharedCondition, int? SharedConditionVersion);

public static class Views
{
    public static ConditionView? Condition(ConditionNode? n) => n is null ? null : new ConditionView(
        n.Id, n.Kind, n.ConditionTypeCode, n.Parameters, n.Children.Select(c => Condition(c)!).ToList(), n.ReferenceCode, n.ReferenceVersion);

    /// <summary>Policy üyesinin okunur adı (tipine göre rol / grup / kullanıcı / client / alt policy).</summary>
    public static object Member(AuthorizationModel m, PolicyType type, int id) => type switch
    {
        PolicyType.Role => new { id, code = m.Roles.GetValueOrDefault(id)?.Code ?? $"#{id}", name = m.Roles.GetValueOrDefault(id)?.Name },
        PolicyType.Group => new { id, code = m.Groups.GetValueOrDefault(id)?.Code ?? $"#{id}", name = m.Groups.GetValueOrDefault(id)?.Name },
        PolicyType.User => new { id, code = m.Users.GetValueOrDefault(id)?.UserName ?? $"#{id}", name = m.Users.GetValueOrDefault(id)?.FullName },
        PolicyType.Client => new { id, code = m.ClientCodeOf(id), name = m.ClientsByPk.GetValueOrDefault(id)?.Name },
        _ => new { id, code = m.Policies.GetValueOrDefault(id)?.Row.Code ?? $"#{id}", name = m.Policies.GetValueOrDefault(id)?.Row.Name }
    };
}
