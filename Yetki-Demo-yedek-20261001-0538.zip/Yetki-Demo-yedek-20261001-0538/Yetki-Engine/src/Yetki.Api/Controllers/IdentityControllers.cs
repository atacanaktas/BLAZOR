using Yetki.Application.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Changes;
using Yetki.Application.Definitions;
using Yetki.Application.Evaluation;
using Yetki.Application.Model;
using Yetki.Domain.Common;

namespace Yetki.Api.Controllers;

// ================================ Kurum ================================

[ApiController]
[Route("api")]
public sealed class TenantsController(AuthorizationModelProvider models, TenantService service) : ControllerBase
{
    [HttpGet("tenants")]
    public async Task<object> List(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.Tenants.Values.OrderBy(o => o.Id).Select(o => new
        {
            o.Id, o.Code, o.Name, o.Type, o.ParentId, parent = o.ParentId is { } p ? m.TenantCode(p) : null, o.IsActive,
            userCount = m.Users.Values.Count(u => u.TenantId == o.Id),
            roleCount = m.Roles.Values.Count(r => r.TenantId == o.Id),
            inheritedRoles = m.Roles.Values.Where(r => r.IsInheritable && r.TenantId != o.Id && m.TenantAncestors[o.Id].Contains(r.TenantId)).Select(r => r.Code).ToList(),
            groupCount = m.Groups.Values.Count(g => g.TenantId == o.Id),
            ownPolicies = m.Policies.Values.Where(p => p.Row.TenantId == o.Id).Select(p => p.Row.Code).ToList(),
            ownApplications = m.Apps.Values.Where(a => a.TenantId == o.Id).Select(a => a.Code).ToList(),
            inheritedApplications = m.Apps.Values.Where(a => a.TenantId != o.Id && m.IsAvailableIn(a.TenantId, o.Id)).Select(a => a.Code).ToList(),
            ownClients = m.ClientsById.Values.Where(c => c.TenantId == o.Id).Select(c => c.ClientId).ToList(),
            inheritedClients = m.ClientsById.Values.Where(c => c.TenantId != o.Id && m.IsAvailableIn(c.TenantId, o.Id)).Select(c => c.ClientId).ToList()
        }).ToList();
    }

    [HttpGet("org-units")]
    public async Task<object> Units([FromQuery] int? tenantId, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.Units.Values.Where(u => tenantId is null || u.TenantId == tenantId).OrderBy(u => u.TenantId).ThenBy(u => u.Id)
            .Select(u => new
            {
                u.Id, u.Code, u.Name, u.Type, u.ParentId, u.TenantId, tenant = m.TenantCode(u.TenantId),
                userCount = m.Data.UserUnits.Count(x => x.OrgUnitId == u.Id)
            }).ToList();
    }

    [HttpPost("tenants")]
    public async Task<object> Create(TenantUpsert dto, CancellationToken ct) => new { (await service.CreateAsync(dto, ct)).Id };

    [HttpPost("org-units")]
    public async Task<object> CreateUnit(OrgUnitUpsert dto, CancellationToken ct) => new { (await service.CreateUnitAsync(dto, ct)).Id };
}

// ================================ Kullanıcı ================================

public sealed record RoleAssignRequest(int RoleId, DateTime? ValidUntil, string? Reason);

[ApiController]
[Route("api/users")]
public sealed class UsersController(IIdentityProvider identities, AuthorizationModelProvider models, AssignmentService assignments, EntitlementService entitlements, IYetkiDbContext db, IClock clock) : ControllerBase
{
    [HttpGet]
    public async Task<object> List([FromQuery] string? q, [FromQuery] int? tenantId, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        return m.Users.Values
            .Where(u => tenantId is null || u.TenantId == tenantId)
            .Where(u => string.IsNullOrWhiteSpace(q) || u.UserName.Contains(q, StringComparison.OrdinalIgnoreCase) || u.FullName.Contains(q, StringComparison.OrdinalIgnoreCase))
            .OrderBy(u => u.UserName, StringComparer.Ordinal)
            .Select(u =>
            {
                var e = m.GetEffective(u.Id, now);
                return new
                {
                    u.Id, u.UserName, u.FullName, u.Title, u.Kind, u.IsActive, u.IsOnLeave, tenant = m.TenantCode(u.TenantId),
                    units = m.UnitCodesOf(u.Id).ToList(),
                    directRoles = m.DirectRoleCodes(u.Id, now).ToList(),
                    groups = e.Groups.Select(g => g.Code).ToList(),
                    accessCount = e.Accesses.Count,
                    conditionalCount = e.Accesses.Count(a => a.Conditional)
                };
            }).ToList();
    }

    [HttpGet("{id:int}")]
    public async Task<object> Detail(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Users.TryGetValue(id, out var u)) throw new NotFoundException("Kullanıcı", id);
        var user = await identities.GetUserAsync(id, ct) ?? throw new NotFoundException("User", id);
        var roles = (await identities.GetUserRolesAsync(id, ct))
            .Select(x => new { x.RoleId, Code = m.Roles.GetValueOrDefault(x.RoleId)?.Code,
                Name = m.Roles.GetValueOrDefault(x.RoleId)?.Name, x.ValidFrom, x.ValidUntil, x.Reason, x.AssignedAt, x.AssignedBy }).ToList();
        var units = await db.UserOrgUnits.AsNoTracking().Where(x => x.UserId == id)
            .Select(x => new { x.OrgUnitId, x.OrgUnit.Code, x.OrgUnit.Name, x.OrgUnit.Type, x.IsPrimary }).ToListAsync(ct);
        var explicitGroups = await db.GroupMembers.AsNoTracking().Where(x => x.UserId == id)
            .Select(x => new { x.GroupId, x.Group.Code, x.ValidUntil }).ToListAsync(ct);
        var violations = await db.SodViolations.AsNoTracking().Where(v => v.UserId == id && v.Status != ViolationStatus.Resolved)
            .Select(v => new { v.Id, v.SodRule.Code, v.Status, v.Details, v.DetectedAt }).ToListAsync(ct);
        return new
        {
            user = new
            {
                user.Id, user.UserName, user.FullName, user.Email, user.Title, user.EmployeeNo, user.Kind, user.IsActive, user.IsOnLeave,
                user.CashWithdrawalLimit, user.CustomerNo, user.TenantId, tenant = m.TenantCode(user.TenantId)
            },
            roles, units, explicitGroups, violations,
            policies = m.PoliciesWithMember(PolicyType.User, id).Select(p => new { p.Row.Id, p.Row.Code, p.Row.Name }).ToList(),
            tenantChain = m.TenantAncestors[u.TenantId].Select(m.TenantCode).ToList()
        };
    }

    [HttpGet("{id:int}/effective")]
    public async Task<EffectiveAccessSet> Effective(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Users.ContainsKey(id)) throw new NotFoundException("Kullanıcı", id);
        return m.GetEffective(id, clock.UtcNow);
    }

    [HttpGet("{id:int}/entitlements")]
    public async Task<EntitlementResult> Entitlements(int id, [FromQuery] string? client, [FromQuery] string? application,
        [FromQuery] bool evaluate, [FromQuery] string? ip, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Users.TryGetValue(id, out var u)) throw new NotFoundException("Kullanıcı", id);
        return await entitlements.GetAsync(new EntitlementRequest
        {
            User = u.UserName, Client = client, Application = application, Evaluate = evaluate,
            Context = ip is null ? new() : new() { ["IpAddress"] = ip }
        }, ct);
    }

    [HttpPost]
    public async Task<object> Create(UserUpsert dto, CancellationToken ct) => new { (await assignments.CreateUserAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task<ChangeImpactResult> Update(int id, UserUpsert dto, CancellationToken ct) => assignments.UpdateUserAsync(id, dto, ct);

    [HttpPost("{id:int}/roles")]
    public Task<ChangeImpactResult> AssignRole(int id, RoleAssignRequest r, CancellationToken ct) => assignments.AssignRoleAsync(id, r.RoleId, r.ValidUntil, r.Reason, ct);

    [HttpDelete("{id:int}/roles/{roleId:int}")]
    public Task<ChangeImpactResult> RevokeRole(int id, int roleId, CancellationToken ct) => assignments.RevokeRoleAsync(id, roleId, ct);

    [HttpPost("{id:int}/units/{unitId:int}")]
    public Task<ChangeImpactResult> AddUnit(int id, int unitId, CancellationToken ct) => assignments.SetUserUnitAsync(id, unitId, true, ct);

    [HttpDelete("{id:int}/units/{unitId:int}")]
    public Task<ChangeImpactResult> RemoveUnit(int id, int unitId, CancellationToken ct) => assignments.SetUserUnitAsync(id, unitId, false, ct);
}

// ================================ Rol ================================

[ApiController]
[Route("api/roles")]
public sealed class RolesController(AuthorizationModelProvider models, AssignmentService assignments, IClock clock) : ControllerBase
{
    [HttpGet]
    public async Task<object> List(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        return m.Roles.Values.OrderBy(r => r.TenantId).ThenBy(r => r.Code, StringComparer.Ordinal).Select(r => new
        {
            r.Id, r.Code, r.Name, r.IsInheritable, r.IsActive, r.TenantId, tenant = m.TenantCode(r.TenantId),
            policies = m.PoliciesWithMember(PolicyType.Role, r.Id).Select(p => p.Row.Code).ToList(),
            directHolders = m.Data.UserRoles.Count(x => x.RoleId == r.Id && (x.ValidUntil == null || x.ValidUntil > now)),
            grantingGroups = m.Data.GroupRoles.Where(x => x.RoleId == r.Id && m.Groups.ContainsKey(x.GroupId)).Select(x => m.Groups[x.GroupId].Code).ToList()
        }).ToList();
    }

    /// <summary>Rol detayı: rolü üye alan policy'ler → onları kullanan permission'lar → kapsadıkları yetkiler; rol sahipleri.</summary>
    [HttpGet("{id:int}")]
    public async Task<object> Detail(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Roles.TryGetValue(id, out var r)) throw new NotFoundException("Rol", id);
        var now = clock.UtcNow;
        var holders = m.Users.Values.Select(u => (u, e: m.GetIdentity(u.Id, now).Roles.FirstOrDefault(x => x.RoleId == id)))
            .Where(x => x.e is not null)
            .Select(x => new { userId = x.u.Id, x.u.UserName, x.u.FullName, tenant = m.TenantCode(x.u.TenantId), sources = x.e!.Sources.Select(s => s.Text).ToList() })
            .ToList();
        var policies = m.PoliciesWithMember(PolicyType.Role, id).ToList();
        var permissions = policies.SelectMany(p => m.PermissionsUsingPolicy(p.Row.Id)).DistinctBy(p => p.Row.Id).OrderBy(p => p.Row.Code, StringComparer.Ordinal).ToList();
        return new
        {
            role = new { r.Id, r.Code, r.Name, r.IsInheritable, r.IsActive, r.TenantId, tenant = m.TenantCode(r.TenantId) },
            policies = policies.Select(p => new { p.Row.Id, p.Row.Code, p.Row.Name, p.Row.Logic, p.Row.IsActive }).ToList(),
            permissions = permissions.Select(p => new
            {
                p.Row.Id, p.Row.Code, p.Row.Name, application = p.App.Code,
                otherPolicies = p.PolicyIds.Where(pid => policies.All(x => x.Row.Id != pid)).Select(pid => m.Policies.GetValueOrDefault(pid)?.Row.Code ?? $"#{pid}").ToList(),
                accesses = m.CoverageOf(p).Select(x => x.Key).ToList()
            }).ToList(),
            holders,
            grantingGroups = m.Data.GroupRoles.Where(x => x.RoleId == id && m.Groups.ContainsKey(x.GroupId)).Select(x => new { x.GroupId, m.Groups[x.GroupId].Code, m.Groups[x.GroupId].Name }).ToList()
        };
    }

    [HttpPost]
    public async Task<object> Create(RoleUpsert dto, CancellationToken ct) => new { (await assignments.CreateRoleAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task<ChangeImpactResult> Update(int id, RoleUpsert dto, CancellationToken ct) => assignments.UpdateRoleAsync(id, dto, ct);
}

// ================================ Grup ================================

public sealed record MemberRequest(DateTime? ValidUntil);
public sealed record GroupPreviewRequest(int TenantId, List<GroupFilterDraft> Filters, List<int>? ExplicitMemberIds);

[ApiController]
[Route("api/groups")]
public sealed class GroupsController(AuthorizationModelProvider models, AssignmentService assignments, IYetkiDbContext db, IClock clock) : ControllerBase
{
    [HttpGet]
    public async Task<object> List(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        return m.Groups.Values.OrderBy(g => g.TenantId).ThenBy(g => g.Code, StringComparer.Ordinal).Select(g => new
        {
            g.Id, g.Code, g.Name, g.IsActive, g.TenantId, tenant = m.TenantCode(g.TenantId),
            rule = Describe(m.GroupFilterRows(g.Id)),
            explicitMembers = m.GroupMemberRows(g.Id).Count(),
            memberCount = m.GroupMembersOf(g.Id, now).Count(),
            roles = m.GroupRoleIds(g.Id).Where(m.Roles.ContainsKey).Select(r => m.Roles[r].Code).ToList(),
            policies = m.PoliciesWithMember(PolicyType.Group, g.Id).Select(p => p.Row.Code).ToList()
        }).ToList();
    }

    [HttpGet("{id:int}")]
    public async Task<object> Detail(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Groups.TryGetValue(id, out var g)) throw new NotFoundException("Grup", id);
        var now = clock.UtcNow;
        var description = await db.Groups.AsNoTracking().Where(x => x.Id == id).Select(x => x.Description).FirstOrDefaultAsync(ct);
        var excluded = m.Users.Values.Select(u => (u, x: m.GetIdentity(u.Id, now).ExcludedFromGroups.FirstOrDefault(e => e.GroupId == id)))
            .Where(t => t.x is not null).Select(t => new { userId = t.u.Id, t.u.UserName, t.u.FullName, reason = t.x!.Reason }).ToList();
        return new
        {
            group = new { g.Id, g.Code, g.Name, g.IsActive, g.TenantId, tenant = m.TenantCode(g.TenantId), description },
            filters = m.GroupFilterRows(id).Select(f => new
            {
                f.Order, f.Mode, f.Description, criteria = f.Criteria.Select(c => new { c.Attribute, c.Values }).ToList()
            }).ToList(),
            rule = Describe(m.GroupFilterRows(id)),
            explicitMembers = m.GroupMemberRows(id).Where(x => m.Users.ContainsKey(x.UserId))
                .Select(x => new { x.UserId, m.Users[x.UserId].UserName, m.Users[x.UserId].FullName, x.ValidUntil }).ToList(),
            members = m.GroupMembersOf(id, now).Select(x => new
            {
                userId = x.User.Id, x.User.UserName, x.User.FullName, x.User.Title, tenant = m.TenantCode(x.User.TenantId),
                units = m.UnitCodesOf(x.User.Id).ToList(), reasons = x.Membership.Reasons
            }).ToList(),
            excluded,
            roles = m.GroupRoleIds(id).Where(m.Roles.ContainsKey).Select(r => new { m.Roles[r].Id, m.Roles[r].Code, m.Roles[r].Name }).ToList(),
            policies = m.PoliciesWithMember(PolicyType.Group, id).Select(p => new
            {
                p.Row.Id, p.Row.Code, p.Row.Name, permissions = m.PermissionsUsingPolicy(p.Row.Id).Select(x => x.Row.Code).ToList()
            }).ToList()
        };
    }

    /// <summary>Kaydetmeden önce: bu kurallarla kimler üye olurdu? (canlı önizleme; aynı handler'lar)</summary>
    [HttpPost("preview")]
    public async Task<object> Preview(GroupPreviewRequest r, CancellationToken ct)
    {
        await assignments.ValidateFiltersAsync(r.Filters, ct);
        var m = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        var rows = r.Filters.Select((f, i) => new GroupFilterRow(0, i, f.Mode, f.Description,
            f.Criteria.Select(c => new CriterionRow(c.Attribute.ToUpperInvariant(), c.Values)).ToList())).ToList();
        var explicitIds = r.ExplicitMemberIds?.ToHashSet() ?? [];
        var members = new List<object>();
        var excluded = new List<object>();
        foreach (var u in m.Users.Values.Where(u => m.TenantAncestors[u.TenantId].Contains(r.TenantId)).OrderBy(u => u.UserName, StringComparer.Ordinal))
        {
            var reasons = new List<string>();
            if (explicitIds.Contains(u.Id)) reasons.Add("açık üye");
            string? ex = null;
            foreach (var f in rows)
            {
                if (!m.FilterMatches(f, u, now, out var text)) continue;
                if (f.Mode == InclusionMode.Include) reasons.Add($"kural #{f.Order + 1}: {text}");
                else ex ??= $"kural #{f.Order + 1} (hariç): {text}";
            }
            if (reasons.Count == 0) continue;
            var item = new { userId = u.Id, u.UserName, u.FullName, u.Title, units = m.UnitCodesOf(u.Id).ToList(), reasons, excludedBy = ex };
            (ex is null ? members : excluded).Add(item);
        }
        return new { rule = AssignmentService.Describe(r.Filters), members, excluded };
    }

    [HttpPost]
    public async Task<object> Create(GroupUpsert dto, CancellationToken ct) => new { (await assignments.CreateGroupAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task<ChangeImpactResult> Update(int id, GroupUpsert dto, CancellationToken ct) => assignments.UpdateGroupAsync(id, dto, ct);

    [HttpPut("{id:int}/filters")]
    public Task<ChangeImpactResult> ReplaceFilters(int id, List<GroupFilterDraft> filters, CancellationToken ct) => assignments.ReplaceGroupFiltersAsync(id, filters, ct);

    [HttpPost("{id:int}/members/{userId:int}")]
    public Task<ChangeImpactResult> AddMember(int id, int userId, MemberRequest? r, CancellationToken ct) => assignments.SetGroupMemberAsync(id, userId, true, r?.ValidUntil, ct);

    [HttpDelete("{id:int}/members/{userId:int}")]
    public Task<ChangeImpactResult> RemoveMember(int id, int userId, CancellationToken ct) => assignments.SetGroupMemberAsync(id, userId, false, null, ct);

    [HttpPost("{id:int}/roles/{roleId:int}")]
    public Task<ChangeImpactResult> AddRole(int id, int roleId, CancellationToken ct) => assignments.SetGroupRoleAsync(id, roleId, true, ct);

    [HttpDelete("{id:int}/roles/{roleId:int}")]
    public Task<ChangeImpactResult> RemoveRole(int id, int roleId, CancellationToken ct) => assignments.SetGroupRoleAsync(id, roleId, false, ct);

    [HttpGet("/api/group-criteria")]
    public async Task<object> Criteria(CancellationToken ct) =>
        (await models.GetCurrentAsync(ct)).Criteria.All.Select(h => h.Descriptor).OrderBy(d => d.Code).ToList();

    public static string Describe(IEnumerable<GroupFilterRow> filters)
    {
        var list = filters.ToList();
        if (list.Count == 0) return "(kural yok — sadece açık üyeler)";
        return string.Join(" ∪ ", list.Where(f => f.Mode == InclusionMode.Include).Select(Part))
               + string.Concat(list.Where(f => f.Mode == InclusionMode.Exclude).Select(f => " − " + Part(f)));

        static string Part(GroupFilterRow f) => "(" + string.Join(" ∧ ", f.Criteria.Select(c => $"{c.Attribute}∈{{{string.Join(",", c.Values)}}}")) + ")";
    }
}
