using Microsoft.AspNetCore.Mvc;
using Yetki.Application.Inventory;
using Yetki.Domain.Catalog;

namespace Yetki.Api.Controllers;

/// <summary>
/// Envanter (uygulamada gerçekte ne var: Swagger endpoint'leri, ekran/bileşen listesi) ve kapsama raporu.
/// Envanter sadece bilgidir: yetki tanımı üretmez, kararları etkilemez.
/// </summary>
[ApiController]
[Route("api/inventory")]
public sealed class InventoryController(InventoryService inventory) : ControllerBase
{
    /// <summary>Kapsama raporu: envanter ↔ yetki tanımları (korunuyor / permission yok / tanımsız / atıl).</summary>
    [HttpGet("{applicationId:int}/coverage")]
    public Task<CoverageReport> Coverage(int applicationId, CancellationToken ct) => inventory.CoverageAsync(applicationId, ct);

    /// <summary>Endpoint envanteri içe aktar (OpenAPI JSON veya "METHOD /yol açıklama" satırları). Öncekinin yerini alır.</summary>
    [HttpPost("{applicationId:int}/endpoints")]
    public Task<InventorySnapshotInfo> ImportEndpoints(int applicationId, InventoryImport dto, CancellationToken ct) =>
        inventory.ImportAsync(applicationId, InventoryKind.Endpoint, dto, ct);

    /// <summary>UI öğesi envanteri içe aktar (JSON dizi veya "KOD;Ad;ÜstKod;Tip" satırları). Öncekinin yerini alır.</summary>
    [HttpPost("{applicationId:int}/ui")]
    public Task<InventorySnapshotInfo> ImportUi(int applicationId, InventoryImport dto, CancellationToken ct) =>
        inventory.ImportAsync(applicationId, InventoryKind.UiElement, dto, ct);

    [HttpDelete("{applicationId:int}/{kind}")]
    public Task Delete(int applicationId, InventoryKind kind, CancellationToken ct) => inventory.DeleteAsync(applicationId, kind, ct);
}
