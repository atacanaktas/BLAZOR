using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Definitions;
using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Domain.Common;

namespace Yetki.Api.Controllers;

/// <summary>Policy'ler (KİM / HANGİ KOŞULDA?): rol, grup, kullanıcı, client, condition (ABAC), aggregate.</summary>
[ApiController]
[Route("api/policies")]
public sealed class PoliciesController(AuthorizationModelProvider models, PolicyManagementService service, IYetkiDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<object> List(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.Policies.Values.OrderBy(p => p.Row.Type).ThenBy(p => p.Row.Code, StringComparer.Ordinal).Select(p => new
        {
            p.Row.Id, p.Row.Code, p.Row.Name, p.Row.Type, p.Row.Logic, p.Row.Mode, p.Row.IsActive, strategy = p.Row.Strategy, p.Row.Version, tenant = p.TenantCode,
            members = p.OrderedMembers.Select(id => Views.Member(m, p.Row.Type, id)).ToList(),
            rules = (p.Definition?.Rules ?? []).OrderBy(r => r.Order).Select(r => new { r.Code, r.Name, r.IsActive, expression = PolicyEvaluator.Render(r.Condition) }).ToList(),
            obligations = p.Obligations.Select(o => o.Code).ToList(),
            permissions = m.PermissionsUsingPolicy(p.Row.Id).Select(x => x.Row.Code).ToList()
        }).ToList();
    }

    [HttpGet("{id:int}")]
    public async Task<object> Detail(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Policies.TryGetValue(id, out var p)) throw new NotFoundException("Policy", id);
        var meta = await db.Policies.AsNoTracking().Where(x => x.Id == id).Select(x => new { x.Description, x.UpdatedAt, x.UpdatedBy, x.TenantId }).FirstAsync(ct);
        var ruleMeta = await db.Rules.AsNoTracking().Where(r => r.PolicyId == id).ToDictionaryAsync(r => r.Id, r => r.Description, ct);
        var permissions = m.PermissionsUsingPolicy(id).ToList();
        return new
        {
            policy = new
            {
                p.Row.Id, p.Row.Code, p.Row.Name, meta.Description, p.Row.Type, p.Row.Logic, p.Row.Mode, p.Row.IsActive, decisionStrategy = p.Row.Strategy,
                p.Row.Version, meta.TenantId, tenant = p.TenantCode, meta.UpdatedAt, meta.UpdatedBy
            },
            members = p.OrderedMembers.Select(mid => Views.Member(m, p.Row.Type, mid)).ToList(),
            memberIds = p.OrderedMembers,
            obligations = p.Obligations.Select(o => new { o.Id, o.Code, o.FulfillOn, o.Order, parameters = o.Params }).ToList(),
            rules = (p.Definition?.Rules ?? []).OrderBy(r => r.Order).ThenBy(r => r.Code).Select(r => new
            {
                id = r.RuleId, r.Code, r.Name, description = ruleMeta.GetValueOrDefault(r.RuleId), r.Order, r.ReasonCode, r.IsActive,
                expression = PolicyEvaluator.Render(r.Condition), condition = Views.Condition(r.Condition)
            }).ToList(),
            usedBy = new
            {
                permissions = permissions.Select(x => new { x.Row.Id, x.Row.Code, x.Row.Name, application = x.App.Code, coverage = m.CoverageOf(x).Count() }).ToList(),
                aggregates = m.Policies.Values.Where(a => a.Row.Type == PolicyType.Aggregate && a.Members.Contains(id)).Select(a => new { a.Row.Id, a.Row.Code }).ToList()
            }
        };
    }

    [HttpPost]
    public Task<DefinitionChangeResult> Create(PolicyUpsert dto, CancellationToken ct) => service.CreatePolicyAsync(dto, ct);

    /// <summary>?dryRun=true: sadece erişim etkisi (kim kazanır / kaybeder, SoD, RACF) döner.</summary>
    [HttpPut("{id:int}")]
    public Task<DefinitionChangeResult> Update(int id, PolicyUpsert dto, [FromQuery] bool dryRun, CancellationToken ct) => service.UpdatePolicyAsync(id, dto, dryRun, ct);

    [HttpDelete("{id:int}")]
    public Task Delete(int id, CancellationToken ct) => service.DeletePolicyAsync(id, ct);

    [HttpPost("{id:int}/obligations")]
    public async Task<object> AddObligation(int id, ObligationUpsert dto, CancellationToken ct) => new { (await service.AddObligationAsync(id, dto, ct)).Id };

    [HttpDelete("/api/policy-obligations/{obligationId:int}")]
    public Task RemoveObligation(int obligationId, CancellationToken ct) => service.RemoveObligationAsync(obligationId, ct);

    /// <summary>Yükümlülük tipleri (koddaki katalog; PEP bunları yerine getirir).</summary>
    [HttpGet("/api/obligation-types")]
    public IReadOnlyList<ObligationTypeDef> ObligationTypes() => Application.PolicyEngine.ObligationTypes.All;

    [HttpPost("{id:int}/rules")]
    public async Task<object> CreateRule(int id, RuleUpsert dto, CancellationToken ct) => new { (await service.CreateRuleAsync(id, dto, ct)).Id };

    [HttpPut("/api/rules/{ruleId:int}")]
    public Task UpdateRule(int ruleId, RuleUpsert dto, CancellationToken ct) => service.UpdateRuleAsync(ruleId, dto, ct);

    [HttpDelete("/api/rules/{ruleId:int}")]
    public Task DeleteRule(int ruleId, CancellationToken ct) => service.DeleteRuleAsync(ruleId, ct);

    [HttpGet("/api/rules")]
    public async Task<object> AllRules(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.Policies.Values.Where(p => p.Definition is not null).SelectMany(p => p.Definition!.Rules.Select(r => new
        {
            id = r.RuleId, policyId = p.Row.Id, policy = p.Row.Code, r.Code, r.Name, r.Order, r.ReasonCode, r.IsActive,
            expression = PolicyEvaluator.Render(r.Condition), condition = Views.Condition(r.Condition)
        })).OrderBy(r => r.policy).ThenBy(r => r.Order).ToList();
    }

    [HttpGet("/api/condition-types")]
    public async Task<object> ConditionTypes(CancellationToken ct) =>
        await db.ConditionTypes.AsNoTracking().OrderBy(t => t.Code)
            .Select(t => new { t.Id, t.Code, t.Name, t.Description, t.DefaultScope, t.ParameterSchemaJson, t.RequiredAttributes, t.IsAvailable, t.IsSubjectOnly })
            .ToListAsync(ct);
}

/// <summary>Keycloak permission'ları: HANGİ resource/scope'u HANGİ policy'lerle koruyorum?</summary>
[ApiController]
[Route("api/permissions")]
public sealed class PermissionsController(AuthorizationModelProvider models, PermissionService service, IYetkiDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<object> List([FromQuery] int? applicationId, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.Permissions.Values.Where(p => applicationId is null || p.Row.ApplicationId == applicationId)
            .OrderBy(p => p.App.Code).ThenBy(p => p.Row.Code, StringComparer.Ordinal).Select(p => new
            {
                p.Row.Id, p.Row.Code, p.Row.Name, p.Row.IsActive, strategy = p.Row.Strategy, application = p.App.Code, applicationId = p.App.Id,
                p.Row.Target, p.Row.AllScopes, resourceType = p.Row.ResourceTypeId is { } t && m.ResourceTypes.TryGetValue(t, out var rt) ? rt.Code : null,
                resources = p.Resources.Select(r => m.Resources.GetValueOrDefault(r)?.Code ?? $"#{r}").ToList(),
                scopes = p.Scopes.Select(s => m.Scopes.GetValueOrDefault(s)?.Code ?? $"#{s}").ToList(),
                policies = p.PolicyIds.Select(id => new { id, code = m.Policies.GetValueOrDefault(id)?.Row.Code ?? $"#{id}", type = m.Policies.GetValueOrDefault(id)?.Row.Type }).ToList(),
                coverage = m.CoverageOf(p).Count(),
                hasIdentityPolicy = m.HasIdentityPolicy(p)
            }).ToList();
    }

    [HttpGet("{id:int}")]
    public async Task<object> Detail(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Permissions.TryGetValue(id, out var p)) throw new NotFoundException("Permission", id);
        var meta = await db.Permissions.AsNoTracking().Where(x => x.Id == id).Select(x => new { x.Description, x.UpdatedAt, x.UpdatedBy }).FirstAsync(ct);
        return new
        {
            permission = new
            {
                p.Row.Id, p.Row.Code, p.Row.Name, meta.Description, p.Row.IsActive, decisionStrategy = p.Row.Strategy, p.Row.Version,
                applicationId = p.App.Id, application = p.App.Code, applicationStrategy = p.App.Strategy, p.Row.Target, p.Row.AllScopes, p.Row.ResourceTypeId,
                resourceType = p.Row.ResourceTypeId is { } t && m.ResourceTypes.TryGetValue(t, out var rt) ? rt.Code : null,
                meta.UpdatedAt, meta.UpdatedBy, hasIdentityPolicy = m.HasIdentityPolicy(p)
            },
            resourceIds = p.Resources.ToList(),
            scopeIds = p.Scopes.ToList(),
            policyIds = p.PolicyIds,
            resources = p.Resources.Select(r => m.Resources.TryGetValue(r, out var row) ? new { row.Id, row.Code, row.Name } : new { Id = r, Code = $"#{r}", Name = "?" }).ToList(),
            scopes = p.Scopes.Select(s => m.Scopes.TryGetValue(s, out var row) ? new { row.Id, row.Code, row.Name } : new { Id = s, Code = $"#{s}", Name = "?" }).ToList(),
            policies = p.PolicyIds.Select(pid => m.Policies.TryGetValue(pid, out var pol)
                ? new { pol.Row.Id, pol.Row.Code, pol.Row.Name, pol.Row.Type, pol.Row.Logic, pol.Row.Mode, pol.Row.IsActive, members = pol.OrderedMembers.Select(x => Views.Member(m, pol.Row.Type, x)).ToList() }
                : null).Where(x => x is not null).ToList(),
            coverage = m.CoverageOf(p).Select(x => new
            {
                x.Id, x.Key, x.Name, resourceType = x.Type.Code, otherPermissions = m.PermissionsFor(x.Id).Where(o => o.Row.Id != id).Select(o => o.Row.Code).ToList()
            }).ToList()
        };
    }

    /// <summary>?dryRun=true: sadece erişim etkisi döner (kaydetmez).</summary>
    [HttpPost]
    public Task<DefinitionChangeResult> Create(PermissionUpsert dto, [FromQuery] bool dryRun, CancellationToken ct) => service.CreateAsync(dto, dryRun, ct);

    [HttpPut("{id:int}")]
    public Task<DefinitionChangeResult> Update(int id, PermissionUpsert dto, [FromQuery] bool dryRun, CancellationToken ct) => service.UpdateAsync(id, dto, dryRun, ct);

    [HttpDelete("{id:int}")]
    public Task<DefinitionChangeResult> Delete(int id, [FromQuery] bool dryRun, CancellationToken ct) => service.DeleteAsync(id, dryRun, ct);
}

[ApiController]
[Route("api/shared-conditions")]
public sealed class SharedConditionsController(AuthorizationModelProvider models, SharedConditionService service, IYetkiDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<object> List(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var resolver = new ConditionTreeResolver(m.Data.Conditions, m.Data.SharedConditions, null);
        var rows = await db.SharedConditions.AsNoTracking().OrderBy(s => s.Code).ToListAsync(ct);
        var result = new List<object>();
        foreach (var s in rows)
        {
            var usages = await service.UsagesAsync(s.Id, ct);
            result.Add(new
            {
                s.Id, s.Code, s.Name, s.Description, s.Scope, s.Domain, s.IsActive, s.Version,
                expression = PolicyEvaluator.Render(resolver.SharedRoot(s.Id)),
                usageCount = usages.Count, policies = usages.Select(u => u.Policy).Distinct().ToList()
            });
        }
        return result;
    }

    [HttpGet("{id:int}")]
    public async Task<object> Detail(int id, CancellationToken ct)
    {
        var s = await db.SharedConditions.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Ortak koşul", id);
        var m = await models.GetCurrentAsync(ct);
        var root = new ConditionTreeResolver(m.Data.Conditions, m.Data.SharedConditions, null).SharedRoot(id);
        return new
        {
            sharedCondition = new { s.Id, s.Code, s.Name, s.Description, s.Scope, s.Domain, s.IsActive, s.Version },
            expression = PolicyEvaluator.Render(root), expandedExpression = PolicyEvaluator.Render(root, expand: true),
            condition = Views.Condition(root), usages = await service.UsagesAsync(id, ct)
        };
    }

    [HttpPost]
    public async Task<object> Create(SharedConditionUpsert dto, CancellationToken ct) => new { (await service.CreateAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task Update(int id, SharedConditionUpsert dto, CancellationToken ct) => service.UpdateAsync(id, dto, ct);

    [HttpDelete("{id:int}")]
    public Task Delete(int id, CancellationToken ct) => service.DeleteAsync(id, ct);
}
