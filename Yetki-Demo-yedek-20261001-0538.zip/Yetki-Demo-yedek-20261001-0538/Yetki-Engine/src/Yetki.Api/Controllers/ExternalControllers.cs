using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.External;
using Yetki.Application.Model;
using Yetki.Domain.Common;

namespace Yetki.Api.Controllers;

/// <summary>
/// Dış sistemler (RACF / LDAP): tanımlar, katalog bağımlılıkları (API / endpoint / permission → dış yetki), zincir,
/// kullanıcının olması gereken ↔ açık dış durumu, mutabakat (drift) ve provisioning.
/// Değiştiren uçlar <c>?dryRun=true</c> ile sadece etkiyi (kimde ne açılır/kapanır) döner.
/// </summary>
[ApiController]
[Route("api/external")]
public sealed class ExternalController(
    IYetkiDbContext db, AuthorizationModelProvider models, ExternalDefinitionService definitions, ExternalProvisioningService provisioning) : ControllerBase
{
    [HttpGet("systems")]
    public async Task<object> Systems(CancellationToken ct)
    {
        var catalog = await ExternalRequirementCatalog.LoadAsync(db, ct);
        var usage = catalog.Dependencies.GroupBy(d => d.ExternalPermissionId).ToDictionary(g => g.Key, g => g.Count());
        var holders = await db.UserExternalGrants.AsNoTracking().GroupBy(g => g.ExternalPermissionId).Select(g => new { g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.Count, ct);
        var requires = catalog.Requirements.ToLookup(r => r.ExternalPermissionId);
        var requiredBy = catalog.Requirements.ToLookup(r => r.RequiredExternalPermissionId);
        var meta = await db.ExternalPermissions.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Description, ct);
        return catalog.Systems.Values.OrderBy(s => s.Code).Select(s => new
        {
            s.Id, s.Code, s.Name, s.HasAccessLevels,
            permissions = catalog.Permissions.Values.Where(p => p.SystemId == s.Id).OrderBy(p => p.ResourceClass).ThenBy(p => p.Code, StringComparer.Ordinal).Select(p => new
            {
                p.Id, p.Code, p.Name, p.ResourceClass, description = meta.GetValueOrDefault(p.Id),
                dependencyCount = usage.GetValueOrDefault(p.Id), userCount = holders.GetValueOrDefault(p.Id),
                requires = requires[p.Id].Select(r => new { id = r.RequiredExternalPermissionId, key = catalog.Target(r.RequiredExternalPermissionId).Key, level = r.AccessLevel }).ToList(),
                requiredBy = requiredBy[p.Id].Select(r => catalog.Target(r.ExternalPermissionId).Key).ToList()
            }).ToList()
        }).ToList();
    }

    [HttpPost("systems")]
    public async Task<object> CreateSystem(ExternalSystemUpsert dto, CancellationToken ct) => new { (await definitions.CreateSystemAsync(dto, ct)).Id };

    [HttpPost("permissions")]
    public async Task<object> CreatePermission(ExternalPermissionUpsert dto, CancellationToken ct) => new { (await definitions.CreatePermissionAsync(dto, ct)).Id };

    /// <summary>Zincir: bu dış yetkiyi alan kullanıcıya gerekli dış yetki de verilir.</summary>
    [HttpPost("permissions/{id:int}/requires")]
    public Task<ExternalImpactResult> AddRequirement(int id, ExternalRequirementUpsert dto, [FromQuery] bool dryRun, CancellationToken ct) =>
        definitions.SetRequirementAsync(id, dto, true, dryRun, ct);

    [HttpDelete("permissions/{id:int}/requires/{requiredId:int}")]
    public Task<ExternalImpactResult> RemoveRequirement(int id, int requiredId, [FromQuery] bool dryRun, CancellationToken ct) =>
        definitions.SetRequirementAsync(id, new ExternalRequirementUpsert { RequiredExternalPermissionId = requiredId }, false, dryRun, ct);

    /// <summary>Bağımlılıklar (filtre: resourceId, resourceScopeId; forResource = resource'un kendisi + scope'larınınki). Sahibi açıklamasıyla.</summary>
    [HttpGet("dependencies")]
    public async Task<object> Dependencies([FromQuery] int? resourceId, [FromQuery] int? resourceScopeId, [FromQuery] int? forResource, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var catalog = await ExternalRequirementCatalog.LoadAsync(db, ct);
        HashSet<int> resourceScopes = forResource is null ? [] : m.ScopesOf(forResource.Value).Select(s => s.Id).ToHashSet();
        return catalog.Dependencies
            .Where(d => forResource == null || d.ResourceId == forResource || (d.ResourceScopeId is { } rs && resourceScopes.Contains(rs)))
            .Where(d => (resourceId == null || d.ResourceId == resourceId) && (resourceScopeId == null || d.ResourceScopeId == resourceScopeId))
            .Select(d => DependencyView(m, catalog, d)).ToList();
    }

    [HttpPost("dependencies")]
    public Task<ExternalImpactResult> AddDependency(ExternalDependencyUpsert dto, [FromQuery] bool dryRun, CancellationToken ct) =>
        definitions.AddDependencyAsync(dto, dryRun, ct);

    [HttpDelete("dependencies/{id:int}")]
    public Task<ExternalImpactResult> RemoveDependency(int id, [FromQuery] bool dryRun, CancellationToken ct) =>
        definitions.RemoveDependencyAsync(id, dryRun, ct);

    /// <summary>Mutabakat raporu: olması gereken ile dış sistemde açık olan arasında farkı olan kullanıcılar.</summary>
    [HttpGet("drift")]
    public Task<DriftReport> Drift(CancellationToken ct) => provisioning.DriftAsync(ct);

    [HttpPost("reconcile")]
    public async Task<object> ReconcileAll(CancellationToken ct) => new { actions = await provisioning.ReconcileAllAsync(null, ct) };

    /// <summary>
    /// Baseline: dış sistemdeki mevcut durumun olması gerekenle aynı olduğu kabul edilir (komut gönderilmez).
    /// İlk kurulumda / RACF'ten durum içe aktarıldığında kullanılır; sonraki değişiklikler sadece fark üretir.
    /// </summary>
    [HttpPost("baseline")]
    public async Task<object> Baseline(CancellationToken ct)
    {
        await provisioning.BaselineAsync(ct);
        return new { message = "Dış sistem durumu olması gereken durumla eşitlendi (komut gönderilmedi)." };
    }

    // ------------------------------ Kullanıcı ------------------------------

    [HttpGet("/api/users/{id:int}/external")]
    public Task<UserExternalStatus> UserStatus(int id, CancellationToken ct) => provisioning.GetUserStatusAsync(id, ct);

    [HttpPost("/api/users/{id:int}/external/reconcile")]
    public async Task<object> ReconcileUser(int id, CancellationToken ct)
    {
        var actions = await provisioning.ReconcileUserAsync(id, null, ct);
        return new { count = actions.Count, actions = actions.Select(a => new { a.ActionType, a.ExternalSystemCode, a.ExternalPermissionCode, a.AccessLevel, a.Status, a.ResultMessage }) };
    }

    /// <summary>Yetkinin (resource:scope) dış gereksinimleri (doğrudan + resource mirası + zincir) ve ilgili bağımlılıklar.</summary>
    [HttpGet("/api/resource-scopes/{id:int}/external")]
    public async Task<object> AccessRequirements(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.ResourceScopes.TryGetValue(id, out var p)) throw new NotFoundException("Yetki", id);
        var catalog = await ExternalRequirementCatalog.LoadAsync(db, ct);
        return new
        {
            defaultLevel = ExternalRequirementCatalog.DefaultLevel(p.Scope.Code),
            requirements = catalog.ForAccess(p).Select(n => new
            {
                n.Target.ExternalPermissionId, n.Target.System, n.Target.Code, n.Target.Name, n.Target.ResourceClass, level = n.Level, n.Reasons
            }).ToList(),
            dependencies = catalog.Dependencies
                .Where(d => d.ResourceScopeId == id || d.ResourceId == p.Resource.Id)
                .Select(d => DependencyView(m, catalog, d)).ToList()
        };
    }

    private static object DependencyView(AuthorizationModel m, ExternalRequirementCatalog catalog, ExternalDependencyRow d)
    {
        var t = catalog.Target(d.ExternalPermissionId);
        string owner, ownerType;
        int? ownerResourceId;
        if (d.ResourceId is { } r)
        {
            ownerType = "Resource";
            ownerResourceId = r;
            owner = m.Resources.TryGetValue(r, out var res) ? $"{res.Code} (tüm scope'lar)" : $"resource #{r}";
        }
        else
        {
            ownerType = "ResourceScope";
            var rs = m.ResourceScopes.GetValueOrDefault(d.ResourceScopeId!.Value);
            ownerResourceId = rs?.Resource.Id;
            owner = rs?.Key ?? $"yetki #{d.ResourceScopeId}";
        }
        return new
        {
            d.Id, ownerType, owner, resourceId = d.ResourceId, resourceScopeId = d.ResourceScopeId, ownerResourceId,
            t.ExternalPermissionId, t.System, t.Code, t.Name, t.ResourceClass, t.HasAccessLevels, level = d.AccessLevel, d.Note
        };
    }
}
