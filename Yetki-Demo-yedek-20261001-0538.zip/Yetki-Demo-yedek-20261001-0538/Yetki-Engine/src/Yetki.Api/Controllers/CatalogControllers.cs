using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Changes;
using Yetki.Application.Definitions;
using Yetki.Application.Model;
using Yetki.Domain.Common;

namespace Yetki.Api.Controllers;

/// <summary>
/// Yetki tanımları: Tenant → Uygulama (resource server) → resource (tipiyle) → scope'lar (yetkiler) + URI eşlemeleri.
/// Ayrı bir katalog / seviye yoktur; gruplama türetilir (HTTP'de URL kırılımı, UI'da üst-alt). Tanımsız URI'ye gelen istek reddedilir.
/// </summary>
[ApiController]
[Route("api/catalog")]
public sealed class CatalogController(AuthorizationModelProvider models, CatalogService catalog, IYetkiDbContext db, IClock clock) : ControllerBase
{
    /// <summary>Tenant → uygulama → resource listesi. Ağaç (URL kırılımı / üst-alt) istemcide bu listeden kurulur.</summary>
    [HttpGet("tree")]
    public async Task<object> Tree(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        object ResourceView(ResourceRow r) => new
        {
            r.Id, r.Code, r.Name, r.IsActive, r.ParentId, r.ExternalCode, r.Order,
            type = m.ResourceTypes[r.ResourceTypeId].Code, typeName = m.ResourceTypes[r.ResourceTypeId].Name,
            color = m.ResourceTypes[r.ResourceTypeId].Color, matchesHttp = m.ResourceTypes[r.ResourceTypeId].MatchesHttp,
            scopes = m.ScopesOf(r.Id).Select(s => s.Scope.Code).OrderBy(s => s).ToList(),
            uris = m.UrisOf(r.Id).OrderBy(u => u.Pattern, StringComparer.Ordinal).Select(u => new { u.Method, u.Pattern }).ToList(),
            group = AuthorizationModel.UrlGroup(m.UrisOf(r.Id).Select(u => u.Pattern)),
            protectedScopes = m.ScopesOf(r.Id).Count(s => m.PermissionsFor(s.Id).Count > 0)
        };

        return m.Tenants.Values.OrderBy(t => t.Id).Select(t => new
        {
            t.Id, t.Code, t.Name,
            applications = m.Apps.Values.Where(a => a.TenantId == t.Id).OrderBy(a => a.Code, StringComparer.Ordinal).Select(a => new
            {
                a.Id, a.Code, a.Name, a.Type, a.IsActive, strategy = a.Strategy,
                resourceCount = m.Resources.Values.Count(r => r.ApplicationId == a.Id),
                scopeCount = m.Scopes.Values.Count(s => s.ApplicationId == a.Id),
                permissionCount = m.Permissions.Values.Count(p => p.Row.ApplicationId == a.Id),
                resources = m.Resources.Values.Where(r => r.ApplicationId == a.Id).OrderBy(r => r.Order).ThenBy(r => r.Code, StringComparer.Ordinal).Select(ResourceView).ToList()
            }).ToList()
        }).ToList();
    }

    // ------------------------------ Uygulama ------------------------------

    [HttpGet("applications")]
    public async Task<object> Applications(CancellationToken ct) =>
        await db.Applications.AsNoTracking().OrderBy(a => a.Id).Select(a => new
        {
            a.Id, a.Code, a.Name, a.Type, a.Description, a.OwnerTeamId, ownerTeam = a.OwnershipTeam != null ? a.OwnershipTeam.Name : null,
            a.OwnerUserId, a.IsActive, a.TenantId, tenant = a.Tenant.Code, a.DecisionStrategy
        }).ToListAsync(ct);

    [HttpGet("applications/{id:int}")]
    public async Task<object> Application(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Apps.TryGetValue(id, out var a)) throw new NotFoundException("Uygulama", id);
        var meta = await db.Applications.AsNoTracking().Where(x => x.Id == id).Select(x => new
        {
            x.Description, x.OwnerTeamId, ownerTeam = x.OwnershipTeam != null ? x.OwnershipTeam.Name : null, x.OwnerUserId
        }).FirstAsync(ct);
        return new
        {
            application = new { a.Id, a.Code, a.Name, a.Type, a.IsActive, a.TenantId, tenant = m.TenantCode(a.TenantId), decisionStrategy = a.Strategy, meta.Description, meta.OwnerTeamId, meta.ownerTeam, meta.OwnerUserId },
            scopes = m.Scopes.Values.Where(s => s.ApplicationId == id).OrderBy(s => s.Code, StringComparer.Ordinal)
                .Select(s => new { s.Id, s.Code, s.Name, resourceCount = m.ResourceScopes.Values.Count(x => x.Scope.Id == s.Id) }).ToList(),
            permissions = m.Permissions.Values.Where(p => p.Row.ApplicationId == id).OrderBy(p => p.Row.Code, StringComparer.Ordinal)
                .Select(p => new { p.Row.Id, p.Row.Code, p.Row.Name, p.Row.IsActive, coverage = m.CoverageOf(p).Count() }).ToList(),
            clients = m.ClientsById.Values.Where(c => c.ApplicationId == id).Select(c => new { c.Id, c.ClientId, c.Name }).ToList()
        };
    }

    [HttpPost("applications")]
    public async Task<object> CreateApplication(ApplicationUpsert dto, CancellationToken ct) => new { (await catalog.CreateApplicationAsync(dto, ct)).Id };

    [HttpPut("applications/{id:int}")]
    public Task<ChangeImpactResult> UpdateApplication(int id, ApplicationUpsert dto, CancellationToken ct) => catalog.UpdateApplicationAsync(id, dto, ct);

    [HttpDelete("applications/{id:int}")]
    public Task DeleteApplication(int id, CancellationToken ct) => catalog.DeleteApplicationAsync(id, ct);

    // ------------------------------ Resource tipi ------------------------------

    [HttpGet("/api/resource-types")]
    public async Task<object> ResourceTypes(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var meta = await db.ResourceTypes.AsNoTracking().ToDictionaryAsync(t => t.Id, t => t.Description, ct);
        return m.ResourceTypes.Values.OrderBy(t => t.Code, StringComparer.Ordinal).Select(t => new
        {
            t.Id, t.Code, t.Name, description = meta.GetValueOrDefault(t.Id), t.MatchesHttp, t.SupportsHierarchy, t.Color, t.IsActive,
            resourceCount = m.Resources.Values.Count(r => r.ResourceTypeId == t.Id),
            permissionCount = m.Permissions.Values.Count(p => p.Row.ResourceTypeId == t.Id)
        }).ToList();
    }

    [HttpPost("/api/resource-types")]
    public async Task<object> CreateResourceType(ResourceTypeUpsert dto, CancellationToken ct) => new { (await catalog.CreateResourceTypeAsync(dto, ct)).Id };

    [HttpPut("/api/resource-types/{id:int}")]
    public Task<ChangeImpactResult> UpdateResourceType(int id, ResourceTypeUpsert dto, CancellationToken ct) => catalog.UpdateResourceTypeAsync(id, dto, ct);

    [HttpDelete("/api/resource-types/{id:int}")]
    public Task DeleteResourceType(int id, CancellationToken ct) => catalog.DeleteResourceTypeAsync(id, ct);

    // ------------------------------ Scope ------------------------------

    [HttpGet("/api/scopes")]
    public async Task<object> Scopes([FromQuery] int? applicationId, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var meta = await db.Scopes.AsNoTracking().ToDictionaryAsync(s => s.Id, s => s.Description, ct);
        return m.Scopes.Values.Where(s => applicationId is null || s.ApplicationId == applicationId)
            .OrderBy(s => s.ApplicationId).ThenBy(s => s.Code, StringComparer.Ordinal).Select(s => new
            {
                s.Id, s.Code, s.Name, description = meta.GetValueOrDefault(s.Id), s.ApplicationId, application = m.Apps.GetValueOrDefault(s.ApplicationId)?.Code,
                resourceCount = m.ResourceScopes.Values.Count(x => x.Scope.Id == s.Id)
            }).ToList();
    }

    [HttpPost("/api/scopes")]
    public async Task<object> CreateScope(ScopeUpsert dto, CancellationToken ct) => new { (await catalog.CreateScopeAsync(dto, ct)).Id };

    [HttpPut("/api/scopes/{id:int}")]
    public Task UpdateScope(int id, ScopeUpsert dto, CancellationToken ct) => catalog.UpdateScopeAsync(id, dto, ct);

    [HttpDelete("/api/scopes/{id:int}")]
    public Task DeleteScope(int id, CancellationToken ct) => catalog.DeleteScopeAsync(id, ct);

    // ------------------------------ Resource ------------------------------

    /// <summary>Resource detayı: scope'lar (yetkiler) ve her birini koruyan permission'lar, URI eşlemeleri, üst/alt resource'lar.</summary>
    [HttpGet("/api/resources/{id:int}")]
    public async Task<object> Resource(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Resources.TryGetValue(id, out var r)) throw new NotFoundException("Resource", id);
        var now = clock.UtcNow;
        var meta = await db.Resources.AsNoTracking().Where(x => x.Id == id).Select(x => new
        {
            x.Description, x.OwnerTeamId, ownerTeam = x.OwnershipTeam != null ? x.OwnershipTeam.Name : null
        }).FirstAsync(ct);
        var type = m.ResourceTypes[r.ResourceTypeId];
        return new
        {
            resource = new
            {
                r.Id, r.Code, r.Name, r.IsActive, r.Order, r.ApplicationId, application = m.Apps[r.ApplicationId].Code, r.ExternalCode,
                path = m.PathOf(r.Id), r.ResourceTypeId, type = type.Code, typeName = type.Name,
                type.MatchesHttp, type.SupportsHierarchy, r.ParentId, parent = r.ParentId is { } p && m.Resources.TryGetValue(p, out var pr) ? pr.Code : null,
                meta.Description, meta.OwnerTeamId, meta.ownerTeam
            },
            scopes = m.ScopesOf(id).OrderBy(s => s.Scope.Code, StringComparer.Ordinal).Select(s => new
            {
                resourceScopeId = s.Id, scopeId = s.Scope.Id, s.Scope.Code, s.Scope.Name, s.Key, riskLevel = s.Row.RiskLevel,
                permissions = m.PermissionsFor(s.Id).Select(p => new { p.Row.Id, p.Row.Code, p.Row.Name, identity = m.HasIdentityPolicy(p) }).ToList(),
                holderCount = m.HoldersOf(s.Id, now).Count()
            }).ToList(),
            uris = m.UrisOf(id).OrderBy(u => u.Pattern, StringComparer.Ordinal).ThenBy(u => u.Method).Select(u => new
            {
                u.Id, u.Method, u.Pattern, u.ScopeId, scope = m.Scopes.GetValueOrDefault(u.ScopeId)?.Code
            }).ToList(),
            children = m.Resources.Values.Where(c => c.ParentId == id).OrderBy(c => c.Order).Select(c => new { c.Id, c.Code, c.Name, type = m.ResourceTypes[c.ResourceTypeId].Code }).ToList()
        };
    }

    [HttpPost("/api/resources")]
    public async Task<object> CreateResource(ResourceUpsert dto, CancellationToken ct)
    {
        var (r, impact) = await catalog.CreateResourceAsync(dto, ct);
        return new { r.Id, r.Code, impact };
    }

    [HttpPut("/api/resources/{id:int}")]
    public Task<ChangeImpactResult> UpdateResource(int id, ResourceUpsert dto, CancellationToken ct) => catalog.UpdateResourceAsync(id, dto, ct);

    [HttpDelete("/api/resources/{id:int}")]
    public Task DeleteResource(int id, CancellationToken ct) => catalog.DeleteResourceAsync(id, ct);

    [HttpPost("/api/resources/{id:int}/uris")]
    public async Task<object> AddUri(int id, UriUpsert dto, CancellationToken ct) => new { (await catalog.AddUriAsync(id, dto, ct)).Id };

    [HttpPut("/api/resource-uris/{id:int}")]
    public Task UpdateUri(int id, UriUpsert dto, CancellationToken ct) => catalog.UpdateUriAsync(id, dto, ct);

    [HttpDelete("/api/resource-uris/{id:int}")]
    public Task DeleteUri(int id, CancellationToken ct) => catalog.DeleteUriAsync(id, ct);

    /// <summary>URI eşleştirme testi: bu METHOD + path hangi yetkiye eşlenir? (karar vermez, katalog kontrolü)</summary>
    [HttpGet("/api/uri-match")]
    public async Task<object> MatchUri([FromQuery] string method, [FromQuery] string path, [FromQuery] string? application, [FromQuery] string? tenant, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var tenantId = tenant is not null && m.TenantByCode.TryGetValue(tenant, out var t) ? t.Id : m.Tenants.Keys.Min();
        var (match, ambiguous) = m.MatchHttp(application, method, path, tenantId);
        return new
        {
            matched = match is null ? null : new { match.Access.Key, match.Access.Name, uri = $"{match.Uri.Method} {match.Uri.Pattern}", application = match.Access.App.Code, resourceId = match.Access.Resource.Id },
            ambiguous = ambiguous.Select(a => new { a.Access.Key, uri = $"{a.Uri.Method} {a.Uri.Pattern}" }).ToList()
        };
    }
}

/// <summary>Yetkiler (resource:scope) — rol/grup/kullanıcıya permission'lar üzerinden verilen birim.</summary>
[ApiController]
[Route("api/resource-scopes")]
public sealed class ResourceScopesController(AuthorizationModelProvider models, IClock clock) : ControllerBase
{
    [HttpGet]
    public async Task<object> List([FromQuery] string? q, [FromQuery] int? applicationId, [FromQuery] string? type, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        return m.ResourceScopes.Values
            .Where(x => applicationId is null || x.App.Id == applicationId)
            .Where(x => type is null || x.Type.Code.Equals(type, StringComparison.OrdinalIgnoreCase))
            .Where(x => string.IsNullOrWhiteSpace(q) || x.Key.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Name.Contains(q, StringComparison.OrdinalIgnoreCase))
            .OrderBy(x => x.Key, StringComparer.Ordinal)
            .Select(x => new
            {
                x.Id, x.Key, x.Name, application = x.App.Code, resourceId = x.Resource.Id, resource = x.Resource.Code, resourceType = x.Type.Code, color = x.Type.Color,
                scope = x.Scope.Code, x.Path, riskLevel = x.Row.RiskLevel, x.IsActive,
                permissions = m.PermissionsFor(x.Id).Select(p => p.Row.Code).ToList(),
                uris = m.UrisOf(x.Resource.Id).Where(u => u.ScopeId == x.Scope.Id).Select(u => $"{u.Method} {u.Pattern}").ToList(),
                holderCount = m.HoldersOf(x.Id, now).Count()
            }).ToList();
    }

    /// <summary>"Kimde var, neden?" — etkin sahipler ve kaynak yolları.</summary>
    [HttpGet("{id:int}/holders")]
    public async Task<object> Holders(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.ResourceScopes.ContainsKey(id)) throw new NotFoundException("Yetki", id);
        return m.HoldersOf(id, clock.UtcNow).Select(h => new
        {
            userId = h.User.Id, h.User.UserName, h.User.FullName, tenant = m.TenantCode(h.User.TenantId), units = m.UnitCodesOf(h.User.Id).ToList(),
            h.Access.Conditional, h.Access.Conditions, sources = h.Access.Sources.Select(s => new { s.Permission, s.Policy, s.PolicyType, s.Path }).ToList()
        }).ToList();
    }
}

[ApiController]
[Route("api/ownership-teams")]
public sealed class OwnershipTeamsController(IYetkiDbContext db, OwnershipTeamService service) : ControllerBase
{
    [HttpGet]
    public async Task<object> List([FromQuery] int? tenantId, CancellationToken ct) =>
        await db.OwnershipTeams.AsNoTracking()
            .Where(t => tenantId == null || t.TenantId == tenantId)
            .OrderBy(t => t.Tenant.Code).ThenBy(t => t.Code)
            .Select(t => new
            {
                t.Id, t.TenantId, tenant = t.Tenant.Code, t.Code, t.Name, t.Description, t.IsActive,
                t.ParentId, parent = t.Parent != null ? t.Parent.Code : null,
                applicationCount = db.Applications.Count(a => a.OwnerTeamId == t.Id),
                resourceCount = db.Resources.Count(r => r.OwnerTeamId == t.Id),
                childTeamCount = db.OwnershipTeams.Count(c => c.ParentId == t.Id)
            }).ToListAsync(ct);

    [HttpPost]
    public async Task<object> Create(OwnershipTeamUpsert dto, CancellationToken ct) =>
        new { (await service.CreateAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task Update(int id, OwnershipTeamUpsert dto, CancellationToken ct) => service.UpdateAsync(id, dto, ct);

    [HttpDelete("{id:int}")]
    public Task Delete(int id, CancellationToken ct) => service.DeleteAsync(id, ct);
}

[ApiController]
[Route("api/clients")]
public sealed class ClientsController(AuthorizationModelProvider models, ClientService clients, ClientCredentialService credentials, IYetkiDbContext db, IClock clock) : ControllerBase
{
    [HttpGet]
    public async Task<object> List(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var meta = await db.Clients.AsNoTracking().ToDictionaryAsync(c => c.Id, c => c.Description, ct);
        var now = clock.UtcNow;
        var secrets = (await db.ClientSecrets.AsNoTracking().Select(s => new { s.ClientId, s.RevokedAt, s.ExpiresAt, s.LastUsedAt }).ToListAsync(ct))
            .GroupBy(s => s.ClientId).ToDictionary(g => g.Key, g => new
            {
                active = g.Count(s => s.RevokedAt == null && (s.ExpiresAt == null || s.ExpiresAt > now)),
                lastUsedAt = g.Max(s => s.LastUsedAt)
            });
        return m.ClientsById.Values.OrderBy(c => c.Id).Select(c => new
        {
            c.Id, c.ClientId, c.Name, c.Type, c.IsActive, description = meta.GetValueOrDefault(c.Id), c.TenantId, tenant = m.TenantCode(c.TenantId),
            application = c.ApplicationId is { } a && m.Apps.TryGetValue(a, out var app) ? app.Code : null, c.ApplicationId,
            serviceAccount = c.ServiceAccountUserId is { } u && m.Users.TryGetValue(u, out var user) ? user.UserName : null, c.ServiceAccountUserId,
            policies = m.PoliciesWithMember(PolicyType.Client, c.Id).Select(p => p.Row.Code).ToList(),
            queryApplicationIds = m.ScopeOf(c).Applications, queryApplications = m.ScopeOf(c).Applications.Select(a => m.Apps.GetValueOrDefault(a)?.Code).ToList(),
            queryTenantIds = m.ScopeOf(c).Tenants, queryTenants = m.ScopeOf(c).Tenants.Select(m.TenantCode).ToList(),
            onBehalfOfClientIds = m.ScopeOf(c).OnBehalfOf, onBehalfOf = m.ScopeOf(c).OnBehalfOf.Select(m.ClientCodeOf).ToList(),
            rateLimitPerMinute = m.ScopeOf(c).RateLimitPerMinute,
            activeSecrets = secrets.GetValueOrDefault(c.Id)?.active ?? 0, secretLastUsedAt = secrets.GetValueOrDefault(c.Id)?.lastUsedAt
        }).ToList();
    }

    // ------------------------------ Motor kimlik bilgileri (secret) ------------------------------

    [HttpGet("{id:int}/secrets")]
    public Task<IReadOnlyList<ClientSecretView>> Secrets(int id, CancellationToken ct) => credentials.ListAsync(id, ct);

    /// <summary>Yeni secret: düz metin sadece bu cevapta döner.</summary>
    [HttpPost("{id:int}/secrets")]
    public Task<CreatedClientSecret> CreateSecret(int id, ClientSecretCreate dto, CancellationToken ct) => credentials.CreateAsync(id, dto, ct);

    [HttpDelete("{id:int}/secrets/{secretId:int}")]
    public Task RevokeSecret(int id, int secretId, CancellationToken ct) => credentials.RevokeAsync(id, secretId, ct);

    [HttpPost]
    public async Task<object> Create(ClientUpsert dto, CancellationToken ct) => new { (await clients.CreateAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task Update(int id, ClientUpsert dto, CancellationToken ct) => clients.UpdateAsync(id, dto, ct);

    [HttpDelete("{id:int}")]
    public Task Delete(int id, CancellationToken ct) => clients.DeleteAsync(id, ct);
}
