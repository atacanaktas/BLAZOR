using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Changes;
using Yetki.Application.Definitions;
using Yetki.Application.Evaluation;
using Yetki.Application.Governance;
using Yetki.Application.Model;
using Yetki.Application.Simulation;
using Yetki.Domain.Common;
using Yetki.Infrastructure.Services;

namespace Yetki.Api.Controllers;

public sealed record ViolationUpdate(ViolationStatus Status, string? Note);

[ApiController]
[Route("api/sod")]
public sealed class SodController(IYetkiDbContext db, GovernanceService governance, SodService sod, AuthorizationModelProvider models) : ControllerBase
{
    [HttpGet("rules")]
    public async Task<object> Rules(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var rules = await db.SodRules.AsNoTracking().Include(r => r.Members).OrderBy(r => r.Code).ToListAsync(ct);
        var open = await db.SodViolations.AsNoTracking().Where(v => v.Status != ViolationStatus.Resolved).GroupBy(v => v.SodRuleId)
            .Select(g => new { g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.Count, ct);
        return rules.Select(r => new
        {
            r.Id, r.Code, r.Name, r.Description, r.Severity, r.Enforcement, r.IsActive, openViolations = open.GetValueOrDefault(r.Id),
            members = SodService.Snapshot(m, r.Id, r.Code, r.Name, r.Severity, r.Enforcement, r.Members.Select(x => (x.MemberType, x.MemberId))).Members
        }).ToList();
    }

    [HttpPost("rules")]
    public Task<SodRuleCreated> Create(SodRuleUpsert dto, CancellationToken ct) => governance.CreateSodRuleAsync(dto, ct);

    [HttpPut("rules/{id:int}")]
    public Task Update(int id, SodRuleUpsert dto, CancellationToken ct) => governance.UpdateSodRuleAsync(id, dto, ct);

    [HttpGet("violations")]
    public async Task<object> Violations([FromQuery] bool includeResolved, CancellationToken ct)
    {
        var model = await models.GetCurrentAsync(ct);
        var rows = await db.SodViolations.AsNoTracking().Where(v => includeResolved || v.Status != ViolationStatus.Resolved).OrderByDescending(v => v.DetectedAt)
            .Select(v => new
            {
                v.Id, rule = v.SodRule.Code, ruleName = v.SodRule.Name, v.SodRule.Severity, v.SodRule.Enforcement, v.UserId,
                v.Status, v.DetectedBy, v.DetectedAt, v.LastSeenAt, v.ClosedAt, v.ClosedBy, v.Note, v.Details
            }).ToListAsync(ct);

        return rows.Select(v => new
        {
            v.Id, v.rule, v.ruleName, v.Severity, v.Enforcement, v.UserId,
            UserName = model.Users.GetValueOrDefault(v.UserId)?.UserName,
            FullName = model.Users.GetValueOrDefault(v.UserId)?.FullName,
            v.Status, v.DetectedBy, v.DetectedAt, v.LastSeenAt, v.ClosedAt, v.ClosedBy, v.Note, v.Details
        }).ToList();
    }

    [HttpPut("violations/{id:int}")]
    public Task UpdateViolation(int id, ViolationUpdate r, CancellationToken ct) => governance.UpdateViolationAsync(id, r.Status, r.Note, ct);

    [HttpPost("scan")]
    public Task<SodScanResult> Scan(CancellationToken ct) => sod.ScanAsync(ct);
}

/// <summary>What-If: aynı model kurucusu ve aynı karar motoruyla simülasyon.</summary>
[ApiController]
[Route("api/simulation")]
public sealed class SimulationController(SimulationService simulation) : ControllerBase
{
    [HttpPost("changes")]
    public Task<ChangeImpactResult> Changes(AuthorizationChangeSet changes, CancellationToken ct) => simulation.SimulateChangesAsync(changes, ct);

    [HttpPost("evaluate")]
    public Task<AuthorizationDecision> Evaluate(SimulatedEvaluateRequest request, CancellationToken ct) => simulation.SimulateEvaluateAsync(request, ct);

    [HttpPost("policy-impact")]
    public Task<PolicyImpactResult> PolicyImpact(PolicyImpactRequest request, CancellationToken ct) => simulation.PolicyImpactAsync(request, ct);

    [HttpPost("sod-rule")]
    public Task<IReadOnlyList<SodUserConflicts>> SodRule(SodRuleImpactRequest request, CancellationToken ct) => simulation.SodRuleImpactAsync(request, ct);
}

[ApiController]
[Route("api")]
public sealed class OperationsController(IYetkiDbContext db, AuthorizationModelProvider models, OutboxProcessor outbox, IClock clock) : ControllerBase
{
    [HttpGet("dashboard")]
    public async Task<object> Dashboard(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var since = clock.UtcNow.AddHours(-24);
        var decisions = await db.AuditLogs.AsNoTracking().Where(a => a.Category == AuditCategory.AuthorizationDecision && a.Timestamp >= since)
            .GroupBy(a => a.Decision).Select(g => new { decision = g.Key, count = g.Count() }).ToListAsync(ct);
        return new
        {
            modelVersion = m.Version, modelBuiltAt = m.BuiltAt,
            counts = new
            {
                tenants = m.Tenants.Count, units = m.Units.Count, users = m.Users.Count, roles = m.Roles.Count, groups = m.Groups.Count,
                applications = m.Apps.Count, resourceTypes = m.ResourceTypes.Count, resources = m.Resources.Count,
                scopes = m.Scopes.Count, resourceScopes = m.ResourceScopes.Count, uris = m.Data.Uris.Count,
                unprotectedAccesses = m.ResourceScopes.Keys.Count(id => m.PermissionsFor(id).Count == 0),
                permissions = m.Permissions.Count, permissionsWithoutIdentity = m.Permissions.Values.Count(p => p.Row.IsActive && !m.HasIdentityPolicy(p)),
                clients = m.ClientsById.Count, policies = m.Policies.Count, reportOnlyPolicies = m.Policies.Values.Count(p => p.Row.Mode == PolicyMode.ReportOnly),
                sharedConditions = m.Data.SharedConditions.Count,
                openViolations = await db.SodViolations.CountAsync(v => v.Status != ViolationStatus.Resolved, ct),
                pendingEvents = await db.OutboxEvents.CountAsync(e => e.Status == OutboxStatus.Pending, ct)
            },
            decisionsLast24h = decisions,
            recentDecisions = await db.AuditLogs.AsNoTracking().Where(a => a.Category == AuditCategory.AuthorizationDecision)
                .OrderByDescending(a => a.Timestamp).Take(10)
                .Select(a => new { a.Id, a.Timestamp, a.SubjectUserName, a.ClientId, a.PermissionCode, a.Decision, a.ReasonCode }).ToListAsync(ct),
            recentChanges = await db.AuditLogs.AsNoTracking().Where(a => a.Category == AuditCategory.Management)
                .OrderByDescending(a => a.Timestamp).Take(10).Select(a => new { a.Id, a.Timestamp, a.Actor, a.Action, a.Summary }).ToListAsync(ct)
        };
    }

    [HttpGet("version")]
    public async Task<object> Version(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return new { modelVersion = m.Version, builtAt = m.BuiltAt, pendingEvents = await db.OutboxEvents.CountAsync(e => e.Status == OutboxStatus.Pending, ct) };
    }

    [HttpGet("events")]
    public async Task<object> Events([FromQuery] int take = 200, CancellationToken ct = default) =>
        await db.OutboxEvents.AsNoTracking().OrderByDescending(e => e.OccurredAt).Take(Math.Clamp(take, 1, 1000))
            .Select(e => new { e.Id, e.EventType, e.AggregateType, e.AggregateId, e.OccurredAt, e.Actor, e.Status, e.Attempts, e.ProcessedAt, e.Error, e.PayloadJson })
            .ToListAsync(ct);

    [HttpPost("events/process")]
    public async Task<object> Process(CancellationToken ct) => new { processed = await outbox.ProcessBatchAsync(ct) };

    [HttpGet("provisioning")]
    public async Task<object> Provisioning(CancellationToken ct) =>
        await db.ProvisioningActions.AsNoTracking().OrderByDescending(p => p.CreatedAt).Take(300).ToListAsync(ct);

    [HttpGet("audit")]
    public async Task<object> Audit([FromQuery] AuditCategory? category, [FromQuery] string? user, [FromQuery] string? permission, [FromQuery] string? q,
        [FromQuery] int take = 200, CancellationToken ct = default)
    {
        var query = db.AuditLogs.AsNoTracking().AsQueryable();
        if (category is not null) query = query.Where(a => a.Category == category);
        if (!string.IsNullOrWhiteSpace(user)) query = query.Where(a => a.SubjectUserName == user || a.Actor == user);
        if (!string.IsNullOrWhiteSpace(permission)) query = query.Where(a => a.PermissionCode == permission);
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(a => (a.Summary ?? "").Contains(q) || a.Action.Contains(q));
        return await query.OrderByDescending(a => a.Timestamp).Take(Math.Clamp(take, 1, 1000))
            .Select(a => new { a.Id, a.Timestamp, a.Category, a.Actor, a.Action, a.EntityType, a.EntityId, a.SubjectUserName, a.ClientId, a.PermissionCode, a.Decision, a.ReasonCode, a.Summary })
            .ToListAsync(ct);
    }

    [HttpGet("audit/{id:guid}")]
    public async Task<object> AuditDetail(Guid id, CancellationToken ct) =>
        await db.AuditLogs.AsNoTracking().FirstOrDefaultAsync(a => a.Id == id, ct) ?? throw new NotFoundException("Audit", id);

    /// <summary>
    /// UI seçim listeleri: users, roles, groups, tenants, units, applications, teams, nodes, resource-types, resources, scopes,
    /// resource-scopes, clients, policies, permissions, shared-conditions, external-permissions. group: gruplama başlığı.
    /// </summary>
    [HttpGet("options/{kind}")]
    public async Task<object> Options(string kind, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return kind switch
        {
            "users" => m.Users.Values.OrderBy(u => u.UserName).Select(u => O(u.Id, $"{u.UserName} — {u.FullName}", m.TenantCode(u.TenantId), u.UserName)).ToList(),
            "roles" => m.Roles.Values.OrderBy(r => r.Code).Select(r => O(r.Id, $"{r.Code} — {r.Name}", m.TenantCode(r.TenantId), r.Code)).ToList(),
            "groups" => m.Groups.Values.OrderBy(g => g.Code).Select(g => O(g.Id, $"{g.Code} — {g.Name}", m.TenantCode(g.TenantId), g.Code)).ToList(),
            "tenants" => m.Tenants.Values.OrderBy(o => o.Id).Select(o => O(o.Id, $"{o.Code} — {o.Name}", null, o.Code)).ToList(),
            "units" => m.Units.Values.OrderBy(u => u.TenantId).ThenBy(u => u.Code).Select(u => O(u.Id, $"{u.Code} — {u.Name}", m.TenantCode(u.TenantId), u.Code)).ToList(),
            "applications" => m.Apps.Values.OrderBy(a => a.Id).Select(a => O(a.Id, $"{a.Code} — {a.Name}", m.TenantCode(a.TenantId), a.Code)).ToList(),
            "teams" => await db.OwnershipTeams.AsNoTracking().Where(t => t.IsActive).OrderBy(t => t.Tenant.Code).ThenBy(t => t.Code)
                .Select(t => O(t.Id, t.Code + " — " + t.Name, t.Tenant.Code, t.Code)).ToListAsync(ct),
            "resource-types" => m.ResourceTypes.Values.OrderBy(t => t.Code).Select(t => O(t.Id, $"{t.Code} — {t.Name}", t.MatchesHttp ? "HTTP" : "UI / mantıksal", t.Code)).ToList(),
            "resources" => m.Resources.Values.OrderBy(r => r.Code).Select(r => O(r.Id, $"{r.Code} — {r.Name} ({m.ResourceTypes[r.ResourceTypeId].Code})", m.Apps[r.ApplicationId].Code, r.Code)).ToList(),
            "scopes" => m.Scopes.Values.OrderBy(s => s.ApplicationId).ThenBy(s => s.Code).Select(s => O(s.Id, $"{s.Code} — {s.Name}", m.Apps.GetValueOrDefault(s.ApplicationId)?.Code, s.Code)).ToList(),
            "resource-scopes" => m.ResourceScopes.Values.OrderBy(x => x.Key).Select(x => O(x.Id, $"{x.Key} — {x.Name}", x.App.Code, x.Key)).ToList(),
            "clients" => m.ClientsById.Values.OrderBy(c => c.Id).Select(c => O(c.Id, $"{c.ClientId} — {c.Name} ({m.TenantCode(c.TenantId)})", m.TenantCode(c.TenantId), c.ClientId)).ToList(),
            "policies" => m.Policies.Values.OrderBy(p => p.Row.Code).Select(p => O(p.Row.Id, $"{p.Row.Code} — {p.Row.Name}", p.Row.Type.ToString(), p.Row.Code)).ToList(),
            "permissions" => m.Permissions.Values.OrderBy(p => p.Row.Code).Select(p => O(p.Row.Id, $"{p.Row.Code} — {p.Row.Name}", p.App.Code, p.Row.Code)).ToList(),
            "shared-conditions" => m.Data.SharedConditions.OrderBy(s => s.Code).Select(s => O(s.Id, s.Code, s.IsActive ? null : "pasif", s.Code)).ToList(),
            "external-permissions" => await db.ExternalPermissions.AsNoTracking().OrderBy(p => p.Code)
                .Select(p => O(p.Id, p.ExternalSystem.Code + ":" + p.Code + " — " + p.Name, p.ExternalSystem.Code, p.Code)).ToListAsync(ct),
            _ => throw new NotFoundException("Seçim listesi", kind)
        };
    }

    private static object O(int value, string label, string? group, string code) => new { value, label, group, code };
}
