using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Yetki.Infrastructure.Services;

namespace Yetki.Infrastructure.Persistence;

/// <summary>
/// `dotnet ef migrations add ...` için tasarım zamanı fabrikası (uygulamayı çalıştırmadan DbContext kurar).
/// Migration'lar SQLite içindir; SQL Server'a geçişte ayrı bir migration seti üretilmelidir.
/// </summary>
public sealed class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<YetkiDbContext>
{
    public YetkiDbContext CreateDbContext(string[] args) =>
        new(new DbContextOptionsBuilder<YetkiDbContext>().UseSqlite("Data Source=design-time.db").Options,
            new SystemClock(), new SystemActor("design-time"), new InProcessAuthorizationVersion());
}
