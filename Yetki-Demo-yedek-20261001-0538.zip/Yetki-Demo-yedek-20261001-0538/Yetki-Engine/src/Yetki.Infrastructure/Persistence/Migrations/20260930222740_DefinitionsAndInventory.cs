﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class DefinitionsAndInventory : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Katalog seviyeleri kalkıyor (gruplama artık URL / üst-alt ilişkisinden türetiliyor).
            // Resource'ların seviye bağı önce boşaltılır; aksi halde tablo silinirken yabancı anahtar ihlali olur.
            migrationBuilder.Sql("UPDATE \"Resources\" SET \"CatalogNodeId\" = NULL;");

            migrationBuilder.DropForeignKey(
                name: "FK_Resources_CatalogNodes_CatalogNodeId",
                table: "Resources");

            migrationBuilder.DropTable(
                name: "CatalogNodes");

            migrationBuilder.DropIndex(
                name: "IX_Resources_CatalogNodeId",
                table: "Resources");

            migrationBuilder.DropColumn(
                name: "CatalogNodeId",
                table: "Resources");

            migrationBuilder.AddColumn<string>(
                name: "ExternalCode",
                table: "Resources",
                type: "TEXT",
                maxLength: 64,
                nullable: true);

            migrationBuilder.CreateTable(
                name: "InventorySnapshots",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    ApplicationId = table.Column<int>(type: "INTEGER", nullable: false),
                    Kind = table.Column<int>(type: "INTEGER", nullable: false),
                    Source = table.Column<string>(type: "TEXT", maxLength: 128, nullable: false),
                    ImportedAt = table.Column<DateTime>(type: "TEXT", nullable: false),
                    ImportedBy = table.Column<string>(type: "TEXT", maxLength: 64, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InventorySnapshots", x => x.Id);
                    table.ForeignKey(
                        name: "FK_InventorySnapshots_Applications_ApplicationId",
                        column: x => x.ApplicationId,
                        principalTable: "Applications",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "InventoryItems",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    SnapshotId = table.Column<int>(type: "INTEGER", nullable: false),
                    Method = table.Column<string>(type: "TEXT", maxLength: 8, nullable: true),
                    Path = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    Code = table.Column<string>(type: "TEXT", maxLength: 64, nullable: true),
                    Name = table.Column<string>(type: "TEXT", maxLength: 160, nullable: true),
                    ParentCode = table.Column<string>(type: "TEXT", maxLength: 64, nullable: true),
                    ElementType = table.Column<string>(type: "TEXT", maxLength: 32, nullable: true),
                    Description = table.Column<string>(type: "TEXT", maxLength: 512, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InventoryItems", x => x.Id);
                    table.ForeignKey(
                        name: "FK_InventoryItems_InventorySnapshots_SnapshotId",
                        column: x => x.SnapshotId,
                        principalTable: "InventorySnapshots",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Resources_ApplicationId_ExternalCode",
                table: "Resources",
                columns: new[] { "ApplicationId", "ExternalCode" });

            migrationBuilder.CreateIndex(
                name: "IX_InventoryItems_SnapshotId",
                table: "InventoryItems",
                column: "SnapshotId");

            migrationBuilder.CreateIndex(
                name: "IX_InventorySnapshots_ApplicationId_Kind",
                table: "InventorySnapshots",
                columns: new[] { "ApplicationId", "Kind" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "InventoryItems");

            migrationBuilder.DropTable(
                name: "InventorySnapshots");

            migrationBuilder.DropIndex(
                name: "IX_Resources_ApplicationId_ExternalCode",
                table: "Resources");

            migrationBuilder.DropColumn(
                name: "ExternalCode",
                table: "Resources");

            migrationBuilder.AddColumn<int>(
                name: "CatalogNodeId",
                table: "Resources",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "CatalogNodes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    ApplicationId = table.Column<int>(type: "INTEGER", nullable: false),
                    OwnerTeamId = table.Column<int>(type: "INTEGER", nullable: true),
                    ParentId = table.Column<int>(type: "INTEGER", nullable: true),
                    TenantId = table.Column<int>(type: "INTEGER", nullable: false),
                    Code = table.Column<string>(type: "TEXT", maxLength: 32, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "TEXT", nullable: false),
                    CreatedBy = table.Column<string>(type: "TEXT", maxLength: 64, nullable: false),
                    Description = table.Column<string>(type: "TEXT", nullable: true),
                    Name = table.Column<string>(type: "TEXT", maxLength: 128, nullable: false),
                    OwnerUserId = table.Column<int>(type: "INTEGER", nullable: true),
                    Path = table.Column<string>(type: "TEXT", maxLength: 256, nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "TEXT", nullable: true),
                    UpdatedBy = table.Column<string>(type: "TEXT", maxLength: 64, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CatalogNodes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CatalogNodes_Applications_ApplicationId",
                        column: x => x.ApplicationId,
                        principalTable: "Applications",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CatalogNodes_CatalogNodes_ParentId",
                        column: x => x.ParentId,
                        principalTable: "CatalogNodes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CatalogNodes_OwnershipTeams_OwnerTeamId",
                        column: x => x.OwnerTeamId,
                        principalTable: "OwnershipTeams",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CatalogNodes_Tenants_TenantId",
                        column: x => x.TenantId,
                        principalTable: "Tenants",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Resources_CatalogNodeId",
                table: "Resources",
                column: "CatalogNodeId");

            migrationBuilder.CreateIndex(
                name: "IX_CatalogNodes_ApplicationId_ParentId_Code",
                table: "CatalogNodes",
                columns: new[] { "ApplicationId", "ParentId", "Code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_CatalogNodes_OwnerTeamId",
                table: "CatalogNodes",
                column: "OwnerTeamId");

            migrationBuilder.CreateIndex(
                name: "IX_CatalogNodes_ParentId",
                table: "CatalogNodes",
                column: "ParentId");

            migrationBuilder.CreateIndex(
                name: "IX_CatalogNodes_Path",
                table: "CatalogNodes",
                column: "Path",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_CatalogNodes_TenantId",
                table: "CatalogNodes",
                column: "TenantId");

            migrationBuilder.AddForeignKey(
                name: "FK_Resources_CatalogNodes_CatalogNodeId",
                table: "Resources",
                column: "CatalogNodeId",
                principalTable: "CatalogNodes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
