using Yetki.Application.Identity;
using Yetki.Infrastructure.Identity;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Yetki.Application;
using Yetki.Application.Abstractions;
using Yetki.Application.Evaluation;
using Yetki.Application.Events;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Infrastructure.Persistence;
using Yetki.Infrastructure.Services;

namespace Yetki.Infrastructure;

public static class DependencyInjection
{
    /// <summary>
    /// Persistence:Provider
    ///  - "Sqlite" (varsayılan): ConnectionStrings:Yetki (ör. "Data Source=yetki.db"). Göreli yol <paramref name="basePath"/>'e göre çözülür.
    ///  - "InMemory": testler için.
    /// SQL Server'a geçiş: Microsoft.EntityFrameworkCore.SqlServer paketi + aşağıdaki "SqlServer" dalı + SQL Server için ayrı migration seti.
    /// </summary>
    public static IServiceCollection AddYetkiInfrastructure(this IServiceCollection services, IConfiguration config, string? basePath = null)
    {
        services.AddYetkiApplication();

        var provider = config["Persistence:Provider"] ?? "Sqlite";
        services.AddDbContext<YetkiDbContext>(options =>
        {
            switch (provider)
            {
                case "Sqlite":
                    options.UseSqlite(ResolveSqlite(config.GetConnectionString("Yetki") ?? "Data Source=yetki.db", basePath));
                    break;
                case "InMemory":
                    options.UseInMemoryDatabase(config["Persistence:InMemoryDatabaseName"] ?? "YetkiDb")
                           .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning));
                    break;
                // case "SqlServer":
                //     options.UseSqlServer(config.GetConnectionString("Yetki"), sql => sql.EnableRetryOnFailure());
                //     break;
                default:
                    throw new InvalidOperationException($"Desteklenmeyen persistence provider: {provider}");
            }
        });
        services.AddScoped<IYetkiDbContext>(sp => sp.GetRequiredService<YetkiDbContext>());

        // The single composition point for identity-source integration.
        switch (config["Identity:Provider"] ?? "LocalDb")
        {
            case "LocalDb": services.AddScoped<IIdentityProvider, LocalIdentityProvider>(); break;
            default: throw new InvalidOperationException("Unsupported identity provider: " + config["Identity:Provider"]);
        }
        services.AddSingleton<IClock, SystemClock>();
        services.AddSingleton<IAuthorizationVersion, InProcessAuthorizationVersion>();
        services.Configure<AuthorizationEngineOptions>(o => config.GetSection("AuthorizationEngine").Bind(o));
        services.AddScoped<IProvisioningAdapter, DummyProvisioningAdapter>();
        services.AddScoped<IOutboxEventHandler, LoggingEventHandler>();

        services.AddSingleton<OutboxProcessor>();
        services.AddHostedService(sp => sp.GetRequiredService<OutboxProcessor>());
        return services;
    }

    /// <summary>"Data Source=yetki.db" gibi göreli yolları verilen klasöre göre mutlak yapar (çalışma dizininden bağımsız).</summary>
    public static string ResolveSqlite(string connectionString, string? basePath)
    {
        var b = new SqliteConnectionStringBuilder(connectionString);
        if (basePath is not null && !string.IsNullOrWhiteSpace(b.DataSource) && b.DataSource != ":memory:" && !Path.IsPathRooted(b.DataSource))
            b.DataSource = Path.GetFullPath(Path.Combine(basePath, b.DataSource));
        return b.ToString();
    }

    /// <summary>
    /// Veritabanını hazırlar: ilişkisel sağlayıcıda bekleyen migration'ları uygular (mevcut veri korunur; dosya yoksa oluşturulur),
    /// InMemory'de şemayı kurar; ardından condition tipi kataloğunu koddaki handler'larla senkronize eder. SEED YOKTUR:
    /// örnek veri ayrı araçla (tools/Yetki.SampleData) yedek.db olarak üretilir.
    /// </summary>
    public static async Task InitializeYetkiDatabaseAsync(this IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var sp = scope.ServiceProvider;
        var db = sp.GetRequiredService<YetkiDbContext>();
        if (db.Database.IsRelational())
        {
            await db.Database.MigrateAsync();
            // EF Core yeni SQLite dosyasını WAL moduna alır (-wal/-shm yan dosyaları). Tek dosya modu (DELETE):
            // yedek.db → yetki.db kopyalamak güvenli olur, geride eski WAL kalıp veriyi bozamaz.
            if (db.Database.ProviderName == "Microsoft.EntityFrameworkCore.Sqlite")
                await db.Database.ExecuteSqlRawAsync("PRAGMA journal_mode=DELETE;");
        }
        else await db.Database.EnsureCreatedAsync();

        await sp.GetRequiredService<ConditionTypeCatalogSynchronizer>().SyncAsync();

        sp.GetRequiredService<ILoggerFactory>().CreateLogger("Yetki")
            .LogInformation("Yetki veritabanı hazır ({Provider}: {Source}).", db.Database.ProviderName, db.Database.IsRelational() ? db.Database.GetDbConnection().DataSource : "in-memory");
    }
}
