﻿using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Identity;
using Yetki.Domain.Identity;
using Yetki.Domain.Rbac;

namespace Yetki.Infrastructure.Identity;

/// <summary>All physical User/Role/UserRole access is isolated here. Staged writes share the audit/outbox DbContext.</summary>
public sealed class LocalIdentityProvider(IYetkiDbContext db, IAuthorizationVersion version) : IIdentityProvider
{
    public string Name => "LocalDb";
    public IdentityCapabilities Capabilities => new(true, true, true);
    private static readonly Expression<Func<User, IdentityUser>> UserProjection = u => new(u.Id, u.TenantId, u.UserName, u.FullName, u.Email, u.Title, u.EmployeeNo, u.Kind, u.IsActive, u.IsOnLeave, u.CashWithdrawalLimit, u.CustomerNo);
    private static readonly Expression<Func<Role, IdentityRole>> RoleProjection = r => new(r.Id, r.TenantId, r.Code, r.Name, r.Description, r.IsInheritable, r.IsActive);
    private static readonly Expression<Func<UserRole, IdentityUserRole>> AssignmentProjection = x => new(x.UserId, x.RoleId, x.ValidFrom, x.ValidUntil, x.Reason, x.AssignedAt, x.AssignedBy);
    public Task<string> GetRevisionAsync(CancellationToken ct) { ct.ThrowIfCancellationRequested(); return Task.FromResult($"LocalDb:{version.Current}"); }
    public async Task<IdentitySnapshot> ReadSnapshotAsync(CancellationToken ct) => new(
        await db.Users.AsNoTracking().Select(UserProjection).ToListAsync(ct),
        await db.Roles.AsNoTracking().Select(RoleProjection).ToListAsync(ct),
        await db.UserRoles.AsNoTracking().Select(AssignmentProjection).ToListAsync(ct));
    public Task<IdentityUser?> GetUserAsync(int id, CancellationToken ct) => db.Users.AsNoTracking().Where(x => x.Id == id).Select(UserProjection).FirstOrDefaultAsync(ct);
    public Task<IdentityRole?> GetRoleAsync(int id, CancellationToken ct) => db.Roles.AsNoTracking().Where(x => x.Id == id).Select(RoleProjection).FirstOrDefaultAsync(ct);
    public Task<IdentityUserRole?> GetUserRoleAsync(int userId, int roleId, CancellationToken ct) => db.UserRoles.AsNoTracking().Where(x => x.UserId == userId && x.RoleId == roleId).Select(AssignmentProjection).FirstOrDefaultAsync(ct);
    public async Task<IReadOnlyList<IdentityUserRole>> GetUserRolesAsync(int userId, CancellationToken ct) => await db.UserRoles.AsNoTracking().Where(x => x.UserId == userId).Select(AssignmentProjection).ToListAsync(ct);
    public Task<bool> UserNameExistsAsync(string name, CancellationToken ct) => db.Users.AnyAsync(x => x.UserName == name, ct);
    public Task<bool> RoleCodeExistsAsync(string code, CancellationToken ct) => db.Roles.AnyAsync(x => x.Code == code, ct);
    public async Task<IdentityPage<IdentityUser>> SearchUsersAsync(IdentityUserQuery request, CancellationToken ct)
    {
        if (request.Page < 1 || request.Page > 100000 || request.PageSize < 1 || request.PageSize > 48 || request.Search?.Length > 200) throw new ValidationException("Invalid identity query.");
        var query = db.Users.AsNoTracking().Where(x => request.TenantId == null || x.TenantId == request.TenantId);
        if (!string.IsNullOrWhiteSpace(request.Search)) { var term = request.Search.Trim().ToLower(); query = query.Where(x => x.UserName.ToLower().Contains(term) || x.FullName.ToLower().Contains(term)); }
        var total = await query.CountAsync(ct);
        var page = Math.Min(request.Page, Math.Max(1, (int)Math.Ceiling(total / (double)request.PageSize)));
        return new(await query.OrderBy(x => x.UserName).ThenBy(x => x.Id).Skip((page - 1) * request.PageSize).Take(request.PageSize).Select(UserProjection).ToListAsync(ct), total, page, request.PageSize);
    }
    public async Task<IdentityUser> CreateUserAsync(IdentityUser value, int? primaryOrgUnitId, CancellationToken ct)
    {
        var user = new User { TenantId = value.TenantId, UserName = value.UserName };
        Copy(value, user);
        if (primaryOrgUnitId is { } unitId) user.OrgUnits.Add(new UserOrgUnit { OrgUnitId = unitId, IsPrimary = true });
        db.Users.Add(user);
        await db.SaveChangesAsync(ct);
        return value with { Id = user.Id };
    }
    public async Task<IdentityRole> CreateRoleAsync(IdentityRole value, CancellationToken ct)
    {
        var role = new Role { TenantId = value.TenantId, Code = value.Code, Name = value.Name, Description = value.Description, IsActive = value.IsActive, IsInheritable = value.IsInheritable };
        db.Roles.Add(role); await db.SaveChangesAsync(ct); return value with { Id = role.Id };
    }
    public async Task StageUserUpdateAsync(IdentityUser user, CancellationToken ct) => Copy(user, await db.Users.FindAsync([user.Id], ct) ?? throw new NotFoundException("User", user.Id));
    public async Task StageRoleUpdateAsync(IdentityRole value, CancellationToken ct)
    {
        var role = await db.Roles.FindAsync([value.Id], ct) ?? throw new NotFoundException("Role", value.Id);
        role.Name = value.Name; role.Description = value.Description; role.IsInheritable = value.IsInheritable; role.IsActive = value.IsActive;
    }
    public Task StageAssignRoleAsync(IdentityUserRole value, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        db.UserRoles.Add(new UserRole { UserId = value.UserId, RoleId = value.RoleId, ValidFrom = value.ValidFrom, ValidUntil = value.ValidUntil, Reason = value.Reason, AssignedAt = value.AssignedAt, AssignedBy = value.AssignedBy });
        return Task.CompletedTask;
    }
    public async Task StageRevokeRoleAsync(int userId, int roleId, CancellationToken ct)
    {
        var row = await db.UserRoles.FirstOrDefaultAsync(x => x.UserId == userId && x.RoleId == roleId, ct) ?? throw new NotFoundException("UserRole", $"{userId}/{roleId}");
        db.UserRoles.Remove(row);
    }
    private static void Copy(IdentityUser value, User user)
    {
        user.FullName = value.FullName; user.Email = value.Email; user.Title = value.Title; user.EmployeeNo = value.EmployeeNo;
        user.Kind = value.Kind; user.IsActive = value.IsActive; user.IsOnLeave = value.IsOnLeave;
        user.CashWithdrawalLimit = value.CashWithdrawalLimit; user.CustomerNo = value.CustomerNo;
    }
}
