using Yetki.Application.Abstractions;
using Yetki.Application.Changes;
using Yetki.Application.Evaluation;
using Yetki.Application.Governance;
using Yetki.Application.Model;
using Yetki.Domain.Common;

namespace Yetki.Application.Simulation;

public sealed class SimulatedEvaluateRequest
{
    public AuthorizationRequest Request { get; set; } = new();
    public AuthorizationChangeSet? Changes { get; set; }
    public PolicyChangeSet? PolicyChanges { get; set; }
    /// <summary>Kararın hangi an için simüle edileceği (UTC). Boşsa şimdi.</summary>
    public DateTime? AsOfUtc { get; set; }
}

public sealed class SodRuleImpactRequest
{
    public string Code { get; set; } = "DRAFT";
    public SodEnforcement Enforcement { get; set; } = SodEnforcement.Block;
    public List<int> ResourceScopeIds { get; set; } = new();
    public List<int> RoleIds { get; set; } = new();
}

/// <summary>What-If. KENDİ karar mantığı yoktur: aynı model kurucusu, aynı evaluator, aynı etki analizi.</summary>
public sealed class SimulationService(
    AuthorizationChangeService changes,
    AuthorizationEvaluator evaluator,
    AuthorizationModelProvider models,
    PolicyImpactService policyImpact,
    SodService sod,
    ICurrentActor actor)
{
    public Task<ChangeImpactResult> SimulateChangesAsync(AuthorizationChangeSet changeSet, CancellationToken ct) =>
        changes.AnalyzeAsync(changeSet, dryRun: true, ct);

    public async Task<AuthorizationDecision> SimulateEvaluateAsync(SimulatedEvaluateRequest request, CancellationToken ct)
    {
        var model = await models.BuildWhatIfAsync(request.Changes, request.PolicyChanges, ct);
        return await evaluator.EvaluateAsync(request.Request, new EvaluationOptions
        {
            Model = model, AsOfUtc = request.AsOfUtc, IsSimulation = true, WriteAudit = true, Actor = actor.Name
        }, ct);
    }

    public Task<PolicyImpactResult> PolicyImpactAsync(PolicyImpactRequest request, CancellationToken ct) => policyImpact.AnalyzeAsync(request, ct);

    public async Task<IReadOnlyList<SodUserConflicts>> SodRuleImpactAsync(SodRuleImpactRequest request, CancellationToken ct)
    {
        var members = request.ResourceScopeIds.Select(id => (SodMemberType.ResourceScope, id)).Concat(request.RoleIds.Select(id => (SodMemberType.Role, id))).ToList();
        if (members.Count < 2) throw new ValidationException("SoD kuralı en az 2 üye içermelidir.");
        var model = await models.GetCurrentAsync(ct);
        return await sod.SimulateRuleAsync(SodService.Snapshot(model, 0, request.Code, request.Code, Severity.High, request.Enforcement, members), ct);
    }
}
