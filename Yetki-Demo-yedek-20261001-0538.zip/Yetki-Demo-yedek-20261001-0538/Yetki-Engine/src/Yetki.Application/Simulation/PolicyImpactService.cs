using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Context;
using Yetki.Application.Definitions;
using Yetki.Application.Evaluation;
using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Domain.Common;
using Yetki.Domain.Governance;

namespace Yetki.Application.Simulation;

public sealed class ImpactScenario
{
    public string Name { get; set; } = "Senaryo";
    /// <summary>Örnek bağlam. "@userBranch" değeri her kullanıcının kendi (ilk) birim koduyla değiştirilir.</summary>
    public Dictionary<string, string?> Context { get; set; } = new();
    public string? Client { get; set; }
}

public sealed class PolicyImpactRequest
{
    public PolicyChangeSet Changes { get; set; } = new();
    public List<ImpactScenario> Scenarios { get; set; } = new();
    public DateTime? AsOfUtc { get; set; }
    public bool IncludeUnchanged { get; set; }
    public int MaxEvaluations { get; set; } = 3000;
}

public sealed record RuleRef(string Policy, string Code, string Name, string Expression);

public sealed record RuleChange(string Policy, string RuleCode, string ExpressionBefore, string ExpressionAfter);

/// <summary>Yetki (resource:scope) seviyesinde yapısal fark — bağlamdan bağımsız.</summary>
public sealed record AccessPolicyDiff(
    int ResourceScopeId, string Key, string Name, string Path, int HolderCount,
    IReadOnlyList<string> PoliciesBefore, IReadOnlyList<string> PoliciesAfter,
    IReadOnlyList<RuleRef> RulesBefore, IReadOnlyList<RuleRef> RulesAfter,
    IReadOnlyList<string> AddedRules, IReadOnlyList<string> RemovedRules, IReadOnlyList<RuleChange> ChangedRules,
    IReadOnlyList<string> RequiredAttributesAfter, IReadOnlyList<string> NewRequiredAttributes,
    bool BecomesUnrestricted, bool BecomesRestricted);

public sealed record DecisionBrief(DecisionType Decision, string ReasonCode, string Reason, string? DecidingPolicy, string? DecidingRule);

public sealed record PolicyImpactRow(int UserId, string UserName, string FullName, string Permission, string Scenario, DecisionBrief Before, DecisionBrief After, string Change);

public sealed record AffectedUser(int UserId, string UserName, string FullName, string Tenant, IReadOnlyList<string> Permissions);

public sealed class PolicyImpactResult
{
    public string Summary { get; set; } = "";
    public IReadOnlyList<AccessPolicyDiff> Accesses { get; init; } = [];
    public IReadOnlyList<AffectedUser> AffectedUsers { get; init; } = [];
    public IReadOnlyList<ImpactScenario> Scenarios { get; init; } = [];
    public IReadOnlyList<PolicyImpactRow> Rows { get; init; } = [];
    public int Evaluations { get; init; }
    public bool Truncated { get; init; }
    public int NewlyDenied { get; init; }
    public int NewlyAllowed { get; init; }
    public int OtherChanged { get; init; }
    public int Unchanged { get; init; }
    public double DurationMs { get; init; }
}

/// <summary>
/// Condition (ABAC) What-If: "Bu policy / kural / ortak koşul değişirse kimler, hangi yetkide, hangi durumda etkilenir?"
///  1) Yapısal fark: her yetki (resource:scope) için permission'lar üzerinden uygulanan policy/kural seti önce/sonra
///  2) Etkilenen kullanıcılar: yetkiye (statik) sahip herkes
///  3) Senaryolu karşılaştırma: AYNI AuthorizationEvaluator ile önce/sonra modelde karar
/// Kendi karar mantığı yoktur.
/// </summary>
public sealed class PolicyImpactService(
    IYetkiDbContext db,
    AuthorizationModelProvider models,
    AuthorizationEvaluator evaluator,
    ConditionHandlerRegistry handlers,
    PolicyManagementService definitions,
    AuditWriter audit,
    IClock clock,
    ICurrentActor actor)
{
    public async Task<PolicyImpactResult> AnalyzeAsync(PolicyImpactRequest request, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        var changes = request.Changes ?? new PolicyChangeSet();
        if (changes.IsEmpty) throw new ValidationException("En az bir policy değişikliği belirtilmelidir.");
        await ValidateAsync(changes, ct);

        var before = await models.GetCurrentAsync(ct);
        var after = await models.BuildWhatIfAsync(null, changes, ct);
        var now = request.AsOfUtc?.ToUniversalTime() ?? clock.UtcNow;

        var diffs = new List<AccessPolicyDiff>();
        var holders = new Dictionary<int, List<UserRow>>();
        foreach (var rs in before.ResourceScopes.Values.OrderBy(p => p.Key, StringComparer.Ordinal))
        {
            var b = Applied(before, rs.Id);
            var a = Applied(after, rs.Id);
            if (Signature(b) == Signature(a)) continue;
            var h = before.HoldersOf(rs.Id, now).Select(x => x.User).ToList();
            holders[rs.Id] = h;
            diffs.Add(BuildDiff(rs, h.Count, b, a));
        }

        var affected = holders.SelectMany(kv => kv.Value.Select(u => (u, key: before.ResourceScopes[kv.Key].Key)))
            .GroupBy(x => x.u.Id)
            .Select(g => new AffectedUser(g.Key, g.First().u.UserName, g.First().u.FullName, before.TenantCode(g.First().u.TenantId),
                g.Select(x => x.key).Distinct().OrderBy(c => c).ToList()))
            .OrderBy(u => u.UserName, StringComparer.Ordinal).ToList();

        var rows = new List<PolicyImpactRow>();
        int evaluations = 0, newlyDenied = 0, newlyAllowed = 0, other = 0, unchanged = 0;
        var truncated = false;
        var max = Math.Clamp(request.MaxEvaluations, 1, 20000);

        if (request.Scenarios.Count > 0)
        {
            foreach (var (rsId, users) in holders)
            foreach (var user in users)
            foreach (var scenario in request.Scenarios)
            {
                if (evaluations >= max) { truncated = true; break; }
                evaluations++;
                var ctx = new Dictionary<string, string?>(scenario.Context, StringComparer.OrdinalIgnoreCase);
                foreach (var key in ctx.Keys.ToList())
                    if (string.Equals(ctx[key], "@userBranch", StringComparison.OrdinalIgnoreCase))
                        ctx[key] = before.UnitCodesOf(user.Id).FirstOrDefault();

                var req = new AuthorizationRequest
                {
                    Subject = new SubjectInfo { UserId = user.Id }, Permission = before.ResourceScopes[rsId].Key, Context = ctx, Client = scenario.Client
                };
                var bd = await evaluator.EvaluateAsync(req, new EvaluationOptions { Model = before, IsSimulation = true, WriteAudit = false, AsOfUtc = now }, ct);
                var ad = await evaluator.EvaluateAsync(req, new EvaluationOptions { Model = after, IsSimulation = true, WriteAudit = false, AsOfUtc = now }, ct);

                var change = Classify(bd, ad);
                switch (change)
                {
                    case "NEWLY_DENIED" or "NEWLY_INDETERMINATE": newlyDenied++; break;
                    case "NEWLY_ALLOWED": newlyAllowed++; break;
                    case "UNCHANGED": unchanged++; break;
                    default: other++; break;
                }
                if (change != "UNCHANGED" || request.IncludeUnchanged)
                    rows.Add(new PolicyImpactRow(user.Id, user.UserName, user.FullName, req.Permission!, scenario.Name, Brief(bd), Brief(ad), change));
            }
        }

        sw.Stop();
        var result = new PolicyImpactResult
        {
            Accesses = diffs,
            AffectedUsers = affected,
            Scenarios = request.Scenarios,
            Rows = rows.OrderBy(r => r.Change is "NEWLY_DENIED" or "NEWLY_INDETERMINATE" ? 0 : r.Change == "NEWLY_ALLOWED" ? 1 : 2).ThenBy(r => r.UserName).ToList(),
            Evaluations = evaluations, Truncated = truncated,
            NewlyDenied = newlyDenied, NewlyAllowed = newlyAllowed, OtherChanged = other, Unchanged = unchanged,
            DurationMs = Math.Round(sw.Elapsed.TotalMilliseconds, 1),
            Summary = BuildSummary(diffs, affected.Count, request.Scenarios.Count, newlyDenied, newlyAllowed, other)
        };

        audit.Add(new AuditLog
        {
            Category = AuditCategory.Simulation, Actor = actor.Name, Action = "PolicyImpact", Summary = result.Summary,
            DetailsJson = JsonDefaults.Serialize(new { changes, scenarios = request.Scenarios, result.NewlyDenied, result.NewlyAllowed, result.Evaluations })
        });
        await db.SaveChangesAsync(ct);
        return result;
    }

    /// <summary>Yetkiye uygulanan permission'lar ve (aggregate'ler açılmış) policy'leri: (permission, policy) çiftleri.</summary>
    private static List<(CompiledPermission Permission, CompiledPolicy Policy)> Applied(AuthorizationModel m, int rsId)
    {
        var result = new List<(CompiledPermission, CompiledPolicy)>();
        foreach (var perm in m.PermissionsFor(rsId))
            foreach (var pid in perm.PolicyIds) Walk(perm, pid, 0);
        return result;

        void Walk(CompiledPermission perm, int policyId, int depth)
        {
            if (depth > AuthorizationModel.MaxPolicyDepth || !m.Policies.TryGetValue(policyId, out var p)) return;
            result.Add((perm, p));
            if (p.Row.Type == PolicyType.Aggregate) foreach (var c in p.OrderedMembers) Walk(perm, c, depth + 1);
        }
    }

    /// <summary>Uygulanan policy setinin karar semantiğini temsil eden imza (tip, logic, mod, strateji, aktiflik, üyeler, kurallar).</summary>
    private static string Signature(IReadOnlyList<(CompiledPermission Permission, CompiledPolicy Policy)> applied) =>
        string.Join("||", applied.OrderBy(a => a.Permission.Row.Code, StringComparer.Ordinal).ThenBy(a => a.Policy.Row.Code, StringComparer.Ordinal).Select(a =>
            $"{a.Permission.Row.Code}/{a.Permission.Row.Strategy}:{a.Policy.Row.Code}:{a.Policy.Row.Type}:{a.Policy.Row.Logic}:{a.Policy.Row.Mode}:{a.Policy.Row.Strategy}:{a.Policy.Row.IsActive}:" +
            string.Join(',', a.Policy.OrderedMembers) + ":" +
            string.Join(";", (a.Policy.Definition?.Rules ?? []).OrderBy(r => r.Order).ThenBy(r => r.Code).Select(r =>
                $"{r.Code}/{r.IsActive}/{r.Order}/{PolicyEvaluator.Render(r.Condition, expand: true)}"))));

    private AccessPolicyDiff BuildDiff(ResourceScopeInfo rs, int holderCount,
        IReadOnlyList<(CompiledPermission Permission, CompiledPolicy Policy)> before, IReadOnlyList<(CompiledPermission Permission, CompiledPolicy Policy)> after)
    {
        static List<(CompiledPolicy P, RuleDefinition R)> Active(IEnumerable<(CompiledPermission Permission, CompiledPolicy Policy)> ps) =>
            ps.Select(x => x.Policy).DistinctBy(p => p.Row.Id)
                .Where(p => p.Row.Mode == PolicyMode.Enforce && p.Row.IsActive && p.Definition is not null)
                .SelectMany(p => p.Definition!.Rules.Where(r => r.IsActive).Select(r => (p, r))).ToList();

        var rb = Active(before);
        var ra = Active(after);
        string Key((CompiledPolicy P, RuleDefinition R) x) => $"{x.P.Row.Code}/{x.R.Code}";

        var added = ra.Where(x => rb.All(y => Key(y) != Key(x))).Select(Key).ToList();
        var removed = rb.Where(x => ra.All(y => Key(y) != Key(x))).Select(Key).ToList();
        var changed = ra.Select(x => (a: x, b: rb.FirstOrDefault(y => Key(y) == Key(x))))
            .Where(t => t.b.R is not null)
            .Select(t => (t.a, t.b, eb: PolicyEvaluator.Render(t.b.R.Condition, true), ea: PolicyEvaluator.Render(t.a.R.Condition, true)))
            .Where(t => t.eb != t.ea)
            .Select(t => new RuleChange(t.a.P.Row.Code, t.a.R.Code, t.eb, t.ea))
            .ToList();

        var attrBefore = RequiredAttributes(rb.Select(x => x.R));
        var attrAfter = RequiredAttributes(ra.Select(x => x.R));
        static string Label((CompiledPermission Permission, CompiledPolicy Policy) x) =>
            $"{x.Permission.Row.Code} ← {x.Policy.Row.Code} ({x.Policy.Row.Type}{(x.Policy.Row.Mode != PolicyMode.Enforce ? $", {x.Policy.Row.Mode}" : "")}{(x.Policy.Row.IsActive ? "" : ", pasif")})";

        return new AccessPolicyDiff(rs.Id, rs.Key, rs.Name, rs.Path, holderCount,
            before.Select(Label).ToList(), after.Select(Label).ToList(),
            rb.Select(x => new RuleRef(x.P.Row.Code, x.R.Code, x.R.Name, PolicyEvaluator.Render(x.R.Condition))).ToList(),
            ra.Select(x => new RuleRef(x.P.Row.Code, x.R.Code, x.R.Name, PolicyEvaluator.Render(x.R.Condition))).ToList(),
            added, removed, changed, attrAfter, attrAfter.Except(attrBefore).ToList(),
            BecomesUnrestricted: rb.Count > 0 && ra.Count == 0,
            BecomesRestricted: rb.Count == 0 && ra.Count > 0);
    }

    /// <summary>Çağıranın (gateway / servis) sağlaması gereken attribute'lar: Context.* ve Environment.* (motorun ürettikleri hariç).</summary>
    private List<string> RequiredAttributes(IEnumerable<RuleDefinition> rules) => rules
        .SelectMany(r => PolicyEvaluator.Flatten(r.Condition))
        .Where(n => n.Kind == ConditionKind.Predicate && n.ConditionTypeCode is not null)
        .SelectMany(n =>
        {
            var attrs = handlers.Find(n.ConditionTypeCode!)?.Descriptor.RequiredAttributes ?? [];
            return n.Parameters.TryGetValue("AmountAttribute", out var k) && !string.IsNullOrWhiteSpace(k)
                ? attrs.Select(a => a == AttributeId.Ctx(AuthContextKeys.TransactionAmount).ToString() ? AttributeId.Ctx(k).ToString() : a)
                : attrs;
        })
        .Where(a => !a.StartsWith("Subject.", StringComparison.Ordinal)
                    && a != AttributeId.Env(AuthContextKeys.CurrentTime).ToString() && a != AttributeId.Env(AuthContextKeys.ClientId).ToString())
        .Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(a => a, StringComparer.Ordinal).ToList();

    private static DecisionBrief Brief(AuthorizationDecision d) => new(d.Decision, d.ReasonCode, d.HumanReadableReason, d.DecidingPolicy, d.DecidingRule);

    private static string Classify(AuthorizationDecision b, AuthorizationDecision a)
    {
        if (b.Decision == a.Decision) return b.ReasonCode == a.ReasonCode ? "UNCHANGED" : "REASON_CHANGED";
        if (a.IsAllowed) return "NEWLY_ALLOWED";
        if (b.IsAllowed) return a.Decision == DecisionType.Indeterminate ? "NEWLY_INDETERMINATE" : "NEWLY_DENIED";
        return "REASON_CHANGED";
    }

    private async Task ValidateAsync(PolicyChangeSet c, CancellationToken ct)
    {
        var errors = new List<string>();
        var policyIds = c.PolicyActivations.Select(x => x.PolicyId).Concat(c.PolicyModes.Select(x => x.PolicyId)).Concat(c.PolicyStrategies.Select(x => x.PolicyId))
            .Concat(c.AddedRules.Select(x => x.PolicyId)).Distinct().ToList();
        var ruleIds = c.RuleOverrides.Select(x => x.RuleId).Concat(c.RemovedRuleIds).Concat(c.ReplacedRules.Select(x => x.RuleId)).Distinct().ToList();
        var condIds = c.ConditionOverrides.Select(x => x.ConditionId).Distinct().ToList();

        if (await db.Policies.CountAsync(p => policyIds.Contains(p.Id), ct) != policyIds.Count) errors.Add("Bilinmeyen policy.");
        if (await db.Rules.CountAsync(r => ruleIds.Contains(r.Id), ct) != ruleIds.Count) errors.Add("Bilinmeyen rule.");
        var addedTo = c.AddedRules.Select(x => x.PolicyId).Distinct().ToList();
        if (await db.Policies.AnyAsync(p => addedTo.Contains(p.Id) && p.Type != PolicyType.Condition, ct)) errors.Add("Kural sadece Condition policy'sine eklenir.");

        var conditions = await db.RuleConditions.AsNoTracking().Where(x => condIds.Contains(x.Id))
            .Select(x => new { x.Id, x.Kind, Type = x.ConditionType != null ? x.ConditionType.Code : null }).ToListAsync(ct);
        if (conditions.Count != condIds.Count) errors.Add("Bilinmeyen condition.");
        foreach (var o in c.ConditionOverrides)
        {
            var cond = conditions.FirstOrDefault(x => x.Id == o.ConditionId);
            if (cond is not null && cond.Kind != ConditionKind.Predicate) { errors.Add($"Condition #{o.ConditionId} predicate değil."); continue; }
            var handler = cond?.Type is null ? null : handlers.Find(cond.Type);
            if (handler is null) continue;
            var ps = o.Parameters.Where(kv => !string.IsNullOrWhiteSpace(kv.Value)).ToDictionary(kv => kv.Key, kv => kv.Value.Trim(), StringComparer.OrdinalIgnoreCase);
            errors.AddRange(handler.ValidateParameters(ps).Select(e => $"{cond!.Type}: {e}"));
        }
        if (errors.Count > 0) throw ValidationException.Of("changes", errors);

        foreach (var draft in c.AddedRules.Concat(c.ReplacedRules.Select(r => r.Rule))) await definitions.ValidateConditionAsync(draft.Condition, ct);
        foreach (var r in c.SharedConditionReplacements)
        {
            if (!await db.SharedConditions.AnyAsync(x => x.Id == r.SharedConditionId, ct)) throw new NotFoundException("Ortak koşul", r.SharedConditionId);
            await definitions.ValidateConditionAsync(r.Condition, ct, selfSharedId: r.SharedConditionId);
        }
    }

    private static string BuildSummary(List<AccessPolicyDiff> diffs, int users, int scenarioCount, int denied, int allowed, int other)
    {
        var s = $"{diffs.Count} yetki (resource:scope), {users} kullanıcı kapsamda.";
        var newAttrs = diffs.SelectMany(d => d.NewRequiredAttributes).Distinct().ToList();
        if (newAttrs.Count > 0) s += $" YENİ gerekli attribute: {string.Join(", ", newAttrs)} (göndermeyen gateway/servislerde karar Indeterminate olur).";
        var unrestricted = diffs.Where(d => d.BecomesUnrestricted).Select(d => d.Key).Distinct().ToList();
        if (unrestricted.Count > 0) s += $" DİKKAT: {unrestricted.Count} yetki koşulsuz kalıyor ({string.Join(", ", unrestricted.Take(5))}{(unrestricted.Count > 5 ? "..." : "")}).";
        var restricted = diffs.Count(d => d.BecomesRestricted);
        if (restricted > 0) s += $" {restricted} yetki ilk kez koşula bağlanıyor.";
        if (scenarioCount > 0) s += $" Senaryolarda: {denied} karar izin → red, {allowed} karar → izin, {other} diğer değişim.";
        return s;
    }
}
