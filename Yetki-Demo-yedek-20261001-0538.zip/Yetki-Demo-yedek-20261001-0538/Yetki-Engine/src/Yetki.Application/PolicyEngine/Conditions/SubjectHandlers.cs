using System.Globalization;
using Yetki.Application.Context;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Domain.Common;

namespace Yetki.Application.PolicyEngine.Conditions;

/// <summary>
/// Context tutarı &gt; kullanıcının limit attribute'u. Limit policy'de SABİT DEĞİLDİR; kullanıcı attribute'u olarak çözülür
/// (prototipte yetki modeli, üretimde limit yönetim servisi). Eksik değer → Indeterminate (fail-closed).
/// </summary>
public sealed class AmountExceedsSubjectLimitConditionHandler : ConditionHandlerBase
{
    public const string Code = "AMOUNT_EXCEEDS_SUBJECT_LIMIT";

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Tutar kullanıcı limitini aşıyor", "İşlem tutarı kullanıcının limit attribute'undan BÜYÜK.", ConditionScope.Global,
        [
            new("AmountAttribute", "Tutar context anahtarı", "string", false, AuthContextKeys.TransactionAmount, null),
            new("LimitAttribute", "Kullanıcı limit attribute'u", "string", false, SubjectAttributes.CashWithdrawalLimit, null)
        ],
        [AttributeId.Ctx(AuthContextKeys.TransactionAmount).ToString(), AttributeId.Subject(SubjectAttributes.CashWithdrawalLimit).ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var amountId = AttributeId.Ctx(ctx.Param("AmountAttribute", AuthContextKeys.TransactionAmount));
        var limitId = AttributeId.Subject(ctx.Param("LimitAttribute", SubjectAttributes.CashWithdrawalLimit));
        var amount = await ctx.Attributes.GetDecimalAsync(amountId, ct);
        var limit = await ctx.Attributes.GetDecimalAsync(limitId, ct);
        if (amount is null || limit is null)
            return ConditionResult.Missing(new[] { (amountId, amount), (limitId, limit) }.Where(x => x.Item2 is null).Select(x => x.Item1).ToArray());
        return ConditionResult.Of(amount > limit, $"Tutar {F(amount)} > kullanıcı limiti {F(limit)}.", $"Tutar {F(amount)} ≤ kullanıcı limiti {F(limit)}.");
    }

    internal static string F(decimal? d) => d?.ToString("N2", CultureInfo.InvariantCulture) ?? "-";
}

/// <summary>Context tutarı sabit eşikten büyük mü? (domain eşiği)</summary>
public sealed class AmountGreaterThanConditionHandler : ConditionHandlerBase
{
    public const string Code = "AMOUNT_GREATER_THAN";

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Tutar eşikten büyük", "İşlem tutarı parametredeki sabit eşikten BÜYÜK.", ConditionScope.Domain,
        [
            new("Threshold", "Eşik", "decimal", true, null, "Nokta ondalık ayırıcı"),
            new("AmountAttribute", "Tutar context anahtarı", "string", false, AuthContextKeys.TransactionAmount, null)
        ],
        [AttributeId.Ctx(AuthContextKeys.TransactionAmount).ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var amountId = AttributeId.Ctx(ctx.Param("AmountAttribute", AuthContextKeys.TransactionAmount));
        var amount = await ctx.Attributes.GetDecimalAsync(amountId, ct);
        if (amount is null) return ConditionResult.Missing(amountId);
        var threshold = ctx.DecimalParam("Threshold");
        if (threshold is null) return ConditionResult.Error("INVALID_PARAMETER", "Threshold tanımsız.");
        var F = AmountExceedsSubjectLimitConditionHandler.F;
        return ConditionResult.Of(amount > threshold, $"Tutar {F(amount)} > eşik {F(threshold)}.", $"Tutar {F(amount)} ≤ eşik {F(threshold)}.");
    }
}

/// <summary>Veri kapsamı: işlemin şubesi (Context.BranchCode) kullanıcının birimleri veya ALT birimleri içinde mi? (bölge müdürü → bölgedeki şubeler)</summary>
public sealed class BranchInUserScopeConditionHandler : ConditionHandlerBase
{
    public const string Code = "BRANCH_IN_USER_SCOPE";
    private static readonly AttributeId Branch = AttributeId.Ctx(AuthContextKeys.BranchCode);
    private static readonly AttributeId Scope = AttributeId.Subject(SubjectAttributes.OrgUnitScope);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Şube kullanıcının veri kapsamında",
        "İşlemin/kaydın şubesi kullanıcının birimi veya onun alt birimlerinden biri.", ConditionScope.Global, [],
        [Branch.ToString(), Scope.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var branch = await ctx.Attributes.GetStringAsync(Branch, ct);
        if (branch is null) return ConditionResult.Missing(Branch);
        var scope = await ctx.Attributes.GetAsync(Scope, ct);
        if (scope is null) return ConditionResult.Missing(Scope);
        var codes = ConditionEvaluationContext.SplitList(scope.Value);
        return ConditionResult.Of(codes.Contains(branch, StringComparer.OrdinalIgnoreCase),
            $"{branch} şubesi kullanıcının kapsamında.",
            $"{branch} şubesi kullanıcının kapsamı dışında (kapsam: {string.Join(",", codes)}).");
    }
}

/// <summary>Kullanıcı verilen birimlerden birinde mi? IncludeSubtree=true: birimin alt birimleri de sayılır (GM → tüm daireler).</summary>
public sealed class SubjectInUnitConditionHandler : ConditionHandlerBase
{
    public const string Code = "SUBJECT_IN_UNIT";
    private static readonly AttributeId Units = AttributeId.Subject(SubjectAttributes.OrgUnitCodes);
    private static readonly AttributeId Ancestry = AttributeId.Subject(SubjectAttributes.OrgUnitAncestry);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcı birimde", "Kullanıcı verilen birimlerden birinde (opsiyonel: alt birimleri dahil).", ConditionScope.Global,
        [
            new("Units", "Birim kodları", "list", true, null, "ör. 101,737 veya GM"),
            new("IncludeSubtree", "Alt birimler dahil", "bool", false, "false", "true: GM verilirse GM altındaki daireler de sayılır")
        ],
        [Units.ToString(), Ancestry.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var attr = ctx.BoolParam("IncludeSubtree", false) ? Ancestry : Units;
        var v = await ctx.Attributes.GetAsync(attr, ct);
        if (v is null) return ConditionResult.Missing(attr);
        var mine = ConditionEvaluationContext.SplitList(v.Value);
        var wanted = ConditionEvaluationContext.SplitList(ctx.Param("Units"));
        var hit = mine.Intersect(wanted, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
        return ConditionResult.Of(hit is not null, $"Kullanıcı {hit} biriminde.", $"Kullanıcı {string.Join(",", wanted)} birimlerinde değil.");
    }
}

/// <summary>Kullanıcının etkin rolleri (doğrudan + gruptan) arasında verilenlerden biri var mı?</summary>
public sealed class SubjectHasRoleConditionHandler : ConditionHandlerBase
{
    public const string Code = "SUBJECT_HAS_ROLE";
    private static readonly AttributeId Roles = AttributeId.Subject(SubjectAttributes.RoleCodes);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcı rolde", "Kullanıcının etkin rollerinden biri verilen listede.", ConditionScope.Global,
        [new("Roles", "Roller", "list", true, null, "ör. GM850UZYTK,SUBEMDR")],
        [Roles.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var v = await ctx.Attributes.GetAsync(Roles, ct);
        if (v is null) return ConditionResult.Missing(Roles);
        var hit = ConditionEvaluationContext.SplitList(v.Value).Intersect(ConditionEvaluationContext.SplitList(ctx.Param("Roles")), StringComparer.OrdinalIgnoreCase).FirstOrDefault();
        return ConditionResult.Of(hit is not null, $"Kullanıcı {hit} rolünde.", $"Kullanıcı {ctx.Param("Roles")} rollerinde değil.");
    }
}

/// <summary>Kullanıcı verilen gruplardan birinin üyesi mi? (kişi listesi policy'ye yazılmaz, gruba referans verilir)</summary>
public sealed class SubjectInGroupConditionHandler : ConditionHandlerBase
{
    public const string Code = "SUBJECT_IN_GROUP";
    private static readonly AttributeId Groups = AttributeId.Subject(SubjectAttributes.GroupCodes);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcı grupta", "Kullanıcı verilen gruplardan birinin üyesi.", ConditionScope.Global,
        [new("Groups", "Gruplar", "list", true, null, "ör. GISE_101_AST")],
        [Groups.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var v = await ctx.Attributes.GetAsync(Groups, ct);
        if (v is null) return ConditionResult.Missing(Groups);
        var hit = ConditionEvaluationContext.SplitList(v.Value).Intersect(ConditionEvaluationContext.SplitList(ctx.Param("Groups")), StringComparer.OrdinalIgnoreCase).FirstOrDefault();
        return ConditionResult.Of(hit is not null, $"Kullanıcı {hit} grubunun üyesi.", $"Kullanıcı {ctx.Param("Groups")} gruplarının üyesi değil.");
    }
}

/// <summary>Kullanıcı izinde mi?</summary>
public sealed class UserOnLeaveConditionHandler : ConditionHandlerBase
{
    public const string Code = "USER_ON_LEAVE";
    private static readonly AttributeId OnLeave = AttributeId.Subject(SubjectAttributes.IsOnLeave);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcı izinde", "Kullanıcı şu an izinde.", ConditionScope.Global, [], [OnLeave.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var onLeave = await ctx.Attributes.GetBoolAsync(OnLeave, ct);
        return onLeave is null ? ConditionResult.Missing(OnLeave) : ConditionResult.Of(onLeave.Value, "Kullanıcı izinde.", "Kullanıcı aktif görevde.");
    }
}

/// <summary>İşlemdeki müşteri personelin kendisi mi? (Context.CustomerId == Subject.CustomerId)</summary>
public sealed class CustomerIsSelfConditionHandler : ConditionHandlerBase
{
    public const string Code = "CUSTOMER_IS_SELF";
    private static readonly AttributeId Customer = AttributeId.Ctx(AuthContextKeys.CustomerId);
    private static readonly AttributeId Own = AttributeId.Subject(SubjectAttributes.CustomerId);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Müşteri personelin kendisi", "İşlemdeki müşteri, personelin kendi müşteri numarası.", ConditionScope.Global, [],
        [Customer.ToString(), Own.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var customer = await ctx.Attributes.GetStringAsync(Customer, ct);
        if (customer is null) return ConditionResult.Missing(Customer);
        var own = await ctx.Attributes.GetAsync(Own, ct);
        if (own is null) return ConditionResult.Missing(Own);
        return ConditionResult.Of(own.Value is not null && string.Equals(own.Value, customer, StringComparison.OrdinalIgnoreCase),
            "İşlem personelin kendi müşteri hesabında.", "Müşteri personelin kendisi değil.");
    }
}
