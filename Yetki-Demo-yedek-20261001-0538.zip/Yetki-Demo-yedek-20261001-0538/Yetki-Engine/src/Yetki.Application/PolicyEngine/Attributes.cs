using System.Globalization;
using Yetki.Application.Context;
using Yetki.Application.Model;

namespace Yetki.Application.PolicyEngine.Attributes;

/// <summary>Attribute kategorisi (NIST ABAC: subject / resource / action / environment + iş bağlamı).</summary>
public enum AttributeCategory
{
    Subject = 1,
    Resource = 2,
    Action = 3,
    /// <summary>Motor/platform tarafından güvenilir şekilde üretilen ortam bilgisi (zaman, IP, kanal, client, cihaz).</summary>
    Environment = 4,
    /// <summary>İş bağlamı: SDK'da DTO attribute'u ile gelen değerler (tutar, müşteri, şube...).</summary>
    Context = 5
}

public readonly record struct AttributeId(AttributeCategory Category, string Name)
{
    public override string ToString() => $"{Category}.{Name}";

    public static AttributeId Subject(string name) => new(AttributeCategory.Subject, name);
    public static AttributeId Env(string name) => new(AttributeCategory.Environment, name);
    public static AttributeId Ctx(string name) => new(AttributeCategory.Context, name);

    public static AttributeId ForRequestKey(string key) => AuthContextKeys.IsEnvironment(key) ? Env(key) : Ctx(key);
}

/// <summary>Çözülmüş değer. Value=null → kaynak "bilinen boş" diyor. Provider çözemediyse AttributeValue'nun kendisi null (→ Indeterminate).</summary>
public sealed record AttributeValue(string? Value, string Source);

public sealed record SubjectRef(int UserId, string UserName);

public sealed record ResourceRef(string? Type, string? Id)
{
    public override string ToString() => Type is null ? Id ?? "" : $"{Type}:{Id}";
}

/// <summary>Attribute çözümlemesi için istek kapsamı. Model: kararın verildiği (gerçek veya What-If) yetki modeli.</summary>
public sealed class AttributeResolutionScope
{
    public required SubjectRef Subject { get; init; }
    public required AuthorizationContext Context { get; init; }
    public required string Action { get; init; }
    public ResourceRef? Resource { get; init; }
    public required AuthorizationModel Model { get; init; }
    public required DateTime Now { get; init; }
}

/// <summary>
/// Attribute değer kaynağı. Policy motoru değerin nereden geldiğini bilmez: bugün yetki modeli / istek bağlamı,
/// yarın HR, limit yönetimi, core banking servisleri. Yeni kaynak = yeni provider + DI kaydı (kayıt sırası önceliktir).
/// </summary>
public interface IAttributeValueProvider
{
    string Name { get; }
    bool CanResolve(AttributeId id);
    ValueTask<AttributeValue?> ResolveAsync(AttributeId id, AttributeResolutionScope scope, CancellationToken ct);
}

public sealed record UsedAttribute(string Attribute, string? Value, string Source, bool Resolved);

/// <summary>Hassas değerlerin audit/log'a nasıl yazılacağı. Karar daima gerçek değerle verilir.</summary>
public interface IAttributeRedactor
{
    string? Redact(string attribute, string? value);
}

public sealed class DefaultAttributeRedactor : IAttributeRedactor
{
    private readonly HashSet<string> _sensitive = new(
        ["Context.CustomerId", "Context.AccountNo", "Subject.CustomerId", "Environment.DeviceId"], StringComparer.OrdinalIgnoreCase);

    public string? Redact(string attribute, string? value)
    {
        if (value is null || !_sensitive.Contains(attribute)) return value;
        return value.Length <= 2 ? "**" : new string('*', value.Length - 2) + value[^2..];
    }
}

/// <summary>Tek değerlendirme boyunca attribute'ları çözer, önbelleğe alır ve hangi değerin kullanıldığını kaydeder.</summary>
public sealed class AttributeResolver(IReadOnlyList<IAttributeValueProvider> providers, AttributeResolutionScope scope)
{
    private readonly Dictionary<AttributeId, AttributeValue?> _cache = new();
    private readonly List<UsedAttribute> _used = new();

    public AttributeResolutionScope Scope => scope;
    public IReadOnlyList<UsedAttribute> Used => _used;

    public async ValueTask<AttributeValue?> GetAsync(AttributeId id, CancellationToken ct)
    {
        if (!_cache.TryGetValue(id, out var value))
        {
            value = null;
            foreach (var p in providers.Where(p => p.CanResolve(id)))
            {
                value = await p.ResolveAsync(id, scope, ct);
                if (value is not null) break;
            }
            _cache[id] = value;
        }
        _used.Add(new UsedAttribute(id.ToString(), value?.Value, value?.Source ?? "unresolved", value is not null));
        return value;
    }

    public async ValueTask<string?> GetStringAsync(AttributeId id, CancellationToken ct) =>
        (await GetAsync(id, ct)) is { Value: { Length: > 0 } v } ? v : null;

    public async ValueTask<decimal?> GetDecimalAsync(AttributeId id, CancellationToken ct) =>
        AuthorizationContext.TryParseDecimal(await GetStringAsync(id, ct), out var d) ? d : null;

    public async ValueTask<bool?> GetBoolAsync(AttributeId id, CancellationToken ct) =>
        bool.TryParse(await GetStringAsync(id, ct), out var b) ? b : null;

    public async ValueTask<DateTime?> GetDateTimeUtcAsync(AttributeId id, CancellationToken ct)
    {
        var s = await GetStringAsync(id, ct);
        return s is not null && DateTimeOffset.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var dto)
            ? dto.UtcDateTime : null;
    }
}

/// <summary>İstek bağlamı (Environment + Context + Action) ve subject kimliği.</summary>
public sealed class RequestContextAttributeProvider : IAttributeValueProvider
{
    public string Name => "Request";

    public bool CanResolve(AttributeId id) =>
        id.Category is AttributeCategory.Environment or AttributeCategory.Context or AttributeCategory.Action or AttributeCategory.Resource;

    public ValueTask<AttributeValue?> ResolveAsync(AttributeId id, AttributeResolutionScope scope, CancellationToken ct)
    {
        AttributeValue? v = id.Category switch
        {
            AttributeCategory.Action => new AttributeValue(scope.Action, "Request"),
            AttributeCategory.Resource when id.Name == "Type" => new AttributeValue(scope.Resource?.Type, "Request"),
            AttributeCategory.Resource when id.Name == "Id" => new AttributeValue(scope.Resource?.Id, "Request"),
            _ => scope.Context.GetString(id.Name) is { } s
                ? new AttributeValue(s, id.Name is AuthContextKeys.CurrentTime or AuthContextKeys.ClientId ? "Engine" : "Request")
                : null
        };
        return ValueTask.FromResult(v);
    }
}

/// <summary>
/// Subject attribute'larını yetki modelinden çözer (kullanıcı kaydı, birim hiyerarşisi, etkin roller/gruplar).
/// Üretimde bunun ÖNÜNE HR / limit servisi provider'ları eklenebilir (ör. CashWithdrawalLimit gerçek limit sisteminden).
/// </summary>
public sealed class ModelSubjectAttributeProvider : IAttributeValueProvider
{
    public string Name => "AuthorizationModel";

    public bool CanResolve(AttributeId id) => id.Category == AttributeCategory.Subject;

    public ValueTask<AttributeValue?> ResolveAsync(AttributeId id, AttributeResolutionScope scope, CancellationToken ct)
    {
        var m = scope.Model;
        if (!m.Users.TryGetValue(scope.Subject.UserId, out var u)) return ValueTask.FromResult<AttributeValue?>(null);

        string? value;
        switch (id.Name)
        {
            case SubjectAttributes.UserName: value = u.UserName; break;
            case SubjectAttributes.Tenant: value = m.Tenants[u.TenantId].Code; break;
            case SubjectAttributes.Title: value = u.Title; break;
            case SubjectAttributes.Kind: value = u.Kind.ToString(); break;
            case SubjectAttributes.CashWithdrawalLimit: value = u.CashWithdrawalLimit.ToString(CultureInfo.InvariantCulture); break;
            case SubjectAttributes.IsOnLeave: value = u.IsOnLeave.ToString(); break;
            case SubjectAttributes.CustomerId: value = u.CustomerNo; break;
            case SubjectAttributes.OrgUnitCodes: value = string.Join(",", m.UnitCodesOf(u.Id)); break;
            case SubjectAttributes.OrgUnitScope: value = string.Join(",", m.UnitScopeOf(u.Id)); break;
            case SubjectAttributes.OrgUnitAncestry: value = string.Join(",", m.UnitAncestryOf(u.Id)); break;
            case SubjectAttributes.RoleCodes: value = string.Join(",", m.GetIdentity(u.Id, scope.Now).Roles.Select(r => r.Code)); break;
            case SubjectAttributes.GroupCodes: value = string.Join(",", m.GetIdentity(u.Id, scope.Now).Groups.Select(g => g.Code)); break;
            default: return ValueTask.FromResult<AttributeValue?>(null);
        }
        return ValueTask.FromResult<AttributeValue?>(new AttributeValue(value, Name));
    }
}
