using Yetki.Domain.Common;

namespace Yetki.Application.PolicyEngine;

/// <summary>Birleştirme sonucu: karar + kararı belirleyen girdinin indeksi (açıklanabilirlik için).</summary>
public readonly record struct CombiningResult(DecisionType Decision, int? DecidingIndex);

/// <summary>
/// Keycloak karar stratejileri. Girdi: Permit / Deny / Indeterminate (belirsiz, fail-closed) / NotApplicable (etkisiz, yok sayılır).
///   Unanimous   : reddeden varsa Deny; yoksa belirsiz varsa Indeterminate; yoksa Permit.
///   Affirmative : izin veren varsa Permit; yoksa belirsiz varsa Indeterminate; yoksa Deny.
///   Consensus   : izin verenler (reddeden + belirsiz)'den fazlaysa Permit; belirsizler sonucu değiştirebiliyorsa Indeterminate; yoksa Deny.
/// Tüm girdiler NotApplicable ise sonuç NotApplicable. Belirsizlik izni hiçbir zaman tek başına üretmez (güvenli taraf).
/// Aynı fonksiyon condition kurallarını, aggregate alt policy'leri, permission policy'lerini ve uygulamadaki permission'ları birleştirir.
/// </summary>
public static class DecisionStrategies
{
    public static CombiningResult Combine(DecisionStrategy strategy, IReadOnlyList<DecisionType> r) => strategy switch
    {
        DecisionStrategy.Affirmative => First(r, DecisionType.Permit) ?? First(r, DecisionType.Indeterminate) ?? First(r, DecisionType.Deny) ?? NotApplicable,
        DecisionStrategy.Consensus => Consensus(r),
        _ => First(r, DecisionType.Deny) ?? First(r, DecisionType.Indeterminate) ?? First(r, DecisionType.Permit) ?? NotApplicable
    };

    private static readonly CombiningResult NotApplicable = new(DecisionType.NotApplicable, null);

    private static CombiningResult Consensus(IReadOnlyList<DecisionType> r)
    {
        int p = r.Count(x => x == DecisionType.Permit), d = r.Count(x => x == DecisionType.Deny), i = r.Count(x => x == DecisionType.Indeterminate);
        if (p + d + i == 0) return NotApplicable;
        if (p > d + i) return First(r, DecisionType.Permit)!.Value;
        if (p + i > d) return First(r, DecisionType.Indeterminate)!.Value;
        return First(r, DecisionType.Deny)!.Value;
    }

    private static CombiningResult? First(IReadOnlyList<DecisionType> r, DecisionType d)
    {
        for (var i = 0; i < r.Count; i++)
            if (r[i] == d) return new CombiningResult(d, i);
        return null;
    }

    /// <summary>Negative logic: Permit ↔ Deny; belirsiz ve etkisiz olduğu gibi kalır.</summary>
    public static DecisionType ApplyLogic(PolicyLogic logic, DecisionType d) => logic == PolicyLogic.Negative
        ? d switch { DecisionType.Permit => DecisionType.Deny, DecisionType.Deny => DecisionType.Permit, _ => d }
        : d;

    public static string Describe(DecisionStrategy s) => s switch
    {
        DecisionStrategy.Affirmative => "en az biri yeterli",
        DecisionStrategy.Consensus => "çoğunluk",
        _ => "hepsi izin vermeli"
    };
}
