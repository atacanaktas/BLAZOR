using Yetki.Application.Abstractions;

namespace Yetki.Application.PolicyEngine;

/// <summary>Yükümlülük tipi parametresi (UI formu ve doğrulama için).</summary>
public sealed record ObligationParamDef(string Key, string Label, bool Required, string? Hint = null);

/// <summary>
/// Yükümlülük tipi. Davranış PEP'tedir (SDK / API) — motor sadece kararla birlikte döner. Tipler KODDA tanımlıdır
/// (DB'de serbest metin davranış yok); PEP tanımadığı yükümlülükte erişimi REDDEDER (XACML: obligation yerine getirilemezse deny).
/// </summary>
public sealed record ObligationTypeDef(string Code, string Name, string Description, IReadOnlyList<ObligationParamDef> Parameters);

/// <summary>Karar ile PEP'e dönen yükümlülük.</summary>
public sealed record DecisionObligation(string Code, string Policy, IReadOnlyDictionary<string, string> Parameters);

public static class ObligationTypes
{
    public static readonly IReadOnlyList<ObligationTypeDef> All =
    [
        new("MASK_FIELDS", "Alan maskele",
            "Yanıttaki alanları maskeler (ör. mobilde TCKN / telefon). Alan adları büyük/küçük harf duyarsız, iç içe nesnelerde de uygulanır.",
            [new("Fields", "Alanlar", true, "virgülle: tckn,telefon"), new("KeepLast", "Sondan görünür karakter", false, "ör. 2 → *********12")]),
        new("LIMIT_RESULTS", "Sonuç sayısını sınırla",
            "Liste yanıtlarında en fazla N kayıt döner (ör. mobilde toplu müşteri araması 20 kayıt).",
            [new("Max", "En fazla kayıt", true, "ör. 20")]),
        new("LOG_ACCESS", "Hassas erişimi logla",
            "PEP erişimi ayrı bir hassas veri erişim loguna yazar (KVKK erişim kaydı).",
            [new("Category", "Kategori", false, "ör. KVKK_MUSTERI")])
    ];

    public static ObligationTypeDef? Find(string code) => All.FirstOrDefault(t => string.Equals(t.Code, code, StringComparison.OrdinalIgnoreCase));

    /// <summary>Tip ve parametreleri doğrular; bilinmeyen tip / eksik zorunlu parametre / sayısal olmayan değer reddedilir.</summary>
    public static Dictionary<string, string> Validate(string code, IReadOnlyDictionary<string, string>? parameters)
    {
        var type = Find(code) ?? throw new ValidationException($"Bilinmeyen yükümlülük tipi: {code}. Tanımlı: {string.Join(", ", All.Select(t => t.Code))}");
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var def in type.Parameters)
        {
            var value = parameters?.FirstOrDefault(p => string.Equals(p.Key, def.Key, StringComparison.OrdinalIgnoreCase)).Value?.Trim();
            if (string.IsNullOrEmpty(value))
            {
                if (def.Required) throw new ValidationException($"{type.Code}: '{def.Key}' zorunlu.");
                continue;
            }
            if (def.Key is "Max" or "KeepLast" && (!int.TryParse(value, out var n) || n < 0))
                throw new ValidationException($"{type.Code}: '{def.Key}' sıfır veya pozitif tam sayı olmalı.");
            result[def.Key] = value;
        }
        var unknown = parameters?.Keys.Where(k => type.Parameters.All(d => !string.Equals(d.Key, k, StringComparison.OrdinalIgnoreCase))).ToList() ?? [];
        if (unknown.Count > 0) throw new ValidationException($"{type.Code}: tanımsız parametre: {string.Join(", ", unknown)}");
        return result;
    }
}
