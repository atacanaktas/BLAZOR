﻿using Yetki.Domain.Common;

namespace Yetki.Application.Identity;

// Source-independent values: no EF entities, IQueryable, or navigation properties cross this boundary.
public sealed record IdentityUser(int Id, int TenantId, string UserName, string FullName, string? Email,
    string? Title, string? EmployeeNo, UserKind Kind, bool IsActive, bool IsOnLeave,
    decimal CashWithdrawalLimit, string? CustomerNo);
public sealed record IdentityRole(int Id, int TenantId, string Code, string Name, string? Description, bool IsInheritable, bool IsActive);
public sealed record IdentityUserRole(int UserId, int RoleId, DateTime? ValidFrom, DateTime? ValidUntil,
    string? Reason, DateTime AssignedAt, string AssignedBy);
public sealed record IdentitySnapshot(IReadOnlyList<IdentityUser> Users, IReadOnlyList<IdentityRole> Roles, IReadOnlyList<IdentityUserRole> UserRoles);
public sealed record IdentityPage<T>(IReadOnlyList<T> Items, int Total, int Page, int PageSize);
public sealed record IdentityUserQuery(int? TenantId = null, string? Search = null, int Page = 1, int PageSize = 12);
public sealed record IdentityCapabilities(bool Users, bool Roles, bool UserRoles);

/// <summary>
/// Replace this single provider registration to source User, Role and UserRole from another store/API.
/// Revision must change when any source identity data changes; failures must propagate (no stale/local fallback).
/// Stage methods enlist in the application's unit of work; they MUST NOT independently commit.
/// A remote read-only provider advertises false capabilities and rejects mutations. Remote writes require
/// an explicit transactional/outbox strategy; an HTTP call is not a substitute for a staged DB change.
/// </summary>
public interface IIdentityProvider
{
    string Name { get; }
    IdentityCapabilities Capabilities { get; }
    Task<string> GetRevisionAsync(CancellationToken ct);
    Task<IdentitySnapshot> ReadSnapshotAsync(CancellationToken ct);
    Task<IdentityUser?> GetUserAsync(int id, CancellationToken ct);
    Task<IdentityRole?> GetRoleAsync(int id, CancellationToken ct);
    Task<IdentityUserRole?> GetUserRoleAsync(int userId, int roleId, CancellationToken ct);
    Task<IReadOnlyList<IdentityUserRole>> GetUserRolesAsync(int userId, CancellationToken ct);
    Task<IdentityPage<IdentityUser>> SearchUsersAsync(IdentityUserQuery query, CancellationToken ct);
    Task<bool> UserNameExistsAsync(string name, CancellationToken ct);
    Task<bool> RoleCodeExistsAsync(string code, CancellationToken ct);
    // Creation returns generated IDs after committing the complete creation operation.
    Task<IdentityUser> CreateUserAsync(IdentityUser user, int? primaryOrgUnitId, CancellationToken ct);
    Task<IdentityRole> CreateRoleAsync(IdentityRole role, CancellationToken ct);
    Task StageUserUpdateAsync(IdentityUser user, CancellationToken ct);
    Task StageRoleUpdateAsync(IdentityRole role, CancellationToken ct);
    Task StageAssignRoleAsync(IdentityUserRole assignment, CancellationToken ct);
    Task StageRevokeRoleAsync(int userId, int roleId, CancellationToken ct);
}

public static class IdentityWrites
{
    public static void Require(bool supported, string operation)
    {
        if (!supported) throw new Yetki.Application.Abstractions.ValidationException($"The configured identity source does not support {operation}. Manage this data at its source.");
    }
}
