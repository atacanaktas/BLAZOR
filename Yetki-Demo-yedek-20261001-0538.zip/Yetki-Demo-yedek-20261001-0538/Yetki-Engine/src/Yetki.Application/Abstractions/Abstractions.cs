using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Yetki.Domain.Catalog;
using Yetki.Domain.Clients;
using Yetki.Domain.Governance;
using Yetki.Domain.Groups;
using Yetki.Domain.Identity;
using Yetki.Domain.Tenants;
using Yetki.Domain.Policies;
using Yetki.Domain.Rbac;

namespace Yetki.Application.Abstractions;

/// <summary>
/// Kalıcılık sınırı. Application katmanı EF Core soyutlamasını (DbSet/LINQ) kullanır ama provider'ı (InMemory / SQLite / SQL Server) bilmez.
/// </summary>
public interface IYetkiDbContext
{
    DbSet<Tenant> Tenants { get; }
    DbSet<OrgUnit> OrgUnits { get; }
    DbSet<User> Users { get; }
    DbSet<UserOrgUnit> UserOrgUnits { get; }

    DbSet<CatalogApplication> Applications { get; }
    DbSet<OwnershipTeam> OwnershipTeams { get; }
    DbSet<ResourceType> ResourceTypes { get; }
    DbSet<Resource> Resources { get; }
    DbSet<Scope> Scopes { get; }
    DbSet<ResourceScope> ResourceScopes { get; }
    DbSet<ResourceUri> ResourceUris { get; }
    DbSet<InventorySnapshot> InventorySnapshots { get; }
    DbSet<InventoryItem> InventoryItems { get; }

    DbSet<Client> Clients { get; }
    DbSet<ClientQueryApplication> ClientQueryApplications { get; }
    DbSet<ClientQueryTenant> ClientQueryTenants { get; }
    DbSet<ClientDelegation> ClientDelegations { get; }
    DbSet<ClientSecret> ClientSecrets { get; }

    DbSet<Role> Roles { get; }
    DbSet<UserRole> UserRoles { get; }

    DbSet<Group> Groups { get; }
    DbSet<GroupMember> GroupMembers { get; }
    DbSet<GroupFilter> GroupFilters { get; }
    DbSet<GroupFilterCriterion> GroupFilterCriteria { get; }
    DbSet<GroupFilterValue> GroupFilterValues { get; }
    DbSet<GroupRole> GroupRoles { get; }

    DbSet<Policy> Policies { get; }
    DbSet<PolicyMember> PolicyMembers { get; }
    DbSet<PolicyObligation> PolicyObligations { get; }
    DbSet<PolicyObligationParameter> PolicyObligationParameters { get; }
    DbSet<Rule> Rules { get; }
    DbSet<RuleCondition> RuleConditions { get; }
    DbSet<ConditionParameter> ConditionParameters { get; }
    DbSet<SharedCondition> SharedConditions { get; }
    DbSet<ConditionType> ConditionTypes { get; }
    DbSet<Permission> Permissions { get; }
    DbSet<PermissionResource> PermissionResources { get; }
    DbSet<PermissionScope> PermissionScopes { get; }
    DbSet<PermissionPolicy> PermissionPolicies { get; }

    DbSet<SodRule> SodRules { get; }
    DbSet<SodRuleMember> SodRuleMembers { get; }
    DbSet<SodViolation> SodViolations { get; }
    DbSet<ExternalSystem> ExternalSystems { get; }
    DbSet<ExternalPermission> ExternalPermissions { get; }
    DbSet<ExternalPermissionRequirement> ExternalPermissionRequirements { get; }
    DbSet<ExternalDependency> ExternalDependencies { get; }
    DbSet<UserExternalGrant> UserExternalGrants { get; }
    DbSet<OutboxEvent> OutboxEvents { get; }
    DbSet<ProvisioningAction> ProvisioningActions { get; }
    DbSet<AuditLog> AuditLogs { get; }

    EntityEntry Add(object entity);
    EntityEntry Remove(object entity);
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}

public interface IClock
{
    DateTime UtcNow { get; }
}

/// <summary>Yönetim işlemini yapan kişi (audit "kim yaptı?"). Prototipte X-Actor header'ından gelir.</summary>
public interface ICurrentActor
{
    string Name { get; }
}

/// <summary>
/// Yetki verisinin global versiyonu: yetkiyi etkileyen her kayıtta artar. Bellek içi yetki modeli bu versiyonla
/// önbelleklenir. Çok instance'lı kurulumda dağıtık bir kaynaktan (Redis/DB) okunmalıdır (TODO).
/// </summary>
public interface IAuthorizationVersion
{
    long Current { get; }
    void Bump();
}

public class NotFoundException(string entity, object key) : Exception($"{entity} bulunamadı: {key}");

public class ValidationException(string message, IDictionary<string, string[]>? errors = null) : Exception(message)
{
    public IDictionary<string, string[]> Errors { get; } = errors ?? new Dictionary<string, string[]>();

    public static ValidationException Of(string field, IEnumerable<string> errors) =>
        new("Geçersiz istek.", new Dictionary<string, string[]> { [field] = errors.ToArray() });
}

/// <summary>Soran client'ın bu soruyu sorma yetkisi yok (soru kapsamı dışında). 403 döner.</summary>
public class ForbiddenException(string code, string message) : Exception(message)
{
    public string Code { get; } = code;
}

/// <summary>İş kuralı çakışması (SoD Block, kod tekrarı, kullanımdaki kayıt). Details istemciye olduğu gibi döner.</summary>
public class ConflictException(string message, object? details = null) : Exception(message)
{
    public object? Details { get; } = details;
}
