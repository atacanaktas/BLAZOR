using System.Globalization;

namespace Yetki.Application.Context;

/// <summary>
/// Normalize istek bağlamı anahtarları (API sözleşmesi). SDK'daki AuthContextType değerleriyle aynı isimler.
/// </summary>
public static class AuthContextKeys
{
    // ---- Environment: motor/platform üretir, iş ekibinden istenmez ----
    /// <summary>Karar anı. Otorite motordur; çağıranın gönderdiği değer CallerTime olarak saklanır.</summary>
    public const string CurrentTime = "CurrentTime";
    public const string IpAddress = "IpAddress";
    public const string Channel = "Channel";
    public const string Platform = "Platform";
    public const string DeviceId = "DeviceId";
    public const string DeviceCompliant = "DeviceCompliant";
    /// <summary>İsteği gönderen OAuth client (motor istekteki Client alanından yazar).</summary>
    public const string ClientId = "ClientId";
    public const string CallerTime = "CallerTime";

    // ---- Context: iş değerleri (SDK'da DTO property'si semantik attribute ile işaretlenir) ----
    public const string TransactionAmount = "TransactionAmount";
    public const string Currency = "Currency";
    public const string CustomerId = "CustomerId";
    public const string AccountNo = "AccountNo";
    /// <summary>İşlemin/kaydın ait olduğu şube (veri kapsamı kontrolleri).</summary>
    public const string BranchCode = "BranchCode";
    /// <summary>Kaydın ait olduğu tenant (resource.properties.Tenant). Verilirse istek tenant'ıyla aynı olmalı (tenant izolasyonu).</summary>
    public const string ResourceTenant = "Tenant";

    private static readonly HashSet<string> EnvironmentKeys = new(StringComparer.OrdinalIgnoreCase)
        { CurrentTime, IpAddress, Channel, Platform, DeviceId, DeviceCompliant, ClientId, CallerTime };

    public static bool IsEnvironment(string key) => EnvironmentKeys.Contains(key);
}

/// <summary>Kullanıcı (subject) attribute adları. Değerler IAttributeValueProvider'larla çözülür.</summary>
public static class SubjectAttributes
{
    public const string UserName = "UserName";
    public const string Tenant = "Tenant";
    public const string Title = "Title";
    public const string Kind = "Kind";
    public const string CashWithdrawalLimit = "CashWithdrawalLimit";
    public const string IsOnLeave = "IsOnLeave";
    public const string CustomerId = "CustomerId";
    /// <summary>Kullanıcının bağlı olduğu birim kodları (virgülle).</summary>
    public const string OrgUnitCodes = "OrgUnitCodes";
    /// <summary>Veri kapsamı: bağlı birimler + tüm alt birimleri (bölge müdürü → bölgedeki şubeler).</summary>
    public const string OrgUnitScope = "OrgUnitScope";
    /// <summary>Bağlı birimler + tüm üst birimleri (GM altındaki daire → GM).</summary>
    public const string OrgUnitAncestry = "OrgUnitAncestry";
    /// <summary>Etkin roller (doğrudan + gruptan).</summary>
    public const string RoleCodes = "RoleCodes";
    public const string GroupCodes = "GroupCodes";
}

/// <summary>Değerlendirme sırasında kullanılan normalize istek bağlamı (invariant-culture string değerler).</summary>
public sealed class AuthorizationContext
{
    private readonly Dictionary<string, string?> _values;

    public AuthorizationContext(IDictionary<string, string?>? values = null)
    {
        _values = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
        if (values is null) return;
        foreach (var (k, v) in values)
            if (!string.IsNullOrWhiteSpace(k)) _values[k.Trim()] = v?.Trim();
    }

    public IReadOnlyDictionary<string, string?> Values => _values;

    public void Set(string key, string? value) => _values[key] = value;

    public string? GetString(string key) => _values.TryGetValue(key, out var v) && !string.IsNullOrWhiteSpace(v) ? v : null;

    public static bool TryParseDecimal(string? s, out decimal value) =>
        decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out value);
}
