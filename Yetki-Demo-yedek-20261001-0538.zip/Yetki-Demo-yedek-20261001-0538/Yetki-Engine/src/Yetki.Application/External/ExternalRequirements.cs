using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Model;
using Yetki.Domain.Common;

namespace Yetki.Application.External;

// ============================================================================================
//  Dış sistem gereksinimi (RACF / LDAP) — kimlik yayılımı: CICS'te çağıran kullanıcının RACF yetkisi aranır.
//
//  Yetki Y (resource:scope) gereksinimi =
//      Y'ye (resource:scope) doğrudan bağlı bağımlılıklar
//    ∪ Y'nin resource'una bağlı bağımlılıklar (resource → tüm scope'larına miras)
//    + zincir (dış yetki → gerektirdiği dış yetki)
//  Seviye: bağımlılıkta verilmişse o, yoksa scope'tan (view/read/list/export/print → READ, diğerleri → UPDATE).
//  Kullanıcının olması gereken dış durumu = etkin yetkilerinin gereksinimlerinin birleşimi (dış yetki başına en yüksek seviye).
//  Pasif kullanıcı → boş küme (her şey geri alınır).
// ============================================================================================

public sealed record ExternalSystemRow(int Id, string Code, string Name, bool HasAccessLevels);
public sealed record ExternalPermissionRow(int Id, int SystemId, string Code, string? Name, string? ResourceClass);
public sealed record ExternalRequirementRow(int ExternalPermissionId, int RequiredExternalPermissionId, ExternalAccessLevel? AccessLevel);
public sealed record ExternalDependencyRow(int Id, int? ResourceId, int? ResourceScopeId, int ExternalPermissionId, ExternalAccessLevel? AccessLevel, string? Note);

/// <summary>Dış yetki kimliği (sistem + kod + sınıf).</summary>
public sealed record ExternalTarget(int ExternalPermissionId, string System, string Code, string? Name, string? ResourceClass, bool HasAccessLevels)
{
    public string Key => $"{System}:{Code}";
}

/// <summary>Gereken dış yetki + seviye + neden (hangi yetki / resource / zincir yüzünden).</summary>
public sealed record ExternalNeed(ExternalTarget Target, ExternalAccessLevel? Level, IReadOnlyList<string> Reasons);

/// <summary>Dış bağımlılık kataloğu (değişmez anlık görüntü). What-If için With/Without ile değiştirilmiş kopyası kurulabilir.</summary>
public sealed class ExternalRequirementCatalog
{
    public const int MaxChainDepth = 8;

    public IReadOnlyDictionary<int, ExternalSystemRow> Systems { get; }
    public IReadOnlyDictionary<int, ExternalPermissionRow> Permissions { get; }
    public IReadOnlyList<ExternalDependencyRow> Dependencies { get; }
    public IReadOnlyList<ExternalRequirementRow> Requirements { get; }

    private readonly ILookup<int, ExternalDependencyRow> _byResource, _byResourceScope;
    private readonly ILookup<int, ExternalRequirementRow> _requires;

    public ExternalRequirementCatalog(IEnumerable<ExternalSystemRow> systems, IEnumerable<ExternalPermissionRow> permissions,
        IEnumerable<ExternalDependencyRow> dependencies, IEnumerable<ExternalRequirementRow> requirements)
    {
        Systems = systems.ToDictionary(s => s.Id);
        Permissions = permissions.ToDictionary(p => p.Id);
        Dependencies = dependencies.ToList();
        Requirements = requirements.ToList();
        _byResource = Dependencies.Where(d => d.ResourceId is not null).ToLookup(d => d.ResourceId!.Value);
        _byResourceScope = Dependencies.Where(d => d.ResourceScopeId is not null).ToLookup(d => d.ResourceScopeId!.Value);
        _requires = Requirements.ToLookup(r => r.ExternalPermissionId);
    }

    public static async Task<ExternalRequirementCatalog> LoadAsync(IYetkiDbContext db, CancellationToken ct) => new(
        await db.ExternalSystems.AsNoTracking().Select(s => new ExternalSystemRow(s.Id, s.Code, s.Name, s.HasAccessLevels)).ToListAsync(ct),
        await db.ExternalPermissions.AsNoTracking().Select(p => new ExternalPermissionRow(p.Id, p.ExternalSystemId, p.Code, p.Name, p.ResourceClass)).ToListAsync(ct),
        await db.ExternalDependencies.AsNoTracking()
            .Select(d => new ExternalDependencyRow(d.Id, d.ResourceId, d.ResourceScopeId, d.ExternalPermissionId, d.AccessLevel, d.Note)).ToListAsync(ct),
        await db.ExternalPermissionRequirements.AsNoTracking()
            .Select(r => new ExternalRequirementRow(r.ExternalPermissionId, r.RequiredExternalPermissionId, r.AccessLevel)).ToListAsync(ct));

    /// <summary>What-If: bağımlılık eklenmiş / çıkarılmış kopya.</summary>
    public ExternalRequirementCatalog With(ExternalDependencyRow? added = null, int? removedDependencyId = null) =>
        new(Systems.Values, Permissions.Values,
            Dependencies.Where(d => d.Id != removedDependencyId).Concat(added is null ? [] : [added]), Requirements);

    public ExternalRequirementCatalog WithRequirement(ExternalRequirementRow? added = null, (int From, int To)? removed = null) =>
        new(Systems.Values, Permissions.Values, Dependencies,
            Requirements.Where(r => removed is null || r.ExternalPermissionId != removed.Value.From || r.RequiredExternalPermissionId != removed.Value.To)
                .Concat(added is null ? [] : [added]));

    public ExternalTarget Target(int externalPermissionId)
    {
        var p = Permissions[externalPermissionId];
        var s = Systems[p.SystemId];
        return new ExternalTarget(p.Id, s.Code, p.Code, p.Name, p.ResourceClass, s.HasAccessLevels);
    }

    /// <summary>Scope'tan varsayılan erişim seviyesi: okuma türü → READ, değişiklik türü → UPDATE.</summary>
    public static ExternalAccessLevel DefaultLevel(string scope) => scope.ToLowerInvariant() switch
    {
        "read" or "view" or "export" or "print" or "list" or "search" or "inquiry" => ExternalAccessLevel.Read,
        _ => ExternalAccessLevel.Update
    };

    /// <summary>Bir yetkinin (resource:scope) dış gereksinimleri (resource mirası + zincir, nedenleriyle). Seviyesiz sistemlerde Level = null.</summary>
    public IReadOnlyList<ExternalNeed> ForAccess(ResourceScopeInfo p)
    {
        var acc = new Dictionary<int, (ExternalAccessLevel? Level, List<string> Reasons)>();
        var defaultLevel = DefaultLevel(p.Scope.Code);

        foreach (var d in _byResourceScope[p.Id]) AddWithChain(d.ExternalPermissionId, d.AccessLevel ?? defaultLevel, $"yetki {p.Key} (doğrudan)");
        foreach (var d in _byResource[p.Resource.Id]) AddWithChain(d.ExternalPermissionId, d.AccessLevel ?? defaultLevel, $"resource {p.Resource.Code} (tüm scope'lar)");

        return acc.Select(kv => new ExternalNeed(Target(kv.Key), kv.Value.Level, kv.Value.Reasons.Distinct().ToList()))
            .OrderBy(n => n.Target.System).ThenBy(n => n.Target.Code, StringComparer.Ordinal).ToList();

        void AddWithChain(int extId, ExternalAccessLevel level, string reason)
        {
            var path = new HashSet<int>();
            Visit(extId, level, reason, 0);

            void Visit(int id, ExternalAccessLevel lvl, string why, int depth)
            {
                if (depth > MaxChainDepth || !path.Add(id) || !Permissions.ContainsKey(id)) return;
                var hasLevels = Systems[Permissions[id].SystemId].HasAccessLevels;
                var effective = hasLevels ? lvl : (ExternalAccessLevel?)null;
                if (!acc.TryGetValue(id, out var cur)) acc[id] = cur = (effective, new List<string>());
                acc[id] = (Max(cur.Level, effective), cur.Reasons);
                cur.Reasons.Add(why);
                foreach (var r in _requires[id])
                    Visit(r.RequiredExternalPermissionId, r.AccessLevel ?? lvl, $"{why} → {Target(id).Key} gerektirir", depth + 1);
                path.Remove(id);
            }
        }
    }

    /// <summary>Kullanıcının olması gereken dış durumu: etkin (koşullu dahil) yetkilerinin gereksinimleri (dış yetki başına en yüksek seviye).</summary>
    public IReadOnlyList<ExternalNeed> ForUser(AuthorizationModel m, EffectiveAccessSet set)
    {
        if (!set.IsActive) return [];
        var acc = new Dictionary<int, (ExternalTarget Target, ExternalAccessLevel? Level, List<string> Reasons)>();
        foreach (var ep in set.Accesses)
        {
            if (!m.ResourceScopes.TryGetValue(ep.ResourceScopeId, out var p)) continue;
            foreach (var need in ForAccess(p))
            {
                if (!acc.TryGetValue(need.Target.ExternalPermissionId, out var cur))
                    acc[need.Target.ExternalPermissionId] = cur = (need.Target, need.Level, new List<string>());
                acc[need.Target.ExternalPermissionId] = (cur.Target, Max(cur.Level, need.Level), cur.Reasons);
                cur.Reasons.AddRange(need.Reasons.Select(r => $"{p.Key} ← {r}"));
            }
        }
        return acc.Values.Select(x => new ExternalNeed(x.Target, x.Level, x.Reasons.Distinct().ToList()))
            .OrderBy(n => n.Target.System).ThenBy(n => n.Target.Code, StringComparer.Ordinal).ToList();
    }

    /// <summary>Zincir döngü kontrolü: from → to eklenirse to'dan from'a yol var mı?</summary>
    public bool WouldCreateCycle(int from, int to)
    {
        var stack = new Stack<int>([to]);
        var seen = new HashSet<int>();
        while (stack.Count > 0)
        {
            var id = stack.Pop();
            if (id == from) return true;
            if (!seen.Add(id)) continue;
            foreach (var r in _requires[id]) stack.Push(r.RequiredExternalPermissionId);
        }
        return false;
    }

    public static ExternalAccessLevel? Max(ExternalAccessLevel? a, ExternalAccessLevel? b) =>
        a is null ? b : b is null ? a : (ExternalAccessLevel)Math.Max((int)a.Value, (int)b.Value);
}

// ------------------------------ Olması gereken ↔ dış sistemdeki durum farkı ------------------------------

/// <summary>Dış durum farkı kalemi. Action: Grant / Modify (seviye değişimi) / Revoke / None (senkron).</summary>
public sealed record ExternalDiffItem(
    ExternalTarget Target, ExternalAccessLevel? DesiredLevel, ExternalAccessLevel? CurrentLevel, string Action, IReadOnlyList<string> Reasons);

public static class ExternalDiff
{
    /// <summary>
    /// desired: olması gereken · current: dış sistemdeki (veya önceki) durum (dış yetki id → seviye).
    /// previous: önceki gereksinimler verilirse Revoke kalemlerinin nedeni "önceden şu yüzden gerekiyordu" olur.
    /// </summary>
    public static List<ExternalDiffItem> Compute(IReadOnlyList<ExternalNeed> desired, IReadOnlyDictionary<int, ExternalAccessLevel?> current,
        Func<int, ExternalTarget> target, bool includeUnchanged = false, IReadOnlyList<ExternalNeed>? previous = null)
    {
        var previousReasons = previous?.ToDictionary(n => n.Target.ExternalPermissionId, n => n.Reasons);
        var result = new List<ExternalDiffItem>();
        foreach (var n in desired)
        {
            var id = n.Target.ExternalPermissionId;
            if (!current.TryGetValue(id, out var cur)) result.Add(new(n.Target, n.Level, null, "Grant", n.Reasons));
            else if (cur != n.Level) result.Add(new(n.Target, n.Level, cur, "Modify", n.Reasons));
            else if (includeUnchanged) result.Add(new(n.Target, n.Level, cur, "None", n.Reasons));
        }
        var desiredIds = desired.Select(n => n.Target.ExternalPermissionId).ToHashSet();
        foreach (var (id, lvl) in current.Where(c => !desiredIds.Contains(c.Key)))
            result.Add(new(target(id), null, lvl, "Revoke",
                previousReasons?.GetValueOrDefault(id)?.Select(r => $"önceden: {r}").ToList() ?? ["artık hiçbir etkin yetki bunu gerektirmiyor"]));
        return result.OrderBy(r => r.Action == "None").ThenBy(r => r.Target.System).ThenBy(r => r.Target.Code, StringComparer.Ordinal).ToList();
    }

    public static IReadOnlyDictionary<int, ExternalAccessLevel?> ToState(IEnumerable<ExternalNeed> needs) =>
        needs.ToDictionary(n => n.Target.ExternalPermissionId, n => n.Level);
}
