using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Yetki.Application.Common;

public static class JsonDefaults
{
    public static readonly JsonSerializerOptions Options = Create();

    public static JsonSerializerOptions Create()
    {
        var o = new JsonSerializerOptions(JsonSerializerDefaults.Web)
        {
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };
        o.Converters.Add(new JsonStringEnumConverter());
        return o;
    }

    public static string Serialize<T>(T value) => JsonSerializer.Serialize(value, Options);
}

public static class Codes
{
    /// <summary>Tanım kodları (rol, grup, policy, düğüm...) BÜYÜK harf. Türkçe kültür sürprizine karşı Invariant.</summary>
    public static string Normalize(string code) => code.Trim().ToUpperInvariant();

    /// <summary>Permission, client_id, kullanıcı adı, API kodu: küçük harf (sektördeki yaygın biçim).</summary>
    public static string Lower(string code) => code.Trim().ToLowerInvariant();

    /// <summary>"anka.nakit.cekim.gise:create" → "create"</summary>
    public static string ActionOf(string permissionCode)
    {
        var i = permissionCode.LastIndexOf(':');
        return i < 0 ? "execute" : permissionCode[(i + 1)..];
    }

    public static IReadOnlyList<string> SplitList(string? csv) =>
        (csv ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
}

/// <summary>
/// Tenant miras kuralı (tek kural): bir tanım (uygulama, client, policy, miras alınabilir rol) sahibi olan tenant'ta ve
/// onun ALT tenant'larında kullanılabilir. Üst tenant'ın kullanıcısı alt tenant'ın tanımını kullanamaz.
/// </summary>
public static class TenantHierarchy
{
    /// <summary>ownerTenantId'ye ait tanım tenantId'de kullanılabilir mi? (tenantId == owner veya owner, tenantId'nin atası)</summary>
    public static async Task<bool> IsAvailableAsync(Abstractions.IYetkiDbContext db, int ownerTenantId, int tenantId, CancellationToken ct)
    {
        int? current = tenantId;
        var seen = new HashSet<int>();
        while (current is { } c && seen.Add(c))
        {
            if (c == ownerTenantId) return true;
            current = await Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.FirstOrDefaultAsync(
                db.Tenants.Where(t => t.Id == c).Select(t => t.ParentId), ct);
        }
        return false;
    }
}
