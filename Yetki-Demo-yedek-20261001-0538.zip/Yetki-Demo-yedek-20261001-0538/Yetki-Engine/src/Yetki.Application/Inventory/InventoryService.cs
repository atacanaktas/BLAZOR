using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Model;
using Yetki.Domain.Catalog;

namespace Yetki.Application.Inventory;

public enum InventoryFormat { Lines = 1, OpenApi = 2, Json = 3 }

/// <summary>
/// Envanter içe aktarımı. Endpoint: OpenAPI/Swagger JSON veya satır listesi ("GET /v1/x  açıklama").
/// UI öğesi: JSON dizi ([{code,name,parent,type}]) veya satır listesi ("KOD;Ad;ÜstKod;Tip").
/// </summary>
public sealed class InventoryImport
{
    public string Source { get; set; } = default!;
    public InventoryFormat Format { get; set; } = InventoryFormat.Lines;
    public string Content { get; set; } = default!;
    /// <summary>Endpoint path'lerinin başına eklenecek önek (ör. gateway'deki yol /anka).</summary>
    public string? PathPrefix { get; set; }
}

public enum CoverageStatus { Protected = 1, NoPermission = 2, Undefined = 3, Ambiguous = 4 }

public sealed record InventorySnapshotInfo(InventoryKind Kind, string Source, DateTime ImportedAt, string ImportedBy, int ItemCount);

public sealed record EndpointCoverage(
    string Method, string Path, string? Name, string Group, CoverageStatus Status,
    string? Key, int? ResourceId, string? MatchedUri, IReadOnlyList<string> Permissions, IReadOnlyList<string> Ambiguous,
    string SuggestedScope, int? SuggestedResourceId, string? SuggestedResourceCode, string SuggestedCode);

public sealed record StaleUri(int ResourceId, string Resource, string Method, string Pattern, string Key, string Group);

public sealed record UiCoverage(
    string Code, string? Name, string? ParentCode, string? ElementType, CoverageStatus Status,
    int? ResourceId, string? Resource, IReadOnlyList<ScopeState> Scopes,
    string SuggestedCode, int? SuggestedTypeId, int? SuggestedParentId);

public sealed record ScopeState(string Key, bool Protected);

public sealed record StaleUi(int ResourceId, string Code, string Name, string Type, string? ExternalCode);

public sealed record CoverageReport(
    int ApplicationId, string Application, InventorySnapshotInfo? Endpoints, InventorySnapshotInfo? UiElements,
    IReadOnlyList<EndpointCoverage> EndpointItems, IReadOnlyList<StaleUri> StaleUris,
    IReadOnlyList<UiCoverage> UiItems, IReadOnlyList<StaleUi> StaleUiResources);

/// <summary>
/// ENVANTER ve KAPSAMA: uygulamada gerçekte ne var (Swagger, ekran listesi) ↔ yetki tanımları.
/// Envanter sadece bilgidir: resource / permission üretmez, kararları etkilemez. Rapor dört durumu ayırır:
///  korunuyor · tanımlı ama permission yok (kapalı) · tanımsız (kapalı; çağrılırsa reddedilir) · tanımlı ama envanterde yok (atıl olabilir).
/// </summary>
public sealed class InventoryService(IYetkiDbContext db, AuthorizationModelProvider models, AuditWriter audit, IClock clock, ICurrentActor actor)
{
    public static readonly string[] Methods = ["GET", "POST", "PUT", "PATCH", "DELETE"];

    public async Task<InventorySnapshotInfo> ImportAsync(int applicationId, InventoryKind kind, InventoryImport dto, CancellationToken ct)
    {
        var app = await db.Applications.FindAsync([applicationId], ct) ?? throw new NotFoundException("Uygulama", applicationId);
        if (string.IsNullOrWhiteSpace(dto.Source)) throw new ValidationException("Kaynak açıklaması girilmeli (ör. \"Swagger v1.4\").");
        if (string.IsNullOrWhiteSpace(dto.Content)) throw new ValidationException("İçerik boş.");
        var items = kind == InventoryKind.Endpoint ? ParseEndpoints(dto) : ParseUi(dto);
        if (items.Count == 0) throw new ValidationException("İçerikten hiç öğe okunamadı.");

        var old = await db.InventorySnapshots.Where(s => s.ApplicationId == app.Id && s.Kind == kind).ToListAsync(ct);
        db.InventorySnapshots.RemoveRange(old);
        var snapshot = new InventorySnapshot
        {
            ApplicationId = app.Id, Kind = kind, Source = dto.Source.Trim(), ImportedAt = clock.UtcNow, ImportedBy = actor.Name, Items = items
        };
        db.InventorySnapshots.Add(snapshot);
        audit.Management("InventoryImported", "Inventory", app.Code,
            $"Envanter içe aktarıldı: {app.Code} · {(kind == InventoryKind.Endpoint ? "endpoint" : "UI öğesi")} · {items.Count} öğe ({snapshot.Source})",
            new { kind, dto.Source, count = items.Count });
        await db.SaveChangesAsync(ct);
        return Info(snapshot, items.Count);
    }

    public async Task DeleteAsync(int applicationId, InventoryKind kind, CancellationToken ct)
    {
        var old = await db.InventorySnapshots.Where(s => s.ApplicationId == applicationId && s.Kind == kind).ToListAsync(ct);
        if (old.Count == 0) return;
        db.InventorySnapshots.RemoveRange(old);
        audit.Management("InventoryDeleted", "Inventory", applicationId.ToString(), $"Envanter silindi ({kind})", new { applicationId, kind });
        await db.SaveChangesAsync(ct);
    }

    public async Task<CoverageReport> CoverageAsync(int applicationId, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Apps.TryGetValue(applicationId, out var app)) throw new NotFoundException("Uygulama", applicationId);
        var snapshots = await db.InventorySnapshots.AsNoTracking().Include(s => s.Items)
            .Where(s => s.ApplicationId == applicationId).ToListAsync(ct);
        var endpointSnap = snapshots.FirstOrDefault(s => s.Kind == InventoryKind.Endpoint);
        var uiSnap = snapshots.FirstOrDefault(s => s.Kind == InventoryKind.UiElement);
        var appResources = m.Resources.Values.Where(r => r.ApplicationId == app.Id).ToList();

        // ---- Endpoint'ler
        var endpoints = new List<EndpointCoverage>();
        var hitUris = new HashSet<int>();
        foreach (var item in endpointSnap?.Items.OrderBy(i => i.Path).ThenBy(i => i.Method) ?? Enumerable.Empty<InventoryItem>())
        {
            var method = item.Method ?? "GET";
            var path = item.Path ?? "/";
            var group = AuthorizationModel.UrlGroup([path]);
            var scope = SuggestScope(method);
            var (match, ambiguous) = m.MatchHttp(app.Code, method, path, app.TenantId);
            if (match is not null) hitUris.Add(match.Uri.Id);
            foreach (var a in ambiguous) hitUris.Add(a.Uri.Id);

            // Öneri: aynı URL grubundaki mevcut resource (yeni URI oraya eklenir) veya yeni resource kodu
            var sibling = match is null
                ? appResources.Where(r => m.ResourceTypes[r.ResourceTypeId].MatchesHttp)
                    .Select(r => (r, prefix: AuthorizationModel.UrlGroup(m.UrisOf(r.Id).Select(u => u.Pattern))))
                    .Where(x => x.prefix.Length > 0 && (group + "/").StartsWith(x.prefix + "/", StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(x => x.prefix.Length).Select(x => x.r).FirstOrDefault()
                : null;

            if (ambiguous.Count > 0)
                endpoints.Add(new(method, path, item.Name, group, CoverageStatus.Ambiguous, null, null, null, [], ambiguous.Select(a => $"{a.Uri.Method} {a.Uri.Pattern} → {a.Access.Key}").ToList(),
                    scope, null, null, SuggestCode(app.Code, group)));
            else if (match is null)
                endpoints.Add(new(method, path, item.Name, group, CoverageStatus.Undefined, null, null, null, [], [],
                    scope, sibling?.Id, sibling?.Code, SuggestCode(app.Code, group)));
            else
            {
                var perms = m.PermissionsFor(match.Access.Id).Select(p => p.Row.Code).ToList();
                endpoints.Add(new(method, path, item.Name, group, perms.Count > 0 ? CoverageStatus.Protected : CoverageStatus.NoPermission,
                    match.Access.Key, match.Access.Resource.Id, $"{match.Uri.Method} {match.Uri.Pattern}", perms, [], scope, null, null, SuggestCode(app.Code, group)));
            }
        }
        var staleUris = endpointSnap is null ? [] : appResources
            .SelectMany(r => m.UrisOf(r.Id).Where(u => !hitUris.Contains(u.Id)).Select(u => new StaleUri(r.Id, r.Code, u.Method, u.Pattern,
                $"{r.Code}:{m.Scopes.GetValueOrDefault(u.ScopeId)?.Code}", AuthorizationModel.UrlGroup([u.Pattern]))))
            .OrderBy(x => x.Pattern).ToList();

        // ---- UI öğeleri (kod eşleşmesi: resource.ExternalCode veya resource.Code)
        var uiResources = appResources.Where(r => !m.ResourceTypes[r.ResourceTypeId].MatchesHttp).ToList();
        ResourceRow? FindRes(string? code) => string.IsNullOrWhiteSpace(code) ? null : uiResources.FirstOrDefault(r =>
            string.Equals(r.ExternalCode, code, StringComparison.OrdinalIgnoreCase) || string.Equals(r.Code, code, StringComparison.OrdinalIgnoreCase));
        var ui = new List<UiCoverage>();
        var hitResources = new HashSet<int>();
        foreach (var item in uiSnap?.Items.OrderBy(i => i.ParentCode).ThenBy(i => i.Code) ?? Enumerable.Empty<InventoryItem>())
        {
            var r = FindRes(item.Code);
            var typeId = SuggestType(m, item.ElementType);
            var parentId = FindRes(item.ParentCode)?.Id;
            var suggested = $"{app.Code.ToLowerInvariant()}.{Slug(item.Code ?? item.Name ?? "oge")}";
            if (r is null)
            {
                ui.Add(new(item.Code ?? "", item.Name, item.ParentCode, item.ElementType, CoverageStatus.Undefined, null, null, [], suggested, typeId, parentId));
                continue;
            }
            hitResources.Add(r.Id);
            var scopes = m.ScopesOf(r.Id).Select(s => new ScopeState(s.Key, m.PermissionsFor(s.Id).Count > 0)).ToList();
            ui.Add(new(item.Code ?? "", item.Name, item.ParentCode, item.ElementType,
                scopes.Any(s => s.Protected) ? CoverageStatus.Protected : CoverageStatus.NoPermission, r.Id, r.Code, scopes, suggested, typeId, parentId));
        }
        var staleUi = uiSnap is null ? [] : uiResources.Where(r => !hitResources.Contains(r.Id))
            .Select(r => new StaleUi(r.Id, r.Code, r.Name, m.ResourceTypes[r.ResourceTypeId].Code, r.ExternalCode)).OrderBy(x => x.Code).ToList();

        return new CoverageReport(app.Id, app.Code,
            endpointSnap is null ? null : Info(endpointSnap, endpointSnap.Items.Count),
            uiSnap is null ? null : Info(uiSnap, uiSnap.Items.Count),
            endpoints, staleUris, ui, staleUi);
    }

    // ================================ Ayrıştırma ================================

    private static List<InventoryItem> ParseEndpoints(InventoryImport dto)
    {
        var prefix = string.IsNullOrWhiteSpace(dto.PathPrefix) ? "" : "/" + dto.PathPrefix.Trim().Trim('/');
        var list = new List<InventoryItem>();
        if (dto.Format == InventoryFormat.OpenApi)
        {
            JsonDocument doc;
            try { doc = JsonDocument.Parse(dto.Content); }
            catch (JsonException ex) { throw new ValidationException($"OpenAPI JSON okunamadı: {ex.Message}"); }
            using (doc)
            {
                var root = doc.RootElement;
                // Swagger 2.0 basePath
                if (root.TryGetProperty("basePath", out var bp) && bp.GetString() is { Length: > 1 } basePath) prefix += "/" + basePath.Trim('/');
                if (!root.TryGetProperty("paths", out var paths) || paths.ValueKind != JsonValueKind.Object)
                    throw new ValidationException("OpenAPI belgesinde 'paths' bulunamadı.");
                foreach (var path in paths.EnumerateObject())
                {
                    if (path.Value.ValueKind != JsonValueKind.Object) continue;
                    foreach (var op in path.Value.EnumerateObject())
                    {
                        var method = op.Name.ToUpperInvariant();
                        if (!Methods.Contains(method)) continue;
                        string? name = null;
                        if (op.Value.ValueKind == JsonValueKind.Object)
                            name = (op.Value.TryGetProperty("summary", out var s) ? s.GetString() : null)
                                   ?? (op.Value.TryGetProperty("operationId", out var o) ? o.GetString() : null);
                        list.Add(new InventoryItem { Method = method, Path = NormalizePath(prefix + path.Name), Name = Trim(name, 160) });
                    }
                }
            }
        }
        else
        {
            foreach (var raw in Lines(dto.Content))
            {
                var parts = raw.Split([' ', '\t'], 3, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length < 2) throw new ValidationException($"Satır okunamadı (beklenen: METHOD /yol [açıklama]): {raw}");
                var method = parts[0].ToUpperInvariant();
                if (!Methods.Contains(method)) throw new ValidationException($"Geçersiz HTTP metodu: {parts[0]} ({raw})");
                list.Add(new InventoryItem { Method = method, Path = NormalizePath(prefix + parts[1]), Name = Trim(parts.Length > 2 ? parts[2] : null, 160) });
            }
        }
        return list.DistinctBy(i => (i.Method, i.Path?.ToLowerInvariant())).ToList();
    }

    private static List<InventoryItem> ParseUi(InventoryImport dto)
    {
        var list = new List<InventoryItem>();
        if (dto.Format == InventoryFormat.Json)
        {
            JsonDocument doc;
            try { doc = JsonDocument.Parse(dto.Content); }
            catch (JsonException ex) { throw new ValidationException($"JSON okunamadı: {ex.Message}"); }
            using (doc)
            {
                if (doc.RootElement.ValueKind != JsonValueKind.Array) throw new ValidationException("Beklenen: [{\"code\":\"GVADAG00\",\"name\":\"...\",\"parent\":\"...\",\"type\":\"SCREEN\"}]");
                foreach (var e in doc.RootElement.EnumerateArray())
                {
                    string? P(string n) => e.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;
                    var code = P("code") ?? throw new ValidationException("Her öğede 'code' olmalı.");
                    list.Add(new InventoryItem { Code = Trim(code, 64), Name = Trim(P("name"), 160), ParentCode = Trim(P("parent"), 64), ElementType = Trim(P("type")?.ToUpperInvariant(), 32) });
                }
            }
        }
        else
        {
            foreach (var raw in Lines(dto.Content))
            {
                var p = raw.Split(';').Select(x => x.Trim()).ToArray();
                if (p[0].Length == 0) throw new ValidationException($"Satır okunamadı (beklenen: KOD;Ad;ÜstKod;Tip): {raw}");
                list.Add(new InventoryItem
                {
                    Code = Trim(p[0], 64), Name = Trim(p.ElementAtOrDefault(1), 160),
                    ParentCode = Trim(p.ElementAtOrDefault(2), 64), ElementType = Trim(p.ElementAtOrDefault(3)?.ToUpperInvariant(), 32)
                });
            }
        }
        return list.DistinctBy(i => i.Code!.ToUpperInvariant()).ToList();
    }

    // ================================ Öneriler ================================

    /// <summary>HTTP metodundan scope önerisi (sadece öneri; karar yetki ekibinindir): GET → view, POST → create, PUT/PATCH → update, DELETE → delete.</summary>
    public static string SuggestScope(string method) => method.ToUpperInvariant() switch
    {
        "GET" => "view",
        "PUT" or "PATCH" => "update",
        "DELETE" => "delete",
        _ => "create"
    };

    private static string SuggestCode(string app, string group)
    {
        var segs = group.Split('/', StringSplitOptions.RemoveEmptyEntries).Where(s => !IsVersion(s)).ToList();
        return $"{app.ToLowerInvariant()}.{(segs.Count > 0 ? Slug(segs[^1]) : "yeni")}";
    }

    private static int? SuggestType(AuthorizationModel m, string? elementType) =>
        (elementType is null ? null : m.ResourceTypes.Values.FirstOrDefault(t => string.Equals(t.Code, elementType, StringComparison.OrdinalIgnoreCase))?.Id)
        ?? m.ResourceTypes.Values.Where(t => !t.MatchesHttp && t.IsActive).OrderBy(t => t.Code).Select(t => (int?)t.Id).FirstOrDefault();

    // ================================ Yardımcılar ================================

    private static InventorySnapshotInfo Info(InventorySnapshot s, int count) => new(s.Kind, s.Source, s.ImportedAt, s.ImportedBy, count);

    private static IEnumerable<string> Lines(string content) =>
        content.Split('\n').Select(l => l.Trim()).Where(l => l.Length > 0 && !l.StartsWith('#'));

    private static string NormalizePath(string p)
    {
        var path = p.Trim().Split('?')[0];
        var segs = path.Split('/', StringSplitOptions.RemoveEmptyEntries);
        return "/" + string.Join('/', segs);
    }

    private static bool IsVersion(string s) => s.Length >= 2 && (s[0] == 'v' || s[0] == 'V') && s[1..].All(char.IsDigit);

    private static string Slug(string s)
    {
        var chars = s.ToLowerInvariant().Where(c => char.IsLetterOrDigit(c) && c < 128).ToArray();
        var slug = new string(chars);
        return slug.Length == 0 ? "oge" : char.IsLetter(slug[0]) ? slug : "x" + slug;
    }

    private static string? Trim(string? s, int max = 512) =>
        string.IsNullOrWhiteSpace(s) ? null : s.Trim().Length > max ? s.Trim()[..max] : s.Trim();
}
