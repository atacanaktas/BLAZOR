using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Changes;
using Yetki.Application.Common;
using Yetki.Application.Events;
using Yetki.Application.Model;
using Yetki.Domain.Common;
using Yetki.Domain.Policies;

namespace Yetki.Application.Definitions;

public sealed class PermissionUpsert
{
    public int ApplicationId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    /// <summary>Neye uygulanır? Açıkça seçilir; boş liste "tümü" değil "hiçbiri" demektir.</summary>
    public PermissionTarget Target { get; set; } = PermissionTarget.Resources;
    /// <summary>Sadece Target = ResourceType.</summary>
    public int? ResourceTypeId { get; set; }
    /// <summary>Sadece Target = Resources. Boşsa permission atıldır (hiçbir yetkiyi etkilemez).</summary>
    public List<int> ResourceIds { get; set; } = new();
    /// <summary>true: kapsamdaki resource'ların tüm scope'ları. false: sadece ScopeIds (boşsa atıl).</summary>
    public bool AllScopes { get; set; }
    public List<int> ScopeIds { get; set; } = new();
    public List<int> PolicyIds { get; set; } = new();
    public DecisionStrategy DecisionStrategy { get; set; } = DecisionStrategy.Unanimous;
    public bool IsActive { get; set; } = true;
}

/// <summary>
/// Keycloak permission yönetimi: resource / resource tipi / scope kapsamını policy'lere bağlar.
/// Her değişiklik önce What-If modelinde kurulur ve etkisi (kim kazanır / kaybeder, SoD, RACF/LDAP) hesaplanır;
/// dryRun=false'ta SoD Block varsa reddedilir, yoksa uygulanır ve erişimi değişen kullanıcılar için mutabakat olayı yazılır.
/// </summary>
public sealed class PermissionService(IYetkiDbContext db, AuthorizationModelProvider models, AuthorizationChangeService changes)
{
    public async Task<DefinitionChangeResult> CreateAsync(PermissionUpsert dto, bool dryRun, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Permissions.AnyAsync(p => p.Code == code, ct)) throw new ConflictException($"Permission kodu zaten var: {code}");
        var warnings = await ValidateAsync(dto, ct);
        const int draftId = -1;

        void Mutate(ModelData d)
        {
            d.Permissions.Add(new PermissionRow(draftId, dto.ApplicationId, code, dto.Name, dto.Target, dto.ResourceTypeId, dto.AllScopes, dto.DecisionStrategy, dto.IsActive, 1));
            AddRelations(d, draftId, dto);
        }

        if (dryRun) return new DefinitionChangeResult(null, await changes.AnalyzeAsync(Mutate, true, ct), warnings);
        Permission? created = null;
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Mutate = Mutate,
            ApplyEntities = () =>
            {
                created = new Permission
                {
                    ApplicationId = dto.ApplicationId, Code = code, Name = dto.Name, Description = dto.Description,
                    Target = dto.Target, ResourceTypeId = dto.ResourceTypeId, AllScopes = dto.AllScopes, DecisionStrategy = dto.DecisionStrategy, IsActive = dto.IsActive,
                    Resources = dto.ResourceIds.Distinct().Select(r => new PermissionResource { ResourceId = r }).ToList(),
                    Scopes = dto.ScopeIds.Distinct().Select(s => new PermissionScope { ScopeId = s }).ToList(),
                    Policies = dto.PolicyIds.Distinct().Select((p, i) => new PermissionPolicy { PolicyId = p, Order = i }).ToList()
                };
                db.Permissions.Add(created);
                return Task.CompletedTask;
            },
            EventType = EventTypes.PermissionChanged, AggregateType = "Permission", AggregateId = code,
            EventPayload = new { action = "created", code, dto.Target, dto.ResourceTypeId, dto.ResourceIds, dto.AllScopes, dto.ScopeIds, dto.PolicyIds },
            AuditSummary = $"Permission oluşturuldu: {code}"
        }, ct);
        return new DefinitionChangeResult(created?.Id, impact, warnings);
    }

    public async Task<DefinitionChangeResult> UpdateAsync(int id, PermissionUpsert dto, bool dryRun, CancellationToken ct)
    {
        var p = await db.Permissions.Include(x => x.Resources).Include(x => x.Scopes).Include(x => x.Policies).FirstOrDefaultAsync(x => x.Id == id, ct)
                ?? throw new NotFoundException("Permission", id);
        dto.ApplicationId = p.ApplicationId;
        var warnings = await ValidateAsync(dto, ct);

        void Mutate(ModelData d)
        {
            var i = d.Permissions.FindIndex(x => x.Id == id);
            d.Permissions[i] = d.Permissions[i] with { Name = dto.Name, Target = dto.Target, ResourceTypeId = dto.ResourceTypeId, AllScopes = dto.AllScopes, Strategy = dto.DecisionStrategy, IsActive = dto.IsActive };
            d.PermissionResources.RemoveAll(x => x.PermissionId == id);
            d.PermissionScopes.RemoveAll(x => x.PermissionId == id);
            d.PermissionPolicies.RemoveAll(x => x.PermissionId == id);
            AddRelations(d, id, dto);
        }

        if (dryRun) return new DefinitionChangeResult(id, await changes.AnalyzeAsync(Mutate, true, ct), warnings);
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Mutate = Mutate,
            ApplyEntities = () =>
            {
                p.Name = dto.Name; p.Description = dto.Description; p.Target = dto.Target; p.ResourceTypeId = dto.ResourceTypeId; p.AllScopes = dto.AllScopes; p.DecisionStrategy = dto.DecisionStrategy;
                p.IsActive = dto.IsActive; p.Version++;
                db.PermissionResources.RemoveRange(p.Resources);
                db.PermissionScopes.RemoveRange(p.Scopes);
                db.PermissionPolicies.RemoveRange(p.Policies);
                foreach (var r in dto.ResourceIds.Distinct()) db.PermissionResources.Add(new PermissionResource { PermissionId = id, ResourceId = r });
                foreach (var s in dto.ScopeIds.Distinct()) db.PermissionScopes.Add(new PermissionScope { PermissionId = id, ScopeId = s });
                foreach (var (pid, i) in dto.PolicyIds.Distinct().Select((x, i) => (x, i))) db.PermissionPolicies.Add(new PermissionPolicy { PermissionId = id, PolicyId = pid, Order = i });
                return Task.CompletedTask;
            },
            EventType = EventTypes.PermissionChanged, AggregateType = "Permission", AggregateId = p.Code,
            EventPayload = new { action = "updated", p.Code, dto.Target, dto.ResourceTypeId, dto.ResourceIds, dto.AllScopes, dto.ScopeIds, dto.PolicyIds, dto.IsActive },
            AuditSummary = $"Permission güncellendi: {p.Code} v{p.Version + 1} (aktif={dto.IsActive})"
        }, ct);
        return new DefinitionChangeResult(id, impact, warnings);
    }

    public async Task<DefinitionChangeResult> DeleteAsync(int id, bool dryRun, CancellationToken ct)
    {
        var p = await db.Permissions.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Permission", id);

        void Mutate(ModelData d)
        {
            d.Permissions.RemoveAll(x => x.Id == id);
            d.PermissionResources.RemoveAll(x => x.PermissionId == id);
            d.PermissionScopes.RemoveAll(x => x.PermissionId == id);
            d.PermissionPolicies.RemoveAll(x => x.PermissionId == id);
        }

        if (dryRun) return new DefinitionChangeResult(id, await changes.AnalyzeAsync(Mutate, true, ct), []);
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Mutate = Mutate,
            ApplyEntities = () => { db.Permissions.Remove(p); return Task.CompletedTask; },
            EventType = EventTypes.PermissionChanged, AggregateType = "Permission", AggregateId = p.Code,
            EventPayload = new { action = "deleted", p.Code },
            AuditSummary = $"Permission silindi: {p.Code}"
        }, ct);
        return new DefinitionChangeResult(id, impact, []);
    }

    private static void AddRelations(ModelData d, int id, PermissionUpsert dto)
    {
        d.PermissionResources.AddRange(dto.ResourceIds.Distinct().Select(r => new PermissionResourceRow(id, r)));
        d.PermissionScopes.AddRange(dto.ScopeIds.Distinct().Select(s => new PermissionScopeRow(id, s)));
        d.PermissionPolicies.AddRange(dto.PolicyIds.Distinct().Select((p, i) => new PermissionPolicyRow(id, p, i)));
    }

    /// <summary>
    /// Kapsam ve policy'leri doğrular. Hedef türüne ait olmayan alanlar temizlenir (tip hedefinde resource listesi, resource hedefinde tip...),
    /// böylece kapsam her zaman seçilen hedef türünden okunur. Uyarılar: kimlik policy'si yok (koşulu sağlayan HERKESE açılır),
    /// tüm uygulama hedefi, kapsamı boş (atıl) permission.
    /// </summary>
    private async Task<List<string>> ValidateAsync(PermissionUpsert dto, CancellationToken ct)
    {
        var model = await models.GetCurrentAsync(ct);
        if (!model.Apps.ContainsKey(dto.ApplicationId)) throw new NotFoundException("Uygulama", dto.ApplicationId);
        if (!Enum.IsDefined(dto.Target)) throw new ValidationException("Geçersiz hedef türü.");
        if (dto.Target == PermissionTarget.ResourceType)
        {
            if (dto.ResourceTypeId is not { } t) throw new ValidationException("Tip hedefinde resource tipi seçilmelidir.");
            if (!model.ResourceTypes.ContainsKey(t)) throw new NotFoundException("Resource tipi", t);
        }
        if (dto.Target != PermissionTarget.ResourceType) dto.ResourceTypeId = null;
        if (dto.Target != PermissionTarget.Resources) dto.ResourceIds = [];
        if (dto.AllScopes) dto.ScopeIds = [];
        var wrongResource = dto.ResourceIds.Where(r => !model.Resources.TryGetValue(r, out var row) || row.ApplicationId != dto.ApplicationId).ToList();
        if (wrongResource.Count > 0) throw new ValidationException("Resource'lar permission'ın uygulamasına ait olmalı.");
        var wrongScope = dto.ScopeIds.Where(s => !model.Scopes.TryGetValue(s, out var row) || row.ApplicationId != dto.ApplicationId).ToList();
        if (wrongScope.Count > 0) throw new ValidationException("Scope'lar permission'ın uygulamasına ait olmalı.");
        if (dto.PolicyIds.Count == 0) throw new ValidationException("Permission en az bir policy içermelidir.");
        var missing = dto.PolicyIds.Where(p => !model.Policies.ContainsKey(p)).ToList();
        if (missing.Count > 0) throw new ValidationException($"Bulunamayan policy: {string.Join(", ", missing)}");

        var warnings = new List<string>();
        var draft = new CompiledPermission(new PermissionRow(0, dto.ApplicationId, dto.Code, dto.Name, dto.Target, dto.ResourceTypeId, dto.AllScopes, dto.DecisionStrategy, dto.IsActive, 1),
            model.Apps[dto.ApplicationId], dto.ResourceIds.ToHashSet(), dto.ScopeIds.ToHashSet(), dto.PolicyIds);
        if (!model.HasIdentityPolicy(draft))
            warnings.Add("Bu permission rol / grup / kullanıcı policy'si içermiyor. Tek permission olduğu yetkilerde koşulları sağlayan HERKES erişir; " +
                         "başka permission'larla birlikte (uygulama stratejisi Unanimous) ise ek kısıt gibi davranır.");
        if (dto.Target == PermissionTarget.Application)
            warnings.Add("Hedef: uygulamadaki TÜM resource'lar — sonradan eklenen resource'lar da kendiliğinden bu permission'ın kitlesine açılır.");
        if (dto.Target == PermissionTarget.Resources && dto.ResourceIds.Count == 0)
            warnings.Add("Resource seçilmedi: permission atıl kalır (hiçbir yetkiyi etkilemez).");
        if (!dto.AllScopes && dto.ScopeIds.Count == 0)
            warnings.Add("Scope seçilmedi: permission atıl kalır (hiçbir yetkiyi etkilemez).");
        var coverage = model.ResourceScopes.Values.Count(draft.Applies);
        if (coverage == 0 && warnings.All(w => !w.Contains("atıl"))) warnings.Add("Kapsamda hiç yetki (resource:scope) yok: permission atıl.");
        return warnings;
    }
}
