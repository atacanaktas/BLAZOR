using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Changes;
using Yetki.Application.Common;
using Yetki.Application.Events;
using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Domain.Common;
using Yetki.Domain.Policies;

namespace Yetki.Application.Definitions;

public sealed class PolicyUpsert
{
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public PolicyType Type { get; set; }
    public PolicyLogic Logic { get; set; } = PolicyLogic.Positive;
    public DecisionStrategy DecisionStrategy { get; set; } = DecisionStrategy.Unanimous;
    public PolicyMode Mode { get; set; } = PolicyMode.Enforce;
    public bool IsActive { get; set; } = true;
    /// <summary>Tipine göre rol / grup / kullanıcı / client id'leri veya (Aggregate) alt policy id'leri. Condition'da boş.</summary>
    public List<int> MemberIds { get; set; } = new();
}

public sealed class RuleUpsert
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public int Order { get; set; }
    public string? ReasonCode { get; set; }
    public bool IsActive { get; set; } = true;
    public ConditionDraft Condition { get; set; } = new();
}

public sealed class ObligationUpsert
{
    public string Code { get; set; } = default!;
    public ObligationFulfillOn FulfillOn { get; set; } = ObligationFulfillOn.Permit;
    public int Order { get; set; }
    public Dictionary<string, string> Parameters { get; set; } = new();
}

/// <summary>Tanım değişikliği sonucu: kayıt id'si + erişim etkisi (dryRun'da uygulanmaz) + uyarılar.</summary>
public sealed record DefinitionChangeResult(int? Id, ChangeImpactResult Impact, IReadOnlyList<string> Warnings);

/// <summary>
/// Policy yönetimi (Keycloak policy tipleri + ABAC condition):
///  - Rol / grup / kullanıcı / client / aggregate policy'lerinde üye değişikliği erişimi değiştirir → etki analizi (dryRun ile önizleme),
///    SoD Block kontrolü ve RACF/LDAP mutabakatı AuthorizationChangeService üzerinden.
///  - Condition policy kuralları ve parametreleri ilgili IConditionHandler'a doğrulatılır; etkisi What-If "policy impact" ile görülür.
///  - Her değişiklik Policy.Version'ı artırır; kararlar versiyonla audit'lenir; PolicyChanged event'i üretilir.
/// </summary>
public sealed class PolicyManagementService(
    IYetkiDbContext db,
    ConditionHandlerRegistry handlers,
    AuthorizationModelProvider models,
    AuthorizationChangeService changes,
    OutboxWriter outbox,
    AuditWriter audit)
{
    // ================================ Policy ================================

    public async Task<DefinitionChangeResult> CreatePolicyAsync(PolicyUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Policies.AnyAsync(p => p.Code == code, ct)) throw new ConflictException($"Policy kodu zaten var: {code}");
        if (!await db.Tenants.AnyAsync(o => o.Id == dto.TenantId, ct)) throw new NotFoundException("Kurum", dto.TenantId);
        var members = await ValidateMembersAsync(dto.Type, dto.MemberIds, null, ct);
        var p = new Policy
        {
            TenantId = dto.TenantId, Code = code, Name = dto.Name, Description = dto.Description, Type = dto.Type, Logic = dto.Logic,
            DecisionStrategy = dto.DecisionStrategy, Mode = dto.Mode, IsActive = dto.IsActive, Version = 1,
            Members = members.Select(m => new PolicyMember { MemberId = m }).ToList()
        };
        db.Policies.Add(p);
        audit.Management("PolicyCreated", "Policy", code, $"Policy oluşturuldu: {code} ({dto.Type}, {dto.Logic}, {members.Count} üye)", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", code, new { action = "created", code, dto.Type });
        await db.SaveChangesAsync(ct);
        // Henüz hiçbir permission kullanmadığı için erişim değişmez.
        return new DefinitionChangeResult(p.Id, new ChangeImpactResult { DryRun = false, Applied = true, Summary = "Yeni policy henüz bir permission'da kullanılmıyor; erişim değişmez." }, []);
    }

    /// <summary>Policy'yi (üyeler, logic, strateji, mod, aktiflik) günceller. dryRun: sadece erişim etkisi döner.</summary>
    public async Task<DefinitionChangeResult> UpdatePolicyAsync(int id, PolicyUpsert dto, bool dryRun, CancellationToken ct)
    {
        var p = await db.Policies.Include(x => x.Members).FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Policy", id);
        if (dto.Type != p.Type) throw new ValidationException("Policy tipi değiştirilemez; yeni policy oluşturun.");
        var members = await ValidateMembersAsync(p.Type, dto.MemberIds, id, ct);

        void Mutate(ModelData d)
        {
            var i = d.Policies.FindIndex(x => x.Id == id);
            d.Policies[i] = d.Policies[i] with { Name = dto.Name, Logic = dto.Logic, Strategy = dto.DecisionStrategy, Mode = dto.Mode, IsActive = dto.IsActive };
            d.PolicyMembers.RemoveAll(m => m.PolicyId == id);
            d.PolicyMembers.AddRange(members.Select(m => new PolicyMemberRow(id, m)));
        }

        if (dryRun) return new DefinitionChangeResult(id, await changes.AnalyzeAsync(Mutate, true, ct), []);
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Mutate = Mutate,
            ApplyEntities = () =>
            {
                p.Name = dto.Name; p.Description = dto.Description; p.Logic = dto.Logic; p.DecisionStrategy = dto.DecisionStrategy;
                p.Mode = dto.Mode; p.IsActive = dto.IsActive; p.Version++;
                foreach (var m in p.Members.Where(m => !members.Contains(m.MemberId)).ToList()) db.PolicyMembers.Remove(m);
                foreach (var m in members.Where(m => p.Members.All(x => x.MemberId != m))) db.PolicyMembers.Add(new PolicyMember { PolicyId = id, MemberId = m });
                return Task.CompletedTask;
            },
            EventType = EventTypes.PolicyChanged, AggregateType = "Policy", AggregateId = p.Code,
            EventPayload = new { action = "updated", p.Code, dto.Logic, dto.Mode, dto.IsActive, members },
            AuditSummary = $"Policy güncellendi: {p.Code} v{p.Version + 1} ({dto.Logic}, {dto.Mode}, aktif={dto.IsActive}, {members.Count} üye)"
        }, ct);
        return new DefinitionChangeResult(id, impact, []);
    }

    public async Task DeletePolicyAsync(int id, CancellationToken ct)
    {
        var p = await db.Policies.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Policy", id);
        var usage = new
        {
            permissions = await db.PermissionPolicies.Where(x => x.PolicyId == id).Select(x => x.Permission.Code).ToListAsync(ct),
            aggregates = await db.PolicyMembers.Where(m => m.MemberId == id && m.Policy.Type == PolicyType.Aggregate).Select(m => m.Policy.Code).ToListAsync(ct)
        };
        if (usage.permissions.Count + usage.aggregates.Count > 0) throw new ConflictException($"'{p.Code}' kullanımda; silinemez.", usage);
        foreach (var rule in await db.Rules.Where(r => r.PolicyId == id).ToListAsync(ct))
            RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.RuleId == rule.Id).ToListAsync(ct));
        db.Policies.Remove(p);
        audit.Management("PolicyDeleted", "Policy", p.Code, $"Policy silindi: {p.Code}");
        outbox.Add(EventTypes.PolicyChanged, "Policy", p.Code, new { action = "deleted", p.Code });
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Üyeleri tipe göre doğrular: rol / grup / kullanıcı / client (aracı olamaz) / alt policy (döngü olamaz). Condition'da üye yok.</summary>
    private async Task<List<int>> ValidateMembersAsync(PolicyType type, List<int> ids, int? selfId, CancellationToken ct)
    {
        var members = ids.Distinct().ToList();
        if (type == PolicyType.Condition)
        {
            if (members.Count > 0) throw new ValidationException("Condition policy'nin üyesi olmaz; koşullar kurallarla tanımlanır.");
            return members;
        }
        if (members.Count == 0) throw new ValidationException("Policy en az bir üye içermelidir.");
        var model = await models.GetCurrentAsync(ct);
        var missing = type switch
        {
            PolicyType.Role => members.Where(m => !model.Roles.ContainsKey(m)).ToList(),
            PolicyType.Group => members.Where(m => !model.Groups.ContainsKey(m)).ToList(),
            PolicyType.User => members.Where(m => !model.Users.ContainsKey(m)).ToList(),
            PolicyType.Client => members.Where(m => !model.ClientsByPk.ContainsKey(m)).ToList(),
            _ => members.Where(m => !model.Policies.ContainsKey(m)).ToList()
        };
        if (missing.Count > 0) throw new ValidationException($"Bulunamayan üye(ler): {string.Join(", ", missing)}");
        if (type == PolicyType.Client && members.Any(m => model.ClientsByPk[m].Type == ClientType.Intermediary))
            throw new ValidationException("Aracı (gateway/BFF) client'lar kanal policy'sine eklenemez; isteği başlatan client seçilmeli.");
        if (type == PolicyType.Aggregate && selfId is { } self)
        {
            // self → üye → ... → self döngüsü
            var stack = new Stack<int>(members);
            var seen = new HashSet<int>();
            while (stack.Count > 0)
            {
                var id = stack.Pop();
                if (id == self) throw new ValidationException("Döngüsel aggregate: policy doğrudan veya dolaylı olarak kendini içeriyor.");
                if (!seen.Add(id) || !model.Policies.TryGetValue(id, out var child) || child.Row.Type != PolicyType.Aggregate) continue;
                foreach (var m in child.Members) stack.Push(m);
            }
        }
        return members;
    }

    // ------------------------------ Yükümlülük ------------------------------

    public async Task<PolicyObligation> AddObligationAsync(int policyId, ObligationUpsert dto, CancellationToken ct)
    {
        var p = await db.Policies.FindAsync([policyId], ct) ?? throw new NotFoundException("Policy", policyId);
        var code = Codes.Normalize(dto.Code);
        var parameters = ObligationTypes.Validate(code, dto.Parameters);
        var row = new PolicyObligation
        {
            PolicyId = policyId, Code = code, FulfillOn = dto.FulfillOn, Order = dto.Order,
            Parameters = parameters.Select(kv => new PolicyObligationParameter { Key = kv.Key, Value = kv.Value }).ToList()
        };
        db.PolicyObligations.Add(row);
        p.Version++;
        var text = $"{code}({string.Join(", ", parameters.Select(kv => $"{kv.Key}={kv.Value}"))}) · {dto.FulfillOn}";
        audit.Management("PolicyObligationAdded", "Policy", p.Code, $"'{p.Code}' v{p.Version}: yükümlülük eklendi → {text}", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", p.Code, new { action = "obligation-added", policy = p.Code, obligation = text, p.Version });
        await db.SaveChangesAsync(ct);
        return row;
    }

    public async Task RemoveObligationAsync(int id, CancellationToken ct)
    {
        var o = await db.PolicyObligations.Include(x => x.Policy).FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Yükümlülük", id);
        db.PolicyObligations.Remove(o);
        o.Policy.Version++;
        audit.Management("PolicyObligationRemoved", "Policy", o.Policy.Code, $"'{o.Policy.Code}' v{o.Policy.Version}: yükümlülük kaldırıldı → {o.Code}");
        outbox.Add(EventTypes.PolicyChanged, "Policy", o.Policy.Code, new { action = "obligation-removed", policy = o.Policy.Code, obligation = o.Code, o.Policy.Version });
        await db.SaveChangesAsync(ct);
    }

    // ================================ Rule (Condition policy) ================================

    public async Task<Rule> CreateRuleAsync(int policyId, RuleUpsert dto, CancellationToken ct)
    {
        var policy = await db.Policies.FindAsync([policyId], ct) ?? throw new NotFoundException("Policy", policyId);
        if (policy.Type != PolicyType.Condition) throw new ValidationException("Kural sadece Condition policy'sine eklenir.");
        var code = Codes.Normalize(dto.Code);
        if (await db.Rules.AnyAsync(r => r.PolicyId == policyId && r.Code == code, ct))
            throw new ConflictException($"'{policy.Code}' policy'sinde bu rule kodu zaten var: {code}");
        var v = await ValidateConditionAsync(dto.Condition, ct);

        var rule = new Rule
        {
            PolicyId = policyId, Code = code, Name = dto.Name, Description = dto.Description,
            Order = dto.Order, ReasonCode = NormalizeReason(dto.ReasonCode), IsActive = dto.IsActive
        };
        db.Rules.Add(rule);
        AddConditionTree(rule, null, null, dto.Condition, 0, v);
        policy.Version++;
        audit.Management("RuleCreated", "Policy", policy.Code, $"'{policy.Code}' v{policy.Version}: rule eklendi {code} (sağlanmalı: {Render(dto.Condition)})", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", policy.Code, new { action = "rule-created", policy = policy.Code, rule = code, policy.Version });
        await db.SaveChangesAsync(ct);
        return rule;
    }

    public async Task UpdateRuleAsync(int ruleId, RuleUpsert dto, CancellationToken ct)
    {
        var rule = await db.Rules.Include(r => r.Policy).FirstOrDefaultAsync(r => r.Id == ruleId, ct) ?? throw new NotFoundException("Rule", ruleId);
        var v = await ValidateConditionAsync(dto.Condition, ct);
        rule.Name = dto.Name; rule.Description = dto.Description;
        rule.Order = dto.Order; rule.ReasonCode = NormalizeReason(dto.ReasonCode); rule.IsActive = dto.IsActive;
        RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.RuleId == ruleId).ToListAsync(ct));
        AddConditionTree(rule, null, null, dto.Condition, 0, v);
        rule.Policy.Version++;
        audit.Management("RuleUpdated", "Policy", rule.Policy.Code, $"'{rule.Policy.Code}' v{rule.Policy.Version}: rule güncellendi {rule.Code} (sağlanmalı: {Render(dto.Condition)})", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", rule.Policy.Code, new { action = "rule-updated", policy = rule.Policy.Code, rule = rule.Code, rule.Policy.Version });
        await db.SaveChangesAsync(ct);
    }

    public async Task DeleteRuleAsync(int ruleId, CancellationToken ct)
    {
        var rule = await db.Rules.Include(r => r.Policy).FirstOrDefaultAsync(r => r.Id == ruleId, ct) ?? throw new NotFoundException("Rule", ruleId);
        RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.RuleId == ruleId).ToListAsync(ct));
        db.Rules.Remove(rule);
        rule.Policy.Version++;
        audit.Management("RuleDeleted", "Policy", rule.Policy.Code, $"'{rule.Policy.Code}' v{rule.Policy.Version}: rule silindi {rule.Code}");
        outbox.Add(EventTypes.PolicyChanged, "Policy", rule.Policy.Code, new { action = "rule-deleted", policy = rule.Policy.Code, rule = rule.Code, rule.Policy.Version });
        await db.SaveChangesAsync(ct);
    }

    // ================================ Condition ağacı ================================

    public sealed record ConditionValidation(IReadOnlyDictionary<string, int> Types, IReadOnlyDictionary<string, int> Shared);

    /// <summary>
    /// Condition ağacını doğrular (yapı, derinlik, predicate parametreleri, ortak koşul referansları).
    /// selfSharedId verilirse (ortak koşul düzenlerken) doğrudan/dolaylı kendine referans (döngü) reddedilir.
    /// </summary>
    public async Task<ConditionValidation> ValidateConditionAsync(ConditionDraft root, CancellationToken ct, int? selfSharedId = null)
    {
        var errors = new List<string>();
        var codes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var refs = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        void Walk(ConditionDraft n, int depth, string path)
        {
            if (depth > PolicyEvaluator.MaxConditionDepth) { errors.Add($"{path}: ağaç en fazla {PolicyEvaluator.MaxConditionDepth} seviye olabilir."); return; }
            switch (n.Kind)
            {
                case ConditionKind.Predicate:
                    if (string.IsNullOrWhiteSpace(n.ConditionTypeCode)) { errors.Add($"{path}: condition tipi zorunlu."); return; }
                    if (n.Children.Count > 0) errors.Add($"{path}: predicate çocuk içeremez.");
                    var handler = handlers.Find(n.ConditionTypeCode);
                    if (handler is null) { errors.Add($"{path}: bilinmeyen condition tipi '{n.ConditionTypeCode}'."); return; }
                    codes.Add(handler.Descriptor.Code);
                    var ps = n.Parameters.Where(kv => !string.IsNullOrWhiteSpace(kv.Value))
                        .ToDictionary(kv => kv.Key.Trim(), kv => kv.Value.Trim(), StringComparer.OrdinalIgnoreCase);
                    errors.AddRange(handler.ValidateParameters(ps).Select(e => $"{path} ({handler.Descriptor.Code}): {e}"));
                    n.Parameters = ps;
                    n.ConditionTypeCode = handler.Descriptor.Code;
                    break;
                case ConditionKind.Reference:
                    if (string.IsNullOrWhiteSpace(n.SharedConditionCode)) { errors.Add($"{path}: ortak koşul seçilmeli."); return; }
                    if (n.Children.Count > 0) errors.Add($"{path}: ortak koşul referansı çocuk içeremez.");
                    n.SharedConditionCode = Codes.Normalize(n.SharedConditionCode);
                    refs.Add(n.SharedConditionCode);
                    n.Parameters = new();
                    break;
                case ConditionKind.Not:
                    if (n.Children.Count != 1) errors.Add($"{path}: NOT tam olarak bir alt koşul içermeli.");
                    break;
                default:
                    if (n.Children.Count == 0) errors.Add($"{path}: AND/OR en az bir alt koşul içermeli.");
                    break;
            }
            for (var i = 0; i < n.Children.Count; i++) Walk(n.Children[i], depth + 1, $"{path}.{i + 1}");
        }

        Walk(root, 0, "condition");

        var refList = refs.ToList();
        var shared = await db.SharedConditions.AsNoTracking().Where(x => refList.Contains(x.Code)).Select(x => new { x.Id, x.Code, x.IsActive }).ToListAsync(ct);
        foreach (var r in refList)
        {
            var sc = shared.FirstOrDefault(x => x.Code == r);
            if (sc is null) errors.Add($"Ortak koşul bulunamadı: {r}");
            else if (!sc.IsActive) errors.Add($"Ortak koşul pasif: {r}");
        }
        if (selfSharedId is { } self && shared.Count > 0 && (await ReachableSharedAsync(shared.Select(x => x.Id), ct)).Contains(self))
            errors.Add("Döngüsel referans: ortak koşul doğrudan veya dolaylı olarak kendine referans veriyor.");

        if (errors.Count > 0) throw ValidationException.Of("condition", errors);

        var codeList = codes.ToList();
        var types = await db.ConditionTypes.Where(t => codeList.Contains(t.Code) && t.IsAvailable).ToDictionaryAsync(t => t.Code, t => t.Id, StringComparer.OrdinalIgnoreCase, ct);
        var missing = codeList.Where(c => !types.ContainsKey(c)).ToList();
        if (missing.Count > 0) throw new ValidationException($"Katalogda olmayan condition tipi: {string.Join(", ", missing)}");
        return new ConditionValidation(types, shared.ToDictionary(x => x.Code, x => x.Id, StringComparer.OrdinalIgnoreCase));
    }

    private async Task<HashSet<int>> ReachableSharedAsync(IEnumerable<int> start, CancellationToken ct)
    {
        var edges = (await db.RuleConditions.AsNoTracking().Where(c => c.SharedConditionId != null && c.ReferencedSharedConditionId != null)
                .Select(c => new { From = c.SharedConditionId!.Value, To = c.ReferencedSharedConditionId!.Value }).ToListAsync(ct))
            .ToLookup(e => e.From, e => e.To);
        var seen = new HashSet<int>();
        var stack = new Stack<int>(start);
        while (stack.Count > 0)
        {
            var id = stack.Pop();
            if (!seen.Add(id)) continue;
            foreach (var next in edges[id]) stack.Push(next);
        }
        return seen;
    }

    /// <summary>Condition ağacını entity olarak ekler. Sahibi ya bir rule ya da bir ortak koşuldur.</summary>
    internal void AddConditionTree(Rule? rule, SharedCondition? owner, RuleCondition? parent, ConditionDraft draft, int order, ConditionValidation v)
    {
        var node = new RuleCondition
        {
            Rule = rule, SharedCondition = owner, Parent = parent, Kind = draft.Kind, Order = order,
            ConditionTypeId = draft.Kind == ConditionKind.Predicate ? v.Types[draft.ConditionTypeCode!] : null,
            ReferencedSharedConditionId = draft.Kind == ConditionKind.Reference ? v.Shared[draft.SharedConditionCode!] : null,
            Parameters = draft.Kind == ConditionKind.Predicate
                ? draft.Parameters.Select(kv => new ConditionParameter { Key = kv.Key, Value = kv.Value }).ToList()
                : new List<ConditionParameter>()
        };
        db.RuleConditions.Add(node);
        for (var i = 0; i < draft.Children.Count; i++) AddConditionTree(rule, owner, node, draft.Children[i], i, v);
    }

    internal void RemoveNodes(List<RuleCondition> nodes)
    {
        foreach (var n in nodes)
        {
            foreach (var p in n.Parameters.ToList()) db.ConditionParameters.Remove(p);
            db.RuleConditions.Remove(n);
        }
    }

    private static string? NormalizeReason(string? reason) => string.IsNullOrWhiteSpace(reason) ? null : Codes.Normalize(reason);

    public static string Render(ConditionDraft d) => PolicyEvaluator.Render(PolicyCompiler.FromDraftUnresolved(d));
}
