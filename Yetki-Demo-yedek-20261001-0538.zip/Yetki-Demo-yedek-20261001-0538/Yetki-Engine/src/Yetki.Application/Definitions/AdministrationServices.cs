using Yetki.Application.Identity;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Events;
using Yetki.Application.Governance;
using Yetki.Application.Model;
using Yetki.Domain.Clients;
using Yetki.Domain.Common;
using Yetki.Domain.Governance;
using Yetki.Domain.Tenants;

namespace Yetki.Application.Definitions;

// ================================ Kurum ================================

public sealed class TenantUpsert
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public TenantType Type { get; set; } = TenantType.Subsidiary;
    public int? ParentId { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class OrgUnitUpsert
{
    public int TenantId { get; set; }
    public int? ParentId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public OrgUnitType Type { get; set; } = OrgUnitType.Branch;
    public bool IsActive { get; set; } = true;
}

public sealed class TenantService(IYetkiDbContext db, AuditWriter audit)
{
    public async Task<Tenant> CreateAsync(TenantUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Tenants.AnyAsync(o => o.Code == code, ct)) throw new ConflictException($"Kurum kodu zaten var: {code}");
        if (dto.ParentId is { } p && !await db.Tenants.AnyAsync(o => o.Id == p, ct)) throw new NotFoundException("Üst kurum", p);
        var tenant = new Tenant { Code = code, Name = dto.Name, Type = dto.Type, ParentId = dto.ParentId, IsActive = dto.IsActive };
        db.Tenants.Add(tenant);
        audit.Management("TenantCreated", "Tenant", code, $"Kurum eklendi: {code}", dto);
        await db.SaveChangesAsync(ct);
        return tenant;
    }

    public async Task<OrgUnit> CreateUnitAsync(OrgUnitUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.OrgUnits.AnyAsync(u => u.TenantId == dto.TenantId && u.Code == code, ct)) throw new ConflictException($"Birim kodu zaten var: {code}");
        if (dto.ParentId is { } p)
        {
            var parent = await db.OrgUnits.FindAsync([p], ct) ?? throw new NotFoundException("Üst birim", p);
            if (parent.TenantId != dto.TenantId) throw new ValidationException("Üst birim aynı kurumda olmalı.");
        }
        var unit = new OrgUnit { TenantId = dto.TenantId, ParentId = dto.ParentId, Code = code, Name = dto.Name, Type = dto.Type, IsActive = dto.IsActive };
        db.OrgUnits.Add(unit);
        audit.Management("OrgUnitCreated", "OrgUnit", code, $"Birim eklendi: {code} ({dto.Type})", dto);
        await db.SaveChangesAsync(ct);
        return unit;
    }
}

// ================================ Client ================================

public sealed class ClientUpsert
{
    /// <summary>Client'ı kaydeden tenant (oluştururken zorunlu). Client bu tenant ve alt tenant'larında kullanılabilir.</summary>
    public int TenantId { get; set; }
    public string ClientId { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ClientType Type { get; set; }
    public int? ApplicationId { get; set; }
    public int? ServiceAccountUserId { get; set; }
    public bool IsActive { get; set; } = true;
    /// <summary>Soru kapsamı: hakkında soru sorabileceği uygulamalar (boşsa hiçbiri).</summary>
    public List<int> QueryApplicationIds { get; set; } = new();
    /// <summary>Soru kapsamı: kullanıcıları için soru sorabileceği kurumlar; alt kurumlar dahil (boşsa hiçbiri).</summary>
    public List<int> QueryTenantIds { get; set; } = new();
    /// <summary>Sadece aracı (Intermediary): adına soru sorabileceği client'lar.</summary>
    public List<int> OnBehalfOfClientIds { get; set; } = new();
    public int? RateLimitPerMinute { get; set; }
}

/// <summary>
/// OAuth client kayıtları. Kanal kısıtları Client policy'leriyle permission'lara eklenir; client değişikliği KARARI değiştirebilir,
/// bu nedenle audit + event üretir.
/// </summary>
public sealed class ClientService(IIdentityProvider identities, IYetkiDbContext db, OutboxWriter outbox, AuditWriter audit)
{
    public async Task<Client> CreateAsync(ClientUpsert dto, CancellationToken ct)
    {
        var id = Codes.Lower(dto.ClientId);
        if (await db.Clients.AnyAsync(c => c.ClientId == id, ct)) throw new ConflictException($"client_id zaten var: {id}");
        await ValidateAsync(dto, ct);
        var c = new Client
        {
            TenantId = dto.TenantId, ClientId = id, Name = dto.Name, Description = dto.Description, Type = dto.Type, ApplicationId = dto.ApplicationId,
            ServiceAccountUserId = dto.Type == ClientType.Service ? dto.ServiceAccountUserId : null, IsActive = dto.IsActive,
            RateLimitPerMinute = dto.RateLimitPerMinute,
            QueryApplications = dto.QueryApplicationIds.Distinct().Select(a => new ClientQueryApplication { ApplicationId = a }).ToList(),
            QueryTenants = dto.QueryTenantIds.Distinct().Select(t => new ClientQueryTenant { TenantId = t }).ToList(),
            Delegations = dto.Type == ClientType.Intermediary ? dto.OnBehalfOfClientIds.Distinct().Select(x => new ClientDelegation { OnBehalfOfClientId = x }).ToList() : []
        };
        db.Clients.Add(c);
        Changed("ClientCreated", id, $"Client eklendi: {id} ({dto.Type})", dto);
        await db.SaveChangesAsync(ct);
        return c;
    }

    public async Task UpdateAsync(int id, ClientUpsert dto, CancellationToken ct)
    {
        var c = await db.Clients.Include(x => x.QueryApplications).Include(x => x.QueryTenants).Include(x => x.Delegations)
                    .FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Client", id);
        dto.TenantId = c.TenantId; // tenant sonradan değiştirilemez
        await ValidateAsync(dto, ct, id);
        c.Name = dto.Name; c.Description = dto.Description; c.Type = dto.Type; c.ApplicationId = dto.ApplicationId; c.IsActive = dto.IsActive;
        c.ServiceAccountUserId = dto.Type == ClientType.Service ? dto.ServiceAccountUserId : null;
        c.RateLimitPerMinute = dto.RateLimitPerMinute;
        db.ClientQueryApplications.RemoveRange(c.QueryApplications);
        db.ClientQueryTenants.RemoveRange(c.QueryTenants);
        db.ClientDelegations.RemoveRange(c.Delegations);
        foreach (var a in dto.QueryApplicationIds.Distinct()) db.ClientQueryApplications.Add(new ClientQueryApplication { ClientId = c.Id, ApplicationId = a });
        foreach (var t in dto.QueryTenantIds.Distinct()) db.ClientQueryTenants.Add(new ClientQueryTenant { ClientId = c.Id, TenantId = t });
        if (dto.Type == ClientType.Intermediary)
            foreach (var x in dto.OnBehalfOfClientIds.Distinct()) db.ClientDelegations.Add(new ClientDelegation { ClientId = c.Id, OnBehalfOfClientId = x });
        Changed("ClientUpdated", c.ClientId, $"Client güncellendi: {c.ClientId} (aktif={dto.IsActive})", dto);
        await db.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(int id, CancellationToken ct)
    {
        var c = await db.Clients.FindAsync([id], ct) ?? throw new NotFoundException("Client", id);
        var policies = await db.PolicyMembers.Where(m => m.MemberId == id && m.Policy.Type == PolicyType.Client).Select(m => m.Policy.Code).ToListAsync(ct);
        if (policies.Count > 0) throw new ConflictException($"'{c.ClientId}' kanal policy'lerinde kullanılıyor; silinemez.", new { policies });
        var delegatedBy = await db.ClientDelegations.Where(d => d.OnBehalfOfClientId == id).Select(d => d.Client.ClientId).ToListAsync(ct);
        if (delegatedBy.Count > 0) throw new ConflictException($"'{c.ClientId}' adına konuşan aracılar var; önce onlardan kaldırın.", new { delegatedBy });
        db.Clients.Remove(c);
        Changed("ClientDeleted", c.ClientId, $"Client silindi: {c.ClientId}");
        await db.SaveChangesAsync(ct);
    }

    private async Task ValidateAsync(ClientUpsert dto, CancellationToken ct, int? selfId = null)
    {
        if (dto.RateLimitPerMinute is <= 0) throw new ValidationException("İstek limiti pozitif olmalı.");
        if (dto.QueryApplicationIds.Count > 0 && await db.Applications.CountAsync(a => dto.QueryApplicationIds.Contains(a.Id), ct) != dto.QueryApplicationIds.Distinct().Count())
            throw new ValidationException("Soru kapsamındaki uygulamalardan biri bulunamadı.");
        if (dto.QueryTenantIds.Count > 0 && await db.Tenants.CountAsync(t => dto.QueryTenantIds.Contains(t.Id), ct) != dto.QueryTenantIds.Distinct().Count())
            throw new ValidationException("Soru kapsamındaki kurumlardan biri bulunamadı.");
        if (dto.OnBehalfOfClientIds.Count > 0)
        {
            if (dto.Type != ClientType.Intermediary) throw new ValidationException("Sadece aracı (Intermediary) client'lar başka client adına konuşabilir.");
            if (selfId is { } me && dto.OnBehalfOfClientIds.Contains(me)) throw new ValidationException("Client kendi adına aracı olamaz.");
            if (await db.Clients.CountAsync(c => dto.OnBehalfOfClientIds.Contains(c.Id) && c.Type != ClientType.Intermediary, ct) != dto.OnBehalfOfClientIds.Distinct().Count())
                throw new ValidationException("Adına konuşulacak client'lar kayıtlı ve aracı olmayan client'lar olmalı.");
        }
        if (!await db.Tenants.AnyAsync(t => t.Id == dto.TenantId, ct)) throw new ValidationException("Client'ı kaydeden tenant seçilmeli.");
        if (dto.ApplicationId is { } a && !await db.Applications.AnyAsync(x => x.Id == a, ct)) throw new NotFoundException("Uygulama", a);
        if (dto.Type == ClientType.Service)
        {
            if (dto.ServiceAccountUserId is not { } u) throw new ValidationException("Service client için servis hesabı zorunlu.");
            var account = await identities.GetUserAsync(u, ct);
            if (account is null || account.Kind != UserKind.ServiceAccount) throw new ValidationException("Servis hesabı ServiceAccount türünde bir kullanıcı olmalı.");
            if (account.TenantId != dto.TenantId) throw new ValidationException("Servis hesabı client ile aynı tenant'a ait olmalı.");
        }
    }

    private void Changed(string action, string id, string summary, object? details = null)
    {
        audit.Management(action, "Client", id, summary, details);
        outbox.Add(EventTypes.ClientChanged, "Client", id, new { action, id });
    }
}

// ================================ SoD / dış sistem ================================

public sealed class SodRuleUpsert
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public Severity Severity { get; set; } = Severity.High;
    public SodEnforcement Enforcement { get; set; } = SodEnforcement.Block;
    public bool IsActive { get; set; } = true;
    /// <summary>Yetkiler (resource:scope id'leri).</summary>
    public List<int> ResourceScopeIds { get; set; } = new();
    public List<int> RoleIds { get; set; } = new();
}

public sealed record SodRuleCreated(int Id, string Code, int CurrentViolatingUsers, IReadOnlyList<SodUserConflicts> Preview);

public sealed class GovernanceService(IYetkiDbContext db, SodService sod, AuthorizationModelProvider models, OutboxWriter outbox, AuditWriter audit, IClock clock, ICurrentActor actor)
{
    public async Task<SodRuleCreated> CreateSodRuleAsync(SodRuleUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.SodRules.AnyAsync(r => r.Code == code, ct)) throw new ConflictException($"SoD kural kodu zaten var: {code}");
        var members = await ValidateMembersAsync(dto, ct);
        var rule = new SodRule
        {
            Code = code, Name = dto.Name, Description = dto.Description, Severity = dto.Severity, Enforcement = dto.Enforcement, IsActive = dto.IsActive,
            Members = members.Select(m => new SodRuleMember { MemberType = m.Type, MemberId = m.Id }).ToList()
        };
        db.SodRules.Add(rule);
        audit.Management(EventTypes.SoDRuleChanged, "SodRule", code, $"SoD kuralı oluşturuldu: {code} ({dto.Enforcement})", dto);
        outbox.Add(EventTypes.SoDRuleChanged, "SodRule", code, new { action = "created", code, dto.Enforcement });
        await db.SaveChangesAsync(ct);

        var model = await models.GetCurrentAsync(ct);
        var preview = await sod.SimulateRuleAsync(SodService.Snapshot(model, rule.Id, code, dto.Name, dto.Severity, dto.Enforcement, members), ct);
        return new SodRuleCreated(rule.Id, code, preview.Count, preview);
    }

    public async Task UpdateSodRuleAsync(int id, SodRuleUpsert dto, CancellationToken ct)
    {
        var rule = await db.SodRules.Include(r => r.Members).FirstOrDefaultAsync(r => r.Id == id, ct) ?? throw new NotFoundException("SoD kuralı", id);
        var members = await ValidateMembersAsync(dto, ct);
        rule.Name = dto.Name; rule.Description = dto.Description; rule.Severity = dto.Severity; rule.Enforcement = dto.Enforcement; rule.IsActive = dto.IsActive;
        foreach (var m in rule.Members.ToList()) db.SodRuleMembers.Remove(m);
        foreach (var m in members) db.SodRuleMembers.Add(new SodRuleMember { SodRuleId = rule.Id, MemberType = m.Type, MemberId = m.Id });
        audit.Management(EventTypes.SoDRuleChanged, "SodRule", rule.Code, $"SoD kuralı güncellendi: {rule.Code}", dto);
        outbox.Add(EventTypes.SoDRuleChanged, "SodRule", rule.Code, new { action = "updated", rule.Code, dto.Enforcement, dto.IsActive });
        await db.SaveChangesAsync(ct);
    }

    public async Task<List<(SodMemberType Type, int Id)>> ValidateMembersAsync(SodRuleUpsert dto, CancellationToken ct)
    {
        var members = dto.ResourceScopeIds.Distinct().Select(id => (SodMemberType.ResourceScope, id)).Concat(dto.RoleIds.Distinct().Select(id => (SodMemberType.Role, id))).ToList();
        if (members.Count < 2) throw new ValidationException("SoD kuralı en az 2 üye (yetki/rol) içermelidir.");
        var model = await models.GetCurrentAsync(ct);
        if (dto.ResourceScopeIds.Distinct().Any(id => !model.ResourceScopes.ContainsKey(id)) || dto.RoleIds.Distinct().Any(id => !model.Roles.ContainsKey(id)))
            throw new ValidationException("SoD üyelerinden biri bulunamadı.");
        return members;
    }

    public async Task UpdateViolationAsync(int id, ViolationStatus status, string? note, CancellationToken ct)
    {
        var v = await db.SodViolations.FindAsync([id], ct) ?? throw new NotFoundException("İhlal", id);
        v.Status = status;
        v.Note = note;
        if (status == ViolationStatus.Resolved) { v.ClosedAt = clock.UtcNow; v.ClosedBy = actor.Name; }
        audit.Management("SodViolationUpdated", "SodViolation", id, $"İhlal #{id} → {status}", new { status, note });
        await db.SaveChangesAsync(ct);
    }

}
