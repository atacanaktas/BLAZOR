using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Domain.Clients;

namespace Yetki.Application.Definitions;

public sealed record ClientSecretView(int Id, string Prefix, string? Description, DateTime CreatedAt, string CreatedBy,
    DateTime? ExpiresAt, DateTime? RevokedAt, DateTime? LastUsedAt, bool IsValid);

/// <summary>Yeni secret: düz metin SADECE bu cevapta döner; sistemde yalnızca özeti tutulur.</summary>
public sealed record CreatedClientSecret(int Id, string ClientId, string Secret, string Prefix, DateTime? ExpiresAt);

public sealed class ClientSecretCreate
{
    public string? Description { get; set; }
    /// <summary>Geçerlilik (gün). Boşsa süresiz (sadece iptal ile kapanır).</summary>
    public int? ExpiresInDays { get; set; }
}

/// <summary>
/// Client'ların motora kimlik doğrulaması: secret oluşturma / iptal / doğrulama.
/// Secret yüksek entropili rastgele değerdir ("ysk_" + 32 bayt); SHA-256 özeti saklanır, karşılaştırma sabit zamanlıdır.
/// Kesintisiz değişim: yeni secret oluşturulur, tüketici geçince eskisi iptal edilir (aynı anda birden fazla geçerli olabilir).
/// </summary>
public sealed class ClientCredentialService(IYetkiDbContext db, AuditWriter audit, IClock clock, ICurrentActor actor)
{
    public const string SecretPrefix = "ysk_";

    public async Task<IReadOnlyList<ClientSecretView>> ListAsync(int clientPk, CancellationToken ct)
    {
        var now = clock.UtcNow;
        return (await db.ClientSecrets.AsNoTracking().Where(s => s.ClientId == clientPk).OrderByDescending(s => s.CreatedAt).ToListAsync(ct))
            .Select(s => new ClientSecretView(s.Id, s.Prefix, s.Description, s.CreatedAt, s.CreatedBy, s.ExpiresAt, s.RevokedAt, s.LastUsedAt, IsValid(s, now)))
            .ToList();
    }

    public async Task<CreatedClientSecret> CreateAsync(int clientPk, ClientSecretCreate dto, CancellationToken ct)
    {
        var client = await db.Clients.FindAsync([clientPk], ct) ?? throw new NotFoundException("Client", clientPk);
        if (dto.ExpiresInDays is <= 0) throw new ValidationException("Geçerlilik süresi pozitif olmalı.");
        var plain = SecretPrefix + Convert.ToBase64String(RandomNumberGenerator.GetBytes(32)).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        var secret = Add(client, plain, dto.Description, dto.ExpiresInDays is { } d ? clock.UtcNow.AddDays(d) : null);
        audit.Management("ClientSecretCreated", "Client", client.ClientId, $"Client secret oluşturuldu: {client.ClientId} ({secret.Prefix}…)",
            new { dto.Description, secret.ExpiresAt });
        await db.SaveChangesAsync(ct);
        return new CreatedClientSecret(secret.Id, client.ClientId, plain, secret.Prefix, secret.ExpiresAt);
    }

    /// <summary>Bilinen düz metinle secret ekler (örnek veri aracı için). Normal akışta CreateAsync kullanılır.</summary>
    public ClientSecret Add(Client client, string plain, string? description, DateTime? expiresAt)
    {
        var secret = new ClientSecret
        {
            Client = client, SecretHash = Hash(plain), Prefix = plain.Length > 10 ? plain[..10] : plain, Description = description,
            CreatedAt = clock.UtcNow, CreatedBy = actor.Name, ExpiresAt = expiresAt
        };
        db.ClientSecrets.Add(secret);
        return secret;
    }

    public async Task RevokeAsync(int clientPk, int secretId, CancellationToken ct)
    {
        var s = await db.ClientSecrets.Include(x => x.Client).FirstOrDefaultAsync(x => x.Id == secretId && x.ClientId == clientPk, ct)
                ?? throw new NotFoundException("Client secret", secretId);
        if (s.RevokedAt is not null) return;
        s.RevokedAt = clock.UtcNow;
        audit.Management("ClientSecretRevoked", "Client", s.Client.ClientId, $"Client secret iptal edildi: {s.Client.ClientId} ({s.Prefix}…)");
        await db.SaveChangesAsync(ct);
    }

    /// <summary>client_id + secret doğrulaması. Başarılıysa client kodu döner ve secret'ın son kullanım zamanı güncellenir.</summary>
    public async Task<string?> ValidateAsync(string clientId, string secret, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(secret)) return null;
        var code = clientId.Trim().ToLowerInvariant();
        var client = await db.Clients.FirstOrDefaultAsync(c => c.ClientId == code, ct);
        if (client is null || !client.IsActive) return null;
        var hash = Hash(secret.Trim());
        var now = clock.UtcNow;
        var candidates = await db.ClientSecrets.Where(s => s.ClientId == client.Id && s.RevokedAt == null).ToListAsync(ct);
        var match = candidates.FirstOrDefault(s => (s.ExpiresAt == null || s.ExpiresAt > now)
            && CryptographicOperations.FixedTimeEquals(Encoding.ASCII.GetBytes(s.SecretHash), Encoding.ASCII.GetBytes(hash)));
        if (match is null) return null;
        match.LastUsedAt = now;
        await db.SaveChangesAsync(ct);
        return client.ClientId;
    }

    private static bool IsValid(ClientSecret s, DateTime now) => s.RevokedAt is null && (s.ExpiresAt is null || s.ExpiresAt > now);

    public static string Hash(string plain) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(plain))).ToLowerInvariant();
}
