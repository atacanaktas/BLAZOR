using Yetki.Domain.Common;

namespace Yetki.Application.Model;

/// <summary>Grup üyelik nedeni: açık üye veya kitle kuralı (hangi kriterlerle eşleşti).</summary>
public sealed record MembershipReason(string Kind, int? FilterOrder, string Text);

public sealed record GroupMembership(int GroupId, string Code, string Name, string Tenant, IReadOnlyList<MembershipReason> Reasons);

/// <summary>Include kuralıyla eşleşip Exclude kuralıyla çıkarılan grup (açıklama için).</summary>
public sealed record GroupExclusion(int GroupId, string Code, string Reason);

public sealed record RoleSource(string Kind, int? GroupId, string? GroupCode, string Text, DateTime? ValidUntil);

public sealed record EffectiveRole(int RoleId, string Code, string Name, string Tenant, IReadOnlyList<RoleSource> Sources);

/// <summary>Kullanıcının kimlik durumu: etkin roller (doğrudan + gruptan) ve grup üyelikleri. Policy'ler buna bakar.</summary>
public sealed class IdentityState
{
    public required UserRow User { get; init; }
    public IReadOnlyList<EffectiveRole> Roles { get; init; } = [];
    public IReadOnlyList<GroupMembership> Groups { get; init; } = [];
    public IReadOnlyList<GroupExclusion> ExcludedFromGroups { get; init; } = [];
    /// <summary>Kurum kuralı nedeniyle yok sayılan atamalar (ör. alt kurum kullanıcısına miras alınamaz rol).</summary>
    public IReadOnlyList<string> IgnoredAssignments { get; init; } = [];
}

/// <summary>Erişimin kaynağı: hangi permission'daki hangi policy, neden eşleşti (ör. "rol SUBEMDR (doğrudan atama)").</summary>
public sealed record AccessSource(string Permission, string Policy, PolicyType PolicyType, string Path);

/// <summary>
/// Kullanıcının bir yetkiye (resource:scope) statik erişimi.
/// Conditional: erişim çalışma anında değerlendirilen koşullara bağlı (Condition / Client policy'leri) — Conditions listesinde.
/// </summary>
public sealed record EffectiveAccess(
    int ResourceScopeId, string Key, string Name, string Application, string Resource, string ResourceType, string Scope,
    string Path, Severity RiskLevel, bool Conditional, IReadOnlyList<AccessSource> Sources, IReadOnlyList<string> Conditions);

/// <summary>Açıklanabilir etkin erişim seti ("kim neye erişebilir, neden?"). Statiktir: istek bağlamına bakmaz.</summary>
public sealed class EffectiveAccessSet
{
    public int UserId { get; init; }
    public string UserName { get; init; } = default!;
    public string FullName { get; init; } = default!;
    public string Tenant { get; init; } = default!;
    public bool IsActive { get; init; }
    public long ModelVersion { get; init; }
    public DateTime ComputedAt { get; init; }
    public IReadOnlyList<EffectiveRole> Roles { get; init; } = [];
    public IReadOnlyList<GroupMembership> Groups { get; init; } = [];
    public IReadOnlyList<GroupExclusion> ExcludedFromGroups { get; init; } = [];
    public IReadOnlyList<EffectiveAccess> Accesses { get; init; } = [];
    public IReadOnlyList<string> IgnoredAssignments { get; init; } = [];

    private Dictionary<int, EffectiveAccess>? _byId;

    public EffectiveAccess? Find(int resourceScopeId) =>
        (_byId ??= Accesses.ToDictionary(p => p.ResourceScopeId)).GetValueOrDefault(resourceScopeId);

    public EffectiveAccess? Find(string key) =>
        Accesses.FirstOrDefault(p => string.Equals(p.Key, key, StringComparison.OrdinalIgnoreCase));
}
