using Yetki.Application.PolicyEngine;
using Yetki.Domain.Common;

namespace Yetki.Application.Model;

/// <summary>Değerlendirmeye hazır policy: üyeler (rol/grup/kullanıcı/client/alt policy id'leri), condition kural seti, yükümlülükler.</summary>
public sealed record CompiledPolicy(PolicyRow Row, string TenantCode, IReadOnlySet<int> Members, IReadOnlyList<int> OrderedMembers,
    PolicyDefinition? Definition, IReadOnlyList<ObligationRow> Obligations);

/// <summary>Değerlendirmeye hazır Keycloak permission: kapsam (resource / tip / scope) + policy'ler.</summary>
public sealed record CompiledPermission(PermissionRow Row, AppRow App, IReadOnlySet<int> Resources, IReadOnlySet<int> Scopes, IReadOnlyList<int> PolicyIds)
{
    /// <summary>
    /// Permission bu yetkiye (resource:scope) uygulanır mı? Kapsam açıkça seçilir: boş resource / scope listesi
    /// "hiçbiri" demektir (permission atıl kalır), asla "tümü" değil — silinen resource yetkiyi genişletemez.
    /// </summary>
    public bool Applies(ResourceScopeInfo rs) =>
        rs.App.Id == Row.ApplicationId
        && Row.Target switch
        {
            PermissionTarget.Resources => Resources.Contains(rs.Resource.Id),
            PermissionTarget.ResourceType => Row.ResourceTypeId == rs.Resource.ResourceTypeId,
            PermissionTarget.Application => true,
            _ => false
        }
        && (Row.AllScopes || Scopes.Contains(rs.Scope.Id));
}

/// <summary>
/// Model verisinden (ve opsiyonel What-If policy değişikliklerinden) değerlendirmeye hazır policy'leri kurar.
///  - Pasif policy'ler de derlenir (yönetim ekranı için); değerlendirmede pasif policy izin vermez.
///  - Pasif / bulunamayan / döngüsel ortak koşul referansı çocuksuz Reference düğümü olur → Indeterminate (fail-closed).
/// </summary>
public static class PolicyCompiler
{
    public static IReadOnlyList<CompiledPolicy> Compile(ModelData data, PolicyChangeSet? changes)
    {
        var resolver = new ConditionTreeResolver(data.Conditions, data.SharedConditions, changes);
        var tenants = data.Tenants.ToDictionary(o => o.Id, o => o.Code);
        var removedRules = changes?.RemovedRuleIds.ToHashSet() ?? [];
        var rulesByPolicy = data.Rules.ToLookup(r => r.PolicyId);
        var membersByPolicy = data.PolicyMembers.ToLookup(m => m.PolicyId, m => m.MemberId);
        var obligationsByPolicy = data.Obligations.ToLookup(o => o.PolicyId);

        var result = new List<CompiledPolicy>();
        foreach (var p0 in data.Policies)
        {
            var p = p0 with
            {
                IsActive = changes?.PolicyActivations.LastOrDefault(a => a.PolicyId == p0.Id)?.IsActive ?? p0.IsActive,
                Mode = changes?.PolicyModes.LastOrDefault(a => a.PolicyId == p0.Id)?.Mode ?? p0.Mode,
                Strategy = changes?.PolicyStrategies.LastOrDefault(a => a.PolicyId == p0.Id)?.Strategy ?? p0.Strategy
            };

            PolicyDefinition? definition = null;
            if (p.Type == PolicyType.Condition)
            {
                var rules = rulesByPolicy[p.Id].Where(r => !removedRules.Contains(r.Id)).Select(r =>
                {
                    var o = changes?.RuleOverrides.LastOrDefault(x => x.RuleId == r.Id);
                    var rep = changes?.ReplacedRules.LastOrDefault(x => x.RuleId == r.Id);
                    return rep is null
                        ? new RuleDefinition(r.Id, r.Code, r.Name, r.Description, o?.Order ?? r.Order, r.ReasonCode, o?.IsActive ?? r.IsActive, resolver.RuleRoot(r.Id))
                        : new RuleDefinition(r.Id, r.Code, rep.Rule.Name ?? r.Name, r.Description, rep.Rule.Order, rep.Rule.ReasonCode,
                            o?.IsActive ?? r.IsActive, resolver.FromDraft(rep.Rule.Condition));
                }).ToList();
                if (changes is not null)
                {
                    var draftRuleId = -1000 * p.Id - 1;
                    foreach (var d in changes.AddedRules.Where(d => d.PolicyId == p.Id))
                        rules.Add(new RuleDefinition(draftRuleId--, d.Code, d.Name ?? d.Code, "What-If taslağı", d.Order, d.ReasonCode, true, resolver.FromDraft(d.Condition)));
                }
                definition = new PolicyDefinition(p.Id, p.Code, p.Name, p.Version, p.Strategy, rules);
            }

            var members = membersByPolicy[p.Id].ToList();
            result.Add(new CompiledPolicy(p, tenants.GetValueOrDefault(p.TenantId, "?"), members.ToHashSet(), members, definition,
                obligationsByPolicy[p.Id].OrderBy(o => o.Order).ThenBy(o => o.Code, StringComparer.Ordinal).ToList()));
        }
        return result;
    }

    public static IReadOnlyList<CompiledPermission> CompilePermissions(ModelData data)
    {
        var apps = data.Applications.ToDictionary(a => a.Id);
        var res = data.PermissionResources.ToLookup(x => x.PermissionId, x => x.ResourceId);
        var scopes = data.PermissionScopes.ToLookup(x => x.PermissionId, x => x.ScopeId);
        var policies = data.PermissionPolicies.ToLookup(x => x.PermissionId);
        return data.Permissions.Where(p => apps.ContainsKey(p.ApplicationId)).Select(p => new CompiledPermission(p, apps[p.ApplicationId],
            res[p.Id].ToHashSet(), scopes[p.Id].ToHashSet(), policies[p.Id].OrderBy(x => x.Order).Select(x => x.PolicyId).ToList())).ToList();
    }

    /// <summary>Taslak condition ağacını çözümsüz düğüme çevirir (referanslar sadece kodla; audit metni/önizleme için).</summary>
    public static ConditionNode FromDraftUnresolved(ConditionDraft d)
    {
        var id = 0;
        return Convert(d);

        ConditionNode Convert(ConditionDraft x) => x.Kind == ConditionKind.Reference
            ? new ConditionNode(--id, ConditionKind.Reference, null, true, ConditionTreeResolver.Empty, [], x.SharedConditionCode)
            : new ConditionNode(--id, x.Kind, x.Kind == ConditionKind.Predicate ? x.ConditionTypeCode : null, true,
                new Dictionary<string, string>(x.Parameters, StringComparer.OrdinalIgnoreCase), x.Children.Select(Convert).ToList());
    }
}

/// <summary>Condition satırlarını ağaçlara çevirir; ortak koşul referanslarını döngü korumalı çözer; What-If değişikliklerini uygular.</summary>
public sealed class ConditionTreeResolver
{
    public static readonly IReadOnlyDictionary<string, string> Empty = new Dictionary<string, string>();

    private readonly ILookup<(int, int?), ConditionRow> _ruleChildren;
    private readonly ILookup<(int, int?), ConditionRow> _sharedChildren;
    private readonly Dictionary<int, SharedRow> _sharedById;
    private readonly Dictionary<string, int> _sharedIdByCode;
    private readonly Dictionary<int, Dictionary<string, string>> _paramOverrides;
    private readonly Dictionary<int, ConditionDraft> _sharedReplacements;
    private int _draftNodeId;

    public ConditionTreeResolver(IEnumerable<ConditionRow> rows, IEnumerable<SharedRow> shared, PolicyChangeSet? changes)
    {
        var list = rows.ToList();
        _ruleChildren = list.Where(r => r.RuleId != null).ToLookup(r => (r.RuleId!.Value, r.ParentId));
        _sharedChildren = list.Where(r => r.SharedId != null).ToLookup(r => (r.SharedId!.Value, r.ParentId));
        _sharedById = shared.ToDictionary(s => s.Id);
        _sharedIdByCode = _sharedById.Values.ToDictionary(s => s.Code, s => s.Id, StringComparer.OrdinalIgnoreCase);
        _paramOverrides = changes?.ConditionOverrides.GroupBy(o => o.ConditionId).ToDictionary(g => g.Key, g => g.Last().Parameters) ?? [];
        _sharedReplacements = changes?.SharedConditionReplacements.GroupBy(r => r.SharedConditionId).ToDictionary(g => g.Key, g => g.Last().Condition) ?? [];
    }

    public ConditionNode? RuleRoot(int ruleId)
    {
        var root = _ruleChildren[(ruleId, null)].OrderBy(c => c.Order).FirstOrDefault();
        return root is null ? null : Build(root, new HashSet<int>(), id => _ruleChildren[(ruleId, id)]);
    }

    /// <summary>Ortak koşulun çözülmüş kökü (referanslar içerikleriyle).</summary>
    public ConditionNode? SharedRoot(int sharedId)
    {
        var node = Reference(sharedId, null, 0, new HashSet<int>());
        return node.Children.FirstOrDefault();
    }

    public ConditionNode FromDraft(ConditionDraft d) => FromDraft(d, new HashSet<int>());

    private ConditionNode FromDraft(ConditionDraft d, IReadOnlySet<int> path)
    {
        var id = --_draftNodeId;
        if (d.Kind == ConditionKind.Reference) return Reference(null, d.SharedConditionCode, id, path);
        return new ConditionNode(id, d.Kind, d.Kind == ConditionKind.Predicate ? d.ConditionTypeCode : null, true,
            new Dictionary<string, string>(d.Parameters, StringComparer.OrdinalIgnoreCase),
            d.Children.Select(c => FromDraft(c, path)).ToList());
    }

    private ConditionNode Build(ConditionRow row, IReadOnlySet<int> path, Func<int?, IEnumerable<ConditionRow>> childrenOf)
    {
        if (row.Kind == ConditionKind.Reference) return Reference(row.RefId, null, row.Id, path);
        return new ConditionNode(row.Id, row.Kind, row.TypeCode, row.TypeAvailable,
            _paramOverrides.TryGetValue(row.Id, out var o) ? new Dictionary<string, string>(o, StringComparer.OrdinalIgnoreCase) : row.Params,
            childrenOf(row.Id).OrderBy(c => c.Order).ThenBy(c => c.Id).Select(c => Build(c, path, childrenOf)).ToList());
    }

    private ConditionNode Reference(int? refId, string? refCode, int nodeId, IReadOnlySet<int> path)
    {
        var sid = refId ?? (refCode is not null && _sharedIdByCode.TryGetValue(refCode, out var byCode) ? byCode : null);
        if (sid is null || !_sharedById.TryGetValue(sid.Value, out var meta))
            return new ConditionNode(nodeId, ConditionKind.Reference, null, true, Empty, [], refCode ?? $"#{refId}");
        if (!meta.IsActive || path.Contains(meta.Id))
            return new ConditionNode(nodeId, ConditionKind.Reference, null, true, Empty, [], meta.Code, meta.Version);

        var inner = new HashSet<int>(path) { meta.Id };
        ConditionNode? root;
        if (_sharedReplacements.TryGetValue(meta.Id, out var replacement))
            root = FromDraft(replacement, inner);
        else
        {
            var r = _sharedChildren[(meta.Id, null)].OrderBy(x => x.Order).FirstOrDefault();
            root = r is null ? null : Build(r, inner, id => _sharedChildren[(meta.Id, id)]);
        }
        return new ConditionNode(nodeId, ConditionKind.Reference, null, true, Empty, root is null ? [] : [root], meta.Code, meta.Version);
    }
}
