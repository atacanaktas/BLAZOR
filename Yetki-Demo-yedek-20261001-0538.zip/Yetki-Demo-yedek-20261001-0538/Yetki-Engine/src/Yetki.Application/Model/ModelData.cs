using Yetki.Domain.Common;

namespace Yetki.Application.Model;

// Ham model satırları (değişmez kayıtlar). Veritabanından tek seferde yüklenir; What-If için kopyalanıp değiştirilir.

public sealed record TenantRow(int Id, string Code, string Name, TenantType Type, int? ParentId, bool IsActive);
public sealed record UnitRow(int Id, int TenantId, int? ParentId, string Code, string Name, OrgUnitType Type, bool IsActive);
public sealed record UserRow(int Id, int TenantId, string UserName, string FullName, string? Title, string? EmployeeNo,
    UserKind Kind, bool IsActive, bool IsOnLeave, decimal CashWithdrawalLimit, string? CustomerNo);
public sealed record UserUnitRow(int UserId, int OrgUnitId, bool IsPrimary);

public sealed record AppRow(int Id, int TenantId, string Code, string Name, ApplicationType Type, DecisionStrategy Strategy, bool IsActive);
public sealed record ResourceTypeRow(int Id, string Code, string Name, bool MatchesHttp, bool SupportsHierarchy, string? Color, bool IsActive);
public sealed record ResourceRow(int Id, int ApplicationId, int ResourceTypeId, int? ParentId, string Code, string Name, string? ExternalCode, int Order, bool IsActive);
public sealed record ScopeRow(int Id, int ApplicationId, string Code, string Name);
public sealed record ResourceScopeRow(int Id, int ResourceId, int ScopeId, Severity RiskLevel);
public sealed record UriRow(int Id, int ResourceId, string Method, string Pattern, int ScopeId);

/// <summary>Client'ın soru kapsamı: sorabileceği uygulamalar ve kurumlar, adına konuşabileceği client'lar (aracı), istek limiti.</summary>
public sealed record ClientScopeRow(int ClientId, IReadOnlyList<int> Applications, IReadOnlyList<int> Tenants, IReadOnlyList<int> OnBehalfOf, int? RateLimitPerMinute);

public sealed record ClientRow(int Id, int TenantId, string ClientId, string Name, ClientType Type, int? ApplicationId, int? ServiceAccountUserId, bool IsActive);

public sealed record RoleRow(int Id, int TenantId, string Code, string Name, bool IsInheritable, bool IsActive);
public sealed record UserRoleRow(int UserId, int RoleId, DateTime? ValidFrom, DateTime? ValidUntil);

public sealed record GroupRow(int Id, int TenantId, string Code, string Name, bool IsActive);
public sealed record GroupMemberRow(int GroupId, int UserId, DateTime? ValidUntil);
public sealed record CriterionRow(string Attribute, IReadOnlyList<string> Values);
public sealed record GroupFilterRow(int GroupId, int Order, InclusionMode Mode, string? Description, IReadOnlyList<CriterionRow> Criteria);
public sealed record GroupRoleRow(int GroupId, int RoleId);

public sealed record PolicyRow(int Id, int TenantId, string Code, string Name, PolicyType Type, PolicyLogic Logic, DecisionStrategy Strategy,
    PolicyMode Mode, bool IsActive, int Version);
/// <summary>Policy üyesi: tipine göre rol / grup / kullanıcı / client id veya (Aggregate) alt policy id.</summary>
public sealed record PolicyMemberRow(int PolicyId, int MemberId);
/// <summary>Policy yükümlülüğü (PEP yerine getirir).</summary>
public sealed record ObligationRow(int Id, int PolicyId, string Code, ObligationFulfillOn FulfillOn, int Order, IReadOnlyDictionary<string, string> Params);
public sealed record RuleRow(int Id, int PolicyId, string Code, string Name, string? Description, int Order, string? ReasonCode, bool IsActive);
public sealed record ConditionRow(int Id, int? RuleId, int? SharedId, int? ParentId, ConditionKind Kind, int Order,
    string? TypeCode, bool TypeAvailable, int? RefId, IReadOnlyDictionary<string, string> Params);
public sealed record SharedRow(int Id, string Code, bool IsActive, int Version);

public sealed record PermissionRow(int Id, int ApplicationId, string Code, string Name, PermissionTarget Target, int? ResourceTypeId, bool AllScopes,
    DecisionStrategy Strategy, bool IsActive, int Version);
public sealed record PermissionResourceRow(int PermissionId, int ResourceId);
public sealed record PermissionScopeRow(int PermissionId, int ScopeId);
public sealed record PermissionPolicyRow(int PermissionId, int PolicyId, int Order);

/// <summary>Yetki modelinin ham verisi. Clone() sığ kopyadır: satırlar değişmez, listeler yenidir.</summary>
public sealed class ModelData
{
    public List<TenantRow> Tenants { get; init; } = new();
    public List<UnitRow> Units { get; init; } = new();
    public List<UserRow> Users { get; init; } = new();
    public List<UserUnitRow> UserUnits { get; init; } = new();
    public List<AppRow> Applications { get; init; } = new();
    public List<ResourceTypeRow> ResourceTypes { get; init; } = new();
    public List<ResourceRow> Resources { get; init; } = new();
    public List<ScopeRow> Scopes { get; init; } = new();
    public List<ResourceScopeRow> ResourceScopes { get; init; } = new();
    public List<UriRow> Uris { get; init; } = new();
    public List<ClientRow> Clients { get; init; } = new();
    public List<ClientScopeRow> ClientScopes { get; init; } = new();
    public List<RoleRow> Roles { get; init; } = new();
    public List<UserRoleRow> UserRoles { get; init; } = new();
    public List<GroupRow> Groups { get; init; } = new();
    public List<GroupMemberRow> GroupMembers { get; init; } = new();
    public List<GroupFilterRow> GroupFilters { get; init; } = new();
    public List<GroupRoleRow> GroupRoles { get; init; } = new();
    public List<PolicyRow> Policies { get; init; } = new();
    public List<PolicyMemberRow> PolicyMembers { get; init; } = new();
    public List<ObligationRow> Obligations { get; init; } = new();
    public List<RuleRow> Rules { get; init; } = new();
    public List<ConditionRow> Conditions { get; init; } = new();
    public List<SharedRow> SharedConditions { get; init; } = new();
    public List<PermissionRow> Permissions { get; init; } = new();
    public List<PermissionResourceRow> PermissionResources { get; init; } = new();
    public List<PermissionScopeRow> PermissionScopes { get; init; } = new();
    public List<PermissionPolicyRow> PermissionPolicies { get; init; } = new();

    public ModelData Clone() => new()
    {
        Tenants = [.. Tenants], Units = [.. Units], Users = [.. Users], UserUnits = [.. UserUnits],
        Applications = [.. Applications], ResourceTypes = [.. ResourceTypes], Resources = [.. Resources],
        Scopes = [.. Scopes], ResourceScopes = [.. ResourceScopes], Uris = [.. Uris], Clients = [.. Clients], ClientScopes = [.. ClientScopes],
        Roles = [.. Roles], UserRoles = [.. UserRoles], Groups = [.. Groups], GroupMembers = [.. GroupMembers],
        GroupFilters = [.. GroupFilters], GroupRoles = [.. GroupRoles], Policies = [.. Policies], PolicyMembers = [.. PolicyMembers],
        Obligations = [.. Obligations], Rules = [.. Rules], Conditions = [.. Conditions], SharedConditions = [.. SharedConditions],
        Permissions = [.. Permissions], PermissionResources = [.. PermissionResources], PermissionScopes = [.. PermissionScopes],
        PermissionPolicies = [.. PermissionPolicies]
    };

    /// <summary>Kimlik tarafı değişikliklerini (kaydedilmemiş) bu veriye uygular.</summary>
    public ModelData Apply(AuthorizationChangeSet? c)
    {
        if (c is null || c.IsEmpty) return this;

        foreach (var x in c.UserRoles)
        {
            UserRoles.RemoveAll(r => r.UserId == x.UserId && r.RoleId == x.RoleId);
            if (x.Add) UserRoles.Add(new UserRoleRow(x.UserId, x.RoleId, null, x.ValidUntil));
        }
        foreach (var x in c.UserUnits)
        {
            UserUnits.RemoveAll(r => r.UserId == x.UserId && r.OrgUnitId == x.OrgUnitId);
            if (x.Add) UserUnits.Add(new UserUnitRow(x.UserId, x.OrgUnitId, !UserUnits.Any(u => u.UserId == x.UserId)));
        }
        foreach (var x in c.GroupMembers)
        {
            GroupMembers.RemoveAll(r => r.GroupId == x.GroupId && r.UserId == x.UserId);
            if (x.Add) GroupMembers.Add(new GroupMemberRow(x.GroupId, x.UserId, x.ValidUntil));
        }
        foreach (var x in c.GroupRoles)
        {
            GroupRoles.RemoveAll(r => r.GroupId == x.GroupId && r.RoleId == x.RoleId);
            if (x.Add) GroupRoles.Add(new GroupRoleRow(x.GroupId, x.RoleId));
        }
        foreach (var x in c.GroupFilters)
        {
            GroupFilters.RemoveAll(f => f.GroupId == x.GroupId);
            GroupFilters.AddRange(x.Filters.Select((f, i) => new GroupFilterRow(x.GroupId, i, f.Mode, f.Description,
                f.Criteria.Select(cr => new CriterionRow(cr.Attribute.Trim().ToUpperInvariant(), cr.Values.Select(v => v.Trim()).Where(v => v.Length > 0).ToList())).ToList())));
        }
        foreach (var x in c.GroupActivations)
        {
            var i = Groups.FindIndex(g => g.Id == x.Id);
            if (i >= 0) Groups[i] = Groups[i] with { IsActive = x.IsActive };
        }
        foreach (var x in c.RoleUpdates)
        {
            var i = Roles.FindIndex(r => r.Id == x.RoleId);
            if (i >= 0) Roles[i] = Roles[i] with { IsActive = x.IsActive ?? Roles[i].IsActive, IsInheritable = x.IsInheritable ?? Roles[i].IsInheritable };
        }
        foreach (var x in c.UserUpdates)
        {
            var i = Users.FindIndex(u => u.Id == x.UserId);
            if (i >= 0)
                Users[i] = Users[i] with
                {
                    Title = x.Title ?? Users[i].Title, IsActive = x.IsActive ?? Users[i].IsActive, IsOnLeave = x.IsOnLeave ?? Users[i].IsOnLeave,
                    CashWithdrawalLimit = x.CashWithdrawalLimit ?? Users[i].CashWithdrawalLimit
                };
        }
        return this;
    }
}
