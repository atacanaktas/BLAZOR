using Yetki.Domain.Common;

namespace Yetki.Domain.Catalog;

// ============================================================================================
//  Yetki tanımları (Keycloak Authorization Services modeli). Ayrı bir "katalog" yoktur: korunan şeyler
//  yetki ekibinin tanımıdır. Gerçekte var olanlar (Swagger / ekran listesi) ayrı ENVANTER'dir ve sadece bilgi amaçlıdır.
//
//  Application (resource server: Anka, Nextral)          → sahibi bir tenant; o tenant ve alt tenant'ları kullanır
//   ├ Scope         uygulamanın işlem sözlüğü (view, create, close, approve...)
//   └ Resource      korunan varlık (kod: anka.vadelihesap) · tipi yetki yönetiminin tanımladığı ResourceType
//       ├ ResourceScope  resource üzerinde yapılabilen işlem = YETKİ (anka.vadelihesap:close) ← rol/grup/kişiye bu verilir
//       └ ResourceUri    (HTTP tipleri) METHOD + URI deseni → scope   ← gateway/framework'ten gelen istek buna eşlenir
//
//  Kimlik resource kodudur; URI sadece eşleştirme bilgisidir (değişirse güncellenir, yetkiler etkilenmez).
//  Gruplama tanımlanmaz, türetilir: HTTP resource'larında URL kırılımları, UI resource'larında üst-alt ilişkisi.
//  Tanımlanmamış bir URI'ye gelen istek her zaman reddedilir (developer'ın attribute koymasına bağlı değildir).
// ============================================================================================

/// <summary>Katalog tanımlarının teknik/iş sahipliğini üstlenen ekip.</summary>
public class OwnershipTeam : AuditableEntity
{
    public int TenantId { get; set; }
    public Tenants.Tenant Tenant { get; set; } = default!;
    public int? ParentId { get; set; }
    public OwnershipTeam? Parent { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>Resource server: yetkilendirilen sistem / ürün (Keycloak'ta authorization açık client).</summary>
public class CatalogApplication : AuditableEntity
{
    /// <summary>Sahip tenant. Uygulama bu tenant ve alt tenant'larında kullanılabilir.</summary>
    public int TenantId { get; set; }
    public Tenants.Tenant Tenant { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ApplicationType Type { get; set; }
    public int? OwnerTeamId { get; set; }
    public OwnershipTeam? OwnershipTeam { get; set; }
    /// <summary>Identity adapter tarafından sağlanan sorumlu user kimliği; yerel Users tablosuna FK değildir.</summary>
    public int? OwnerUserId { get; set; }
    /// <summary>
    /// Aynı resource/scope'a birden fazla permission uygulandığında sonuçların birleştirilmesi (Keycloak resource server
    /// decision strategy). Varsayılan Unanimous: uygulanan tüm permission'lar izin vermeli.
    /// </summary>
    public DecisionStrategy DecisionStrategy { get; set; } = DecisionStrategy.Unanimous;
    public bool IsActive { get; set; } = true;
}

/// <summary>
/// Resource tipi: yetki yönetiminin tanımladığı sınıflandırma (Endpoint, Menü, Ekran, Buton...).
/// MatchesHttp: bu tipteki resource'lar HTTP isteğiyle (METHOD + URI) eşleşir; URI eşlemesi gerekir.
/// SupportsHierarchy: üst-alt ilişkisi anlamlıdır (menü → ekran → buton; üst kapalıysa alt da kapalı).
/// </summary>
public class ResourceType : AuditableEntity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool MatchesHttp { get; set; }
    public bool SupportsHierarchy { get; set; }
    /// <summary>UI'da gösterilecek renk (antd tag rengi: blue, purple, gold...).</summary>
    public string? Color { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>Uygulamanın işlem sözlüğü (Keycloak authorization scope): view, create, close, approve...</summary>
public class Scope : AuditableEntity
{
    public int ApplicationId { get; set; }
    public CatalogApplication Application { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
}

/// <summary>Korunan varlık. Kod kalıcı kimliktir (anka.vadelihesap); URI'ler değişse de değişmez.</summary>
public class Resource : AuditableEntity
{
    public int ApplicationId { get; set; }
    public CatalogApplication Application { get; set; } = default!;
    public int ResourceTypeId { get; set; }
    public ResourceType ResourceType { get; set; } = default!;
    /// <summary>Üst resource (menü → ekran → buton). Üst kapalıysa alt öğe de kapalı gösterilir.</summary>
    public int? ParentId { get; set; }
    public Resource? Parent { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    /// <summary>
    /// Uygulamanın kendi kodu (ör. Nextral ekran kodu GVADAG00). Envanterle eşleştirmede kullanılır; yetki kimliği değildir.
    /// </summary>
    public string? ExternalCode { get; set; }
    public string? Description { get; set; }
    public int? OwnerTeamId { get; set; }
    public OwnershipTeam? OwnershipTeam { get; set; }
    public int Order { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<ResourceScope> Scopes { get; set; } = new List<ResourceScope>();
    public ICollection<ResourceUri> Uris { get; set; } = new List<ResourceUri>();
}

/// <summary>Resource üzerinde yapılabilen işlem = YETKİ. Anahtar: {resource}:{scope} (anka.vadelihesap:close).</summary>
public class ResourceScope : Entity
{
    public int ResourceId { get; set; }
    public Resource Resource { get; set; } = default!;
    public int ScopeId { get; set; }
    public Scope Scope { get; set; } = default!;
    public Severity RiskLevel { get; set; } = Severity.Medium;
}

/// <summary>HTTP eşlemesi: METHOD + URI deseni → resource'un bir scope'u. Desen: /v1/vadeli-hesap/{hesapNo}, * tek segment, ** kalan tümü.</summary>
public class ResourceUri : Entity
{
    public int ResourceId { get; set; }
    public Resource Resource { get; set; } = default!;
    /// <summary>GET, POST, PUT, PATCH, DELETE veya * (tümü).</summary>
    public string Method { get; set; } = "GET";
    public string Pattern { get; set; } = "/";
    public int ScopeId { get; set; }
    public Scope Scope { get; set; } = default!;
}

// ============================================================================================
//  ENVANTER: uygulamada gerçekte ne var? (Swagger / gateway route'ları, ekran-bileşen listesi)
//  Sadece bilgi amaçlıdır: yetkiye etkisi YOKTUR, resource / permission üretmez.
//  Kapsama raporu envanteri yetki tanımlarıyla çarpıştırır (korunuyor / tanımsız / atıl / permission'sız).
// ============================================================================================

public enum InventoryKind { Endpoint = 1, UiElement = 2 }

/// <summary>Bir uygulamanın bir türdeki envanter anlık görüntüsü. Yeniden içe aktarım öncekinin yerini alır.</summary>
public class InventorySnapshot : Entity
{
    public int ApplicationId { get; set; }
    public CatalogApplication Application { get; set; } = default!;
    public InventoryKind Kind { get; set; }
    /// <summary>Kaynak açıklaması (ör. "Swagger v1.4", "Nextral ekran listesi").</summary>
    public string Source { get; set; } = default!;
    public DateTime ImportedAt { get; set; }
    public string ImportedBy { get; set; } = default!;
    public ICollection<InventoryItem> Items { get; set; } = new List<InventoryItem>();
}

/// <summary>Envanter öğesi: endpoint (Method + Path) veya UI öğesi (Code, Name, üst kod, tip).</summary>
public class InventoryItem : Entity
{
    public int SnapshotId { get; set; }
    public InventorySnapshot Snapshot { get; set; } = default!;
    public string? Method { get; set; }
    public string? Path { get; set; }
    public string? Code { get; set; }
    public string? Name { get; set; }
    public string? ParentCode { get; set; }
    /// <summary>UI öğesinin türü (MENU, SCREEN, BUTTON...) — resource tipi önerisi için.</summary>
    public string? ElementType { get; set; }
    public string? Description { get; set; }
}
