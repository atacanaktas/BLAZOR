# OAuth client permissions and granted scopes

The authorization decision keeps two different concepts separate:

1. `ClientPermissionGrant` is the registered/pre-authorized set of permissions
   an OAuth client may receive. It can target an Application, CatalogNode or a
   single Permission and may restrict Actions.
2. `AuthorizationRequest.Scopes` is the set actually granted to the access
   token. Values follow RFC 6749 scope semantics: space-delimited at protocol
   boundaries and case-sensitive. A catalog Permission code is its OAuth scope
   value, for example `anka.nakit.cekim.gise:read`.

Runtime authorization requires:

```
User entitlement
  ∩ Client allowed permission
  ∩ token granted scope
  ∩ enforce policies
```

`AuthorizationEngine:RequireClient` and `RequireGrantedScopes` are enabled in
the API configuration. Missing client identity fails with `CLIENT_REQUIRED`.
Missing granted scopes fails with `TOKEN_SCOPE_REQUIRED`; a token that lacks the
resolved Permission fails with `INSUFFICIENT_SCOPE`. A client that was not
pre-authorized fails with `CLIENT_PERMISSION_NOT_ALLOWED`.

When the SDK enforces an API endpoint, scope failures return HTTP 403 with a
Bearer `WWW-Authenticate` challenge containing `error="insufficient_scope"`
and the required Permission scope, following RFC 6750 behavior.

The SDK reads the original OAuth client from `azp`/`client_id` and granted
scopes from `scope`/`scp`. `X-OAuth-Scopes` is available only with the SDK's
explicit demo-header mode. The management UI's evaluation form sends scopes in
the request body; AuthZEN maps `context.scope`.

The existing physical SQLite table remains named `ClientGrants` for a
non-destructive data-compatible rollout. The domain type, application model,
API routes and UI use `ClientPermissionGrant` / `Allowed Permissions`.
