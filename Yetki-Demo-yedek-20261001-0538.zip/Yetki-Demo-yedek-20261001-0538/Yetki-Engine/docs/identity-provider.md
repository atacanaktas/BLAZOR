# Identity source integration

User, Role and UserRole data are accessed through `IIdentityProvider` in
`src/Yetki.Application/Identity`. The engine model, user details, assignments,
client validation, SoD validation and Structure Explorer consume this boundary.
Controllers do not query these three local tables directly.

Current configuration in `src/Yetki.Api/appsettings.json`:

```json
"Identity": { "Provider": "LocalDb" }
```

`LocalIdentityProvider` in Infrastructure contains the physical table reads and
writes. Existing tables and API response shapes are retained. No profile copies
or synchronization tables were introduced.

## Adding a different source

Implement `IIdentityProvider` and register it in the Identity provider switch in
`Infrastructure/DependencyInjection.cs`. An unknown provider fails startup.
For a different local schema, change the local adapter/mapping. For an HR API,
add an adapter with that API's authentication, field mapping and error handling,
then select it in configuration. Merely changing the configuration does not
implement an API integration.

The provider can compose multiple sources, for example HR-owned Users with
locally owned Roles and UserRole assignments. Keep that routing inside the adapter.
Use the same source semantics for snapshots, individual lookups, search,
existence checks and writes.

The contract uses stable integer User/Role IDs and existing Tenant IDs. Map
external identifiers consistently; usernames are not interchangeable with IDs.
The current database still has foreign keys from local permissions, group
memberships, organizational assignments, audit-related entities and other
relationships to Users/Roles. Before introducing identities absent from these
tables, explicitly migrate those references to a minimal identity-reference
registry (without duplicate profiles), or redesign the FK strategy. The service
boundary does not remove those database constraints.

## Freshness and failure behavior

`GetRevisionAsync` must return a token that changes for User, Role or UserRole
updates, including deletions and assignment validity changes. An external adapter
must implement this with a source revision/ETag or an explicit bounded refresh
strategy. Source errors propagate; there is no silent local or stale fallback.
The model cache keys on local authorization version and identity revision.
External revision changes advance the model version used for decision caching.

`ReadSnapshotAsync` returns a complete, internally consistent identity snapshot.
The engine currently builds its cached authorization model from this snapshot;
this change does not make the engine lazy-load 20,000 identities. Search supports
source-side tenant filtering and paging; the LocalDb adapter executes it in SQL.
Use bulk reads/paging internally in an API adapter, avoiding one call per user.

## Writes and transactions

`Capabilities` separately controls User, Role and UserRole writes. A read-only
adapter advertises false and rejects write methods. AssignmentService checks
capabilities before applying a mutation; unsupported writes never fall back to
the local database.

Stage methods must participate in the application's unit of work and must not
commit independently. LocalDb shares the same scoped DbContext with
AuthorizationChangeService, so identity changes, audit and outbox records are
saved together after impact analysis and SoD checks. Creation methods commit
the complete creation operation and return generated IDs; primary org-unit
creation is included in the local User operation.

A remote HTTP write cannot join the local database transaction. Before enabling
remote writes, implement an explicit outbox/workflow and reconciliation strategy
that preserves the impact/SoD semantics. Until then use read-only capabilities
for externally owned data.

## Validation

Run `dotnet test tests/Yetki.Tests/Yetki.Tests.csproj` from Yetki-Engine.
IdentityProviderTests covers local search and assignment metadata, replacement
source data and cache revisions, read-only rejection and source unavailability.
The existing assignment/SoD/evaluation suite also runs against LocalDb.
