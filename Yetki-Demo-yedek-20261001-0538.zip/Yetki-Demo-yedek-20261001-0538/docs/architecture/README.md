# Yetki Platformu mimari diyagramları

Bu klasördeki çıktılar 01.10.2026 tarihinde mevcut kod taranarak üretildi.

## Dosyalar

- `authorization-architecture-interactive.html`: Ana çıktı. İnternet bağlantısı istemez; tarayıcıda açılır. Sekmeler, hover açıklamaları ve tıklanınca açılan teknik detay paneli içerir.
- `authorization-architecture.drawio`: [diagrams.net](https://app.diagrams.net/) üzerinden **File → Open From → Device** ile açılıp düzenlenebilir. İki sayfası vardır: runtime decision ve control/provisioning.

## Koddan doğrulanan ana eşlemeler

| Mimari rol | Güncel karşılık |
|---|---|
| PAP | `Yetki-Web` + management controller/application service katmanı |
| PDP | `AuthorizationEvaluator`, `PolicyEvaluator`, `/api/v1/authorize`, AuthZEN uçları |
| PEP | Gateway veya uygulama backend'i. Örnek veride `anka-gateway`; Nextral için `nextral-api`. Güncel repoda ortak SDK projesi yok. |
| PIP | `IIdentityProvider`, `RequestContextAttributeProvider`, `ModelSubjectAttributeProvider` |
| PRP | `AuthorizationModelProvider`, `AuthorizationModelCache`, derlenmiş model ve SQLite tanımları |

## Önemli güncel davranış

`nextral-api` kendi `client_secret` değeriyle `POST /api/v1/token` üzerinden kısa ömürlü motor JWT'si alır. Bu JWT son kullanıcı token'ı değildir; `sub` alanı caller `client_id` değeridir. Yetki Engine son kullanıcının OAuth/OIDC token'ını doğrulamaz. Subject, tenant ve güvenilir işlem context'inin çıkarılması PEP/caller sorumluluğundadır.

Nextral masaüstündeki ekran, menü ve butonlar client değildir. `NEXTRAL` application'ında `Resource` olarak tanımlanırlar. Motoru tüketen client sunucu tarafındaki `nextral-api` uygulamasıdır.

## İncelenen temel kaynaklar

- `Yetki-Engine/src/Yetki.Api/Infrastructure/EngineAuth.cs`
- `Yetki-Engine/src/Yetki.Api/Controllers/AuthorizationController.cs`
- `Yetki-Engine/src/Yetki.Application/Evaluation/AuthorizationEvaluator.cs`
- `Yetki-Engine/src/Yetki.Application/Model/AuthorizationModel.cs`
- `Yetki-Engine/src/Yetki.Application/Model/ModelProvider.cs`
- `Yetki-Engine/src/Yetki.Application/Identity/IIdentityProvider.cs`
- `Yetki-Engine/src/Yetki.Domain/Catalog/Catalog.cs`
- `Yetki-Engine/src/Yetki.Domain/Policies/Policy.cs`
- `Yetki-Engine/src/Yetki.Domain/Clients/Client.cs`
- `Yetki-Engine/src/Yetki.Application/External/ExternalProvisioningService.cs`
- `Yetki-Engine/tools/Yetki.SampleData/SampleDataBuilder.cs`

