import { useCallback, useEffect, useState } from 'react'
import { api } from '../api/client'
import type { Option } from '../api/types'

/** GET isteği + yeniden yükleme. path null ise istek atılmaz. */
export function useApi<T>(path: string | null) {
  const [data, setData] = useState<T | undefined>(undefined)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | undefined>(undefined)
  const [tick, setTick] = useState(0)

  useEffect(() => {
    if (!path) return
    let cancelled = false
    setLoading(true)
    setError(undefined)
    api
      .get<T>(path)
      .then((d) => !cancelled && setData(d))
      .catch((e: Error) => !cancelled && setError(e.message))
      .finally(() => !cancelled && setLoading(false))
    return () => {
      cancelled = true
    }
  }, [path, tick])

  const reload = useCallback(() => setTick((t) => t + 1), [])
  return { data, loading, error, reload, setData }
}

export type OptionKind =
  | 'users' | 'roles' | 'groups' | 'tenants' | 'units' | 'applications' | 'teams' | 'resource-types' | 'resources' | 'scopes'
  | 'resource-scopes' | 'clients' | 'policies' | 'permissions' | 'shared-conditions' | 'external-permissions'

const cache = new Map<OptionKind, Promise<Option[]>>()

function loadOptions(kind: OptionKind) {
  let request = cache.get(kind)
  if (!request) {
    request = api.get<Option[]>(`/api/options/${kind}`).catch((error) => {
      // Geçici API hatası boş liste olarak kalıcılaşmamalı. Sonraki deneme yeni istek atar.
      cache.delete(kind)
      throw error
    })
    cache.set(kind, request)
  }
  return request
}

/** Seçim listeleri: GET /api/options/{kind} → [{value, label, group, code}]. Sayfa ömrü boyunca önbelleklenir. */
export function useOptions(kind: OptionKind, refresh = 0) {
  const [options, setOptions] = useState<Option[]>([])
  useEffect(() => {
    if (refresh > 0) cache.delete(kind)
    let cancelled = false
    let retryTimer: number | undefined
    const load = (attempt = 0) => {
      loadOptions(kind)
        .then((o) => !cancelled && setOptions(o))
        .catch(() => {
          if (cancelled) return
          if (attempt < 2) retryTimer = window.setTimeout(() => load(attempt + 1), 600 * (attempt + 1))
          else setOptions([])
        })
    }
    load()
    return () => {
      cancelled = true
      if (retryTimer !== undefined) window.clearTimeout(retryTimer)
    }
  }, [kind, refresh])
  return options
}

/** Yönetim işlemi sonrası seçim listelerini tazelemek için. */
export function invalidateOptions(...kinds: OptionKind[]) {
  for (const k of kinds) cache.delete(k)
}

/** Select için: kod/etiketle aranabilir liste. exclude: gösterilmeyecek id'ler. */
export function toSelectOptions(options: Option[], exclude: number[] = []) {
  return options.filter((o) => !exclude.includes(o.value)).map((o) => ({ value: o.value, label: o.label }))
}

/** Select için: değer = kod (permission kodu, kullanıcı adı, rol kodu...). */
export function toCodeOptions(options: Option[]) {
  return options.map((o) => ({ value: o.code, label: o.label }))
}
