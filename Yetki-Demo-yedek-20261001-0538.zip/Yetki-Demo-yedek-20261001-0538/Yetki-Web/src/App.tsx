import { AccessBindingsPage, ReportCenterPage } from './pages/WorkspaceCenters'
import { Navigate, Route, Routes } from 'react-router-dom'
import { AppLayout } from './layout/AppLayout'
import { DashboardPage } from './pages/DashboardPage'
import { TenantsPage } from './pages/TenantsPage'
import { UserDetailPage, UsersPage } from './pages/UsersPages'
import { RoleDetailPage, RolesPage } from './pages/RolesPages'
import { GroupDetailPage, GroupsPage } from './pages/GroupsPages'
import { CatalogPage, ClientsPage, ResourceTypesPage } from './pages/CatalogPages'
import { InventoryPage } from './pages/InventoryPage'
import { PermissionDetailPage, PermissionsPage } from './pages/PermissionsPages'
import { PoliciesPage, PolicyDetailPage } from './pages/PoliciesPages'
import { SharedConditionsPage } from './pages/SharedConditionsPage'
import { ConditionTypesPage } from './pages/ConditionTypesPage'
import { EvaluatePage } from './pages/EvaluatePage'
import { NextralPage } from './pages/NextralPage'
import { WhatIfPage } from './pages/WhatIfPage'
import { GatewayPage } from './pages/GatewayPage'
import { AuditPage, ExternalPage, SodPage } from './pages/GovernancePages'
import { OwnershipTeamsPage } from './pages/OwnershipTeamsPage'

export default function App() {
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route index element={<DashboardPage />} />
        <Route path="access-management" element={<AccessBindingsPage />} />
        <Route path="reports" element={<ReportCenterPage />} />
        <Route path="tenants" element={<TenantsPage />} />
        <Route path="units" element={<Navigate to="/tenants" replace />} />
        <Route path="users" element={<UsersPage />} />
        <Route path="users/:id" element={<UserDetailPage />} />
        <Route path="roles" element={<RolesPage />} />
        <Route path="roles/:id" element={<RoleDetailPage />} />
        <Route path="groups" element={<GroupsPage />} />
        <Route path="groups/:id" element={<GroupDetailPage />} />
        <Route path="catalog" element={<CatalogPage />} />
        <Route path="resource-types" element={<ResourceTypesPage />} />
        <Route path="accesses" element={<Navigate to="/catalog?view=list" replace />} />
        <Route path="inventory" element={<InventoryPage />} />
        <Route path="ownership-teams" element={<OwnershipTeamsPage />} />
        <Route path="permissions" element={<PermissionsPage />} />
        <Route path="permissions/:id" element={<PermissionDetailPage />} />
        <Route path="clients" element={<ClientsPage />} />
        <Route path="policies" element={<PoliciesPage />} />
        <Route path="policies/:id" element={<PolicyDetailPage />} />
        <Route path="shared-conditions" element={<SharedConditionsPage />} />
        <Route path="condition-types" element={<ConditionTypesPage />} />
        <Route path="rules" element={<Navigate to="/condition-types" replace />} />
        <Route path="evaluate" element={<EvaluatePage />} />
        <Route path="nextral" element={<NextralPage />} />
        <Route path="what-if" element={<WhatIfPage />} />
        <Route path="gateway" element={<GatewayPage />} />
        <Route path="sdk-demo" element={<Navigate to="/gateway" replace />} />
        <Route path="sod" element={<SodPage />} />
        <Route path="external" element={<ExternalPage />} />
        <Route path="events" element={<Navigate to="/external?tab=provisioning" replace />} />
        <Route path="audit" element={<AuditPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  )
}
