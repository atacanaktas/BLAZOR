import {
  AuditOutlined, BranchesOutlined, CloudServerOutlined, ClusterOutlined,
  ApiOutlined, AppstoreOutlined, DesktopOutlined, ExperimentOutlined, FileProtectOutlined, GlobalOutlined, KeyOutlined,
  FileSearchOutlined, MobileOutlined, PlayCircleOutlined, SafetyCertificateOutlined,
  ShareAltOutlined, TeamOutlined, ThunderboltOutlined, UserOutlined,
} from '@ant-design/icons'

export const workspaces = [
  { key: 'tenants', label: 'Tenants & Organization', icon: <GlobalOutlined />,
    description: 'Tenant, organizasyon birimleri ve hiyerarşi bilgileri.',
    owner: 'Veri sahibi: HR / Identity ekipleri',
    children: [
      { key: '/tenants', label: 'Tenants & Organization', icon: <GlobalOutlined />, task: 'Tenants & Organization', hint: 'Tenant, organizasyon birimleri ve hiyerarşi bilgileri.' },
    ] },
  { key: 'users', label: 'Users & Assignments', icon: <UserOutlined />,
    description: 'HR kaynaklı kullanıcı profilleri, rol, şube ve organizasyon atamaları. Yetki motoru bu bilgileri karar girdisi olarak kullanır.',
    owner: 'Veri sahibi: HR / Identity ekipleri',
    children: [
      { key: '/users', label: 'Users & Assignments', icon: <UserOutlined />, task: 'Users & Assignments', hint: 'User profili, iş rolü, şube ve organizasyon atamaları.' },
    ] },
  { key: 'roles', label: 'Role Directory', icon: <SafetyCertificateOutlined />,
    description: 'İş rolü tanımları ve sahipleri. Rolün eriştiği yetkiler Rol policy\'leri ve permission\'lar üzerinden gelir.',
    owner: 'Veri sahibi: HR / Identity ekipleri',
    children: [
      { key: '/roles', label: 'Role Directory', icon: <SafetyCertificateOutlined />, task: 'Role Directory', hint: 'İş rolü tanımları ve sahipleri. Rolün eriştiği yetkiler Rol policy\'leri ve permission\'lar üzerinden gelir.' },
    ] },
  { key: 'catalogs', label: 'Authorization Model', icon: <ClusterOutlined />,
    description: 'Yetki tanımları: uygulama (resource server) → resource → scope → URI eşlemeleri, resource tipleri, client\'lar ve condition tipleri. Envanter (Swagger / ekran listesi) sadece karşılaştırma içindir.',
    owner: 'Tanım sahibi: Yetki yönetimi',
    children: [
      { key: '/catalog', label: 'Resources', icon: <ClusterOutlined />, task: 'Resources', hint: 'Uygulama → resource (tipli) → scope\'lar ve METHOD + URI eşlemeleri; URL / üst-alt ile otomatik gruplanır.' },
      { key: '/inventory', label: 'Inventory & Coverage', icon: <FileSearchOutlined />, task: 'Inventory & Coverage', hint: 'Swagger ve ekran listesini yetki tanımlarıyla karşılaştır: tanımsız, atıl, korunmayan.' },
      { key: '/resource-types', label: 'Resource Types', icon: <AppstoreOutlined />, task: 'Resource Types', hint: 'Endpoint, menü, ekran, buton... resource sınıfları (CRUD).' },
      { key: '/clients', label: 'Clients', icon: <MobileOutlined />, task: 'Clients', hint: 'İsteği başlatan uygulamalar, aracılar ve servis hesapları.' },
      { key: '/condition-types', label: 'Condition Types', icon: <BranchesOutlined />, task: 'Condition Types', hint: 'Rule oluştururken kullanılabilen Condition tipleri ve parametre sözleşmeleri.' },
    ] },
  { key: 'ownership', label: 'Ownership Teams', icon: <TeamOutlined />,
    description: 'Uygulama ve resource sahipliğinde seçilebilen ekipler ve ekip hiyerarşisi.',
    owner: 'Tanım sahibi: Uygulama ekipleri',
    children: [
      { key: '/ownership-teams', label: 'Ownership Teams', icon: <TeamOutlined />, task: 'Ownership Teams', hint: 'Uygulama ve resource sahiplik ekipleri.' },
    ] },
  { key: 'sod', label: 'SoD Control Catalog', icon: <SafetyCertificateOutlined />,
    description: 'Birlikte bulunamayan rol / yetki (resource:scope) tanımları, severity ve enforcement; açık ihlaller.',
    owner: 'Tanım sahibi: Risk / İç kontrol ekipleri',
    children: [
      { key: '/sod', label: 'SoD Control Catalog', icon: <SafetyCertificateOutlined />, task: 'SoD Control Catalog', hint: 'Birlikte bulunamayan rol / yetki tanımları, severity ve enforcement.' },
    ] },
  { key: 'external', label: 'External Dependencies', icon: <CloudServerOutlined />,
    description: 'Resource / resource:scope → dış sistem (RACF / LDAP) erişimi, zincir bağımlılıklar, mutabakat, provisioning talimatları ve outbox bildirimleri.',
    owner: 'Tanım sahibi: Entegrasyon ekipleri',
    children: [
      { key: '/external', label: 'External Dependencies', icon: <CloudServerOutlined />, task: 'External Dependencies', hint: 'Dış sistem yetkileri, katalog bağımlılıkları, mutabakat, provisioning talimatları ve outbox bildirimleri.' },
    ] },
  { key: 'management', label: 'Access Management', icon: <KeyOutlined />,
    description: 'Keycloak modeli: Permission (resource / scope ← policy\'ler) ve Policy (rol, grup, kullanıcı, kanal, koşul, birleşik).',
    owner: 'İşlem sahibi: Yetki yönetimi ekibi',
    children: [
      { key: '/access-management', label: 'Access Overview', icon: <KeyOutlined />, task: 'Access Overview', hint: 'Yetki yönetimi işlerine hızlı giriş.' },
      { key: '/permissions', label: 'Permissions', icon: <KeyOutlined />, task: 'Permissions', hint: 'Hangi resource / scope, hangi policy\'lerle korunur?' },
      { key: '/policies', label: 'Policies & Rules', icon: <FileProtectOutlined />, task: 'Policies & Rules', hint: 'Kim (rol / grup / kullanıcı / kanal) ve hangi koşulda (ABAC kuralları)?' },
      { key: '/groups', label: 'Access Groups', icon: <TeamOutlined />, task: 'Access Groups', hint: 'Erişim amaçlı grup, üyelik kriterleri ve rolleri.' },
      { key: '/shared-conditions', label: 'Shared Conditions', icon: <ShareAltOutlined />, task: 'Shared Conditions', hint: 'Policy’lerde tekrar kullanılan Condition ifadeleri.' },
      { key: '/what-if', label: 'Change Simulation', icon: <ExperimentOutlined />, task: 'Change Simulation', hint: 'Değişikliği uygulamadan önce erişim ve SoD etkisini incele.' },
    ] },
  { key: 'reporting', label: 'Monitoring & Reports', icon: <AuditOutlined />,
    description: 'Sahibinden bağımsız olarak tüm alanları incele: mevcut erişim, karar gerekçesi, kontrol ihlalleri ve değişiklik kayıtları.',
    owner: 'Görünürlük: HR + Catalogs + Access Management',
    children: [
      { key: '/reports', label: 'Report Center', icon: <AuditOutlined />, task: 'Report Center', hint: 'Kim neye erişebilir? Endpoint nasıl korunuyor? Role kimlerde? SoD durumu nedir?' },
      { key: '/audit', label: 'Audit & Decision History', icon: <AuditOutlined />, task: 'Audit & Decision History', hint: 'Geçmiş kararın kaydedilmiş gerekçesi ve yönetim değişiklikleri.' },
      { key: '/evaluate', label: 'Decision Analysis', icon: <ThunderboltOutlined />, task: 'Decision Analysis', hint: 'Güncel verilerle bir isteğin neden PERMIT / DENY aldığını incele.' },
    ] },
  { key: 'demos', label: 'Demos & Prototypes', icon: <PlayCircleOutlined />,
    description: 'Örnek uygulamalar üzerinde yetki kontrolünü deneyin.',
    owner: 'Demo ve tasarım alternatifleri',
    children: [
      { key: '/nextral', label: 'Nextral Demo', icon: <DesktopOutlined />, task: 'Nextral Demo', hint: 'User erişimini örnek Nextral ekranında dene.' },
      { key: '/gateway', label: 'Gateway Simulator', icon: <ApiOutlined />, task: 'Gateway Simulator', hint: 'METHOD + URI ile gateway yetki kontrolünü dene; tanımsız endpoint kapalı.' },
    ] },
]
export const sections = workspaces

export const bindingTasks = [
  { to: '/catalog', title: 'Resource → scope → URI', text: 'Uygulamada resource tanımla, scope\'larını seç, HTTP tiplerinde METHOD + URI desenlerini scope\'a eşle.' },
  { to: '/inventory', title: 'Envanter ↔ tanımlar', text: 'Swagger ve ekran listesini içe aktar; tanımsız olanları tek tıkla tanımla, atıl olanları gör.' },
  { to: '/resource-types', title: 'Resource tipleri', text: 'Endpoint, menü, ekran, buton gibi tipleri tanımla (HTTP eşleşmesi, hiyerarşi).' },
  { to: '/permissions', title: 'Resource / scope ← Policy (Permission)', text: 'Hangi yetkinin hangi policy\'lerle korunacağını belirle; kaydetmeden önce kim kazanır / kaybeder gör.' },
  { to: '/policies', title: 'Kim? Hangi koşulda? (Policy)', text: 'Rol, grup, kullanıcı, kanal (client), koşul (ABAC) ve birleşik policy\'ler.' },
  { to: '/groups', title: 'Grup → rol', text: 'Erişim amaçlı grup üyelik kriterleri ve grubun verdiği roller.' },
  { to: '/gateway', title: 'Gateway ile dene', text: 'METHOD + URI isteği gönder, eşlenen yetkiyi ve kararı gör.' },
]
export const reportGroups = [
  { title: 'Current Access', description: 'Güncel modeldeki erişim yolları; Policy sonucu istek bağlamına göre değişebilir.', items: [
    { to: '/users', title: 'X User bugün nerelere erişebilir, neden?', text: 'User seç → etkin yetkiler (resource:scope), permission ← policy kaynakları, koşullu olanlar.' },
    { to: '/roles', title: 'Y Role kimlerde var?', text: 'Role seç → doğrudan ve Group üzerinden sahipler.' },
    { to: '/groups', title: 'Group üyeliği nereden geliyor?', text: 'Üyeleri, dinamik kriterleri ve erişim bağlantılarını incele.' },
  ] },
  { title: 'Resource Protection & Catalogs', description: 'Uygulama, entegrasyon ve kontrol sahiplerinin tanımları da raporlama kapsamındadır.', items: [
    { to: '/catalog', title: 'X endpoint nasıl korunuyor?', text: 'Resource seç → URI → scope → koruyan permission\'lar ve sahipler.' },
    { to: '/catalog?view=list', title: 'Bir yetki kimde var?', text: 'Resources → Liste görünümünden resource:scope seç → sahipler ve neden.' },
    { to: '/inventory', title: 'Uygulamadaki her endpoint / ekran korunuyor mu?', text: 'Envanter ↔ yetki tanımları: tanımsız, atıl, permission\'sız.' },
    { to: '/permissions', title: 'Permission neyi, hangi policy\'lerle koruyor?', text: 'Kapsadığı yetkiler, policy\'ler ve aynı yetkideki diğer permission\'lar.' },
    { to: '/external', title: 'Hangi dış sistem erişimleri gerekli?', text: 'Bağımlılık zincirlerini, access level ve drift durumunu incele.' },
    { to: '/sod?tab=v', title: 'SoD ihlalleri kimlerde var?', text: 'Açık ihlalleri ve kontrol sonuçlarını incele; gerektiğinde tarama çalıştır.' },
    { to: '/sod?tab=r', title: 'Hangi rol / yetki birlikte bulunamaz?', text: 'Kontrol kataloğunu, severity ve enforcement tanımlarını incele.' },
    { to: '/tenants', title: 'Organizasyon yapısı nasıl?', text: 'Tenant ve organizasyon hiyerarşisini incele.' },
    { to: '/resource-types', title: 'Hangi resource tipleri var?', text: 'Endpoint / menü / ekran / buton tiplerini ve kullanımlarını incele.' },
    { to: '/clients', title: 'Hangi client\'lar hangi kanal policy\'lerinde?', text: 'Client, aracı, servis hesabı ve onları kullanan kanal policy\'leri.' },
    { to: '/condition-types', title: 'Hangi Condition tipleri destekleniyor?', text: 'Condition tiplerini ve parametrelerini incele.' },
    { to: '/policies', title: 'Hangi policy ve kural uygulanıyor?', text: 'Policy üyeleri, kuralları ve onları kullanan permission\'lar.' },
    { to: '/shared-conditions', title: 'Hangi ortak Condition kullanılıyor?', text: 'Tekrar kullanılan Condition tanımlarını incele.' },
  ] },
  { title: 'History & Operations', description: 'Geçmiş kayıtlar ve güncel simülasyon farklı kanıtlardır.', items: [
    { to: '/audit', title: 'T anındaki işlem neden PERMIT aldı?', text: 'Audit kaydını aç → o kararla birlikte kaydedilmiş gerekçe ve erişim kaynaklarını incele.' },
    { to: '/audit', title: 'Kim, hangi tanımı veya atamayı değiştirdi?', text: 'Mevcut audit kayıtlarını actor, kategori ve metin ile ara.' },
    { to: '/external?tab=provisioning', title: 'Değişiklik dış sisteme ulaştı mı?', text: 'Provisioning aksiyonlarını ve event teslim durumlarını incele.' },
    { to: '/evaluate', title: 'Aynı istek bugün hangi kararı alır?', text: 'Güncel model ile Decision Analysis çalıştır; geçmiş kararın yerine kullanma.' },
    { to: '/what-if', title: 'Değişiklik kimleri etkiler?', text: 'Uygulamadan önce erişim değişimini ve SoD etkisini simüle et.' },
  ] },
]
