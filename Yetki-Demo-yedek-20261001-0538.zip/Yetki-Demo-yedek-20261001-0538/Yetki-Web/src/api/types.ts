// Yetki Motoru API sözleşme tipleri (backend DTO'larıyla birebir).
// Model: Keycloak Authorization Services — Resource (tipli) · Scope · Policy (rol/grup/kullanıcı/client/condition/aggregate) · Permission.

export type DecisionType = 'Permit' | 'Deny' | 'NotApplicable' | 'Indeterminate'
export type TriState = 'True' | 'False' | 'Indeterminate'
export type ConditionKind = 'Predicate' | 'AllOf' | 'AnyOf' | 'Not' | 'Reference'
export type InclusionMode = 'Include' | 'Exclude'
/** Intermediary = aracı (gateway / BFF / kullanıcı adına çağıran servis): isteği başlatmaz, 'via' zincirinde yer alır. */
export type ClientType = 'Confidential' | 'Public' | 'Service' | 'Intermediary'
export type Severity = 'Low' | 'Medium' | 'High' | 'Critical'
export type PolicyType = 'Role' | 'Group' | 'User' | 'Client' | 'Condition' | 'Aggregate'
export type PolicyLogic = 'Positive' | 'Negative'
export type DecisionStrategy = 'Unanimous' | 'Affirmative' | 'Consensus'
export type PolicyMode = 'Enforce' | 'ReportOnly' | 'Advisory'
export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | '*'

export interface Option {
  value: number
  label: string
  group?: string
  code: string
}

// ------------------------------------------------------------------ Katalog

export interface ResourceTypeView {
  id: number
  code: string
  name: string
  description?: string
  matchesHttp: boolean
  supportsHierarchy: boolean
  color?: string
  isActive: boolean
  resourceCount: number
  permissionCount: number
}

/** Yetki tanımları ağacındaki resource. Gruplama türetilir: HTTP'de URL öneki (group), UI'da üst-alt (parentId). */
export interface CatalogTreeResource {
  id: number
  code: string
  name: string
  isActive: boolean
  parentId?: number
  externalCode?: string
  order: number
  type: string
  typeName: string
  color?: string
  matchesHttp: boolean
  scopes: string[]
  uris: { method: HttpMethod; pattern: string }[]
  /** URI'lerin ortak öneki (ilk parametreye kadar), ör. /v1/vadeli-hesap. URI yoksa boş. */
  group: string
  protectedScopes: number
}

export interface CatalogTreeApp {
  id: number
  code: string
  name: string
  type: string
  isActive: boolean
  strategy: DecisionStrategy
  resourceCount: number
  scopeCount: number
  permissionCount: number
  resources: CatalogTreeResource[]
}

export interface CatalogTreeTenant {
  id: number
  code: string
  name: string
  applications: CatalogTreeApp[]
}

export interface ResourceDetail {
  resource: {
    id: number; code: string; name: string; isActive: boolean; order: number; applicationId: number; application: string; externalCode?: string; path: string
    resourceTypeId: number; type: string; typeName: string; matchesHttp: boolean; supportsHierarchy: boolean; parentId?: number; parent?: string
    description?: string; ownerTeamId?: number; ownerTeam?: string
  }
  scopes: {
    resourceScopeId: number; scopeId: number; code: string; name: string; key: string; riskLevel: Severity
    permissions: { id: number; code: string; name: string; identity: boolean }[]
    holderCount: number
  }[]
  uris: { id: number; method: HttpMethod; pattern: string; scopeId: number; scope?: string }[]
  children: { id: number; code: string; name: string; type: string }[]
}

export interface ResourceScopeView {
  id: number
  key: string
  name: string
  application: string
  resourceId: number
  resource: string
  resourceType: string
  color?: string
  scope: string
  path: string
  riskLevel: Severity
  isActive: boolean
  permissions: string[]
  uris: string[]
  holderCount: number
}

// ------------------------------------------------------------------ Policy / Permission

export interface PolicyMemberView {
  id: number
  code: string
  name?: string
}

export interface PolicyListItem {
  id: number
  code: string
  name: string
  type: PolicyType
  logic: PolicyLogic
  mode: PolicyMode
  isActive: boolean
  strategy: DecisionStrategy
  version: number
  tenant: string
  members: PolicyMemberView[]
  rules: { code: string; name: string; isActive: boolean; expression: string }[]
  obligations: string[]
  permissions: string[]
}

/** Permission'ın neye uygulandığı (açık seçim; boş liste "hiçbiri" demektir). */
export type PermissionTarget = 'Resources' | 'ResourceType' | 'Application'

export interface PermissionListItem {
  id: number
  code: string
  name: string
  isActive: boolean
  strategy: DecisionStrategy
  application: string
  applicationId: number
  target: PermissionTarget
  allScopes: boolean
  resourceType?: string
  resources: string[]
  scopes: string[]
  policies: { id: number; code: string; type?: PolicyType }[]
  coverage: number
  hasIdentityPolicy: boolean
}

// ------------------------------------------------------------------ Etkin erişim

export interface MembershipReason {
  kind: 'Member' | 'Filter'
  filterOrder?: number
  text: string
}

export interface GroupMembership {
  groupId: number
  code: string
  name: string
  tenant: string
  reasons: MembershipReason[]
}

/** Erişimin kaynağı: hangi permission'daki hangi policy, neden (ör. "rol SUBEMDR (doğrudan atama)"). */
export interface AccessSource {
  permission: string
  policy: string
  policyType: PolicyType
  path: string
}

export interface EffectiveAccess {
  resourceScopeId: number
  key: string
  name: string
  application: string
  resource: string
  resourceType: string
  scope: string
  path: string
  riskLevel: Severity
  /** Çalışma anında değerlendirilen koşullara (condition / client policy) bağlı. */
  conditional: boolean
  sources: AccessSource[]
  conditions: string[]
}

export interface EffectiveAccessSet {
  userId: number
  userName: string
  fullName: string
  tenant: string
  isActive: boolean
  modelVersion: number
  computedAt: string
  roles: { roleId: number; code: string; name: string; tenant: string; sources: { kind: string; groupCode?: string; text: string; validUntil?: string }[] }[]
  groups: GroupMembership[]
  excludedFromGroups: { groupId: number; code: string; reason: string }[]
  accesses: EffectiveAccess[]
  ignoredAssignments: string[]
}

// ------------------------------------------------------------------ Karar

export interface UsedAttribute {
  attribute: string
  value?: string | null
  source: string
  resolved: boolean
}

export interface ConditionTrace {
  kind: ConditionKind
  conditionType?: string
  expression: string
  value: TriState
  message?: string
  missingAttributes?: string[]
  evidence?: UsedAttribute[]
  children?: ConditionTrace[]
}

/** Rule sonucu: result Permit = sağlandı · Deny = sağlanmadı · Indeterminate = belirsiz · NotApplicable = pasif. */
export interface RuleEvaluation {
  ruleId: number
  code: string
  name: string
  order: number
  isActive: boolean
  conditionValue: TriState
  result: DecisionType
  reasonCode?: string
  message: string
  expression: string
  condition?: ConditionTrace
  missingAttributes: string[]
  evidence: UsedAttribute[]
  isDeciding: boolean
}

export interface PolicyEvaluation {
  policyId: number
  code: string
  name: string
  type: PolicyType
  logic: PolicyLogic
  mode: PolicyMode
  strategy: DecisionStrategy
  version: number
  result: DecisionType
  detail: string
  decidingRule?: string
  rules: RuleEvaluation[]
  children: PolicyEvaluation[]
  isDeciding: boolean
}

export interface PermissionEvaluation {
  permissionId: number
  code: string
  name: string
  strategy: DecisionStrategy
  result: DecisionType
  policies: PolicyEvaluation[]
  isDeciding: boolean
}

export interface DecisionStep {
  step: string
  outcome: 'Pass' | 'Fail' | 'Info' | 'Skip'
  detail: string
}

/** Karar ile PEP'e dönen yükümlülük (ör. MASK_FIELDS). PEP tanımıyorsa erişimi reddetmeli. */
export interface DecisionObligation {
  code: string
  policy: string
  parameters: Record<string, string>
}

export interface AuthorizationDecision {
  decisionId: string
  decision: DecisionType
  isAllowed: boolean
  reasonCode: string
  humanReadableReason: string
  userName?: string
  tenant?: string
  client?: string
  /** Soruyu soran (doğrulanmış) client; boşsa iç çağrı (konsol / simülasyon). */
  caller?: string
  via: string[]
  obligations: DecisionObligation[]
  permission?: string
  permissionName?: string
  resourceCode?: string
  resourceType?: string
  scope?: string
  application?: string
  catalogPath?: string
  http?: string
  matchedUri?: string
  resource?: string
  decidingPermission?: string
  decidingPolicy?: string
  decidingRule?: string
  evaluatedAt: string
  isSimulation: boolean
  modelVersion: number
  durationMs: number
  steps: DecisionStep[]
  permissions: PermissionEvaluation[]
  reportOnlyDenials: string[]
  failedRules: string[]
  missingAttributes: string[]
  evidence: UsedAttribute[]
  context: Record<string, string | null>
}

export interface ObligationTypeDef {
  code: string
  name: string
  description: string
  parameters: { key: string; label: string; required: boolean; hint?: string }[]
}

/** İstek: { tenant, client, subject, (http | resource + scope | permission), context }. */
export interface AuthorizationRequest {
  tenant?: string
  via?: string[]
  subject: { id?: string; userId?: number }
  http?: { application?: string; method: string; path: string }
  scope?: string
  permission?: string
  resource?: { type?: string; id?: string; properties?: Record<string, string> }
  context: Record<string, string>
  client?: string
  /** Soran client (sadece konsol / simülasyon; gerçekte motor token'ından çıkar). */
  caller?: string
  correlationId?: string
}

// ------------------------------------------------------------------ Entitlement

export interface RuntimeCheck {
  decision: DecisionType
  reasonCode: string
  reason: string
}

export interface EntitledAccess {
  resourceScopeId: number
  key: string
  name: string
  application: string
  resource: string
  resourceType: string
  scope: string
  path: string
  riskLevel: Severity
  sources: string[]
  conditional: boolean
  conditions: string[]
  runtime?: RuntimeCheck
}

export interface UiEntitlement {
  resourceId: number
  code: string
  name: string
  resourceType: string
  parentCode?: string
  order: number
  path: string
  enabled: boolean
  reason: string
  scopes: { scope: string; key: string; enabled: boolean; reason: string; runtime?: RuntimeCheck }[]
}

export interface EntitlementResult {
  userName: string
  fullName: string
  tenant: string
  client?: string
  modelVersion: number
  computedAt: string
  eTag: string
  accesses: EntitledAccess[]
  uiResources: UiEntitlement[]
}

// ------------------------------------------------------------------ Condition (ABAC)

export interface ConditionView {
  id: number
  kind: ConditionKind
  conditionType?: string
  parameters: Record<string, string>
  children: ConditionView[]
  sharedCondition?: string
  sharedConditionVersion?: number
}

export interface ConditionDraft {
  kind: ConditionKind
  conditionTypeCode?: string
  sharedConditionCode?: string
  parameters: Record<string, string>
  children: ConditionDraft[]
}

export interface ParamDef {
  key: string
  label: string
  type: string
  required: boolean
  defaultValue?: string
  description?: string
}

export interface ConditionTypeInfo {
  id: number
  code: string
  name: string
  description?: string
  defaultScope: string
  parameterSchemaJson: string
  requiredAttributes?: string
  isAvailable: boolean
  isSubjectOnly: boolean
}

export interface SharedConditionInfo {
  id: number
  code: string
  name: string
  description?: string
  scope: 'Global' | 'Domain'
  domain?: string
  isActive: boolean
  version: number
  expression: string
  usageCount: number
  policies: string[]
}

export interface RuleView {
  id: number
  code: string
  name: string
  description?: string
  order: number
  reasonCode?: string
  isActive: boolean
  expression: string
  condition?: ConditionView
  policyId?: number
  policy?: string
}

export interface RuleDraft {
  policyId: number
  code: string
  name?: string
  order: number
  reasonCode?: string
  condition: ConditionDraft
}

// ------------------------------------------------------------------ Grup

export interface GroupCriterionDraft {
  attribute: string
  values: string[]
}

export interface GroupFilterDraft {
  mode: InclusionMode
  description?: string
  criteria: GroupCriterionDraft[]
}

export interface GroupCriterionInfo {
  code: string
  name: string
  description: string
  valueSource: 'role' | 'orgUnit' | 'orgUnitType' | 'tenant' | 'user' | 'userKind' | 'text'
}

// ------------------------------------------------------------------ Değişiklik setleri (What-If)

export interface AuthorizationChangeSet {
  userRoles?: { userId: number; roleId: number; add: boolean; validUntil?: string }[]
  userUnits?: { userId: number; orgUnitId: number; add: boolean }[]
  groupMembers?: { groupId: number; userId: number; add: boolean; validUntil?: string }[]
  groupRoles?: { groupId: number; roleId: number; add: boolean }[]
  groupFilters?: { groupId: number; filters: GroupFilterDraft[] }[]
  groupActivations?: { id: number; isActive: boolean }[]
  roleUpdates?: { roleId: number; isActive?: boolean; isInheritable?: boolean }[]
  userUpdates?: { userId: number; title?: string; isActive?: boolean; isOnLeave?: boolean; cashWithdrawalLimit?: number }[]
}

export interface PolicyChangeSet {
  policyActivations?: { policyId: number; isActive: boolean }[]
  policyModes?: { policyId: number; mode: PolicyMode }[]
  policyStrategies?: { policyId: number; strategy: DecisionStrategy }[]
  ruleOverrides?: { ruleId: number; isActive?: boolean; order?: number }[]
  conditionOverrides?: { conditionId: number; parameters: Record<string, string> }[]
  addedRules?: RuleDraft[]
  removedRuleIds?: number[]
  replacedRules?: { ruleId: number; rule: RuleDraft }[]
  sharedConditionReplacements?: { sharedConditionId: number; condition: ConditionDraft }[]
}

// ------------------------------------------------------------------ Etki analizi

export interface AccessDelta {
  resourceScopeId: number
  key: string
  name: string
  path: string
  conditional: boolean
  sources: string[]
}

export interface SodConflict {
  sodRuleId: number
  code: string
  name: string
  severity: Severity
  enforcement: 'Warn' | 'Block'
  matchedMembers: { type: string; id: number; code: string; name: string; paths: string[] }[]
}

// ------------------------------------------------------------------ Dış sistem (RACF / LDAP)

export type ExternalAccessLevel = 'Read' | 'Update' | 'Control' | 'Alter'

/** Dış sistemde açılacak / değişecek / kapanacak yetki (seviye büyük harf: READ, UPDATE...). */
export interface ExternalChange {
  system: string
  code: string
  resourceClass?: string
  level?: string
  previousLevel?: string
  reasons: string[]
}

export interface ExternalUserImpact {
  userId: number
  userName: string
  grants: ExternalChange[]
  modifies: ExternalChange[]
  revokes: ExternalChange[]
}

export interface ExternalImpactResult {
  dryRun: boolean
  summary: string
  affectedUserCount: number
  users: ExternalUserImpact[]
}

export interface ExternalTargetView {
  externalPermissionId: number
  system: string
  code: string
  name?: string
  resourceClass?: string
  hasAccessLevels: boolean
}

export interface ExternalDiffItem {
  target: ExternalTargetView
  desiredLevel?: ExternalAccessLevel
  currentLevel?: ExternalAccessLevel
  action: 'Grant' | 'Modify' | 'Revoke' | 'None'
  reasons: string[]
}

export interface UserExternalStatus {
  userId: number
  userName: string
  isActive: boolean
  inSync: boolean
  items: ExternalDiffItem[]
}

export interface ExternalDependencyView {
  id: number
  ownerType: 'Resource' | 'ResourceScope'
  owner: string
  resourceId?: number
  resourceScopeId?: number
  ownerResourceId?: number
  externalPermissionId: number
  system: string
  code: string
  name?: string
  resourceClass?: string
  hasAccessLevels: boolean
  level?: ExternalAccessLevel
  note?: string
}

export interface ExternalSystemView {
  id: number
  code: string
  name: string
  hasAccessLevels: boolean
  permissions: {
    id: number; code: string; name?: string; resourceClass?: string; description?: string; dependencyCount: number; userCount: number
    requires: { id: number; key: string; level?: ExternalAccessLevel }[]
    requiredBy: string[]
  }[]
}

export interface UserImpact {
  userId: number
  userName: string
  fullName: string
  tenant: string
  addedAccesses: AccessDelta[]
  removedAccesses: AccessDelta[]
  retainedAccesses: { resourceScopeId: number; key: string; name: string; before: string[]; after: string[] }[]
  addedRoles: string[]
  removedRoles: string[]
  addedGroups: string[]
  removedGroups: string[]
  newSodConflicts: SodConflict[]
  externalGrants: ExternalChange[]
  externalRevokes: ExternalChange[]
}

export interface ChangeImpactResult {
  dryRun: boolean
  applied: boolean
  blocked: boolean
  summary: string
  affectedUserCount: number
  evaluatedUserCount: number
  users: UserImpact[]
  blockingConflicts: { userId: number; userName: string; conflict: SodConflict }[]
  warnings: { userId: number; userName: string; conflict: SodConflict }[]
}

/** Tanım değişikliği sonucu (policy / permission): id + erişim etkisi + uyarılar. */
export interface DefinitionChangeResult {
  id?: number
  impact: ChangeImpactResult
  warnings: string[]
}

export interface ImpactScenario {
  name: string
  context: Record<string, string | undefined>
  client?: string
}

export type DecisionChange = 'NEWLY_DENIED' | 'NEWLY_INDETERMINATE' | 'NEWLY_ALLOWED' | 'REASON_CHANGED' | 'UNCHANGED'

export interface AccessPolicyDiff {
  resourceScopeId: number
  key: string
  name: string
  path: string
  holderCount: number
  policiesBefore: string[]
  policiesAfter: string[]
  rulesBefore: { policy: string; code: string; name: string; expression: string }[]
  rulesAfter: { policy: string; code: string; name: string; expression: string }[]
  addedRules: string[]
  removedRules: string[]
  changedRules: { policy: string; ruleCode: string; expressionBefore: string; expressionAfter: string }[]
  requiredAttributesAfter: string[]
  newRequiredAttributes: string[]
  becomesUnrestricted: boolean
  becomesRestricted: boolean
}

export interface DecisionBrief {
  decision: DecisionType
  reasonCode: string
  reason: string
  decidingPolicy?: string
  decidingRule?: string
}

export interface PolicyImpactResult {
  summary: string
  accesses: AccessPolicyDiff[]
  affectedUsers: { userId: number; userName: string; fullName: string; tenant: string; permissions: string[] }[]
  scenarios: ImpactScenario[]
  rows: { userId: number; userName: string; fullName: string; permission: string; scenario: string; before: DecisionBrief; after: DecisionBrief; change: DecisionChange }[]
  evaluations: number
  truncated: boolean
  newlyDenied: number
  newlyAllowed: number
  otherChanged: number
  unchanged: number
  durationMs: number
}

// ------------------------------------------------------------------ Envanter & kapsama

export type InventoryKind = 'Endpoint' | 'UiElement'
export type InventoryFormat = 'Lines' | 'OpenApi' | 'Json'
/** Protected = korunuyor · NoPermission = tanımlı ama permission yok (kapalı) · Undefined = tanımsız (kapalı) · Ambiguous = belirsiz eşleşme */
export type CoverageStatus = 'Protected' | 'NoPermission' | 'Undefined' | 'Ambiguous'

export interface InventorySnapshotInfo {
  kind: InventoryKind
  source: string
  importedAt: string
  importedBy: string
  itemCount: number
}

export interface EndpointCoverage {
  method: string
  path: string
  name?: string
  group: string
  status: CoverageStatus
  key?: string
  resourceId?: number
  matchedUri?: string
  permissions: string[]
  ambiguous: string[]
  suggestedScope: string
  suggestedResourceId?: number
  suggestedResourceCode?: string
  suggestedCode: string
}

export interface UiCoverage {
  code: string
  name?: string
  parentCode?: string
  elementType?: string
  status: CoverageStatus
  resourceId?: number
  resource?: string
  scopes: { key: string; protected: boolean }[]
  suggestedCode: string
  suggestedTypeId?: number
  suggestedParentId?: number
}

export interface CoverageReport {
  applicationId: number
  application: string
  endpoints?: InventorySnapshotInfo
  uiElements?: InventorySnapshotInfo
  endpointItems: EndpointCoverage[]
  staleUris: { resourceId: number; resource: string; method: string; pattern: string; key: string; group: string }[]
  uiItems: UiCoverage[]
  staleUiResources: { resourceId: number; code: string; name: string; type: string; externalCode?: string }[]
}
