import { Alert } from 'antd'
import { ArrowRightOutlined } from '@ant-design/icons'
import { Link } from 'react-router-dom'
import { PageHeader } from '../components/common'
import { bindingTasks, reportGroups } from '../layout/navigation'
import './DashboardPage.css'

function Entry({ item }: { item: { to: string; title: string; text: string } }) {
  return <Link to={item.to} className="task-link"><span><strong>{item.title}</strong><small>{item.text}</small></span><ArrowRightOutlined /></Link>
}

export function AccessBindingsPage() {
  return <div className="task-dashboard">
    <PageHeader title="Access Overview" subtitle="Keycloak modeli: resource (tipli) üzerinde scope'lar; permission'lar bunları policy'lerle korur." />
    <div className="binding-flow" aria-label="Erişim bağlantıları">
      <span>METHOD + URI / Menü / Ekran</span><b>→</b><span>resource:scope</span><b>←</b><span>Permission</span><b>←</b><span>Policy (rol / grup / kanal / koşul)</span>
      <span className="binding-policy">Tanımsız URI veya permission'sız scope → erişim kapalı</span>
    </div>
    <div className="task-links">{bindingTasks.map((item) => <Entry key={item.title} item={item} />)}</div>
  </div>
}

export function ReportCenterPage() {
  return <div className="task-dashboard">
    <PageHeader title="Report Center" subtitle="Tanımın sahibi kim olursa olsun, erişimleri, kontrolleri ve kayıtlı işlemleri buradan inceleyin." />
    <Alert type="info" showIcon title="Güncel durum ve geçmiş karar"
      description="Mevcut rapor ve detay ekranlarına yönlendirir. Geçmiş karar için saklanan audit kanıtını kullanın; güncel modelle yapılan analiz, T anındaki durumun yeniden kurulması değildir." />
    {reportGroups.map((group) => <section key={group.title}>
      <div className="workspace-section-heading"><h2>{group.title}</h2><p>{group.description}</p></div>
      <div className="task-links">{group.items.map((item) => <Entry key={item.title} item={item} />)}</div>
    </section>)}
  </div>
}
