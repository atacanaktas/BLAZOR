import { Alert, App, Breadcrumb, Button, Card, Checkbox, Col, Descriptions, Drawer, Dropdown, Empty, Flex, Form, Input, InputNumber, Modal, Popconfirm, Row, Segmented, Select, Switch, Table, Tag, Tooltip, Tree, Typography } from 'antd'
import { AppstoreOutlined, ApartmentOutlined, DeleteOutlined, EditOutlined, FolderOutlined, GlobalOutlined, KeyOutlined, LinkOutlined, PlusOutlined, SearchOutlined, UnorderedListOutlined } from '@ant-design/icons'
import { useMemo, useState, type ReactNode } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import type {
  CatalogTreeApp, CatalogTreeResource, CatalogTreeTenant, ChangeImpactResult, DecisionStrategy, ExternalDependencyView,
  ResourceDetail, ResourceScopeView, ResourceTypeView, Severity,
} from '../api/types'
import { ResourceModal, ScopeModal, UriModal, httpMethods as methods, severities } from '../components/ResourceForms'
import { AddDependencyButton, ExternalDependencyList, ExternalDependencyModal, type DependencyOwner } from '../components/External'
import { invalidateOptions, toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { invalidateCatalogTree, useCatalogTree } from '../components/Catalog'
import { AccessKey, ActiveTag, Code, MethodTag, PageGuide, PageHeader, ResourceTypeTag, SeverityTag, StrategyTag, TenantTag, fmt, strategyHelp, strategyLabel } from '../components/common'

const strategies: DecisionStrategy[] = ['Unanimous', 'Affirmative', 'Consensus']

type Dialog =
  | { kind: 'app'; tenantId?: number; application?: AppDetail['application'] }
  | { kind: 'resource'; applicationId: number; parentId?: number; resource?: ResourceDetail }

interface AppDetail {
  application: { id: number; code: string; name: string; type: string; isActive: boolean; tenantId: number; tenant: string; decisionStrategy: DecisionStrategy; description?: string; ownerTeamId?: number; ownerTeam?: string; ownerUserId?: number }
  scopes: { id: number; code: string; name: string; resourceCount: number }[]
  permissions: { id: number; code: string; name: string; isActive: boolean; coverage: number }[]
  clients: { id: number; clientId: string; name: string }[]
}

// ================================ Yetki tanımları (Resources) ================================

export function CatalogPage() {
  const [refresh, setRefresh] = useState(0)
  const tree = useCatalogTree(refresh)
  const [params, setParams] = useSearchParams()
  const [search, setSearch] = useState('')
  const [dialog, setDialog] = useState<Dialog>()
  const refreshTree = () => { invalidateCatalogTree(); invalidateOptions('resources', 'resource-scopes', 'scopes', 'applications'); setRefresh((r) => r + 1) }
  const view = params.get('view') === 'list' ? 'list' : 'tree'
  const sel = { tenant: params.get('tenant'), app: params.get('app'), resource: params.get('resource') }
  const selectedKey = sel.resource ? `res:${sel.resource}` : sel.app ? `app:${sel.app}` : sel.tenant ? `tenant:${sel.tenant}` : undefined

  const { treeData, parentOf } = useMemo(() => buildTree(tree, search, setDialog, setParams), [tree, search, setParams])
  const [expanded, setExpanded] = useState<string[]>([])
  const [expandedFor, setExpandedFor] = useState<string>()
  const expandToken = `${selectedKey}|${tree.length}|${refresh}|${search}`
  if (tree.length > 0 && expandToken !== expandedFor) {
    const path: string[] = tree.map((t) => `tenant:${t.id}`)
    for (let k = selectedKey ? parentOf.get(selectedKey) : undefined; k; k = parentOf.get(k)) path.push(k)
    // Aramada eşleşenlerin tüm üstleri açılır
    if (search.trim()) for (const k of parentOf.keys()) if (k.startsWith('res:')) for (let p = parentOf.get(k); p; p = parentOf.get(p)) path.push(p)
    setExpandedFor(expandToken)
    setExpanded((prev) => [...new Set([...prev, ...path])])
  }
  const tenant = tree.find((t) => String(t.id) === sel.tenant)

  return (
    <>
      <PageHeader title="Resources"
        subtitle="Yetki tanımları: uygulama (resource server) → resource (tipli) → scope'lar ve URI eşlemeleri. Gruplama otomatik: HTTP'de URL kırılımları, ekranlarda üst-alt ilişkisi."
        extra={<Flex gap={8}>
          <Segmented value={view} onChange={(v) => setParams(v === 'list' ? { view: 'list' } : {})}
            options={[{ value: 'tree', label: 'Ağaç', icon: <ApartmentOutlined /> }, { value: 'list', label: 'Liste', icon: <UnorderedListOutlined /> }]} />
          <Link to="/inventory"><Button icon={<SearchOutlined />}>Envanter & kapsama</Button></Link>
          <Button icon={<PlusOutlined />} onClick={() => setDialog({ kind: 'app' })}>Uygulama</Button>
        </Flex>} />
      <PageGuide>
        <p><b>Resource</b> korunan varlıktır; kodu kalıcı kimliğidir (ör. <Code>anka.vadelihesap</Code>). <b>Scope</b> üzerinde yapılan işlemdir (view, create, close...). <b>resource:scope</b> bir yetkidir; rol/grup/kişiye <Link to="/permissions">Permission</Link>'lar ve <Link to="/policies">Policy</Link>'ler üzerinden verilir.</p>
        <p>Ayrı bir katalog ya da seviye tanımı yoktur. HTTP resource'ları URI desenlerinin ortak önekine göre (<Code>/v1/vadeli-hesap</Code>), menü / ekran / butonlar üst-alt ilişkisine göre kendiliğinden gruplanır. Gruplama sadece görünümdür; yetkiye etkisi yoktur.</p>
        <p>Uygulamada gerçekte ne olduğu (Swagger, ekran listesi) <Link to="/inventory">Envanter & kapsama</Link> sayfasındadır: tanımsız, atıl ve korunmayan öğeler oradan görülür ve tek tıkla tanımlanır.</p>
      </PageGuide>
      {view === 'list' ? <AccessList /> : (
      <Row gutter={16}>
        <Col xs={24} xl={9}>
          <Card size="small" styles={{ body: { maxHeight: 'calc(100vh - 230px)', overflow: 'auto' } }}>
            <Input.Search placeholder="Resource kodu, adı, uygulama kodu veya URL ara" allowClear onChange={(e) => setSearch(e.target.value)} style={{ marginBottom: 8 }} />
            <Tree showLine blockNode expandedKeys={expanded} onExpand={(keys) => setExpanded(keys.map(String))}
              selectedKeys={selectedKey ? [selectedKey] : []} treeData={treeData as never}
              onSelect={(keys, info) => {
                const k = String(keys[0] ?? info.node.key)
                const [t, id] = k.split(':')
                if (t === 'tenant') setParams({ tenant: id })
                else if (t === 'app') setParams({ app: id })
                else if (t === 'res') setParams({ resource: id })
                else setExpanded((prev) => prev.includes(k) ? prev.filter((x) => x !== k) : [...prev, k])   // klasör: aç / kapat
              }} />
          </Card>
        </Col>
        <Col xs={24} xl={15}>
          {sel.resource ? <ResourcePanel key={sel.resource} id={Number(sel.resource)} onChanged={refreshTree} setDialog={setDialog}
              onNavigate={(k, id) => setParams({ [k]: String(id) })} onDeleted={() => { refreshTree(); setParams({}) }} />
            : sel.app ? <ApplicationPanel key={sel.app} id={Number(sel.app)} setDialog={setDialog} onChanged={refreshTree}
              onDeleted={() => { refreshTree(); setParams({}) }} />
            : tenant ? <Card title={<><GlobalOutlined /> {tenant.code} — {tenant.name}</>}
                extra={<Button type="primary" size="small" icon={<PlusOutlined />} onClick={() => setDialog({ kind: 'app', tenantId: tenant.id })}>Uygulama ekle</Button>}>
                <Typography.Paragraph type="secondary">Bu tenant'ın sahip olduğu uygulamalar (resource server). Uygulama bu tenant ve alt tenant'larında kullanılabilir.</Typography.Paragraph>
                {tenant.applications.length ? tenant.applications.map((a) => (
                  <Card key={a.id} size="small" hoverable style={{ marginBottom: 8 }} onClick={() => setParams({ app: String(a.id) })}>
                    <b>{a.code}</b> — {a.name} · {a.resourceCount} resource · {a.scopeCount} scope · {a.permissionCount} permission
                  </Card>)) : <Empty description="Bu tenant'a ait uygulama yok" />}
              </Card>
            : <Card className="evaluation-empty">
                <span className="evaluation-empty-icon"><AppstoreOutlined /></span>
                <Typography.Title level={4}>Yetki tanımlarını keşfedin</Typography.Title>
                <Typography.Paragraph type="secondary">Bir uygulama veya resource seçin. Scope'lar, URI eşlemeleri, onları koruyan permission'lar ve sahipleri burada görünür.</Typography.Paragraph>
                <div className="evaluation-steps"><span>Uygulama</span><span>Resource</span><span>Scope → Permission</span></div>
              </Card>}
        </Col>
      </Row>)}
      {dialog?.kind === 'app' && <AppModal tenantId={dialog.tenantId} application={dialog.application} onClose={() => setDialog(undefined)} onDone={refreshTree} />}
      {dialog?.kind === 'resource' && <ResourceModal applicationId={dialog.applicationId} parentId={dialog.parentId} detail={dialog.resource}
        onClose={() => setDialog(undefined)} onDone={(id) => { refreshTree(); if (id) setParams({ resource: String(id) }) }} />}
    </>
  )
}

type SetParams = ReturnType<typeof useSearchParams>[1]

/** URL öneki trie düğümü (HTTP resource'larını gruplar). */
interface UrlFolder { segment: string; path: string; folders: Map<string, UrlFolder>; resources: CatalogTreeResource[] }

/**
 * Ağaç: tenant → uygulama → (HTTP) URL klasörleri → resource · (UI) üst-alt zinciri.
 * Tek alt klasörü olan ve kendi resource'u olmayan klasörler birleştirilir (/v1 › /kredi → /v1/kredi).
 */
function buildTree(tree: CatalogTreeTenant[], search: string, setDialog: (d: Dialog) => void, setParams: SetParams) {
  const q = search.trim().toLowerCase()
  const parentOf = new Map<string, string>()
  const stop = (run: () => void) => ({ domEvent }: { domEvent: React.MouseEvent | React.KeyboardEvent }) => { domEvent.stopPropagation(); run() }
  const menu = (content: ReactNode, items: { key: string; label: string; icon?: ReactNode; onClick: (info: { domEvent: React.MouseEvent | React.KeyboardEvent }) => void }[]) => (
    <Dropdown trigger={['contextMenu']} menu={{ items }}><span style={{ display: 'inline-block', width: '100%' }}>{content}</span></Dropdown>
  )
  const resMatch = (r: CatalogTreeResource) => !q || r.code.toLowerCase().includes(q) || r.name.toLowerCase().includes(q)
    || (r.externalCode ?? '').toLowerCase().includes(q) || r.uris.some((u) => u.pattern.toLowerCase().includes(q))

  const resourceTitle = (r: CatalogTreeResource, app: CatalogTreeApp) => menu(<span style={{ opacity: r.isActive ? 1 : 0.55 }}>
    <ResourceTypeTag type={r.type} color={r.color} name={r.typeName} /><b>{r.code}</b> <Typography.Text type="secondary" style={{ fontSize: 12 }}>
      {r.name}{r.externalCode ? ` · ${r.externalCode}` : ''} · {r.scopes.join(', ') || 'scope yok'}</Typography.Text>
    {r.scopes.length > r.protectedScopes && <Tooltip title="Permission'ı olmayan scope var: bu işlemlere kimse erişemez (varsayılan kapalı)."><Tag color="orange" style={{ marginLeft: 4 }}>korumasız scope</Tag></Tooltip>}
    {r.matchesHttp && r.uris.length === 0 && <Tooltip title="URI eşlemesi yok: gateway'den gelen hiçbir istek bu resource'a eşlenmez."><Tag color="red" style={{ marginLeft: 4 }}>URI yok</Tag></Tooltip>}
  </span>, [
    { key: 'open', label: 'Aç', onClick: stop(() => setParams({ resource: String(r.id) })) },
    ...(!r.matchesHttp ? [{ key: 'child', label: 'Alt resource ekle', icon: <PlusOutlined />, onClick: stop(() => setDialog({ kind: 'resource', applicationId: app.id, parentId: r.id })) }] : []),
  ])

  // UI: üst-alt zinciri
  const uiNodes = (list: CatalogTreeResource[], parentKey: string, app: CatalogTreeApp): object[] => {
    const ids = new Set(list.map((r) => r.id))
    const hasMatch = (r: CatalogTreeResource): boolean => resMatch(r) || list.some((c) => c.parentId === r.id && hasMatch(c))
    const conv = (r: CatalogTreeResource, parent: string): object => {
      const key = `res:${r.id}`
      parentOf.set(key, parent)
      return { key, title: resourceTitle(r, app), children: list.filter((c) => c.parentId === r.id && hasMatch(c)).map((c) => conv(c, key)) }
    }
    return list.filter((r) => !r.parentId || !ids.has(r.parentId)).filter(hasMatch).map((r) => conv(r, parentKey))
  }

  // HTTP: URL öneki klasörleri
  const httpNodes = (list: CatalogTreeResource[], parentKey: string, app: CatalogTreeApp): object[] => {
    const root: UrlFolder = { segment: '', path: '', folders: new Map(), resources: [] }
    const noUri: CatalogTreeResource[] = []
    for (const r of list.filter(resMatch)) {
      if (!r.group) { noUri.push(r); continue }
      let cur = root
      for (const seg of r.group.split('/').filter(Boolean)) {
        const path = `${cur.path}/${seg}`
        if (!cur.folders.has(seg)) cur.folders.set(seg, { segment: seg, path, folders: new Map(), resources: [] })
        cur = cur.folders.get(seg)!
      }
      cur.resources.push(r)
    }
    const conv = (f: UrlFolder, parent: string, label: string): object => {
      // tek alt klasörlü ve resource'suz klasörleri birleştir
      while (f.resources.length === 0 && f.folders.size === 1) { const only = [...f.folders.values()][0]; label = `${label}/${only.segment}`; f = only }
      const key = `url:${app.id}:${f.path}`
      parentOf.set(key, parent)
      return {
        key, selectable: true,
        title: <span><FolderOutlined /> <Typography.Text code>{label}</Typography.Text></span>,
        children: [
          ...[...f.folders.values()].sort((a, b) => a.segment.localeCompare(b.segment)).map((c) => conv(c, key, `/${c.segment}`)),
          ...f.resources.map((r) => { parentOf.set(`res:${r.id}`, key); return { key: `res:${r.id}`, title: resourceTitle(r, app), isLeaf: true } }),
        ],
      }
    }
    const nodes = [...root.folders.values()].sort((a, b) => a.segment.localeCompare(b.segment)).map((f) => conv(f, parentKey, `/${f.segment}`))
    if (noUri.length) {
      const key = `nouri:${app.id}`
      parentOf.set(key, parentKey)
      nodes.push({ key, title: <span><FolderOutlined /> <Typography.Text type="secondary">URI'siz ({noUri.length})</Typography.Text></span>,
        children: noUri.map((r) => { parentOf.set(`res:${r.id}`, key); return { key: `res:${r.id}`, title: resourceTitle(r, app), isLeaf: true } }) })
    }
    return nodes
  }

  const treeData = tree.map((t) => ({
    key: `tenant:${t.id}`,
    title: <span><GlobalOutlined /> <b>{t.code}</b> — {t.name}</span>,
    children: t.applications.filter((a) => !q || a.code.toLowerCase().includes(q) || a.name.toLowerCase().includes(q) || a.resources.some(resMatch)).map((a) => {
      const key = `app:${a.id}`
      parentOf.set(key, `tenant:${t.id}`)
      const appMatch = !!q && (a.code.toLowerCase().includes(q) || a.name.toLowerCase().includes(q))
      const scoped = appMatch ? { ...a, resources: a.resources } : a
      const http = scoped.resources.filter((r) => r.matchesHttp)
      const ui = scoped.resources.filter((r) => !r.matchesHttp)
      return {
        key,
        title: menu(<b style={{ opacity: a.isActive ? 1 : 0.55 }}><AppstoreOutlined /> {a.code} — {a.name} <Typography.Text type="secondary" style={{ fontSize: 12, fontWeight: 400 }}>({a.resourceCount} resource · {a.permissionCount} permission)</Typography.Text></b>, [
          { key: 'open', label: 'Aç', onClick: stop(() => setParams({ app: String(a.id) })) },
          { key: 'res', label: 'Resource ekle', icon: <KeyOutlined />, onClick: stop(() => setDialog({ kind: 'resource', applicationId: a.id })) },
        ]),
        children: [...httpNodes(http, key, a), ...uiNodes(ui, key, a)],
      }
    }),
  }))
  return { treeData, parentOf }
}

// ------------------------------ Uygulama paneli ------------------------------

function ApplicationPanel({ id, setDialog, onChanged, onDeleted }: { id: number; setDialog: (d: Dialog) => void; onChanged: () => void; onDeleted: () => void }) {
  const { data, reload } = useApi<AppDetail>(`/api/catalog/applications/${id}`)
  const users = useOptions('users')
  const [scopeModal, setScopeModal] = useState<AppDetail['scopes'][number] | 'new'>()
  const { message } = App.useApp()
  if (!data) return <Card loading />
  const a = data.application
  const remove = async () => { try { await api.del(`/api/catalog/applications/${id}`); message.success('Silindi'); onDeleted() } catch (e) { message.error((e as Error).message) } }
  const removeScope = async (sid: number) => { try { await api.del(`/api/scopes/${sid}`); message.success('Scope silindi'); reload(); onChanged() } catch (e) { message.error((e as Error).message) } }
  return (
    <Card size="small"
      title={<Flex vertical gap={2}><span><AppstoreOutlined /> <b>{a.code}</b> — {a.name}</span><Typography.Text type="secondary" style={{ fontSize: 12 }}>Resource server (Keycloak: authorization açık client)</Typography.Text></Flex>}
      extra={<Flex gap={6} wrap>
        <Button size="small" icon={<EditOutlined />} onClick={() => setDialog({ kind: 'app', application: a })}>Düzenle</Button>
        <Button size="small" type="primary" icon={<KeyOutlined />} onClick={() => setDialog({ kind: 'resource', applicationId: a.id })}>Resource</Button>
        <Popconfirm title={`${a.code} silinsin mi?`} description="Resource, scope, permission veya client varsa silinemez." onConfirm={remove}>
          <Button size="small" danger icon={<DeleteOutlined />} />
        </Popconfirm>
      </Flex>}>
      <Descriptions size="small" column={{ xs: 1, md: 2 }} style={{ marginBottom: 12 }}>
        <Descriptions.Item label="Tenant"><TenantTag tenant={a.tenant} /></Descriptions.Item>
        <Descriptions.Item label="Tip"><Tag>{a.type}</Tag> <ActiveTag active={a.isActive} /></Descriptions.Item>
        <Descriptions.Item label="Permission birleştirme" span={2}><StrategyTag strategy={a.decisionStrategy} />
          <Typography.Text type="secondary" style={{ fontSize: 12 }}> Aynı yetkiye birden fazla permission uygulanırsa: {strategyHelp[a.decisionStrategy]}</Typography.Text></Descriptions.Item>
        <Descriptions.Item label="Sahip ekip">{a.ownerTeam ?? '—'}</Descriptions.Item>
        <Descriptions.Item label="Sorumlu">{users.find((u) => u.value === a.ownerUserId)?.label ?? '—'}</Descriptions.Item>
      </Descriptions>
      {a.description && <Typography.Paragraph type="secondary">{a.description}</Typography.Paragraph>}
      <Card size="small" type="inner" title="Scope'lar (uygulamanın işlem sözlüğü)" extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setScopeModal('new')}>Scope</Button>}>
        <Table size="small" rowKey="id" pagination={false} dataSource={data.scopes}
          columns={[
            { title: 'Kod', dataIndex: 'code', render: (v) => <Code>{v}</Code> },
            { title: 'Ad', dataIndex: 'name' },
            { title: 'Kullanan resource', dataIndex: 'resourceCount', width: 130 },
            {
              width: 90, render: (_, s) => <Flex gap={2}>
                <Button size="small" type="text" icon={<EditOutlined />} onClick={() => setScopeModal(s)} />
                <Popconfirm title={`${s.code} silinsin mi?`} onConfirm={() => removeScope(s.id)} disabled={s.resourceCount > 0}>
                  <Button size="small" type="text" danger icon={<DeleteOutlined />} disabled={s.resourceCount > 0} />
                </Popconfirm>
              </Flex>,
            },
          ]} />
      </Card>
      <Card size="small" type="inner" style={{ marginTop: 12 }} title={`Permission'lar (${data.permissions.length})`} extra={<Link to={`/permissions/new?app=${a.id}`}><Button size="small" icon={<PlusOutlined />}>Permission</Button></Link>}>
        <Flex wrap gap={4}>{data.permissions.map((p) => <Link key={p.id} to={`/permissions/${p.id}`}><Tag color={p.isActive ? 'green' : 'default'}>{p.code} · {p.coverage} yetki</Tag></Link>)}
          {data.permissions.length === 0 && <Typography.Text type="secondary">Henüz yok — resource'lar varsayılan olarak kapalıdır.</Typography.Text>}</Flex>
      </Card>
      {data.clients.length > 0 && <Typography.Paragraph type="secondary" style={{ marginTop: 12, marginBottom: 0 }}>Bu uygulamanın client'ları: {data.clients.map((c) => <Tag key={c.id}>{c.clientId}</Tag>)}</Typography.Paragraph>}
      {scopeModal && <ScopeModal applicationId={a.id} scope={scopeModal === 'new' ? undefined : scopeModal} onClose={() => setScopeModal(undefined)} onDone={() => { reload(); onChanged() }} />}
    </Card>
  )
}

// ------------------------------ Resource paneli ------------------------------

function ResourcePanel({ id, setDialog, onNavigate, onChanged, onDeleted }: {
  id: number; setDialog: (d: Dialog) => void; onNavigate: (k: 'resource' | 'app', id: number) => void; onChanged: () => void; onDeleted: () => void
}) {
  const { data, reload } = useApi<ResourceDetail>(`/api/resources/${id}`)
  const deps = useApi<ExternalDependencyView[]>(`/api/external/dependencies?forResource=${id}`)
  const [uriModal, setUriModal] = useState<ResourceDetail['uris'][number] | 'new'>()
  const [holders, setHolders] = useState<{ id: number; key: string }>()
  const [depOwner, setDepOwner] = useState<DependencyOwner>()
  const [test, setTest] = useState<{ method: string; path: string }>({ method: 'GET', path: '' })
  const [testResult, setTestResult] = useState<string>()
  const { message } = App.useApp()
  if (!data) return <Card loading />
  const r = data.resource
  const reloadAll = () => { reload(); deps.reload(); onChanged() }
  const remove = async () => { try { await api.del(`/api/resources/${id}`); message.success('Silindi'); onDeleted() } catch (e) { message.error((e as Error).message) } }
  const removeUri = async (uid: number) => { try { await api.del(`/api/resource-uris/${uid}`); message.success('URI kaldırıldı — bu URI\'ye gelen istekler artık reddedilir'); reloadAll() } catch (e) { message.error((e as Error).message) } }
  const setRisk = async (scopeId: number, risk: Severity) => {
    try {
      await api.put(`/api/resources/${id}`, {
        applicationId: r.applicationId, externalCode: r.externalCode, resourceTypeId: r.resourceTypeId, parentId: r.parentId, code: r.code, name: r.name,
        description: r.description, ownerTeamId: r.ownerTeamId, order: r.order, isActive: r.isActive,
        scopes: data.scopes.map((s) => ({ scopeId: s.scopeId, riskLevel: s.scopeId === scopeId ? risk : s.riskLevel })),
      })
      reload()
    } catch (e) { message.error((e as Error).message) }
  }
  const runTest = async () => {
    try {
      const m = await api.get<{ matched?: { key: string; uri: string }; ambiguous: { key: string; uri: string }[] }>(`/api/uri-match?method=${test.method}&path=${encodeURIComponent(test.path)}&application=${r.application}`)
      setTestResult(m.matched ? `→ ${m.matched.key} (desen: ${m.matched.uri})` : m.ambiguous.length ? `BELİRSİZ: ${m.ambiguous.map((x) => `${x.uri} → ${x.key}`).join(' | ')}` : 'Eşleşme yok → istek reddedilir (URI_NOT_REGISTERED)')
    } catch (e) { message.error((e as Error).message) }
  }
  const resourceDeps = (deps.data ?? []).filter((d) => d.resourceId === id)
  return (
    <Card size="small"
      title={<Flex vertical gap={4}>
        <Breadcrumb items={[{ title: <a onClick={() => onNavigate('app', r.applicationId)}>{r.application}</a> }, ...(r.parent ? [{ title: <a onClick={() => onNavigate('resource', r.parentId!)}>{r.parent}</a> }] : [])]} />
        <span><Tag color="gold">{r.type}</Tag><b>{r.code}</b> — {r.name} <ActiveTag active={r.isActive} /></span>
      </Flex>}
      extra={<Flex gap={6}>
        <Button size="small" icon={<EditOutlined />} onClick={() => setDialog({ kind: 'resource', applicationId: r.applicationId, resource: data })}>Düzenle</Button>
        {r.supportsHierarchy && <Button size="small" icon={<PlusOutlined />} onClick={() => setDialog({ kind: 'resource', applicationId: r.applicationId, parentId: r.id })}>Alt resource</Button>}
        <Link to={`/permissions/new?app=${r.applicationId}&resource=${r.id}`}><Button size="small" type="primary" icon={<KeyOutlined />}>Permission</Button></Link>
        <Popconfirm title={`${r.code} silinsin mi?`} description="Alt resource, permission, dış bağımlılık veya SoD üyeliği varsa silinemez." onConfirm={remove}>
          <Button size="small" danger icon={<DeleteOutlined />} />
        </Popconfirm>
      </Flex>}>
      {r.description && <Typography.Paragraph type="secondary">{r.description}</Typography.Paragraph>}
      <Descriptions size="small" column={{ xs: 1, md: 3 }} style={{ marginBottom: 12 }}>
        <Descriptions.Item label="Tip">{r.typeName}{r.matchesHttp ? ' · HTTP' : ''}{r.supportsHierarchy ? ' · hiyerarşik' : ''}</Descriptions.Item>
        <Descriptions.Item label="Konum (türetilmiş)"><Typography.Text code>{r.path}</Typography.Text></Descriptions.Item>
        {r.externalCode && <Descriptions.Item label="Uygulama kodu"><Typography.Text code>{r.externalCode}</Typography.Text></Descriptions.Item>}
        <Descriptions.Item label="Sahip ekip">{r.ownerTeam ?? '—'}</Descriptions.Item>
      </Descriptions>

      <Card size="small" type="inner" title="Scope'lar = yetkiler (resource:scope)">
        <Table size="small" rowKey="resourceScopeId" pagination={false} dataSource={data.scopes}
          columns={[
            { title: 'Yetki', render: (_, s) => <><AccessKey value={s.key} /><br /><Typography.Text type="secondary" style={{ fontSize: 12 }}>{s.name}</Typography.Text></> },
            { title: 'Risk', width: 120, render: (_, s) => <Select size="small" value={s.riskLevel} onChange={(v) => setRisk(s.scopeId, v)} options={severities.map((x) => ({ value: x, label: <SeverityTag severity={x} /> }))} style={{ width: 110 }} variant="borderless" /> },
            {
              title: 'Koruyan permission', render: (_, s) => s.permissions.length === 0
                ? <Tooltip title="Bu işleme hiçbir permission uygulanmıyor: kimse erişemez (varsayılan kapalı)."><Tag color="orange">permission yok → kapalı</Tag></Tooltip>
                : s.permissions.map((p) => <Link key={p.id} to={`/permissions/${p.id}`}><Tag color={p.identity ? 'green' : 'gold'}>{p.code}</Tag></Link>),
            },
            { title: 'Sahip', width: 80, render: (_, s) => <a onClick={() => setHolders({ id: s.resourceScopeId, key: s.key })}>{s.holderCount}</a> },
            {
              title: 'Dış sistem', render: (_, s) => <Flex vertical gap={2}>
                <ExternalDependencyList deps={(deps.data ?? []).filter((d) => d.resourceScopeId === s.resourceScopeId)} onChanged={reloadAll} />
                <AddDependencyButton label="bağımlılık" onClick={() => setDepOwner({ resourceScopeId: s.resourceScopeId, label: s.key })} />
              </Flex>,
            },
          ]} />
        <Flex align="center" gap={8} style={{ marginTop: 8 }} wrap>
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>Resource geneli (tüm scope'lar) dış bağımlılık:</Typography.Text>
          <ExternalDependencyList deps={resourceDeps} onChanged={reloadAll} />
          <AddDependencyButton label="tüm scope'lar" onClick={() => setDepOwner({ resourceId: id, label: `${r.code} (tüm scope'lar)` })} />
        </Flex>
      </Card>

      {r.matchesHttp && (
        <Card size="small" type="inner" style={{ marginTop: 12 }} title="URI eşlemeleri (METHOD + desen → scope)" extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setUriModal('new')} disabled={data.scopes.length === 0}>URI</Button>}>
          {data.uris.length === 0 ? <Alert type="warning" showIcon message="URI yok: gateway'den gelen hiçbir istek bu resource'a eşlenmez (istekler URI_NOT_REGISTERED ile reddedilir)." />
            : <Table size="small" rowKey="id" pagination={false} dataSource={data.uris}
              columns={[
                { title: 'Method', dataIndex: 'method', width: 90, render: (v) => <MethodTag method={v} /> },
                { title: 'Desen', dataIndex: 'pattern', render: (v) => <Code>{v}</Code> },
                { title: 'Scope', dataIndex: 'scope', render: (v) => <Tag>{v}</Tag> },
                {
                  width: 90, render: (_, u) => <Flex gap={2}>
                    <Button size="small" type="text" icon={<EditOutlined />} onClick={() => setUriModal(u)} />
                    <Popconfirm title="URI eşlemesi kaldırılsın mı?" description="Bu METHOD + desenle gelen istekler reddedilir." onConfirm={() => removeUri(u.id)}>
                      <Button size="small" type="text" danger icon={<DeleteOutlined />} />
                    </Popconfirm>
                  </Flex>,
                },
              ]} />}
          <Flex gap={6} style={{ marginTop: 8 }} align="center" wrap>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>Eşleşme testi:</Typography.Text>
            <Select size="small" value={test.method} onChange={(v) => setTest({ ...test, method: v })} options={methods.filter((m) => m !== '*').map((m) => ({ value: m, label: m }))} style={{ width: 90 }} />
            <Input size="small" placeholder="/v1/vadeli-hesap/TR12/kapat" value={test.path} onChange={(e) => setTest({ ...test, path: e.target.value })} style={{ width: 300 }} onPressEnter={runTest} />
            <Button size="small" icon={<SearchOutlined />} onClick={runTest} disabled={!test.path}>Test</Button>
            {testResult && <Typography.Text style={{ fontSize: 12 }}>{testResult}</Typography.Text>}
          </Flex>
          <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8, marginBottom: 0 }}>
            <Code>{'{ad}'}</Code> veya <Code>*</Code> tek segment, sonda <Code>**</Code> kalan tüm segmentler. En özel desen kazanır. Desen değişirse yetkiler (resource:scope) ve bağlı permission'lar değişmez.
          </Typography.Paragraph>
        </Card>
      )}

      {data.children.length > 0 && (
        <Card size="small" type="inner" style={{ marginTop: 12 }} title="Alt resource'lar (üst kapalıysa alt da kapalı görünür)">
          <Flex wrap gap={6}>{data.children.map((c) => <Tag key={c.id} style={{ cursor: 'pointer' }} onClick={() => onNavigate('resource', c.id)}>{c.type} · {c.code}</Tag>)}</Flex>
        </Card>
      )}

      {uriModal && <UriModal resourceId={id} scopes={data.scopes} uri={uriModal === 'new' ? undefined : uriModal} onClose={() => setUriModal(undefined)} onDone={reloadAll} />}
      {holders && <HoldersDrawer id={holders.id} title={holders.key} onClose={() => setHolders(undefined)} />}
      {depOwner && <ExternalDependencyModal owner={depOwner} onClose={() => setDepOwner(undefined)} onDone={reloadAll} />}
    </Card>
  )
}

/** "Kimde var, neden?" — yetkinin etkin sahipleri ve permission → policy yolları. */
export function HoldersDrawer({ id, title, onClose }: { id: number; title: string; onClose: () => void }) {
  const { data, loading } = useApi<{ userId: number; userName: string; fullName: string; tenant: string; units: string[]; conditional: boolean; conditions: string[]; sources: { permission: string; policy: string; policyType: string; path: string }[] }[]>(`/api/resource-scopes/${id}/holders`)
  const navigate = useNavigate()
  return (
    <Drawer open width={760} title={<>Sahipler · <AccessKey value={title} /></>} onClose={onClose}>
      <Table size="small" rowKey="userId" loading={loading} dataSource={data ?? []} pagination={{ pageSize: 15 }} rowClassName="clickable-row" onRow={(u) => ({ onClick: () => navigate(`/users/${u.userId}`) })}
        columns={[
          { title: 'Kullanıcı', render: (_, u) => <><b>{u.userName}</b> {u.conditional && <Tag color="gold">koşullu</Tag>}<br /><Typography.Text type="secondary" style={{ fontSize: 12 }}>{u.fullName} · {u.tenant} · {u.units.join(',')}</Typography.Text></> },
          { title: 'Neden', render: (_, u) => <Flex vertical gap={2}>{u.sources.map((s, i) => <Typography.Text key={i} style={{ fontSize: 12 }}>{s.path}</Typography.Text>)}
            {u.conditional && <Typography.Text type="secondary" style={{ fontSize: 11 }}>koşul: {u.conditions.join(' · ')}</Typography.Text>}</Flex> },
        ]} />
    </Drawer>
  )
}

// ------------------------------ Modallar ------------------------------

function AppModal({ tenantId, application, onClose, onDone }: { tenantId?: number; application?: AppDetail['application']; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const tenants = useOptions('tenants')
  const teams = useOptions('teams')
  const users = useOptions('users')
  const { message } = App.useApp()
  const save = async () => {
    const v = await form.validateFields()
    try {
      if (application) {
        const r = await api.put<ChangeImpactResult>(`/api/catalog/applications/${application.id}`, v)
        message.success(r?.affectedUserCount ? `Güncellendi · ${r.summary}` : 'Güncellendi')
      } else await api.post('/api/catalog/applications', v)
      onDone(); onClose()
    } catch (e) { message.error((e as Error).message) }
  }
  return (
    <Modal open title={application ? `${application.code} düzenle` : 'Yeni uygulama (resource server)'} onCancel={onClose} onOk={save} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={application ?? { tenantId, type: 'ApiPlatform', decisionStrategy: 'Unanimous', isActive: true }}>
        <Form.Item name="tenantId" label="Sahip tenant" rules={[{ required: true }]}><Select disabled={!!application} options={toSelectOptions(tenants)} /></Form.Item>
        <Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input disabled={!!application} placeholder="ANKA" /></Form.Item>
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Form.Item name="type" label="Tip"><Select options={['ApiPlatform', 'Desktop', 'Mobile', 'Web', 'Batch'].map((t) => ({ value: t, label: t }))} /></Form.Item>
        <Form.Item name="decisionStrategy" label="Permission birleştirme stratejisi" extra="Aynı yetkiye birden fazla permission uygulanırsa sonuçlar nasıl birleşir? (Keycloak varsayılanı Unanimous)">
          <Select options={strategies.map((s) => ({ value: s, label: `${strategyLabel[s]} — ${strategyHelp[s]}` }))} />
        </Form.Item>
        <Form.Item name="ownerTeamId" label="Sahip ekip"><Select allowClear showSearch optionFilterProp="label" options={toSelectOptions(teams)} /></Form.Item>
        <Form.Item name="ownerUserId" label="Sorumlu kullanıcı"><Select allowClear showSearch optionFilterProp="label" options={toSelectOptions(users)} /></Form.Item>
        <Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item>
        <Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item>
      </Form>
    </Modal>
  )
}

// ================================ Resource Types ================================

export function ResourceTypesPage() {
  const { data, loading, reload } = useApi<ResourceTypeView[]>('/api/resource-types')
  const [editing, setEditing] = useState<ResourceTypeView | 'new'>()
  const { message } = App.useApp()
  const remove = async (t: ResourceTypeView) => { try { await api.del(`/api/resource-types/${t.id}`); message.success('Silindi'); reload(); invalidateOptions('resource-types') } catch (e) { message.error((e as Error).message) } }
  return (
    <>
      <PageHeader title="Resource Types" subtitle="Yetki yönetiminin tanımladığı resource sınıfları: endpoint, menü, ekran, buton... Tip, resource'un nasıl eşlendiğini ve görüntülendiğini belirler."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setEditing('new')}>Yeni tip</Button>} />
      <Alert type="info" showIcon style={{ marginBottom: 12 }}
        message="HTTP ile eşleşen tipler (ör. ENDPOINT) METHOD + URI desenleri ile gateway isteklerine bağlanır; tanımsız URI'ye erişim kapalıdır. Diğer tipler (menü, ekran, buton) login'de entitlement ile açılır/kapanır; hiyerarşik tiplerde üst kapalıysa alt da kapalıdır."
        description="Permission'lar bir tipin TÜM resource'larına da uygulanabilir (ör. 'tüm MENU resource'larında view')." />
      <Table<ResourceTypeView> rowKey="id" loading={loading} dataSource={data ?? []} pagination={false}
        columns={[
          { title: 'Kod', render: (_, t) => <ResourceTypeTag type={t.code} color={t.color} /> },
          { title: 'Ad', render: (_, t) => <><b>{t.name}</b><br /><Typography.Text type="secondary" style={{ fontSize: 12 }}>{t.description}</Typography.Text></> },
          { title: 'HTTP eşleşmesi', dataIndex: 'matchesHttp', width: 130, render: (v) => (v ? <Tag color="blue">METHOD + URI</Tag> : <Tag>yok</Tag>) },
          { title: 'Hiyerarşi', dataIndex: 'supportsHierarchy', width: 110, render: (v) => (v ? <Tag color="purple">üst → alt</Tag> : '—') },
          { title: 'Resource', dataIndex: 'resourceCount', width: 90 },
          { title: 'Permission', dataIndex: 'permissionCount', width: 100 },
          { title: '', width: 150, render: (_, t) => <Flex gap={4} align="center"><ActiveTag active={t.isActive} />
            <Button size="small" type="text" icon={<EditOutlined />} onClick={() => setEditing(t)} />
            <Popconfirm title={`${t.code} silinsin mi?`} onConfirm={() => remove(t)} disabled={t.resourceCount + t.permissionCount > 0}>
              <Tooltip title={t.resourceCount + t.permissionCount > 0 ? 'Kullanımda' : 'Sil'}><Button size="small" type="text" danger icon={<DeleteOutlined />} disabled={t.resourceCount + t.permissionCount > 0} /></Tooltip>
            </Popconfirm></Flex> },
        ]} />
      {editing && <ResourceTypeModal type={editing === 'new' ? undefined : editing} onClose={() => setEditing(undefined)} onDone={() => { reload(); invalidateOptions('resource-types') }} />}
    </>
  )
}

const typeColors = ['blue', 'geekblue', 'purple', 'magenta', 'gold', 'orange', 'green', 'cyan', 'volcano', 'lime']

function ResourceTypeModal({ type, onClose, onDone }: { type?: ResourceTypeView; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const save = async () => {
    const v = await form.validateFields()
    try {
      if (type) await api.put(`/api/resource-types/${type.id}`, v)
      else await api.post('/api/resource-types', v)
      onDone(); onClose()
    } catch (e) { message.error((e as Error).message) }
  }
  return (
    <Modal open title={type ? `Tip: ${type.code}` : 'Yeni resource tipi'} onCancel={onClose} onOk={save} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={type ?? { matchesHttp: false, supportsHierarchy: false, isActive: true, color: 'blue' }}>
        <Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input disabled={!!type} placeholder="TAB" /></Form.Item>
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input placeholder="Sekme" /></Form.Item>
        <Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item>
        <Form.Item name="matchesHttp" valuePropName="checked"><Checkbox>HTTP isteğiyle eşleşir (METHOD + URI deseni tanımlanır)</Checkbox></Form.Item>
        <Form.Item name="supportsHierarchy" valuePropName="checked"><Checkbox>Hiyerarşik (üst → alt; üst kapalıysa alt da kapalı)</Checkbox></Form.Item>
        <Form.Item name="color" label="Renk"><Select options={typeColors.map((c) => ({ value: c, label: <Tag color={c}>{c}</Tag> }))} /></Form.Item>
        <Form.Item name="isActive" label="Aktif" valuePropName="checked" extra="Pasif tipteki resource'lara erişim kapanır."><Switch /></Form.Item>
      </Form>
    </Modal>
  )
}

// ================================ Liste görünümü (tüm resource:scope) ================================

/** Tüm yetkiler (resource:scope) tek tabloda: URI'ler, koruyan permission'lar, sahipler. Resources sayfasının "Liste" görünümü. */
export function AccessList() {
  const [q, setQ] = useState('')
  const [appId, setAppId] = useState<number>()
  const [type, setType] = useState<string>()
  const apps = useOptions('applications')
  const types = useOptions('resource-types')
  const params = new URLSearchParams()
  if (q) params.set('q', q)
  if (appId) params.set('applicationId', String(appId))
  if (type) params.set('type', type)
  const { data, loading } = useApi<ResourceScopeView[]>(`/api/resource-scopes?${params.toString()}`)
  const [holders, setHolders] = useState<{ id: number; key: string }>()
  const navigate = useNavigate()
  return (
    <>
      <Flex gap={8} wrap style={{ marginBottom: 12 }}>
        <Input.Search placeholder="anka.vadelihesap:close" allowClear onSearch={setQ} style={{ width: 280 }} />
        <Select allowClear placeholder="Uygulama" value={appId} onChange={setAppId} options={toSelectOptions(apps)} style={{ width: 240 }} />
        <Select allowClear placeholder="Resource tipi" value={type} onChange={setType} options={types.map((t) => ({ value: t.code, label: t.label }))} style={{ width: 220 }} />
      </Flex>
      <Table<ResourceScopeView> rowKey="id" size="small" loading={loading} dataSource={data ?? []} pagination={{ pageSize: 25 }}
        columns={[
          { title: 'Yetki', render: (_, x) => <><AccessKey value={x.key} /><br /><Typography.Text type="secondary" style={{ fontSize: 12 }}>{x.name}</Typography.Text></>, sorter: (a, b) => a.key.localeCompare(b.key) },
          { title: 'Tip', render: (_, x) => <ResourceTypeTag type={x.resourceType} color={x.color} />, width: 100 },
          { title: 'Uygulama / konum', render: (_, x) => <><Tag>{x.application}</Tag><Typography.Text type="secondary" style={{ fontSize: 12 }}>{x.path}</Typography.Text></> },
          { title: 'URI', dataIndex: 'uris', render: (v: string[]) => v.map((u) => <div key={u}><Code>{u}</Code></div>) },
          { title: 'Permission', dataIndex: 'permissions', render: (v: string[]) => v.length ? v.map((p) => <Tag key={p} color="green">{p}</Tag>) : <Tag color="orange">yok → kapalı</Tag> },
          { title: 'Risk', dataIndex: 'riskLevel', render: (v) => <SeverityTag severity={v} />, width: 90 },
          { title: 'Sahip', dataIndex: 'holderCount', width: 70, render: (v, x) => <a onClick={() => setHolders({ id: x.id, key: x.key })}>{v}</a> },
          { width: 50, render: (_, x) => <Tooltip title="Resources'ta aç"><Button size="small" type="text" icon={<LinkOutlined />} onClick={() => navigate(`/catalog?resource=${x.resourceId}`)} /></Tooltip> },
        ]} />
      {holders && <HoldersDrawer id={holders.id} title={holders.key} onClose={() => setHolders(undefined)} />}
    </>
  )
}

// ================================ Client'lar ================================

interface ClientRow {
  id: number; clientId: string; name: string; type: string; isActive: boolean; description?: string; tenantId: number; tenant: string
  application?: string; applicationId?: number; serviceAccount?: string; serviceAccountUserId?: number; policies: string[]
  queryApplicationIds: number[]; queryApplications: string[]; queryTenantIds: number[]; queryTenants: string[]
  onBehalfOfClientIds: number[]; onBehalfOf: string[]; rateLimitPerMinute?: number; activeSecrets: number; secretLastUsedAt?: string
}

interface SecretView { id: number; prefix: string; description?: string; createdAt: string; createdBy: string; expiresAt?: string; revokedAt?: string; lastUsedAt?: string; isValid: boolean }

export function ClientsPage() {
  const { data, loading, reload } = useApi<ClientRow[]>('/api/clients')
  const [editing, setEditing] = useState<ClientRow | 'new' | null>(null)
  const [secretsFor, setSecretsFor] = useState<ClientRow>()
  const { message } = App.useApp()
  const remove = async (c: ClientRow) => { try { await api.del(`/api/clients/${c.id}`); message.success('Silindi'); reload(); invalidateOptions('clients') } catch (e) { message.error((e as Error).message) } }
  return (
    <>
      <PageHeader title="Clients" subtitle="Motoru tüketen uygulamalar. Her client motora kendi secret'ıyla gelir ve sadece kendi soru kapsamında soru sorabilir."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setEditing('new')}>Yeni client</Button>} />
      <PageGuide title="Client güvenliği nasıl çalışır?">
        <p><b>Kimlik:</b> Client motora kendi secret'ıyla token alarak gelir (<Code>POST /api/v1/token</Code>, client_id + client_secret → 10 dk'lık token), karar uçlarını <Code>Authorization: Bearer &lt;token&gt;</Code> ile çağırır. Soruyu soranın kim olduğu bu token'dan çıkar.</p>
        <p><b>Sorumluluk:</b> İstekteki kullanıcı, yetki ve bağlam bilgisinin doğruluğu client'ındır (kullanıcıyı kendi token'ıyla doğrulamış olmalı). Motor kendini <b>soru kapsamıyla</b> korur: client sadece izin verilen uygulamalar ve kurumlar hakkında soru sorabilir; başka client adına sadece yetkili <b>aracılar</b> (gateway) konuşabilir; dakikalık istek limiti vardır. Böylece hatalı veya ele geçirilmiş bir client yalnızca kendi kapsamını etkiler, diğer tüketiciler çalışmaya devam eder.</p>
        <p><b>Kanal kuralları:</b> 'Para çek' butonu sadece Nextral'den → Client policy KANAL_NEXTRAL permission'a eklenir. Masaüstü ekranları client değil, NEXTRAL'daki resource'lardır.</p>
        <p>Örnek veride her client'ın demo secret'ı vardır: <Code>ysk_demo_&lt;client_id&gt;</Code> (ör. ysk_demo_nextral-api). Yetki testi ekranları motor token'ı istemez; "Soran" alanıyla kapsam kuralları test edilebilir.</p>
      </PageGuide>
      <Table<ClientRow> rowKey="id" loading={loading} dataSource={data ?? []} pagination={false}
        columns={[
          { title: 'client_id', render: (_, c) => <><b>{c.clientId}</b><br /><Typography.Text type="secondary">{c.name}</Typography.Text></> },
          { title: 'Tenant', dataIndex: 'tenant', render: (v) => <TenantTag tenant={v} />, width: 110 },
          { title: 'Tip', render: (_, c) => <><Tag color={c.type === 'Service' ? 'purple' : c.type === 'Public' ? 'orange' : c.type === 'Intermediary' ? 'magenta' : 'blue'}>{c.type === 'Intermediary' ? 'Aracı (gateway/BFF)' : c.type}</Tag>{c.serviceAccount && <div style={{ fontSize: 12 }}>servis hesabı: {c.serviceAccount}</div>}</> },
          {
            title: 'Soru kapsamı', render: (_, c) => <Flex vertical gap={2}>
              <div>{c.queryApplications.length ? c.queryApplications.map((a) => <Tag key={a}>{a}</Tag>) : <Tag color="red">uygulama yok</Tag>}</div>
              <div>{c.queryTenants.length ? c.queryTenants.map((t) => <Tag key={t} color="blue">{t} +alt</Tag>) : <Tag color="red">kurum yok</Tag>}</div>
              {c.onBehalfOf.length > 0 && <Typography.Text style={{ fontSize: 12 }}>adına konuşur: {c.onBehalfOf.join(', ')}</Typography.Text>}
              {c.rateLimitPerMinute && <Typography.Text type="secondary" style={{ fontSize: 12 }}>limit: {c.rateLimitPerMinute}/dk</Typography.Text>}
            </Flex>,
          },
          { title: 'Kanal policy\'leri', dataIndex: 'policies', render: (v: string[]) => v.length ? v.map((p) => <Tag key={p} color="geekblue">{p}</Tag>) : <Typography.Text type="secondary">—</Typography.Text> },
          { title: 'Secret', width: 150, render: (_, c) => <><a onClick={() => setSecretsFor(c)}>{c.activeSecrets} geçerli</a>
              {c.secretLastUsedAt && <div><Typography.Text type="secondary" style={{ fontSize: 11 }}>son: {fmt(c.secretLastUsedAt)}</Typography.Text></div>}</> },
          { title: '', width: 170, render: (_, c) => <Flex gap={4} align="center"><ActiveTag active={c.isActive} />
            <Button size="small" type="text" icon={<EditOutlined />} onClick={() => setEditing(c)} />
            <Popconfirm title={`${c.clientId} silinsin mi?`} onConfirm={() => remove(c)} disabled={c.policies.length > 0}>
              <Button size="small" type="text" danger icon={<DeleteOutlined />} disabled={c.policies.length > 0} />
            </Popconfirm></Flex> },
        ]} />
      {editing && <ClientModal client={editing === 'new' ? undefined : editing} clients={data ?? []} onClose={() => setEditing(null)} onDone={() => { reload(); invalidateOptions('clients') }} />}
      {secretsFor && <SecretsDrawer client={secretsFor} onClose={() => { setSecretsFor(undefined); reload() }} />}
    </>
  )
}

function ClientModal({ client, clients, onClose, onDone }: { client?: ClientRow; clients: ClientRow[]; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const tenants = useOptions('tenants')
  const apps = useOptions('applications')
  const users = useOptions('users')
  const { message } = App.useApp()
  const type = Form.useWatch('type', form)
  const save = async () => {
    const v = await form.validateFields()
    try {
      const body = { ...v, onBehalfOfClientIds: v.type === 'Intermediary' ? v.onBehalfOfClientIds ?? [] : [] }
      if (client) await api.put(`/api/clients/${client.id}`, body)
      else await api.post('/api/clients', body)
      onDone(); onClose()
    } catch (e) { message.error((e as Error).message) }
  }
  return (
    <Modal open width={720} title={client ? client.clientId : 'Yeni client'} onCancel={onClose} onOk={save} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={client ?? { type: 'Confidential', isActive: true, queryApplicationIds: [], queryTenantIds: [], onBehalfOfClientIds: [] }}>
        <Row gutter={12}>
          <Col span={12}><Form.Item name="tenantId" label="Kayıtlı olduğu tenant" rules={[{ required: true }]} extra="Sonradan değiştirilemez.">
            <Select disabled={!!client} options={toSelectOptions(tenants)} />
          </Form.Item></Col>
          <Col span={12}><Form.Item name="clientId" label="client_id" rules={[{ required: true }]}><Input disabled={!!client} placeholder="internet-sube-api" /></Form.Item></Col>
          <Col span={12}><Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item></Col>
          <Col span={12}><Form.Item name="type" label="Tip" extra="Aracı: gateway / BFF — başka client'lar adına soru sorar.">
            <Select options={[{ value: 'Confidential', label: 'Confidential' }, { value: 'Public', label: 'Public' }, { value: 'Service', label: 'Service (client credentials)' }, { value: 'Intermediary', label: 'Aracı (gateway / BFF)' }]} />
          </Form.Item></Col>
          {type === 'Service' && <Col span={12}><Form.Item name="serviceAccountUserId" label="Servis hesabı" rules={[{ required: true }]}><Select showSearch optionFilterProp="label" options={toSelectOptions(users.filter((u) => u.code.startsWith('svc.')))} /></Form.Item></Col>}
          <Col span={12}><Form.Item name="applicationId" label="Ait olduğu uygulama"><Select allowClear options={toSelectOptions(apps)} /></Form.Item></Col>
        </Row>
        <Card size="small" type="inner" title="Soru kapsamı (motor kendini bununla korur)" style={{ marginBottom: 12 }}>
          <Form.Item name="queryApplicationIds" label="Hakkında soru sorabileceği uygulamalar" extra="Boşsa hiçbir uygulama hakkında soru soramaz.">
            <Select mode="multiple" optionFilterProp="label" options={toSelectOptions(apps)} />
          </Form.Item>
          <Form.Item name="queryTenantIds" label="Kullanıcıları için soru sorabileceği kurumlar" extra="Alt kurumlar dahildir. Boşsa hiçbir kullanıcı için soru soramaz.">
            <Select mode="multiple" optionFilterProp="label" options={toSelectOptions(tenants)} />
          </Form.Item>
          {type === 'Intermediary' && <Form.Item name="onBehalfOfClientIds" label="Adına konuşabileceği client'lar" extra="Gateway, isteği başlatan client'ı sadece bu listedekiler için bildirebilir.">
            <Select mode="multiple" optionFilterProp="label" options={clients.filter((c) => c.type !== 'Intermediary' && c.id !== client?.id).map((c) => ({ value: c.id, label: c.clientId }))} />
          </Form.Item>}
          <Form.Item name="rateLimitPerMinute" label="İstek limiti (dakika)" extra="Boşsa motor varsayılanı (600/dk)." style={{ marginBottom: 0 }}><InputNumber min={1} style={{ width: 160 }} /></Form.Item>
        </Card>
        <Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item>
        <Form.Item name="isActive" label="Aktif" valuePropName="checked" extra="Pasif client motoru kullanamaz (token alamaz, mevcut token'ı reddedilir)."><Switch /></Form.Item>
      </Form>
    </Modal>
  )
}

/** Client'ın motor secret'ları: oluştur (düz metin bir kez gösterilir), iptal et. */
function SecretsDrawer({ client, onClose }: { client: ClientRow; onClose: () => void }) {
  const { data, reload } = useApi<SecretView[]>(`/api/clients/${client.id}/secrets`)
  const [created, setCreated] = useState<{ secret: string }>()
  const [desc, setDesc] = useState('')
  const [days, setDays] = useState<number | null>(180)
  const { message } = App.useApp()
  const create = async () => {
    try {
      const r = await api.post<{ secret: string }>(`/api/clients/${client.id}/secrets`, { description: desc || undefined, expiresInDays: days ?? undefined })
      setCreated(r); setDesc(''); reload()
    } catch (e) { message.error((e as Error).message) }
  }
  const revoke = async (s: SecretView) => {
    try { await api.del(`/api/clients/${client.id}/secrets/${s.id}`); message.success('Secret iptal edildi'); reload() } catch (e) { message.error((e as Error).message) }
  }
  return (
    <Drawer open width={720} title={<>Motor secret'ları · <Code>{client.clientId}</Code></>} onClose={onClose}>
      <Alert type="info" showIcon style={{ marginBottom: 12 }} message="Secret sadece oluşturulurken bir kez gösterilir; sistemde yalnızca özeti tutulur."
        description="Kesintisiz değişim: yeni secret oluşturun, tüketici yenisine geçince eskisini iptal edin. İptal edilen / süresi dolan secret ile token alınamaz." />
      {created && <Alert type="success" showIcon style={{ marginBottom: 12 }} closable onClose={() => setCreated(undefined)}
        message="Yeni secret — şimdi kopyalayın, tekrar gösterilmeyecek" description={<Typography.Text code copyable>{created.secret}</Typography.Text>} />}
      <Flex gap={8} style={{ marginBottom: 12 }} wrap>
        <Input placeholder="Açıklama (ör. prod 2026-10)" value={desc} onChange={(e) => setDesc(e.target.value)} style={{ width: 260 }} />
        <InputNumber placeholder="Gün (boş: süresiz)" value={days} onChange={setDays} min={1} addonAfter="gün" style={{ width: 170 }} />
        <Button type="primary" icon={<PlusOutlined />} onClick={create}>Secret oluştur</Button>
      </Flex>
      <Table<SecretView> size="small" rowKey="id" pagination={false} dataSource={data ?? []}
        columns={[
          { title: 'Secret', render: (_, s) => <><Code>{s.prefix}…</Code><div><Typography.Text type="secondary" style={{ fontSize: 12 }}>{s.description}</Typography.Text></div></> },
          { title: 'Durum', render: (_, s) => s.revokedAt ? <Tag>iptal</Tag> : s.isValid ? <Tag color="green">geçerli</Tag> : <Tag color="orange">süresi doldu</Tag> },
          { title: 'Oluşturma', render: (_, s) => <Typography.Text style={{ fontSize: 12 }}>{fmt(s.createdAt)} · {s.createdBy}</Typography.Text> },
          { title: 'Bitiş', render: (_, s) => <Typography.Text style={{ fontSize: 12 }}>{s.expiresAt ? fmt(s.expiresAt) : 'süresiz'}</Typography.Text> },
          { title: 'Son kullanım', render: (_, s) => <Typography.Text style={{ fontSize: 12 }}>{s.lastUsedAt ? fmt(s.lastUsedAt) : '—'}</Typography.Text> },
          { width: 60, render: (_, s) => s.isValid && <Popconfirm title="Secret iptal edilsin mi?" description="Bu secret ile artık token alınamaz." onConfirm={() => revoke(s)}><Button size="small" type="text" danger icon={<DeleteOutlined />} /></Popconfirm> },
        ]} />
    </Drawer>
  )
}
