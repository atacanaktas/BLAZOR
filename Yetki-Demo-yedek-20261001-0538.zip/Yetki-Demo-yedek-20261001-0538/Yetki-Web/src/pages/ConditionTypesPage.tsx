import { Alert, Table, Tabs, Tag, Typography } from 'antd'
import { Link } from 'react-router-dom'
import type { ConditionTypeInfo, GroupCriterionInfo, ParamDef, RuleView } from '../api/types'
import { useApi } from '../hooks/useApi'
import { Code, PageHeader } from '../components/common'

/** Koşul tipleri (policy) ve grup kriterleri: davranış C# handler'dadır, DB sadece parametre tutar. */
export function ConditionTypesPage() {
  const types = useApi<ConditionTypeInfo[]>('/api/condition-types')
  const criteria = useApi<GroupCriterionInfo[]>('/api/group-criteria')
  const rules = useApi<RuleView[]>('/api/rules')
  return (
    <>
      <PageHeader title="Koşul tipleri" subtitle="Politika ve grup kurallarında kullanılabilen koşulları inceleyin." />
      <Alert type="info" showIcon style={{ marginBottom: 12 }}
        message="İki ayrı mekanizma"
        description={<>
          <b>Grup kriteri</b> (ROLE, ORG_UNIT, TITLE...): <i>statik</i> kullanıcı özelliği → "kim üye?" (yetki verir, önceden hesaplanır).<br />
          <b>Policy koşulu</b> (TIME_WINDOW, IP_IN_RANGE, AMOUNT...): <i>istek bağlamı</i> → "şu an yapılabilir mi?" (daraltır). "Sadece kullanıcı" işaretli koşullar bağlam gerektirmez.
        </>} />
      <Tabs items={[
        {
          key: 'types', label: `Policy koşul tipleri (${types.data?.length ?? 0})`,
          children: (
            <Table size="small" rowKey="code" loading={types.loading} dataSource={types.data ?? []} pagination={false}
              columns={[
                { title: 'Kod', render: (_, t) => <><Code>{t.code}</Code>{!t.isAvailable && <Tag color="red">handler yok</Tag>}<br /><Typography.Text type="secondary">{t.name}</Typography.Text></> },
                { title: 'TRUE ise', dataIndex: 'description' },
                { title: 'Parametreler', render: (_, t) => (JSON.parse(t.parameterSchemaJson) as ParamDef[]).map((p) => <Tag key={p.key} title={p.description}>{p.key}{p.required ? '*' : ''}: {p.type}</Tag>) },
                { title: 'Okuduğu attribute', render: (_, t) => (t.requiredAttributes ?? '').split(',').filter(Boolean).map((a) => <Tag key={a} color={a.startsWith('Subject.') ? 'blue' : a.startsWith('Environment.') ? 'cyan' : 'orange'}>{a}</Tag>) },
                { title: '', render: (_, t) => t.isSubjectOnly && <Tag color="purple">sadece kullanıcı</Tag> },
              ]} />
          ),
        },
        {
          key: 'criteria', label: `Grup kriterleri (${criteria.data?.length ?? 0})`,
          children: (
            <Table size="small" rowKey="code" dataSource={criteria.data ?? []} pagination={false}
              columns={[
                { title: 'Kod', render: (_, c) => <><Code>{c.code}</Code><br /><Typography.Text type="secondary">{c.name}</Typography.Text></> },
                { title: 'Anlamı', dataIndex: 'description' },
                { title: 'Değer kaynağı', dataIndex: 'valueSource', render: (v) => <Tag>{v}</Tag> },
              ]} />
          ),
        },
        {
          key: 'rules', label: `Tüm rule'lar (${rules.data?.length ?? 0})`,
          children: (
            <Table size="small" rowKey="id" dataSource={rules.data ?? []} pagination={{ pageSize: 25 }}
              columns={[
                { title: 'Policy', render: (_, r) => <Link to={`/policies/${r.policyId}`}><Tag color="purple">{r.policy}</Tag></Link> },
                { title: 'Rule', render: (_, r) => <><Code>{r.code}</Code><br /><Typography.Text type="secondary">{r.name}</Typography.Text></> },
                { title: 'Sağlandı değilse', dataIndex: 'reasonCode', render: (v) => v && <Code>{v}</Code> },
                { title: 'Koşul (sağlanmalı)', dataIndex: 'expression', render: (v) => <Typography.Text style={{ fontSize: 12 }}>{v}</Typography.Text> },
              ]} />
          ),
        },
      ]} />
    </>
  )
}
