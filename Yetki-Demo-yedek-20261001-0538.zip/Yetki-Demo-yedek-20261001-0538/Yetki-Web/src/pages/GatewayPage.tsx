import { Alert, App, Button, Card, Col, Flex, Input, Row, Select, Steps, Table, Tag, Typography } from 'antd'
import { ApiOutlined, SendOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { api } from '../api/client'
import type { AuthorizationDecision } from '../api/types'
import { useOptions } from '../hooks/useApi'
import { AccessKey, Code, DecisionTag, MethodTag, PageGuide, PageHeader } from '../components/common'
import { DecisionView } from '../components/DecisionView'

interface MatchResult { matched?: { key: string; name: string; uri: string; application: string; resourceId: number }; ambiguous: { key: string; uri: string }[] }

interface LogRow {
  id: number
  method: string
  path: string
  user?: string
  client?: string
  status: number
  decision: AuthorizationDecision
}

const methods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE']

const samples: { label: string; method: string; path: string; user: string; client: string; headers?: Record<string, string> }[] = [
  { label: 'Vadeli hesap listesi', method: 'GET', path: '/v1/vadeli-hesap', user: 'ali.demir', client: 'nextral-api' },
  { label: 'Vadeli hesap kapat', method: 'POST', path: '/v1/vadeli-hesap/TR120001/kapat', user: 'ali.demir', client: 'nextral-api' },
  { label: 'Vadeli kapat · gişe asistanı', method: 'POST', path: '/v1/vadeli-hesap/TR120001/kapat', user: 'ayse.yilmaz', client: 'nextral-api' },
  { label: 'Para çekme 20.000', method: 'POST', path: '/v1/cash-withdrawals', user: 'ahmet.kaya', client: 'nextral-api', headers: { TransactionAmount: '20000', CustomerId: 'C-555' } },
  { label: 'Tanımsız endpoint (dekont)', method: 'GET', path: '/v1/vadeli-hesap/TR120001/dekont', user: 'ali.demir', client: 'nextral-api' },
  { label: 'EFT iptal (DELETE → cancel)', method: 'DELETE', path: '/v1/eft/E-9', user: 'zeynep.acar', client: 'nextral-api' },
  { label: 'Müşteri · Anka Web (maske)', method: 'GET', path: '/v1/musteriler/C-555', user: 'ayse.yilmaz', client: 'anka-web' },
]

/**
 * Gateway simülatörü: uygulama kodunda [Authorize("X")] yok. Gateway her isteğin METHOD + path'ini PDP'ye gönderir;
 * motor kayıtlı URI desenlerinden resource:scope'u bulur, permission / policy'leri değerlendirir. Tanımsız URI → 403.
 */
export function GatewayPage() {
  const { message } = App.useApp()
  const users = useOptions('users')
  const clients = useOptions('clients')
  const apps = useOptions('applications')
  const [application, setApplication] = useState<string | undefined>('ANKA')
  const [method, setMethod] = useState('GET')
  const [path, setPath] = useState('/v1/vadeli-hesap/TR120001')
  const [user, setUser] = useState<string | undefined>('ali.demir')
  const [client, setClient] = useState<string | undefined>('nextral-api')
  const [ip, setIp] = useState('10.1.2.3')
  const [gateway, setGateway] = useState<string | undefined>('anka-gateway')
  const via = gateway && clients.some((c) => c.code === gateway) ? [gateway] : undefined
  const [extra, setExtra] = useState<Record<string, string>>({})
  const [match, setMatch] = useState<MatchResult>()
  const [log, setLog] = useState<LogRow[]>([])
  const [selected, setSelected] = useState<LogRow>()
  const [busy, setBusy] = useState(false)

  const send = async (m = method, p = path, u = user, c = client, ctx = extra) => {
    setBusy(true)
    try {
      const qs = new URLSearchParams({ method: m, path: p })
      if (application) qs.set('application', application)
      setMatch(await api.get<MatchResult>(`/api/uri-match?${qs.toString()}`))
      // Motoru gateway çağırır (soran = gateway; kendi token'ıyla), isteği başlatan client'ı (azp) kendisi bildirir.
      // Gateway seçilmediyse client doğrudan soruyor demektir. Konsol ucu: token yerine soran burada belirtilir.
      const decision = await api.post<AuthorizationDecision>('/api/console/authorize', {
        subject: { id: u }, client: c, caller: via?.[0] ?? c,
        http: { application, method: m, path: p },
        context: { IpAddress: ip, ...ctx },
      })
      const row: LogRow = { id: Date.now(), method: m, path: p, user: u, client: c, status: decision.isAllowed ? 200 : 403, decision }
      setLog((l) => [row, ...l].slice(0, 30))
      setSelected(row)
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setBusy(false)
    }
  }

  const d = selected?.decision
  return (
    <>
      <PageHeader title="Gateway simülatörü" subtitle="Geliştiricinin koda yetki kodu yazmasına gerek yok: gateway her isteği METHOD + URI ile sorar, tanımsız endpoint kapalıdır." />
      <PageGuide>
        <p>Akış: <b>istek → gateway (PEP)</b> → <Code>POST /api/v1/authorize {'{ http: { method, path }, subject, client }'}</Code> → motor URI desenlerinden <b>resource:scope</b>'u bulur → o yetkiye uygulanan permission'ları ve policy'leri değerlendirir → 200 / 403.</p>
        <p>Gateway motoru <b>kendi token'ıyla</b> çağırır (<Code>POST /api/v1/token</Code>, client_id + secret). Soran = gateway; isteği başlatan client'ı (ör. nextral-api) gateway bildirir ve bunu sadece adına konuşma yetkisi olduğu client'lar için yapabilir. Kullanıcı ve bağlam bilgisinin doğruluğu gateway'in sorumluluğundadır.</p>
        <p>Eşleşen desen yoksa istek <Code>URI_NOT_REGISTERED</Code> ile reddedilir; yani yetki yönetiminin tanımlamadığı hiçbir endpoint dışarı açılmaz. Policy'nin istediği değer (tutar, müşteri no...) istekte yoksa karar belirsiz olur ve yine reddedilir.</p>
      </PageGuide>
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={10}>
          <Card size="small" title={<><ApiOutlined /> İstek</>}>
            <Flex vertical gap={8}>
              <Flex gap={6} wrap>{samples.map((s) => (
                <Button key={s.label} size="small" onClick={() => { setMethod(s.method); setPath(s.path); setUser(s.user); setClient(s.client); setExtra(s.headers ?? {}); send(s.method, s.path, s.user, s.client, s.headers ?? {}) }}>{s.label}</Button>
              ))}</Flex>
              <Flex gap={6}>
                <Select allowClear placeholder="Uygulama (upstream)" value={application} onChange={setApplication} options={apps.map((a) => ({ value: a.code, label: a.label }))} style={{ flex: 1 }} />
                <Select allowClear placeholder="Soran: client'ın kendisi" value={gateway} onChange={setGateway} options={clients.map((c) => ({ value: c.code, label: `soran: ${c.code}` }))} style={{ width: 220 }} />
              </Flex>
              <Flex gap={6}>
                <Select value={method} onChange={setMethod} options={methods.map((m) => ({ value: m, label: m }))} style={{ width: 110 }} />
                <Input value={path} onChange={(e) => setPath(e.target.value)} onPressEnter={() => send()} />
              </Flex>
              <Flex gap={6}>
                <Select showSearch allowClear placeholder="Kullanıcı (token sub)" optionFilterProp="label" value={user} onChange={setUser} options={users.map((u) => ({ value: u.code, label: u.label }))} style={{ flex: 1 }} />
                <Select allowClear placeholder="Client (azp)" value={client} onChange={setClient} options={clients.map((c) => ({ value: c.code, label: c.code }))} style={{ width: 200 }} />
              </Flex>
              <Input addonBefore="X-Forwarded-For" value={ip} onChange={(e) => setIp(e.target.value)} />
              <Input addonBefore="Ek context" placeholder="TransactionAmount=20000, CustomerId=C-555"
                value={Object.entries(extra).map(([k, v]) => `${k}=${v}`).join(', ')}
                onChange={(e) => setExtra(Object.fromEntries(e.target.value.split(',').map((x) => x.trim().split('=')).filter((x) => x.length === 2 && x[0]).map(([k, v]) => [k.trim(), v.trim()])))} />
              <Button type="primary" icon={<SendOutlined />} loading={busy} onClick={() => send()}>Gönder</Button>
            </Flex>
          </Card>
          {match && (
            <Card size="small" title="1 · URI eşleşmesi (katalog)" style={{ marginTop: 16 }}>
              {match.matched
                ? <>Desen <Code>{match.matched.uri}</Code> → <AccessKey value={match.matched.key} /> <Typography.Text type="secondary">{match.matched.name}</Typography.Text></>
                : match.ambiguous.length
                  ? <Alert type="error" showIcon message="Belirsiz eşleşme — reddedilir" description={match.ambiguous.map((a) => <div key={a.key + a.uri}><Code>{a.uri}</Code> → {a.key}</div>)} />
                  : <Alert type="error" showIcon message="Eşleşen URI deseni yok → 403 (URI_NOT_REGISTERED)" description="Bu endpoint yetki tanımlarında yok. Resources'ta ilgili resource'a URI eşlemesi ekleyin veya Envanter & Kapsama'dan tanımlayın." />}
            </Card>
          )}
          <Card size="small" title="Gateway erişim logu" style={{ marginTop: 16 }}>
            <Table<LogRow> size="small" rowKey="id" dataSource={log} pagination={false} rowClassName={(r) => (r.id === selected?.id ? 'ant-table-row-selected' : 'clickable-row')}
              onRow={(r) => ({ onClick: () => setSelected(r) })}
              columns={[
                { title: 'Durum', dataIndex: 'status', width: 70, render: (v) => <Tag color={v === 200 ? 'green' : 'red'}>{v}</Tag> },
                { title: 'İstek', render: (_, r) => <><MethodTag method={r.method} /><Typography.Text style={{ fontSize: 12 }}>{r.path}</Typography.Text></> },
                { title: 'Kim', render: (_, r) => <Typography.Text style={{ fontSize: 12 }}>{r.user} · {r.client}</Typography.Text> },
                { title: 'Neden', render: (_, r) => <Code>{r.decision.reasonCode}</Code> },
              ]} />
          </Card>
        </Col>
        <Col xs={24} xl={14}>
          {d ? (
            <Flex vertical gap={12}>
              <Card size="small">
                <Steps size="small" current={d.isAllowed ? 3 : undefined} status={d.isAllowed ? 'finish' : 'error'}
                  items={[
                    { title: 'Gateway', description: `${selected!.method} ${selected!.path}` },
                    { title: 'resource:scope', description: d.permission ?? '—' },
                    { title: 'Permission / policy', description: d.decidingPermission ?? d.reasonCode },
                    { title: d.isAllowed ? '200 → upstream' : '403', description: <DecisionTag decision={d.decision} /> },
                  ]} />
                {d.obligations.length > 0 && <Alert style={{ marginTop: 8 }} type="warning" showIcon message={<>Gateway yanıtta uygular: {d.obligations.map((o) => <Tag key={o.code} color="gold">⚑ {o.code} {Object.entries(o.parameters).map(([k, v]) => `${k}=${v}`).join(' ')}</Tag>)}</>} />}
              </Card>
              <DecisionView decision={d} />
            </Flex>
          ) : (
            <Card className="evaluation-empty">
              <span className="evaluation-empty-icon"><ApiOutlined /></span>
              <Typography.Title level={4}>Bir istek gönderin</Typography.Title>
              <Typography.Paragraph type="secondary">Hazır örneklerden birini seçin. Gateway'in PDP'ye ne sorduğu, URI'nin hangi yetkiye eşlendiği ve kararın gerekçesi burada görünür.</Typography.Paragraph>
            </Card>
          )}
        </Col>
      </Row>
    </>
  )
}
