import { App, Button, Card, Col, Collapse, DatePicker, Flex, Form, Input, InputNumber, Row, Segmented, Select, Switch, Tabs, Typography } from 'antd'
import { ThunderboltOutlined } from '@ant-design/icons'
import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import type { Dayjs } from 'dayjs'
import { api } from '../api/client'
import type { AuthorizationDecision, AuthorizationRequest } from '../api/types'
import { useOptions } from '../hooks/useApi'
import { DecisionView } from '../components/DecisionView'
import { PageHeader } from '../components/common'
import { nextBusinessMorning } from '../components/PolicyImpact'

interface EvalForm {
  tenant?: string
  user?: string
  client?: string
  via?: string[]
  /** Motoru çağıran (soran) client. Boşsa yönetim konsolu: soru kapsamı uygulanmaz. */
  caller?: string
  target: 'http' | 'resource' | 'key'
  application?: string
  method?: string
  path?: string
  resource?: string
  scope?: string
  key?: string
  resourceId?: string
  // kaydın (resource instance) özellikleri
  RecordTenant?: string
  BranchCode?: string
  CustomerId?: string
  // bağlam (context)
  IpAddress?: string
  TransactionAmount?: number
  Platform?: string
  DeviceCompliant?: boolean
  simulate?: boolean
  asOf?: Dayjs
}

const BANK_IP = '10.1.2.3'
const http = (method: string, path: string, application = 'ANKA'): Partial<EvalForm> => ({ target: 'http', application, method, path })
const rs = (key: string): Partial<EvalForm> => { const [resource, scope] = key.split(':'); return { target: 'resource', resource, scope } }

const presets: { group: string; items: Record<string, Partial<EvalForm>> }[] = [
  {
    group: 'Soran (motoru çağıran client) kapsamı',
    items: {
      'nextral-api sorar · kendi kapsamında': { caller: 'nextral-api', client: undefined, user: 'ayse.yilmaz', ...http('GET', '/v1/musteriler/C-555'), IpAddress: BANK_IP },
      'nextral-api sorar · B_PORTAL (kapsam dışı)': { caller: 'nextral-api', client: undefined, tenant: 'BISTIRAK', user: 'nil.sezer', ...http('GET', '/v1/portfoy/rapor', 'B_PORTAL') },
      'nextral-api, anka-web gibi davranır': { caller: 'nextral-api', client: 'anka-web', user: 'ayse.yilmaz', ...http('GET', '/v1/musteriler/C-555'), IpAddress: BANK_IP },
      'anka-gateway, nextral-api adına sorar': { caller: 'anka-gateway', client: 'nextral-api', user: 'ayse.yilmaz', ...http('GET', '/v1/musteriler/C-555'), IpAddress: BANK_IP },
      'b-portal-web, ABANK kullanıcısı için sorar': { caller: 'b-portal-web', client: undefined, user: 'ayse.yilmaz', ...http('GET', '/v1/portfoy/rapor', 'B_PORTAL') },
    },
  },
  {
    group: 'Gateway (METHOD + URI)',
    items: {
      'Ahmet · para çekme 75.000 (PERMIT)': { tenant: 'ABANK', user: 'ahmet.kaya', client: 'nextral-api', ...http('POST', '/v1/cash-withdrawals'), TransactionAmount: 75000, CustomerId: 'C-555', IpAddress: BANK_IP, simulate: true },
      'Ahmet · 150.000 (limit kuralı)': { tenant: 'ABANK', user: 'ahmet.kaya', client: 'nextral-api', ...http('POST', '/v1/cash-withdrawals'), TransactionAmount: 150000, CustomerId: 'C-555', IpAddress: BANK_IP, simulate: true },
      'Ahmet · 20:00 (mesai)': { tenant: 'ABANK', user: 'ahmet.kaya', client: 'nextral-api', ...http('POST', '/v1/cash-withdrawals'), TransactionAmount: 5000, CustomerId: 'C-555', IpAddress: BANK_IP, simulate: true },
      'Ahmet · banka ağı dışı': { tenant: 'ABANK', user: 'ahmet.kaya', client: 'nextral-api', ...http('POST', '/v1/cash-withdrawals'), TransactionAmount: 5000, CustomerId: 'C-555', IpAddress: '85.100.1.1', simulate: true },
      'İzindeki gişe yetkilisi (negatif policy)': { tenant: 'ABANK', user: 'selin.aydin', client: 'nextral-api', ...http('POST', '/v1/cash-withdrawals'), TransactionAmount: 100, CustomerId: 'C-555', IpAddress: BANK_IP, simulate: true },
      'Kendi hesabından çekim': { user: 'ayse.yilmaz', client: 'nextral-api', ...http('POST', '/v1/cash-withdrawals'), TransactionAmount: 100, CustomerId: 'C-1001', IpAddress: BANK_IP, simulate: true },
      'Rolü yok (NO_EFFECTIVE_PERMISSION)': { tenant: 'ABANK', user: 'elif.sahin', client: 'nextral-api', ...http('POST', '/v1/cash-withdrawals'), TransactionAmount: 100, IpAddress: BANK_IP, simulate: true },
      'Vadeli kapat (POST …/kapat → close)': { user: 'ali.demir', client: 'nextral-api', ...http('POST', '/v1/vadeli-hesap/TR120001/kapat'), IpAddress: BANK_IP, simulate: true },
      'Tanımsız URI (reddedilir)': { user: 'ali.demir', client: 'nextral-api', ...http('GET', '/v1/vadeli-hesap/TR120001/dekont'), IpAddress: BANK_IP },
      'Kredi onayı 2M · şube müdürü': { user: 'ali.demir', client: 'nextral-api', ...http('POST', '/v1/kredi/dosya/K-1/onay'), TransactionAmount: 2000000, IpAddress: BANK_IP },
      'Kredi onayı 2M · GM 850': { user: 'sibel.ates', client: 'nextral-api', ...http('POST', '/v1/kredi/dosya/K-1/onay'), TransactionAmount: 2000000, IpAddress: BANK_IP },
    },
  },
  {
    group: 'Kanal (client) · aracı · yükümlülük',
    items: {
      'Vadeli · mobil, cihaz uyumlu': { user: 'zeynep.acar', client: 'mobil-sube-tablet', ...http('GET', '/v1/vadeli-hesap/TR1'), IpAddress: '85.100.1.1', DeviceCompliant: true, simulate: true },
      'Vadeli · mobil, cihaz uyumsuz': { user: 'zeynep.acar', client: 'mobil-sube-tablet', ...http('GET', '/v1/vadeli-hesap/TR1'), IpAddress: '85.100.1.1', DeviceCompliant: false, simulate: true },
      'Müşteri · Anka Web (maskeleme)': { user: 'ayse.yilmaz', client: 'anka-web', ...http('GET', '/v1/musteriler/C-555'), IpAddress: BANK_IP },
      'Nextral → gateway → Anka': { user: 'ayse.yilmaz', client: 'nextral-api', via: ['anka-gateway'], ...http('GET', '/v1/musteriler/C-555'), IpAddress: BANK_IP },
      'Gateway client olarak (reddedilir)': { user: 'zeynep.acar', client: 'anka-gateway', ...http('POST', '/v1/eft'), IpAddress: BANK_IP },
      'Para çek butonu · Nextral': { user: 'ayse.yilmaz', client: 'nextral-api', ...rs('nextral.buton.nakitcekim:execute') },
      'Para çek butonu · Anka Web': { user: 'ayse.yilmaz', client: 'anka-web', ...rs('nextral.buton.nakitcekim:execute') },
    },
  },
  {
    group: 'Tenant · grup · veri kapsamı',
    items: {
      'Başka tenant adına işlem': { tenant: 'BISTIRAK', user: 'ayse.yilmaz', client: 'nextral-api', ...http('GET', '/v1/cash-withdrawals'), IpAddress: BANK_IP },
      'Başka tenant\'ın kaydı': { tenant: 'ABANK', user: 'ayse.yilmaz', client: 'nextral-api', ...http('GET', '/v1/cash-withdrawals/77'), RecordTenant: 'BISTIRAK', IpAddress: BANK_IP },
      'B portalı · B kullanıcısı': { tenant: 'BISTIRAK', user: 'nil.sezer', client: 'b-portal-web', ...http('GET', '/v1/portfoy/rapor', 'B_PORTAL'), IpAddress: BANK_IP },
      'Kredi kullandırım · komite (grup)': { user: 'sibel.ates', client: 'nextral-api', ...http('POST', '/v1/kredi/dosya/K-1/kullandir'), IpAddress: BANK_IP },
      'Kredi kullandırım · 737 müdürü': { user: 'emre.yildiz', client: 'nextral-api', ...http('POST', '/v1/kredi/dosya/K-1/kullandir'), IpAddress: BANK_IP },
      'Şube raporu · kendi şubesi': { user: 'ali.demir', client: 'nextral-api', ...http('GET', '/v1/raporlar/sube/101'), BranchCode: '101', IpAddress: BANK_IP, simulate: true },
      'Şube raporu · başka şube': { user: 'ali.demir', client: 'nextral-api', ...http('GET', '/v1/raporlar/sube/737'), BranchCode: '737', IpAddress: BANK_IP, simulate: true },
      'Şube raporu · iç denetim (kullanıcı policy)': { user: 'gul.yuce', client: 'nextral-api', ...http('GET', '/v1/raporlar/sube/737'), BranchCode: '737', IpAddress: BANK_IP, simulate: true },
      'Servis · rapor batch': { user: undefined, client: 'rapor-batch', ...http('GET', '/v1/raporlar/sube/101/export'), BranchCode: '101', IpAddress: '10.9.9.9' },
    },
  },
]

function buildRequest(v: EvalForm): AuthorizationRequest {
  const context: Record<string, string> = {}
  for (const k of ['IpAddress', 'TransactionAmount', 'Platform'] as const) {
    const val = v[k]
    if (val !== undefined && val !== null && val !== '') context[k] = String(val)
  }
  if (v.DeviceCompliant !== undefined) context.DeviceCompliant = String(v.DeviceCompliant)
  const properties: Record<string, string> = {}
  if (v.RecordTenant) properties.Tenant = v.RecordTenant
  if (v.BranchCode) properties.BranchCode = v.BranchCode
  if (v.CustomerId) properties.CustomerId = v.CustomerId
  const hasProps = Object.keys(properties).length > 0
  return {
    tenant: v.tenant || undefined,
    client: v.client || undefined,
    caller: v.caller || undefined,
    via: v.via?.length ? v.via : undefined,
    subject: { id: v.user },
    http: v.target === 'http' ? { application: v.application || undefined, method: v.method ?? 'GET', path: v.path ?? '/' } : undefined,
    permission: v.target === 'key' ? v.key : undefined,
    scope: v.target === 'resource' ? v.scope : undefined,
    resource: v.target === 'resource' ? { type: v.resource, id: v.resourceId || undefined, properties } : hasProps || v.resourceId ? { id: v.resourceId || undefined, properties } : undefined,
    context,
  }
}

/** AuthZEN biçimi: http → resource.type "http"; resource+scope → action.name = scope; anahtar → action.name = "resource:scope". */
function toAuthZen(r: AuthorizationRequest) {
  const subject = r.subject.id ? { type: 'user', id: r.subject.id, properties: r.tenant ? { tenant: r.tenant } : undefined } : { type: 'client', id: r.client }
  const context = { client_id: r.client, ...(r.via?.length ? { via: r.via.join(',') } : {}), ...r.context }
  if (r.http) return { subject, action: { name: r.http.method }, resource: { type: 'http', id: r.http.application, properties: { path: r.http.path, ...r.resource?.properties } }, context }
  if (r.permission) return { subject, action: { name: r.permission }, resource: r.resource, context }
  return { subject, action: { name: r.scope }, resource: r.resource, context }
}

export function EvaluatePage() {
  const [params] = useSearchParams()
  const [form] = Form.useForm<EvalForm>()
  const { message } = App.useApp()
  const users = useOptions('users')
  const tenants = useOptions('tenants')
  const apps = useOptions('applications')
  const resources = useOptions('resources')
  const accesses = useOptions('resource-scopes')
  const clients = useOptions('clients')
  const [result, setResult] = useState<AuthorizationDecision>()
  const [loading, setLoading] = useState(false)
  const target = Form.useWatch('target', form)
  const resource = Form.useWatch('resource', form)
  const simulate = Form.useWatch('simulate', form)
  const [request, setRequest] = useState<AuthorizationRequest>()

  const scopes = useMemo(() => {
    if (!resource) return []
    return accesses.filter((a) => a.code.startsWith(`${resource}:`)).map((a) => ({ value: a.code.slice(resource.length + 1), label: a.label.slice(resource.length + 1) }))
  }, [resource, accesses])

  const key = params.get('permission')
  const initial: Partial<EvalForm> = key ? { ...rs(key), user: params.get('user') ?? undefined }
    : { ...http('POST', '/v1/cash-withdrawals'), user: params.get('user') ?? 'ahmet.kaya', tenant: 'ABANK' }

  const submit = async () => {
    const v = await form.validateFields()
    const r = buildRequest(v)
    setRequest(r)
    setLoading(true)
    try {
      setResult(v.simulate
        ? await api.post<AuthorizationDecision>('/api/simulation/evaluate', { request: r, asOfUtc: v.asOf?.toISOString() })
        : await api.post<AuthorizationDecision>('/api/console/authorize', r))
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setLoading(false)
    }
  }

  const applyPreset = (label: string, p: Partial<EvalForm>) => {
    form.resetFields()
    const hour = label.includes('20:00') ? 20 : label.startsWith('Ahmet') ? 14 : 11
    form.setFieldsValue({ tenant: undefined, via: undefined, caller: undefined, RecordTenant: undefined, BranchCode: undefined, CustomerId: undefined, TransactionAmount: undefined, DeviceCompliant: undefined, ...p,
      asOf: p.simulate ? nextBusinessMorning().hour(hour).minute(hour === 14 ? 35 : 0) : undefined })
  }

  return (
    <>
      <PageHeader title="Yetki testi"
        subtitle="Bir kullanıcının isteğinin sonucunu görün: gateway gibi METHOD + URI ile, resource + scope ile veya yetki anahtarıyla." />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={9}>
          <Card size="small" title="Değerlendirme bilgileri">
            <Collapse size="small" style={{ marginBottom: 20 }} items={presets.map((g, i) => ({
              key: String(i), label: g.group,
              children: <Flex wrap gap={4}>{Object.entries(g.items).map(([label, p]) => <Button key={label} size="small" onClick={() => applyPreset(label, p)}>{label}</Button>)}</Flex>,
            }))} />
            <Form form={form} layout="vertical" initialValues={{ client: 'nextral-api', TransactionAmount: 20000, CustomerId: 'C-555', IpAddress: BANK_IP, ...initial }}>
              <Row gutter={8}>
                <Col span={8}><Form.Item name="tenant" label="Tenant" tooltip="Boşsa kullanıcının tenant'ı. Kullanıcı başka tenant adına işlem yapamaz."><Select allowClear options={tenants.map((t) => ({ value: t.code, label: t.code }))} /></Form.Item></Col>
                <Col span={16}><Form.Item name="client" label="Client (isteği başlatan uygulama)"><Select allowClear showSearch optionFilterProp="label" options={clients.map((c) => ({ value: c.code, label: c.label }))} /></Form.Item></Col>
                <Col span={24}><Form.Item name="via" label="Aracı zinciri (via)" tooltip="Gateway / BFF: isteği kullanıcı adına iletir. Karar orijinal client'a göre verilir; aracı ayrıca doğrulanır.">
                  <Select mode="multiple" allowClear placeholder="Doğrudan (aracı yok)" options={clients.map((c) => ({ value: c.code, label: c.label }))} />
                </Form.Item></Col>
                <Col span={24}><Form.Item name="caller" label="Soran (motoru çağıran client)"
                  tooltip="Gerçekte soran, motor token'ından çıkar ve sadece kendi soru kapsamında (uygulama, kurum) soru sorabilir; başka client adına sadece yetkili aracı konuşabilir. Boş: yönetim konsolu — kapsam uygulanmaz.">
                  <Select allowClear placeholder="Yönetim konsolu (kapsam kontrolü yok)" options={clients.map((c) => ({ value: c.code, label: c.label }))} />
                </Form.Item></Col>
                <Col span={24}><Form.Item name="user" label="Subject (kullanıcı)"><Select allowClear showSearch optionFilterProp="label" options={users.map((u) => ({ value: u.code, label: `${u.label} (${u.group})` }))} /></Form.Item></Col>
              </Row>
              <Form.Item name="target"><Segmented block options={[{ value: 'http', label: 'METHOD + URI' }, { value: 'resource', label: 'Resource + Scope' }, { value: 'key', label: 'resource:scope' }]} /></Form.Item>
              {target === 'http' && (
                <Row gutter={8}>
                  <Col span={24}><Form.Item name="application" label="Uygulama (resource server)" tooltip="Boşsa tüm uygulamaların URI'lerinde aranır."><Select allowClear options={apps.map((a) => ({ value: a.code, label: a.label }))} /></Form.Item></Col>
                  <Col span={7}><Form.Item name="method" label="Metod"><Select options={['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].map((m) => ({ value: m, label: m }))} /></Form.Item></Col>
                  <Col span={17}><Form.Item name="path" label="Path" rules={[{ required: true }]}><Input placeholder="/v1/vadeli-hesap/TR12/kapat" /></Form.Item></Col>
                </Row>
              )}
              {target === 'resource' && (
                <Row gutter={8}>
                  <Col span={16}><Form.Item name="resource" label="Resource" rules={[{ required: true }]}>
                    <Select showSearch optionFilterProp="label" onChange={() => form.setFieldValue('scope', undefined)} options={resources.map((r) => ({ value: r.code, label: `${r.label} · ${r.group}` }))} />
                  </Form.Item></Col>
                  <Col span={8}><Form.Item name="scope" label="Scope" rules={[{ required: true }]}><Select options={scopes} /></Form.Item></Col>
                </Row>
              )}
              {target === 'key' && (
                <Form.Item name="key" label="Yetki (resource:scope)" rules={[{ required: true }]}><Select showSearch optionFilterProp="label" options={accesses.map((p) => ({ value: p.code, label: p.label }))} /></Form.Item>
              )}
              <Typography.Text strong>Kayıt (resource.properties)</Typography.Text>
              <Row gutter={8}>
                <Col span={8}><Form.Item name="RecordTenant" label="Tenant" tooltip="Kaydın ait olduğu tenant; istek tenant'ıyla aynı olmalı"><Select allowClear options={tenants.map((t) => ({ value: t.code, label: t.code }))} /></Form.Item></Col>
                <Col span={8}><Form.Item name="BranchCode" label="BranchCode"><Input /></Form.Item></Col>
                <Col span={8}><Form.Item name="CustomerId" label="CustomerId"><Input /></Form.Item></Col>
              </Row>
              <Typography.Text strong>Bağlam (context)</Typography.Text>
              <Row gutter={8}>
                <Col span={12}><Form.Item name="IpAddress" label="IpAddress"><Input /></Form.Item></Col>
                <Col span={12}><Form.Item name="TransactionAmount" label="TransactionAmount"><InputNumber style={{ width: '100%' }} min={0} step={1000} /></Form.Item></Col>
                <Col span={12}><Form.Item name="Platform" label="Platform"><Select allowClear options={['BRANCH_DESKTOP', 'MOBILE', 'INTERNET'].map((c) => ({ value: c, label: c }))} /></Form.Item></Col>
                <Col span={12}><Form.Item name="DeviceCompliant" label="Cihaz uyumlu (MDM)" valuePropName="checked"><Switch /></Form.Item></Col>
              </Row>
              <Flex gap={8} align="center">
                <Form.Item name="simulate" valuePropName="checked" style={{ marginBottom: 8 }}><Switch checkedChildren="Simülasyon" unCheckedChildren="Gerçek" /></Form.Item>
                {simulate && <Form.Item name="asOf" style={{ marginBottom: 8, flex: 1 }}><DatePicker showTime placeholder="Karar anı" style={{ width: '100%' }} /></Form.Item>}
              </Flex>
              <Button type="primary" icon={<ThunderboltOutlined />} block loading={loading} onClick={submit}>Değerlendir</Button>
            </Form>
          </Card>
          {request && (
            <Card size="small" style={{ marginTop: 16 }}>
              <Tabs size="small" items={[
                { key: 'std', label: 'İstek', children: <pre style={{ fontSize: 11, margin: 0, whiteSpace: 'pre-wrap' }}>{`POST /api/v1/authorize\nAuthorization: Bearer <${request.caller ?? 'soran client'} token'ı>   ← POST /api/v1/token (client_id + secret)\n\n${JSON.stringify({ ...request, caller: undefined }, null, 2)}`}</pre> },
                { key: 'az', label: 'AuthZEN biçimi', children: <pre style={{ fontSize: 11, margin: 0, whiteSpace: 'pre-wrap' }}>{`POST /access/v1/evaluation\n${JSON.stringify(toAuthZen(request), null, 2)}`}</pre> },
              ]} />
            </Card>
          )}
        </Col>
        <Col xs={24} xl={15}>
          {result ? <DecisionView decision={result} /> : (
            <Card className="evaluation-empty">
              <span className="evaluation-empty-icon"><ThunderboltOutlined /></span>
              <Typography.Title level={4}>Karar sonucunu burada görün</Typography.Title>
              <Typography.Paragraph type="secondary">Bir kullanıcı ve istek seçin ya da hazır senaryolardan başlayın. Karar, isteğin eşlendiği resource:scope, uygulanan permission'lar ve policy ağacı burada gösterilir.</Typography.Paragraph>
              <div className="evaluation-steps"><span>01 · İstek</span><span>02 · resource:scope</span><span>03 · Permission → Policy</span></div>
            </Card>
          )}
        </Col>
      </Row>
    </>
  )
}
