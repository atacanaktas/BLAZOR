import { Alert, App, Button, Card, Col, Descriptions, Flex, Form, Input, InputNumber, Modal, Popconfirm, Radio, Row, Select, Switch, Table, Tabs, Tag, Typography } from 'antd'
import { DeleteOutlined, EditOutlined, ExperimentOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { api } from '../api/client'
import type {
  ConditionDraft, ConditionTypeInfo, DecisionStrategy, DefinitionChangeResult, ObligationTypeDef, PolicyChangeSet, PolicyListItem, PolicyLogic, PolicyMemberView,
  PolicyMode, PolicyType, RuleView, SharedConditionInfo,
} from '../api/types'
import { invalidateOptions, toSelectOptions, useApi, useOptions, type OptionKind } from '../hooks/useApi'
import { ActiveTag, Code, LogicTag, ModeTag, PageGuide, PageHeader, PolicyTypeTag, StrategyTag, TagSummary, TenantTag, fmt, policyTypeMeta, strategyHelp, strategyLabel } from '../components/common'
import { ConditionBuilder, emptyPredicate, renderDraft, toDraft } from '../components/ConditionBuilder'
import { PolicyChangeModal } from '../components/PolicyImpact'
import { DefinitionChangeModal } from '../components/DefinitionChange'

const policyTypes: PolicyType[] = ['Role', 'Group', 'User', 'Client', 'Condition', 'Aggregate']
const strategies: DecisionStrategy[] = ['Unanimous', 'Affirmative', 'Consensus']
const memberKind: Partial<Record<PolicyType, OptionKind>> = { Role: 'roles', Group: 'groups', User: 'users', Client: 'clients', Aggregate: 'policies' }
const memberLabel: Record<PolicyType, string> = { Role: 'Roller', Group: 'Gruplar', User: 'Kullanıcılar', Client: 'Client\'lar (kanal)', Condition: '', Aggregate: 'Alt policy\'ler' }

// ================================ Liste ================================

export function PoliciesPage() {
  const { data, loading, reload } = useApi<PolicyListItem[]>('/api/policies')
  const [query, setQuery] = useState('')
  const [tab, setTab] = useState<PolicyType | 'all'>('all')
  const navigate = useNavigate()
  const [creating, setCreating] = useState(false)
  const q = query.toLocaleLowerCase('tr-TR')
  const filtered = (data ?? []).filter((p) => (tab === 'all' || p.type === tab)
    && `${p.code} ${p.name} ${p.members.map((m) => m.code).join(' ')}`.toLocaleLowerCase('tr-TR').includes(q))
  return (
    <>
      <PageHeader title="Policies" subtitle="KİM ve HANGİ KOŞULDA? Rol, grup, kullanıcı, kanal (client), koşul (ABAC) ve birleşik policy'ler. Permission'lar bunları resource/scope'lara bağlar."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setCreating(true)}>Yeni policy</Button>} />
      <PageGuide title="Policy nasıl değerlendirilir?">
        <p>Policy tek başına bir şeye erişim vermez; bir <Link to="/permissions">Permission</Link>'a eklendiğinde o permission'ın resource/scope'larını korur.</p>
        <p><b>Kimlik policy'leri</b> (Rol / Grup / Kullanıcı) kime verildiğini söyler. <b>Kanal</b> policy'si isteği başlatan client'ı, <b>Koşul</b> policy'si kuralları (saat, IP, tutar, şube...) değerlendirir. <b>Birleşik</b> policy alt policy'leri stratejiyle birleştirir (ör. "rol X VEYA grup Y" için Affirmative).</p>
        <p><b>Negatif</b> mantık sonucu tersine çevirir (ör. "izinli DEĞİLSE"). <b>ReportOnly</b> kararı etkilemez, sadece raporlanır; <b>Advisory</b> kararı etkilemez ama koşulu sağlanırsa yükümlülüklerini (maskeleme vb.) ekler.</p>
      </PageGuide>
      <Tabs activeKey={tab} onChange={(k) => setTab(k as PolicyType | 'all')}
        items={[{ key: 'all', label: `Tümü (${data?.length ?? 0})` }, ...policyTypes.map((t) => ({ key: t, label: <>{policyTypeMeta[t].icon} {policyTypeMeta[t].label} ({(data ?? []).filter((p) => p.type === t).length})</> }))]} />
      <Flex className="list-toolbar" justify="space-between" align="center" gap={12} wrap>
        <Input.Search allowClear placeholder="Policy kodu, adı veya üyesi ara" onChange={(e) => setQuery(e.target.value)} style={{ width: 340 }} />
        <Typography.Text type="secondary">{filtered.length} policy</Typography.Text>
      </Flex>
      <Table<PolicyListItem> rowKey="id" loading={loading} dataSource={filtered} pagination={{ pageSize: 20, hideOnSinglePage: true }}
        rowClassName="clickable-row" onRow={(p) => ({ onClick: () => navigate(`/policies/${p.id}`) })}
        columns={[
          { title: 'Policy', render: (_, p) => <><Code>{p.code}</Code> <LogicTag logic={p.logic} />{p.mode !== 'Enforce' && <ModeTag mode={p.mode} />}{!p.isActive && <Tag>pasif</Tag>}<br /><Typography.Text type="secondary">{p.name}</Typography.Text></> },
          { title: 'Tip', dataIndex: 'type', width: 150, render: (v) => <PolicyTypeTag type={v} /> },
          {
            title: 'Üyeler / kurallar', render: (_, p) => p.type === 'Condition'
              ? <><StrategyTag strategy={p.strategy} /><TagSummary values={p.rules.map((r) => `${r.name}${r.isActive ? '' : ' (pasif)'}`)} limit={3} /></>
              : <>{p.type === 'Aggregate' && <StrategyTag strategy={p.strategy} />}<TagSummary values={p.members.map((m) => m.code)} limit={4} /></>,
          },
          { title: 'Yükümlülük', dataIndex: 'obligations', width: 140, render: (v: string[]) => v.map((o) => <Tag key={o} color="gold">⚑ {o}</Tag>) },
          { title: 'Kullanan permission', dataIndex: 'permissions', render: (v: string[]) => v.length ? <TagSummary values={v} limit={3} /> : <Typography.Text type="secondary">kullanılmıyor</Typography.Text> },
          { title: 'Tenant', dataIndex: 'tenant', width: 100, render: (v) => <TenantTag tenant={v} /> },
        ]} />
      {creating && <PolicyCreateModal initialType={tab === 'all' ? undefined : tab} onClose={() => setCreating(false)}
        onDone={(id) => { reload(); invalidateOptions('policies'); if (id) navigate(`/policies/${id}`) }} />}
    </>
  )
}

/** Tipine göre üye seçici (rol / grup / kullanıcı / client / alt policy). */
function MemberPicker({ type, value, onChange, exclude }: { type: PolicyType; value?: number[]; onChange?: (v: number[]) => void; exclude?: number[] }) {
  const kind = memberKind[type] ?? 'roles'
  const options = useOptions(kind)
  return <Select mode="multiple" showSearch optionFilterProp="label" value={value} onChange={onChange}
    options={toSelectOptions(options, exclude)} placeholder={memberLabel[type]} />
}

interface PolicyFormValues {
  tenantId: number; code: string; name: string; description?: string; type: PolicyType; logic: PolicyLogic; decisionStrategy: DecisionStrategy
  mode: PolicyMode; isActive: boolean; memberIds: number[]
}

function PolicyFields({ type, editing, selfId }: { type: PolicyType; editing: boolean; selfId?: number }) {
  const tenants = useOptions('tenants')
  return (
    <Row gutter={12}>
      {!editing && <>
        <Col span={12}><Form.Item name="type" label="Tip" rules={[{ required: true }]} extra={policyTypeMeta[type]?.help}>
          <Select options={policyTypes.map((t) => ({ value: t, label: <>{policyTypeMeta[t].icon} {policyTypeMeta[t].label}</> }))} />
        </Form.Item></Col>
        <Col span={12}><Form.Item name="tenantId" label="Tenant" rules={[{ required: true }]}><Select options={toSelectOptions(tenants)} /></Form.Item></Col>
        <Col span={12}><Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input placeholder="ROL_GISE" /></Form.Item></Col>
      </>}
      <Col span={editing ? 24 : 12}><Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item></Col>
      {type !== 'Condition' && <Col span={24}><Form.Item name="memberIds" label={memberLabel[type]} rules={[{ required: true, type: 'array', min: 1 }]}
        extra={type === 'Group' ? 'Grup üyeliği (açık üye veya kitle kuralı) ve grubun rolleri dikkate alınır.' : type === 'Role' ? 'Rol doğrudan veya grup üzerinden gelebilir.' : type === 'Client' ? 'Karar orijinal client\'a (gateway üzerinden gelse bile) göre verilir.' : undefined}>
        <MemberPicker type={type} exclude={selfId ? [selfId] : []} />
      </Form.Item></Col>}
      <Col span={8}><Form.Item name="logic" label="Mantık" tooltip="Negatif: sonuç tersine çevrilir (şartı sağlamıyorsa izin).">
        <Radio.Group optionType="button" options={[{ value: 'Positive', label: 'Pozitif' }, { value: 'Negative', label: 'Negatif' }]} />
      </Form.Item></Col>
      {(type === 'Condition' || type === 'Aggregate') && <Col span={16}><Form.Item name="decisionStrategy" label={type === 'Condition' ? 'Kural birleştirme' : 'Alt policy birleştirme'}>
        <Select options={strategies.map((s) => ({ value: s, label: `${strategyLabel[s]} — ${strategyHelp[s]}` }))} />
      </Form.Item></Col>}
      <Col span={16}><Form.Item name="mode" label="Mod">
        <Radio.Group optionType="button" options={[{ value: 'Enforce', label: 'Enforce' }, { value: 'ReportOnly', label: 'ReportOnly (deneme)' }, { value: 'Advisory', label: 'Advisory (sadece yükümlülük)' }]} />
      </Form.Item></Col>
      <Col span={8}><Form.Item name="isActive" label="Aktif" valuePropName="checked" extra="Pasif policy → izin vermez (DENY)."><Switch /></Form.Item></Col>
      <Col span={24}><Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item></Col>
    </Row>
  )
}

function PolicyCreateModal({ initialType, onClose, onDone }: { initialType?: PolicyType; onClose: () => void; onDone: (id?: number) => void }) {
  const [form] = Form.useForm<PolicyFormValues>()
  const { message } = App.useApp()
  const type = (Form.useWatch('type', form) ?? initialType ?? 'Role') as PolicyType
  const save = async () => {
    const v = await form.validateFields()
    try {
      const r = await api.post<DefinitionChangeResult>('/api/policies', { ...v, memberIds: v.type === 'Condition' ? [] : v.memberIds })
      if (r.warnings?.length) message.warning(r.warnings.join(' · '))
      else message.success('Oluşturuldu — bir permission\'a eklenene kadar etkisizdir')
      onDone(r.id); onClose()
    } catch (e) { message.error((e as Error).message) }
  }
  return (
    <Modal open width={720} title="Yeni policy" onCancel={onClose} onOk={save} okText="Oluştur" destroyOnHidden>
      <Form form={form} layout="vertical" onValuesChange={(c) => { if ('type' in c) form.setFieldValue('memberIds', []) }}
        initialValues={{ type: initialType ?? 'Role', tenantId: 1, logic: 'Positive', decisionStrategy: 'Unanimous', mode: 'Enforce', isActive: true, memberIds: [] }}>
        <PolicyFields type={type} editing={false} />
      </Form>
      {type === 'Condition' && <Typography.Text type="secondary">Oluşturduktan sonra kuralları ekleyin. Kuralı olmayan koşul policy'si belirsiz sonuç verir (izin yok).</Typography.Text>}
    </Modal>
  )
}

// ================================ Detay ================================

interface PolicyDetail {
  policy: {
    id: number; code: string; name: string; description?: string; type: PolicyType; logic: PolicyLogic; mode: PolicyMode; isActive: boolean
    decisionStrategy: DecisionStrategy; version: number; tenantId: number; tenant: string; updatedAt?: string; updatedBy?: string
  }
  members: PolicyMemberView[]
  memberIds: number[]
  obligations: { id: number; code: string; fulfillOn: 'Permit' | 'Deny'; order: number; parameters: Record<string, string> }[]
  rules: RuleView[]
  usedBy: { permissions: { id: number; code: string; name: string; application: string; coverage: number }[]; aggregates: { id: number; code: string }[] }
}

interface Pending { title: string; changes: PolicyChangeSet; apply: () => Promise<unknown> }

const memberLink: Partial<Record<PolicyType, string>> = { Role: '/roles', Group: '/groups', User: '/users', Aggregate: '/policies' }

export function PolicyDetailPage() {
  const { id } = useParams()
  const policyId = Number(id)
  const navigate = useNavigate()
  const { data, reload } = useApi<PolicyDetail>(`/api/policies/${policyId}`)
  const types = useApi<ConditionTypeInfo[]>('/api/condition-types').data ?? []
  const shared = useApi<SharedConditionInfo[]>('/api/shared-conditions').data ?? []
  const [pending, setPending] = useState<Pending>()
  const [definition, setDefinition] = useState<PolicyFormValues>()
  const [ruleModal, setRuleModal] = useState<RuleView | 'new' | null>(null)
  const [obligationModal, setObligationModal] = useState(false)
  const [editing, setEditing] = useState(false)
  const { message } = App.useApp()
  if (!data) return <Card loading />
  const p = data.policy
  const inUse = data.usedBy.permissions.length + data.usedBy.aggregates.length > 0
  const remove = async () => { try { await api.del(`/api/policies/${policyId}`); message.success('Silindi'); invalidateOptions('policies'); navigate('/policies') } catch (e) { message.error((e as Error).message) } }

  return (
    <>
      <PageHeader
        title={<><Code>{p.code}</Code> {p.name}</>}
        subtitle={<Flex gap={4} wrap align="center"><PolicyTypeTag type={p.type} /><LogicTag logic={p.logic} /><ModeTag mode={p.mode} />
          {(p.type === 'Condition' || p.type === 'Aggregate') && <StrategyTag strategy={p.decisionStrategy} />}<ActiveTag active={p.isActive} /><TenantTag tenant={p.tenant} /> v{p.version}</Flex>}
        extra={<Flex gap={8}>
          <Button icon={<EditOutlined />} onClick={() => setEditing(true)}>Düzenle</Button>
          {p.type === 'Condition' && <Link to={`/what-if?tab=policy&policyId=${policyId}`}><Button icon={<ExperimentOutlined />}>What-If</Button></Link>}
          <Popconfirm title={`${p.code} silinsin mi?`} description={inUse ? 'Permission veya birleşik policy kullanıyor; önce oradan çıkarın.' : 'Geri alınamaz.'} onConfirm={remove} disabled={inUse}>
            <Button danger icon={<DeleteOutlined />} disabled={inUse} />
          </Popconfirm>
        </Flex>} />
      {p.description && <Typography.Paragraph type="secondary">{p.description}</Typography.Paragraph>}
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={p.type === 'Condition' ? 9 : 12}>
          {p.type !== 'Condition' && (
            <Card size="small" title={`${memberLabel[p.type]} (${data.members.length})`} extra={<Typography.Text type="secondary" style={{ fontSize: 12 }}>{policyTypeMeta[p.type].help}</Typography.Text>}>
              <Flex wrap gap={4}>{data.members.map((m) => {
                const base = memberLink[p.type]
                const tag = <Tag color={policyTypeMeta[p.type].color}>{m.code}{m.name ? ` — ${m.name}` : ''}</Tag>
                return base ? <Link key={m.id} to={`${base}/${m.id}`}>{tag}</Link> : <span key={m.id}>{tag}</span>
              })}</Flex>
              {p.type === 'Aggregate' && <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8, marginBottom: 0 }}>{strategyHelp[p.decisionStrategy]}</Typography.Paragraph>}
            </Card>
          )}
          <Card size="small" style={{ marginTop: p.type === 'Condition' ? 0 : 16 }} title="Kullanıldığı yerler">
            <Table size="small" rowKey="id" pagination={false} dataSource={data.usedBy.permissions}
              locale={{ emptyText: 'Hiçbir permission kullanmıyor — bu policy şu an etkisiz.' }}
              columns={[
                { title: 'Permission', render: (_, x) => <><Link to={`/permissions/${x.id}`}><Code>{x.code}</Code></Link><br /><Typography.Text type="secondary" style={{ fontSize: 12 }}>{x.name}</Typography.Text></> },
                { title: 'Uygulama', dataIndex: 'application', render: (v) => <Tag>{v}</Tag> },
                { title: 'Yetki', dataIndex: 'coverage', width: 70 },
              ]} />
            {data.usedBy.aggregates.length > 0 && <div style={{ marginTop: 8 }}>Birleşik policy'lerde: {data.usedBy.aggregates.map((a) => <Link key={a.id} to={`/policies/${a.id}`}><Tag color="magenta">{a.code}</Tag></Link>)}</div>}
          </Card>
          <Card size="small" style={{ marginTop: 16 }} title="Yükümlülükler (obligation)" extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setObligationModal(true)}>Yükümlülük</Button>}>
            {data.obligations.length === 0 && <Typography.Text type="secondary">Yok</Typography.Text>}
            {data.obligations.map((o) => (
              <Flex key={o.id} justify="space-between" align="center" style={{ marginBottom: 4 }}>
                <span><Tag color="gold">⚑ {o.code}</Tag>{Object.entries(o.parameters).map(([k, v]) => <Tag key={k}>{k}={v}</Tag>)}<Typography.Text type="secondary" style={{ fontSize: 12 }}>{o.fulfillOn === 'Permit' ? 'izin verilince' : 'reddedilince'}</Typography.Text></span>
                <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={async () => {
                  try { await api.del(`/api/policy-obligations/${o.id}`); message.success('Yükümlülük kaldırıldı'); reload() } catch (e) { message.error((e as Error).message) }
                }} />
              </Flex>
            ))}
            <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8, marginBottom: 0 }}>
              Policy izin verdiğinde (Advisory modda koşulu sağlandığında) karar ile PEP'e döner: MASK_FIELDS alanları maskeler, LOG_ACCESS hassas erişim loguna yazar. PEP tanımadığı yükümlülükte erişimi reddeder.
            </Typography.Paragraph>
          </Card>
          <Descriptions size="small" style={{ marginTop: 12 }} column={1}>
            <Descriptions.Item label="Son değişiklik">{fmt(p.updatedAt)} {p.updatedBy && `· ${p.updatedBy}`}</Descriptions.Item>
          </Descriptions>
        </Col>
        {p.type === 'Condition' && (
          <Col xs={24} xl={15}>
            <Card size="small" title={<>Kurallar <StrategyTag strategy={p.decisionStrategy} /></>} extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setRuleModal('new')}>Kural ekle</Button>}>
              {data.rules.length === 0 && <Alert type="warning" showIcon style={{ marginBottom: 8 }} message="Kural yok: bu policy belirsiz sonuç verir (izin yok)." />}
              <Table<RuleView> size="small" rowKey="id" dataSource={data.rules} pagination={false}
                columns={[
                  { title: '#', dataIndex: 'order', width: 50 },
                  { title: 'Kural', width: 220, render: (_, r) => <><Code>{r.code}</Code>{!r.isActive && <Tag>pasif</Tag>}<br /><Typography.Text type="secondary">{r.name}</Typography.Text></> },
                  { title: 'Koşul (sağlanmalı)', dataIndex: 'expression', render: (v) => <Typography.Text style={{ fontSize: 12, wordBreak: 'break-word' }}>{v}</Typography.Text> },
                  { title: 'Sağlanmazsa', dataIndex: 'reasonCode', width: 190, render: (v) => v && <Code>{v}</Code> },
                  {
                    width: 90, render: (_, r) => <Flex gap={2}>
                      <Button size="small" type="text" icon={<EditOutlined />} onClick={() => setRuleModal(r)} />
                      <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={() => setPending({ title: `${p.code} / ${r.code} kuralını sil`, changes: { removedRuleIds: [r.id] }, apply: () => api.del(`/api/rules/${r.id}`) })} />
                    </Flex>,
                  },
                ]} />
              <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8, marginBottom: 0 }}>
                Kural değişiklikleri senaryolarla karar bazında simüle edilir (kim hangi durumda reddedilir). Değer eksikse karar belirsiz olur → izin yok (gateway / servis gerekli context'i göndermeli).
              </Typography.Paragraph>
            </Card>
          </Col>
        )}
      </Row>

      {editing && <PolicyEditModal detail={data} onClose={() => setEditing(false)} onSubmit={(v) => { setEditing(false); setDefinition(v) }} />}
      {definition && (
        <DefinitionChangeModal title={`${p.code} güncelle — erişim etkisi`} onClose={() => setDefinition(undefined)} onDone={() => { reload(); invalidateOptions('policies') }}
          run={(dryRun) => api.put<DefinitionChangeResult>(`/api/policies/${policyId}?dryRun=${dryRun}`, definition)} />
      )}
      {ruleModal && (
        <RuleModal policyId={policyId} rule={ruleModal === 'new' ? undefined : ruleModal} types={types} shared={shared} onClose={() => setRuleModal(null)}
          onSubmit={(draft, body) => {
            const existing = ruleModal === 'new' ? undefined : ruleModal
            setRuleModal(null)
            setPending(existing
              ? { title: `${p.code} / ${existing.code} güncelle`, changes: { replacedRules: [{ ruleId: existing.id, rule: draft }] }, apply: () => api.put(`/api/rules/${existing.id}`, body) }
              : { title: `${p.code}: yeni kural ${draft.code}`, changes: { addedRules: [draft] }, apply: () => api.post(`/api/policies/${policyId}/rules`, body) })
          }} />
      )}
      {obligationModal && <ObligationModal policyId={policyId} onClose={() => setObligationModal(false)} onDone={reload} />}
      {pending && <PolicyChangeModal open title={pending.title} changes={pending.changes} apply={pending.apply} onClose={() => setPending(undefined)} onDone={reload} />}
    </>
  )
}

function PolicyEditModal({ detail, onClose, onSubmit }: { detail: PolicyDetail; onClose: () => void; onSubmit: (v: PolicyFormValues) => void }) {
  const [form] = Form.useForm<PolicyFormValues>()
  const p = detail.policy
  const submit = async () => {
    const v = await form.validateFields()
    onSubmit({ ...v, tenantId: p.tenantId, code: p.code, type: p.type, memberIds: p.type === 'Condition' ? [] : v.memberIds })
  }
  return (
    <Modal open width={720} title={`${p.code} düzenle`} onCancel={onClose} onOk={submit} okText="Etkiyi gör" destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={{ ...p, memberIds: detail.memberIds }}>
        <PolicyFields type={p.type} editing selfId={p.type === 'Aggregate' ? p.id : undefined} />
      </Form>
    </Modal>
  )
}

/** Yükümlülük ekle: tip katalogdan, parametre formu tipten üretilir. */
function ObligationModal({ policyId, onClose, onDone }: { policyId: number; onClose: () => void; onDone: () => void }) {
  const types = useApi<ObligationTypeDef[]>('/api/obligation-types').data ?? []
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const code = Form.useWatch('code', form) as string | undefined
  const type = types.find((t) => t.code === code)
  const save = async () => {
    const v = await form.validateFields()
    try {
      await api.post(`/api/policies/${policyId}/obligations`, { code: v.code, fulfillOn: v.fulfillOn, parameters: v.parameters ?? {} })
      message.success('Yükümlülük eklendi')
      onDone()
      onClose()
    } catch (e) { message.error((e as Error).message) }
  }
  return (
    <Modal open title="Yükümlülük (obligation)" okText="Ekle" onOk={save} onCancel={onClose} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={{ fulfillOn: 'Permit' }}>
        <Form.Item name="code" label="Tip" rules={[{ required: true }]} extra={type?.description}>
          <Select options={types.map((t) => ({ value: t.code, label: `${t.code} — ${t.name}` }))} onChange={() => form.setFieldValue('parameters', {})} />
        </Form.Item>
        {type?.parameters.map((prm) => (
          <Form.Item key={prm.key} name={['parameters', prm.key]} label={prm.label} rules={prm.required ? [{ required: true }] : undefined} extra={prm.hint}>
            <Input />
          </Form.Item>
        ))}
        <Form.Item name="fulfillOn" label="Ne zaman">
          <Radio.Group options={[{ value: 'Permit', label: 'İzin verilince' }, { value: 'Deny', label: 'Reddedilince' }]} optionType="button" />
        </Form.Item>
      </Form>
    </Modal>
  )
}

function RuleModal({ policyId, rule, types, shared, onClose, onSubmit }: {
  policyId: number
  rule?: RuleView
  types: ConditionTypeInfo[]
  shared: SharedConditionInfo[]
  onClose: () => void
  onSubmit: (draft: { policyId: number; code: string; name?: string; order: number; reasonCode?: string; condition: ConditionDraft }, body: object) => void
}) {
  const [form] = Form.useForm()
  const [condition, setCondition] = useState<ConditionDraft>(rule?.condition ? toDraft(rule.condition) : emptyPredicate())
  const allRules = useApi<RuleView[]>('/api/rules').data ?? []
  const submit = async () => {
    const v = await form.validateFields()
    onSubmit({ policyId, code: v.code, name: v.name, order: v.order, reasonCode: v.reasonCode, condition }, { ...v, condition })
  }
  return (
    <Modal open title={rule ? `Kural: ${rule.code}` : 'Yeni kural'} onCancel={onClose} onOk={submit} okText="Etkiyi gör" width={980} destroyOnHidden>
      {!rule && (
        <Flex gap={8} align="center" style={{ marginBottom: 12 }}>
          <Typography.Text type="secondary">Mevcut bir kuraldan kopyala:</Typography.Text>
          <Select style={{ width: 460 }} showSearch optionFilterProp="label" placeholder="Kural seç" allowClear
            options={allRules.map((r) => ({ value: r.id, label: `${r.policy} / ${r.code} — ${r.expression}` }))}
            onChange={(id) => {
              const r = allRules.find((x) => x.id === id)
              if (!r) return
              form.setFieldsValue({ code: r.code, name: r.name, reasonCode: r.reasonCode })
              if (r.condition) setCondition(toDraft(r.condition))
            }} />
        </Flex>
      )}
      <Form form={form} layout="vertical" initialValues={rule ?? { order: 50, isActive: true }}>
        <Row gutter={12}>
          <Col span={6}><Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input disabled={!!rule} placeholder="WORKING_HOURS" /></Form.Item></Col>
          <Col span={14}><Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input placeholder="Mesai saatinde olmalı" /></Form.Item></Col>
          <Col span={4}><Form.Item name="order" label="Sıra"><InputNumber style={{ width: '100%' }} /></Form.Item></Col>
          <Col span={12}><Form.Item name="reasonCode" label="Sağlanmazsa neden kodu"><Input placeholder="OUTSIDE_BUSINESS_HOURS" /></Form.Item></Col>
          <Col span={4}><Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item></Col>
        </Row>
      </Form>
      <Typography.Text strong>Koşul: TRUE → kural sağlandı · FALSE → sağlanmadı · değer eksik → belirsiz</Typography.Text>{' '}
      <Typography.Text type="secondary" style={{ fontSize: 12 }}>önizleme: <Code>{renderDraft(condition)}</Code></Typography.Text>
      <div style={{ marginTop: 6 }}><ConditionBuilder value={condition} onChange={setCondition} types={types} shared={shared} /></div>
      <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8 }}>
        Kullanıcıya özgü değerler (limit, birim, rol) buraya yazılmaz; koşul tipi onları attribute olarak çözer. Banka ağı / mesai gibi ortak tanımlar için "Ortak koşul (@referans)" seçin.
      </Typography.Paragraph>
    </Modal>
  )
}
