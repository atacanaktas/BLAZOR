import { Alert, Button, Card, Col, Empty, Flex, Input, Menu, Row, Select, Switch, Table, Tag, Tooltip, Typography } from 'antd'
import { CheckCircleTwoTone, CloseCircleTwoTone, DesktopOutlined, LockOutlined } from '@ant-design/icons'
import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import type { EntitlementResult, UiEntitlement } from '../api/types'
import { useApi, useOptions } from '../hooks/useApi'
import { AccessKey, DecisionTag, PageHeader } from '../components/common'

/**
 * Nextral masaüstü login olduğunda Nextral-Api'nin (client) motora yaptığı çağrının simülasyonu:
 *   GET /api/v1/entitlements/{user}?application=NEXTRAL   (Authorization: Bearer <nextral-api token'ı>)
 * Bu ekran konsol ucunu kullanır (/api/console/entitlements) ve soranı seçilen client olarak test eder.
 * Menü / ekran / buton resource'ları (URI'siz) bu listeye göre açılır; üst kapalıysa alt da kapalıdır.
 * Asıl güvenlik yine sunucudadır: buton açık olsa bile Anka API'si gateway'de karar ister.
 */
export function NextralPage() {
  const [params] = useSearchParams()
  const users = useOptions('users')
  const clients = useOptions('clients')
  const [user, setUser] = useState(params.get('user') ?? 'ayse.yilmaz')
  const [client, setClient] = useState('nextral-api')
  const [evaluate, setEvaluate] = useState(true)
  const [ip, setIp] = useState('10.1.2.3')
  const { data, loading } = useApi<EntitlementResult>(`/api/console/entitlements/${user}?caller=${client}&application=NEXTRAL&evaluate=${evaluate}&ip=${encodeURIComponent(ip)}`)
  const [screen, setScreen] = useState<string>()

  const ui = useMemo(() => [...(data?.uiResources ?? [])].sort((a, b) => a.order - b.order || a.code.localeCompare(b.code)), [data])
  const childrenOf = (code?: string) => ui.filter((u) => u.parentCode === code)
  const roots = ui.filter((u) => !u.parentCode)
  const screens = ui.filter((u) => u.parentCode && childrenOf(u.code).length + u.scopes.length > 0 && roots.some((r) => r.code === u.parentCode))
  const current = ui.find((u) => u.code === screen) ?? screens.find((s) => s.enabled) ?? screens[0]
  const buttons = current ? childrenOf(current.code) : []
  const extraScopes = current ? current.scopes.filter((s) => s.scope !== 'view') : []
  const viewOf = (u: UiEntitlement) => u.scopes.find((s) => s.scope === 'view') ?? u.scopes[0]
  const actionOf = (u: UiEntitlement) => u.scopes.find((s) => s.scope !== 'view') ?? u.scopes[0]

  return (
    <>
      <PageHeader title="Ekran simülasyonu" subtitle="Login'de dönen yetki listesiyle Nextral menü / ekran / butonlarının açık-kapalı hali (URI'siz resource'lar)." />
      <Card size="small" style={{ marginBottom: 16 }}>
        <Flex gap={12} wrap align="center">
          <span>Kullanıcı: <Select showSearch optionFilterProp="label" style={{ width: 300 }} value={user} onChange={setUser} options={users.map((u) => ({ value: u.code, label: u.label }))} /></span>
          <span>Client: <Select style={{ width: 260 }} value={client} onChange={setClient} options={clients.map((c) => ({ value: c.code, label: c.label }))} /></span>
          <span>IP: <Input style={{ width: 140 }} value={ip} onChange={(e) => setIp(e.target.value)} /></span>
          <span><Switch checked={evaluate} onChange={setEvaluate} /> Koşullu yetkileri "şu an" değerlendir</span>
          {data && <Tag>ETag {data.eTag}</Tag>}
        </Flex>
      </Card>
      <Row gutter={16}>
        <Col xs={24} xl={16}>
          <div className="screen-preview">
            <Flex justify="space-between" align="center" className="screen-preview-header">
              <span><DesktopOutlined /> Nextral Şube — {data?.fullName} ({data?.userName}) · {data?.tenant}</span>
              <span className="screen-preview-badge">Önizleme</span>
            </Flex>
            {loading && !data ? <Card loading /> : ui.length === 0 ? <Empty style={{ padding: 32 }} description="NEXTRAL uygulamasında menü / ekran resource'u yok" /> : (
              <Flex className="screen-preview-body">
                <div className="screen-preview-menu">
                  <Menu mode="inline" selectedKeys={current ? [current.code] : []} defaultOpenKeys={roots.map((r) => r.code)} style={{ borderInlineEnd: 0 }}
                    onClick={(e) => setScreen(e.key)}
                    items={roots.map((m) => ({
                      key: m.code, disabled: !m.enabled, icon: m.enabled ? undefined : <LockOutlined />,
                      label: <Tooltip title={m.reason} placement="right">{m.name}</Tooltip>,
                      children: childrenOf(m.code).map((s) => ({
                        key: s.code, disabled: !s.enabled, icon: s.enabled ? undefined : <LockOutlined />,
                        label: <Tooltip title={s.reason} placement="right">{s.name}</Tooltip>,
                      })),
                    }))} />
                </div>
                <div className="screen-preview-content">
                  {current ? (
                    <>
                      <Typography.Title level={5} style={{ marginTop: 0 }}>{current.name}</Typography.Title>
                      {!current.enabled && <Alert type="warning" showIcon message={current.reason} style={{ marginBottom: 12 }} />}
                      <Flex wrap gap={10}>
                        {buttons.map((b) => {
                          const s = actionOf(b)
                          return (
                            <Tooltip key={b.code} title={<>{b.reason}{s && <div style={{ marginTop: 4, opacity: 0.8 }}>{s.key}: {s.reason}</div>}</>}>
                              <Button size="large" disabled={!b.enabled} icon={b.enabled ? undefined : <LockOutlined />} style={{ minWidth: 150 }}>{b.name}</Button>
                            </Tooltip>
                          )
                        })}
                        {extraScopes.map((s) => (
                          <Tooltip key={s.key} title={s.reason}>
                            <Button size="large" disabled={!current.enabled || !s.enabled} icon={s.enabled ? undefined : <LockOutlined />} style={{ minWidth: 120 }}>{s.scope}</Button>
                          </Tooltip>
                        ))}
                        {buttons.length + extraScopes.length === 0 && <Empty description="Bu ekranda buton yok" />}
                      </Flex>
                    </>
                  ) : <Empty />}
                </div>
              </Flex>
            )}
            <div className="screen-preview-footer">
              {data && <>client: {data.client ?? '—'} · {data.accesses.length} yetki · {ui.filter((u) => u.enabled).length}/{ui.length} UI öğesi açık · model v{data.modelVersion}</>}
            </div>
          </div>
        </Col>
        <Col xs={24} xl={8}>
          <Alert type="info" showIcon message="Güvenlik sunucudadır"
            description="Buton açık olsa bile Nextral, Anka API'sini çağırdığında gateway METHOD + URI ile tekrar karar ister (işlem anındaki tutar, müşteri, saat ile). Bu liste yalnızca kullanıcı deneyimi içindir; model değişmediyse (ETag) istemci önbelleğini kullanır." />
          <Card size="small" title="Özet" style={{ marginTop: 16 }}>
            {data && <Flex vertical gap={4}>
              <span>Açık öğe: <b>{ui.filter((u) => u.enabled).length}</b> / {ui.length}</span>
              <span>Koşul / kanal nedeniyle şu an kapalı: <b>{ui.filter((u) => u.scopes.some((s) => s.runtime && s.runtime.decision !== 'Permit')).length}</b></span>
              <span>Üst menü / ekran kapalı olduğu için kapalı: <b>{ui.filter((u) => !u.enabled && u.reason.includes('Üst')).length}</b></span>
            </Flex>}
          </Card>
        </Col>
        <Col span={24} style={{ marginTop: 16 }}>
          <Card size="small" title="Öğe bazında neden (açık / kapalı)">
            <Table<UiEntitlement> size="small" rowKey="code" pagination={false} dataSource={ui}
              columns={[
                { title: 'Öğe', render: (_, u) => <>{u.parentCode && '└ '}{u.enabled ? <CheckCircleTwoTone twoToneColor="#52c41a" /> : <CloseCircleTwoTone twoToneColor="#ff4d4f" />} {u.name} <Tag>{u.resourceType}</Tag></> },
                { title: 'Yetki', render: (_, u) => <Flex vertical gap={2}>{u.scopes.map((s) => <span key={s.key}><AccessKey value={s.key} /> {s.enabled ? '' : <Tag color="red">kapalı</Tag>}</span>)}</Flex> },
                { title: 'Şu an', render: (_, u) => { const s = viewOf(u); return s?.runtime ? <DecisionTag decision={s.runtime.decision} /> : null } },
                { title: 'Neden', dataIndex: 'reason', render: (v) => <Typography.Text style={{ fontSize: 12 }}>{v}</Typography.Text> },
              ]} />
          </Card>
        </Col>
      </Row>
    </>
  )
}
