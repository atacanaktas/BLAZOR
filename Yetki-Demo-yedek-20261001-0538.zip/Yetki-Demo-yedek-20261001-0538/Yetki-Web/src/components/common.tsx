import { Flex, Tag, Tooltip, Typography } from 'antd'
import {
  CloudServerOutlined,
  ExperimentOutlined,
  GlobalOutlined,
  MobileOutlined,
  NodeIndexOutlined,
  SafetyCertificateOutlined,
  TeamOutlined,
  UserOutlined,
} from '@ant-design/icons'
import type { ReactNode } from 'react'
import dayjs from 'dayjs'
import type { AccessSource, DecisionStrategy, DecisionType, PolicyLogic, PolicyMode, PolicyType, TriState } from '../api/types'

export function PageHeader({ title, subtitle, extra }: { title: ReactNode; subtitle?: ReactNode; extra?: ReactNode }) {
  return (
    <Flex className="page-header" justify="space-between" align="center" gap={16} wrap>
      <div className="page-heading">
        <Typography.Title level={1}>{title}</Typography.Title>
        {subtitle && <div className="page-subtitle">{subtitle}</div>}
      </div>
      {extra && <div className="page-header-actions">{extra}</div>}
    </Flex>
  )
}

/** İkincil açıklamalar, asıl çalışma alanını kaplamadan erişilebilir kalır. */
export function PageGuide({ title = 'Bu sayfa nasıl çalışır?', children }: { title?: string; children: ReactNode }) {
  return <details className="page-guide"><summary>{title}</summary><div className="page-guide-content">{children}</div></details>
}

export function TagSummary({ values, limit = 2 }: { values: string[]; limit?: number }) {
  return <span className="tag-summary">{values.slice(0, limit).map((v) => <Tag key={v} title={v}>{v}</Tag>)}
    {values.length > limit && <Tooltip title={values.slice(limit).join(' · ')}><Tag tabIndex={0}>+{values.length - limit}</Tag></Tooltip>}
    {values.length === 0 && <span className="muted-dash">—</span>}
  </span>
}

export const Code = ({ children }: { children: ReactNode }) => (
  <Typography.Text code style={{ whiteSpace: 'nowrap' }}>{children}</Typography.Text>
)

export const fmt = (d?: string | null) => (d ? dayjs(d).format('DD.MM.YYYY HH:mm:ss') : '—')
export const fmtDate = (d?: string | null) => (d ? dayjs(d).format('DD.MM.YYYY') : '—')

export function ActiveTag({ active }: { active: boolean }) {
  return active ? <Tag color="green">Aktif</Tag> : <Tag>Pasif</Tag>
}

const decisionColor: Record<DecisionType, string> = { Permit: 'green', Deny: 'red', NotApplicable: 'default', Indeterminate: 'orange' }
const decisionLabel: Record<DecisionType, string> = { Permit: 'PERMIT', Deny: 'DENY', NotApplicable: 'ETKİSİZ', Indeterminate: 'INDETERMINATE' }

export function DecisionTag({ decision }: { decision?: string | null }) {
  if (!decision) return <Tag>—</Tag>
  const d = decision as DecisionType
  return <Tag color={decisionColor[d] ?? 'default'}>{decisionLabel[d] ?? decision}</Tag>
}

const triColor: Record<TriState, string> = { True: 'blue', False: 'default', Indeterminate: 'orange' }

export function TriTag({ value }: { value: TriState }) {
  return <Tag color={triColor[value]}>{value === 'True' ? 'TRUE' : value === 'False' ? 'FALSE' : 'BELİRSİZ'}</Tag>
}

/** Rule sonucu: Permit = sağlandı, Deny = sağlanmadı, Indeterminate = belirsiz, NotApplicable = pasif. */
export function RuleResultTag({ result }: { result: DecisionType | string }) {
  if (result === 'Permit') return <Tag color="green">SAĞLANDI</Tag>
  if (result === 'Deny') return <Tag color="red">SAĞLANMADI</Tag>
  if (result === 'Indeterminate') return <Tag color="orange">BELİRSİZ</Tag>
  return <Tag>PASİF</Tag>
}

// ------------------------------------------------------------------ Keycloak kavramları

export const policyTypeMeta: Record<PolicyType, { label: string; color: string; icon: ReactNode; help: string }> = {
  Role: { label: 'Rol', color: 'blue', icon: <SafetyCertificateOutlined />, help: 'Kullanıcı üye rollerden birine (doğrudan veya gruptan) sahipse izin verir.' },
  Group: { label: 'Grup', color: 'purple', icon: <TeamOutlined />, help: 'Kullanıcı üye gruplardan birinin (açık veya kitle kuralıyla) üyesiyse izin verir.' },
  User: { label: 'Kullanıcı', color: 'cyan', icon: <UserOutlined />, help: 'Kullanıcı listede adıyla varsa izin verir (istisnalar için).' },
  Client: { label: 'Kanal (client)', color: 'geekblue', icon: <MobileOutlined />, help: 'İsteği başlatan uygulama (client) listedeyse izin verir.' },
  Condition: { label: 'Koşul (ABAC)', color: 'gold', icon: <ExperimentOutlined />, help: 'Kurallar (saat, IP, tutar, şube...) stratejiye göre sağlanırsa izin verir; eksik değer → belirsiz (izin yok).' },
  Aggregate: { label: 'Birleşik', color: 'magenta', icon: <NodeIndexOutlined />, help: 'Alt policy\'leri karar stratejisiyle birleştirir.' },
}

export function PolicyTypeTag({ type }: { type?: PolicyType }) {
  if (!type) return null
  const m = policyTypeMeta[type]
  return <Tooltip title={m.help}><Tag color={m.color} icon={m.icon}>{m.label}</Tag></Tooltip>
}

export const strategyLabel: Record<DecisionStrategy, string> = {
  Unanimous: 'Unanimous (hepsi)',
  Affirmative: 'Affirmative (en az biri)',
  Consensus: 'Consensus (çoğunluk)',
}

export const strategyHelp: Record<DecisionStrategy, string> = {
  Unanimous: 'Hepsi izin vermeli. Biri reddederse red; biri belirsizse izin yok.',
  Affirmative: 'En az biri izin vermeli. Hiçbiri izin vermez ve belirsiz varsa izin yok.',
  Consensus: 'İzin verenler reddedenlerden (ve belirsizlerden) fazla olmalı; eşitlikte red.',
}

export function StrategyTag({ strategy }: { strategy: DecisionStrategy }) {
  return <Tooltip title={strategyHelp[strategy]}><Tag color="geekblue">{strategyLabel[strategy] ?? strategy}</Tag></Tooltip>
}

export function LogicTag({ logic }: { logic: PolicyLogic }) {
  return logic === 'Negative'
    ? <Tooltip title="Sonuç tersine çevrilir: şartı SAĞLAMIYORSA izin verir."><Tag color="volcano">NEGATİF</Tag></Tooltip>
    : null
}

export function ModeTag({ mode }: { mode: PolicyMode }) {
  if (mode === 'ReportOnly') return <Tooltip title="Değerlendirilir ve kaydedilir ama kararı etkilemez (güvenli devreye alma)."><Tag color="purple">REPORT-ONLY</Tag></Tooltip>
  if (mode === 'Advisory') return <Tooltip title="Kararı etkilemez; koşulu sağlanırsa yükümlülüklerini (ör. maskeleme) karara ekler."><Tag color="cyan">ADVISORY</Tag></Tooltip>
  return <Tag color="blue">ENFORCE</Tag>
}

export const methodColor: Record<string, string> = { GET: 'green', POST: 'orange', PUT: 'blue', PATCH: 'blue', DELETE: 'red', '*': 'purple' }

export function MethodTag({ method }: { method: string }) {
  return <Tag color={methodColor[method] ?? 'default'} style={{ fontFamily: 'monospace' }}>{method}</Tag>
}

export function ResourceTypeTag({ type, color, name }: { type: string; color?: string; name?: string }) {
  return <Tooltip title={name}><Tag color={color ?? 'default'}>{type}</Tag></Tooltip>
}

/** Yetki anahtarı: resource:scope */
export function AccessKey({ value, conditional }: { value: string; conditional?: boolean }) {
  const i = value.lastIndexOf(':')
  return (
    <span style={{ whiteSpace: 'nowrap' }}>
      <Typography.Text code>{i < 0 ? value : <>{value.slice(0, i)}<b>:{value.slice(i + 1)}</b></>}</Typography.Text>
      {conditional && <Tooltip title="Çalışma anında değerlendirilen koşullara bağlı (condition / kanal policy'leri)."><Tag color="gold" style={{ marginLeft: 4 }}>koşullu</Tag></Tooltip>}
    </span>
  )
}

export function SeverityTag({ severity }: { severity: string }) {
  const color = { Critical: 'magenta', High: 'red', Medium: 'orange', Low: 'blue' }[severity] ?? 'default'
  return <Tag color={color}>{severity}</Tag>
}

export function EnforcementTag({ enforcement }: { enforcement: string }) {
  return enforcement === 'Block' ? <Tag color="red">ENGELLE</Tag> : <Tag color="gold">UYAR</Tag>
}

export function TenantTag({ tenant }: { tenant?: string }) {
  if (!tenant) return null
  return <Tag color={tenant === 'ABANK' ? 'blue' : 'cyan'} icon={<GlobalOutlined />}>{tenant}</Tag>
}

export function ExternalSystemIcon() {
  return <CloudServerOutlined />
}

/** Erişimin kaynağı: "Bu kullanıcı bu yetkiyi neden aldı?" (permission ← policy: gerekçe) */
export function SourceList({ sources, conditions }: { sources: AccessSource[]; conditions?: string[] }) {
  return (
    <Flex vertical gap={4}>
      {sources.map((s, i) => (
        <div key={i}>
          <PolicyTypeTag type={s.policyType} />
          <Typography.Text style={{ fontSize: 13 }}>{s.path}</Typography.Text>
        </div>
      ))}
      {conditions && conditions.length > 0 && (
        <div><Tag color="gold">koşul</Tag><Typography.Text type="secondary" style={{ fontSize: 12 }}>{conditions.join(' · ')}</Typography.Text></div>
      )}
    </Flex>
  )
}

export const riskOrder: Record<string, number> = { Low: 1, Medium: 2, High: 3, Critical: 4 }
