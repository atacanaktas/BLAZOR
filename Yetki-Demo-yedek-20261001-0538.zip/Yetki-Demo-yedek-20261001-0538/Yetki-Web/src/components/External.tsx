import { Alert, App, Button, Flex, Form, Input, Modal, Select, Table, Tag, Tooltip, Typography } from 'antd'
import { DeleteOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { api } from '../api/client'
import type { ExternalChange, ExternalDependencyView, ExternalImpactResult, ExternalSystemView } from '../api/types'
import { useApi } from '../hooks/useApi'

const levelColor: Record<string, string> = { READ: 'green', UPDATE: 'orange', CONTROL: 'volcano', ALTER: 'red' }

/** Dış yetki etiketi: RACF · MUS1 (TCICSTRN) · READ */
export function ExternalTag({ system, code, resourceClass, level, previousLevel }: {
  system: string; code: string; resourceClass?: string; level?: string; previousLevel?: string
}) {
  const lvl = level?.toUpperCase()
  return (
    <Tag color={system === 'RACF' ? 'geekblue' : 'purple'} style={{ marginInlineEnd: 4 }}>
      {system}:{code}{resourceClass && <span style={{ opacity: 0.7 }}> ({resourceClass})</span>}
      {lvl && <b style={{ marginLeft: 4, color: levelColor[lvl] === 'green' ? '#389e0d' : '#d4380d' }}>{previousLevel ? `${previousLevel.toUpperCase()}→` : ''}{lvl}</b>}
    </Tag>
  )
}

function ChangeList({ items, kind }: { items: ExternalChange[]; kind: 'GRANT' | 'MODIFY' | 'REVOKE' }) {
  const color = kind === 'GRANT' ? 'green' : kind === 'MODIFY' ? 'gold' : 'volcano'
  return (
    <>
      {items.map((c) => (
        <div key={`${kind}${c.system}${c.code}`}>
          <Tooltip title={c.reasons.map((r, i) => <div key={i}>{r}</div>)}>
            <Tag color={color}>{kind}</Tag><ExternalTag system={c.system} code={c.code} resourceClass={c.resourceClass} level={c.level} previousLevel={kind === 'MODIFY' ? c.previousLevel : undefined} />
          </Tooltip>
        </div>
      ))}
    </>
  )
}

/** Dış bağımlılık değişikliğinin etkisi: kimde RACF/LDAP'ta ne açılır / değişir / kapanır. */
export function ExternalImpactView({ impact }: { impact: ExternalImpactResult }) {
  return (
    <Flex vertical gap={8}>
      <Alert type={impact.affectedUserCount ? 'warning' : 'info'} showIcon message={impact.summary}
        description={impact.dryRun ? 'Önizleme: henüz uygulanmadı. Uygulanınca etkilenen kullanıcılar için mutabakat (provisioning) tetiklenir.' : 'Uygulandı; mutabakat olayı outbox\'a yazıldı.'} />
      {impact.users.length > 0 && (
        <Table size="small" rowKey="userId" dataSource={impact.users} pagination={{ pageSize: 8 }}
          columns={[
            { title: 'Kullanıcı', dataIndex: 'userName', width: 150 },
            { title: 'External System', render: (_, u) => <><ChangeList items={u.grants} kind="GRANT" /><ChangeList items={u.modifies} kind="MODIFY" /><ChangeList items={u.revokes} kind="REVOKE" /></> },
          ]} />
      )}
    </Flex>
  )
}

/** Bağımlılığın sahibi: resource (tüm scope'ları) veya resource:scope (tek yetki). */
export type DependencyOwner = { resourceId?: number; resourceScopeId?: number; label: string }

/**
 * Katalog öğesine (API / endpoint / permission) dış bağımlılık ekler: önce etki (dryRun), sonra uygula.
 * Seviye boşsa scope'tan türetilir (view → READ, create/update/close → UPDATE).
 */
export function ExternalDependencyModal({ owner, onClose, onDone }: { owner: DependencyOwner; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const systems = useApi<ExternalSystemView[]>('/api/external/systems')
  const [impact, setImpact] = useState<ExternalImpactResult>()
  const [busy, setBusy] = useState(false)
  const extId = Form.useWatch('externalPermissionId', form) as number | undefined
  const selectedSystem = (systems.data ?? []).find((s) => s.permissions.some((p) => p.id === extId))
  const body = async () => ({ ...(await form.validateFields()), resourceId: owner.resourceId, resourceScopeId: owner.resourceScopeId })
  const run = async (dryRun: boolean) => {
    setBusy(true)
    try {
      const r = await api.post<ExternalImpactResult>(`/api/external/dependencies?dryRun=${dryRun}`, await body())
      if (dryRun) setImpact(r)
      else {
        message.success(r.summary)
        onDone()
        onClose()
      }
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setBusy(false)
    }
  }
  return (
    <Modal open width={820} title={`${owner.label} → External Dependency`} onCancel={onClose} destroyOnHidden
      footer={<Flex gap={8} justify="end">
        <Button onClick={onClose}>Vazgeç</Button>
        <Button loading={busy} onClick={() => run(true)}>Etkiyi gör</Button>
        <Button type="primary" loading={busy} disabled={!impact} onClick={() => run(false)}>Uygula</Button>
      </Flex>}>
      <Typography.Paragraph type="secondary" style={{ fontSize: 12 }}>
        Kimlik yayılımı: kullanıcı kendi mainframe token'ıyla CICS'i çağırır; CICS <b>çağıran kullanıcının</b> RACF yetkisini arar.
        Bu yetkiye (etkin olarak) sahip her kullanıcı için dış sistemde karşılık gelen yetki açılır; yetki kaybedilince kapanır.
      </Typography.Paragraph>
      <Form form={form} layout="vertical" onValuesChange={() => setImpact(undefined)}>
        <Form.Item name="externalPermissionId" label="External Permission (RACF transaction / dataset / application, LDAP group)" rules={[{ required: true }]}>
          <Select showSearch optionFilterProp="label"
            options={(systems.data ?? []).map((s) => ({
              label: `${s.code} — ${s.name}`,
              options: s.permissions.map((p) => ({ value: p.id, label: `${s.code}:${p.code}${p.resourceClass ? ` (${p.resourceClass})` : ''} — ${p.name ?? ''}` })),
            }))} />
        </Form.Item>
        {selectedSystem?.hasAccessLevels !== false && (
          <Form.Item name="accessLevel" label="Access Level" extra="Boş: scope'tan türetilir (view/read/export → READ, diğerleri → UPDATE).">
            <Select allowClear placeholder="Varsayılan (scope'tan)" options={['Read', 'Update', 'Control', 'Alter'].map((l) => ({ value: l, label: l.toUpperCase() }))} />
          </Form.Item>
        )}
        <Form.Item name="note" label="Not"><Input placeholder="ör. MUS1 transaction'ı müşteri kaydını okur" /></Form.Item>
      </Form>
      {impact && <ExternalImpactView impact={impact} />}
    </Modal>
  )
}

/** Bağımlılık listesi (kaldırmadan önce etki gösterilir). */
export function ExternalDependencyList({ deps, onChanged, showOwner }: { deps: ExternalDependencyView[]; onChanged: () => void; showOwner?: boolean }) {
  const { message, modal } = App.useApp()
  const remove = async (d: ExternalDependencyView) => {
    try {
      const preview = await api.del<ExternalImpactResult>(`/api/external/dependencies/${d.id}?dryRun=true`)
      modal.confirm({
        width: 820, title: `${d.owner} → ${d.system}:${d.code} bağımlılığını kaldır`, content: <ExternalImpactView impact={preview} />, okText: 'Kaldır', okButtonProps: { danger: true },
        onOk: async () => {
          const r = await api.del<ExternalImpactResult>(`/api/external/dependencies/${d.id}`)
          message.success(r.summary)
          onChanged()
        },
      })
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  if (deps.length === 0) return <Typography.Text type="secondary">—</Typography.Text>
  return (
    <Flex wrap gap={2}>
      {deps.map((d) => (
        <span key={d.id}>
          <Tooltip title={<>{d.name}{d.note && <div>{d.note}</div>}{showOwner && <div>← {d.owner}</div>}</>}>
            <span><ExternalTag system={d.system} code={d.code} resourceClass={d.resourceClass} level={d.level} />
              {!d.level && d.hasAccessLevels && <Typography.Text type="secondary" style={{ fontSize: 11, marginRight: 4 }}>seviye: scope'tan</Typography.Text>}</span>
          </Tooltip>
          <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={() => remove(d)} />
        </span>
      ))}
    </Flex>
  )
}

export function AddDependencyButton({ onClick, label = 'dış bağımlılık' }: { onClick: () => void; label?: string }) {
  return <Button size="small" type="dashed" icon={<PlusOutlined />} onClick={onClick}>{label}</Button>
}

