import { useEffect, useState } from 'react'
import { api } from '../api/client'
import type { CatalogTreeTenant } from '../api/types'

let treePromise: Promise<CatalogTreeTenant[]> | undefined

/** Yetki tanımları ağacı: Tenant → Uygulama (resource server) → resource listesi (gruplama istemcide: URL / üst-alt). */
export function useCatalogTree(refresh = 0) {
  const [tree, setTree] = useState<CatalogTreeTenant[]>([])
  useEffect(() => {
    if (refresh > 0 || !treePromise) treePromise = api.get<CatalogTreeTenant[]>('/api/catalog/tree').catch(() => [])
    let cancelled = false
    treePromise.then((t) => !cancelled && setTree(t))
    return () => {
      cancelled = true
    }
  }, [refresh])
  return tree
}

export function invalidateCatalogTree() {
  treePromise = undefined
}
