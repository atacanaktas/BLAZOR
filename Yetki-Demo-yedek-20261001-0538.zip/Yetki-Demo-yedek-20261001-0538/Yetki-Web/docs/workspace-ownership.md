# Workspace ownership map

This is a navigation and responsibility classification, not an access-control
change. Existing insert/update/delete and assignment controls remain available.
Owner labels describe the intended operating model, not a live HR connection.
The identity provider still uses LocalDb. No approval workflow or team-specific
page permissions have been introduced.

| Area | Existing functions | Intended owner |
| --- | --- | --- |
| HR & Identity | Users, employment attributes, User–Role assignments, organization memberships, Role directory, Tenants / organization | HR / Identity |
| Catalogs & Controls | Platforms, Domains, Modules, Submodules, Screens / UI, APIs / Endpoints, Clients, Service Account links, Permission definitions, external dependencies, SoD definitions, Condition Types | Application / integration / control owners |
| Access Management | Endpoint / UI–Permission mappings, Role–Permission mappings, Client Scope, access Groups / membership criteria, direct Permission exceptions, Policies / Rules / targets, Shared Conditions, What-If | Authorization team |
| Monitoring & Reports | Current entitlements and sources, Role holders, protection definitions, SoD violations and definitions, external drift, audit evidence, event delivery | Authorization team across all domains |
| Demos & Prototypes | Nextral, SDK/service demo | Demo / design evaluation |

## Shared screens

Role detail contains directory data, holders and Role–Permission editing.
API/UI detail contains inventory and Permission mapping. Client detail contains
catalog information and access Scope. External Systems contains definitions,
dependency chains and drift. SoD contains control definitions and violations.
These are intentionally not duplicated. Access Bindings and Report Center link
to the existing screens. The ownership context shows the canonical section;
the task descriptions distinguish editing relationships from defining source data.

SoD defaults to Control Definitions; /sod?tab=v opens Violations and /sod?tab=r
opens definitions. Search parameters follow tab changes and browser history.

## Catalog examples already represented

- Resource / action and Permission identifiers.
- Endpoint HTTP method, path, operation and API relationship.
- UI hierarchy and Screen/Button definitions.
- Calling Client and Service Account identity.
- API / Endpoint / Permission dependencies on external permissions.
- Transitive external permission requirements and access levels.
- Incompatible Role / Permission combinations, severity and enforcement.
- Available Condition Types and their parameter contracts.

Application ownership, data-classification catalogs, approval authorities and
mandatory control baselines could be future catalog areas; this change does not
claim they are implemented.

## Reporting scope and limits

Report Center covers every current business area through existing list/detail,
analysis and audit views; it is a directory of existing reports, not a new data
warehouse or export engine. Current access depends on request context and Policy
evaluation; a Permission grant alone is not unconditional PERMIT.

Authorization decision audit stores PermissionSources, evaluation steps, policy
and rule outcomes, evidence and model version. Historical analysis is limited to
records actually retained, including their redaction and detail settings.
Current model evaluation cannot reconstruct an arbitrary historical snapshot.
The existing Audit screen is limited to its existing query/filter behavior.

A future guarantee that *every* operation can be reported requires an explicit
audit coverage review (including catalog creates, upstream HR changes and source
history), retention/versioning and historical query design. Regrouping does not
add missing audit records, historical HR snapshots, exports or approval flows.

API inventory and endpoint management are accessed through /catalog (API selection: /catalog?api={id}). The separate /apis and /apis/:id frontend pages and their list-only backend GET endpoints have been removed. Shared API detail/create and Endpoint mutations remain for Catalog.
