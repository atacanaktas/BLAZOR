# Yetki-Web — Proje Notları (React yönetim paneli)

> Bu dosya projeye daha sonra dönüldüğünde (insan veya AI asistan) genel resmi, detayları, dikkat edilmesi gerekenleri ve TODO'ları hızlıca hatırlamak içindir.
> Backend notları (model, karar akışı, API uçları, örnek veri senaryoları, yetki.db / yedek.db): `../Yetki-Engine/PROJE-NOTLARI.md`
> **2026-09-25:** Panel yeni hibrit modele göre baştan yazıldı. Önceki sürüm: `../Yetki-Demo-yedek-2026-09-25.zip`.

---

## 1. Özet

Yetki yönetim ekibinin kullandığı kurumsal admin paneli. **Frontend hiçbir yetki kararı üretmez**; her şey Yetki Motoru API'sinden gelir.
Model (2026-09-25'ten itibaren "Hybrid Authorization Model" dokümanıyla hizalı): **1 Tenant → 2 Client → 3 Resource + Action → 4 RBAC (User → Role/Group → Permission) → 5 Policy → Rule** (rule = sağlanması gereken tek koşul). Menü, modelin sorularına göre gruplanmıştır:

| Menü grubu | Ekranlar |
|---|---|
| Tenant & Kimlik | Tenant'lar (A Bankası → B İştiraki; kendi/miras ↑ uygulama, client, policy, rol; birim ağacı; yeni tenant + birim), Kullanıcılar (yeni kullanıcı) |
| **Kim?** (RBAC) | Roller, Gruplar (kitle kuralı) |
| **Ne / Nerede?** (Katalog = Resource) | Katalog ağacı (uygulama tenant'a ait; action'ı olan düğüm = RESOURCE), Permission'lar (Resource + Action), API & Endpoint, Client'lar (OAuth; tenant'a kayıtlı) |
| **Ne zaman / Nasıl?** (Policy) | Policy'ler (hedef/istisna + karar stratejisi + rule'lar = sağlanması gereken koşullar), Ortak Koşullar, Koşul & Kriter Tipleri |
| Analiz & Test | Yetki Testi, **Nextral Ekran Simülasyonu**, What-If, SDK/Mikroservis Demo |
| Yönetişim & İzleme | SoD & İhlaller, Dış Sistemler (RACF/LDAP), Event & Provisioning, Audit |

Stack: React 19, TypeScript 6, Vite 8, **Ant Design 6** (`destroyOnHidden`, `Flex vertical`, Drawer `size`), react-router-dom 7, dayjs (tr). Lint: oxlint.

---

## 2. Çalıştırma

```bash
npm install
npm run dev        # http://localhost:5180 (strictPort)
npm run build      # tsc -b + vite build
npm run lint       # oxlint
```
Önkoşul: API `http://localhost:5100`. SDK Demo için örnek mikroservis `http://localhost:5200` (`Yetki-Engine/samples/Anka.NakitService`).
Node **20.19+ / 22.12+** gerekir (Vite 8). `.env.local`: `VITE_API_URL`, `VITE_SAMPLE_APP_URL`.
Port değişirse API `appsettings.json → Cors:Origins` ve örnek servis CORS listesi güncellenmeli.

---

## 3. Klasör yapısı

```
src/
├─ main.tsx / App.tsx            ConfigProvider (tr_TR, tema), rotalar
├─ api/client.ts                 fetch sarmalayıcı, ApiError (ProblemDetails), X-Actor, örnek servis çağrısı (X-User, X-Client-Id)
├─ api/types.ts                  API sözleşme tipleri (karar, entitlement, katalog, change set'ler, etki sonuçları)
├─ hooks/useApi.ts               useApi(path) · useOptions(kind) → GET /api/options/{kind} (önbellekli) · invalidateOptions
├─ layout/AppLayout.tsx          Menü, model versiyonu, bekleyen event rozeti, aktör seçimi
├─ components/
│  ├─ External.tsx               ExternalTag, ExternalImpactView, ExternalDependencyModal (etki → uygula), ExternalDependencyList (silmeden önce etki)
│  ├─ common.tsx                 PageHeader, Code, DecisionTag, RuleResultTag (sağlandı/sağlanmadı), ModeTag, TargetTag, TenantTag, SourceList, SeverityTag, algorithmLabel...
│  ├─ Catalog.tsx                useCatalogTree + TargetPicker (Tümü / Uygulama / Katalog düğümü / Permission)
│  ├─ GroupFilterEditor.tsx      Kitle kuralı editörü (VE/VEYA/Hariç; değer seçicileri kriter tipine göre)
│  ├─ ConditionBuilder.tsx       Policy condition ağacı (Predicate/NOT/AND/OR/@ortak koşul)
│  ├─ DecisionView.tsx           Açıklanabilir karar: numaralı adımlar (stepTitle: 1 Tenant … 5 Policy), RBAC kaynağı, policy → rule sonuçları, hariç/ReportOnly
│  ├─ ChangeModal / ConfirmChangeModal / ImpactView   RBAC değişikliği: seç → What-If → uygula
│  └─ PolicyImpact.tsx           Policy değişikliği etkisi (senaryolar + client), PolicyChangeModal
└─ pages/
   ├─ DashboardPage, TenantsPage, UsersPages (liste+detay), RolesPages, GroupsPages
   ├─ CatalogPages (Katalog ağacı + düğüm paneli, Permission liste/detay, API liste/detay, Client'lar, manifest içe aktarma)
   ├─ PoliciesPages (liste + detay: hedefler, kapsam, rule'lar), SharedConditionsPage, ConditionTypesPage
   ├─ EvaluatePage ({tenant, client, subject, resource, action, context}; hazır senaryolar + AuthZEN karşılığı), NextralPage, WhatIfPage, SdkDemoPage
   └─ GovernancePages (SoD, Dış sistemler: mutabakat/baseline/dış yetki/zincir, Event & Provisioning, Audit)
```

---

## 4. Tasarım prensipleri (bozulmamalı)

1. **Frontend karar vermez.** Nextral simülasyonu bile `/api/v1/entitlements` sonucunu gösterir.
2. **Önce etkiyi gör, sonra uygula.** Yetkiyi değiştiren her işlem önizlemeden geçer:
   - RBAC (rol/permission/birim/grup üyeliği/grup yetkisi/grup kuralı/kullanıcı bilgisi/rol ayarı): `ChangeModal` / `ConfirmChangeModal` → `/api/simulation/changes` → kazanır/kaybeder/korunur, SoD (Block ise buton pasif), RACF/LDAP.
   - Policy (hedef/istisna ekle-çıkar, mod/algoritma/aktiflik, rule ekle/düzenle/sil, ortak koşul): `PolicyChangeModal` → `/api/simulation/policy-impact` (varsayılan 3 senaryo: Nextral'den tipik, yüksek tutar, saha tableti/dış IP; karar anı bir sonraki iş günü 11:00).
3. **Açıklanabilirlik görünür olmalı:** yetki listelerinde kaynak yolu (`SourceList`), grup üyeliğinde "neden üye / neden hariç", policy'de "← Düğüm ANKA/NAKIT (miras)", kararda adım adım akış.
4. **Katalog ağacı ana gezinme aracıdır** (200+ API): permission ve API listeleri arama + uygulama filtresi ile; hedef seçimi `TargetPicker` ile.
5. Seçim listeleri tek uçtan: `/api/options/{kind}`; yeni kayıt sonrası `invalidateOptions(...)`.
6. Seçim değişince taslak state'i effect içinde sıfırlamak yerine bileşen `key` ile yeniden kurulur (What-If sekmeleri); sunucu verisinden türeyen düzenlenebilir state "`edited ?? sunucuVerisi`" kalıbıyla tutulur (grup kuralları).

---

## 5. Ekran notları

- **Gruplar / detay:** Kural editörü + "Canlı önizleme" (`POST /api/groups/preview`: kaydetmeden üyeler ve hariç kalanlar) + "Etkiyi gör ve kaydet" (`PUT /api/groups/{id}/filters`). Grup rol ve permission verebilir; açık üyeler süreli olabilir.
- **Katalog ağacı:** Uygulama → Domain → Modül → Alt modül → **API → Endpoint** (endpoint satırında method, path ve eşlendiği permission; eşlenmemiş kırmızı). API seçilince (`/catalog?api={id}`) sağda API paneli: kırılım, audience, endpoint ekle/sil, endpoint → permission eşleme (alt modülün kendi action'ları üstte). Alt modül panelinde "API ekle". Seçimin yolu ağaçta otomatik açılır; arama API kodu ve endpoint path'inde de çalışır. API yönetimi yalnızca Catalog içindeki ortak panelden yapılır; ayrı API liste/detay sayfaları kaldırılmıştır.
- **Katalog:** Uygulamalar sahibi tenant etiketiyle; action'ı olan düğüm "RESOURCE" etiketi + action listesi + örnek istek gösterir. "Action ekle" = Resource + Action → permission. Yeni uygulama formunda sahip tenant zorunlu. Düğüm paneli sekmeleri: Policy'ler (doğrudan / miras / hariç / alt düğümlere), Action / permission, API (endpoint → permission, eşlenmemiş kırmızı), Ekran/buton, Client'lar, Alt düğümler. "Servis manifesti içe aktar" örnek servisten `/.well-known/yetki-manifest` çekebilir.
- **Permission detayı:** tenant bazında uygulanan/hariç policy'ler, veren roller/gruplar, hangi client'lardan kullanılabildiği, endpoint ve UI bağlantıları, **dış sistem gereksinimi** (hesaplanmış: RACF/LDAP yetkisi + seviye + neden; doğrudan bağımlılık ekle), "kimde var, neden?".
- **Dış sistem (RACF/LDAP):** API paneli → API seviyesi bağımlılık + endpoint başına bağımlılık (ekle: dış yetki + seviye/boş = action'dan → Etkiyi gör → Uygula; sil: önce etki). Ağaçta endpoint/API yanında `RACF:MUS1` gibi özet. Kullanıcı detayı → "Dış sistem" sekmesi: olması gereken ↔ açık olan (AÇILACAK / SEVİYE DEĞİŞECEK / KAPANACAK / SENKRON, nedenleriyle) + "Mutabakat yap". Dış Sistemler sayfası: drift raporu, tümünü mutabakat, baseline, dış yetki/zincir yönetimi. Etki analizlerinde (ImpactView) GRANT / MODIFY / REVOKE ve nedenleri.
- **Client'lar:** tip Aracı (gateway/BFF) seçilebilir (isteği başlatmaz, via'da doğrulanır; kapsamı = iletebileceği API'ler); kayıtlı tenant (sonradan değişmez; alt tenant'lar da kullanır) + resource kapsamı = hedef + action filtresi (ör. mobil tablet ANKA/MUSTERI `[read]`).
- **Policy detayı:** Mod (Enforce/ReportOnly), karar stratejisi (Tüm rule'lar sağlanmalı / En az biri yeterli), hedefler (TargetTag; kapatınca etki önizlemesi), kapsam, rule'lar: koşul (sağlanmalı) + sağlanmazsa neden kodu; Effect alanı YOK. Mevcut rule'dan kopyalama ile yeni rule. **Kanal (client) hedefi** kartı (SADECE / HARİÇ client; ekle/kaldır etki önizlemeli, aracılar listelenmez) ve **Yükümlülükler** kartı (tip `/api/obligation-types`'tan, parametre formu tipten; izin/ret'te).
- **Yetki Testi:** Varsayılan mod **Resource + Action** (resource listesi `GET /api/options/resources`, action'lar o düğümün permission'larından); Permission ve Endpoint modları da var. Tenant, client, subject; kayıt özellikleri (Tenant, BranchCode, CustomerId → `resource.properties`); bağlam; simülasyon (karar anı). İstek hem standart hem AuthZEN biçiminde gösterilir. Hazır senaryo grupları: **Doküman örneği** (Ahmet · para çekme 75.000 / limit / saat / IP / izin / RBAC yok), Tenant·client·resource (TENANT_MISMATCH, RESOURCE_TENANT_MISMATCH, CLIENT_TENANT_MISMATCH, RESOURCE_NOT_IN_TENANT), RBAC·grup·veri kapsamı, diğer biçimler. Boş veritabanında bu kullanıcılar yoktur. Aracı zinciri (via) alanı; "Kanal · aracı · yükümlülük" senaryo grubu (Nextral / Mobil / Anka Web aynı müşteri endpoint'i, gateway üzerinden, gateway client olarak → CLIENT_IS_INTERMEDIARY). Karar ekranında orijinal client + aracı zinciri ve yükümlülükler kartı.
- **SDK Demo:** aracı (X-Via) seçimi; "Çekim sorgula" + client `anka-web` → SDK yanıtı maskeler (hesapNo / musteriTckn), Nextral'da açık döner.
- **Nextral Ekran Simülasyonu:** WinForms benzeri pencere; sol menü ekranlar/menüler, sağda butonlar; kilitli öğenin nedeni tooltip'te; "şu an" kararı (mesai dışı vb.) opsiyonel.
- **What-If:** Kullanıcı (rol/birim/unvan/izin), Rol (permission ekle/çıkar, pasifleştir), Grup (kural, yetki, üye), Policy (A hedefler, B rule'lar, C parametre, D taslak rule + senaryolar), SoD taslağı. Derin link: `?tab=user&userId=`, `?tab=role&roleId=`, `?tab=group&groupId=`, `?tab=policy&policyId=`.

---

## 6. Dikkat edilmesi gerekenler

- Gerçek kararda zaman motorun saatidir: mesai dışında nakit işlemleri reddedilir — demo için "Simülasyon" ile karar anı seçin veya What-If senaryolarını kullanın.
- `KURUMSAL_AG` policy'si IP ister; Yetki Testi ve Nextral ekranı varsayılan `10.1.2.3` gönderir.
- Aktör (X-Actor) ve örnek servisteki X-User/X-Client-Id prototip kolaylığıdır; üretimde token.
- API verisi kalıcıdır (`Yetki-Engine/src/Yetki.Api/yetki.db`). Boş veritabanında Genel Bakış bir uyarı gösterir; sıfırdan başlamak için Tenant'lar → Kullanıcılar → Katalog (uygulama: sahip tenant) → Roller → Client → Policy sırası izlenir. Örnek veriye dönmek: API kapalıyken `yedek.db` → `yetki.db` kopyala (yanında `yetki.db-wal/-shm` varsa sil).
- Lint: 16 `only-export-components` uyarısı (sayfa dosyaları yardımcı bileşen export ediyor) ve `useApi` içindeki veri çekme effect'i bilinçli.

---

## 7. TODO

- [ ] Kimlik doğrulama (OIDC/MSAL), aktörün token'dan gelmesi, panelin kendi yetkileri (buton görünürlüğü entitlement ile)
- [ ] Büyük listelerde sunucu tarafı sayfalama (kullanıcı/permission 10K+), katalog ağacında tembel yükleme
- [ ] Yetki gözden geçirme (recertification) ekranları; değişiklik talebi + 4-göz onay akışı
- [ ] Katalog düğümü taşıma/yeniden adlandırma sihirbazı (etki önizlemeli)
- [ ] Policy/ortak koşul versiyon geçmişi ve fark görünümü
- [ ] Kod bölme (tek chunk ~1.4 MB, antd)
