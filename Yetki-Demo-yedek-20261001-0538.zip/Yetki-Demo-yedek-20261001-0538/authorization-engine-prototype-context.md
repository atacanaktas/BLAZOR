# Authorization Engine / Yetki Motoru – Prototype Context

## 1. Amaç

Kurumsal/banka ölçeğinde kullanılabilecek, mevcut yetki sisteminin kademeli olarak taşınmasına izin veren bir **Authorization Platform / Yetki Motoru prototipi** oluşturulacaktır.

Prototipin amacı bütün mevcut sistemi ilk günden yeniden tasarlamak değildir. Mevcut yapı mümkün olduğunca **smooth migration** ile sisteme alınmalı; ileride yetki/grup/rol sadeleştirmeleri zamana yayılarak yapılabilmelidir.

Mevcut ölçekte yaklaşık:
- 4.000 grup
- 700.000 grup/yetki ilişkisi
- Açılış saatleri civarında yaklaşık 20–21 bin kullanıcının kısa zaman aralığında login olması

Bu nedenle tasarım sadece fonksiyonel değil, performans ve ölçek açısından da düşünülmelidir.

---

## 2. Proje Yapısı

Prototip iki ayrı uygulamadan oluşacaktır.

### Backend
- **.NET Web API**
- Tüm authorization/business logic backend'de bulunacaktır.
- Frontend hiçbir authorization kararını kendi başına üretmemelidir.
- REST API üzerinden yönetim ve authorization endpoint'leri sunacaktır.

### Frontend
- Tercihen **React**
- Sade, kurumsal bir admin dashboard olacaktır.
- Yetki yönetim ekibi tarafından kullanılacaktır.
- API dışında doğrudan DB erişimi olmayacaktır.

Örnek ekranlar:
- Kullanıcı arama/detay
- Kullanıcının effective yetkileri
- Kullanıcının rolleri ve grupları
- Rol yönetimi
- Permission/yetki yönetimi
- Grup yönetimi
- Policy yönetimi
- Rule yönetimi
- SoD / conflict rule yönetimi
- What-if / simulation ekranları
- İhlal/uyarı ekranları
- Audit görüntüleme
- İleride provisioning/event sonuçları

UI mümkün olduğunca sade tutulacaktır: sol menü + liste/detay ekranları + gerektiğinde modal/drawer.

---

## 3. Temel Tasarım Yaklaşımı

Sistem saf RBAC veya saf policy-based olmayacaktır.

**Hibrit yaklaşım:**

> RBAC + Policy/Rule based authorization

### RBAC ne için kullanılacak?
"Kullanıcı normal şartlarda ne yapabilir?"

### Policy ne için kullanılacak?
"Bu yetki bu işlem bağlamında şu anda kullanılabilir mi?"

Örnek:

User -> Role -> Permission -> Policy -> Rules

Bir kullanıcının `CASH_WITHDRAW` permission'ı olabilir ancak:
- işlem tutarı <= 100.000 TL,
- mesai saatleri içinde,
- uygun kanal/şube üzerinden

gibi koşullar ayrıca değerlendirilir.

Statik ekran/menu gibi permission'lar login sırasında topluca alınabilir. Tutar, saat, kanal, şube vb. context-dependent kararlar işlem anında authorization engine tarafından değerlendirilmelidir.

---

## 4. Domain Kavramları

### User
Sistemde yetkilendirilen kişi.

### Organization Unit
Şube, genel müdürlük birimi vb. organizasyon yapısı.

Örnek:
- 101 Şube
- 928 Şube
- Genel Müdürlük / Krediler

### Permission
Atomik yetki.

Örnek:
- `TERM_DEPOSIT_VIEW`
- `TERM_DEPOSIT_UPDATE`
- `TERM_DEPOSIT_CLOSE`
- `CREDIT_CREATE`
- `CREDIT_APPROVE`

### Role
Permission'ların iş fonksiyonuna göre paketlenmesi.

Örnek:
- Vadeli Hesap Asistanı
- Gişe Yetkilisi
- Kredi Yönetmeni

Rol temel yönetim mekanizmasıdır.

Rol mirası/hiyerarşisi ilk prototip için zorunlu değildir. Organizasyon hiyerarşisi otomatik olarak authorization hiyerarşisine çevrilmemelidir.

### Group
Grup ana authorization modeli değil, **esnek kompozisyon/kitle tanımlama aracı** olacaktır.

Grup aşağıdakileri birlikte içerebilir:
- User
- Role
- Organization Unit

Örnek:

> Bütün Gişe Yetkilileri + 101 Şubede çalışan herkes + Ahmet

Grup içinde grup (nested group) ilk aşamada desteklenmemelidir. Derin hiyerarşilerden kaçınılmalıdır.

Ana kullanım mümkün olduğunca Role üzerinden olmalı; Group istisnai/esnek senaryolar için kullanılmalıdır.

---

## 5. Policy ve Rule

Policy ve Rule ayrı kavramlar olarak modellenebilir.

### Policy
Bir permission'ın hangi koşullarda kullanılabileceğini tanımlayan karar bütünü.

### Rule
Policy içindeki küçük ve tekrar kullanılabilir koşul.

Örnek rule'lar:
- BUSINESS_HOURS
- USER_TRANSACTION_LIMIT
- BRANCH_MATCH
- CHANNEL_IS_CASH_DESK
- IP_RANGE_ALLOWED
- USER_NOT_ON_LEAVE

Örnek:

`CashWithdrawalPolicy`

Rules:
- BusinessHoursRule
- CashDeskChannelRule
- UserLimitRule

Rule'lar mümkün olduğunca aynı seviyede kompoze edilmelidir. Derin `policy -> sub-policy -> sub-policy` inheritance zincirlerinden kaçınılmalıdır.

### Global ve Domain Rule

İki tip rule desteklenebilmelidir:

**Global/shared rule**
- Mesai saati
- IP aralığı
- Kanal
- Şube
- Genel kullanıcı durumu

**Domain-specific rule**
- Kredilere özel limit kontrolü
- Vadeli hesaba özel business condition

Domain ekiplerinin özel ihtiyaçları engellenmemelidir; ancak ortak ihtiyaçlar tekrar tekrar domain rule olarak yazılmamalıdır.

---

## 6. Soft Recommendation vs Hard Authorization

İki kavram kesin olarak ayrılmalıdır.

### Hard / Deterministic
Gerçek authorization kararı.

Örnek:
- ALLOW
- DENY
- Limit exceeded
- Outside business hours
- SoD violation

### Soft / Advisory
Yetki yönetim ekibine öneri veya uyarı.

Örnek:
- "Bu permission'a çok benzeyen başka bir permission mevcut."
- "Benzer isimli bir grup mevcut."
- "Bu rol mevcut bir rolle %90 benzer permission setine sahip."

Soft advisory işlemi engellememelidir. Yetki ekibi isterse işlemi devam ettirebilmelidir.

Bu özellik ilk prototipte tamamen uygulanmak zorunda değildir; ancak mimari ileride AI/analiz katmanı eklenebilecek şekilde kurulmalıdır.

---

## 7. Separation of Duties (SoD)

Birbirleriyle birlikte bulunmaması gereken permission/role kombinasyonları tanımlanabilmelidir.

Örnek:

> CREDIT_CREATE ve CREDIT_APPROVE aynı kullanıcıda bulunamaz.

Kontrol iki şekilde yapılabilmelidir:

1. **Assignment-time check** – yeni yetki verilirken
2. **Retrospective scan** – sonradan eklenen kurallar için geçmiş atamaları tarama

Örnek:

A ve B permission'ı geçmişte aynı kullanıcıya verilmiş olabilir. Bir ay sonra "A ve B aynı kişide bulunamaz" kuralı eklenirse sistem mevcut kullanıcıları tarayıp ihlalleri raporlayabilmelidir.

Sistem otomatik olarak yetki silmemelidir. İhlali tespit edip görünür hale getirmelidir.

---

## 8. What-If / Simulation

Yönetim panelinde authorization değişiklikleri uygulanmadan önce simüle edilebilmelidir.

Örnek sorular:
- Bu kullanıcıya bu rolü verirsem effective permission'ları ne olur?
- Bu permission'ı verirsem SoD ihlali oluşur mu?
- Bu kullanıcıyı bu gruba eklersem ne değişir?
- Bu policy değişirse kimler etkilenir?
- Yeni conflict rule eklenirse mevcutta kaç ihlal oluşur?
- Bu permission hangi dış sistem yetkilerini gerektirir?

Simulation mümkünse gerçek authorization evaluator'ı kullanmalıdır; ayrı bir karar mantığı yazılmamalıdır.

---

## 9. External System / RACF Mapping

Bugünkü yapıda .NET authorization ile Mainframe/RACF authorization ayrı yönetilmektedir.

Örnek:

Bir kullanıcıya `VADA_MENU` yetkisi verilmesi, mainframe tarafında aşağıdaki RACF transaction yetkilerini de gerektirebilir:

- VADA-B0
- VADA-X
- vb.

Bugün bu mapping bilgisi merkezi olarak bulunmayabilir. Domain/ekran ekipleriyle çalışılarak zaman içinde oluşturulacaktır.

Bunun için bir **External Permission Mapping** modeli bulunmalıdır.

Örnek mantık:

`VADA_MENU`
-> RACF: `VADA-B0`
-> RACF: `VADA-X`

İlk prototipte gerçek RACF entegrasyonu zorunlu değildir.

Permission assignment sonucunda bir event/action oluşturulması yeterlidir.

İlk aşamada event handler:
- log yazabilir,
- DB'ye kayıt bırakabilir,
- popup/notification oluşturabilir,
- e-mail üretebilir.

İleride aynı event:
- RACF adapter,
- EGL/CICS çağrısı,
- FTP/batch,
- başka API

üzerinden gerçek provisioning yapabilir.

Authorization core, RACF/FTP/EGL detaylarını bilmemelidir.

---

## 10. Event / Provisioning Mimarisi

Yetki değişiklikleri event üretmeye uygun tasarlanmalıdır.

Örnek event'ler:
- PermissionAssigned
- PermissionRevoked
- RoleAssigned
- RoleRevoked
- GroupMembershipChanged
- PolicyChanged
- SoDRuleCreated

Event consumer ilk aşamada basit olabilir.

Gelecekte ayrı bir **Provisioning Service** oluşturularak external system adapter'ları buraya bağlanabilir.

Önemli prensip:

> Authorization kararı ile external provisioning birbirine sıkı bağlanmamalıdır.

---

## 11. Önerilen Veri Modeli – Kabaca

Kolon seviyesine inmeden ana tablolar:

### Identity / Organization
- Users
- OrganizationUnits
- UserOrganizationUnits

### RBAC
- Roles
- Permissions
- UserRoles
- RolePermissions

### Flexible Groups
- Groups
- GroupUsers
- GroupRoles
- GroupOrganizationUnits
- GroupPermissions (grubun doğrudan permission alması desteklenecekse)

### Policy
- Policies
- Rules
- PolicyRules
- PermissionPolicies

Rule parametreleri için ileride ayrıca yapı gerekebilir:
- RuleParameters / RuleConfiguration

### SoD
- ConflictRules / SoDRules
- ConflictRuleMembers
- DetectedViolations

### External Systems
- ExternalSystems
- ExternalPermissions
- PermissionExternalMappings

### Events / Provisioning
- DomainEvents / OutboxEvents
- ProvisioningActions
- ProvisioningResults

### Audit
- AuditLogs

---

## 12. Effective Permission

Sistem aşağıdaki soruya açıklanabilir şekilde cevap vermelidir:

> "Ahmet bu permission'ı neden aldı?"

Cevap örnekleri:
- doğrudan Role X üzerinden,
- Group Y içindeki Role X üzerinden,
- Organization Unit 101'in dahil olduğu Group Z üzerinden.

Effective permission hesaplanırken sadece sonuç değil, mümkünse **permission source / authorization path** bilgisi de üretilebilmelidir.

Bu ileride audit, troubleshooting, what-if ve AI analizleri için değerlidir.

---

## 13. Performans

Mevcut hacimler SQL açısından korkutucu değildir; ancak doğru tasarım gerektirir.

Önemli konular:
- doğru composite index'ler,
- connection pooling,
- gereksiz N+1 query'lerden kaçınma,
- batch/effective permission query'leri,
- gerektiğinde cache,
- permission/version invalidation,
- login storm testi.

Yaklaşık 20–21 bin kullanıcının 10 dakikalık pencere içinde login olması test edilmelidir.

Login sırasında statik permission set'i alınabilir ve uygulama/framework tarafında kullanılabilir.

Ancak context-dependent policy kararları cache'lenmiş statik permission ile bypass edilmemelidir.

---

## 14. API Kategorileri

### Query
- Kullanıcının rolleri
- Kullanıcının grupları
- Kullanıcının effective permission'ları
- Rolün permission'ları
- Grubun üyeleri
- Permission'ın bağlı policy'leri
- Permission'ın external mappings'i

### Management
- User yönetimi (prototip kapsamında gerekiyorsa)
- Role CRUD
- Permission CRUD
- Group CRUD
- Role/Permission assignment
- Group member assignment
- Policy CRUD
- Rule CRUD
- Policy/Rule mapping
- SoD rule CRUD

### Authorization
Örnek:

`POST /authorization/evaluate`

Input kabaca:
- User
- Permission / Action
- Resource
- Context
  - Amount
  - Time
  - Branch
  - Channel
  - IP
  - vb.

Output yalnızca true/false olmamalıdır.

Örnek:
- Decision: Allow / Deny
- ReasonCode
- HumanReadableReason
- MatchedRules
- FailedRules
- Decision/Audit ID

### Simulation
- Role assignment simulation
- Group membership simulation
- Permission assignment simulation
- Policy impact simulation
- SoD impact simulation

---

## 15. Audit / Explainability

Banka ortamında authorization kararları açıklanabilir olmalıdır.

Kaydedilebilecek bilgiler:
- Kim?
- Hangi permission/action?
- Hangi resource?
- Ne zaman?
- Hangi context ile?
- Sonuç neydi?
- Hangi rule sonucu etkiledi?
- Permission hangi kaynaktan geldi?
- Yönetim değişikliğini kim yaptı?

Audit tasarımı sonradan eklenen bir özellik olarak görülmemelidir.

---

## 16. AI / MCP İçin Geleceğe Hazırlık

İleride bir AI/MCP katmanının sistemi analiz etmesi beklenebilir.

Örnek ihtiyaçlar:
- benzer permission tespiti,
- benzer role/group tespiti,
- gereksiz/duplicate authorization analizi,
- SoD ihlallerinin açıklanması,
- permission kullanım analizi,
- "Bu kullanıcı neden yetkili?" sorgusu,
- "Bu policy değişirse kim etkilenir?" analizi.

Bu nedenle API'ler ve veri modeli açıklanabilir, sorgulanabilir ve metadata açısından zengin olmalıdır.

AI hiçbir zaman core authorization kararının zorunlu parçası olmamalıdır. Core karar motoru deterministik kalmalıdır.

---

## 17. Prototip Geliştirme Sırası

Her şeyi aynı anda yazmak yerine aşağıdaki sırayla ilerlemek mantıklıdır:

### Phase 1 – Core RBAC
- User
- Role
- Permission
- UserRole
- RolePermission
- Effective permission query

### Phase 2 – Policy Engine
- Policy
- Rule
- PolicyRule
- PermissionPolicy
- Authorization evaluate endpoint
- Örnek business-hours ve amount-limit rule

### Phase 3 – Flexible Groups
- Group
- User/Role/Organization Unit membership
- Effective permission resolution

### Phase 4 – SoD
- Conflict rule
- Assignment-time validation
- Existing assignment scan
- Violation dashboard

### Phase 5 – What-If
- Assignment simulation
- Policy impact simulation

### Phase 6 – Event / External Mapping
- External permission mapping
- Outbox/event
- Dummy provisioning handler
- Log/DB/UI notification

### Phase 7 – Advanced Analysis
- Similar permission/role/group suggestions
- Periodic authorization review
- AI/MCP integration hooks

---

## 18. Tasarım Prensipleri

1. **Core authorization deterministik olmalı.**
2. **AI/advisory karar mekanizmasını bloke etmemeli.**
3. **Role ana yönetim mekanizması olmalı.**
4. **Group esneklik için kullanılmalı, ana model haline gelmemeli.**
5. **Organization hierarchy authorization hierarchy değildir.**
6. **Policy inheritance yerine composition tercih edilmeli.**
7. **Rule'lar küçük ve tekrar kullanılabilir olmalı.**
8. **Authorization ile provisioning ayrılmalı.**
9. **Her effective permission'ın kaynağı açıklanabilmeli.**
10. **What-if gerçek evaluator mantığını yeniden kullanmalı.**
11. **Mevcut sistem bir gecede yeniden tasarlanmamalı; migration-friendly olunmalı.**
12. **Frontend sadece yönetim arayüzüdür; business/authorization logic API'de kalmalıdır.**
13. **Audit ve explainability ilk günden tasarımın parçası olmalıdır.**
14. **Yeni entegrasyonlar adapter/event yaklaşımıyla eklenebilmelidir.**

---

## 19. Prototipin Başarı Kriteri

Prototip sonunda en azından şu hikâye uçtan uca gösterilebilmelidir:

1. Bir permission oluştur.
2. Permission'ı bir role bağla.
3. Rolü kullanıcıya ata.
4. Kullanıcının effective permission'larını getir.
5. Permission'a policy bağla.
6. Mesai saati veya işlem limiti gibi rule ile `ALLOW/DENY` üret.
7. Kararın nedenini göster.
8. SoD conflict oluştur ve assignment sırasında uyar/engelle.
9. What-if ile değişikliği uygulamadan sonucu göster.
10. Permission için external/RACF mapping tanımla.
11. Assignment sonrası dummy event/provisioning action üret.
12. Tüm süreci React admin ekranından yönet/görüntüle.

Bu temel başarıldığında sistem ileride gerçek RACF/LDAP/identity entegrasyonları, periyodik analiz servisleri ve AI/MCP özellikleri eklenebilecek sağlam bir prototip tabanına sahip olacaktır.

---

# Addendum — SDK, Runtime Authorization Context, Rule Model and Persistence Strategy

## 1. Authorization Engine vs. Consumer SDK

The authorization platform must expose a reusable .NET SDK/framework integration layer in addition to the central Authorization API/Engine.

The central engine remains the source of truth and decision maker. Business-domain developers (term deposit, credit, cash/teller, ATM, etc.) should not be expected to manually reproduce authorization logic inside their application code.

Primary design goal: **minimize developer-written authorization `if` statements and reduce the possibility of a developer forgetting or incorrectly implementing a security check.**

### Declarative authorization

For simple/static permission checks, prefer declarative endpoint/controller integration such as an authorization attribute/filter/middleware concept:

- Endpoint declares the required permission (example: `VADA_MENU`).
- Framework/SDK intercepts the request before business logic executes.
- SDK collects the authenticated user and available authorization context.
- SDK calls/evaluates the Authorization Engine.
- `Deny` prevents execution of the business endpoint.
- Business code should not contain manual permission lookup logic.

The exact attribute/API names are implementation details and can be refined during coding.

## 2. Dynamic Business Context Without Naming Conventions

Policy evaluation may require runtime values that the authorization framework cannot infer by itself, for example:

- transaction amount,
- customer number,
- account/product identifiers,
- other domain-specific request values.

Do **not** require all business teams to use fixed DTO property names such as `CustomerNo` or `TransactionAmount`. That creates fragile cross-bank naming conventions and remains developer-error prone.

Instead, the SDK should support semantic metadata/attributes that business developers can place on their existing request DTO properties. Conceptually:

- a property can be marked as the authorization-context `Customer`,
- another as `TransactionAmount`,
- etc.

The business team remains free to name and structure its DTOs. The SDK cares about the semantic marker, not the CLR property name.

The SDK should inspect the endpoint/request metadata and build a normalized `AuthorizationContext` before evaluating policies.

### Context that should NOT require business annotations

Technical/environmental context should be collected automatically by the framework whenever trustworthy information is already available, for example:

- authenticated user identity,
- source IP,
- request time,
- channel/platform (where reliably known by the platform),
- other request/framework metadata.

Business developers should annotate only information the framework cannot know automatically.

### Fail closed

If a policy requires a context value and that value cannot be resolved, the engine must not silently skip that rule. The authorization result should fail closed (or return an explicit indeterminate/missing-context decision that is treated as deny by the enforcement layer) and clearly state which required context was missing.

## 3. Rule Type vs. Rule Instance

Keep a distinction between a **Rule Type** and an actual **Rule**.

### RuleType

Represents capabilities supported by the authorization engine, for example:

- IP / IP range check,
- time/business-hours check,
- platform/channel check,
- transaction amount vs. user limit check,
- customer-related checks,
- organizational checks.

A RuleType is effectively a catalog of rule capabilities understood by the engine.

Each RuleType should map to a C# evaluator/handler implementation. Example conceptual handlers:

- `IpRangeRuleHandler`
- `BusinessHoursRuleHandler`
- `PlatformRuleHandler`
- `TransactionLimitRuleHandler`

**Do not store executable C#, SQL, scripts, or arbitrary expressions in the database.** Database/configuration data describes the rule; trusted application code implements its behavior.

### Rule

A Rule is a configured instance of a RuleType and belongs to/references a Policy.

Not every rule needs a literal comparison value in the rule row. Rules may compare runtime context against another value resolved from the subject/user/environment.

Example:

> For a cash-withdrawal operation, `Request.TransactionAmount <= User.CashWithdrawalLimit`.

The actual monetary limit is **not** owned by the policy definition. The policy expresses the comparison/constraint. The user's current limit is an input/value resolved elsewhere.

This distinction is important for the future architecture because real user limits may eventually come from an HR, identity, limit-management, or other banking system.

## 4. Prototype User Limit

For the prototype, do not integrate an external limit system.

The prototype `User` entity may contain a simple dummy field such as `CashWithdrawalLimit` so the complete dynamic-policy flow can be demonstrated.

Example prototype scenario:

1. User calls a cash-withdrawal endpoint.
2. Endpoint requires the appropriate permission.
3. Request DTO supplies `TransactionAmount` through authorization-context metadata.
4. Policy includes a transaction-limit rule.
5. Rule handler reads the request amount from `AuthorizationContext`.
6. Rule handler reads the user's prototype `CashWithdrawalLimit`.
7. Engine compares them and returns Allow/Deny with an explanation.

This is deliberately a prototype shortcut. The engine should be structured so that later the user-limit lookup can move behind a provider/resolver interface without redesigning the policy engine or business endpoints.

## 5. Future Context/Value Providers

Although the first prototype can read values directly from in-memory entities, avoid tightly coupling rule handlers to that storage choice.

Design toward resolver/provider abstractions so future values can originate from external systems. Conceptually, a rule can obtain operands from sources such as:

- Request context,
- User/subject attributes,
- Organization attributes,
- Environment,
- External provider.

The prototype does not need a generic expression language. Keep the implementation explicit and typed. Extensibility should come from adding supported RuleTypes/handlers/providers, not from executing arbitrary expressions stored in configuration.

## 6. Policy Evaluation Pipeline

Conceptual runtime flow:

`HTTP Request -> SDK / Authorization Filter -> Build AuthorizationContext -> Resolve Effective Permissions -> Resolve Policies -> Evaluate Rules -> AuthorizationDecision -> Allow/Deny`

An `AuthorizationDecision` should be explainable and suitable for audit/What-If reuse. It should be able to communicate at least:

- Allowed / Denied,
- requested permission/action,
- evaluated policies/rules,
- failed rule(s),
- human-readable/machine-readable reason codes,
- missing context when applicable.

The same underlying evaluation engine should later power the What-If screens. Do not build a separate simulation implementation with different authorization semantics.

## 7. Policy/Rule Logical Composition

Initially keep composition intentionally constrained and understandable.

Policies contain multiple rules. The prototype can begin with straightforward AND semantics where all required rules must pass. The data model should not prevent later support for explicit rule groups / controlled AND-OR composition.

Avoid introducing a full general-purpose expression language or deeply nested policy inheritance during the prototype.

## 8. Persistence Strategy — In-Memory First, SQL Server Ready

The production target database is **Microsoft SQL Server**, but the prototype should require **no SQL Server instance or manual database setup**.

Use an in-memory persistence implementation for the prototype while designing entities and persistence boundaries as if they will later be persisted to SQL Server.

Requirements:

- Domain/persistence entities should exist from day one.
- Relationships, IDs, constraints and navigation concepts should be SQL-friendly.
- Application/business logic must not depend directly on the in-memory storage mechanism.
- Seed realistic dummy data at startup for prototype/demo use.
- Repositories/data-access abstractions (or equivalent persistence boundaries) should allow the backing implementation to be replaced.
- Avoid in-memory-only modelling tricks that cannot map cleanly to relational tables.

### Migration goal

At the point where the prototype is accepted and a real database is desired, moving to SQL Server should require minimal application changes: configure the SQL Server provider/connection, create migrations/schema, and replace/configure the persistence implementation rather than redesigning the authorization domain.

The intended outcome is effectively: **same entities, same authorization services, same policy engine, different persistence provider.**

## 9. Updated Prototype Priorities

The coding order should now prioritize:

1. Core entities: User, Role, Permission and their relationships.
2. Effective permission resolution.
3. Policy, RuleType and Rule entities.
4. Typed C# rule-handler/evaluator architecture.
5. AuthorizationContext model.
6. .NET SDK/framework integration with declarative endpoint authorization.
7. Semantic request-property metadata for domain context such as transaction amount/customer.
8. Automatic collection of technical context such as user/IP/time/platform where possible.
9. Prototype transaction-limit rule using the dummy user cash-withdrawal limit.
10. Explainable AuthorizationDecision and audit-ready output.
11. In-memory persistence + startup seed data, while remaining SQL Server ready.
12. React authorization-management UI using the API.
13. Then extend with flexible Groups, SoD/retroactive violation analysis, What-If screens, external-system mappings/events/provisioning (RACF etc.), and later AI/MCP-facing capabilities.

## 10. Architectural Guardrails Added From This Discussion

- Authorization rules belong in the authorization platform, not scattered through business applications.
- Prefer declarative enforcement over manual calls and `if` statements.
- Never depend on DTO property-name conventions across business domains.
- Distinguish framework-known technical context from business-provided semantic context.
- Missing required policy context must never accidentally grant access.
- Store rule configuration as data; execute rule behavior in trusted typed C# handlers.
- Do not embed arbitrary executable scripts/SQL/C# in policy rows.
- Do not store externally-owned dynamic values (such as a user's real operational limit) as permanent policy constants merely for convenience.
- Prototype shortcuts must sit behind boundaries that can later be replaced by real integrations.
- The first prototype is in-memory, but the model is designed for a low-friction move to Microsoft SQL Server.
