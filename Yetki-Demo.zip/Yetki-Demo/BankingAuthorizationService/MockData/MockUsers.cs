using BankingAuthorizationService.Common;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.MockData;

public static class MockUsers
{
    public static List<User> GetAll() => new()
    {
        new User
        {
            Id = UserIds.Ahmet,
            Username = "ahmet",
            DisplayName = "Ahmet Yılmaz",
            RoleIds = new List<string> { RoleIds.FinanceViewer },
            CompanyScope = "company:10"
        },
        new User
        {
            Id = UserIds.Mehmet,
            Username = "mehmet",
            DisplayName = "Mehmet Öz",
            RoleIds = new List<string> { RoleIds.FinanceOperator },
            CompanyScope = "company:10"
        },
        new User
        {
            Id = UserIds.Ayse,
            Username = "ayse",
            DisplayName = "Ayşe Kara",
            RoleIds = new List<string> { RoleIds.FinanceManager },
            CompanyScope = "company:10"
        },
        new User
        {
            Id = UserIds.Admin,
            Username = "admin",
            DisplayName = "Admin",
            RoleIds = new List<string> { RoleIds.BankAdmin },
            CompanyScope = "*"
        },
        new User
        {
            Id = UserIds.Auditor,
            Username = "auditor",
            DisplayName = "Denetçi",
            RoleIds = new List<string> { RoleIds.Auditor },
            CompanyScope = "company:10"
        }
    };
}
