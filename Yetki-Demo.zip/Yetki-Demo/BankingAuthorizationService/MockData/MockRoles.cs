using BankingAuthorizationService.Common;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.MockData;

public static class MockRoles
{
    public static List<Role> GetAll() => new()
    {
        new Role
        {
            Id = RoleIds.FinanceViewer,
            Name = "FinanceViewer",
            PermissionIds = new List<string>
            {
                PermissionNames.CustomerRead,
                PermissionNames.AccountRead,
                PermissionNames.AccountBalanceView,
                PermissionNames.TransactionRead,
                PermissionNames.PaymentRead,
                PermissionNames.TransferRead,
                PermissionNames.StatementRead,
                PermissionNames.ReportRead
            }
        },
        new Role
        {
            Id = RoleIds.FinanceOperator,
            Name = "FinanceOperator",
            PermissionIds = new List<string>
            {
                PermissionNames.CustomerRead,
                PermissionNames.AccountRead,
                PermissionNames.AccountBalanceView,
                PermissionNames.TransactionRead,
                PermissionNames.PaymentRead,
                PermissionNames.PaymentCreate,
                PermissionNames.PaymentSubmit,
                PermissionNames.PaymentCancel,
                PermissionNames.TransferRead,
                PermissionNames.TransferCreate,
                PermissionNames.StatementRead,
                PermissionNames.StatementDownload,
                PermissionNames.ReportRead
            }
        },
        new Role
        {
            Id = RoleIds.FinanceManager,
            Name = "FinanceManager",
            ApprovalLimit = 1_000_000m,
            PermissionIds = new List<string>
            {
                PermissionNames.CustomerRead,
                PermissionNames.CustomerUpdate,
                PermissionNames.CustomerPhoneView,
                PermissionNames.CustomerIdentityView,
                PermissionNames.AccountRead,
                PermissionNames.AccountBalanceView,
                PermissionNames.AccountBalanceViewVip,
                PermissionNames.AccountUpdate,
                PermissionNames.TransactionRead,
                PermissionNames.PaymentRead,
                PermissionNames.PaymentCreate,
                PermissionNames.PaymentSubmit,
                PermissionNames.PaymentApprove,
                PermissionNames.PaymentReject,
                PermissionNames.PaymentExecute,
                PermissionNames.PaymentCancel,
                PermissionNames.TransferRead,
                PermissionNames.TransferCreate,
                PermissionNames.TransferApprove,
                PermissionNames.TransferExecute,
                PermissionNames.StatementRead,
                PermissionNames.StatementDownload,
                PermissionNames.ReportRead,
                PermissionNames.ReportExport
            }
        },
        new Role
        {
            Id = RoleIds.Auditor,
            Name = "Auditor",
            PermissionIds = new List<string>
            {
                PermissionNames.CustomerRead,
                PermissionNames.AccountRead,
                PermissionNames.AccountBalanceView,
                PermissionNames.TransactionRead,
                PermissionNames.PaymentRead,
                PermissionNames.TransferRead,
                PermissionNames.AuditLogRead,
                PermissionNames.ReportRead,
                PermissionNames.ReportExport
            }
        },
        new Role
        {
            Id = RoleIds.BankAdmin,
            Name = "BankAdmin",
            PermissionIds = new List<string> { PermissionNames.Wildcard }
        }
    };
}
