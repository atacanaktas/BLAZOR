using BankingAuthorizationService.Common;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.MockData;

public static class MockPermissions
{
    public static List<Permission> GetAll()
    {
        var descriptions = new Dictionary<string, string>
        {
            [PermissionNames.CustomerRead] = "View customer records",
            [PermissionNames.CustomerCreate] = "Create a new customer",
            [PermissionNames.CustomerUpdate] = "Update customer details",
            [PermissionNames.CustomerIdentityView] = "View customer national ID",
            [PermissionNames.CustomerPhoneView] = "View customer phone number",
            [PermissionNames.AccountRead] = "View account records",
            [PermissionNames.AccountBalanceView] = "View account balance",
            [PermissionNames.AccountBalanceViewVip] = "View unmasked balance for VIP customers",
            [PermissionNames.AccountUpdate] = "Update account details",
            [PermissionNames.AccountClose] = "Close an account",
            [PermissionNames.TransactionRead] = "View account transactions",
            [PermissionNames.PaymentRead] = "View payment records",
            [PermissionNames.PaymentCreate] = "Create a new payment",
            [PermissionNames.PaymentUpdate] = "Update a payment",
            [PermissionNames.PaymentSubmit] = "Submit a payment for approval",
            [PermissionNames.PaymentApprove] = "Approve a pending payment",
            [PermissionNames.PaymentReject] = "Reject a pending payment",
            [PermissionNames.PaymentExecute] = "Execute an approved payment",
            [PermissionNames.PaymentCancel] = "Cancel a payment",
            [PermissionNames.TransferRead] = "View transfer records",
            [PermissionNames.TransferCreate] = "Create a new transfer",
            [PermissionNames.TransferApprove] = "Approve a pending transfer",
            [PermissionNames.TransferExecute] = "Execute an approved transfer",
            [PermissionNames.StatementRead] = "View account statements",
            [PermissionNames.StatementDownload] = "Download account statements",
            [PermissionNames.ReportRead] = "View reports",
            [PermissionNames.ReportExport] = "Export reports",
            [PermissionNames.RoleRead] = "View roles",
            [PermissionNames.UserRead] = "View users",
            [PermissionNames.AuditLogRead] = "View the authorization audit log"
        };

        return PermissionNames.All.Select(id =>
        {
            var parts = id.Split('.', 2);
            return new Permission
            {
                Id = id,
                Resource = parts[0],
                Action = parts.Length > 1 ? parts[1] : string.Empty,
                Description = descriptions.TryGetValue(id, out var d) ? d : id
            };
        }).ToList();
    }
}
