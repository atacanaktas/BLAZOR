using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;
using BankingAuthorizationService.Rbac;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Rule: user has payment.approve AND payment is within scope (checked generically by the
/// engine) AND payment.status == PENDING_APPROVAL AND payment.createdBy != user.id
/// (maker/checker) AND payment.amount &lt;= user's approval limit.
/// </summary>
public class PaymentApprovePolicy : IPolicy
{
    private readonly MakerCheckerPolicy _makerChecker;
    private readonly IRbacService _rbac;

    public string Name => "PaymentApprovePolicy";

    public PaymentApprovePolicy(MakerCheckerPolicy makerChecker, IRbacService rbac)
    {
        _makerChecker = makerChecker;
        _rbac = rbac;
    }

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        var payment = context.Resource;
        if (payment is null)
        {
            return PolicyEvaluationResult.Deny("No payment specified to approve");
        }

        var status = payment.GetAttribute<string>("status");
        var statusOk = string.Equals(status, PaymentStatus.PendingApproval, StringComparison.OrdinalIgnoreCase);
        context.AddStep("Payment Status", statusOk ? StepResultNames.Pass : StepResultNames.Fail, $"Status is {status}");
        if (!statusOk)
        {
            return PolicyEvaluationResult.Deny($"Payment is not pending approval (status: {status})", Name);
        }

        var makerCheckerResult = _makerChecker.Evaluate(context);
        context.AddStep(
            "Maker/Checker",
            makerCheckerResult.Decision == PolicyDecision.Allow ? StepResultNames.Pass : StepResultNames.Fail,
            makerCheckerResult.Reason);
        if (makerCheckerResult.Decision != PolicyDecision.Allow)
        {
            return makerCheckerResult;
        }

        var amount = payment.GetAttribute<decimal>("amount");
        var limit = _rbac.GetApprovalLimit(context.User.Id);
        var withinLimit = limit is null || amount <= limit;
        context.AddStep(
            "Amount Limit",
            withinLimit ? StepResultNames.Pass : StepResultNames.Fail,
            limit is null ? "Approval limit is unlimited" : $"Limit is {limit:N0}, payment amount is {amount:N0}");
        if (!withinLimit)
        {
            return PolicyEvaluationResult.Deny("Payment amount exceeds approval limit", Name);
        }

        return PolicyEvaluationResult.Allow("Payment is pending approval, not self-created, and within approval limit");
    }
}
