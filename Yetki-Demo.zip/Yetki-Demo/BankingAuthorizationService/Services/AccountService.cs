using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;
using BankingAuthorizationService.Dtos;
using BankingAuthorizationService.Models;
using BankingAuthorizationService.Resources;

namespace BankingAuthorizationService.Services;

public class AccountService : IAccountService
{
    private readonly IResourceService _resources;
    private readonly IAuthorizationEngine _engine;

    public AccountService(IResourceService resources, IAuthorizationEngine engine)
    {
        _resources = resources;
        _engine = engine;
    }

    public List<AccountDto> GetAll(string userId)
    {
        var result = new List<AccountDto>();
        foreach (var resource in _resources.GetByType(ResourceTypes.Account))
        {
            var auth = _engine.Check(new AuthorizationRequest
            {
                UserId = userId,
                Permission = PermissionNames.AccountRead,
                ResourceType = ResourceTypes.Account,
                ResourceId = resource.Id
            });

            if (auth.Allowed)
            {
                result.Add(MapToDto(userId, resource));
            }
        }

        return result;
    }

    public (AccountDto?, AuthorizationResponse) GetById(string userId, string id)
    {
        var resource = _resources.GetById(id);
        if (resource is null || resource.Type != ResourceTypes.Account)
        {
            return (null, new AuthorizationResponse
            {
                Allowed = false,
                Decision = DecisionNames.Deny,
                Permission = PermissionNames.AccountRead,
                Reasons = new List<string> { "Account not found" }
            });
        }

        var auth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = PermissionNames.AccountRead,
            ResourceType = ResourceTypes.Account,
            ResourceId = id
        });

        return auth.Allowed ? (MapToDto(userId, resource), auth) : (null, auth);
    }

    private AccountDto MapToDto(string userId, Resource resource)
    {
        var balanceAuth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = PermissionNames.AccountBalanceView,
            ResourceType = ResourceTypes.Account,
            ResourceId = resource.Id
        });

        var customerId = resource.GetAttribute<string>("customerId");
        var customer = customerId is null ? null : _resources.GetById(customerId);

        return new AccountDto
        {
            Id = resource.Id,
            CustomerId = customerId ?? string.Empty,
            CustomerName = customer?.GetAttribute<string>("name") ?? string.Empty,
            Currency = resource.GetAttribute<string>("currency") ?? string.Empty,
            Balance = balanceAuth.Allowed ? resource.GetAttribute<decimal>("balance") : null,
            BalanceMasked = !balanceAuth.Allowed,
            Status = resource.GetAttribute<string>("status") ?? string.Empty,
            CompanyId = resource.GetAttribute<string>("companyId") ?? string.Empty
        };
    }
}
