using BankingAuthorizationService.Dtos;
using BankingAuthorizationService.Services;
using Microsoft.AspNetCore.Mvc;

namespace BankingAuthorizationService.Controllers;

[ApiController]
[Route("api/accounts")]
public class AccountController : ControllerBase
{
    private readonly IAccountService _accountService;
    private readonly ITransactionService _transactionService;

    public AccountController(IAccountService accountService, ITransactionService transactionService)
    {
        _accountService = accountService;
        _transactionService = transactionService;
    }

    [HttpGet]
    public ActionResult<List<AccountDto>> GetAll([FromQuery] string userId)
    {
        return Ok(_accountService.GetAll(userId));
    }

    [HttpGet("{id}")]
    public ActionResult<AccountDto> GetById(string id, [FromQuery] string userId)
    {
        var (account, auth) = _accountService.GetById(userId, id);
        return account is null ? StatusCode(403, auth) : Ok(account);
    }

    [HttpGet("{id}/transactions")]
    public ActionResult<List<TransactionDto>> GetTransactions(string id, [FromQuery] string userId)
    {
        return Ok(_transactionService.GetByAccount(userId, id));
    }
}
