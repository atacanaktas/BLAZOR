using BankingAuthorizationService.Common;
using BankingAuthorizationService.Services;

namespace BankingAuthorizationService.Rbac;

public class RbacService : IRbacService
{
    private readonly IUserService _userService;
    private readonly IRoleService _roleService;

    public RbacService(IUserService userService, IRoleService roleService)
    {
        _userService = userService;
        _roleService = roleService;
    }

    public bool HasPermission(string userId, string permission)
    {
        var roles = GetRolesForUser(userId);
        return roles.Any(r => r.PermissionIds.Contains(PermissionNames.Wildcard) || r.PermissionIds.Contains(permission));
    }

    public IReadOnlyList<string> GetEffectivePermissions(string userId)
    {
        var roles = GetRolesForUser(userId);
        if (roles.Any(r => r.PermissionIds.Contains(PermissionNames.Wildcard)))
        {
            return PermissionNames.All.ToList();
        }

        return roles.SelectMany(r => r.PermissionIds).Distinct().ToList();
    }

    public string? GetGrantingRoleName(string userId, string permission)
    {
        var roles = GetRolesForUser(userId);
        var granting = roles.FirstOrDefault(r =>
            r.PermissionIds.Contains(PermissionNames.Wildcard) || r.PermissionIds.Contains(permission));
        return granting?.Name;
    }

    public decimal? GetApprovalLimit(string userId)
    {
        var roles = GetRolesForUser(userId)
            .Where(r => r.PermissionIds.Contains(PermissionNames.Wildcard) || r.PermissionIds.Contains(PermissionNames.PaymentApprove))
            .ToList();

        if (roles.Count == 0)
        {
            return 0m;
        }

        // A role with no ApprovalLimit set (e.g. BankAdmin) means unlimited approval authority.
        if (roles.Any(r => r.ApprovalLimit is null))
        {
            return null;
        }

        return roles.Max(r => r.ApprovalLimit);
    }

    private List<Models.Role> GetRolesForUser(string userId)
    {
        var user = _userService.GetById(userId);
        if (user is null)
        {
            return new List<Models.Role>();
        }

        return user.RoleIds
            .Select(id => _roleService.GetById(id))
            .Where(r => r is not null)
            .Select(r => r!)
            .ToList();
    }
}
