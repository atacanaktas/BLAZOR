namespace BankingAuthorizationService.Common;

public static class RoleIds
{
    public const string FinanceViewer = "role-finance-viewer";
    public const string FinanceOperator = "role-finance-operator";
    public const string FinanceManager = "role-finance-manager";
    public const string Auditor = "role-auditor";
    public const string BankAdmin = "role-bank-admin";
}

public static class UserIds
{
    public const string Ahmet = "user-1";
    public const string Mehmet = "user-2";
    public const string Ayse = "user-3";
    public const string Admin = "user-4";
    public const string Auditor = "user-5";
}

public static class ResourceTypes
{
    public const string Customer = "customer";
    public const string Account = "account";
    public const string Payment = "payment";
    public const string Transaction = "transaction";
    public const string Transfer = "transfer";
}

public static class PaymentStatus
{
    public const string Draft = "DRAFT";
    public const string PendingApproval = "PENDING_APPROVAL";
    public const string Approved = "APPROVED";
    public const string Rejected = "REJECTED";
    public const string Executed = "EXECUTED";
    public const string Cancelled = "CANCELLED";
}

public static class DecisionNames
{
    public const string Allow = "ALLOW";
    public const string Deny = "DENY";
    public const string Mask = "MASK";
}

public static class StepResultNames
{
    public const string Pass = "PASS";
    public const string Fail = "FAIL";
    public const string Mask = "MASK";
    public const string NotApplicable = "N/A";
}
