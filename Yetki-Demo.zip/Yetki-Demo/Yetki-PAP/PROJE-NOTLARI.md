# Yetki-PAP — Güncel Proje Notları

> Son güncelleme: 4 Ekim 2026  
> Genel mimari: [`../README.md`](../README.md). Ana backlog: [`../TODO.md`](../TODO.md). Web: [`../Yetki-Web/PROJE-NOTLARI.md`](../Yetki-Web/PROJE-NOTLARI.md).

## Sorumluluk

PAP, yönetim/control-plane servisidir. Runtime authorization kararı üretmez.

- Application, flexible resource tree, resource type, scope, URI/endpoint, permission, policy, rule, condition, obligation ve policy reference tanımları.
- Group filter/member/role, client/secret/scope/intermediary, tenant, ownership team, SoD ve external system/dependency tanımları.
- Identity işlemlerini `IIdentityDirectory` ile PIP'e yönlendirme.
- Değişiklik öncesi PDP impact/validation; Block SoD'da reddetme; apply sonrası audit, violation ve outbox.
- Ortak prototip DB şemasının EF migration sahipliği.
- Sample data aracı ve external provisioning worker.

Aktif DB: `../DataBase/yetki.demo.db`. PAP başlangıçta migration uygular ve SQLite journal mode'u güvenli kopyalama için `DELETE` yapar. PIP/PDP migration çalıştırmaz.

## Ana proje yapısı

```text
src/Yetki.Pap.Api             HTTP management/proxy endpoint'leri
src/Yetki.Pap.Application     ChangeGate, definition, identity, governance akışları
src/Yetki.Pap.Infrastructure  EF Core, migrations, PDP/PIP client'ları, adapters
src/Yetki.Pap.Domain          Yönetim domain entity ve enum'ları
src/Yetki.Pap.Worker          Outbox/provisioning consumer
tools/Yetki.Pap.SampleData    yetki.demo.yedek.db üretimi
tests/Yetki.Pap.Tests         PDP/PIP fake'li application workflow testleri
```

## PDP sözleşmesi

Ortak binary/domain kütüphanesi yoktur. PAP, PDP JSON sözleşmelerini `Application/Integration/PdpContracts.cs` içinde kendi contract'larıyla karşılar.

- `POST /api/analysis/impact`: identity `AuthorizationChangeSet`, definition `ModelPatch` ve policy change set'lerinin kullanıcı/access/SoD/external etkisi.
- `conditions/validate`, `obligations/validate`, `group-filters/validate`, `permission-draft`: draft doğrulama ve normalize.
- `policy-impact`: farklı senaryolarda before/after policy kararı.
- `sod/rule-preview`, `sod/detect`: taslak ve mevcut ihlal hesabı.
- `external/impact`, `external/users/{id}`, `external/desired`: external desired/current hesapları.
- `/api/analysis/views/*`: hesaplanan read view'lar. PAP bunları Web'e iletir.
- `/api/analysis/decide` ve entitlements: yönetim konsolu analiz çağrıları.

PDP contract'ı değişirse PAP contract'ı ve integration testleri birlikte güncellenmelidir.

## ChangeGate ilkesi

Erişimi etkileyen mutation doğrudan DB'ye yazmamalıdır:

1. Current model version alınır.
2. Değişiklik kaydedilmeden PDP'ye gönderilir.
3. Gain/loss/retained, role/group, new SoD ve external farkı hesaplanır.
4. Block SoD, truncated/stale veya validation hatasında işlem durur.
5. Apply sırasında model version yeniden doğrulanır.
6. Yazma, model version artışı, audit/outbox ve gerekli violation kaydı yapılır.

Rule create/update/delete ve obligation değişiklikleri de bu akıştadır. UI preview güvenlik sınırı değildir.

## Identity yazma sırası ve bilinen tutarlılık riski

Identity değişikliğinde akış: PDP preview → PIP write → PAP audit/outbox. PIP ile PAP işlemi distributed transaction değildir. PIP başarılı, PAP audit/outbox başarısız olursa reconciliation gerekir. Hedef mimaride HR event'i ve idempotent orchestration kullanılmalıdır.

## External provisioning

PAP outbox olayı üretir. Worker, PDP'den kullanıcının desired external state ve diff'ini alır; adapter'a `Grant/Modify/Revoke` komutu verir; sonucu kaydeder. Demo adapter komutu simüle eder. Gerçek RACF/LDAP entegrasyonu yoktur.

## Güvenlik durumu

- PAP management API authentication/authorization içermez.
- `X-Actor` yalnız audit demosudur.
- PDP/PIP service key'leri demo yapılandırmasıdır.
- Maker-checker, signed publish, rollback ve emergency access yoktur.

Bu maddeler üretim öncesi P0'dır; ayrıntı ana TODO'dadır.

## Test

4 Ekim 2026: `dotnet test Yetki.Pap.sln` sonucu **14/14 başarılı**.

PAP testleri workflow'u fake PDP/PIP ile sınar. Karar motoru doğruluğu PDP testlerinde, identity davranışı PIP testlerinde, servislerin birlikte çalışması `../e2e` paketindedir.
