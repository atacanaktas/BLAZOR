﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Changes;
using Yetki.Pap.Application.Definitions;
using Yetki.Pap.Application.Events;
using Yetki.Pap.Application.Governance;
using Yetki.Pap.Application.Integration;
using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Policies;
using Yetki.Pap.Domain.Tenants;

namespace Yetki.Pap.Tests;

/// <summary>
/// PAP iş akışları: doğrulama, PDP'ye sorulan taslak (ModelPatch / change set), SoD engeli, PIP'e yazım sırası, olay / audit / ihlal kaydı,
/// paylaşılan model versiyonu. Karar ve etki HESABI PDP'nin, kimlik kuralları PIP'in testlerindedir.
/// </summary>
public class PapWorkflowTests
{
    private static ChangeImpactResult ImpactFor(int userId, string userName, bool blocked = false, bool warn = false)
    {
        var conflict = new SodConflict(1, "SOD_TEST", "Test", Severity.High, blocked ? SodEnforcement.Block : SodEnforcement.Warn, []);
        var user = new UserImpact(userId, userName, userName, "ABANK",
            [new AccessDelta(10, "anka.x:view", "X", "ANKA / x", false, ["rol"])], [], [], ["GISEYTK"], [], [], [],
            blocked || warn ? [conflict] : [], [], []);
        return new ChangeImpactResult
        {
            Summary = "1 kullanıcının erişimi değişir", AffectedUserCount = 1, Users = [user], Blocked = blocked,
            BlockingConflicts = blocked ? [new SodFinding(userId, userName, conflict)] : [],
            Warnings = warn ? [new SodFinding(userId, userName, conflict)] : []
        };
    }

    [Fact]
    public async Task Kural_policy_referansi_kaydeder_ve_referans_verilen_policy_silinemez()
    {
        await using var host = await TestHost.CreateAsync();
        var (tenantId, mesaiId) = await host.DbAsync(async db => (
            await db.Tenants.Where(t => t.Code == "ABANK").Select(t => t.Id).SingleAsync(),
            await db.Policies.Where(p => p.Code == "MESAI").Select(p => p.Id).SingleAsync()));
        var svc = (IServiceProvider sp) => sp.GetRequiredService<PolicyManagementService>();
        var created = await host.WithAsync(sp => svc(sp).CreatePolicyAsync(new PolicyUpsert { TenantId = tenantId, Code = "ogle_arasi", Name = "Öğle arası" }, default));

        // KİM kartı (kimlik koşulları VEYA) + mevcut MESAI policy'si referansla
        var rule = new RuleUpsert
        {
            Code = "kim", Name = "Kim", Order = 10,
            Condition = new ConditionDraft
            {
                Kind = ConditionKind.AllOf,
                Children =
                [
                    new ConditionDraft { Kind = ConditionKind.AnyOf, Children =
                    [
                        new ConditionDraft { ConditionTypeCode = "SUBJECT_HAS_ROLE", Parameters = new() { ["Roles"] = "GISEAST" } },
                        new ConditionDraft { ConditionTypeCode = "SUBJECT_IN_UNIT", Parameters = new() { ["Units"] = "101" } }
                    ] },
                    new ConditionDraft { Kind = ConditionKind.Reference, PolicyCode = "MESAI" }
                ]
            }
        };
        await host.WithAsync(async sp => { await svc(sp).CreateRuleAsync(created.Id!.Value, rule, null, default); });
        Assert.Equal(created.Id!.Value, Assert.Single(host.Pdp.ValidatedForPolicies));   // PDP'ye kuralın policy'si bildirilir (kurum + döngü kontrolü)
        var reference = await host.DbAsync(db => db.RuleConditions.SingleAsync(c => c.Rule.Policy.Code == "OGLE_ARASI" && c.Kind == ConditionKind.Reference));
        Assert.Equal(mesaiId, reference.ReferencedPolicyId);

        var ex = await Assert.ThrowsAsync<ConflictException>(() => host.WithAsync(sp => svc(sp).DeletePolicyAsync(mesaiId, default)));
        Assert.Contains("kullanımda", ex.Message);
    }

    [Fact]
    public async Task Rule_mutation_ChangeGate_SoD_block_oldugunda_kaydedilmez()
    {
        await using var host = await TestHost.CreateAsync();
        var policyId = await host.DbAsync(db => db.Policies.Select(p => p.Id).FirstAsync());
        host.Pdp.Impact = _ => ImpactFor(1, "blocked.user", blocked: true);

        await Assert.ThrowsAsync<ConflictException>(() => host.WithAsync(sp =>
            sp.GetRequiredService<PolicyManagementService>().CreateRuleAsync(policyId, new RuleUpsert
            {
                Code = "BLOCKED_RULE", Name = "Engellenen rule", Condition = new ConditionDraft { ConditionTypeCode = "USER_ON_LEAVE" }
            }, null, default)));

        Assert.False(await host.DbAsync(db => db.Rules.AnyAsync(r => r.Code == "BLOCKED_RULE")));
        Assert.False(await host.DbAsync(db => db.OutboxEvents.AnyAsync(e => e.AggregateId == "BLOCKED_RULE")));
    }

    [Fact]
    public async Task KIM_karti_gruba_cevrilir_erisim_degisirse_durur_sonra_karta_geri_alinir()
    {
        await using var host = await TestHost.CreateAsync();
        var (tenantId, ruleId) = await host.DbAsync(async db => (
            await db.Tenants.Where(t => t.Code == "ABANK").Select(t => t.Id).SingleAsync(),
            await db.Rules.Where(r => r.Code == "HQ_928").Select(r => r.Id).SingleAsync()));   // SUBE_KAPSAMI / HQ_928 = birim 928 (KİM kartı)
        var filters = new List<GroupFilterDraft> { new() { Criteria = [new GroupCriterionDraft { Attribute = "ORG_UNIT", Values = ["928"] }] } };
        host.Pdp.Overlap = _ => new("k", "SUBJECT_IN_UNIT(Units=928)", true, ["gul.yuce"],
            [new AudienceRuleRef(1, "SUBE_KAPSAMI", "x", ruleId, "HQ_928", "GM 928", 1)], [], [], []);
        var dto = new AudiencePromote { TenantId = tenantId, Code = "gm_928", Name = "GM 928 personeli", Filters = filters, RuleIds = [ruleId] };
        var svc = (IServiceProvider sp) => sp.GetRequiredService<AudienceService>();

        // Erişim değişirse durur ve hiçbir şey yazılmaz
        host.Pdp.Impact = _ => ImpactFor(1, "gul.yuce");
        await Assert.ThrowsAsync<ConflictException>(() => host.WithAsync(sp => svc(sp).PromoteAsync(dto, false, default)));
        Assert.False(await host.DbAsync(db => db.Groups.AnyAsync(g => g.Code == "GM_928")));

        // Erişim değişmiyorsa: tek istekte yeni grup (-1) + kitle kuralı + kuralın "grup X" ile değişmesi PDP'ye sorulur, sonra yazılır
        host.Pdp.Impact = _ => new ChangeImpactResult { Summary = "0 kullanıcı" };
        host.Pdp.ImpactRequests.Clear();
        var r = await host.WithAsync(sp => svc(sp).PromoteAsync(dto, false, default));
        var asked = host.Pdp.ImpactRequests.Last();
        Assert.Contains(asked.Patch!, op => op.Table == "Groups" && ((GroupRow)op.Row!).Id == -1);
        Assert.Equal(-1, Assert.Single(asked.Changes!.GroupFilters).GroupId);
        Assert.Equal("GM_928", Assert.Single(asked.PolicyChanges!.ReplacedRules).Rule.Condition.Parameters["Groups"]);
        Assert.Equal("GM_928", r.GroupCode);
        var stored = await host.DbAsync(db => db.RuleConditions.Include(c => c.Parameters).Include(c => c.ConditionType).SingleAsync(c => c.RuleId == ruleId));
        Assert.Equal("SUBJECT_IN_GROUP", stored.ConditionType!.Code);
        Assert.Equal("GM_928", stored.Parameters.Single().Value);
        Assert.True(await host.DbAsync(db => db.GroupFilterCriteria.AnyAsync(c => c.GroupFilter.Group.Code == "GM_928" && c.Attribute == "ORG_UNIT")));

        // Karta geri al: kural tekrar satırlara döner, kullanılmayan grup silinir
        host.Pdp.RuleAudiences[ruleId] = [new() { Criteria = [new GroupCriterionDraft { Attribute = "GROUP", Values = ["GM_928"] }] }];
        var back = await host.WithAsync(sp => svc(sp).DemoteAsync(new AudienceDemote { GroupId = r.GroupId!.Value, RuleIds = [ruleId] }, false, default));
        Assert.True(back.GroupDeleted);
        Assert.False(await host.DbAsync(db => db.Groups.AnyAsync(g => g.Code == "GM_928")));
        Assert.Equal("SUBJECT_IN_UNIT", (await host.DbAsync(db => db.RuleConditions.Include(c => c.ConditionType).SingleAsync(c => c.RuleId == ruleId))).ConditionType!.Code);
    }

    [Fact]
    public async Task Acik_uyeli_veya_rol_veren_grup_karta_alinamaz()
    {
        await using var host = await TestHost.CreateAsync();
        var vekalet = await host.DbAsync(db => db.Groups.Where(g => g.Code == "SUBEMDR_VEKALET_737").Select(g => g.Id).SingleAsync());
        await Assert.ThrowsAsync<ConflictException>(() => host.WithAsync(sp =>
            sp.GetRequiredService<AudienceService>().DemoteAsync(new AudienceDemote { GroupId = vekalet, RuleIds = [1] }, true, default)));
    }

    [Fact]
    public async Task Permission_dryRun_PDPye_patch_gonderir_ve_kaydetmez()
    {
        await using var host = await TestHost.CreateAsync();
        var (appId, resourceId, scopeId, policyId) = await host.DbAsync(async db => (
            await db.Applications.Where(a => a.Code == "ANKA").Select(a => a.Id).SingleAsync(),
            await db.Resources.Where(r => r.Code == "anka.vadelihesap").Select(r => r.Id).SingleAsync(),
            await db.Scopes.Where(s => s.Application.Code == "ANKA" && s.Code == "view").Select(s => s.Id).SingleAsync(),
            await db.Policies.Select(p => p.Id).FirstAsync()));
        var dto = new PermissionUpsert
        {
            ApplicationId = appId, Code = "test_perm", Name = "Test", ResourceIds = [resourceId], ScopeIds = [scopeId], PolicyIds = [policyId]
        };

        var r = await host.WithAsync(sp => sp.GetRequiredService<PermissionService>().CreateAsync(dto, true, null, default));
        Assert.True(r.Impact.DryRun);
        Assert.False(r.Impact.Applied);
        var patch = Assert.Single(host.Pdp.ImpactRequests).Patch!;
        Assert.Contains(patch, op => op.Table == "Permissions" && op.Op == PatchOp.Add && ((PermissionRow)op.Row!).Code == "TEST_PERM" && ((PermissionRow)op.Row!).Id < 0);
        Assert.Contains(patch, op => op.Table == "PermissionResources" && ((PermissionResourceRow)op.Row!).ResourceId == resourceId);
        Assert.False(await host.DbAsync(db => db.Permissions.AnyAsync(p => p.Code == "TEST_PERM")));

        var applied = await host.WithAsync(sp => sp.GetRequiredService<PermissionService>().CreateAsync(dto, false, null, default));
        Assert.True(applied.Impact.Applied);
        Assert.True(await host.DbAsync(db => db.Permissions.AnyAsync(p => p.Code == "TEST_PERM")));
        Assert.True(await host.DbAsync(db => db.OutboxEvents.AnyAsync(e => e.EventType == EventTypes.PermissionChanged && e.AggregateId == "TEST_PERM")));
    }

    [Fact]
    public async Task Permission_baska_uygulamanin_resourceu_reddedilir_tip_hedefinde_resource_listesi_temizlenir()
    {
        await using var host = await TestHost.CreateAsync();
        var (anka, nextralResource, typeId, policyId) = await host.DbAsync(async db => (
            await db.Applications.Where(a => a.Code == "ANKA").Select(a => a.Id).SingleAsync(),
            await db.Resources.Where(r => r.Application.Code != "ANKA").Select(r => r.Id).FirstAsync(),
            await db.ResourceTypes.Select(t => t.Id).FirstAsync(),
            await db.Policies.Select(p => p.Id).FirstAsync()));
        await Assert.ThrowsAsync<ValidationException>(() => host.WithAsync(sp => sp.GetRequiredService<PermissionService>().CreateAsync(new PermissionUpsert
        {
            ApplicationId = anka, Code = "yanlis", Name = "x", ResourceIds = [nextralResource], AllScopes = true, PolicyIds = [policyId]
        }, true, null, default)));

        var dto = new PermissionUpsert
        {
            ApplicationId = anka, Code = "tip", Name = "x", Target = PermissionTarget.ResourceType, ResourceTypeId = typeId, ResourceIds = [nextralResource], AllScopes = true, PolicyIds = [policyId]
        };
        await host.WithAsync(sp => sp.GetRequiredService<PermissionService>().CreateAsync(dto, true, null, default));
        Assert.Empty(dto.ResourceIds);
        Assert.DoesNotContain(host.Pdp.ImpactRequests[0].Patch!, op => op.Table == "PermissionResources");
    }

    [Fact]
    public async Task Permission_ilgisiz_tenant_policy_baglantisini_reddeder()
    {
        await using var host = await TestHost.CreateAsync();
        var (appId, resourceId, scopeId) = await host.DbAsync(async db => (
            await db.Applications.Where(a => a.Code == "ANKA").Select(a => a.Id).SingleAsync(),
            await db.Resources.Where(r => r.Application.Code == "ANKA").Select(r => r.Id).FirstAsync(),
            await db.Scopes.Where(s => s.Application.Code == "ANKA").Select(s => s.Id).FirstAsync()));
        var policyId = await host.DbAsync(async db =>
        {
            var unrelated = new Tenant { Code = "DISBANK", Name = "İlişkisiz Banka", Type = TenantType.Bank };
            var policy = new Policy { Tenant = unrelated, Code = "DIS_POLICY", Name = "Başka tenant policy" };
            db.Policies.Add(policy);
            await db.SaveChangesAsync();
            return policy.Id;
        });

        var ex = await Assert.ThrowsAsync<ValidationException>(() => host.WithAsync(sp =>
            sp.GetRequiredService<PermissionService>().CreateAsync(new PermissionUpsert
            {
                ApplicationId = appId, Code = "CROSS_TENANT", Name = "x", ResourceIds = [resourceId], ScopeIds = [scopeId], PolicyIds = [policyId]
            }, true, null, default)));

        Assert.Contains("tenant", ex.Message, StringComparison.OrdinalIgnoreCase);
        Assert.Empty(host.Pdp.ImpactRequests);
    }

    [Fact]
    public async Task Permission_apply_stale_preview_model_version_ile_kaydedilmez()
    {
        await using var host = await TestHost.CreateAsync();
        var (appId, resourceId, scopeId, policyId) = await host.DbAsync(async db => (
            await db.Applications.Where(a => a.Code == "ANKA").Select(a => a.Id).SingleAsync(),
            await db.Resources.Where(r => r.Application.Code == "ANKA").Select(r => r.Id).FirstAsync(),
            await db.Scopes.Where(s => s.Application.Code == "ANKA").Select(s => s.Id).FirstAsync(),
            await db.Policies.Where(p => p.Tenant.Code == "ABANK").Select(p => p.Id).FirstAsync()));
        host.Pdp.Impact = _ => new ChangeImpactResult { ModelVersion = 42, Summary = "etki yok" };

        var ex = await Assert.ThrowsAsync<ConflictException>(() => host.WithAsync(sp =>
            sp.GetRequiredService<PermissionService>().CreateAsync(new PermissionUpsert
            {
                ApplicationId = appId, Code = "STALE_PREVIEW", Name = "x", ResourceIds = [resourceId], ScopeIds = [scopeId], PolicyIds = [policyId]
            }, false, 41, default)));

        Assert.Contains("yeniden", ex.Message, StringComparison.OrdinalIgnoreCase);
        Assert.False(await host.DbAsync(db => db.Permissions.AnyAsync(p => p.Code == "STALE_PREVIEW")));
    }

    [Fact]
    public async Task SoD_Block_rol_atamasini_PIPe_yazmadan_reddeder()
    {
        await using var host = await TestHost.CreateAsync();
        var (userId, roleId) = await host.DbAsync(async db => (
            await db.Users.Where(u => u.UserName == "ayse.yilmaz").Select(u => u.Id).SingleAsync(),
            await db.Roles.Where(r => r.Code == "SUBEMDR").Select(r => r.Id).SingleAsync()));
        host.Pdp.Impact = _ => ImpactFor(userId, "ayse.yilmaz", blocked: true);
        var writes = FakePip.Writes;

        var ex = await Assert.ThrowsAsync<ConflictException>(() => host.WithAsync(sp => sp.GetRequiredService<AssignmentService>().AssignRoleAsync(userId, roleId, null, null, default)));
        Assert.Contains("SoD", ex.Message);
        Assert.Equal(writes, FakePip.Writes);
        Assert.False(await host.DbAsync(db => db.UserRoles.AnyAsync(x => x.UserId == userId && x.RoleId == roleId)));
        var cs = Assert.Single(host.Pdp.ImpactRequests).Changes!;
        Assert.Contains(cs.UserRoles, c => c.UserId == userId && c.RoleId == roleId && c.Add);
    }

    [Fact]
    public async Task Rol_atamasi_PIPe_yazar_olay_audit_ve_SoD_uyari_kaydi_uretir()
    {
        await using var host = await TestHost.CreateAsync();
        var (userId, roleId) = await host.DbAsync(async db => (
            await db.Users.Where(u => u.UserName == "elif.sahin").Select(u => u.Id).SingleAsync(),
            await db.Roles.Where(r => r.Code == "GISEYTK").Select(r => r.Id).SingleAsync()));
        host.Pdp.Impact = _ => ImpactFor(userId, "elif.sahin", warn: true);
        var ruleId = await host.DbAsync(db => db.SodRules.Select(r => r.Id).FirstAsync());
        host.Pdp.Impact = _ =>
        {
            var i = ImpactFor(userId, "elif.sahin", warn: true);
            var c = i.Warnings[0].Conflict with { SodRuleId = ruleId };
            i.Warnings = [new SodFinding(userId, "elif.sahin", c)];
            return i;
        };

        var impact = await host.WithAsync(sp => sp.GetRequiredService<AssignmentService>().AssignRoleAsync(userId, roleId, null, "vekalet", default));
        Assert.True(impact.Applied);
        Assert.True(await host.DbAsync(db => db.UserRoles.AnyAsync(x => x.UserId == userId && x.RoleId == roleId)));
        Assert.True(await host.DbAsync(db => db.OutboxEvents.AnyAsync(e => e.EventType == EventTypes.RoleAssigned)));
        Assert.True(await host.DbAsync(db => db.OutboxEvents.AnyAsync(e => e.EventType == EventTypes.EffectivePermissionsChanged && e.AggregateId == userId.ToString())));
        Assert.True(await host.DbAsync(db => db.SodViolations.AnyAsync(v => v.UserId == userId && v.SodRuleId == ruleId && v.DetectedBy == ViolationDetectionSource.AssignmentCheck)));
        Assert.True(await host.DbAsync(db => db.AuditLogs.AnyAsync(a => a.Action == EventTypes.RoleAssigned && a.Summary!.Contains("elif.sahin"))));
    }

    [Fact]
    public async Task Resource_olusturma_taslagi_resource_scope_ve_uri_satirlarini_gonderir_URI_cakismasi_reddedilir()
    {
        await using var host = await TestHost.CreateAsync();
        var (appId, typeId, scopeId) = await host.DbAsync(async db => (
            await db.Applications.Where(a => a.Code == "ANKA").Select(a => a.Id).SingleAsync(),
            await db.ResourceTypes.Where(t => t.MatchesHttp).Select(t => t.Id).FirstAsync(),
            await db.Scopes.Where(s => s.Application.Code == "ANKA" && s.Code == "view").Select(s => s.Id).SingleAsync()));
        var dto = new ResourceUpsert
        {
            ApplicationId = appId, ResourceTypeId = typeId, Code = "anka.yeni", Name = "Yeni",
            Scopes = [new ResourceScopeDraft { ScopeId = scopeId }], Uris = [new UriUpsert { Method = "get", Pattern = "/v1/yeni/{id}", ScopeId = scopeId }]
        };
        var (r, _) = await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().CreateResourceAsync(dto, default));
        var patch = Assert.Single(host.Pdp.ImpactRequests).Patch!;
        Assert.Contains(patch, op => op.Table == "Resources" && ((ResourceRow)op.Row!).Code == "anka.yeni");
        Assert.Contains(patch, op => op.Table == "ResourceScopes" && ((ResourceScopeRow)op.Row!).ScopeId == scopeId);
        Assert.Contains(patch, op => op.Table == "Uris" && ((UriRow)op.Row!).Method == "GET" && ((UriRow)op.Row!).Pattern == "/v1/yeni/{id}");
        Assert.True(r.Id > 0);

        var clash = new ResourceUpsert
        {
            ApplicationId = appId, ResourceTypeId = typeId, Code = "anka.yeni2", Name = "Yeni2",
            Scopes = [new ResourceScopeDraft { ScopeId = scopeId }], Uris = [new UriUpsert { Method = "GET", Pattern = "/v1/yeni/{id}", ScopeId = scopeId }]
        };
        await Assert.ThrowsAsync<ConflictException>(() => host.WithAsync(sp => sp.GetRequiredService<CatalogService>().CreateResourceAsync(clash, default)));
    }

    [Fact]
    public async Task Model_verisi_degisince_paylasilan_versiyon_artar_audit_degisince_artmaz()
    {
        await using var host = await TestHost.CreateAsync();
        var v0 = await host.DbAsync(db => db.ModelStates.Select(s => s.Version).SingleAsync());
        await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<Yetki.Pap.Infrastructure.Persistence.YetkiDbContext>();
            db.AuditLogs.Add(new Yetki.Pap.Domain.Governance.AuditLog { Category = AuditCategory.Management, Actor = "t", Action = "x" });
            await db.SaveChangesAsync();
        });
        Assert.Equal(v0, await host.DbAsync(db => db.ModelStates.Select(s => s.Version).SingleAsync()));

        await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<Yetki.Pap.Infrastructure.Persistence.YetkiDbContext>();
            (await db.Groups.FirstAsync()).Description = "değişti";
            await db.SaveChangesAsync();
        });
        Assert.Equal(v0 + 1, await host.DbAsync(db => db.ModelStates.Select(s => s.Version).SingleAsync()));
    }

    [Fact]
    public async Task Policy_ayari_guncelleme_taslagi_PDPye_policy_satiri_olarak_gider_ve_kaydetmez()
    {
        await using var host = await TestHost.CreateAsync();
        var service = (IServiceProvider sp) => sp.GetRequiredService<PolicyManagementService>();
        var tenantId = await host.DbAsync(db => db.Tenants.Select(t => t.Id).FirstAsync());
        var c = (await host.WithAsync(sp => service(sp).CreatePolicyAsync(new PolicyUpsert { TenantId = tenantId, Code = "AYAR", Name = "C" }, default))).Id!.Value;

        var r = await host.WithAsync(sp => service(sp).UpdatePolicyAsync(c,
            new PolicyUpsert { TenantId = tenantId, Code = "AYAR", Name = "C2", DecisionStrategy = DecisionStrategy.Affirmative }, true, null, default));
        Assert.True(r.Impact.DryRun);
        var op = Assert.Single(host.Pdp.ImpactRequests.Last().Patch!);
        Assert.True(op.Table == "Policies" && op.Op == PatchOp.Replace && ((PolicyRow)op.Row!).Name == "C2" && ((PolicyRow)op.Row!).Strategy == DecisionStrategy.Affirmative);
        Assert.Equal("C", await host.DbAsync(db => db.Policies.Where(p => p.Id == c).Select(p => p.Name).SingleAsync()));
    }

    [Fact]
    public async Task SoD_taramasi_PDP_tespitinden_ihlal_acar_ve_gecersizleri_kapatir()
    {
        await using var host = await TestHost.CreateAsync();
        var (ruleId, u1, u2) = await host.DbAsync(async db => (
            await db.SodRules.Select(r => r.Id).FirstAsync(),
            await db.Users.Where(u => u.UserName == "ali.demir").Select(u => u.Id).SingleAsync(),
            await db.Users.Where(u => u.UserName == "elif.sahin").Select(u => u.Id).SingleAsync()));
        // elif için eski açık ihlal (artık çakışma yok → kapanmalı)
        await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<IYetkiDbContext>();
            db.SodViolations.Add(new Yetki.Pap.Domain.Governance.SodViolation { SodRuleId = ruleId, UserId = u2, DetectedAt = host.Clock.UtcNow, LastSeenAt = host.Clock.UtcNow, Details = "eski" });
            await db.SaveChangesAsync(default);
        });
        var conflict = new SodConflict(ruleId, "SOD", "SoD", Severity.High, SodEnforcement.Warn, [new SodMatchedMember(SodMemberType.Role, 1, "R1", "R1", ["doğrudan"])]);
        host.Pdp.Detection = new SodDetectionResult(10, 1, 3, 7, [new SodUserConflicts(u1, "ali.demir", "Ali", [conflict])]);

        var result = await host.WithAsync(sp => sp.GetRequiredService<SodViolationService>().ScanAsync(default));
        Assert.Equal(1, result.NewViolations);
        Assert.Equal(1, result.AutoResolved);
        Assert.True(await host.DbAsync(db => db.SodViolations.AnyAsync(v => v.UserId == u1 && v.Status != ViolationStatus.Resolved && v.Details!.Contains("R1"))));
        Assert.True(await host.DbAsync(db => db.SodViolations.AnyAsync(v => v.UserId == u2 && v.Status == ViolationStatus.Resolved)));
    }
}
