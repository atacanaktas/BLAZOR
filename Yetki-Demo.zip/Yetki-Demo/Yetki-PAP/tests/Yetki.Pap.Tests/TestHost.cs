using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Integration;
using Yetki.Pap.Domain.Identity;
using Yetki.Pap.Domain.Rbac;
using Yetki.Pap.Infrastructure;
using Yetki.Pap.Infrastructure.Persistence;
using Yetki.Pap.Infrastructure.Services;
using Yetki.Pap.SampleData;

namespace Yetki.Pap.Tests;

public sealed class FakeClock : IClock
{
    public DateTime UtcNow { get; set; } = new(2026, 9, 22, 8, 0, 0, DateTimeKind.Utc);
}

/// <summary>
/// PDP'nin yerine: PAP'ın ne sorduğunu kaydeder, ayarlanabilir cevap döner. Karar / etki HESABI PDP'nin testlerindedir;
/// burada PAP'ın iş akışı (doğrulama, engelleme, olay, kayıt) test edilir.
/// </summary>
public sealed class FakePdp(IServiceProvider services) : IPdpClient
{
    public List<ImpactRequest> ImpactRequests { get; } = new();
    public Func<ImpactRequest, ChangeImpactResult> Impact { get; set; } = _ => new ChangeImpactResult { Summary = "etki yok" };
    public SodDetectionResult Detection { get; set; } = new(0, 0, 0, 1, []);
    public PermissionDraftInfo PermissionDraft { get; set; } = new(true, 1, ["x:view"]);

    public Task<ChangeImpactResult> ImpactAsync(ImpactRequest request, CancellationToken ct)
    {
        ImpactRequests.Add(request);
        // JSON gidiş-dönüşü: PAP'ın gönderdiği patch gerçekten serileşebiliyor mu?
        JsonSerializer.Serialize(request, Yetki.Pap.Infrastructure.Integration.ServiceClientBase.Json);
        return Task.FromResult(Impact(request));
    }

    public List<int> ValidatedForPolicies { get; } = new();

    public async Task<ConditionValidation> ValidateConditionAsync(ConditionDraft draft, int policyId, CancellationToken ct)
    {
        ValidatedForPolicies.Add(policyId);
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<YetkiDbContext>();
        var types = await db.ConditionTypes.ToDictionaryAsync(t => t.Code, t => t.Id, StringComparer.OrdinalIgnoreCase, ct);
        var policies = await db.Policies.ToDictionaryAsync(s => s.Code, s => s.Id, StringComparer.OrdinalIgnoreCase, ct);
        return new ConditionValidation(draft, "ifade", types, policies);
    }

    public Task<ObligationValidation> ValidateObligationAsync(string code, Dictionary<string, string> parameters, CancellationToken ct) =>
        Task.FromResult(new ObligationValidation(code.ToUpperInvariant(), parameters));

    public Task<string> ValidateGroupFiltersAsync(List<GroupFilterDraft> filters, CancellationToken ct) => Task.FromResult("(kural)");
    public Task<PermissionDraftInfo> PermissionDraftAsync(object draft, CancellationToken ct) => Task.FromResult(PermissionDraft);
    public Task<IReadOnlyList<SodUserConflicts>> SodRulePreviewAsync(SodRulePreviewRequest request, CancellationToken ct) => Task.FromResult<IReadOnlyList<SodUserConflicts>>([]);
    public Task<SodDetectionResult> SodDetectAsync(CancellationToken ct) => Task.FromResult(Detection);
    public Task<ExternalImpactResult> ExternalImpactAsync(ExternalCatalogPatch patch, CancellationToken ct) => Task.FromResult(new ExternalImpactResult(false, "etki yok", 0, []));
    public Task<UserExternalStatus> ExternalUserAsync(int userId, CancellationToken ct) => Task.FromResult(new UserExternalStatus(userId, "u", true, true, []));
    public Task<DriftReport> ExternalDriftAsync(CancellationToken ct) => Task.FromResult(new DriftReport(0, 0, []));
    public Task<IReadOnlyList<UserExternalDesired>> ExternalDesiredAsync(IReadOnlyCollection<int>? userIds, CancellationToken ct) => Task.FromResult<IReadOnlyList<UserExternalDesired>>([]);
    public Func<AudienceOverlapRequest, AudienceOverlapResult> Overlap { get; set; } = _ => new("k", "ifade", true, [], [], [], [], []);
    public Dictionary<int, List<GroupFilterDraft>?> RuleAudiences { get; } = new();
    public Task<AudienceOverlapResult> AudienceOverlapAsync(AudienceOverlapRequest request, CancellationToken ct) => Task.FromResult(Overlap(request));
    public Task<AudienceCondition> AudienceConditionAsync(List<GroupFilterDraft> filters, CancellationToken ct) =>
        Task.FromResult(new AudienceCondition(new ConditionDraft { ConditionTypeCode = "SUBJECT_IN_UNIT", Parameters = new() { ["Units"] = "101" } }, "SUBJECT_IN_UNIT(Units=101)"));
    public Task<List<GroupFilterDraft>?> RuleAudienceAsync(int ruleId, CancellationToken ct) => Task.FromResult(RuleAudiences.GetValueOrDefault(ruleId));
    public Task<JsonElement> SummaryAsync(CancellationToken ct) => Task.FromResult(JsonDocument.Parse("""{"modelVersion":1,"modelBuiltAt":"2026-01-01T00:00:00Z","counts":{}}""").RootElement);
    public Task<PdpResponse> ForwardAsync(HttpMethod method, string pathAndQuery, string? jsonBody, CancellationToken ct) => Task.FromResult(new PdpResponse(200, "application/json", "{}"));
}

/// <summary>PIP'in yerine: kimlik tabloları aynı (InMemory) veritabanında; PIP'in kuralları PIP testlerindedir.</summary>
public sealed class FakePip(YetkiDbContext db) : IIdentityDirectory
{
    public static int Writes;

    public Task<IdentityUser?> GetUserAsync(int id, CancellationToken ct) =>
        db.Users.AsNoTracking().Where(u => u.Id == id).Select(u => new IdentityUser(u.Id, u.TenantId, u.UserName, u.FullName, u.Email, u.Title, u.EmployeeNo, u.Kind, u.IsActive, u.IsOnLeave, u.CashWithdrawalLimit, u.CustomerNo)).FirstOrDefaultAsync(ct);
    public Task<IdentityRole?> GetRoleAsync(int id, CancellationToken ct) =>
        db.Roles.AsNoTracking().Where(r => r.Id == id).Select(r => new IdentityRole(r.Id, r.TenantId, r.Code, r.Name, r.Description, r.IsInheritable, r.IsActive)).FirstOrDefaultAsync(ct);
    public async Task<IReadOnlyList<IdentityRole>> GetRolesAsync(CancellationToken ct) =>
        await db.Roles.AsNoTracking().Select(r => new IdentityRole(r.Id, r.TenantId, r.Code, r.Name, r.Description, r.IsInheritable, r.IsActive)).ToListAsync(ct);
    public async Task<IReadOnlyList<IdentityUserRole>> GetUserRolesAsync(int userId, CancellationToken ct) =>
        await db.UserRoles.AsNoTracking().Where(x => x.UserId == userId).Select(x => new IdentityUserRole(x.UserId, x.RoleId, x.ValidFrom, x.ValidUntil, x.Reason, x.AssignedAt, x.AssignedBy)).ToListAsync(ct);
    public async Task<IReadOnlyList<IdentityUserUnit>> GetUserUnitsAsync(int userId, CancellationToken ct) =>
        await db.UserOrgUnits.AsNoTracking().Where(x => x.UserId == userId).Select(x => new IdentityUserUnit(x.UserId, x.OrgUnitId, x.IsPrimary)).ToListAsync(ct);
    public async Task<IReadOnlyList<IdentityUnit>> GetUnitsAsync(int? tenantId, CancellationToken ct) =>
        await db.OrgUnits.AsNoTracking().Where(u => tenantId == null || u.TenantId == tenantId).Select(u => new IdentityUnit(u.Id, u.TenantId, u.ParentId, u.Code, u.Name, u.Type, u.IsActive)).ToListAsync(ct);

    public Task<IdentityUser> CreateUserAsync(PipUserUpsert user, CancellationToken ct) => throw new NotSupportedException();
    public Task<IdentityUser> UpdateUserAsync(int id, PipUserUpsert user, CancellationToken ct) => throw new NotSupportedException();
    public Task<IdentityRole> CreateRoleAsync(PipRoleUpsert role, CancellationToken ct) => throw new NotSupportedException();
    public Task<IdentityRole> UpdateRoleAsync(int id, PipRoleUpsert role, CancellationToken ct) => throw new NotSupportedException();

    public async Task AssignRoleAsync(int userId, int roleId, DateTime? validUntil, string? reason, CancellationToken ct)
    {
        Interlocked.Increment(ref Writes);
        db.UserRoles.Add(new UserRole { UserId = userId, RoleId = roleId, ValidUntil = validUntil, Reason = reason });
        await db.SaveChangesAsync(ct);
    }

    public async Task RevokeRoleAsync(int userId, int roleId, CancellationToken ct)
    {
        Interlocked.Increment(ref Writes);
        db.UserRoles.Remove(await db.UserRoles.FirstAsync(x => x.UserId == userId && x.RoleId == roleId, ct));
        await db.SaveChangesAsync(ct);
    }

    public Task AddUserUnitAsync(int userId, int unitId, CancellationToken ct) => throw new NotSupportedException();
    public Task RemoveUserUnitAsync(int userId, int unitId, CancellationToken ct) => throw new NotSupportedException();
    public Task<IdentityUnit> CreateUnitAsync(PipUnitUpsert unit, CancellationToken ct) => throw new NotSupportedException();
}

/// <summary>Her test için izole InMemory veritabanı + örnek veri; PDP ve PIP sahte.</summary>
public sealed class TestHost : IAsyncDisposable
{
    public ServiceProvider Services { get; }
    public FakeClock Clock { get; } = new();
    public FakePdp Pdp { get; }

    private TestHost()
    {
        var config = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["Persistence:Provider"] = "InMemory",
            ["Persistence:InMemoryDatabaseName"] = "test-" + Guid.NewGuid()
        }).Build();

        var services = new ServiceCollection();
        services.AddLogging();
        services.AddYetkiInfrastructure(config);
        services.Replace(ServiceDescriptor.Singleton<IClock>(Clock));
        services.AddScoped<ICurrentActor>(_ => new SystemActor("test"));
        services.AddSingleton<FakePdp>();
        services.Replace(ServiceDescriptor.Scoped<IPdpClient>(sp => sp.GetRequiredService<FakePdp>()));
        services.Replace(ServiceDescriptor.Scoped<IIdentityDirectory, FakePip>());
        Services = services.BuildServiceProvider();
        Pdp = Services.GetRequiredService<FakePdp>();
    }

    public static async Task<TestHost> CreateAsync()
    {
        var host = new TestHost();
        await host.Services.InitializeYetkiDatabaseAsync();
        await using var scope = host.Scope();
        await new SampleDataBuilder(scope.ServiceProvider.GetRequiredService<YetkiDbContext>(), host.Clock).BuildAsync();
        return host;
    }

    public AsyncServiceScope Scope() => Services.CreateAsyncScope();

    public async Task<T> WithAsync<T>(Func<IServiceProvider, Task<T>> action)
    {
        await using var scope = Scope();
        return await action(scope.ServiceProvider);
    }

    public async Task WithAsync(Func<IServiceProvider, Task> action)
    {
        await using var scope = Scope();
        await action(scope.ServiceProvider);
    }

    public Task<T> DbAsync<T>(Func<YetkiDbContext, Task<T>> query) => WithAsync(sp => query(sp.GetRequiredService<YetkiDbContext>()));

    public ValueTask DisposeAsync() => Services.DisposeAsync();
}
