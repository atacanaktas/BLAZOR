using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Infrastructure;
using Yetki.Pap.Infrastructure.Persistence;
using Yetki.Pap.Infrastructure.Services;
using Yetki.Pap.SampleData;

// Kullanım (Yetki-PAP klasöründen):
//   dotnet run --project tools/Yetki.Pap.SampleData                 → Yetki-Demo/DataBase/yetki.demo.yedek.db
//   dotnet run --project tools/Yetki.Pap.SampleData -- <yol.db>     → verilen dosya
// Dosya varsa silinir ve sıfırdan kurulur: migration'lar + condition tipi kataloğu + örnek veri.
// Veritabanları (Yetki-Demo/DataBase — birden fazla servis aynı veritabanını kullanır):
//   yetki.demo.db        → servislerin kullandığı örnek veri (appsettings ConnectionStrings:Yetki)
//   yetki.demo.yedek.db  → örnek verinin temiz kopyası; bozulursa servisler kapalıyken yetki.demo.db üzerine kopyalayın
//   yetki.bos.db         → sadece şema, veri yok (kullanıcının kendi tasarımı için; bu araç ona dokunmaz)

var target = args.Length > 0 ? Path.GetFullPath(args[0]) : Path.GetFullPath(Path.Combine(FindPapRoot(), "..", "DataBase", "yetki.demo.yedek.db"));
if (Path.GetFileName(target) is var name && (name.Equals("yetki.demo.db", StringComparison.OrdinalIgnoreCase) || name.Equals("yetki.bos.db", StringComparison.OrdinalIgnoreCase)))
{
    Console.Error.WriteLine($"Güvenlik: {name} doğrudan hedeflenemez. yetki.demo.yedek.db'yi üretip API kapalıyken kopyalayın.");
    return 1;
}

foreach (var f in new[] { target, target + "-journal", target + "-wal", target + "-shm" })
    if (File.Exists(f)) File.Delete(f);

var config = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
{
    ["Persistence:Provider"] = "Sqlite",
    ["ConnectionStrings:Yetki"] = $"Data Source={target}"
}).Build();

var services = new ServiceCollection();
services.AddLogging();
services.AddYetkiInfrastructure(config);
services.AddScoped<ICurrentActor>(_ => new SystemActor("ornek-veri"));
await using (var provider = services.BuildServiceProvider())
{
    await provider.InitializeYetkiDatabaseAsync();
    await using var scope = provider.CreateAsyncScope();
    var db = scope.ServiceProvider.GetRequiredService<YetkiDbContext>();
    await new SampleDataBuilder(db, scope.ServiceProvider.GetRequiredService<IClock>()).BuildAsync();

    Console.WriteLine($"Örnek veri yazıldı: {target}");
    Console.WriteLine($"  {db.Tenants.Count()} tenant, {db.OrgUnits.Count()} birim, {db.Users.Count()} kullanıcı, {db.Roles.Count()} rol, {db.Groups.Count()} grup");
    Console.WriteLine($"  {db.Applications.Count()} uygulama, {db.ResourceTypes.Count()} resource tipi, {db.Resources.Count()} resource, {db.ResourceScopes.Count()} yetki (resource:scope), {db.ResourceUris.Count()} URI");
    Console.WriteLine($"  {db.Clients.Count()} client, {db.Policies.Count()} policy, {db.Permissions.Count()} permission, {db.Rules.Count()} kural,{db.SodRules.Count()} SoD kuralı");
    Console.WriteLine($"  envanter: {db.InventoryItems.Count()} öğe ({db.InventorySnapshots.Count()} kaynak) — sadece bilgi amaçlı");
    Console.WriteLine($"  {db.ClientSecrets.Count()} demo client secret'ı: ysk_demo_<client_id> (ör. ysk_demo_nextral-api) → PDP POST /api/v1/token");
    Console.WriteLine($"  {db.ExternalPermissions.Count()} dış yetki, {db.ExternalDependencies.Count()} dış bağımlılık, {db.ExternalPermissionRequirements.Count()} zincir");
    Console.WriteLine("  RACF/LDAP baseline'ı (olması gereken = dış sistemdeki durum) PDP hesabı gerektirir: servisler (PIP, PDP, PAP) bu veritabanıyla");
    Console.WriteLine("  açıkken POST /api/external/baseline çağrılır. Condition tipi adları / şemaları PDP ilk açılışta koddan senkronlanır.");
}
SqliteConnection.ClearAllPools(); // dosya kilidini bırak
return 0;

static string FindPapRoot()
{
    for (var dir = new DirectoryInfo(Directory.GetCurrentDirectory()); dir is not null; dir = dir.Parent)
        if (File.Exists(Path.Combine(dir.FullName, "Yetki.Pap.sln"))) return dir.FullName;
    for (var dir = new DirectoryInfo(AppContext.BaseDirectory); dir is not null; dir = dir.Parent)
        if (File.Exists(Path.Combine(dir.FullName, "Yetki.Pap.sln"))) return dir.FullName;
    throw new InvalidOperationException("Yetki.Pap.sln bulunamadı; hedef dosya yolunu argüman olarak verin.");
}
