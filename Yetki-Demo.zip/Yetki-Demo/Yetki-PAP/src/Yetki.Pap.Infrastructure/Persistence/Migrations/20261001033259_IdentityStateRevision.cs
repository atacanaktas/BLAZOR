﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Pap.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class IdentityStateRevision : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "IdentityState",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false),
                    Revision = table.Column<long>(type: "INTEGER", nullable: false),
                    ChangedAt = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IdentityState", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "IdentityState",
                columns: new[] { "Id", "ChangedAt", "Revision" },
                values: new object[] { 1, new DateTime(2026, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), 1L });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "IdentityState");
        }
    }
}
