using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Pap.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class PermissionExplicitTarget : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "AllScopes",
                table: "Permissions",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "Target",
                table: "Permissions",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            // Mevcut kayıtları açık hedefe taşı. Eski örtük anlam: resource listesi doluysa o resource'lar, boşsa tip (verildiyse).
            // Ne resource ne tip olan kayıt eskiden "tüm uygulama" sayılıyordu; artık GENİŞLEMEZ → Resources (atıl) olur.
            migrationBuilder.Sql("""
                UPDATE "Permissions" SET "Target" = CASE
                    WHEN EXISTS (SELECT 1 FROM "PermissionResources" pr WHERE pr."PermissionId" = "Permissions"."Id") THEN 1
                    WHEN "ResourceTypeId" IS NOT NULL THEN 2
                    ELSE 1 END;
                UPDATE "Permissions" SET "ResourceTypeId" = NULL WHERE "Target" <> 2;
                UPDATE "Permissions" SET "AllScopes" = CASE
                    WHEN EXISTS (SELECT 1 FROM "PermissionScopes" ps WHERE ps."PermissionId" = "Permissions"."Id") THEN 0 ELSE 1 END;
                """);

            migrationBuilder.AddCheckConstraint(
                name: "CK_Permissions_Target",
                table: "Permissions",
                sql: "(\"Target\" = 2 AND \"ResourceTypeId\" IS NOT NULL) OR (\"Target\" <> 2 AND \"ResourceTypeId\" IS NULL)");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "CK_Permissions_Target",
                table: "Permissions");

            migrationBuilder.DropColumn(
                name: "AllScopes",
                table: "Permissions");

            migrationBuilder.DropColumn(
                name: "Target",
                table: "Permissions");
        }
    }
}
