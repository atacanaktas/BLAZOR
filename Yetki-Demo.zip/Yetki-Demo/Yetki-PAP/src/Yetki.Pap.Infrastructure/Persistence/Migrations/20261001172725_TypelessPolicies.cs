using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Pap.Infrastructure.Persistence.Migrations
{
    /// <summary>
    /// Policy TİPİ kalkar: her policy kurallardan (yönetim ekranında soru kartlarından) oluşur. Veri birebir çevrilir:
    ///  - Rol / Grup / Kullanıcı policy'si → KİM kuralı (SUBJECT_HAS_ROLE / SUBJECT_IN_GROUP / SUBJECT_IS_USER, üye kodlarıyla);
    ///    ret nedeni eski tipten (ROLE_REQUIRED / GROUP_REQUIRED / USER_NOT_LISTED).
    ///  - Kanal (client) policy'si → NEREDEN kuralı (CLIENT_IN, client id'leriyle; CLIENT_NOT_ALLOWED).
    ///  - Birleşik (aggregate) policy → her alt policy için bir kural: o policy'ye referans (HAZIR POLICY kartı), aynı sıra ve strateji;
    ///    ret nedeni alt policy'den.
    ///  - Koşul policy'leri olduğu gibi kalır. Sonra PolicyMembers tablosu ve Policies.Type sütunu kalkar.
    /// Katalogda (PDP senkronlar) gerekli koşul tipi yoksa yer tutucu satır açılır.
    /// </summary>
    public partial class TypelessPolicies : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            foreach (var code in new[] { "SUBJECT_HAS_ROLE", "SUBJECT_IN_GROUP", "SUBJECT_IS_USER", "CLIENT_IN" })
                migrationBuilder.Sql($"""
                    INSERT INTO "ConditionTypes" ("Code", "Name", "DefaultScope", "ParameterSchemaJson", "IsAvailable", "IsSubjectOnly", "IsIdentity")
                    SELECT '{code}', '{code}', 1, '[]', 1, 0, 0
                    WHERE NOT EXISTS (SELECT 1 FROM "ConditionTypes" WHERE "Code" = '{code}');
                    """);

            // ---- Rol / grup / kullanıcı / kanal → tek kural
            migrationBuilder.Sql("""
                INSERT INTO "Rules" ("PolicyId", "Code", "Name", "Description", "Order", "ReasonCode", "IsActive", "CreatedAt", "CreatedBy")
                SELECT p."Id",
                       CASE p."Type" WHEN 4 THEN 'NEREDEN' ELSE 'KIM' END,
                       CASE p."Type" WHEN 4 THEN 'NEREDEN' ELSE 'KİM' END,
                       NULL, 10,
                       CASE p."Type" WHEN 1 THEN 'ROLE_REQUIRED' WHEN 2 THEN 'GROUP_REQUIRED' WHEN 3 THEN 'USER_NOT_LISTED' ELSE 'CLIENT_NOT_ALLOWED' END,
                       1, datetime('now'), 'migration:typeless'
                FROM "Policies" p WHERE p."Type" IN (1, 2, 3, 4);
                """);
            migrationBuilder.Sql("""
                INSERT INTO "RuleConditions" ("RuleId", "ParentId", "Kind", "ConditionTypeId", "ReferencedPolicyId", "Order")
                SELECT r."Id", NULL, 1,
                       (SELECT t."Id" FROM "ConditionTypes" t WHERE t."Code" =
                           CASE p."Type" WHEN 1 THEN 'SUBJECT_HAS_ROLE' WHEN 2 THEN 'SUBJECT_IN_GROUP' WHEN 3 THEN 'SUBJECT_IS_USER' ELSE 'CLIENT_IN' END),
                       NULL, 0
                FROM "Policies" p JOIN "Rules" r ON r."PolicyId" = p."Id" AND r."CreatedBy" = 'migration:typeless'
                WHERE p."Type" IN (1, 2, 3, 4);
                """);
            migrationBuilder.Sql("""
                INSERT INTO "ConditionParameters" ("ConditionId", "Key", "Value")
                SELECT rc."Id",
                       CASE p."Type" WHEN 1 THEN 'Roles' WHEN 2 THEN 'Groups' WHEN 3 THEN 'Users' ELSE 'Clients' END,
                       COALESCE(CASE p."Type"
                           WHEN 1 THEN (SELECT group_concat(x."Code", ',') FROM "PolicyMembers" m JOIN "Roles" x ON x."Id" = m."MemberId" WHERE m."PolicyId" = p."Id")
                           WHEN 2 THEN (SELECT group_concat(x."Code", ',') FROM "PolicyMembers" m JOIN "Groups" x ON x."Id" = m."MemberId" WHERE m."PolicyId" = p."Id")
                           WHEN 3 THEN (SELECT group_concat(x."UserName", ',') FROM "PolicyMembers" m JOIN "Users" x ON x."Id" = m."MemberId" WHERE m."PolicyId" = p."Id")
                           ELSE (SELECT group_concat(x."ClientId", ',') FROM "PolicyMembers" m JOIN "Clients" x ON x."Id" = m."MemberId" WHERE m."PolicyId" = p."Id")
                       END, '')
                FROM "Policies" p
                JOIN "Rules" r ON r."PolicyId" = p."Id" AND r."CreatedBy" = 'migration:typeless'
                JOIN "RuleConditions" rc ON rc."RuleId" = r."Id"
                WHERE p."Type" IN (1, 2, 3, 4);
                """);

            // ---- Birleşik (aggregate) → alt policy başına bir referans kuralı (HAZIR POLICY kartı)
            migrationBuilder.Sql("""
                INSERT INTO "Rules" ("PolicyId", "Code", "Name", "Description", "Order", "ReasonCode", "IsActive", "CreatedAt", "CreatedBy")
                SELECT a."Id", c."Code", c."Name", NULL,
                       10 * (SELECT COUNT(*) FROM "PolicyMembers" m2 WHERE m2."PolicyId" = m."PolicyId" AND m2."Id" <= m."Id"),
                       CASE c."Type"
                           WHEN 1 THEN 'ROLE_REQUIRED' WHEN 2 THEN 'GROUP_REQUIRED' WHEN 3 THEN 'USER_NOT_LISTED' WHEN 4 THEN 'CLIENT_NOT_ALLOWED'
                           WHEN 5 THEN (SELECT cr."ReasonCode" FROM "Rules" cr WHERE cr."PolicyId" = c."Id" ORDER BY cr."Order", cr."Code" LIMIT 1)
                           ELSE NULL END,
                       1, datetime('now'), 'migration:typeless-agg'
                FROM "Policies" a
                JOIN "PolicyMembers" m ON m."PolicyId" = a."Id"
                JOIN "Policies" c ON c."Id" = m."MemberId"
                WHERE a."Type" = 6;
                """);
            migrationBuilder.Sql("""
                INSERT INTO "RuleConditions" ("RuleId", "ParentId", "Kind", "ConditionTypeId", "ReferencedPolicyId", "Order")
                SELECT r."Id", NULL, 5, NULL, c."Id", 0
                FROM "Rules" r
                JOIN "PolicyMembers" m ON m."PolicyId" = r."PolicyId"
                JOIN "Policies" c ON c."Id" = m."MemberId" AND c."Code" = r."Code"
                WHERE r."CreatedBy" = 'migration:typeless-agg';
                """);
            migrationBuilder.Sql("""UPDATE "Rules" SET "CreatedBy" = 'migration' WHERE "CreatedBy" IN ('migration:typeless', 'migration:typeless-agg');""");
            // Model değişti: PDP önbelleğini yenilesin
            migrationBuilder.Sql("""UPDATE "ModelState" SET "Version" = "Version" + 1;""");

            // ---- Şema
            migrationBuilder.DropTable(
                name: "PolicyMembers");

            migrationBuilder.DropColumn(
                name: "Type",
                table: "Policies");
        }

        /// <summary>Sadece şema geri alınır; çevrilmiş kurallar kalır, eski policy'ler "koşul" (5) tipinde döner.</summary>
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Type",
                table: "Policies",
                type: "INTEGER",
                nullable: false,
                defaultValue: 5);

            migrationBuilder.CreateTable(
                name: "PolicyMembers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    PolicyId = table.Column<int>(type: "INTEGER", nullable: false),
                    MemberId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PolicyMembers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PolicyMembers_Policies_PolicyId",
                        column: x => x.PolicyId,
                        principalTable: "Policies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PolicyMembers_MemberId",
                table: "PolicyMembers",
                column: "MemberId");

            migrationBuilder.CreateIndex(
                name: "IX_PolicyMembers_PolicyId_MemberId",
                table: "PolicyMembers",
                columns: new[] { "PolicyId", "MemberId" },
                unique: true);
        }
    }
}
