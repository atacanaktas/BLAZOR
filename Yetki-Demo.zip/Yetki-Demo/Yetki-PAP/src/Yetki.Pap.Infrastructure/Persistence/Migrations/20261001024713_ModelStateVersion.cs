using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Pap.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class ModelStateVersion : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ModelState",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false),
                    Version = table.Column<long>(type: "INTEGER", nullable: false),
                    ChangedAt = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ModelState", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "ModelState",
                columns: new[] { "Id", "ChangedAt", "Version" },
                values: new object[] { 1, new DateTime(2026, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), 1L });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ModelState");
        }
    }
}
