using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Pap.Infrastructure.Persistence.Migrations
{
    /// <summary>
    /// Ortak koşul (SharedCondition) kavramı kalkar; tekrar kullanım birimi POLICY'dir.
    ///  1. Her ortak koşul aynı ifadeyle bir Condition policy'si olur (kök kurumda; kod çakışırsa sonuna _KOSUL; tek kural "KOSUL").
    ///  2. Ortak koşulun düğümleri bu kurala taşınır.
    ///  3. Ortak koşula referans veren düğümler artık bu policy'ye referans verir (Reference düğümü, ReferencedPolicyId).
    ///  4. SharedConditions tablosu ve eski sütunlar kalkar.
    /// Ayrıca ConditionTypes'a soru kartı (Question) ve kimlik koşulu (IsIdentity) sütunları eklenir (PDP senkronize eder).
    /// Davranış değişmez: referans verilen policy'nin tek kuralı ortak koşulun ifadesidir.
    /// </summary>
    public partial class PolicyReferences : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ReferencedPolicyId",
                table: "RuleConditions",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsIdentity",
                table: "ConditionTypes",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "Question",
                table: "ConditionTypes",
                type: "INTEGER",
                nullable: true);

            // ---- Veri taşıma (eski sütunlar ve tablo henüz duruyor)
            migrationBuilder.Sql("""
                CREATE TEMP TABLE "_SharedToPolicy" AS
                SELECT s."Id" AS "SharedId",
                       CASE WHEN EXISTS (SELECT 1 FROM "Policies" p WHERE p."Code" = s."Code") THEN s."Code" || '_KOSUL' ELSE s."Code" END AS "PolicyCode"
                FROM "SharedConditions" s;
                """);
            migrationBuilder.Sql("""
                INSERT INTO "Policies" ("TenantId", "Code", "Name", "Description", "Type", "Logic", "DecisionStrategy", "Mode", "IsActive", "Version", "CreatedAt", "CreatedBy", "UpdatedAt", "UpdatedBy")
                SELECT (SELECT t."Id" FROM "Tenants" t WHERE t."ParentId" IS NULL ORDER BY t."Id" LIMIT 1),
                       m."PolicyCode", s."Name", COALESCE(s."Description", 'Ortak koşuldan dönüştürüldü (' || s."Code" || ').'),
                       5, 1, 1, 1, s."IsActive", 1, s."CreatedAt", s."CreatedBy", s."UpdatedAt", s."UpdatedBy"
                FROM "SharedConditions" s JOIN "_SharedToPolicy" m ON m."SharedId" = s."Id";
                """);
            migrationBuilder.Sql("""
                INSERT INTO "Rules" ("PolicyId", "Code", "Name", "Description", "Order", "ReasonCode", "IsActive", "CreatedAt", "CreatedBy")
                SELECT p."Id", 'KOSUL', s."Name", NULL, 10, NULL, 1, s."CreatedAt", s."CreatedBy"
                FROM "SharedConditions" s
                JOIN "_SharedToPolicy" m ON m."SharedId" = s."Id"
                JOIN "Policies" p ON p."Code" = m."PolicyCode";
                """);
            // Referanslar: ortak koşul → policy
            migrationBuilder.Sql("""
                UPDATE "RuleConditions"
                SET "ReferencedPolicyId" = (SELECT p."Id" FROM "_SharedToPolicy" m JOIN "Policies" p ON p."Code" = m."PolicyCode"
                                            WHERE m."SharedId" = "RuleConditions"."ReferencedSharedConditionId"),
                    "ReferencedSharedConditionId" = NULL
                WHERE "ReferencedSharedConditionId" IS NOT NULL;
                """);
            // Ortak koşulun düğümleri yeni policy'nin kuralına taşınır
            migrationBuilder.Sql("""
                UPDATE "RuleConditions"
                SET "RuleId" = (SELECT r."Id" FROM "_SharedToPolicy" m
                                JOIN "Policies" p ON p."Code" = m."PolicyCode"
                                JOIN "Rules" r ON r."PolicyId" = p."Id" AND r."Code" = 'KOSUL'
                                WHERE m."SharedId" = "RuleConditions"."SharedConditionId"),
                    "SharedConditionId" = NULL
                WHERE "SharedConditionId" IS NOT NULL;
                """);
            migrationBuilder.Sql("""DROP TABLE "_SharedToPolicy";""");
            // Model değişti: PDP önbelleğini yenilesin
            migrationBuilder.Sql("""UPDATE "ModelState" SET "Version" = "Version" + 1;""");

            // ---- Şema
            migrationBuilder.DropForeignKey(
                name: "FK_RuleConditions_SharedConditions_ReferencedSharedConditionId",
                table: "RuleConditions");

            migrationBuilder.DropForeignKey(
                name: "FK_RuleConditions_SharedConditions_SharedConditionId",
                table: "RuleConditions");

            migrationBuilder.DropCheckConstraint(
                name: "CK_RuleConditions_Owner",
                table: "RuleConditions");

            migrationBuilder.DropIndex(
                name: "IX_RuleConditions_ReferencedSharedConditionId",
                table: "RuleConditions");

            migrationBuilder.DropIndex(
                name: "IX_RuleConditions_SharedConditionId",
                table: "RuleConditions");

            migrationBuilder.DropColumn(
                name: "ReferencedSharedConditionId",
                table: "RuleConditions");

            migrationBuilder.DropColumn(
                name: "SharedConditionId",
                table: "RuleConditions");

            migrationBuilder.DropTable(
                name: "SharedConditions");

            migrationBuilder.AlterColumn<int>(
                name: "RuleId",
                table: "RuleConditions",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "INTEGER",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_RuleConditions_ReferencedPolicyId",
                table: "RuleConditions",
                column: "ReferencedPolicyId");

            migrationBuilder.AddCheckConstraint(
                name: "CK_RuleConditions_Reference",
                table: "RuleConditions",
                sql: "(\"Kind\" = 5 AND \"ReferencedPolicyId\" IS NOT NULL) OR (\"Kind\" <> 5 AND \"ReferencedPolicyId\" IS NULL)");

            migrationBuilder.AddForeignKey(
                name: "FK_RuleConditions_Policies_ReferencedPolicyId",
                table: "RuleConditions",
                column: "ReferencedPolicyId",
                principalTable: "Policies",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <summary>Sadece şema geri alınır; policy'ye dönüştürülen ortak koşullar policy olarak kalır (referanslar kaldırılır).</summary>
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_RuleConditions_Policies_ReferencedPolicyId",
                table: "RuleConditions");

            migrationBuilder.DropCheckConstraint(
                name: "CK_RuleConditions_Reference",
                table: "RuleConditions");

            migrationBuilder.DropIndex(
                name: "IX_RuleConditions_ReferencedPolicyId",
                table: "RuleConditions");

            migrationBuilder.DropColumn(
                name: "IsIdentity",
                table: "ConditionTypes");

            migrationBuilder.DropColumn(
                name: "Question",
                table: "ConditionTypes");

            migrationBuilder.DropColumn(
                name: "ReferencedPolicyId",
                table: "RuleConditions");

            migrationBuilder.AlterColumn<int>(
                name: "RuleId",
                table: "RuleConditions",
                type: "INTEGER",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "INTEGER");

            migrationBuilder.AddColumn<int>(
                name: "SharedConditionId",
                table: "RuleConditions",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ReferencedSharedConditionId",
                table: "RuleConditions",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "SharedConditions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Code = table.Column<string>(type: "TEXT", maxLength: 64, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "TEXT", nullable: false),
                    CreatedBy = table.Column<string>(type: "TEXT", maxLength: 64, nullable: false),
                    Description = table.Column<string>(type: "TEXT", nullable: true),
                    Domain = table.Column<string>(type: "TEXT", maxLength: 32, nullable: true),
                    IsActive = table.Column<bool>(type: "INTEGER", nullable: false),
                    Name = table.Column<string>(type: "TEXT", maxLength: 160, nullable: false),
                    Scope = table.Column<int>(type: "INTEGER", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "TEXT", nullable: true),
                    UpdatedBy = table.Column<string>(type: "TEXT", maxLength: 64, nullable: true),
                    Version = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SharedConditions", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_RuleConditions_SharedConditionId",
                table: "RuleConditions",
                column: "SharedConditionId");

            migrationBuilder.CreateIndex(
                name: "IX_RuleConditions_ReferencedSharedConditionId",
                table: "RuleConditions",
                column: "ReferencedSharedConditionId");

            migrationBuilder.AddCheckConstraint(
                name: "CK_RuleConditions_Owner",
                table: "RuleConditions",
                sql: "(\"RuleId\" IS NOT NULL AND \"SharedConditionId\" IS NULL) OR (\"RuleId\" IS NULL AND \"SharedConditionId\" IS NOT NULL)");

            migrationBuilder.CreateIndex(
                name: "IX_SharedConditions_Code",
                table: "SharedConditions",
                column: "Code",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_RuleConditions_SharedConditions_ReferencedSharedConditionId",
                table: "RuleConditions",
                column: "ReferencedSharedConditionId",
                principalTable: "SharedConditions",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_RuleConditions_SharedConditions_SharedConditionId",
                table: "RuleConditions",
                column: "SharedConditionId",
                principalTable: "SharedConditions",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
