using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Domain.Catalog;
using Yetki.Pap.Domain.Clients;
using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Governance;
using Yetki.Pap.Domain.Groups;
using Yetki.Pap.Domain.Identity;
using Yetki.Pap.Domain.Tenants;
using Yetki.Pap.Domain.Policies;
using Yetki.Pap.Domain.Rbac;

namespace Yetki.Pap.Infrastructure.Persistence;

/// <summary>
/// Tek DbContext. Model konfigürasyonu SQL Server hedeflenerek yazılmıştır (anahtarlar, unique/composite index'ler, uzunluklar,
/// decimal precision, delete davranışları, check constraint'ler). InMemory provider bunların çoğunu yok sayar.
/// </summary>
public class YetkiDbContext(DbContextOptions<YetkiDbContext> options, IClock clock, ICurrentActor actor)
    : DbContext(options), IYetkiDbContext
{
    public DbSet<Tenant> Tenants => Set<Tenant>();
    public DbSet<OrgUnit> OrgUnits => Set<OrgUnit>();
    public DbSet<User> Users => Set<User>();
    public DbSet<UserOrgUnit> UserOrgUnits => Set<UserOrgUnit>();
    public DbSet<CatalogApplication> Applications => Set<CatalogApplication>();
    public DbSet<OwnershipTeam> OwnershipTeams => Set<OwnershipTeam>();
    public DbSet<ResourceType> ResourceTypes => Set<ResourceType>();
    public DbSet<Resource> Resources => Set<Resource>();
    public DbSet<Scope> Scopes => Set<Scope>();
    public DbSet<ResourceScope> ResourceScopes => Set<ResourceScope>();
    public DbSet<ResourceUri> ResourceUris => Set<ResourceUri>();
    public DbSet<InventorySnapshot> InventorySnapshots => Set<InventorySnapshot>();
    public DbSet<InventoryItem> InventoryItems => Set<InventoryItem>();
    public DbSet<Client> Clients => Set<Client>();
    public DbSet<ClientQueryApplication> ClientQueryApplications => Set<ClientQueryApplication>();
    public DbSet<ClientQueryTenant> ClientQueryTenants => Set<ClientQueryTenant>();
    public DbSet<ClientDelegation> ClientDelegations => Set<ClientDelegation>();
    public DbSet<ClientSecret> ClientSecrets => Set<ClientSecret>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<Group> Groups => Set<Group>();
    public DbSet<GroupMember> GroupMembers => Set<GroupMember>();
    public DbSet<GroupFilter> GroupFilters => Set<GroupFilter>();
    public DbSet<GroupFilterCriterion> GroupFilterCriteria => Set<GroupFilterCriterion>();
    public DbSet<GroupFilterValue> GroupFilterValues => Set<GroupFilterValue>();
    public DbSet<GroupRole> GroupRoles => Set<GroupRole>();
    public DbSet<Policy> Policies => Set<Policy>();
    public DbSet<PolicyObligation> PolicyObligations => Set<PolicyObligation>();
    public DbSet<PolicyObligationParameter> PolicyObligationParameters => Set<PolicyObligationParameter>();
    public DbSet<Rule> Rules => Set<Rule>();
    public DbSet<RuleCondition> RuleConditions => Set<RuleCondition>();
    public DbSet<ConditionParameter> ConditionParameters => Set<ConditionParameter>();
    public DbSet<ConditionType> ConditionTypes => Set<ConditionType>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<PermissionResource> PermissionResources => Set<PermissionResource>();
    public DbSet<PermissionScope> PermissionScopes => Set<PermissionScope>();
    public DbSet<PermissionPolicy> PermissionPolicies => Set<PermissionPolicy>();
    public DbSet<SodRule> SodRules => Set<SodRule>();
    public DbSet<SodRuleMember> SodRuleMembers => Set<SodRuleMember>();
    public DbSet<SodViolation> SodViolations => Set<SodViolation>();
    public DbSet<ExternalSystem> ExternalSystems => Set<ExternalSystem>();
    public DbSet<ExternalPermission> ExternalPermissions => Set<ExternalPermission>();
    public DbSet<ExternalPermissionRequirement> ExternalPermissionRequirements => Set<ExternalPermissionRequirement>();
    public DbSet<ExternalDependency> ExternalDependencies => Set<ExternalDependency>();
    public DbSet<UserExternalGrant> UserExternalGrants => Set<UserExternalGrant>();
    public DbSet<OutboxEvent> OutboxEvents => Set<OutboxEvent>();
    public DbSet<ProvisioningAction> ProvisioningActions => Set<ProvisioningAction>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<ModelState> ModelStates => Set<ModelState>();
    public DbSet<IdentityState> IdentityStates => Set<IdentityState>();

    /// <summary>Bu tiplerdeki değişiklikler yetki modelini etkilemez; versiyon artırmaz (model önbelleği korunur).</summary>
    private static readonly HashSet<Type> NonModelTypes =
    [
        typeof(AuditLog), typeof(OutboxEvent), typeof(ProvisioningAction), typeof(SodViolation), typeof(SodRule), typeof(SodRuleMember),
        typeof(InventorySnapshot), typeof(InventoryItem),   // envanter sadece bilgi: yetki modelini değiştirmez
        typeof(ClientSecret),                                // secret / son kullanım zamanı karar modelini değiştirmez
        typeof(ExternalSystem), typeof(ExternalPermission), typeof(ExternalPermissionRequirement), typeof(ExternalDependency),
        typeof(UserExternalGrant), typeof(ConditionType), typeof(OwnershipTeam), typeof(ModelState), typeof(IdentityState)
    ];

    /// <summary>
    /// Model verisi değiştiyse paylaşılan versiyon (ModelState) değişiklikle AYNI transaction'da artırılır: ayrı süreçteki PDP'ler
    /// ya eski veri + eski versiyonu ya da yeni veri + yeni versiyonu görür. Artırma tek SQL ifadesidir (eşzamanlı kayıtlarda kayıp olmaz).
    /// </summary>
    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        ApplyAuditFields();
        var bump = ChangeTracker.Entries().Any(e =>
            e.State is EntityState.Added or EntityState.Modified or EntityState.Deleted && !NonModelTypes.Contains(e.Entity.GetType()));
        if (!bump) return await base.SaveChangesAsync(cancellationToken);

        int result;
        if (Database.IsRelational())
        {
            await using var tx = Database.CurrentTransaction is null ? await Database.BeginTransactionAsync(cancellationToken) : null;
            result = await base.SaveChangesAsync(cancellationToken);
            await Database.ExecuteSqlInterpolatedAsync(
                $"UPDATE \"ModelState\" SET \"Version\" = \"Version\" + 1, \"ChangedAt\" = {clock.UtcNow} WHERE \"Id\" = 1", cancellationToken);
            if (tx is not null) await tx.CommitAsync(cancellationToken);
        }
        else
        {
            if (await ModelStates.FindAsync([1], cancellationToken) is { } state) { state.Version++; state.ChangedAt = clock.UtcNow; }
            result = await base.SaveChangesAsync(cancellationToken);
        }
        return result;
    }

    private void ApplyAuditFields()
    {
        var now = clock.UtcNow;
        foreach (var e in ChangeTracker.Entries())
        {
            if (e.Entity is AuditableEntity a)
            {
                if (e.State == EntityState.Added)
                {
                    if (a.CreatedAt == default) a.CreatedAt = now;
                    if (string.IsNullOrEmpty(a.CreatedBy) || a.CreatedBy == "system") a.CreatedBy = actor.Name;
                }
                else if (e.State == EntityState.Modified)
                {
                    a.UpdatedAt = now;
                    a.UpdatedBy = actor.Name;
                }
            }
            if (e.Entity is IAssignment asg && e.State == EntityState.Added)
            {
                if (asg.AssignedAt == default) asg.AssignedAt = now;
                if (string.IsNullOrEmpty(asg.AssignedBy) || asg.AssignedBy == "system") asg.AssignedBy = actor.Name;
            }
        }
    }

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<ModelState>(e =>
        {
            e.ToTable("ModelState");
            e.Property(x => x.Id).ValueGeneratedNever();
            e.HasData(new ModelState { Id = 1, Version = 1, ChangedAt = new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc) });
        });
        b.Entity<IdentityState>(e =>
        {
            e.ToTable("IdentityState");
            e.Property(x => x.Id).ValueGeneratedNever();
            e.HasData(new IdentityState { Id = 1, Revision = 1, ChangedAt = new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc) });
        });

        // ---------------- Kurum / kimlik ----------------
        b.Entity<Tenant>(e =>
        {
            e.ToTable("Tenants");
            Code(e.Property(x => x.Code), 32); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasOne(x => x.Parent).WithMany().HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<OrgUnit>(e =>
        {
            e.ToTable("OrgUnits");
            Code(e.Property(x => x.Code), 32);
            e.HasIndex(x => new { x.TenantId, x.Code }).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Parent).WithMany().HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<User>(e =>
        {
            e.ToTable("Users");
            e.Property(x => x.UserName).HasMaxLength(64).IsRequired(); e.HasIndex(x => x.UserName).IsUnique();
            e.Property(x => x.FullName).HasMaxLength(128).IsRequired();
            e.Property(x => x.Email).HasMaxLength(128);
            e.Property(x => x.Title).HasMaxLength(128);
            e.Property(x => x.EmployeeNo).HasMaxLength(32);
            e.Property(x => x.CustomerNo).HasMaxLength(32);
            e.Property(x => x.CashWithdrawalLimit).HasPrecision(18, 2);
            e.HasIndex(x => x.TenantId);
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<UserOrgUnit>(e =>
        {
            e.ToTable("UserOrgUnits");
            e.HasKey(x => new { x.UserId, x.OrgUnitId });
            e.HasIndex(x => x.OrgUnitId);
            e.HasOne(x => x.User).WithMany(u => u.OrgUnits).HasForeignKey(x => x.UserId);
            e.HasOne(x => x.OrgUnit).WithMany().HasForeignKey(x => x.OrgUnitId);
            Assign(e);
        });

        // ---------------- Katalog (resource server, resource, scope, URI) ----------------
        b.Entity<OwnershipTeam>(e =>
        {
            e.ToTable("OwnershipTeams");
            Code(e.Property(x => x.Code), 32);
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.Property(x => x.Description).HasMaxLength(512);
            e.HasIndex(x => new { x.TenantId, x.Code }).IsUnique();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Parent).WithMany().HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<CatalogApplication>(e =>
        {
            e.ToTable("Applications");
            Code(e.Property(x => x.Code), 32); e.HasIndex(x => x.Code).IsUnique();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasOne(x => x.OwnershipTeam).WithMany().HasForeignKey(x => x.OwnerTeamId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<ResourceType>(e =>
        {
            e.ToTable("ResourceTypes");
            Code(e.Property(x => x.Code), 32); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.Property(x => x.Description).HasMaxLength(512);
            e.Property(x => x.Color).HasMaxLength(24);
            Audit(e);
        });
        b.Entity<Scope>(e =>
        {
            e.ToTable("Scopes");
            Code(e.Property(x => x.Code), 32);
            e.HasIndex(x => new { x.ApplicationId, x.Code }).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.Property(x => x.Description).HasMaxLength(512);
            e.HasOne(x => x.Application).WithMany().HasForeignKey(x => x.ApplicationId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<Resource>(e =>
        {
            e.ToTable("Resources");
            e.Property(x => x.Code).HasMaxLength(128).IsRequired(); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(160).IsRequired();
            e.Property(x => x.Description).HasMaxLength(512);
            e.Property(x => x.ExternalCode).HasMaxLength(64);
            e.HasIndex(x => x.ApplicationId);
            e.HasIndex(x => new { x.ApplicationId, x.ExternalCode });
            e.HasOne(x => x.Application).WithMany().HasForeignKey(x => x.ApplicationId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ResourceType).WithMany().HasForeignKey(x => x.ResourceTypeId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Parent).WithMany().HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.OwnershipTeam).WithMany().HasForeignKey(x => x.OwnerTeamId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<ResourceScope>(e =>
        {
            e.ToTable("ResourceScopes");
            e.HasIndex(x => new { x.ResourceId, x.ScopeId }).IsUnique();
            e.HasOne(x => x.Resource).WithMany(r => r.Scopes).HasForeignKey(x => x.ResourceId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Scope).WithMany().HasForeignKey(x => x.ScopeId).OnDelete(DeleteBehavior.Restrict);
        });
        b.Entity<ResourceUri>(e =>
        {
            e.ToTable("ResourceUris");
            e.Property(x => x.Method).HasMaxLength(8).IsRequired();
            e.Property(x => x.Pattern).HasMaxLength(256).IsRequired();
            e.HasIndex(x => new { x.ResourceId, x.Method, x.Pattern }).IsUnique();
            e.HasOne(x => x.Resource).WithMany(r => r.Uris).HasForeignKey(x => x.ResourceId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Scope).WithMany().HasForeignKey(x => x.ScopeId).OnDelete(DeleteBehavior.Restrict);
        });
        b.Entity<InventorySnapshot>(e =>
        {
            e.ToTable("InventorySnapshots");
            e.Property(x => x.Source).HasMaxLength(128).IsRequired();
            e.Property(x => x.ImportedBy).HasMaxLength(64).IsRequired();
            e.HasIndex(x => new { x.ApplicationId, x.Kind }).IsUnique();   // uygulama + tür başına tek güncel görüntü
            e.HasOne(x => x.Application).WithMany().HasForeignKey(x => x.ApplicationId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<InventoryItem>(e =>
        {
            e.ToTable("InventoryItems");
            e.Property(x => x.Method).HasMaxLength(8);
            e.Property(x => x.Path).HasMaxLength(256);
            e.Property(x => x.Code).HasMaxLength(64);
            e.Property(x => x.Name).HasMaxLength(160);
            e.Property(x => x.ParentCode).HasMaxLength(64);
            e.Property(x => x.ElementType).HasMaxLength(32);
            e.Property(x => x.Description).HasMaxLength(512);
            e.HasIndex(x => x.SnapshotId);
            e.HasOne(x => x.Snapshot).WithMany(s => s.Items).HasForeignKey(x => x.SnapshotId).OnDelete(DeleteBehavior.Cascade);
        });

        // ---------------- Client ----------------
        b.Entity<ClientQueryApplication>(e =>
        {
            e.ToTable("ClientQueryApplications");
            e.HasKey(x => new { x.ClientId, x.ApplicationId });
            e.HasOne(x => x.Client).WithMany(c => c.QueryApplications).HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Application).WithMany().HasForeignKey(x => x.ApplicationId).OnDelete(DeleteBehavior.Restrict);
        });
        b.Entity<ClientQueryTenant>(e =>
        {
            e.ToTable("ClientQueryTenants");
            e.HasKey(x => new { x.ClientId, x.TenantId });
            e.HasOne(x => x.Client).WithMany(c => c.QueryTenants).HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
        });
        b.Entity<ClientDelegation>(e =>
        {
            e.ToTable("ClientDelegations");
            e.HasKey(x => new { x.ClientId, x.OnBehalfOfClientId });
            e.HasOne(x => x.Client).WithMany(c => c.Delegations).HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.OnBehalfOf).WithMany().HasForeignKey(x => x.OnBehalfOfClientId).OnDelete(DeleteBehavior.Restrict);
        });
        b.Entity<ClientSecret>(e =>
        {
            e.ToTable("ClientSecrets");
            e.Property(x => x.SecretHash).HasMaxLength(64).IsRequired();
            e.Property(x => x.Prefix).HasMaxLength(16).IsRequired();
            e.Property(x => x.Description).HasMaxLength(256);
            e.Property(x => x.CreatedBy).HasMaxLength(64).IsRequired();
            e.HasIndex(x => x.ClientId);
            e.HasIndex(x => x.SecretHash).IsUnique();
            e.HasOne(x => x.Client).WithMany(c => c.Secrets).HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<Client>(e =>
        {
            e.ToTable("Clients");
            e.Property(x => x.ClientId).HasMaxLength(64).IsRequired(); e.HasIndex(x => x.ClientId).IsUnique();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasOne(x => x.Application).WithMany().HasForeignKey(x => x.ApplicationId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ServiceAccountUser).WithMany().HasForeignKey(x => x.ServiceAccountUserId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });

        // ---------------- Rol ----------------
        b.Entity<Role>(e =>
        {
            e.ToTable("Roles");
            Code(e.Property(x => x.Code), 48); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<UserRole>(e =>
        {
            e.ToTable("UserRoles");
            e.HasKey(x => new { x.UserId, x.RoleId });
            e.HasIndex(x => x.RoleId);
            e.Property(x => x.Reason).HasMaxLength(256);
            e.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId);
            e.HasOne(x => x.Role).WithMany().HasForeignKey(x => x.RoleId);
            Assign(e);
        });

        // ---------------- Grup ----------------
        b.Entity<Group>(e =>
        {
            e.ToTable("Groups");
            Code(e.Property(x => x.Code), 48); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<GroupMember>(e =>
        {
            e.ToTable("GroupMembers");
            e.HasKey(x => new { x.GroupId, x.UserId });
            e.HasIndex(x => x.UserId);
            e.HasOne(x => x.Group).WithMany(g => g.Members).HasForeignKey(x => x.GroupId);
            e.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId);
            Assign(e);
        });
        b.Entity<GroupFilter>(e =>
        {
            e.ToTable("GroupFilters");
            e.Property(x => x.Description).HasMaxLength(256);
            e.HasOne(x => x.Group).WithMany(g => g.Filters).HasForeignKey(x => x.GroupId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<GroupFilterCriterion>(e =>
        {
            e.ToTable("GroupFilterCriteria");
            e.Property(x => x.Attribute).HasMaxLength(32).IsRequired();
            e.HasOne(x => x.GroupFilter).WithMany(f => f.Criteria).HasForeignKey(x => x.GroupFilterId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<GroupFilterValue>(e =>
        {
            e.ToTable("GroupFilterValues");
            e.Property(x => x.Value).HasMaxLength(128).IsRequired();
            e.HasIndex(x => new { x.CriterionId, x.Value }).IsUnique();
            e.HasOne(x => x.Criterion).WithMany(c => c.Values).HasForeignKey(x => x.CriterionId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<GroupRole>(e =>
        {
            e.ToTable("GroupRoles");
            e.HasKey(x => new { x.GroupId, x.RoleId });
            e.HasIndex(x => x.RoleId);
            e.HasOne(x => x.Group).WithMany(g => g.Roles).HasForeignKey(x => x.GroupId);
            e.HasOne(x => x.Role).WithMany().HasForeignKey(x => x.RoleId);
            Assign(e);
        });

        // ---------------- Policy / Permission ----------------
        b.Entity<Policy>(e =>
        {
            e.ToTable("Policies");
            Code(e.Property(x => x.Code), 64); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(160).IsRequired();
            e.Property(x => x.Description).HasMaxLength(512);
            e.Property(x => x.Version).IsConcurrencyToken();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<PolicyObligation>(e =>
        {
            e.ToTable("PolicyObligations");
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.HasOne(x => x.Policy).WithMany(p => p.Obligations).HasForeignKey(x => x.PolicyId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<PolicyObligationParameter>(e =>
        {
            e.ToTable("PolicyObligationParameters");
            e.Property(x => x.Key).HasMaxLength(64).IsRequired();
            e.Property(x => x.Value).HasMaxLength(512).IsRequired();
            e.HasIndex(x => new { x.ObligationId, x.Key }).IsUnique();
            e.HasOne(x => x.Obligation).WithMany(o => o.Parameters).HasForeignKey(x => x.ObligationId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<Rule>(e =>
        {
            e.ToTable("Rules");
            Code(e.Property(x => x.Code), 64);
            e.HasIndex(x => new { x.PolicyId, x.Code }).IsUnique();
            e.Property(x => x.Name).HasMaxLength(160).IsRequired();
            e.Property(x => x.ReasonCode).HasMaxLength(64);
            e.HasOne(x => x.Policy).WithMany(p => p.Rules).HasForeignKey(x => x.PolicyId).OnDelete(DeleteBehavior.Cascade);
            Audit(e);
        });
        b.Entity<RuleCondition>(e =>
        {
            // Reference düğümü ⇔ ReferencedPolicyId dolu (başka düğüm tipi policy'ye bağlanamaz)
            e.ToTable("RuleConditions", t => t.HasCheckConstraint("CK_RuleConditions_Reference",
                "(\"Kind\" = 5 AND \"ReferencedPolicyId\" IS NOT NULL) OR (\"Kind\" <> 5 AND \"ReferencedPolicyId\" IS NULL)"));
            e.HasIndex(x => x.RuleId);
            e.HasIndex(x => x.ReferencedPolicyId);
            e.HasOne(x => x.Rule).WithMany(r => r.Conditions).HasForeignKey(x => x.RuleId).OnDelete(DeleteBehavior.Cascade);
            // Kullanımdaki policy silinemez (önce referanslar kaldırılır)
            e.HasOne(x => x.ReferencedPolicy).WithMany().HasForeignKey(x => x.ReferencedPolicyId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Parent).WithMany(x => x.Children).HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ConditionType).WithMany().HasForeignKey(x => x.ConditionTypeId).OnDelete(DeleteBehavior.Restrict);
        });
        b.Entity<ConditionParameter>(e =>
        {
            e.ToTable("ConditionParameters");
            e.Property(x => x.Key).HasMaxLength(64).IsRequired();
            e.Property(x => x.Value).HasMaxLength(1024).IsRequired();
            e.HasIndex(x => new { x.ConditionId, x.Key }).IsUnique();
            e.HasOne(x => x.Condition).WithMany(c => c.Parameters).HasForeignKey(x => x.ConditionId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<ConditionType>(e =>
        {
            e.ToTable("ConditionTypes");
            Code(e.Property(x => x.Code), 64); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
        });
        b.Entity<Permission>(e =>
        {
            e.ToTable("Permissions");
            Code(e.Property(x => x.Code), 64); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(160).IsRequired();
            e.Property(x => x.Description).HasMaxLength(512);
            e.Property(x => x.Version).IsConcurrencyToken();
            e.HasOne(x => x.Application).WithMany().HasForeignKey(x => x.ApplicationId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ResourceType).WithMany().HasForeignKey(x => x.ResourceTypeId).OnDelete(DeleteBehavior.Restrict);
            // Tip hedefi ⇔ ResourceTypeId dolu (tip, başka hedef türünde "gizli" kapsam oluşturamasın)
            e.ToTable(t => t.HasCheckConstraint("CK_Permissions_Target",
                $"(\"Target\" = {(int)PermissionTarget.ResourceType} AND \"ResourceTypeId\" IS NOT NULL) OR (\"Target\" <> {(int)PermissionTarget.ResourceType} AND \"ResourceTypeId\" IS NULL)"));
            Audit(e);
        });
        b.Entity<PermissionResource>(e =>
        {
            e.ToTable("PermissionResources");
            e.HasKey(x => new { x.PermissionId, x.ResourceId });
            e.HasIndex(x => x.ResourceId);
            e.HasOne(x => x.Permission).WithMany(p => p.Resources).HasForeignKey(x => x.PermissionId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Resource).WithMany().HasForeignKey(x => x.ResourceId).OnDelete(DeleteBehavior.Restrict);
        });
        b.Entity<PermissionScope>(e =>
        {
            e.ToTable("PermissionScopes");
            e.HasKey(x => new { x.PermissionId, x.ScopeId });
            e.HasIndex(x => x.ScopeId);
            e.HasOne(x => x.Permission).WithMany(p => p.Scopes).HasForeignKey(x => x.PermissionId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Scope).WithMany().HasForeignKey(x => x.ScopeId).OnDelete(DeleteBehavior.Restrict);
        });
        b.Entity<PermissionPolicy>(e =>
        {
            e.ToTable("PermissionPolicies");
            e.HasKey(x => new { x.PermissionId, x.PolicyId });
            e.HasIndex(x => x.PolicyId);
            e.HasOne(x => x.Permission).WithMany(p => p.Policies).HasForeignKey(x => x.PermissionId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Policy).WithMany().HasForeignKey(x => x.PolicyId).OnDelete(DeleteBehavior.Restrict);
        });

        // ---------------- Yönetişim / olaylar / audit ----------------
        b.Entity<SodRule>(e =>
        {
            e.ToTable("SodRules");
            Code(e.Property(x => x.Code), 64); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(160).IsRequired();
            Audit(e);
        });
        b.Entity<SodRuleMember>(e =>
        {
            e.ToTable("SodRuleMembers");
            e.HasIndex(x => new { x.SodRuleId, x.MemberType, x.MemberId }).IsUnique();
            e.HasOne(x => x.SodRule).WithMany(r => r.Members).HasForeignKey(x => x.SodRuleId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<SodViolation>(e =>
        {
            e.ToTable("SodViolations");
            e.HasIndex(x => new { x.UserId, x.SodRuleId, x.Status });
            e.Property(x => x.Details).HasMaxLength(2048);
            e.HasOne(x => x.SodRule).WithMany().HasForeignKey(x => x.SodRuleId);
            e.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId);
        });
        b.Entity<ExternalSystem>(e =>
        {
            e.ToTable("ExternalSystems");
            Code(e.Property(x => x.Code), 32); e.HasIndex(x => x.Code).IsUnique();
            Audit(e);
        });
        b.Entity<ExternalPermission>(e =>
        {
            e.ToTable("ExternalPermissions");
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.Property(x => x.ResourceClass).HasMaxLength(32);
            e.HasIndex(x => new { x.ExternalSystemId, x.Code }).IsUnique();
            e.HasOne(x => x.ExternalSystem).WithMany(s => s.Permissions).HasForeignKey(x => x.ExternalSystemId);
            Audit(e);
        });
        b.Entity<ExternalPermissionRequirement>(e =>
        {
            e.ToTable("ExternalPermissionRequirements", t => t.HasCheckConstraint("CK_ExternalPermissionRequirements_NotSelf",
                "\"ExternalPermissionId\" <> \"RequiredExternalPermissionId\""));
            e.HasKey(x => new { x.ExternalPermissionId, x.RequiredExternalPermissionId });
            e.HasOne(x => x.ExternalPermission).WithMany(p => p.Requires).HasForeignKey(x => x.ExternalPermissionId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.RequiredExternalPermission).WithMany().HasForeignKey(x => x.RequiredExternalPermissionId).OnDelete(DeleteBehavior.Restrict);
            Assign(e);
        });
        b.Entity<ExternalDependency>(e =>
        {
            // Resource veya ResourceScope'tan TAM OLARAK BİRİ dolu
            e.ToTable("ExternalDependencies", t => t.HasCheckConstraint("CK_ExternalDependencies_Owner",
                "(CASE WHEN \"ResourceId\" IS NULL THEN 0 ELSE 1 END) + (CASE WHEN \"ResourceScopeId\" IS NULL THEN 0 ELSE 1 END) = 1"));
            e.HasOne(x => x.Resource).WithMany().HasForeignKey(x => x.ResourceId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ResourceScope).WithMany().HasForeignKey(x => x.ResourceScopeId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ExternalPermission).WithMany().HasForeignKey(x => x.ExternalPermissionId).OnDelete(DeleteBehavior.Restrict);
            e.HasIndex(x => new { x.ResourceId, x.ResourceScopeId, x.ExternalPermissionId }).IsUnique();
            e.Property(x => x.Note).HasMaxLength(256);
            Assign(e);
        });
        b.Entity<UserExternalGrant>(e =>
        {
            e.ToTable("UserExternalGrants");
            e.HasKey(x => new { x.UserId, x.ExternalPermissionId });
            e.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.ExternalPermission).WithMany().HasForeignKey(x => x.ExternalPermissionId).OnDelete(DeleteBehavior.Restrict);
            e.Property(x => x.ProvisionedBy).HasMaxLength(64);
        });
        b.Entity<OutboxEvent>(e =>
        {
            e.ToTable("OutboxEvents");
            e.HasKey(x => x.Id);
            e.Property(x => x.EventType).HasMaxLength(64).IsRequired();
            e.HasIndex(x => new { x.Status, x.OccurredAt });
        });
        b.Entity<ProvisioningAction>(e =>
        {
            e.ToTable("ProvisioningActions");
            e.Property(x => x.Reason).HasMaxLength(512);
            e.Property(x => x.ResourceClass).HasMaxLength(32);
            e.HasIndex(x => new { x.Status, x.CreatedAt });
            e.HasIndex(x => x.OutboxEventId);
        });
        b.Entity<AuditLog>(e =>
        {
            e.ToTable("AuditLogs");
            e.HasKey(x => x.Id);
            e.Property(x => x.Action).HasMaxLength(64).IsRequired();
            e.HasIndex(x => x.Timestamp);
            e.HasIndex(x => new { x.SubjectUserName, x.Timestamp });
            e.HasIndex(x => new { x.PermissionCode, x.Timestamp });
            e.HasIndex(x => x.CorrelationId);
        });
    }

    private static void Code(PropertyBuilder<string> p, int length) => p.HasMaxLength(length).IsRequired();

    private static void Audit<T>(EntityTypeBuilder<T> e) where T : AuditableEntity
    {
        e.Property(x => x.CreatedBy).HasMaxLength(64);
        e.Property(x => x.UpdatedBy).HasMaxLength(64);
    }

    private static void Assign<T>(EntityTypeBuilder<T> e) where T : class, IAssignment =>
        e.Property(x => x.AssignedBy).HasMaxLength(64);
}
