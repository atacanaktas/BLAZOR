using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Events;
using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Governance;

namespace Yetki.Pap.Infrastructure.Services;

public sealed class SystemClock : IClock
{
    public DateTime UtcNow => DateTime.UtcNow;
}

/// <summary>Arka plan işleri, seed ve testler için sabit aktör.</summary>
public sealed class SystemActor(string name = "system") : ICurrentActor
{
    public string Name { get; } = name;
}

/// <summary>Dummy provisioning adaptörü: gerçek RACF/LDAP çağrısı yapmaz, yapılacak komutu üretir. SystemCode "*" = fallback.</summary>
public sealed class DummyProvisioningAdapter(ILogger<DummyProvisioningAdapter> logger) : IProvisioningAdapter
{
    public string SystemCode => "*";
    public string Name => "DummyProvisioningAdapter";

    public Task<ProvisioningOutcome> ExecuteAsync(ProvisioningRequest r, CancellationToken ct)
    {
        var id = r.UserName.ToUpperInvariant();
        var level = (r.AccessLevel ?? ExternalAccessLevel.Read).ToString().ToUpperInvariant();
        var command = r.ExternalSystemCode.ToUpperInvariant() switch
        {
            // RACF: PERMIT profil CLASS(sınıf) ID(kullanıcı) ACCESS(seviye) · geri alma: DELETE · seviye değişimi: yeni ACCESS
            "RACF" => r.ActionType switch
            {
                ProvisioningActionType.Revoke => $"PERMIT {r.ExternalPermissionCode} CLASS({r.ResourceClass ?? "TCICSTRN"}) ID({id}) DELETE",
                _ => $"PERMIT {r.ExternalPermissionCode} CLASS({r.ResourceClass ?? "TCICSTRN"}) ID({id}) ACCESS({level})"
                     + (r.ActionType == ProvisioningActionType.Modify ? $"   /* {r.PreviousAccessLevel?.ToString().ToUpperInvariant()} → {level} */" : "")
            },
            "LDAP" => r.ActionType == ProvisioningActionType.Revoke
                ? $"REMOVE member uid={r.UserName} FROM {r.ExternalPermissionCode}"
                : $"ADD member uid={r.UserName} TO {r.ExternalPermissionCode}",
            _ => $"{r.ActionType} {r.ExternalPermissionCode} -> {r.UserName}"
        };
        logger.LogInformation("[DUMMY PROVISIONING] {System}: {Command} (sebep: {Reason})", r.ExternalSystemCode, command, r.Reason);
        return Task.FromResult(new ProvisioningOutcome(true, $"SİMÜLE EDİLDİ: {command}"));
    }
}

/// <summary>Tüm event'leri loglar (ilk consumer örneği). Bildirim/e-posta handler'ları aynı arayüzle eklenir.</summary>
public sealed class LoggingEventHandler(ILogger<LoggingEventHandler> logger) : IOutboxEventHandler
{
    public bool CanHandle(string eventType) => true;

    public Task HandleAsync(OutboxEvent evt, CancellationToken ct)
    {
        logger.LogInformation("[EVENT] {Type} {AggregateType}:{AggregateId} by {Actor}", evt.EventType, evt.AggregateType, evt.AggregateId, evt.Actor);
        return Task.CompletedTask;
    }
}

/// <summary>
/// Outbox tüketicisi (polling). İleride ayrı Provisioning Service'e veya broker'a (Kafka/RabbitMQ) publish eden relay'e dönüşebilir.
/// At-least-once: handler'lar idempotent olmalı (TODO: ProvisioningAction için idempotency key).
/// </summary>
public sealed class OutboxProcessor(IServiceScopeFactory scopes, ILogger<OutboxProcessor> logger) : BackgroundService
{
    private const int BatchSize = 50;
    private const int MaxAttempts = 5;
    private static readonly TimeSpan Interval = TimeSpan.FromSeconds(2);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try { await ProcessBatchAsync(stoppingToken); }
            catch (Exception ex) when (ex is not OperationCanceledException) { logger.LogError(ex, "Outbox batch failed"); }
            await Task.Delay(Interval, stoppingToken);
        }
    }

    public async Task<int> ProcessBatchAsync(CancellationToken ct)
    {
        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<IYetkiDbContext>();
        var handlers = scope.ServiceProvider.GetServices<IOutboxEventHandler>().ToList();
        var clock = scope.ServiceProvider.GetRequiredService<IClock>();

        var batch = await db.OutboxEvents.Where(e => e.Status == OutboxStatus.Pending).OrderBy(e => e.OccurredAt).Take(BatchSize).ToListAsync(ct);
        foreach (var evt in batch)
        {
            evt.Attempts++;
            try
            {
                foreach (var h in handlers.Where(h => h.CanHandle(evt.EventType))) await h.HandleAsync(evt, ct);
                evt.Status = OutboxStatus.Processed;
                evt.ProcessedAt = clock.UtcNow;
                evt.Error = null;
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogWarning(ex, "Outbox event {Id} ({Type}) failed, attempt {Attempt}", evt.Id, evt.EventType, evt.Attempts);
                evt.Error = ex.Message;
                if (evt.Attempts >= MaxAttempts) evt.Status = OutboxStatus.Failed;
            }
            await db.SaveChangesAsync(ct);
        }
        return batch.Count;
    }
}
