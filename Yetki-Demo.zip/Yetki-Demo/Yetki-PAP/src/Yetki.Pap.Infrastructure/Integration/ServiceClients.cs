using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Integration;

namespace Yetki.Pap.Infrastructure.Integration;

public sealed class PdpClientOptions
{
    public string BaseUrl { get; set; } = "http://localhost:5200";
    /// <summary>PDP analiz uçlarının servis anahtarı (X-Service-Key).</summary>
    public string ServiceKey { get; set; } = "";
    public int TimeoutSeconds { get; set; } = 60;
}

public sealed class PipClientOptions
{
    public string BaseUrl { get; set; } = "http://localhost:5300";
    public string ServiceKey { get; set; } = "";
    public int TimeoutSeconds { get; set; } = 15;
}

/// <summary>Uzak servis çağrılarının ortak kısmı: JSON, X-Actor iletimi, hata → PAP istisnası (aynı HTTP durumuyla istemciye döner).</summary>
public abstract class ServiceClientBase(HttpClient http, ICurrentActor actor, string serviceName)
{
    public static readonly JsonSerializerOptions Json = CreateJson();

    protected HttpClient Http => http;

    protected async Task<T> SendAsync<T>(HttpMethod method, string path, object? body, CancellationToken ct)
    {
        using var res = await SendRawAsync(method, path, body is null ? null : JsonSerializer.Serialize(body, Json), ct);
        await EnsureAsync(res, ct);
        if (res.StatusCode == HttpStatusCode.NoContent || typeof(T) == typeof(NoContent)) return default!;
        return await res.Content.ReadFromJsonAsync<T>(Json, ct) ?? throw new InvalidOperationException($"{serviceName} boş cevap döndü: {path}");
    }

    protected async Task<T?> GetOrNullAsync<T>(string path, CancellationToken ct) where T : class
    {
        using var res = await SendRawAsync(HttpMethod.Get, path, null, ct);
        if (res.StatusCode == HttpStatusCode.NotFound) return null;
        await EnsureAsync(res, ct);
        return await res.Content.ReadFromJsonAsync<T>(Json, ct);
    }

    protected async Task<HttpResponseMessage> SendRawAsync(HttpMethod method, string path, string? json, CancellationToken ct)
    {
        var req = new HttpRequestMessage(method, path.TrimStart('/'));
        req.Headers.Add("X-Actor", actor.Name);
        if (json is not null) req.Content = new StringContent(json, Encoding.UTF8, "application/json");
        try
        {
            return await http.SendAsync(req, ct);
        }
        catch (HttpRequestException ex)
        {
            throw new ServiceUnavailableException($"{serviceName} erişilemiyor ({http.BaseAddress}): {ex.Message}");
        }
    }

    /// <summary>Uzak ProblemDetails → aynı anlamdaki PAP istisnası (404 / 400 / 409); diğerleri 502.</summary>
    protected async Task EnsureAsync(HttpResponseMessage res, CancellationToken ct)
    {
        if (res.IsSuccessStatusCode) return;
        var body = await res.Content.ReadAsStringAsync(ct);
        string? detail = null;
        Dictionary<string, string[]>? errors = null;
        object? details = null;
        try
        {
            using var doc = JsonDocument.Parse(body);
            var root = doc.RootElement;
            detail = root.TryGetProperty("detail", out var d) ? d.GetString() : root.TryGetProperty("title", out var t) ? t.GetString() : null;
            if (root.TryGetProperty("errors", out var e) && e.ValueKind == JsonValueKind.Object)
                errors = e.Deserialize<Dictionary<string, string[]>>(Json);
            if (root.TryGetProperty("details", out var dt)) details = dt.Clone();
        }
        catch (JsonException) { }
        var message = detail ?? $"{serviceName} hatası ({(int)res.StatusCode})";
        throw res.StatusCode switch
        {
            HttpStatusCode.NotFound => new NotFoundException(message),
            HttpStatusCode.BadRequest => new ValidationException(message, errors),
            HttpStatusCode.Conflict => new ConflictException(message, details),
            _ => new ServiceUnavailableException($"{serviceName} hatası {(int)res.StatusCode}: {message}")
        };
    }

    private static JsonSerializerOptions CreateJson()
    {
        var o = new JsonSerializerOptions(JsonSerializerDefaults.Web) { DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull };
        o.Converters.Add(new JsonStringEnumConverter());
        return o;
    }

    protected sealed class NoContent;
}

/// <summary>Bağımlı servis (PDP / PIP) erişilemedi veya beklenmeyen hata verdi → 502.</summary>
public sealed class ServiceUnavailableException(string message) : Exception(message);

/// <summary>PDP analiz istemcisi. Etki analizi, doğrulama ve hesaplanan görünümler PDP'de (aynı karar modeli).</summary>
public sealed class HttpPdpClient(HttpClient http, ICurrentActor actor) : ServiceClientBase(http, actor, "PDP"), IPdpClient
{
    public Task<ChangeImpactResult> ImpactAsync(ImpactRequest request, CancellationToken ct) =>
        SendAsync<ChangeImpactResult>(HttpMethod.Post, "api/analysis/impact", request, ct);

    public Task<ConditionValidation> ValidateConditionAsync(ConditionDraft draft, int policyId, CancellationToken ct) =>
        SendAsync<ConditionValidation>(HttpMethod.Post, $"api/analysis/conditions/validate?policyId={policyId}", draft, ct);

    public Task<ObligationValidation> ValidateObligationAsync(string code, Dictionary<string, string> parameters, CancellationToken ct) =>
        SendAsync<ObligationValidation>(HttpMethod.Post, "api/analysis/obligations/validate", new { code, parameters }, ct);

    public async Task<string> ValidateGroupFiltersAsync(List<GroupFilterDraft> filters, CancellationToken ct) =>
        (await SendAsync<RuleView>(HttpMethod.Post, "api/analysis/group-filters/validate", filters, ct)).Rule;

    public Task<PermissionDraftInfo> PermissionDraftAsync(object draft, CancellationToken ct) =>
        SendAsync<PermissionDraftInfo>(HttpMethod.Post, "api/analysis/permission-draft", draft, ct);

    public async Task<IReadOnlyList<SodUserConflicts>> SodRulePreviewAsync(SodRulePreviewRequest request, CancellationToken ct) =>
        await SendAsync<List<SodUserConflicts>>(HttpMethod.Post, "api/analysis/sod/rule-preview", request, ct);

    public Task<SodDetectionResult> SodDetectAsync(CancellationToken ct) =>
        SendAsync<SodDetectionResult>(HttpMethod.Post, "api/analysis/sod/detect", new { }, ct);

    public Task<ExternalImpactResult> ExternalImpactAsync(ExternalCatalogPatch patch, CancellationToken ct) =>
        SendAsync<ExternalImpactResult>(HttpMethod.Post, "api/analysis/external/impact", patch, ct);

    public Task<UserExternalStatus> ExternalUserAsync(int userId, CancellationToken ct) =>
        SendAsync<UserExternalStatus>(HttpMethod.Get, $"api/analysis/external/users/{userId}", null, ct);

    public Task<DriftReport> ExternalDriftAsync(CancellationToken ct) =>
        SendAsync<DriftReport>(HttpMethod.Get, "api/analysis/views/external/drift", null, ct);

    public async Task<IReadOnlyList<UserExternalDesired>> ExternalDesiredAsync(IReadOnlyCollection<int>? userIds, CancellationToken ct) =>
        await SendAsync<List<UserExternalDesired>>(HttpMethod.Post, "api/analysis/external/desired", new { userIds }, ct);

    public Task<AudienceOverlapResult> AudienceOverlapAsync(AudienceOverlapRequest request, CancellationToken ct) =>
        SendAsync<AudienceOverlapResult>(HttpMethod.Post, "api/analysis/audiences/overlap", request, ct);

    public Task<AudienceCondition> AudienceConditionAsync(List<GroupFilterDraft> filters, CancellationToken ct) =>
        SendAsync<AudienceCondition>(HttpMethod.Post, "api/analysis/audiences/condition", filters, ct);

    public async Task<List<GroupFilterDraft>?> RuleAudienceAsync(int ruleId, CancellationToken ct) =>
        (await SendAsync<RuleAudienceView>(HttpMethod.Get, $"api/analysis/audiences/rules/{ruleId}", null, ct)).Filters;

    private sealed record RuleAudienceView(List<GroupFilterDraft>? Filters);

    public Task<JsonElement> SummaryAsync(CancellationToken ct) => SendAsync<JsonElement>(HttpMethod.Get, "api/analysis/summary", null, ct);

    public async Task<PdpResponse> ForwardAsync(HttpMethod method, string pathAndQuery, string? jsonBody, CancellationToken ct)
    {
        using var res = await SendRawAsync(method, pathAndQuery, jsonBody, ct);
        var body = await res.Content.ReadAsStringAsync(ct);
        return new PdpResponse((int)res.StatusCode, res.Content.Headers.ContentType?.ToString() ?? "application/json", body);
    }

    private sealed record RuleView(string Rule);
}

/// <summary>PIP (kimlik) istemcisi.</summary>
public sealed class HttpIdentityDirectory(HttpClient http, ICurrentActor actor) : ServiceClientBase(http, actor, "PIP"), IIdentityDirectory
{
    public Task<IdentityUser?> GetUserAsync(int id, CancellationToken ct) => GetOrNullAsync<IdentityUser>($"api/identity/users/{id}", ct);

    public Task<IdentityRole?> GetRoleAsync(int id, CancellationToken ct) => GetOrNullAsync<IdentityRole>($"api/identity/roles/{id}", ct);

    public async Task<IReadOnlyList<IdentityRole>> GetRolesAsync(CancellationToken ct) =>
        await SendAsync<List<IdentityRole>>(HttpMethod.Get, "api/identity/roles", null, ct);

    public async Task<IReadOnlyList<IdentityUserRole>> GetUserRolesAsync(int userId, CancellationToken ct) =>
        await SendAsync<List<IdentityUserRole>>(HttpMethod.Get, $"api/identity/users/{userId}/roles", null, ct);

    public async Task<IReadOnlyList<IdentityUserUnit>> GetUserUnitsAsync(int userId, CancellationToken ct) =>
        await SendAsync<List<IdentityUserUnit>>(HttpMethod.Get, $"api/identity/users/{userId}/units", null, ct);

    public async Task<IReadOnlyList<IdentityUnit>> GetUnitsAsync(int? tenantId, CancellationToken ct) =>
        await SendAsync<List<IdentityUnit>>(HttpMethod.Get, "api/identity/units" + (tenantId is { } t ? $"?tenantId={t}" : ""), null, ct);

    public Task<IdentityUser> CreateUserAsync(PipUserUpsert user, CancellationToken ct) =>
        SendAsync<IdentityUser>(HttpMethod.Post, "api/identity/users", user, ct);

    public Task<IdentityUser> UpdateUserAsync(int id, PipUserUpsert user, CancellationToken ct) =>
        SendAsync<IdentityUser>(HttpMethod.Put, $"api/identity/users/{id}", user, ct);

    public Task<IdentityRole> CreateRoleAsync(PipRoleUpsert role, CancellationToken ct) =>
        SendAsync<IdentityRole>(HttpMethod.Post, "api/identity/roles", role, ct);

    public Task<IdentityRole> UpdateRoleAsync(int id, PipRoleUpsert role, CancellationToken ct) =>
        SendAsync<IdentityRole>(HttpMethod.Put, $"api/identity/roles/{id}", role, ct);

    public Task AssignRoleAsync(int userId, int roleId, DateTime? validUntil, string? reason, CancellationToken ct) =>
        SendAsync<JsonElement>(HttpMethod.Post, $"api/identity/users/{userId}/roles", new { roleId, validUntil, reason }, ct);

    public Task RevokeRoleAsync(int userId, int roleId, CancellationToken ct) =>
        SendAsync<NoContent>(HttpMethod.Delete, $"api/identity/users/{userId}/roles/{roleId}", null, ct);

    public Task AddUserUnitAsync(int userId, int unitId, CancellationToken ct) =>
        SendAsync<JsonElement>(HttpMethod.Post, $"api/identity/users/{userId}/units/{unitId}", new { }, ct);

    public Task RemoveUserUnitAsync(int userId, int unitId, CancellationToken ct) =>
        SendAsync<NoContent>(HttpMethod.Delete, $"api/identity/users/{userId}/units/{unitId}", null, ct);

    public Task<IdentityUnit> CreateUnitAsync(PipUnitUpsert unit, CancellationToken ct) =>
        SendAsync<IdentityUnit>(HttpMethod.Post, "api/identity/units", unit, ct);
}
