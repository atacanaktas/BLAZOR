using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Yetki.Pap.Application;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Events;
using Yetki.Pap.Application.Integration;
using Yetki.Pap.Infrastructure.Integration;
using Yetki.Pap.Infrastructure.Persistence;
using Yetki.Pap.Infrastructure.Services;

namespace Yetki.Pap.Infrastructure;

public static class DependencyInjection
{
    /// <summary>
    /// Persistence:Provider
    ///  - "Sqlite" (varsayılan): ConnectionStrings:Yetki — PDP / PIP ile PAYLAŞILAN veritabanı; şemanın (migration'ların) sahibi PAP'tır.
    ///    Göreli yol <paramref name="basePath"/>'e göre çözülür.
    ///  - "InMemory": testler için.
    /// Pdp / Pip bölümleri: analiz ve kimlik servislerinin adresi ve servis anahtarı.
    /// </summary>
    public static IServiceCollection AddYetkiInfrastructure(this IServiceCollection services, IConfiguration config, string? basePath = null)
    {
        services.AddYetkiApplication();

        var provider = config["Persistence:Provider"] ?? "Sqlite";
        services.AddDbContext<YetkiDbContext>(options =>
        {
            switch (provider)
            {
                case "Sqlite":
                    options.UseSqlite(ResolveSqlite(config.GetConnectionString("Yetki") ?? "Data Source=yetki.db", basePath));
                    break;
                case "InMemory":
                    options.UseInMemoryDatabase(config["Persistence:InMemoryDatabaseName"] ?? "YetkiDb")
                           .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning));
                    break;
                default:
                    throw new InvalidOperationException($"Desteklenmeyen persistence provider: {provider}");
            }
        });
        services.AddScoped<IYetkiDbContext>(sp => sp.GetRequiredService<YetkiDbContext>());
        services.AddSingleton<IClock, SystemClock>();

        // PDP (analiz) ve PIP (kimlik) istemcileri
        services.Configure<PdpClientOptions>(config.GetSection("Pdp"));
        services.Configure<PipClientOptions>(config.GetSection("Pip"));
        services.AddHttpClient<IPdpClient, HttpPdpClient>((sp, c) =>
        {
            var o = sp.GetRequiredService<IOptions<PdpClientOptions>>().Value;
            c.BaseAddress = new Uri(o.BaseUrl.TrimEnd('/') + "/");
            c.Timeout = TimeSpan.FromSeconds(o.TimeoutSeconds);
            c.DefaultRequestHeaders.Add("X-Service-Key", o.ServiceKey);
        });
        services.AddHttpClient<IIdentityDirectory, HttpIdentityDirectory>((sp, c) =>
        {
            var o = sp.GetRequiredService<IOptions<PipClientOptions>>().Value;
            c.BaseAddress = new Uri(o.BaseUrl.TrimEnd('/') + "/");
            c.Timeout = TimeSpan.FromSeconds(o.TimeoutSeconds);
            c.DefaultRequestHeaders.Add("X-Service-Key", o.ServiceKey);
        });

        services.AddScoped<IProvisioningAdapter, DummyProvisioningAdapter>();
        services.AddScoped<IOutboxEventHandler, LoggingEventHandler>();
        // Outbox tüketicisi: sürekli çalışan hali ayrı süreçtir (Yetki.Pap.Worker); API sadece elle tetikler.
        services.AddSingleton<OutboxProcessor>();
        return services;
    }

    /// <summary>"Data Source=yetki.db" gibi göreli yolları verilen klasöre göre mutlak yapar (çalışma dizininden bağımsız).</summary>
    public static string ResolveSqlite(string connectionString, string? basePath)
    {
        var b = new SqliteConnectionStringBuilder(connectionString);
        if (basePath is not null && !string.IsNullOrWhiteSpace(b.DataSource) && b.DataSource != ":memory:" && !Path.IsPathRooted(b.DataSource))
            b.DataSource = Path.GetFullPath(Path.Combine(basePath, b.DataSource));
        return b.ToString();
    }

    /// <summary>
    /// Veritabanını hazırlar: ilişkisel sağlayıcıda bekleyen migration'ları uygular (mevcut veri korunur; dosya yoksa oluşturulur),
    /// InMemory'de şemayı kurar. Şemanın sahibi PAP'tır; PDP ve PIP migration çalıştırmaz. SEED YOKTUR:
    /// örnek veri ayrı araçla (tools/Yetki.Pap.SampleData) yedek.db olarak üretilir. Condition tipi kataloğunu PDP senkronlar.
    /// </summary>
    public static async Task InitializeYetkiDatabaseAsync(this IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var sp = scope.ServiceProvider;
        var db = sp.GetRequiredService<YetkiDbContext>();
        if (db.Database.IsRelational())
        {
            await db.Database.MigrateAsync();
            // EF Core yeni SQLite dosyasını WAL moduna alır (-wal/-shm yan dosyaları). Tek dosya modu (DELETE):
            // yedek.db → yetki.db kopyalamak güvenli olur, geride eski WAL kalıp veriyi bozamaz.
            if (db.Database.ProviderName == "Microsoft.EntityFrameworkCore.Sqlite")
                await db.Database.ExecuteSqlRawAsync("PRAGMA journal_mode=DELETE;");
        }
        else await db.Database.EnsureCreatedAsync();

        sp.GetRequiredService<ILoggerFactory>().CreateLogger("Yetki")
            .LogInformation("Yetki veritabanı hazır ({Provider}: {Source}).", db.Database.ProviderName, db.Database.IsRelational() ? db.Database.GetDbConnection().DataSource : "in-memory");
    }
}
