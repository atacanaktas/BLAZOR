using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Infrastructure;
using Yetki.Pap.Infrastructure.Services;

// PAP işçisi (ayrı süreç): outbox olaylarını işler. Erişimi değişen kullanıcılar ve dış bağımlılık değişiklikleri için
// RACF/LDAP mutabakatı: olması gereken durum PDP'den (analiz ucu), uygulama adaptörlerle, durum kaydı PAP veritabanında.
// Tetikleyiciler: PAP'taki yönetim değişiklikleri (outbox). İleride: İK (PIP) değişiklik olayları, süre dolumu.
var builder = Host.CreateApplicationBuilder(args);
builder.Services.AddYetkiInfrastructure(builder.Configuration, builder.Environment.ContentRootPath);
builder.Services.AddScoped<ICurrentActor>(_ => new SystemActor("pap-worker"));
builder.Services.AddHostedService(sp => sp.GetRequiredService<OutboxProcessor>());

var host = builder.Build();
host.Run();