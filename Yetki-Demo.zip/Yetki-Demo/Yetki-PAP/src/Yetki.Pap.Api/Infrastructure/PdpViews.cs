using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Yetki.Pap.Application.Integration;

namespace Yetki.Pap.Api.Infrastructure;

/// <summary>
/// Hesaplanan yönetim görünümleri PDP'dedir (derlenmiş yetki modeli: kimde var / neden, kapsam, etkin yetki, üyelik).
/// PAP bu ekranları aynı yol ve aynı JSON ile iletir: /api/&lt;x&gt; → PDP /api/analysis/views/&lt;x&gt;. PAP'ta ikinci bir motor yoktur.
/// </summary>
public static class PdpViews
{
    public static async Task<IActionResult> ViewAsync(this ControllerBase controller, IPdpClient pdp, CancellationToken ct)
    {
        var path = controller.Request.Path.Value ?? "";
        var rest = path.StartsWith("/api/", StringComparison.OrdinalIgnoreCase) ? path[5..] : path.TrimStart('/');
        return Result(await pdp.ForwardAsync(HttpMethod.Get, $"api/analysis/views/{rest}{controller.Request.QueryString}", null, ct));
    }

    /// <summary>PDP analiz ucuna gövdeyle iletir (konsol kararı, What-If, önizleme).</summary>
    public static async Task<IActionResult> AnalysisAsync(this ControllerBase controller, IPdpClient pdp, HttpMethod method, string path, object? body, CancellationToken ct) =>
        Result(await pdp.ForwardAsync(method, path, body is null ? null : JsonSerializer.Serialize(body, Yetki.Pap.Infrastructure.Integration.ServiceClientBase.Json), ct));

    public static IActionResult Result(PdpResponse r) =>
        new ContentResult { StatusCode = r.StatusCode, Content = r.Body, ContentType = r.ContentType };
}
