using System.Globalization;
using System.Text.Json.Serialization;
using Yetki.Pap.Api.Infrastructure;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Infrastructure;

// Türkçe kültürde sayı/tarih/büyük-küçük harf sürprizlerini önlemek için invariant.
CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.InvariantCulture;

var builder = WebApplication.CreateBuilder(args);

// PAP (yönetim). Veritabanı PDP / PIP ile paylaşılır (DataBase klasörü); şemanın (migration'ların) sahibi PAP'tır.
// Hesaplar PDP'de (Pdp bölümü), kimlik verisi PIP'te (Pip bölümü). Yönetim konsolu (Yetki-Web) SADECE PAP ile konuşur.
builder.Services.AddYetkiInfrastructure(builder.Configuration, builder.Environment.ContentRootPath);
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentActor, HttpCurrentActor>();

builder.Services.AddControllers(o => o.Filters.Add<ApiExceptionFilter>())
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        o.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "Yetki PAP", Version = "v1",
        Description = "Yönetim noktası: tanımlar, atamalar, SoD, dış sistemler, audit. Hesaplanan görünümler PDP'den, kimlik PIP'ten." });
    c.CustomSchemaIds(t => t.FullName!.Replace("+", "."));
});
builder.Services.AddCors(o => o.AddPolicy("web", p => p
    .WithOrigins(builder.Configuration.GetSection("Cors:Origins").Get<string[]>() ?? ["http://localhost:5180"])
    .AllowAnyHeader().AllowAnyMethod().WithExposedHeaders("ETag")));

var app = builder.Build();

await app.Services.InitializeYetkiDatabaseAsync(); // migration (şema sahibi PAP); seed YOK

app.UseSwagger();
app.UseSwaggerUI();
app.UseCors("web");
app.MapControllers();
app.MapGet("/", () => Results.Redirect("/swagger")).ExcludeFromDescription();

app.Run();

public partial class Program;
