using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Pap.Api.Infrastructure;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Changes;
using Yetki.Pap.Application.Definitions;
using Yetki.Pap.Application.Governance;
using Yetki.Pap.Application.Integration;
using Yetki.Pap.Domain.Common;
using Yetki.Pap.Infrastructure.Services;

namespace Yetki.Pap.Api.Controllers;

public sealed record ViolationUpdate(ViolationStatus Status, string? Note);

[ApiController]
[Route("api/sod")]
public sealed class SodController(IPdpClient pdp, GovernanceService governance, SodViolationService violations) : ControllerBase
{
    [HttpGet("rules")]
    public Task<IActionResult> Rules(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost("rules")]
    public Task<SodRuleCreated> Create(SodRuleUpsert dto, CancellationToken ct) => governance.CreateSodRuleAsync(dto, ct);

    [HttpPut("rules/{id:int}")]
    public Task Update(int id, SodRuleUpsert dto, CancellationToken ct) => governance.UpdateSodRuleAsync(id, dto, ct);

    [HttpGet("violations")]
    public Task<IActionResult> Violations(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPut("violations/{id:int}")]
    public Task UpdateViolation(int id, ViolationUpdate r, CancellationToken ct) => governance.UpdateViolationAsync(id, r.Status, r.Note, ct);

    /// <summary>Geriye dönük tarama: çakışma hesabı PDP'de, ihlal kayıtları PAP'ta.</summary>
    [HttpPost("scan")]
    public Task<SodScanResult> Scan(CancellationToken ct) => violations.ScanAsync(ct);
}

/// <summary>What-If: hesap PDP'de (aynı model kurucusu ve aynı karar motoru); PAP sadece iletir.</summary>
[ApiController]
[Route("api/simulation")]
public sealed class SimulationController(IPdpClient pdp, ChangeGate changes, ICurrentActor actor) : ControllerBase
{
    [HttpPost("changes")]
    public Task<ChangeImpactResult> Changes(AuthorizationChangeSet changeSet, CancellationToken ct) =>
        changes.PreviewAsync(new ImpactRequest { Changes = changeSet }, ct);

    /// <summary>Simüle karar: { request, changes?, policyChanges?, asOfUtc? } — audit'e simülasyon olarak, işlemi yapan kişiyle yazılır.</summary>
    [HttpPost("evaluate")]
    public Task<IActionResult> Evaluate(JsonObject body, CancellationToken ct)
    {
        body["isSimulation"] = true;
        body["actor"] = actor.Name;
        return this.AnalysisAsync(pdp, HttpMethod.Post, "api/analysis/decide", body, ct);
    }

    [HttpPost("policy-impact")]
    public Task<IActionResult> PolicyImpact(JsonObject body, CancellationToken ct) =>
        this.AnalysisAsync(pdp, HttpMethod.Post, "api/analysis/policy-impact", body, ct);

    [HttpPost("sod-rule")]
    public Task<IActionResult> SodRule(JsonObject body, CancellationToken ct) =>
        this.AnalysisAsync(pdp, HttpMethod.Post, "api/analysis/sod/rule-preview", body, ct);
}

/// <summary>
/// YÖNETİM KONSOLU karar uçları (Yetki testi, Gateway simülatörü, Nextral ekranı). Karar PDP'de verilir (analiz ucu);
/// motor token'ı istemez, soru kapsamı uygulanmaz; istenirse "caller" verilerek "şu client sorsaydı" kapsam kuralları da test edilir.
/// Kararlar audit'e "yetki-konsol" olarak yazılır.
/// PROTOTİP: Diğer yönetim uçları gibi korumasızdır; üretimde yönetim kimlik doğrulaması arkasında olmalı.
/// </summary>
[ApiController]
[Route("api/console")]
public sealed class ConsoleController(IPdpClient pdp) : ControllerBase
{
    [HttpPost("authorize")]
    public Task<IActionResult> Authorize(JsonObject request, CancellationToken ct) =>
        this.AnalysisAsync(pdp, HttpMethod.Post, "api/analysis/decide", new { request, actor = "yetki-konsol" }, ct);

    [HttpGet("entitlements/{user}")]
    public Task<IActionResult> Entitlements(string user, [FromQuery] string? client, [FromQuery] string? application,
        [FromQuery] bool evaluate = false, [FromQuery] string? ip = null, [FromQuery] string? caller = null, CancellationToken ct = default) =>
        this.AnalysisAsync(pdp, HttpMethod.Post, "api/analysis/entitlements", new
        {
            user, client, application, evaluate, caller,
            context = ip is null ? new Dictionary<string, string?>() : new Dictionary<string, string?> { ["IpAddress"] = ip }
        }, ct);
}

[ApiController]
[Route("api")]
public sealed class OperationsController(IYetkiDbContext db, IPdpClient pdp, OutboxProcessor outbox, IClock clock) : ControllerBase
{
    /// <summary>Özet: model sayıları PDP'den (yetki modeli), kararlar / değişiklikler / ihlaller / olaylar PAP kayıtlarından.</summary>
    [HttpGet("dashboard")]
    public async Task<object> Dashboard(CancellationToken ct)
    {
        var summary = await pdp.SummaryAsync(ct);
        var counts = summary.GetProperty("counts").Deserialize<Dictionary<string, JsonElement>>()!
            .ToDictionary(kv => kv.Key, kv => (object)kv.Value);
        counts["openViolations"] = await db.SodViolations.CountAsync(v => v.Status != ViolationStatus.Resolved, ct);
        counts["pendingEvents"] = await db.OutboxEvents.CountAsync(e => e.Status == OutboxStatus.Pending, ct);
        var since = clock.UtcNow.AddHours(-24);
        var decisions = await db.AuditLogs.AsNoTracking().Where(a => a.Category == AuditCategory.AuthorizationDecision && a.Timestamp >= since)
            .GroupBy(a => a.Decision).Select(g => new { decision = g.Key, count = g.Count() }).ToListAsync(ct);
        return new
        {
            modelVersion = summary.GetProperty("modelVersion"), modelBuiltAt = summary.GetProperty("modelBuiltAt"),
            counts,
            decisionsLast24h = decisions,
            recentDecisions = await db.AuditLogs.AsNoTracking().Where(a => a.Category == AuditCategory.AuthorizationDecision)
                .OrderByDescending(a => a.Timestamp).Take(10)
                .Select(a => new { a.Id, a.Timestamp, a.SubjectUserName, a.ClientId, a.PermissionCode, a.Decision, a.ReasonCode }).ToListAsync(ct),
            recentChanges = await db.AuditLogs.AsNoTracking().Where(a => a.Category == AuditCategory.Management)
                .OrderByDescending(a => a.Timestamp).Take(10).Select(a => new { a.Id, a.Timestamp, a.Actor, a.Action, a.Summary }).ToListAsync(ct)
        };
    }

    [HttpGet("version")]
    public async Task<object> Version(CancellationToken ct)
    {
        var summary = await pdp.SummaryAsync(ct);
        return new
        {
            modelVersion = summary.GetProperty("modelVersion"), builtAt = summary.GetProperty("modelBuiltAt"),
            pendingEvents = await db.OutboxEvents.CountAsync(e => e.Status == OutboxStatus.Pending, ct)
        };
    }

    [HttpGet("events")]
    public async Task<object> Events([FromQuery] int take = 200, CancellationToken ct = default) =>
        await db.OutboxEvents.AsNoTracking().OrderByDescending(e => e.OccurredAt).Take(Math.Clamp(take, 1, 1000))
            .Select(e => new { e.Id, e.EventType, e.AggregateType, e.AggregateId, e.OccurredAt, e.Actor, e.Status, e.Attempts, e.ProcessedAt, e.Error, e.PayloadJson })
            .ToListAsync(ct);

    /// <summary>Bekleyen olayları hemen işler (sürekli işleyen: Yetki.Pap.Worker).</summary>
    [HttpPost("events/process")]
    public async Task<object> Process(CancellationToken ct) => new { processed = await outbox.ProcessBatchAsync(ct) };

    [HttpGet("provisioning")]
    public async Task<object> Provisioning(CancellationToken ct) =>
        await db.ProvisioningActions.AsNoTracking().OrderByDescending(p => p.CreatedAt).Take(300).ToListAsync(ct);

    [HttpGet("audit")]
    public async Task<object> Audit([FromQuery] AuditCategory? category, [FromQuery] string? user, [FromQuery] string? permission, [FromQuery] string? q,
        [FromQuery] int take = 200, CancellationToken ct = default)
    {
        var query = db.AuditLogs.AsNoTracking().AsQueryable();
        if (category is not null) query = query.Where(a => a.Category == category);
        if (!string.IsNullOrWhiteSpace(user)) query = query.Where(a => a.SubjectUserName == user || a.Actor == user);
        if (!string.IsNullOrWhiteSpace(permission)) query = query.Where(a => a.PermissionCode == permission);
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(a => (a.Summary ?? "").Contains(q) || a.Action.Contains(q));
        return await query.OrderByDescending(a => a.Timestamp).Take(Math.Clamp(take, 1, 1000))
            .Select(a => new { a.Id, a.Timestamp, a.Category, a.Actor, a.Action, a.EntityType, a.EntityId, a.SubjectUserName, a.ClientId, a.PermissionCode, a.Decision, a.ReasonCode, a.Summary })
            .ToListAsync(ct);
    }

    [HttpGet("audit/{id:guid}")]
    public async Task<object> AuditDetail(Guid id, CancellationToken ct) =>
        await db.AuditLogs.AsNoTracking().FirstOrDefaultAsync(a => a.Id == id, ct) ?? throw new NotFoundException("Audit", id);

    /// <summary>UI seçim listeleri (PDP görünümü: users, roles, groups, tenants, units, applications, teams, resource-types, ...).</summary>
    [HttpGet("options/{kind}")]
    public Task<IActionResult> Options(string kind, CancellationToken ct) => this.ViewAsync(pdp, ct);
}
