using Microsoft.AspNetCore.Mvc;
using Yetki.Pap.Api.Infrastructure;
using Yetki.Pap.Application.External;
using Yetki.Pap.Application.Integration;

namespace Yetki.Pap.Api.Controllers;

/// <summary>
/// Dış sistemler (RACF / LDAP): tanımlar, katalog bağımlılıkları (resource / resource:scope → dış yetki), zincir,
/// kullanıcının olması gereken ↔ açık dış durumu, mutabakat (drift) ve provisioning.
/// Değiştiren uçlar <c>?dryRun=true</c> ile sadece etkiyi (kimde ne açılır/kapanır) döner. Hesaplar PDP'de, yürütme PAP'ta.
/// </summary>
[ApiController]
[Route("api/external")]
public sealed class ExternalController(IPdpClient pdp, ExternalDefinitionService definitions, ExternalProvisioningService provisioning) : ControllerBase
{
    [HttpGet("systems")]
    public Task<IActionResult> Systems(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost("systems")]
    public async Task<object> CreateSystem(ExternalSystemUpsert dto, CancellationToken ct) => new { (await definitions.CreateSystemAsync(dto, ct)).Id };

    [HttpPost("permissions")]
    public async Task<object> CreatePermission(ExternalPermissionUpsert dto, CancellationToken ct) => new { (await definitions.CreatePermissionAsync(dto, ct)).Id };

    /// <summary>Zincir: bu dış yetkiyi alan kullanıcıya gerekli dış yetki de verilir.</summary>
    [HttpPost("permissions/{id:int}/requires")]
    public Task<ExternalImpactResult> AddRequirement(int id, ExternalRequirementUpsert dto, [FromQuery] bool dryRun, CancellationToken ct) =>
        definitions.SetRequirementAsync(id, dto, true, dryRun, ct);

    [HttpDelete("permissions/{id:int}/requires/{requiredId:int}")]
    public Task<ExternalImpactResult> RemoveRequirement(int id, int requiredId, [FromQuery] bool dryRun, CancellationToken ct) =>
        definitions.SetRequirementAsync(id, new ExternalRequirementUpsert { RequiredExternalPermissionId = requiredId }, false, dryRun, ct);

    /// <summary>Bağımlılıklar (filtre: resourceId, resourceScopeId; forResource = resource'un kendisi + scope'larınınki). Sahibi açıklamasıyla.</summary>
    [HttpGet("dependencies")]
    public Task<IActionResult> Dependencies(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost("dependencies")]
    public Task<ExternalImpactResult> AddDependency(ExternalDependencyUpsert dto, [FromQuery] bool dryRun, CancellationToken ct) =>
        definitions.AddDependencyAsync(dto, dryRun, ct);

    [HttpDelete("dependencies/{id:int}")]
    public Task<ExternalImpactResult> RemoveDependency(int id, [FromQuery] bool dryRun, CancellationToken ct) =>
        definitions.RemoveDependencyAsync(id, dryRun, ct);

    /// <summary>Mutabakat raporu: olması gereken ile dış sistemde açık olan arasında farkı olan kullanıcılar.</summary>
    [HttpGet("drift")]
    public Task<IActionResult> Drift(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost("reconcile")]
    public async Task<object> ReconcileAll(CancellationToken ct) => new { actions = await provisioning.ReconcileAllAsync(null, ct) };

    /// <summary>
    /// Baseline: dış sistemdeki mevcut durumun olması gerekenle aynı olduğu kabul edilir (komut gönderilmez).
    /// İlk kurulumda / RACF'ten durum içe aktarıldığında kullanılır; sonraki değişiklikler sadece fark üretir.
    /// </summary>
    [HttpPost("baseline")]
    public async Task<object> Baseline(CancellationToken ct)
    {
        await provisioning.BaselineAsync(ct);
        return new { message = "Dış sistem durumu olması gereken durumla eşitlendi (komut gönderilmedi)." };
    }

    // ------------------------------ Kullanıcı ------------------------------

    [HttpGet("/api/users/{id:int}/external")]
    public Task<IActionResult> UserStatus(int id, CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost("/api/users/{id:int}/external/reconcile")]
    public async Task<object> ReconcileUser(int id, CancellationToken ct)
    {
        var actions = await provisioning.ReconcileUserAsync(id, null, ct);
        return new { count = actions.Count, actions = actions.Select(a => new { a.ActionType, a.ExternalSystemCode, a.ExternalPermissionCode, a.AccessLevel, a.Status, a.ResultMessage }) };
    }
}
