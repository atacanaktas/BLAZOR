using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Pap.Api.Infrastructure;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Definitions;
using Yetki.Pap.Application.Integration;

namespace Yetki.Pap.Api.Controllers;

/// <summary>Policy'ler (KİM / HANGİ KOŞULDA?): rol, grup, kullanıcı, client, condition (ABAC), aggregate. Görünümler PDP'de.</summary>
[ApiController]
[Route("api/policies")]
public sealed class PoliciesController(IPdpClient pdp, PolicyManagementService service, IYetkiDbContext db) : ControllerBase
{
    [HttpGet]
    public Task<IActionResult> List(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpGet("{id:int}")]
    public Task<IActionResult> Detail(int id, CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost]
    public Task<DefinitionChangeResult> Create(PolicyUpsert dto, CancellationToken ct) => service.CreatePolicyAsync(dto, ct);

    /// <summary>?dryRun=true: sadece erişim etkisi (kim kazanır / kaybeder, SoD, RACF) döner.</summary>
    [HttpPut("{id:int}")]
    public Task<DefinitionChangeResult> Update(int id, PolicyUpsert dto, [FromQuery] bool dryRun, [FromQuery] long? expectedModelVersion, CancellationToken ct) => service.UpdatePolicyAsync(id, dto, dryRun, expectedModelVersion, ct);

    [HttpDelete("{id:int}")]
    public Task Delete(int id, CancellationToken ct) => service.DeletePolicyAsync(id, ct);

    [HttpPost("{id:int}/obligations")]
    public Task<DefinitionChangeResult> AddObligation(int id, ObligationUpsert dto, [FromQuery] bool dryRun, [FromQuery] long? expectedModelVersion, CancellationToken ct) =>
        service.AddObligationAsync(id, dto, dryRun, expectedModelVersion, ct);

    [HttpDelete("/api/policy-obligations/{obligationId:int}")]
    public Task<DefinitionChangeResult> RemoveObligation(int obligationId, [FromQuery] bool dryRun, [FromQuery] long? expectedModelVersion, CancellationToken ct) =>
        service.RemoveObligationAsync(obligationId, dryRun, expectedModelVersion, ct);

    /// <summary>Yükümlülük tipleri (PDP koddaki katalog; PEP bunları yerine getirir).</summary>
    [HttpGet("/api/obligation-types")]
    public Task<IActionResult> ObligationTypes(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost("{id:int}/rules")]
    public Task<DefinitionChangeResult> CreateRule(int id, RuleUpsert dto, [FromQuery] long? expectedModelVersion, CancellationToken ct) => service.CreateRuleAsync(id, dto, expectedModelVersion, ct);

    [HttpPut("/api/rules/{ruleId:int}")]
    public Task<DefinitionChangeResult> UpdateRule(int ruleId, RuleUpsert dto, [FromQuery] long? expectedModelVersion, CancellationToken ct) => service.UpdateRuleAsync(ruleId, dto, expectedModelVersion, ct);

    [HttpDelete("/api/rules/{ruleId:int}")]
    public Task<DefinitionChangeResult> DeleteRule(int ruleId, [FromQuery] long? expectedModelVersion, CancellationToken ct) => service.DeleteRuleAsync(ruleId, expectedModelVersion, ct);

    [HttpGet("/api/rules")]
    public Task<IActionResult> AllRules(CancellationToken ct) => this.ViewAsync(pdp, ct);

    /// <summary>
    /// Condition tipi kataloğu (PDP açılışta koddaki handler'lardan senkronlar). Question: policy ekranındaki soru kartı
    /// (KİM, NEREDEN...); IsIdentity: kimlik koşulu (istek olmadan kesin çözülür).
    /// </summary>
    [HttpGet("/api/condition-types")]
    public async Task<object> ConditionTypes(CancellationToken ct) =>
        await db.ConditionTypes.AsNoTracking().OrderBy(t => t.Code)
            .Select(t => new { t.Id, t.Code, t.Name, t.Description, t.DefaultScope, t.ParameterSchemaJson, t.RequiredAttributes, t.IsAvailable, t.IsSubjectOnly, t.Question, t.IsIdentity })
            .ToListAsync(ct);
}

/// <summary>
/// Kitle = grup kuralı = KİM kartı. Örtüşme kontrolü (tanım aynı → öneri, sadece üyeler aynı → bilgi),
/// KİM kartını gruba çevirme ve tek kullanımlık grubu karta geri alma. ?dryRun=true: sadece etki (erişim değişmemeli).
/// </summary>
[ApiController]
[Route("api/audiences")]
public sealed class AudiencesController(AudienceService service) : ControllerBase
{
    [HttpPost("overlap")]
    public Task<AudienceOverlapResult> Overlap(AudienceOverlapRequest request, CancellationToken ct) => service.OverlapAsync(request, ct);

    [HttpPost("promote")]
    public Task<AudienceChangeResult> Promote(AudiencePromote dto, [FromQuery] bool dryRun, CancellationToken ct) => service.PromoteAsync(dto, dryRun, ct);

    [HttpPost("demote")]
    public Task<AudienceChangeResult> Demote(AudienceDemote dto, [FromQuery] bool dryRun, CancellationToken ct) => service.DemoteAsync(dto, dryRun, ct);
}

/// <summary>Keycloak permission'ları: HANGİ resource/scope'u HANGİ policy'lerle koruyorum?</summary>
[ApiController]
[Route("api/permissions")]
public sealed class PermissionsController(IPdpClient pdp, PermissionService service) : ControllerBase
{
    [HttpGet]
    public Task<IActionResult> List(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpGet("{id:int}")]
    public Task<IActionResult> Detail(int id, CancellationToken ct) => this.ViewAsync(pdp, ct);

    /// <summary>?dryRun=true: sadece erişim etkisi döner (kaydetmez).</summary>
    [HttpPost]
    public Task<DefinitionChangeResult> Create(PermissionUpsert dto, [FromQuery] bool dryRun, [FromQuery] long? expectedModelVersion, CancellationToken ct) => service.CreateAsync(dto, dryRun, expectedModelVersion, ct);

    [HttpPut("{id:int}")]
    public Task<DefinitionChangeResult> Update(int id, PermissionUpsert dto, [FromQuery] bool dryRun, [FromQuery] long? expectedModelVersion, CancellationToken ct) => service.UpdateAsync(id, dto, dryRun, expectedModelVersion, ct);

    [HttpDelete("{id:int}")]
    public Task<DefinitionChangeResult> Delete(int id, [FromQuery] bool dryRun, [FromQuery] long? expectedModelVersion, CancellationToken ct) => service.DeleteAsync(id, dryRun, expectedModelVersion, ct);
}
