using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Pap.Api.Infrastructure;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Definitions;
using Yetki.Pap.Application.Integration;

namespace Yetki.Pap.Api.Controllers;

/// <summary>
/// Yetki tanımları: Tenant → Uygulama (resource server) → resource (tipiyle) → scope'lar (yetkiler) + URI eşlemeleri.
/// Ayrı bir katalog / seviye yoktur; gruplama türetilir (HTTP'de URL kırılımı, UI'da üst-alt). Tanımsız URI'ye gelen istek reddedilir.
/// Yazma PAP'ta; modelden hesaplanan okuma ekranları (ağaç, kapsam, sahipler) PDP görünümleridir.
/// </summary>
[ApiController]
[Route("api/resources")]
public sealed class ResourcesController(IPdpClient pdp, CatalogService catalog, IYetkiDbContext db) : ControllerBase
{
    /// <summary>Tenant → uygulama → resource listesi. Ağaç (URL kırılımı / üst-alt) istemcide bu listeden kurulur.</summary>
    [HttpGet("tree")]
    public Task<IActionResult> Tree(CancellationToken ct) => this.ViewAsync(pdp, ct);

    // ------------------------------ Uygulama ------------------------------

    [HttpGet("/api/applications")]
    public async Task<object> Applications(CancellationToken ct) =>
        await db.Applications.AsNoTracking().OrderBy(a => a.Id).Select(a => new
        {
            a.Id, a.Code, a.Name, a.Type, a.Description, a.OwnerTeamId, ownerTeam = a.OwnershipTeam != null ? a.OwnershipTeam.Name : null,
            a.OwnerUserId, a.IsActive, a.TenantId, tenant = a.Tenant.Code, a.DecisionStrategy
        }).ToListAsync(ct);

    [HttpGet("/api/applications/{id:int}")]
    public Task<IActionResult> Application(int id, CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost("/api/applications")]
    public async Task<object> CreateApplication(ApplicationUpsert dto, CancellationToken ct) => new { (await catalog.CreateApplicationAsync(dto, ct)).Id };

    [HttpPut("/api/applications/{id:int}")]
    public Task<ChangeImpactResult> UpdateApplication(int id, ApplicationUpsert dto, CancellationToken ct) => catalog.UpdateApplicationAsync(id, dto, ct);

    [HttpDelete("/api/applications/{id:int}")]
    public Task DeleteApplication(int id, CancellationToken ct) => catalog.DeleteApplicationAsync(id, ct);

    // ------------------------------ Resource tipi ------------------------------

    [HttpGet("/api/resource-types")]
    public Task<IActionResult> ResourceTypes(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost("/api/resource-types")]
    public async Task<object> CreateResourceType(ResourceTypeUpsert dto, CancellationToken ct) => new { (await catalog.CreateResourceTypeAsync(dto, ct)).Id };

    [HttpPut("/api/resource-types/{id:int}")]
    public Task<ChangeImpactResult> UpdateResourceType(int id, ResourceTypeUpsert dto, CancellationToken ct) => catalog.UpdateResourceTypeAsync(id, dto, ct);

    [HttpDelete("/api/resource-types/{id:int}")]
    public Task DeleteResourceType(int id, CancellationToken ct) => catalog.DeleteResourceTypeAsync(id, ct);

    // ------------------------------ Scope ------------------------------

    [HttpGet("/api/scopes")]
    public Task<IActionResult> Scopes(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost("/api/scopes")]
    public async Task<object> CreateScope(ScopeUpsert dto, CancellationToken ct) => new { (await catalog.CreateScopeAsync(dto, ct)).Id };

    [HttpPut("/api/scopes/{id:int}")]
    public Task UpdateScope(int id, ScopeUpsert dto, CancellationToken ct) => catalog.UpdateScopeAsync(id, dto, ct);

    [HttpDelete("/api/scopes/{id:int}")]
    public Task DeleteScope(int id, CancellationToken ct) => catalog.DeleteScopeAsync(id, ct);

    // ------------------------------ Resource ------------------------------

    /// <summary>Resource detayı: scope'lar (yetkiler) ve her birini koruyan permission'lar, URI eşlemeleri, üst/alt resource'lar.</summary>
    [HttpGet("{id:int}")]
    public Task<IActionResult> Resource(int id, CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost]
    public async Task<object> CreateResource(ResourceUpsert dto, CancellationToken ct)
    {
        var (r, impact) = await catalog.CreateResourceAsync(dto, ct);
        return new { r.Id, r.Code, impact };
    }

    [HttpPut("{id:int}")]
    public Task<ChangeImpactResult> UpdateResource(int id, ResourceUpsert dto, CancellationToken ct) => catalog.UpdateResourceAsync(id, dto, ct);

    [HttpDelete("{id:int}")]
    public Task DeleteResource(int id, CancellationToken ct) => catalog.DeleteResourceAsync(id, ct);

    [HttpPost("{id:int}/uris")]
    public async Task<object> AddUri(int id, UriUpsert dto, CancellationToken ct) => new { (await catalog.AddUriAsync(id, dto, ct)).Id };

    [HttpPut("/api/resource-uris/{id:int}")]
    public Task UpdateUri(int id, UriUpsert dto, CancellationToken ct) => catalog.UpdateUriAsync(id, dto, ct);

    [HttpDelete("/api/resource-uris/{id:int}")]
    public Task DeleteUri(int id, CancellationToken ct) => catalog.DeleteUriAsync(id, ct);

    /// <summary>URI eşleştirme testi: bu METHOD + path hangi yetkiye eşlenir? (karar vermez, katalog kontrolü)</summary>
    [HttpGet("/api/uri-match")]
    public Task<IActionResult> MatchUri(CancellationToken ct) => this.ViewAsync(pdp, ct);
}

/// <summary>Yetkiler (resource:scope) — rol/grup/kullanıcıya permission'lar üzerinden verilen birim. Görünümler PDP'de.</summary>
[ApiController]
[Route("api/resource-scopes")]
public sealed class ResourceScopesController(IPdpClient pdp) : ControllerBase
{
    [HttpGet]
    public Task<IActionResult> List(CancellationToken ct) => this.ViewAsync(pdp, ct);

    /// <summary>"Kimde var, neden?" — etkin sahipler ve kaynak yolları.</summary>
    [HttpGet("{id:int}/holders")]
    public Task<IActionResult> Holders(int id, CancellationToken ct) => this.ViewAsync(pdp, ct);

    /// <summary>Yetkinin dış gereksinimleri (doğrudan + resource mirası + zincir) ve ilgili bağımlılıklar.</summary>
    [HttpGet("{id:int}/external")]
    public Task<IActionResult> External(int id, CancellationToken ct) => this.ViewAsync(pdp, ct);
}

[ApiController]
[Route("api/ownership-teams")]
public sealed class OwnershipTeamsController(IYetkiDbContext db, OwnershipTeamService service) : ControllerBase
{
    [HttpGet]
    public async Task<object> List([FromQuery] int? tenantId, CancellationToken ct) =>
        await db.OwnershipTeams.AsNoTracking()
            .Where(t => tenantId == null || t.TenantId == tenantId)
            .OrderBy(t => t.Tenant.Code).ThenBy(t => t.Code)
            .Select(t => new
            {
                t.Id, t.TenantId, tenant = t.Tenant.Code, t.Code, t.Name, t.Description, t.IsActive,
                t.ParentId, parent = t.Parent != null ? t.Parent.Code : null,
                applicationCount = db.Applications.Count(a => a.OwnerTeamId == t.Id),
                resourceCount = db.Resources.Count(r => r.OwnerTeamId == t.Id),
                childTeamCount = db.OwnershipTeams.Count(c => c.ParentId == t.Id)
            }).ToListAsync(ct);

    [HttpPost]
    public async Task<object> Create(OwnershipTeamUpsert dto, CancellationToken ct) =>
        new { (await service.CreateAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task Update(int id, OwnershipTeamUpsert dto, CancellationToken ct) => service.UpdateAsync(id, dto, ct);

    [HttpDelete("{id:int}")]
    public Task Delete(int id, CancellationToken ct) => service.DeleteAsync(id, ct);
}

[ApiController]
[Route("api/clients")]
public sealed class ClientsController(IPdpClient pdp, ClientService clients, ClientCredentialService credentials) : ControllerBase
{
    [HttpGet]
    public Task<IActionResult> List(CancellationToken ct) => this.ViewAsync(pdp, ct);

    // ------------------------------ Motor kimlik bilgileri (secret) ------------------------------

    [HttpGet("{id:int}/secrets")]
    public Task<IReadOnlyList<ClientSecretView>> Secrets(int id, CancellationToken ct) => credentials.ListAsync(id, ct);

    /// <summary>Yeni secret: düz metin sadece bu cevapta döner.</summary>
    [HttpPost("{id:int}/secrets")]
    public Task<CreatedClientSecret> CreateSecret(int id, ClientSecretCreate dto, CancellationToken ct) => credentials.CreateAsync(id, dto, ct);

    [HttpDelete("{id:int}/secrets/{secretId:int}")]
    public Task RevokeSecret(int id, int secretId, CancellationToken ct) => credentials.RevokeAsync(id, secretId, ct);

    [HttpPost]
    public async Task<object> Create(ClientUpsert dto, CancellationToken ct) => new { (await clients.CreateAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task Update(int id, ClientUpsert dto, CancellationToken ct) => clients.UpdateAsync(id, dto, ct);

    [HttpDelete("{id:int}")]
    public Task Delete(int id, CancellationToken ct) => clients.DeleteAsync(id, ct);
}
