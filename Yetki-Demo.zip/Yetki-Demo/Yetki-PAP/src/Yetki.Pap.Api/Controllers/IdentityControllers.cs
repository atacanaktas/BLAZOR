using Microsoft.AspNetCore.Mvc;
using Yetki.Pap.Api.Infrastructure;
using Yetki.Pap.Application.Changes;
using Yetki.Pap.Application.Definitions;
using Yetki.Pap.Application.Integration;

namespace Yetki.Pap.Api.Controllers;

// ================================ Kurum ================================

[ApiController]
[Route("api")]
public sealed class TenantsController(IPdpClient pdp, TenantService service) : ControllerBase
{
    [HttpGet("tenants")]
    public Task<IActionResult> List(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpGet("org-units")]
    public Task<IActionResult> Units(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost("tenants")]
    public async Task<object> Create(TenantUpsert dto, CancellationToken ct) => new { (await service.CreateAsync(dto, ct)).Id };

    /// <summary>Birim İK verisidir: PIP'e yazılır.</summary>
    [HttpPost("org-units")]
    public async Task<object> CreateUnit(OrgUnitUpsert dto, CancellationToken ct) => new { (await service.CreateUnitAsync(dto, ct)).Id };
}

// ================================ Kullanıcı (kimlik verisi PIP'te) ================================

public sealed record RoleAssignRequest(int RoleId, DateTime? ValidUntil, string? Reason);

[ApiController]
[Route("api/users")]
public sealed class UsersController(IPdpClient pdp, AssignmentService assignments) : ControllerBase
{
    [HttpGet]
    public Task<IActionResult> List(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpGet("{id:int}")]
    public Task<IActionResult> Detail(int id, CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpGet("{id:int}/effective")]
    public Task<IActionResult> Effective(int id, CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpGet("{id:int}/entitlements")]
    public Task<IActionResult> Entitlements(int id, CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost]
    public async Task<object> Create(UserUpsert dto, CancellationToken ct) => new { (await assignments.CreateUserAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task<ChangeImpactResult> Update(int id, UserUpsert dto, CancellationToken ct) => assignments.UpdateUserAsync(id, dto, ct);

    [HttpPost("{id:int}/roles")]
    public Task<ChangeImpactResult> AssignRole(int id, RoleAssignRequest r, CancellationToken ct) => assignments.AssignRoleAsync(id, r.RoleId, r.ValidUntil, r.Reason, ct);

    [HttpDelete("{id:int}/roles/{roleId:int}")]
    public Task<ChangeImpactResult> RevokeRole(int id, int roleId, CancellationToken ct) => assignments.RevokeRoleAsync(id, roleId, ct);

    [HttpPost("{id:int}/units/{unitId:int}")]
    public Task<ChangeImpactResult> AddUnit(int id, int unitId, CancellationToken ct) => assignments.SetUserUnitAsync(id, unitId, true, ct);

    [HttpDelete("{id:int}/units/{unitId:int}")]
    public Task<ChangeImpactResult> RemoveUnit(int id, int unitId, CancellationToken ct) => assignments.SetUserUnitAsync(id, unitId, false, ct);
}

// ================================ Rol (kimlik verisi PIP'te) ================================

[ApiController]
[Route("api/roles")]
public sealed class RolesController(IPdpClient pdp, AssignmentService assignments) : ControllerBase
{
    [HttpGet]
    public Task<IActionResult> List(CancellationToken ct) => this.ViewAsync(pdp, ct);

    /// <summary>Rol detayı: rolü üye alan policy'ler → onları kullanan permission'lar → kapsadıkları yetkiler; rol sahipleri.</summary>
    [HttpGet("{id:int}")]
    public Task<IActionResult> Detail(int id, CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpPost]
    public async Task<object> Create(RoleUpsert dto, CancellationToken ct) => new { (await assignments.CreateRoleAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task<ChangeImpactResult> Update(int id, RoleUpsert dto, CancellationToken ct) => assignments.UpdateRoleAsync(id, dto, ct);
}

// ================================ Grup ================================

public sealed record MemberRequest(DateTime? ValidUntil);
public sealed record GroupPreviewRequest(int TenantId, List<GroupFilterDraft> Filters, List<int>? ExplicitMemberIds);

[ApiController]
[Route("api/groups")]
public sealed class GroupsController(IPdpClient pdp, AssignmentService assignments) : ControllerBase
{
    [HttpGet]
    public Task<IActionResult> List(CancellationToken ct) => this.ViewAsync(pdp, ct);

    [HttpGet("{id:int}")]
    public Task<IActionResult> Detail(int id, CancellationToken ct) => this.ViewAsync(pdp, ct);

    /// <summary>Kaydetmeden önce: bu kurallarla kimler üye olurdu? (PDP'de canlı önizleme; aynı kriter handler'ları, doğrulama dahil)</summary>
    [HttpPost("preview")]
    public Task<IActionResult> Preview(GroupPreviewRequest r, CancellationToken ct) =>
        this.AnalysisAsync(pdp, HttpMethod.Post, "api/analysis/group-preview", r, ct);

    [HttpPost]
    public async Task<object> Create(GroupUpsert dto, CancellationToken ct) => new { (await assignments.CreateGroupAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task<ChangeImpactResult> Update(int id, GroupUpsert dto, CancellationToken ct) => assignments.UpdateGroupAsync(id, dto, ct);

    [HttpPut("{id:int}/filters")]
    public Task<ChangeImpactResult> ReplaceFilters(int id, List<GroupFilterDraft> filters, CancellationToken ct) => assignments.ReplaceGroupFiltersAsync(id, filters, ct);

    [HttpPost("{id:int}/members/{userId:int}")]
    public Task<ChangeImpactResult> AddMember(int id, int userId, MemberRequest? r, CancellationToken ct) => assignments.SetGroupMemberAsync(id, userId, true, r?.ValidUntil, ct);

    [HttpDelete("{id:int}/members/{userId:int}")]
    public Task<ChangeImpactResult> RemoveMember(int id, int userId, CancellationToken ct) => assignments.SetGroupMemberAsync(id, userId, false, null, ct);

    [HttpPost("{id:int}/roles/{roleId:int}")]
    public Task<ChangeImpactResult> AddRole(int id, int roleId, CancellationToken ct) => assignments.SetGroupRoleAsync(id, roleId, true, ct);

    [HttpDelete("{id:int}/roles/{roleId:int}")]
    public Task<ChangeImpactResult> RemoveRole(int id, int roleId, CancellationToken ct) => assignments.SetGroupRoleAsync(id, roleId, false, ct);

    [HttpGet("/api/group-criteria")]
    public Task<IActionResult> Criteria(CancellationToken ct) => this.ViewAsync(pdp, ct);
}
