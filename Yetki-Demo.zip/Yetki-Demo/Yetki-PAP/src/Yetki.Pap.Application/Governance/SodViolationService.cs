using Microsoft.EntityFrameworkCore;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Audit;
using Yetki.Pap.Application.Common;
using Yetki.Pap.Application.Integration;
using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Governance;

namespace Yetki.Pap.Application.Governance;

public sealed record SodScanResult(int ScannedUsers, int ViolatingUsers, int NewViolations, int StillOpen, int AutoResolved, double DurationMs,
    IReadOnlyList<SodUserConflicts> Details);

/// <summary>
/// SoD ihlal kayıtları (PAP). Çakışma HESABI PDP'dedir (aynı etkin yetki hesabı); burada kayıt açma / güncelleme / otomatik kapatma yapılır.
/// Sistem yetkiyi otomatik silmez; ihlali görünür kılar.
/// </summary>
public sealed class SodViolationService(IYetkiDbContext db, IPdpClient pdp, AuditWriter audit, IClock clock, ICurrentActor actor)
{
    /// <summary>İhlal kaydı açar veya açık kaydın LastSeenAt'ini günceller. SaveChanges çağırana aittir.</summary>
    public async Task<int> UpsertAsync(int userId, IEnumerable<SodConflict> conflicts, ViolationDetectionSource source, CancellationToken ct)
    {
        var now = clock.UtcNow;
        var created = 0;
        foreach (var c in conflicts)
        {
            var existing = await db.SodViolations.FirstOrDefaultAsync(v => v.UserId == userId && v.SodRuleId == c.SodRuleId && v.Status != ViolationStatus.Resolved, ct);
            if (existing is not null)
            {
                existing.LastSeenAt = now;
                existing.Details = c.Describe();
                continue;
            }
            db.SodViolations.Add(new SodViolation
            {
                SodRuleId = c.SodRuleId, UserId = userId, DetectedBy = source, DetectedAt = now, LastSeenAt = now, Details = c.Describe()
            });
            created++;
        }
        return created;
    }

    /// <summary>Geriye dönük tarama: PDP tüm aktif kullanıcılar için çakışmaları hesaplar; artık geçerli olmayan açık ihlaller kapatılır.</summary>
    public async Task<SodScanResult> ScanAsync(CancellationToken ct)
    {
        var detection = await pdp.SodDetectAsync(ct);
        var now = clock.UtcNow;
        var created = 0;
        var seen = new HashSet<(int UserId, int RuleId)>();
        foreach (var u in detection.Details)
        {
            created += await UpsertAsync(u.UserId, u.Conflicts, ViolationDetectionSource.RetrospectiveScan, ct);
            foreach (var c in u.Conflicts) seen.Add((u.UserId, c.SodRuleId));
        }

        var open = await db.SodViolations.Where(v => v.Status != ViolationStatus.Resolved).ToListAsync(ct);
        var autoResolved = 0;
        foreach (var v in open.Where(v => !seen.Contains((v.UserId, v.SodRuleId))))
        {
            v.Status = ViolationStatus.Resolved;
            v.ClosedAt = now;
            v.ClosedBy = "sod-scan";
            v.Note = "Tarama sırasında çakışma artık mevcut değil; otomatik kapatıldı.";
            autoResolved++;
        }

        var result = new SodScanResult(detection.ScannedUsers, detection.ViolatingUsers, created, seen.Count - created, autoResolved, detection.DurationMs, detection.Details);
        audit.Add(new AuditLog
        {
            Category = AuditCategory.SodScan, Actor = actor.Name, Action = "SodScan",
            Summary = $"{result.ScannedUsers} kullanıcı tarandı, {result.ViolatingUsers} kullanıcıda ihlal, {created} yeni kayıt, {autoResolved} otomatik kapandı.",
            DetailsJson = JsonDefaults.Serialize(new { result.ScannedUsers, result.ViolatingUsers, result.NewViolations, result.StillOpen, result.AutoResolved, result.DurationMs, detection.ModelVersion })
        });
        await db.SaveChangesAsync(ct);
        return result;
    }
}
