using Microsoft.EntityFrameworkCore;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Common;
using Yetki.Pap.Application.Events;
using Yetki.Pap.Application.Integration;
using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Groups;

namespace Yetki.Pap.Application.Changes;

public sealed class UserUpsert
{
    public int TenantId { get; set; }
    public string UserName { get; set; } = default!;
    public string FullName { get; set; } = default!;
    public string? Email { get; set; }
    public string? Title { get; set; }
    public string? EmployeeNo { get; set; }
    public UserKind Kind { get; set; } = UserKind.Person;
    public bool IsActive { get; set; } = true;
    public bool IsOnLeave { get; set; }
    public decimal CashWithdrawalLimit { get; set; }
    public string? CustomerNo { get; set; }
    public int? PrimaryOrgUnitId { get; set; }

    internal PipUserUpsert ToPip() => new()
    {
        TenantId = TenantId, UserName = UserName, FullName = FullName, Email = Email, Title = Title, EmployeeNo = EmployeeNo, Kind = Kind,
        IsActive = IsActive, IsOnLeave = IsOnLeave, CashWithdrawalLimit = CashWithdrawalLimit, CustomerNo = CustomerNo, PrimaryOrgUnitId = PrimaryOrgUnitId
    };
}

public sealed class RoleUpsert
{
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsInheritable { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class GroupUpsert
{
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>
/// Yetkiyi etkileyen atama işlemleri. Her işlem bir AuthorizationChangeSet'e çevrilir ve ChangeGate üzerinden
/// (PDP etki analizi + SoD + olay + audit) uygulanır.
///  - Kimlik (kullanıcı, rol, rol ataması, kullanıcı-birim): verinin sahibi PIP'tir; PAP konsolu önce etkiyi sorar, sonra PIP'e yazar.
///  - Grup (üyelik, kitle kuralı, grup rolü): yetki yapısıdır, PAP veritabanına yazılır.
/// </summary>
public sealed class AssignmentService(IYetkiDbContext db, IIdentityDirectory identities, IPdpClient pdp, ChangeGate changes)
{
    // ================================ Kullanıcı (PIP) ================================

    public async Task<IdentityUser> CreateUserAsync(UserUpsert dto, CancellationToken ct)
    {
        if (!await db.Tenants.AnyAsync(o => o.Id == dto.TenantId, ct)) throw new NotFoundException("Kurum", dto.TenantId);
        return await identities.CreateUserAsync(dto.ToPip(), ct);
    }

    /// <summary>Kullanıcı özelliklerini günceller. Unvan/izin/limit/aktiflik grup üyeliğini ve policy'leri etkileyebildiği için etki analizinden geçer.</summary>
    public async Task<ChangeImpactResult> UpdateUserAsync(int userId, UserUpsert dto, CancellationToken ct)
    {
        var user = await UserAsync(userId, ct);
        var cs = new AuthorizationChangeSet();
        cs.UserUpdates.Add(new UserUpdate(userId, dto.Title ?? "", dto.IsActive, dto.IsOnLeave, dto.CashWithdrawalLimit));
        var pip = dto.ToPip();
        pip.TenantId = user.TenantId; pip.UserName = user.UserName;
        return await changes.ApplyAsync(new ChangeCommand
        {
            Impact = new ImpactRequest { Changes = cs },
            ApplyEntities = () => identities.UpdateUserAsync(userId, pip, ct),
            EventType = EventTypes.UserChanged, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, dto.Title, dto.IsActive, dto.IsOnLeave, dto.CashWithdrawalLimit },
            AuditSummary = $"'{user.UserName}' kullanıcı bilgileri güncellendi"
        }, ct);
    }

    public async Task<ChangeImpactResult> AssignRoleAsync(int userId, int roleId, DateTime? validUntil, string? reason, CancellationToken ct)
    {
        var user = await UserAsync(userId, ct);
        var role = await identities.GetRoleAsync(roleId, ct) ?? throw new NotFoundException("Rol", roleId);
        if ((await identities.GetUserRolesAsync(userId, ct)).Any(r => r.RoleId == roleId))
            throw new ConflictException($"'{user.UserName}' zaten '{role.Code}' rolüne sahip.");
        await EnsureRoleUsableAsync(role, user.TenantId, ct);

        var cs = new AuthorizationChangeSet();
        cs.UserRoles.Add(new UserRoleChange(userId, roleId, true, validUntil));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Impact = new ImpactRequest { Changes = cs },
            ApplyEntities = () => identities.AssignRoleAsync(userId, roleId, validUntil, reason, ct),
            EventType = EventTypes.RoleAssigned, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, roleId, role.Code, validUntil, reason },
            AuditSummary = $"'{user.UserName}' kullanıcısına '{role.Code}' rolü atandı" + (validUntil is null ? "" : $" ({validUntil:yyyy-MM-dd}'e kadar)")
        }, ct);
    }

    public async Task<ChangeImpactResult> RevokeRoleAsync(int userId, int roleId, CancellationToken ct)
    {
        var user = await UserAsync(userId, ct);
        if (!(await identities.GetUserRolesAsync(userId, ct)).Any(r => r.RoleId == roleId)) throw new NotFoundException("UserRole", $"{userId}/{roleId}");
        var role = await identities.GetRoleAsync(roleId, ct) ?? throw new NotFoundException("Rol", roleId);
        var cs = new AuthorizationChangeSet();
        cs.UserRoles.Add(new UserRoleChange(userId, roleId, false));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Impact = new ImpactRequest { Changes = cs },
            ApplyEntities = () => identities.RevokeRoleAsync(userId, roleId, ct),
            EventType = EventTypes.RoleRevoked, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, roleId, role.Code },
            AuditSummary = $"'{user.UserName}' kullanıcısından '{role.Code}' rolü alındı"
        }, ct);
    }

    public async Task<ChangeImpactResult> SetUserUnitAsync(int userId, int unitId, bool add, CancellationToken ct)
    {
        var user = await UserAsync(userId, ct);
        var unit = (await identities.GetUnitsAsync(user.TenantId, ct)).FirstOrDefault(u => u.Id == unitId)
                   ?? throw new ValidationException("Birim kullanıcının kurumunda olmalı.");
        var linked = (await identities.GetUserUnitsAsync(userId, ct)).Any(x => x.OrgUnitId == unitId);
        if (add && linked) throw new ConflictException("Kullanıcı zaten bu birimde.");
        if (!add && !linked) throw new NotFoundException("Kullanıcı birimi", $"{userId}/{unitId}");

        var cs = new AuthorizationChangeSet();
        cs.UserUnits.Add(new UserUnitChange(userId, unitId, add));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Impact = new ImpactRequest { Changes = cs },
            ApplyEntities = () => add ? identities.AddUserUnitAsync(userId, unitId, ct) : identities.RemoveUserUnitAsync(userId, unitId, ct),
            EventType = EventTypes.OrgUnitAssignmentChanged, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, unitId, unit.Code, add },
            AuditSummary = $"'{user.UserName}' {(add ? "birime eklendi" : "biriminden çıkarıldı")}: {unit.Code}"
        }, ct);
    }

    // ================================ Rol (PIP) ================================

    public async Task<IdentityRole> CreateRoleAsync(RoleUpsert dto, CancellationToken ct)
    {
        if (!await db.Tenants.AnyAsync(o => o.Id == dto.TenantId, ct)) throw new NotFoundException("Kurum", dto.TenantId);
        return await identities.CreateRoleAsync(new PipRoleUpsert
        {
            TenantId = dto.TenantId, Code = dto.Code, Name = dto.Name, Description = dto.Description, IsInheritable = dto.IsInheritable, IsActive = dto.IsActive
        }, ct);
    }

    public async Task<ChangeImpactResult> UpdateRoleAsync(int roleId, RoleUpsert dto, CancellationToken ct)
    {
        var role = await identities.GetRoleAsync(roleId, ct) ?? throw new NotFoundException("Rol", roleId);
        var cs = new AuthorizationChangeSet();
        cs.RoleUpdates.Add(new RoleUpdate(roleId, dto.IsActive, dto.IsInheritable));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Impact = new ImpactRequest { Changes = cs },
            ApplyEntities = () => identities.UpdateRoleAsync(roleId, new PipRoleUpsert
            {
                TenantId = role.TenantId, Code = role.Code, Name = dto.Name, Description = dto.Description, IsInheritable = dto.IsInheritable, IsActive = dto.IsActive
            }, ct),
            EventType = EventTypes.RoleChanged, AggregateType = "Role", AggregateId = role.Code,
            EventPayload = new { role.Code, dto.IsActive, dto.IsInheritable },
            AuditSummary = $"'{role.Code}' rolü güncellendi (aktif={dto.IsActive}, miras={dto.IsInheritable})"
        }, ct);
    }

    // ================================ Grup (PAP) ================================

    public async Task<Group> CreateGroupAsync(GroupUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Groups.AnyAsync(g => g.Code == code, ct)) throw new ConflictException($"Grup kodu zaten var: {code}");
        if (!await db.Tenants.AnyAsync(o => o.Id == dto.TenantId, ct)) throw new NotFoundException("Kurum", dto.TenantId);
        var g = new Group { TenantId = dto.TenantId, Code = code, Name = dto.Name, Description = dto.Description, IsActive = dto.IsActive };
        db.Groups.Add(g);
        await db.SaveChangesAsync(ct);
        return g;
    }

    public async Task<ChangeImpactResult> UpdateGroupAsync(int groupId, GroupUpsert dto, CancellationToken ct)
    {
        var g = await GroupAsync(groupId, ct);
        var cs = new AuthorizationChangeSet();
        cs.GroupActivations.Add(new ActivationChange(groupId, dto.IsActive));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Impact = new ImpactRequest { Changes = cs },
            ApplyEntities = () => { g.Name = dto.Name; g.Description = dto.Description; g.IsActive = dto.IsActive; return Task.CompletedTask; },
            EventType = EventTypes.GroupChanged, AggregateType = "Group", AggregateId = g.Code,
            EventPayload = new { g.Code, dto.IsActive },
            AuditSummary = $"'{g.Code}' grubu güncellendi (aktif={dto.IsActive})"
        }, ct);
    }

    /// <summary>Kitle kurallarını tamamen değiştirir. Kriterler PDP'deki kriter handler'larına ve güncel modele göre doğrulanır.</summary>
    public async Task<ChangeImpactResult> ReplaceGroupFiltersAsync(int groupId, List<GroupFilterDraft> filters, CancellationToken ct)
    {
        var g = await GroupAsync(groupId, ct);
        var rule = await pdp.ValidateGroupFiltersAsync(filters, ct);
        var cs = new AuthorizationChangeSet();
        cs.GroupFilters.Add(new GroupFiltersReplacement(groupId, filters));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Impact = new ImpactRequest { Changes = cs },
            ApplyEntities = async () =>
            {
                var old = await db.GroupFilters.Include(f => f.Criteria).ThenInclude(c => c.Values).Where(f => f.GroupId == groupId).ToListAsync(ct);
                foreach (var f in old)
                {
                    foreach (var c in f.Criteria) { db.GroupFilterValues.RemoveRange(c.Values); db.GroupFilterCriteria.Remove(c); }
                    db.GroupFilters.Remove(f);
                }
                for (var i = 0; i < filters.Count; i++)
                    db.GroupFilters.Add(new GroupFilter
                    {
                        GroupId = groupId, Mode = filters[i].Mode, Order = i, Description = filters[i].Description,
                        Criteria = filters[i].Criteria.Select((c, j) => new GroupFilterCriterion
                        {
                            Attribute = c.Attribute.Trim().ToUpperInvariant(), Order = j,
                            Values = c.Values.Select(v => v.Trim()).Where(v => v.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).Select(v => new GroupFilterValue { Value = v }).ToList()
                        }).ToList()
                    });
            },
            EventType = EventTypes.GroupFiltersChanged, AggregateType = "Group", AggregateId = g.Code,
            EventPayload = new { g.Code, filters },
            AuditSummary = $"'{g.Code}' grubunun kitle kuralları değişti: {rule}"
        }, ct);
    }

    public async Task<ChangeImpactResult> SetGroupMemberAsync(int groupId, int userId, bool add, DateTime? validUntil, CancellationToken ct)
    {
        var g = await GroupAsync(groupId, ct);
        var user = await UserAsync(userId, ct);
        var link = await db.GroupMembers.FirstOrDefaultAsync(x => x.GroupId == groupId && x.UserId == userId, ct);
        if (add && link is not null) throw new ConflictException("Kullanıcı zaten açık üye.");
        if (!add && link is null) throw new NotFoundException("Grup üyesi", $"{groupId}/{userId}");
        if (add && !(await TenantHierarchy.AncestorsAsync(db, user.TenantId, ct)).Contains(g.TenantId))
            throw new ValidationException($"'{user.UserName}' grubun kurumunda ({await TenantHierarchy.CodeAsync(db, g.TenantId, ct)}) veya alt kurumunda değil.");

        var cs = new AuthorizationChangeSet();
        cs.GroupMembers.Add(new GroupMemberChange(groupId, userId, add, validUntil));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Impact = new ImpactRequest { Changes = cs },
            ApplyEntities = () =>
            {
                if (add) db.GroupMembers.Add(new GroupMember { GroupId = groupId, UserId = userId, ValidUntil = validUntil });
                else db.GroupMembers.Remove(link!);
                return Task.CompletedTask;
            },
            EventType = EventTypes.GroupMembershipChanged, AggregateType = "Group", AggregateId = g.Code,
            EventPayload = new { g.Code, userId, user.UserName, add, validUntil },
            AuditSummary = $"'{g.Code}' grubuna açık üye {(add ? "eklendi" : "çıkarıldı")}: {user.UserName}"
        }, ct);
    }

    /// <summary>Grubun üyelerine rol vermesi (Keycloak group role mapping).</summary>
    public async Task<ChangeImpactResult> SetGroupRoleAsync(int groupId, int roleId, bool add, CancellationToken ct)
    {
        var g = await GroupAsync(groupId, ct);
        var role = await identities.GetRoleAsync(roleId, ct) ?? throw new NotFoundException("Rol", roleId);
        if (add) await EnsureRoleUsableAsync(role, g.TenantId, ct);
        var exists = await db.GroupRoles.AnyAsync(x => x.GroupId == groupId && x.RoleId == roleId, ct);
        if (add && exists) throw new ConflictException($"'{g.Code}' zaten '{role.Code}' rolünü veriyor.");
        if (!add && !exists) throw new NotFoundException("Grup rolü", $"{g.Code}/{role.Code}");

        var cs = new AuthorizationChangeSet();
        cs.GroupRoles.Add(new GroupRoleChange(groupId, roleId, add));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Impact = new ImpactRequest { Changes = cs },
            ApplyEntities = async () =>
            {
                if (add) db.GroupRoles.Add(new GroupRole { GroupId = groupId, RoleId = roleId });
                else db.GroupRoles.Remove(await db.GroupRoles.FirstAsync(x => x.GroupId == groupId && x.RoleId == roleId, ct));
            },
            EventType = EventTypes.GroupRoleChanged, AggregateType = "Group", AggregateId = g.Code,
            EventPayload = new { g.Code, roleId, role = role.Code, add },
            AuditSummary = $"'{g.Code}' grubu {(add ? "artık rol veriyor" : "artık rol vermiyor")}: {role.Code}"
        }, ct);
    }

    // ================================ Yardımcılar ================================

    /// <summary>Rol, hedef kurumda kullanılabilir mi? (aynı kurum veya üst kurumun miras alınabilir rolü)</summary>
    private async Task EnsureRoleUsableAsync(IdentityRole role, int tenantId, CancellationToken ct)
    {
        var ok = role.TenantId == tenantId || (role.IsInheritable && (await TenantHierarchy.AncestorsAsync(db, tenantId, ct)).Contains(role.TenantId));
        if (!ok)
            throw new ValidationException($"'{role.Code}' rolü {await TenantHierarchy.CodeAsync(db, role.TenantId, ct)} kurumuna ait ve miras alınamaz; " +
                                          $"{await TenantHierarchy.CodeAsync(db, tenantId, ct)} kurumunda kullanılamaz.");
    }

    private async Task<IdentityUser> UserAsync(int id, CancellationToken ct) => await identities.GetUserAsync(id, ct) ?? throw new NotFoundException("Kullanıcı", id);
    private async Task<Group> GroupAsync(int id, CancellationToken ct) => await db.Groups.FindAsync([id], ct) ?? throw new NotFoundException("Grup", id);
}
