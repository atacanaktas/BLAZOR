using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Audit;
using Yetki.Pap.Application.Events;
using Yetki.Pap.Application.Governance;
using Yetki.Pap.Application.Integration;
using Yetki.Pap.Domain.Common;

namespace Yetki.Pap.Application.Changes;

/// <summary>
/// Gerçek uygulama komutu. Değişiklik PDP'ye kimlik change set'i ve/veya tanım satırı işlemleri (ModelPatch) olarak anlatılır;
/// ApplyEntities aynı değişikliği kalıcı yapar (PAP veritabanı veya kimlik için PIP).
/// </summary>
public sealed class ChangeCommand
{
    public required ImpactRequest Impact { get; init; }
    public required Func<Task> ApplyEntities { get; init; }
    public required string EventType { get; init; }
    public required string AggregateType { get; init; }
    public required object AggregateId { get; init; }
    public required object EventPayload { get; init; }
    public required string AuditSummary { get; init; }
    public long? ExpectedModelVersion { get; init; }
}

/// <summary>
/// Erişimi etkileyen yönetim değişikliklerinin tek kapısı (PAP):
///   1. Etki PDP'ye sorulur (aynı karar modeli: kim kazanır / kaybeder, yeni SoD çakışmaları, RACF/LDAP farkı)
///   2. Engelleyici SoD çakışması varsa değişiklik reddedilir (409)
///   3. Değişiklik uygulanır; SoD uyarıları ihlal kaydı olur; audit + outbox olayları (erişimi değişen kullanıcılar → mutabakat)
/// What-If ve "etkiyi gör" 1'i aynen kullanır: önizleme ile gerçek uygulama arasında fark olamaz.
/// Not: kimlik değişikliklerinde PIP yazımı PAP'ın veritabanı işinden ayrıdır (önce PIP, sonra PAP audit/olay kaydı).
/// </summary>
public sealed class ChangeGate(IYetkiDbContext db, IPdpClient pdp, SodViolationService violations, OutboxWriter outbox, AuditWriter audit)
{
    public async Task<ChangeImpactResult> PreviewAsync(ImpactRequest request, CancellationToken ct)
    {
        var impact = await pdp.ImpactAsync(request, ct);
        impact.DryRun = true;
        return impact;
    }

    public async Task<ChangeImpactResult> ApplyAsync(ChangeCommand command, CancellationToken ct)
    {
        var impact = await pdp.ImpactAsync(command.Impact, ct);
        if (command.ExpectedModelVersion is { } expected && impact.ModelVersion != expected)
            throw new ConflictException($"Önizlemeden sonra yetki modeli değişti (beklenen v{expected}, güncel v{impact.ModelVersion}). Etkiyi yeniden hesaplayın.", impact);
        if (impact.Blocked)
            throw new ConflictException("SoD kuralı nedeniyle değişiklik engellendi. " + impact.Summary, impact);

        await command.ApplyEntities();

        foreach (var group in impact.Warnings.GroupBy(w => w.UserId))
            await violations.UpsertAsync(group.Key, group.Select(g => g.Conflict), ViolationDetectionSource.AssignmentCheck, ct);

        outbox.Add(command.EventType, command.AggregateType, command.AggregateId, command.EventPayload);
        AddAccessEvents(impact, command.EventType);
        audit.Management(command.EventType, command.AggregateType, command.AggregateId, $"{command.AuditSummary} — {impact.Summary}",
            new { command.EventPayload, impact.AffectedUserCount, Warnings = impact.Warnings.Select(w => new { w.UserName, w.Conflict.Code }) });

        await db.SaveChangesAsync(ct);
        impact.Applied = true;
        return impact;
    }

    /// <summary>
    /// Katalog değişikliği (resource, scope, uygulama, tip) için: etki kaydetmeden ÖNCE hesaplanır (ModelPatch), kayıt sonrası
    /// erişimi değişen kullanıcılar için mutabakat olayı yazılır. SoD bu değişikliklerde engel değildir (yetki tanımı, atama değil).
    /// </summary>
    public Task<ChangeImpactResult> AnalyzeCatalogAsync(IReadOnlyList<ModelPatchOperation> patch, CancellationToken ct) =>
        pdp.ImpactAsync(new ImpactRequest { Patch = patch.ToList() }, ct);

    public async Task<ChangeImpactResult> PublishAsync(ChangeImpactResult impact, string causeEventType, CancellationToken ct)
    {
        AddAccessEvents(impact, causeEventType);
        if (impact.AffectedUserCount > 0) await db.SaveChangesAsync(ct);
        impact.Applied = true;
        return impact;
    }

    private void AddAccessEvents(ChangeImpactResult impact, string cause)
    {
        foreach (var u in impact.Users.Where(u => u.AccessesChanged))
            outbox.Add(EventTypes.EffectivePermissionsChanged, "User", u.UserId, new EffectivePermissionsChangedPayload(
                u.UserId, u.UserName, cause,
                u.AddedAccesses.Select(p => new AccessRef(p.ResourceScopeId, p.Key)).ToList(),
                u.RemovedAccesses.Select(p => new AccessRef(p.ResourceScopeId, p.Key)).ToList()));
    }
}
