using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Events;
using Yetki.Pap.Application.Integration;
using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Governance;

namespace Yetki.Pap.Application.External;

/// <summary>
/// Dış sistem provisioning'i = MUTABAKAT (desired-state reconcile), PAP tarafında yürütülür (worker / konsol):
///   olması gereken (PDP: etkin yetkilerden) − dış sistemde açık olan (UserExternalGrant) → Grant / Modify / Revoke → adaptör.
/// Fark hesabı PDP'dedir (aynı model); burada sadece adaptör çağrısı ve durum kaydı yapılır. Sadece başarılı aksiyonlar durumu
/// günceller; başarısızlar bir sonraki mutabakatta tekrar denenir. İdempotent: aynı olay iki kez işlenirse ikincisi fark bulamaz.
/// </summary>
public sealed class ExternalProvisioningService(
    IYetkiDbContext db, IPdpClient pdp, IEnumerable<IProvisioningAdapter> adapters, IClock clock, ICurrentActor actor,
    ILogger<ExternalProvisioningService> logger)
{
    public async Task<IReadOnlyList<ProvisioningAction>> ReconcileUserAsync(int userId, Guid? eventId, CancellationToken ct)
    {
        UserExternalStatus status;
        try { status = await pdp.ExternalUserAsync(userId, ct); }
        catch (NotFoundException) { return []; }
        var items = status.Items.Where(i => i.Action != "None").ToList();
        if (items.Count == 0) return [];

        var now = clock.UtcNow;
        var actions = items.Select(i => new ProvisioningAction
        {
            OutboxEventId = eventId ?? Guid.Empty, UserId = userId, UserName = status.UserName,
            Reason = Truncate(string.Join(" | ", i.Reasons.Take(3)), 512),
            ExternalSystemCode = i.Target.System, ExternalPermissionCode = i.Target.Code, ResourceClass = i.Target.ResourceClass,
            ActionType = i.Action switch { "Grant" => ProvisioningActionType.Grant, "Modify" => ProvisioningActionType.Modify, _ => ProvisioningActionType.Revoke },
            AccessLevel = i.DesiredLevel, PreviousAccessLevel = i.CurrentLevel, Status = ProvisioningStatus.Pending, CreatedAt = now
        }).ToList();
        db.ProvisioningActions.AddRange(actions);

        var grants = await db.UserExternalGrants.Where(g => g.UserId == userId).ToDictionaryAsync(g => g.ExternalPermissionId, ct);
        foreach (var (action, item) in actions.Zip(items))
        {
            var adapter = adapters.FirstOrDefault(a => string.Equals(a.SystemCode, action.ExternalSystemCode, StringComparison.OrdinalIgnoreCase))
                          ?? adapters.FirstOrDefault(a => a.SystemCode == "*");
            if (adapter is null)
            {
                action.Status = ProvisioningStatus.Failed;
                action.ResultMessage = "Bu sistem için adaptör yok.";
                continue;
            }
            try
            {
                var outcome = await adapter.ExecuteAsync(new ProvisioningRequest(userId, status.UserName, action.Reason, action.ExternalSystemCode,
                    action.ExternalPermissionCode, action.ActionType, action.ResourceClass, action.AccessLevel, action.PreviousAccessLevel), ct);
                action.AdapterName = adapter.Name;
                action.Status = outcome.Success ? ProvisioningStatus.Completed : ProvisioningStatus.Failed;
                action.ResultMessage = outcome.Message;
                if (outcome.Success) ApplyState(grants, userId, item, now);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogError(ex, "Provisioning adapter {Adapter} failed", adapter.Name);
                action.AdapterName = adapter.Name;
                action.Status = ProvisioningStatus.Failed;
                action.ResultMessage = ex.Message;
            }
            action.CompletedAt = clock.UtcNow;
        }
        await db.SaveChangesAsync(ct);
        return actions;
    }

    /// <summary>Farkı olan tüm kullanıcılar (PDP sapma raporu) için mutabakat.</summary>
    public async Task<int> ReconcileAllAsync(Guid? eventId, CancellationToken ct)
    {
        var drift = await pdp.ExternalDriftAsync(ct);
        var count = 0;
        foreach (var u in drift.Users) count += (await ReconcileUserAsync(u.UserId, eventId, ct)).Count;
        return count;
    }

    /// <summary>
    /// Başlangıç yüklemesi (baseline): dış sistemdeki mevcut durumun olması gerekenle aynı olduğu kabul edilir; komut gönderilmez.
    /// Gerçekte RACF'ten okunan mevcut durum (IRRDBU00 / LDAP export) içe aktarılır; demo verisi için bu kullanılır.
    /// </summary>
    public async Task BaselineAsync(CancellationToken ct)
    {
        var desired = await pdp.ExternalDesiredAsync(null, ct);
        db.UserExternalGrants.RemoveRange(await db.UserExternalGrants.ToListAsync(ct));
        var now = clock.UtcNow;
        foreach (var u in desired)
            foreach (var need in u.Needs)
                db.UserExternalGrants.Add(new UserExternalGrant
                {
                    UserId = u.UserId, ExternalPermissionId = need.Target.ExternalPermissionId, AccessLevel = need.Level, ProvisionedAt = now, ProvisionedBy = "baseline"
                });
        await db.SaveChangesAsync(ct);
    }

    private void ApplyState(Dictionary<int, UserExternalGrant> grants, int userId, ExternalDiffItem item, DateTime now)
    {
        var id = item.Target.ExternalPermissionId;
        switch (item.Action)
        {
            case "Grant":
                var g = new UserExternalGrant { UserId = userId, ExternalPermissionId = id, AccessLevel = item.DesiredLevel, ProvisionedAt = now, ProvisionedBy = actor.Name };
                db.UserExternalGrants.Add(g);
                grants[id] = g;
                break;
            case "Modify":
                grants[id].AccessLevel = item.DesiredLevel;
                grants[id].ProvisionedAt = now;
                grants[id].ProvisionedBy = actor.Name;
                break;
            case "Revoke":
                db.UserExternalGrants.Remove(grants[id]);
                grants.Remove(id);
                break;
        }
    }

    private static string Truncate(string s, int max) => s.Length <= max ? s : s[..(max - 1)] + "…";
}
