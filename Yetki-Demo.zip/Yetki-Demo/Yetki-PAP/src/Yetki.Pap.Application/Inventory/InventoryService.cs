using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Audit;
using Yetki.Pap.Application.Common;
using Yetki.Pap.Domain.Catalog;

namespace Yetki.Pap.Application.Inventory;

public enum InventoryFormat { Lines = 1, OpenApi = 2, Json = 3 }

/// <summary>
/// Envanter içe aktarımı. Endpoint: OpenAPI/Swagger JSON veya satır listesi ("GET /v1/x  açıklama").
/// UI öğesi: JSON dizi ([{code,name,parent,type}]) veya satır listesi ("KOD;Ad;ÜstKod;Tip").
/// </summary>
public sealed class InventoryImport
{
    public string Source { get; set; } = default!;
    public InventoryFormat Format { get; set; } = InventoryFormat.Lines;
    public string Content { get; set; } = default!;
    /// <summary>Endpoint path'lerinin başına eklenecek önek (ör. gateway'deki yol /anka).</summary>
    public string? PathPrefix { get; set; }
}

public sealed record InventorySnapshotInfo(InventoryKind Kind, string Source, DateTime ImportedAt, string ImportedBy, int ItemCount);

/// <summary>
/// ENVANTER içe aktarımı (PAP): uygulamada gerçekte ne var (Swagger, ekran listesi). Envanter sadece bilgidir: resource / permission
/// üretmez, kararları etkilemez. Kapsama raporu (envanter ↔ yetki tanımları) PDP'de hesaplanır.
/// </summary>
public sealed class InventoryService(IYetkiDbContext db, AuditWriter audit, IClock clock, ICurrentActor actor)
{
    public static readonly string[] Methods = ["GET", "POST", "PUT", "PATCH", "DELETE"];

    public async Task<InventorySnapshotInfo> ImportAsync(int applicationId, InventoryKind kind, InventoryImport dto, CancellationToken ct)
    {
        var app = await db.Applications.FindAsync([applicationId], ct) ?? throw new NotFoundException("Uygulama", applicationId);
        if (string.IsNullOrWhiteSpace(dto.Source)) throw new ValidationException("Kaynak açıklaması girilmeli (ör. \"Swagger v1.4\").");
        if (string.IsNullOrWhiteSpace(dto.Content)) throw new ValidationException("İçerik boş.");
        var items = kind == InventoryKind.Endpoint ? ParseEndpoints(dto) : ParseUi(dto);
        if (items.Count == 0) throw new ValidationException("İçerikten hiç öğe okunamadı.");

        var old = await db.InventorySnapshots.Where(s => s.ApplicationId == app.Id && s.Kind == kind).ToListAsync(ct);
        db.InventorySnapshots.RemoveRange(old);
        var snapshot = new InventorySnapshot
        {
            ApplicationId = app.Id, Kind = kind, Source = dto.Source.Trim(), ImportedAt = clock.UtcNow, ImportedBy = actor.Name, Items = items
        };
        db.InventorySnapshots.Add(snapshot);
        audit.Management("InventoryImported", "Inventory", app.Code,
            $"Envanter içe aktarıldı: {app.Code} · {(kind == InventoryKind.Endpoint ? "endpoint" : "UI öğesi")} · {items.Count} öğe ({snapshot.Source})",
            new { kind, dto.Source, count = items.Count });
        await db.SaveChangesAsync(ct);
        return Info(snapshot, items.Count);
    }

    public async Task DeleteAsync(int applicationId, InventoryKind kind, CancellationToken ct)
    {
        var old = await db.InventorySnapshots.Where(s => s.ApplicationId == applicationId && s.Kind == kind).ToListAsync(ct);
        if (old.Count == 0) return;
        db.InventorySnapshots.RemoveRange(old);
        audit.Management("InventoryDeleted", "Inventory", applicationId.ToString(), $"Envanter silindi ({kind})", new { applicationId, kind });
        await db.SaveChangesAsync(ct);
    }


    // ================================ Ayrıştırma ================================

    private static List<InventoryItem> ParseEndpoints(InventoryImport dto)
    {
        var prefix = string.IsNullOrWhiteSpace(dto.PathPrefix) ? "" : "/" + dto.PathPrefix.Trim().Trim('/');
        var list = new List<InventoryItem>();
        if (dto.Format == InventoryFormat.OpenApi)
        {
            JsonDocument doc;
            try { doc = JsonDocument.Parse(dto.Content); }
            catch (JsonException ex) { throw new ValidationException($"OpenAPI JSON okunamadı: {ex.Message}"); }
            using (doc)
            {
                var root = doc.RootElement;
                // Swagger 2.0 basePath
                if (root.TryGetProperty("basePath", out var bp) && bp.GetString() is { Length: > 1 } basePath) prefix += "/" + basePath.Trim('/');
                if (!root.TryGetProperty("paths", out var paths) || paths.ValueKind != JsonValueKind.Object)
                    throw new ValidationException("OpenAPI belgesinde 'paths' bulunamadı.");
                foreach (var path in paths.EnumerateObject())
                {
                    if (path.Value.ValueKind != JsonValueKind.Object) continue;
                    foreach (var op in path.Value.EnumerateObject())
                    {
                        var method = op.Name.ToUpperInvariant();
                        if (!Methods.Contains(method)) continue;
                        string? name = null;
                        if (op.Value.ValueKind == JsonValueKind.Object)
                            name = (op.Value.TryGetProperty("summary", out var s) ? s.GetString() : null)
                                   ?? (op.Value.TryGetProperty("operationId", out var o) ? o.GetString() : null);
                        list.Add(new InventoryItem { Method = method, Path = NormalizePath(prefix + path.Name), Name = Trim(name, 160) });
                    }
                }
            }
        }
        else
        {
            foreach (var raw in Lines(dto.Content))
            {
                var parts = raw.Split([' ', '\t'], 3, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length < 2) throw new ValidationException($"Satır okunamadı (beklenen: METHOD /yol [açıklama]): {raw}");
                var method = parts[0].ToUpperInvariant();
                if (!Methods.Contains(method)) throw new ValidationException($"Geçersiz HTTP metodu: {parts[0]} ({raw})");
                list.Add(new InventoryItem { Method = method, Path = NormalizePath(prefix + parts[1]), Name = Trim(parts.Length > 2 ? parts[2] : null, 160) });
            }
        }
        return list.DistinctBy(i => (i.Method, i.Path?.ToLowerInvariant())).ToList();
    }

    private static List<InventoryItem> ParseUi(InventoryImport dto)
    {
        var list = new List<InventoryItem>();
        if (dto.Format == InventoryFormat.Json)
        {
            JsonDocument doc;
            try { doc = JsonDocument.Parse(dto.Content); }
            catch (JsonException ex) { throw new ValidationException($"JSON okunamadı: {ex.Message}"); }
            using (doc)
            {
                if (doc.RootElement.ValueKind != JsonValueKind.Array) throw new ValidationException("Beklenen: [{\"code\":\"GVADAG00\",\"name\":\"...\",\"parent\":\"...\",\"type\":\"SCREEN\"}]");
                foreach (var e in doc.RootElement.EnumerateArray())
                {
                    string? P(string n) => e.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;
                    var code = P("code") ?? throw new ValidationException("Her öğede 'code' olmalı.");
                    list.Add(new InventoryItem { Code = Trim(code, 64), Name = Trim(P("name"), 160), ParentCode = Trim(P("parent"), 64), ElementType = Trim(P("type")?.ToUpperInvariant(), 32) });
                }
            }
        }
        else
        {
            foreach (var raw in Lines(dto.Content))
            {
                var p = raw.Split(';').Select(x => x.Trim()).ToArray();
                if (p[0].Length == 0) throw new ValidationException($"Satır okunamadı (beklenen: KOD;Ad;ÜstKod;Tip): {raw}");
                list.Add(new InventoryItem
                {
                    Code = Trim(p[0], 64), Name = Trim(p.ElementAtOrDefault(1), 160),
                    ParentCode = Trim(p.ElementAtOrDefault(2), 64), ElementType = Trim(p.ElementAtOrDefault(3)?.ToUpperInvariant(), 32)
                });
            }
        }
        return list.DistinctBy(i => i.Code!.ToUpperInvariant()).ToList();
    }

    // ================================ Yardımcılar ================================

    private static InventorySnapshotInfo Info(InventorySnapshot s, int count) => new(s.Kind, s.Source, s.ImportedAt, s.ImportedBy, count);

    private static IEnumerable<string> Lines(string content) =>
        content.Split('\n').Select(l => l.Trim()).Where(l => l.Length > 0 && !l.StartsWith('#'));

    private static string NormalizePath(string p)
    {
        var path = p.Trim().Split('?')[0];
        var segs = path.Split('/', StringSplitOptions.RemoveEmptyEntries);
        return "/" + string.Join('/', segs);
    }

    private static string? Trim(string? s, int max = 512) =>
        string.IsNullOrWhiteSpace(s) ? null : s.Trim().Length > max ? s.Trim()[..max] : s.Trim();
}
