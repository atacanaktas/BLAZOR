using Microsoft.Extensions.DependencyInjection;
using Yetki.Pap.Application.Audit;
using Yetki.Pap.Application.Changes;
using Yetki.Pap.Application.Definitions;
using Yetki.Pap.Application.Events;
using Yetki.Pap.Application.External;
using Yetki.Pap.Application.Governance;
using Yetki.Pap.Application.Inventory;

namespace Yetki.Pap.Application;

/// <summary>
/// PAP (yönetim) servisleri. Karar motoru YOKTUR: etki analizi, doğrulama ve hesaplanan görünümler PDP'den (IPdpClient),
/// kimlik verisi PIP'ten (IIdentityDirectory) gelir. Bu katman tanımları yazar, iş akışlarını (SoD kaydı, audit, outbox,
/// provisioning) yürütür.
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddYetkiApplication(this IServiceCollection services)
    {
        services.AddScoped<AuditWriter>();
        services.AddScoped<OutboxWriter>();
        services.AddScoped<SodViolationService>();
        services.AddScoped<ChangeGate>();
        services.AddScoped<AssignmentService>();
        services.AddScoped<PolicyManagementService>();
        services.AddScoped<PermissionService>();
        services.AddScoped<AudienceService>();
        services.AddScoped<CatalogService>();
        services.AddScoped<InventoryService>();
        services.AddScoped<ClientCredentialService>();
        services.AddScoped<OwnershipTeamService>();
        services.AddScoped<ClientService>();
        services.AddScoped<TenantService>();
        services.AddScoped<GovernanceService>();
        services.AddScoped<ExternalDefinitionService>();
        services.AddScoped<ExternalProvisioningService>();

        services.AddScoped<IOutboxEventHandler, ProvisioningEventHandler>();
        return services;
    }
}
