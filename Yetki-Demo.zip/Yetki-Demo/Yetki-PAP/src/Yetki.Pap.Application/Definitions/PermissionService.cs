using Microsoft.EntityFrameworkCore;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Changes;
using Yetki.Pap.Application.Common;
using Yetki.Pap.Application.Events;
using Yetki.Pap.Application.Integration;
using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Policies;

namespace Yetki.Pap.Application.Definitions;

public sealed class PermissionUpsert
{
    public int ApplicationId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    /// <summary>Neye uygulanır? Açıkça seçilir; boş liste "tümü" değil "hiçbiri" demektir.</summary>
    public PermissionTarget Target { get; set; } = PermissionTarget.Resources;
    /// <summary>Sadece Target = ResourceType.</summary>
    public int? ResourceTypeId { get; set; }
    /// <summary>Sadece Target = Resources. Boşsa permission atıldır (hiçbir yetkiyi etkilemez).</summary>
    public List<int> ResourceIds { get; set; } = new();
    /// <summary>true: kapsamdaki resource'ların tüm scope'ları. false: sadece ScopeIds (boşsa atıl).</summary>
    public bool AllScopes { get; set; }
    public List<int> ScopeIds { get; set; } = new();
    public List<int> PolicyIds { get; set; } = new();
    public DecisionStrategy DecisionStrategy { get; set; } = DecisionStrategy.Unanimous;
    public bool IsActive { get; set; } = true;
}

/// <summary>
/// Keycloak permission yönetimi: resource / resource tipi / scope kapsamını policy'lere bağlar.
/// Her değişiklik PDP'de What-If modelinde kurulur (ModelPatch) ve etkisi (kim kazanır / kaybeder, SoD, RACF/LDAP) hesaplanır;
/// dryRun=false'ta SoD Block varsa reddedilir, yoksa uygulanır ve erişimi değişen kullanıcılar için mutabakat olayı yazılır.
/// </summary>
public sealed class PermissionService(IYetkiDbContext db, IPdpClient pdp, ChangeGate changes)
{
    private const int DraftId = -1;

    public async Task<DefinitionChangeResult> CreateAsync(PermissionUpsert dto, bool dryRun, long? expectedModelVersion, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Permissions.AnyAsync(p => p.Code == code, ct)) throw new ConflictException($"Permission kodu zaten var: {code}");
        var warnings = await ValidateAsync(dto, ct);

        var patch = new List<ModelPatchOperation>
        {
            ModelPatch.Add("Permissions", new PermissionRow(DraftId, dto.ApplicationId, code, dto.Name, dto.Target, dto.ResourceTypeId, dto.AllScopes, dto.DecisionStrategy, dto.IsActive, 1))
        };
        patch.AddRange(Relations(DraftId, dto));
        var request = new ImpactRequest { Patch = patch };

        if (dryRun) return new DefinitionChangeResult(null, await changes.PreviewAsync(request, ct), warnings);
        Permission? created = null;
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Impact = request,
            ApplyEntities = () =>
            {
                created = new Permission
                {
                    ApplicationId = dto.ApplicationId, Code = code, Name = dto.Name, Description = dto.Description,
                    Target = dto.Target, ResourceTypeId = dto.ResourceTypeId, AllScopes = dto.AllScopes, DecisionStrategy = dto.DecisionStrategy, IsActive = dto.IsActive,
                    Resources = dto.ResourceIds.Distinct().Select(r => new PermissionResource { ResourceId = r }).ToList(),
                    Scopes = dto.ScopeIds.Distinct().Select(s => new PermissionScope { ScopeId = s }).ToList(),
                    Policies = dto.PolicyIds.Distinct().Select((p, i) => new PermissionPolicy { PolicyId = p, Order = i }).ToList()
                };
                db.Permissions.Add(created);
                return Task.CompletedTask;
            },
            EventType = EventTypes.PermissionChanged, AggregateType = "Permission", AggregateId = code,
            EventPayload = new { action = "created", code, dto.Target, dto.ResourceTypeId, dto.ResourceIds, dto.AllScopes, dto.ScopeIds, dto.PolicyIds },
            AuditSummary = $"Permission oluşturuldu: {code}",
            ExpectedModelVersion = expectedModelVersion
        }, ct);
        return new DefinitionChangeResult(created?.Id, impact, warnings);
    }

    public async Task<DefinitionChangeResult> UpdateAsync(int id, PermissionUpsert dto, bool dryRun, long? expectedModelVersion, CancellationToken ct)
    {
        var p = await db.Permissions.Include(x => x.Resources).Include(x => x.Scopes).Include(x => x.Policies).FirstOrDefaultAsync(x => x.Id == id, ct)
                ?? throw new NotFoundException("Permission", id);
        dto.ApplicationId = p.ApplicationId;
        dto.Code = p.Code;
        var warnings = await ValidateAsync(dto, ct);

        var patch = new List<ModelPatchOperation>
        {
            ModelPatch.Replace("Permissions", new { Id = id },
                new PermissionRow(id, p.ApplicationId, p.Code, dto.Name, dto.Target, dto.ResourceTypeId, dto.AllScopes, dto.DecisionStrategy, dto.IsActive, p.Version + 1)),
            ModelPatch.Remove("PermissionResources", new { PermissionId = id }),
            ModelPatch.Remove("PermissionScopes", new { PermissionId = id }),
            ModelPatch.Remove("PermissionPolicies", new { PermissionId = id })
        };
        patch.AddRange(Relations(id, dto));
        var request = new ImpactRequest { Patch = patch };

        if (dryRun) return new DefinitionChangeResult(id, await changes.PreviewAsync(request, ct), warnings);
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Impact = request,
            ApplyEntities = () =>
            {
                p.Name = dto.Name; p.Description = dto.Description; p.Target = dto.Target; p.ResourceTypeId = dto.ResourceTypeId; p.AllScopes = dto.AllScopes; p.DecisionStrategy = dto.DecisionStrategy;
                p.IsActive = dto.IsActive; p.Version++;
                db.PermissionResources.RemoveRange(p.Resources);
                db.PermissionScopes.RemoveRange(p.Scopes);
                db.PermissionPolicies.RemoveRange(p.Policies);
                foreach (var r in dto.ResourceIds.Distinct()) db.PermissionResources.Add(new PermissionResource { PermissionId = id, ResourceId = r });
                foreach (var s in dto.ScopeIds.Distinct()) db.PermissionScopes.Add(new PermissionScope { PermissionId = id, ScopeId = s });
                foreach (var (pid, i) in dto.PolicyIds.Distinct().Select((x, i) => (x, i))) db.PermissionPolicies.Add(new PermissionPolicy { PermissionId = id, PolicyId = pid, Order = i });
                return Task.CompletedTask;
            },
            EventType = EventTypes.PermissionChanged, AggregateType = "Permission", AggregateId = p.Code,
            EventPayload = new { action = "updated", p.Code, dto.Target, dto.ResourceTypeId, dto.ResourceIds, dto.AllScopes, dto.ScopeIds, dto.PolicyIds, dto.IsActive },
            AuditSummary = $"Permission güncellendi: {p.Code} v{p.Version + 1} (aktif={dto.IsActive})",
            ExpectedModelVersion = expectedModelVersion
        }, ct);
        return new DefinitionChangeResult(id, impact, warnings);
    }

    public async Task<DefinitionChangeResult> DeleteAsync(int id, bool dryRun, long? expectedModelVersion, CancellationToken ct)
    {
        var p = await db.Permissions.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Permission", id);
        var request = new ImpactRequest
        {
            Patch =
            [
                ModelPatch.Remove("Permissions", new { Id = id }),
                ModelPatch.Remove("PermissionResources", new { PermissionId = id }),
                ModelPatch.Remove("PermissionScopes", new { PermissionId = id }),
                ModelPatch.Remove("PermissionPolicies", new { PermissionId = id })
            ]
        };

        if (dryRun) return new DefinitionChangeResult(id, await changes.PreviewAsync(request, ct), []);
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Impact = request,
            ApplyEntities = () => { db.Permissions.Remove(p); return Task.CompletedTask; },
            EventType = EventTypes.PermissionChanged, AggregateType = "Permission", AggregateId = p.Code,
            EventPayload = new { action = "deleted", p.Code },
            AuditSummary = $"Permission silindi: {p.Code}",
            ExpectedModelVersion = expectedModelVersion
        }, ct);
        return new DefinitionChangeResult(id, impact, []);
    }

    private static IEnumerable<ModelPatchOperation> Relations(int id, PermissionUpsert dto) =>
        dto.ResourceIds.Distinct().Select(r => ModelPatch.Add("PermissionResources", new PermissionResourceRow(id, r)))
            .Concat(dto.ScopeIds.Distinct().Select(s => ModelPatch.Add("PermissionScopes", new PermissionScopeRow(id, s))))
            .Concat(dto.PolicyIds.Distinct().Select((p, i) => ModelPatch.Add("PermissionPolicies", new PermissionPolicyRow(id, p, i))));

    /// <summary>
    /// Kapsam ve policy'leri doğrular. Hedef türüne ait olmayan alanlar temizlenir (tip hedefinde resource listesi, resource hedefinde tip...),
    /// böylece kapsam her zaman seçilen hedef türünden okunur. Uyarılar (kimlik policy'si yok, tüm uygulama, atıl) PDP'nin taslak
    /// değerlendirmesinden üretilir.
    /// </summary>
    private async Task<List<string>> ValidateAsync(PermissionUpsert dto, CancellationToken ct)
    {
        if (!await db.Applications.AnyAsync(a => a.Id == dto.ApplicationId, ct)) throw new NotFoundException("Uygulama", dto.ApplicationId);
        if (!Enum.IsDefined(dto.Target)) throw new ValidationException("Geçersiz hedef türü.");
        if (dto.Target == PermissionTarget.ResourceType)
        {
            if (dto.ResourceTypeId is not { } t) throw new ValidationException("Tip hedefinde resource tipi seçilmelidir.");
            if (!await db.ResourceTypes.AnyAsync(x => x.Id == t, ct)) throw new NotFoundException("Resource tipi", t);
        }
        if (dto.Target != PermissionTarget.ResourceType) dto.ResourceTypeId = null;
        if (dto.Target != PermissionTarget.Resources) dto.ResourceIds = [];
        if (dto.AllScopes) dto.ScopeIds = [];
        var resourceIds = dto.ResourceIds.Distinct().ToList();
        if (await db.Resources.CountAsync(r => resourceIds.Contains(r.Id) && r.ApplicationId == dto.ApplicationId, ct) != resourceIds.Count)
            throw new ValidationException("Resource'lar permission'ın uygulamasına ait olmalı.");
        var scopeIds = dto.ScopeIds.Distinct().ToList();
        if (await db.Scopes.CountAsync(s => scopeIds.Contains(s.Id) && s.ApplicationId == dto.ApplicationId, ct) != scopeIds.Count)
            throw new ValidationException("Scope'lar permission'ın uygulamasına ait olmalı.");
        if (dto.PolicyIds.Count == 0) throw new ValidationException("Permission en az bir policy içermelidir.");
        var policyIds = dto.PolicyIds.Distinct().ToList();
        var found = await db.Policies.Where(p => policyIds.Contains(p.Id)).Select(p => new { p.Id, p.TenantId, p.Code }).ToListAsync(ct);
        var missing = policyIds.Except(found.Select(x => x.Id)).ToList();
        if (missing.Count > 0) throw new ValidationException($"Bulunamayan policy: {string.Join(", ", missing)}");
        var applicationTenantId = await db.Applications.Where(a => a.Id == dto.ApplicationId).Select(a => a.TenantId).SingleAsync(ct);
        var availablePolicyTenants = await TenantHierarchy.AncestorsAsync(db, applicationTenantId, ct);
        foreach (var policy in found)
            if (!availablePolicyTenants.Contains(policy.TenantId))
                throw new ValidationException($"'{policy.Code}' policy'si permission uygulamasının tenant'ında kullanılamaz.");

        var info = await pdp.PermissionDraftAsync(new
        {
            dto.ApplicationId, dto.Code, dto.Name, dto.Target, dto.ResourceTypeId, dto.ResourceIds, dto.AllScopes, dto.ScopeIds, dto.PolicyIds,
            dto.DecisionStrategy, dto.IsActive
        }, ct);
        var warnings = new List<string>();
        if (!info.HasIdentityPolicy)
            warnings.Add("Bu permission kimlik şartı içermiyor (rol / grup / kullanıcı policy'si veya policy içinde KİM koşulu yok). Tek permission olduğu yetkilerde koşulları sağlayan HERKES erişir; " +
                         "başka permission'larla birlikte (uygulama stratejisi Unanimous) ise ek kısıt gibi davranır.");
        if (dto.Target == PermissionTarget.Application)
            warnings.Add("Hedef: uygulamadaki TÜM resource'lar — sonradan eklenen resource'lar da kendiliğinden bu permission'ın kitlesine açılır.");
        if (dto.AllScopes)
            warnings.Add("Scope: uygulamadaki TÜM scope'lar — sonradan eklenen scope'lar da otomatik olarak bu permission kapsamına girer.");
        if (dto.Target == PermissionTarget.Resources && dto.ResourceIds.Count == 0)
            warnings.Add("Resource seçilmedi: permission atıl kalır (hiçbir yetkiyi etkilemez).");
        if (!dto.AllScopes && dto.ScopeIds.Count == 0)
            warnings.Add("Scope seçilmedi: permission atıl kalır (hiçbir yetkiyi etkilemez).");
        if (info.CoverageCount == 0 && warnings.All(w => !w.Contains("atıl"))) warnings.Add("Kapsamda hiç yetki (resource:scope) yok: permission atıl.");
        return warnings;
    }
}
