using Microsoft.EntityFrameworkCore;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Changes;
using Yetki.Pap.Application.Common;
using Yetki.Pap.Application.Events;
using Yetki.Pap.Application.Integration;
using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Groups;
using Yetki.Pap.Domain.Policies;

namespace Yetki.Pap.Application.Definitions;

/// <summary>KİM kartı (kitle) → adlı grup. RuleIds: kitlesi birebir bu satırlar olan ve grupla değiştirilecek kurallar.</summary>
public sealed class AudiencePromote
{
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public List<GroupFilterDraft> Filters { get; set; } = new();
    public List<int> RuleIds { get; set; } = new();
}

/// <summary>Grup → KİM kartı satırları (tek kullanımlık grubu kaldırmak için).</summary>
public sealed class AudienceDemote
{
    public int GroupId { get; set; }
    public List<int> RuleIds { get; set; } = new();
}

public sealed record AudienceChangeResult(int? GroupId, string? GroupCode, bool GroupDeleted, ChangeImpactResult Impact);

/// <summary>
/// KİTLE = grup kuralı = KİM kartı. Aynı tanım iki biçim arasında taşınır:
///  - Gruba çevir: grup bu satırlarla oluşturulur; tanımı birebir aynı KİM kartları "grup X" ile değiştirilir.
///  - Karta geri al: tek kullanımlık grup (açık üyesi / rolü yok) kuralların içine satır olarak yazılır, kullanılmıyorsa silinir.
/// Her ikisinde de önce PDP'ye etkisi sorulur ve HİÇBİR kullanıcının erişimi değişmemelidir; değişiyorsa işlem durur
/// (ör. grup ROLE kriteri sadece doğrudan rollere, KİM kartı gruptan gelen rollere de bakar).
/// </summary>
public sealed class AudienceService(IYetkiDbContext db, IPdpClient pdp, ChangeGate changes, PolicyManagementService policies)
{
    public Task<AudienceOverlapResult> OverlapAsync(AudienceOverlapRequest request, CancellationToken ct) => pdp.AudienceOverlapAsync(request, ct);

    public async Task<AudienceChangeResult> PromoteAsync(AudiencePromote dto, bool dryRun, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (string.IsNullOrWhiteSpace(dto.Name)) throw new ValidationException("Grup adı zorunlu.");
        if (await db.Groups.AnyAsync(g => g.Code == code, ct)) throw new ConflictException($"Grup kodu zaten var: {code}");
        if (!await db.Tenants.AnyAsync(t => t.Id == dto.TenantId, ct)) throw new NotFoundException("Kurum", dto.TenantId);
        var ruleText = await pdp.ValidateGroupFiltersAsync(dto.Filters, ct);   // GROUP kriteri (grup içinde grup) burada reddedilir

        var overlap = await pdp.AudienceOverlapAsync(new AudienceOverlapRequest { TenantId = dto.TenantId, Filters = dto.Filters }, ct);
        var notSame = dto.RuleIds.Where(id => overlap.SameDefinition.All(r => r.RuleId != id)).ToList();
        if (notSame.Count > 0) throw new ValidationException($"Bu kuralların KİM kartı verilen satırlarla birebir aynı değil: {string.Join(", ", notSame)}");
        var rules = await db.Rules.Include(r => r.Policy).Where(r => dto.RuleIds.Contains(r.Id)).ToListAsync(ct);

        var groupCondition = new ConditionDraft { Kind = ConditionKind.Predicate, ConditionTypeCode = "SUBJECT_IN_GROUP", Parameters = new() { ["Groups"] = code } };
        var request = new ImpactRequest
        {
            Patch = [ModelPatch.Add("Groups", new GroupRow(-1, dto.TenantId, code, dto.Name, true))],
            Changes = new AuthorizationChangeSet { GroupFilters = [new GroupFiltersReplacement(-1, dto.Filters)] },
            PolicyChanges = new PolicyChangeSet { ReplacedRules = rules.Select(r => new RuleReplacement(r.Id, Draft(r, groupCondition))).ToList() }
        };
        var impact = await RequireNoAccessChangeAsync(request, "Gruba çevirme", ct);
        if (dryRun) return new AudienceChangeResult(null, code, false, impact);

        var typeId = await db.ConditionTypes.Where(t => t.Code == "SUBJECT_IN_GROUP" && t.IsAvailable).Select(t => (int?)t.Id).SingleOrDefaultAsync(ct)
                     ?? throw new ConflictException("SUBJECT_IN_GROUP koşul tipi katalogda yok (PDP açılışta senkronlar).");
        Group? group = null;
        impact = await changes.ApplyAsync(new ChangeCommand
        {
            Impact = request,
            ApplyEntities = async () =>
            {
                group = new Group { TenantId = dto.TenantId, Code = code, Name = dto.Name, Description = dto.Description, IsActive = true };
                AddFilters(group, dto.Filters);
                db.Groups.Add(group);
                foreach (var r in rules)
                {
                    policies.RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.RuleId == r.Id).ToListAsync(ct));
                    policies.AddConditionTree(r, null, groupCondition, 0, new ConditionValidation(groupCondition, $"SUBJECT_IN_GROUP(Groups={code})", new() { ["SUBJECT_IN_GROUP"] = typeId }, new()));
                    r.Policy.Version++;
                }
            },
            EventType = EventTypes.GroupFiltersChanged, AggregateType = "Group", AggregateId = code,
            EventPayload = new { action = "audience-promoted", code, dto.Filters, rules = rules.Select(r => $"{r.Policy.Code}/{r.Code}") },
            AuditSummary = $"KİM kartı gruba çevrildi: {code} = {ruleText}; kullanan kurallar: {string.Join(", ", rules.Select(r => $"{r.Policy.Code}/{r.Code}"))}"
        }, ct);
        return new AudienceChangeResult(group?.Id, code, false, impact);
    }

    public async Task<AudienceChangeResult> DemoteAsync(AudienceDemote dto, bool dryRun, CancellationToken ct)
    {
        var g = await db.Groups.Include(x => x.Filters).ThenInclude(f => f.Criteria).ThenInclude(c => c.Values)
                    .FirstOrDefaultAsync(x => x.Id == dto.GroupId, ct) ?? throw new NotFoundException("Grup", dto.GroupId);
        if (await db.GroupMembers.AnyAsync(m => m.GroupId == g.Id, ct)) throw new ConflictException($"'{g.Code}' açık (elle eklenmiş / süreli) üyeler içeriyor; KİM kartına alınamaz.");
        if (await db.GroupRoles.AnyAsync(r => r.GroupId == g.Id, ct)) throw new ConflictException($"'{g.Code}' üyelerine rol veriyor; KİM kartına alınamaz.");
        if (g.Filters.Count == 0) throw new ConflictException($"'{g.Code}' kitle kuralı içermiyor.");
        if (dto.RuleIds.Count == 0) throw new ValidationException("Gruba geri alınacak kural seçilmedi.");

        var rules = await db.Rules.Include(r => r.Policy).Where(r => dto.RuleIds.Contains(r.Id)).ToListAsync(ct);
        foreach (var r in rules)
        {
            var rows = await pdp.RuleAudienceAsync(r.Id, ct);
            var only = rows is [{ Mode: InclusionMode.Include, Criteria: [{ } c] }] && c.Attribute == "GROUP" && c.Values.Count == 1
                       && string.Equals(c.Values[0], g.Code, StringComparison.OrdinalIgnoreCase);
            if (!only) throw new ValidationException($"{r.Policy.Code}/{r.Code} kuralının KİM kartı sadece '{g.Code}' grubundan oluşmuyor.");
        }

        var filters = g.Filters.OrderBy(f => f.Order).Select(f => new GroupFilterDraft
        {
            Mode = f.Mode, Description = f.Description,
            Criteria = f.Criteria.OrderBy(c => c.Order).Select(c => new GroupCriterionDraft { Attribute = c.Attribute, Values = c.Values.Select(v => v.Value).ToList() }).ToList()
        }).ToList();
        var audience = await pdp.AudienceConditionAsync(filters, ct);

        // Grup başka bir KİM kartında kullanılmıyorsa silinir
        var otherRules = (await db.ConditionParameters.Where(p => p.Key == "Groups" && p.Condition.ConditionType!.Code == "SUBJECT_IN_GROUP" && !dto.RuleIds.Contains(p.Condition.RuleId))
                .Select(p => new { p.Value, p.Condition.RuleId }).ToListAsync(ct))
            .Where(x => x.Value.Split(',').Any(v => string.Equals(v.Trim(), g.Code, StringComparison.OrdinalIgnoreCase))).ToList();
        var delete = otherRules.Count == 0;

        var request = new ImpactRequest
        {
            PolicyChanges = new PolicyChangeSet { ReplacedRules = rules.Select(r => new RuleReplacement(r.Id, Draft(r, audience.Condition))).ToList() },
            Patch = delete ? [ModelPatch.Remove("Groups", new { Id = g.Id })] : null
        };
        var impact = await RequireNoAccessChangeAsync(request, "Karta geri alma", ct);
        if (dryRun) return new AudienceChangeResult(g.Id, g.Code, delete, impact);

        impact = await changes.ApplyAsync(new ChangeCommand
        {
            Impact = request,
            ApplyEntities = async () =>
            {
                foreach (var r in rules)
                {
                    var v = await pdp.ValidateConditionAsync(audience.Condition, r.PolicyId, ct);
                    policies.RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.RuleId == r.Id).ToListAsync(ct));
                    policies.AddConditionTree(r, null, v.Condition, 0, v);
                    r.Policy.Version++;
                }
                if (delete)
                {
                    foreach (var f in g.Filters.ToList())
                    {
                        foreach (var c in f.Criteria.ToList()) { db.GroupFilterValues.RemoveRange(c.Values); db.GroupFilterCriteria.Remove(c); }
                        db.GroupFilters.Remove(f);
                    }
                    db.Groups.Remove(g);
                }
            },
            EventType = EventTypes.GroupChanged, AggregateType = "Group", AggregateId = g.Code,
            EventPayload = new { action = "audience-demoted", g.Code, deleted = delete, rules = rules.Select(r => $"{r.Policy.Code}/{r.Code}") },
            AuditSummary = $"'{g.Code}' grubu KİM kartına alındı ({audience.Expression}); kurallar: {string.Join(", ", rules.Select(r => $"{r.Policy.Code}/{r.Code}"))}"
                           + (delete ? "; grup silindi" : "; grup başka yerde kullanıldığı için duruyor")
        }, ct);
        return new AudienceChangeResult(g.Id, g.Code, delete, impact);
    }

    private static RuleDraft Draft(Rule r, ConditionDraft condition) =>
        new() { PolicyId = r.PolicyId, Code = r.Code, Name = r.Name, Order = r.Order, ReasonCode = r.ReasonCode, Condition = condition };

    /// <summary>Kitle taşıma erişimi DEĞİŞTİRMEMELİ: değişiyorsa kimin neyi kazanıp kaybettiğiyle durur.</summary>
    private async Task<ChangeImpactResult> RequireNoAccessChangeAsync(ImpactRequest request, string what, CancellationToken ct)
    {
        var impact = await changes.PreviewAsync(request, ct);
        var changed = impact.Users.Where(u => u.AccessesChanged).ToList();
        if (changed.Count > 0)
            throw new ConflictException(
                $"{what} {changed.Count} kullanıcının erişimini değiştirirdi ({string.Join(", ", changed.Take(5).Select(u => u.UserName))}); işlem yapılmadı. " +
                "Not: grup ROLE kriteri sadece doğrudan atanmış rollere, KİM kartı gruptan gelen rollere de bakar.", impact);
        return impact;
    }

    private static void AddFilters(Group g, List<GroupFilterDraft> filters)
    {
        for (var i = 0; i < filters.Count; i++)
            g.Filters.Add(new GroupFilter
            {
                Mode = filters[i].Mode, Order = i, Description = filters[i].Description,
                Criteria = filters[i].Criteria.Select((c, j) => new GroupFilterCriterion
                {
                    Attribute = c.Attribute.Trim().ToUpperInvariant(), Order = j,
                    Values = c.Values.Select(v => v.Trim()).Where(v => v.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).Select(v => new GroupFilterValue { Value = v }).ToList()
                }).ToList()
            });
    }
}
