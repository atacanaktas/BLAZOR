using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Audit;
using Yetki.Pap.Application.Changes;
using Yetki.Pap.Application.Common;
using Yetki.Pap.Application.Events;
using Yetki.Pap.Application.Integration;
using Yetki.Pap.Domain.Catalog;
using Yetki.Pap.Domain.Common;

namespace Yetki.Pap.Application.Definitions;

public sealed class ApplicationUpsert
{
    /// <summary>Sahip tenant (oluştururken zorunlu; sonradan değiştirilemez).</summary>
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ApplicationType Type { get; set; }
    public int? OwnerTeamId { get; set; }
    public int? OwnerUserId { get; set; }
    public DecisionStrategy DecisionStrategy { get; set; } = DecisionStrategy.Unanimous;
    public bool IsActive { get; set; } = true;
}

public sealed class ResourceTypeUpsert
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool MatchesHttp { get; set; }
    public bool SupportsHierarchy { get; set; }
    public string? Color { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class ScopeUpsert
{
    public int ApplicationId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
}

public sealed class ResourceScopeDraft
{
    public int ScopeId { get; set; }
    public Severity RiskLevel { get; set; } = Severity.Medium;
}

public sealed class UriUpsert
{
    public string Method { get; set; } = "GET";
    public string Pattern { get; set; } = "/";
    public int ScopeId { get; set; }
}

public sealed class ResourceUpsert
{
    public int ApplicationId { get; set; }
    public int ResourceTypeId { get; set; }
    public int? ParentId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    /// <summary>Uygulamanın kendi kodu (ör. ekran kodu GVADAG00); envanter eşleştirmesi için. Uygulama içinde tekil.</summary>
    public string? ExternalCode { get; set; }
    public string? Description { get; set; }
    public int? OwnerTeamId { get; set; }
    public int Order { get; set; }
    public bool IsActive { get; set; } = true;
    /// <summary>Resource'un scope'ları (yetkiler). Güncellemede verilirse liste bununla değiştirilir.</summary>
    public List<ResourceScopeDraft>? Scopes { get; set; }
    /// <summary>Sadece oluştururken: ilk URI eşlemeleri (HTTP tiplerinde).</summary>
    public List<UriUpsert>? Uris { get; set; }
}

/// <summary>
/// Kaynak kataloğu = yetkilendirme tanımları (Keycloak resource server modeli): uygulama, gruplama seviyesi, resource tipi,
/// scope, resource, resource:scope (yetki) ve HTTP URI eşlemeleri. Kullanımdaki kayıt silinemez (ConflictException, 409).
/// Erişimi etkileyebilen değişikliklerden sonra etki yayınlanır (erişimi değişen kullanıcılar → RACF/LDAP mutabakatı).
/// </summary>
public sealed partial class CatalogService(
    IYetkiDbContext db, OutboxWriter outbox, AuditWriter audit, IIdentityDirectory identities, ChangeGate changes)
{
    public static readonly string[] HttpMethods = ["GET", "POST", "PUT", "PATCH", "DELETE", "*"];

    // ================================ Uygulama (resource server) ================================

    public async Task<CatalogApplication> CreateApplicationAsync(ApplicationUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        ValidateCode(code, "Uygulama kodu", upper: true);
        if (await db.Applications.AnyAsync(a => a.Code == code, ct)) throw new ConflictException($"Uygulama kodu zaten var: {code}");
        if (!await db.Tenants.AnyAsync(t => t.Id == dto.TenantId, ct)) throw new ValidationException("Uygulamanın sahibi olan tenant seçilmeli.");
        await ValidateOwnershipAsync(dto.TenantId, dto.OwnerTeamId, dto.OwnerUserId, ct);
        var app = new CatalogApplication
        {
            TenantId = dto.TenantId, Code = code, Name = dto.Name, Description = dto.Description, Type = dto.Type,
            OwnerTeamId = dto.OwnerTeamId, OwnerUserId = dto.OwnerUserId, DecisionStrategy = dto.DecisionStrategy, IsActive = dto.IsActive
        };
        db.Applications.Add(app);
        Changed("ApplicationCreated", code, $"Uygulama (resource server) eklendi: {code} ({dto.Type})", dto);
        await db.SaveChangesAsync(ct);
        return app;
    }

    public async Task<ChangeImpactResult> UpdateApplicationAsync(int id, ApplicationUpsert dto, CancellationToken ct)
    {
        var app = await db.Applications.FindAsync([id], ct) ?? throw new NotFoundException("Uygulama", id);
        await ValidateOwnershipAsync(app.TenantId, dto.OwnerTeamId, dto.OwnerUserId, ct);
        var impact = await changes.AnalyzeCatalogAsync(
            [ModelPatch.Replace("Applications", new { Id = id }, new AppRow(id, app.TenantId, app.Code, dto.Name, dto.Type, dto.DecisionStrategy, dto.IsActive))], ct);
        app.Name = dto.Name; app.Description = dto.Description; app.Type = dto.Type; app.DecisionStrategy = dto.DecisionStrategy;
        app.OwnerTeamId = dto.OwnerTeamId; app.OwnerUserId = dto.OwnerUserId; app.IsActive = dto.IsActive;
        Changed("ApplicationUpdated", app.Code, $"Uygulama güncellendi: {app.Code} (strateji={dto.DecisionStrategy}, aktif={dto.IsActive})", dto);
        await db.SaveChangesAsync(ct);
        return await changes.PublishAsync(impact, EventTypes.CatalogChanged, ct);
    }

    public async Task DeleteApplicationAsync(int id, CancellationToken ct)
    {
        var app = await db.Applications.FindAsync([id], ct) ?? throw new NotFoundException("Uygulama", id);
        var usage = new
        {
            resources = await db.Resources.CountAsync(r => r.ApplicationId == id, ct),
            scopes = await db.Scopes.CountAsync(s => s.ApplicationId == id, ct),
            permissions = await db.Permissions.CountAsync(p => p.ApplicationId == id, ct),
            clients = await db.Clients.CountAsync(c => c.ApplicationId == id, ct)
        };
        if (usage.resources + usage.scopes + usage.permissions + usage.clients > 0)
            throw new ConflictException($"'{app.Code}' kullanımda; silinemez.", usage);
        db.Applications.Remove(app);
        Changed("ApplicationDeleted", app.Code, $"Uygulama silindi: {app.Code}", new { id });
        await db.SaveChangesAsync(ct);
    }

    // ================================ Resource tipi ================================

    public async Task<ResourceType> CreateResourceTypeAsync(ResourceTypeUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        ValidateCode(code, "Tip kodu", upper: true);
        if (await db.ResourceTypes.AnyAsync(t => t.Code == code, ct)) throw new ConflictException($"Resource tipi zaten var: {code}");
        var t = new ResourceType
        {
            Code = code, Name = dto.Name, Description = dto.Description, MatchesHttp = dto.MatchesHttp,
            SupportsHierarchy = dto.SupportsHierarchy, Color = Blank(dto.Color), IsActive = dto.IsActive
        };
        db.ResourceTypes.Add(t);
        Changed("ResourceTypeCreated", code, $"Resource tipi eklendi: {code} (HTTP={dto.MatchesHttp}, hiyerarşi={dto.SupportsHierarchy})", dto);
        await db.SaveChangesAsync(ct);
        return t;
    }

    public async Task<ChangeImpactResult> UpdateResourceTypeAsync(int id, ResourceTypeUpsert dto, CancellationToken ct)
    {
        var t = await db.ResourceTypes.FindAsync([id], ct) ?? throw new NotFoundException("Resource tipi", id);
        if (t.MatchesHttp && !dto.MatchesHttp && await db.ResourceUris.AnyAsync(u => u.Resource.ResourceTypeId == id, ct))
            throw new ConflictException($"'{t.Code}' tipindeki resource'ların URI eşlemeleri var; önce URI'leri kaldırın.");
        var impact = await changes.AnalyzeCatalogAsync(
            [ModelPatch.Replace("ResourceTypes", new { Id = id }, new ResourceTypeRow(id, t.Code, dto.Name, dto.MatchesHttp, dto.SupportsHierarchy, Blank(dto.Color), dto.IsActive))], ct);
        t.Name = dto.Name; t.Description = dto.Description; t.MatchesHttp = dto.MatchesHttp; t.SupportsHierarchy = dto.SupportsHierarchy;
        t.Color = Blank(dto.Color); t.IsActive = dto.IsActive;
        Changed("ResourceTypeUpdated", t.Code, $"Resource tipi güncellendi: {t.Code} (aktif={dto.IsActive})", dto);
        await db.SaveChangesAsync(ct);
        return await changes.PublishAsync(impact, EventTypes.CatalogChanged, ct);
    }

    public async Task DeleteResourceTypeAsync(int id, CancellationToken ct)
    {
        var t = await db.ResourceTypes.FindAsync([id], ct) ?? throw new NotFoundException("Resource tipi", id);
        var usage = new
        {
            resources = await db.Resources.CountAsync(r => r.ResourceTypeId == id, ct),
            permissions = await db.Permissions.CountAsync(p => p.ResourceTypeId == id, ct)
        };
        if (usage.resources + usage.permissions > 0) throw new ConflictException($"'{t.Code}' kullanımda; silinemez.", usage);
        db.ResourceTypes.Remove(t);
        Changed("ResourceTypeDeleted", t.Code, $"Resource tipi silindi: {t.Code}", new { id });
        await db.SaveChangesAsync(ct);
    }

    // ================================ Scope ================================

    public async Task<Scope> CreateScopeAsync(ScopeUpsert dto, CancellationToken ct)
    {
        var app = await db.Applications.FindAsync([dto.ApplicationId], ct) ?? throw new NotFoundException("Uygulama", dto.ApplicationId);
        var code = Codes.Lower(dto.Code);
        if (!ScopeCodeRegex().IsMatch(code)) throw new ValidationException("Scope kodu küçük harf, rakam, '-' veya '_' içerebilir (ör. view, close, approve).");
        if (await db.Scopes.AnyAsync(s => s.ApplicationId == app.Id && s.Code == code, ct)) throw new ConflictException($"{app.Code} uygulamasında '{code}' scope'u zaten var.");
        var s = new Scope { ApplicationId = app.Id, Code = code, Name = dto.Name, Description = dto.Description };
        db.Scopes.Add(s);
        Changed("ScopeCreated", $"{app.Code}:{code}", $"Scope eklendi: {app.Code} · {code}", dto);
        await db.SaveChangesAsync(ct);
        return s;
    }

    public async Task UpdateScopeAsync(int id, ScopeUpsert dto, CancellationToken ct)
    {
        var s = await db.Scopes.FindAsync([id], ct) ?? throw new NotFoundException("Scope", id);
        s.Name = dto.Name; s.Description = dto.Description;
        Changed("ScopeUpdated", s.Code, $"Scope güncellendi: {s.Code}", dto);
        await db.SaveChangesAsync(ct);
    }

    public async Task DeleteScopeAsync(int id, CancellationToken ct)
    {
        var s = await db.Scopes.FindAsync([id], ct) ?? throw new NotFoundException("Scope", id);
        var usage = new
        {
            resources = await db.ResourceScopes.CountAsync(x => x.ScopeId == id, ct),
            permissions = await db.PermissionScopes.CountAsync(x => x.ScopeId == id, ct)
        };
        if (usage.resources + usage.permissions > 0) throw new ConflictException($"'{s.Code}' scope'u kullanımda; silinemez.", usage);
        db.Scopes.Remove(s);
        Changed("ScopeDeleted", s.Code, $"Scope silindi: {s.Code}", new { id });
        await db.SaveChangesAsync(ct);
    }

    // ================================ Resource ================================

    public async Task<(Resource Resource, ChangeImpactResult Impact)> CreateResourceAsync(ResourceUpsert dto, CancellationToken ct)
    {
        var app = await db.Applications.FindAsync([dto.ApplicationId], ct) ?? throw new NotFoundException("Uygulama", dto.ApplicationId);
        var code = Codes.Lower(dto.Code);
        if (!ResourceCodeRegex().IsMatch(code))
            throw new ValidationException("Resource kodu küçük harf, rakam, '.', '-' veya '_' içerebilir; harfle başlamalı (ör. anka.vadelihesap).");
        if (await db.Resources.AnyAsync(r => r.Code == code, ct)) throw new ConflictException($"Resource kodu zaten var: {code}");
        var type = await ValidatePlacementAsync(app, dto, null, ct);
        var scopes = await ValidateScopesAsync(app.Id, dto.Scopes ?? [], ct);
        var uris = dto.Uris ?? [];
        if (uris.Count > 0 && !type.MatchesHttp) throw new ValidationException($"'{type.Code}' tipi HTTP ile eşleşmez; URI tanımlanamaz.");
        foreach (var u in uris) await NormalizeUriAsync(app.Id, u, scopes.Select(s => s.ScopeId).ToHashSet(), null, ct);

        const int draftId = -1;
        var patch = new List<ModelPatchOperation>
        {
            ModelPatch.Add("Resources", new ResourceRow(draftId, app.Id, type.Id, dto.ParentId, code, dto.Name, Blank(dto.ExternalCode), dto.Order, dto.IsActive))
        };
        patch.AddRange(scopes.Select((s, i) => ModelPatch.Add("ResourceScopes", new ResourceScopeRow(-1 - i, draftId, s.ScopeId, s.RiskLevel))));
        patch.AddRange(uris.Select((u, i) => ModelPatch.Add("Uris", new UriRow(-1 - i, draftId, u.Method, u.Pattern, u.ScopeId))));
        var impact = await changes.AnalyzeCatalogAsync(patch, ct);
        var r = new Resource
        {
            ApplicationId = app.Id, ResourceTypeId = type.Id, ParentId = dto.ParentId, Code = code, Name = dto.Name, ExternalCode = Blank(dto.ExternalCode),
            Description = dto.Description, OwnerTeamId = dto.OwnerTeamId, Order = dto.Order, IsActive = dto.IsActive,
            Scopes = scopes.Select(s => new ResourceScope { ScopeId = s.ScopeId, RiskLevel = s.RiskLevel }).ToList(),
            Uris = uris.Select(u => new ResourceUri { Method = u.Method, Pattern = u.Pattern, ScopeId = u.ScopeId }).ToList()
        };
        db.Resources.Add(r);
        Changed("ResourceCreated", code, $"Resource eklendi: {code} ({type.Code}) · {scopes.Count} scope, {uris.Count} URI", dto);
        await db.SaveChangesAsync(ct);
        return (r, await changes.PublishAsync(impact, EventTypes.CatalogChanged, ct));
    }

    public async Task<ChangeImpactResult> UpdateResourceAsync(int id, ResourceUpsert dto, CancellationToken ct)
    {
        var r = await db.Resources.Include(x => x.Scopes).Include(x => x.Uris).FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Resource", id);
        var app = await db.Applications.FindAsync([r.ApplicationId], ct) ?? throw new NotFoundException("Uygulama", r.ApplicationId);
        dto.ApplicationId = r.ApplicationId;
        var type = await ValidatePlacementAsync(app, dto, r, ct);
        if (!type.MatchesHttp && r.Uris.Count > 0) throw new ValidationException($"'{type.Code}' tipi HTTP ile eşleşmez; önce URI eşlemelerini kaldırın.");

        var patch = new List<ModelPatchOperation>
        {
            ModelPatch.Replace("Resources", new { Id = r.Id }, new ResourceRow(r.Id, r.ApplicationId, type.Id, dto.ParentId, r.Code, dto.Name, Blank(dto.ExternalCode), dto.Order, dto.IsActive))
        };
        var draftScopeId = -1;
        if (dto.Scopes is not null)
        {
            var scopes = await ValidateScopesAsync(app.Id, dto.Scopes, ct);
            var wanted = scopes.ToDictionary(s => s.ScopeId);
            foreach (var rs in r.Scopes.Where(x => !wanted.ContainsKey(x.ScopeId)).ToList())
            {
                await EnsureResourceScopeRemovableAsync(rs, r, ct);
                db.ResourceScopes.Remove(rs);
                patch.Add(ModelPatch.Remove("ResourceScopes", new { Id = rs.Id }));
            }
            foreach (var s in scopes)
            {
                var existing = r.Scopes.FirstOrDefault(x => x.ScopeId == s.ScopeId);
                if (existing is null)
                {
                    db.ResourceScopes.Add(new ResourceScope { ResourceId = r.Id, ScopeId = s.ScopeId, RiskLevel = s.RiskLevel });
                    patch.Add(ModelPatch.Add("ResourceScopes", new ResourceScopeRow(draftScopeId--, r.Id, s.ScopeId, s.RiskLevel)));
                }
                else
                {
                    existing.RiskLevel = s.RiskLevel;
                    patch.Add(ModelPatch.Replace("ResourceScopes", new { Id = existing.Id }, new ResourceScopeRow(existing.Id, r.Id, s.ScopeId, s.RiskLevel)));
                }
            }
        }
        var impact = await changes.AnalyzeCatalogAsync(patch, ct);
        r.ExternalCode = Blank(dto.ExternalCode); r.ResourceTypeId = type.Id; r.ParentId = dto.ParentId; r.Name = dto.Name; r.Description = dto.Description;
        r.OwnerTeamId = dto.OwnerTeamId; r.Order = dto.Order; r.IsActive = dto.IsActive;
        Changed("ResourceUpdated", r.Code, $"Resource güncellendi: {r.Code} (aktif={dto.IsActive})", dto);
        await db.SaveChangesAsync(ct);
        return await changes.PublishAsync(impact, EventTypes.CatalogChanged, ct);
    }

    public async Task DeleteResourceAsync(int id, CancellationToken ct)
    {
        var r = await db.Resources.Include(x => x.Scopes).FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Resource", id);
        var rsIds = r.Scopes.Select(s => s.Id).ToList();
        var usage = new
        {
            children = await db.Resources.CountAsync(x => x.ParentId == id, ct),
            permissions = await db.PermissionResources.CountAsync(x => x.ResourceId == id, ct),
            externalDependencies = await db.ExternalDependencies.CountAsync(d => d.ResourceId == id || (d.ResourceScopeId != null && rsIds.Contains(d.ResourceScopeId.Value)), ct),
            sodRules = await db.SodRuleMembers.CountAsync(m => m.MemberType == SodMemberType.ResourceScope && rsIds.Contains(m.MemberId), ct)
        };
        if (usage.children + usage.permissions + usage.externalDependencies + usage.sodRules > 0)
            throw new ConflictException($"'{r.Code}' kullanımda; silinemez.", usage);
        var impact = await changes.AnalyzeCatalogAsync(
        [
            ModelPatch.Remove("Resources", new { Id = id }),
            ModelPatch.Remove("ResourceScopes", new { ResourceId = id }),
            ModelPatch.Remove("Uris", new { ResourceId = id })
        ], ct);
        db.Resources.Remove(r);
        Changed("ResourceDeleted", r.Code, $"Resource silindi: {r.Code}", new { id });
        await db.SaveChangesAsync(ct);
        await changes.PublishAsync(impact, EventTypes.CatalogChanged, ct);
    }

    // ------------------------------ URI eşlemesi ------------------------------

    public async Task<ResourceUri> AddUriAsync(int resourceId, UriUpsert dto, CancellationToken ct)
    {
        var r = await db.Resources.Include(x => x.ResourceType).Include(x => x.Scopes).FirstOrDefaultAsync(x => x.Id == resourceId, ct)
                ?? throw new NotFoundException("Resource", resourceId);
        if (!r.ResourceType.MatchesHttp) throw new ValidationException($"'{r.ResourceType.Code}' tipi HTTP ile eşleşmez; URI tanımlanamaz.");
        await NormalizeUriAsync(r.ApplicationId, dto, r.Scopes.Select(s => s.ScopeId).ToHashSet(), null, ct);
        var u = new ResourceUri { ResourceId = r.Id, Method = dto.Method, Pattern = dto.Pattern, ScopeId = dto.ScopeId };
        db.ResourceUris.Add(u);
        Changed("ResourceUriAdded", r.Code, $"URI eşlemesi eklendi: {dto.Method} {dto.Pattern} → {r.Code}", dto);
        await db.SaveChangesAsync(ct);
        return u;
    }

    public async Task UpdateUriAsync(int id, UriUpsert dto, CancellationToken ct)
    {
        var u = await db.ResourceUris.Include(x => x.Resource).ThenInclude(r => r.Scopes).FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("URI", id);
        await NormalizeUriAsync(u.Resource.ApplicationId, dto, u.Resource.Scopes.Select(s => s.ScopeId).ToHashSet(), id, ct);
        u.Method = dto.Method; u.Pattern = dto.Pattern; u.ScopeId = dto.ScopeId;
        Changed("ResourceUriUpdated", u.Resource.Code, $"URI eşlemesi güncellendi: {dto.Method} {dto.Pattern} → {u.Resource.Code}", dto);
        await db.SaveChangesAsync(ct);
    }

    public async Task DeleteUriAsync(int id, CancellationToken ct)
    {
        var u = await db.ResourceUris.Include(x => x.Resource).FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("URI", id);
        db.ResourceUris.Remove(u);
        Changed("ResourceUriDeleted", u.Resource.Code, $"URI eşlemesi silindi: {u.Method} {u.Pattern} ({u.Resource.Code}) — bu URI'ye gelen istekler artık reddedilir", new { id });
        await db.SaveChangesAsync(ct);
    }

    // ================================ Yardımcılar ================================

    private async Task<ResourceType> ValidatePlacementAsync(CatalogApplication app, ResourceUpsert dto, Resource? self, CancellationToken ct)
    {
        var type = await db.ResourceTypes.FindAsync([dto.ResourceTypeId], ct) ?? throw new NotFoundException("Resource tipi", dto.ResourceTypeId);
        if (Blank(dto.ExternalCode) is { } ext
            && await db.Resources.AnyAsync(x => x.ApplicationId == app.Id && x.ExternalCode == ext && (self == null || x.Id != self.Id), ct))
            throw new ConflictException($"{app.Code} uygulamasında '{ext}' uygulama kodu başka bir resource'ta kullanılıyor.");
        if (dto.ParentId is { } parentId)
        {
            var parent = await db.Resources.FindAsync([parentId], ct) ?? throw new NotFoundException("Üst resource", parentId);
            if (parent.ApplicationId != app.Id) throw new ValidationException("Üst resource aynı uygulamada olmalı.");
            if (self is not null)
            {
                int? cur = parentId;
                var seen = new HashSet<int>();
                while (cur is { } c && seen.Add(c))
                {
                    if (c == self.Id) throw new ValidationException("Döngüsel üst-alt ilişkisi oluşur.");
                    cur = await db.Resources.Where(x => x.Id == c).Select(x => x.ParentId).FirstOrDefaultAsync(ct);
                }
            }
        }
        if (dto.OwnerTeamId is { } teamId && !await db.OwnershipTeams.AnyAsync(t => t.Id == teamId && t.TenantId == app.TenantId && t.IsActive, ct))
            throw new ValidationException("Sahip ekip bu tenant'ın aktif ekiplerinden seçilmeli.");
        return type;
    }

    private async Task<List<ResourceScopeDraft>> ValidateScopesAsync(int applicationId, List<ResourceScopeDraft> scopes, CancellationToken ct)
    {
        var ids = scopes.Select(s => s.ScopeId).Distinct().ToList();
        if (await db.Scopes.CountAsync(s => ids.Contains(s.Id) && s.ApplicationId == applicationId, ct) != ids.Count)
            throw new ValidationException("Scope'lar resource'un uygulamasına ait olmalı.");
        return scopes.DistinctBy(s => s.ScopeId).ToList();
    }

    private async Task EnsureResourceScopeRemovableAsync(ResourceScope rs, Resource r, CancellationToken ct)
    {
        var scope = await db.Scopes.Where(s => s.Id == rs.ScopeId).Select(s => s.Code).FirstAsync(ct);
        var usage = new
        {
            uris = r.Uris.Count(u => u.ScopeId == rs.ScopeId),
            externalDependencies = await db.ExternalDependencies.CountAsync(d => d.ResourceScopeId == rs.Id, ct),
            sodRules = await db.SodRuleMembers.CountAsync(m => m.MemberType == SodMemberType.ResourceScope && m.MemberId == rs.Id, ct)
        };
        if (usage.uris + usage.externalDependencies + usage.sodRules > 0)
            throw new ConflictException($"'{r.Code}:{scope}' kullanımda; scope kaldırılamaz.", usage);
    }

    /// <summary>METHOD ve deseni normalize eder; scope resource'a ait olmalı; aynı uygulamada aynı METHOD + desen ikinci kez tanımlanamaz.</summary>
    private async Task NormalizeUriAsync(int applicationId, UriUpsert u, IReadOnlySet<int> resourceScopeIds, int? selfId, CancellationToken ct)
    {
        u.Method = (u.Method ?? "").Trim().ToUpperInvariant();
        if (!HttpMethods.Contains(u.Method)) throw new ValidationException($"Geçersiz HTTP metodu: {u.Method}. Geçerli: {string.Join(", ", HttpMethods)}");
        var p = (u.Pattern ?? "").Trim().Split('?')[0];
        if (!p.StartsWith('/')) throw new ValidationException("URI deseni '/' ile başlamalı (ör. /v1/vadeli-hesap/{hesapNo}).");
        var segments = p.Split('/', StringSplitOptions.RemoveEmptyEntries);
        for (var i = 0; i < segments.Length; i++)
            if (segments[i] == "**" && i != segments.Length - 1) throw new ValidationException("'**' sadece desenin son segmenti olabilir.");
        u.Pattern = "/" + string.Join('/', segments);
        if (!resourceScopeIds.Contains(u.ScopeId)) throw new ValidationException("URI'nin eşlendiği scope resource'un scope'larından biri olmalı.");
        var pattern = u.Pattern;
        var method = u.Method;
        var clash = await db.ResourceUris.Where(x => x.Resource.ApplicationId == applicationId && x.Method == method && x.Pattern == pattern && x.Id != selfId)
            .Select(x => x.Resource.Code).FirstOrDefaultAsync(ct);
        if (clash is not null) throw new ConflictException($"{method} {pattern} zaten '{clash}' resource'una eşlenmiş.");
    }

    private async Task ValidateOwnershipAsync(int tenantId, int? teamId, int? userId, CancellationToken ct)
    {
        if (teamId is { } tid && !await db.OwnershipTeams.AnyAsync(t => t.Id == tid && t.TenantId == tenantId && t.IsActive, ct))
            throw new ValidationException("Sahip ekip bu tenant'ın aktif ekiplerinden seçilmeli.");
        if (userId is { } uid)
        {
            var user = await identities.GetUserAsync(uid, ct);
            if (user is null || !user.IsActive || user.TenantId != tenantId) throw new ValidationException("Sorumlu kullanıcı bu tenant'ın aktif kullanıcısı olmalı.");
        }
    }

    private static void ValidateCode(string code, string label, bool upper)
    {
        if (string.IsNullOrWhiteSpace(code) || code.Contains('/') || code.Contains(':') || code.Contains(' '))
            throw new ValidationException($"{label} boş olamaz; '/', ':' veya boşluk içeremez.");
    }

    private static string? Blank(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    private void Changed(string action, string code, string summary, object? details = null)
    {
        audit.Management(action, "Catalog", code, summary, details);
        outbox.Add(EventTypes.CatalogChanged, "Catalog", code, new { action, code });
    }

    [GeneratedRegex("^[a-z][a-z0-9._-]{1,127}$")]
    private static partial Regex ResourceCodeRegex();

    [GeneratedRegex("^[a-z][a-z0-9_-]{0,31}$")]
    private static partial Regex ScopeCodeRegex();
}
