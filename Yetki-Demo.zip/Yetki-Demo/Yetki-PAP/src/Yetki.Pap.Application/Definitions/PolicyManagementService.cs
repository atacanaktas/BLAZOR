using Microsoft.EntityFrameworkCore;
using Yetki.Pap.Application.Abstractions;
using Yetki.Pap.Application.Audit;
using Yetki.Pap.Application.Changes;
using Yetki.Pap.Application.Common;
using Yetki.Pap.Application.Events;
using Yetki.Pap.Application.Integration;
using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Policies;

namespace Yetki.Pap.Application.Definitions;

public sealed class PolicyUpsert
{
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public PolicyLogic Logic { get; set; } = PolicyLogic.Positive;
    /// <summary>Kuralların (kartların) birleştirilmesi.</summary>
    public DecisionStrategy DecisionStrategy { get; set; } = DecisionStrategy.Unanimous;
    public PolicyMode Mode { get; set; } = PolicyMode.Enforce;
    public bool IsActive { get; set; } = true;
}

public sealed class RuleUpsert
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public int Order { get; set; }
    public string? ReasonCode { get; set; }
    public bool IsActive { get; set; } = true;
    public ConditionDraft Condition { get; set; } = new();
}

public sealed class ObligationUpsert
{
    public string Code { get; set; } = default!;
    public ObligationFulfillOn FulfillOn { get; set; } = ObligationFulfillOn.Permit;
    public int Order { get; set; }
    public Dictionary<string, string> Parameters { get; set; } = new();
}

/// <summary>Tanım değişikliği sonucu: kayıt id'si + erişim etkisi (dryRun'da uygulanmaz) + uyarılar.</summary>
public sealed record DefinitionChangeResult(int? Id, ChangeImpactResult Impact, IReadOnlyList<string> Warnings);

/// <summary>
/// Policy yönetimi. Policy'nin TİPİ yoktur: kuralları (yönetim ekranında soru kartları) vardır.
///  - Policy ayarı (logic, strateji, mod, aktiflik) erişimi değiştirebilir → etki analizi (PDP, dryRun ile önizleme),
///    SoD Block kontrolü ve RACF/LDAP mutabakatı ChangeGate üzerinden.
///  - Kurallar ve yükümlülükler PDP'deki handler'lara doğrulatılır (davranış kodu PDP'dedir).
///  - Her değişiklik Policy.Version'ı artırır; kararlar versiyonla audit'lenir; PolicyChanged event'i üretilir.
/// </summary>
public sealed class PolicyManagementService(
    IYetkiDbContext db,
    IPdpClient pdp,
    ChangeGate changes,
    OutboxWriter outbox,
    AuditWriter audit)
{
    // ================================ Policy ================================

    public async Task<DefinitionChangeResult> CreatePolicyAsync(PolicyUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Policies.AnyAsync(p => p.Code == code, ct)) throw new ConflictException($"Policy kodu zaten var: {code}");
        if (!await db.Tenants.AnyAsync(o => o.Id == dto.TenantId, ct)) throw new NotFoundException("Kurum", dto.TenantId);
        var p = new Policy
        {
            TenantId = dto.TenantId, Code = code, Name = dto.Name, Description = dto.Description, Logic = dto.Logic,
            DecisionStrategy = dto.DecisionStrategy, Mode = dto.Mode, IsActive = dto.IsActive, Version = 1
        };
        db.Policies.Add(p);
        audit.Management("PolicyCreated", "Policy", code, $"Policy oluşturuldu: {code} ({dto.Logic}, {dto.DecisionStrategy}, {dto.Mode})", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", code, new { action = "created", code });
        await db.SaveChangesAsync(ct);
        // Henüz hiçbir permission kullanmadığı için erişim değişmez.
        return new DefinitionChangeResult(p.Id, ChangeImpactResult.Unchanged("Yeni policy henüz bir permission'da kullanılmıyor; erişim değişmez."), []);
    }

    /// <summary>Policy ayarını (ad, logic, strateji, mod, aktiflik) günceller. dryRun: sadece erişim etkisi döner.</summary>
    public async Task<DefinitionChangeResult> UpdatePolicyAsync(int id, PolicyUpsert dto, bool dryRun, long? expectedModelVersion, CancellationToken ct)
    {
        var p = await db.Policies.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Policy", id);
        var request = new ImpactRequest
        {
            Patch = [ModelPatch.Replace("Policies", new { Id = id }, new PolicyRow(id, p.TenantId, p.Code, dto.Name, dto.Logic, dto.DecisionStrategy, dto.Mode, dto.IsActive, p.Version + 1))]
        };

        if (dryRun) return new DefinitionChangeResult(id, await changes.PreviewAsync(request, ct), []);
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Impact = request,
            ApplyEntities = () =>
            {
                p.Name = dto.Name; p.Description = dto.Description; p.Logic = dto.Logic; p.DecisionStrategy = dto.DecisionStrategy;
                p.Mode = dto.Mode; p.IsActive = dto.IsActive; p.Version++;
                return Task.CompletedTask;
            },
            EventType = EventTypes.PolicyChanged, AggregateType = "Policy", AggregateId = p.Code,
            EventPayload = new { action = "updated", p.Code, dto.Logic, dto.DecisionStrategy, dto.Mode, dto.IsActive },
            AuditSummary = $"Policy güncellendi: {p.Code} v{p.Version + 1} ({dto.Logic}, {dto.DecisionStrategy}, {dto.Mode}, aktif={dto.IsActive})",
            ExpectedModelVersion = expectedModelVersion
        }, ct);
        return new DefinitionChangeResult(id, impact, []);
    }

    public async Task DeletePolicyAsync(int id, CancellationToken ct)
    {
        var p = await db.Policies.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Policy", id);
        var usage = new
        {
            permissions = await db.PermissionPolicies.Where(x => x.PolicyId == id).Select(x => x.Permission.Code).ToListAsync(ct),
            // Başka policy'lerin kurallarında (HAZIR POLICY kartı) kullanılıyor
            referencedBy = await db.RuleConditions.Where(c => c.ReferencedPolicyId == id).Select(c => c.Rule.Policy.Code + "/" + c.Rule.Code).Distinct().ToListAsync(ct)
        };
        if (usage.permissions.Count + usage.referencedBy.Count > 0) throw new ConflictException($"'{p.Code}' kullanımda; silinemez.", usage);
        foreach (var rule in await db.Rules.Where(r => r.PolicyId == id).ToListAsync(ct))
            RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.RuleId == rule.Id).ToListAsync(ct));
        db.Policies.Remove(p);
        audit.Management("PolicyDeleted", "Policy", p.Code, $"Policy silindi: {p.Code}");
        outbox.Add(EventTypes.PolicyChanged, "Policy", p.Code, new { action = "deleted", p.Code });
        await db.SaveChangesAsync(ct);
    }

    // ------------------------------ Yükümlülük ------------------------------

    public async Task<DefinitionChangeResult> AddObligationAsync(int policyId, ObligationUpsert dto, bool dryRun, long? expectedModelVersion, CancellationToken ct)
    {
        var p = await db.Policies.FindAsync([policyId], ct) ?? throw new NotFoundException("Policy", policyId);
        var v = await pdp.ValidateObligationAsync(dto.Code, dto.Parameters, ct);
        var row = new PolicyObligation
        {
            PolicyId = policyId, Code = v.Code, FulfillOn = dto.FulfillOn, Order = dto.Order,
            Parameters = v.Parameters.Select(kv => new PolicyObligationParameter { Key = kv.Key, Value = kv.Value }).ToList()
        };
        var text = $"{v.Code}({string.Join(", ", v.Parameters.Select(kv => $"{kv.Key}={kv.Value}"))}) · {dto.FulfillOn}";
        var request = new ImpactRequest();
        var warning = $"Yükümlülük kararı değiştirmez fakat PEP davranışını değiştirir: {text}";
        if (dryRun) return new DefinitionChangeResult(null, await changes.PreviewAsync(request, ct), [warning]);
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Impact = request,
            ApplyEntities = () => { db.PolicyObligations.Add(row); p.Version++; return Task.CompletedTask; },
            EventType = EventTypes.PolicyChanged, AggregateType = "Policy", AggregateId = p.Code,
            EventPayload = new { action = "obligation-added", policy = p.Code, obligation = text },
            AuditSummary = $"'{p.Code}' policy'sine yükümlülük eklendi: {text}",
            ExpectedModelVersion = expectedModelVersion
        }, ct);
        return new DefinitionChangeResult(row.Id, impact, [warning]);
    }

    public async Task<DefinitionChangeResult> RemoveObligationAsync(int id, bool dryRun, long? expectedModelVersion, CancellationToken ct)
    {
        var o = await db.PolicyObligations.Include(x => x.Policy).FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Yükümlülük", id);
        var request = new ImpactRequest();
        var warning = $"'{o.Code}' yükümlülüğü kaldırılırsa PEP artık bu davranışı uygulamaz; veri maskeleme veya audit etkilenebilir.";
        if (dryRun) return new DefinitionChangeResult(id, await changes.PreviewAsync(request, ct), [warning]);
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Impact = request,
            ApplyEntities = () => { db.PolicyObligations.Remove(o); o.Policy.Version++; return Task.CompletedTask; },
            EventType = EventTypes.PolicyChanged, AggregateType = "Policy", AggregateId = o.Policy.Code,
            EventPayload = new { action = "obligation-removed", policy = o.Policy.Code, obligation = o.Code },
            AuditSummary = $"'{o.Policy.Code}' policy'sinden yükümlülük kaldırıldı: {o.Code}",
            ExpectedModelVersion = expectedModelVersion
        }, ct);
        return new DefinitionChangeResult(id, impact, [warning]);
    }

    // ================================ Rule (Condition policy) ================================

    public async Task<DefinitionChangeResult> CreateRuleAsync(int policyId, RuleUpsert dto, long? expectedModelVersion, CancellationToken ct)
    {
        var policy = await db.Policies.FindAsync([policyId], ct) ?? throw new NotFoundException("Policy", policyId);
        var code = Codes.Normalize(dto.Code);
        if (await db.Rules.AnyAsync(r => r.PolicyId == policyId && r.Code == code, ct))
            throw new ConflictException($"'{policy.Code}' policy'sinde bu rule kodu zaten var: {code}");
        var v = await pdp.ValidateConditionAsync(dto.Condition, policyId, ct);

        var rule = new Rule
        {
            PolicyId = policyId, Code = code, Name = dto.Name, Description = dto.Description,
            Order = dto.Order, ReasonCode = NormalizeReason(dto.ReasonCode), IsActive = dto.IsActive
        };
        var request = new ImpactRequest { PolicyChanges = new PolicyChangeSet { AddedRules = [Draft(policyId, code, dto, v.Condition)] } };
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Impact = request,
            ApplyEntities = () =>
            {
                db.Rules.Add(rule);
                AddConditionTree(rule, null, v.Condition, 0, v);
                policy.Version++;
                return Task.CompletedTask;
            },
            EventType = EventTypes.PolicyChanged, AggregateType = "Policy", AggregateId = policy.Code,
            EventPayload = new { action = "rule-created", policy = policy.Code, rule = code },
            AuditSummary = $"'{policy.Code}' policy'sine rule eklendi: {code} (sağlanmalı: {v.Expression})",
            ExpectedModelVersion = expectedModelVersion
        }, ct);
        return new DefinitionChangeResult(rule.Id, impact, []);
    }

    public async Task<DefinitionChangeResult> UpdateRuleAsync(int ruleId, RuleUpsert dto, long? expectedModelVersion, CancellationToken ct)
    {
        var rule = await db.Rules.Include(r => r.Policy).FirstOrDefaultAsync(r => r.Id == ruleId, ct) ?? throw new NotFoundException("Rule", ruleId);
        var v = await pdp.ValidateConditionAsync(dto.Condition, rule.PolicyId, ct);
        var request = new ImpactRequest { PolicyChanges = new PolicyChangeSet { ReplacedRules = [new(ruleId, Draft(rule.PolicyId, rule.Code, dto, v.Condition))] } };
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Impact = request,
            ApplyEntities = async () =>
            {
                rule.Name = dto.Name; rule.Description = dto.Description;
                rule.Order = dto.Order; rule.ReasonCode = NormalizeReason(dto.ReasonCode); rule.IsActive = dto.IsActive;
                RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.RuleId == ruleId).ToListAsync(ct));
                AddConditionTree(rule, null, v.Condition, 0, v);
                rule.Policy.Version++;
            },
            EventType = EventTypes.PolicyChanged, AggregateType = "Policy", AggregateId = rule.Policy.Code,
            EventPayload = new { action = "rule-updated", policy = rule.Policy.Code, rule = rule.Code },
            AuditSummary = $"'{rule.Policy.Code}' policy'sinde rule güncellendi: {rule.Code} (sağlanmalı: {v.Expression})",
            ExpectedModelVersion = expectedModelVersion
        }, ct);
        return new DefinitionChangeResult(ruleId, impact, []);
    }

    public async Task<DefinitionChangeResult> DeleteRuleAsync(int ruleId, long? expectedModelVersion, CancellationToken ct)
    {
        var rule = await db.Rules.Include(r => r.Policy).FirstOrDefaultAsync(r => r.Id == ruleId, ct) ?? throw new NotFoundException("Rule", ruleId);
        var policy = rule.Policy;
        var code = rule.Code;
        var request = new ImpactRequest { PolicyChanges = new PolicyChangeSet { RemovedRuleIds = [ruleId] } };
        var impact = await changes.ApplyAsync(new ChangeCommand
        {
            Impact = request,
            ApplyEntities = async () =>
            {
                RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.RuleId == ruleId).ToListAsync(ct));
                db.Rules.Remove(rule);
                policy.Version++;
            },
            EventType = EventTypes.PolicyChanged, AggregateType = "Policy", AggregateId = policy.Code,
            EventPayload = new { action = "rule-deleted", policy = policy.Code, rule = code },
            AuditSummary = $"'{policy.Code}' policy'sinden rule silindi: {code}",
            ExpectedModelVersion = expectedModelVersion
        }, ct);
        return new DefinitionChangeResult(ruleId, impact, []);
    }

    // ================================ Condition ağacı ================================

    /// <summary>Doğrulanmış condition ağacını rule'un altına entity olarak ekler. Reference düğümü policy'ye bağlanır (kopya değil).</summary>
    internal void AddConditionTree(Rule rule, RuleCondition? parent, ConditionDraft draft, int order, ConditionValidation v)
    {
        var node = new RuleCondition
        {
            Rule = rule, Parent = parent, Kind = draft.Kind, Order = order,
            ConditionTypeId = draft.Kind == ConditionKind.Predicate ? v.ConditionTypes[draft.ConditionTypeCode!] : null,
            ReferencedPolicyId = draft.Kind == ConditionKind.Reference ? v.Policies[draft.PolicyCode!] : null,
            Parameters = draft.Kind == ConditionKind.Predicate
                ? draft.Parameters.Select(kv => new ConditionParameter { Key = kv.Key, Value = kv.Value }).ToList()
                : new List<ConditionParameter>()
        };
        db.RuleConditions.Add(node);
        for (var i = 0; i < draft.Children.Count; i++) AddConditionTree(rule, node, draft.Children[i], i, v);
    }

    internal void RemoveNodes(List<RuleCondition> nodes)
    {
        foreach (var n in nodes)
        {
            foreach (var p in n.Parameters.ToList()) db.ConditionParameters.Remove(p);
            db.RuleConditions.Remove(n);
        }
    }

    private static string? NormalizeReason(string? reason) => string.IsNullOrWhiteSpace(reason) ? null : Codes.Normalize(reason);

    private static RuleDraft Draft(int policyId, string code, RuleUpsert dto, ConditionDraft condition) => new()
    {
        PolicyId = policyId, Code = code, Name = dto.Name, Order = dto.Order,
        ReasonCode = NormalizeReason(dto.ReasonCode), IsActive = dto.IsActive, Condition = condition
    };
}
