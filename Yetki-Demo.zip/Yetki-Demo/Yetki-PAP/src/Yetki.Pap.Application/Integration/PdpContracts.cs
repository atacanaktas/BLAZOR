using System.Text.Json;
using Yetki.Pap.Domain.Common;

namespace Yetki.Pap.Application.Integration;

// ============================================================================================
//  PDP analiz sözleşmesi (JSON). Ortak kütüphane YOK: PAP, PDP'nin JSON'unu kendi tipleriyle karşılar.
//  Alan adları PDP'deki karşılıklarıyla aynıdır (camelCase JSON); PDP değişirse burası da güncellenir.
// ============================================================================================

// ------------------------------ Kimlik değişiklik seti (rol ataması, grup...) ------------------------------

public sealed record UserRoleChange(int UserId, int RoleId, bool Add, DateTime? ValidUntil = null);
public sealed record UserUnitChange(int UserId, int OrgUnitId, bool Add);
public sealed record GroupMemberChange(int GroupId, int UserId, bool Add, DateTime? ValidUntil = null);
public sealed record GroupRoleChange(int GroupId, int RoleId, bool Add);
public sealed record ActivationChange(int Id, bool IsActive);
public sealed record UserUpdate(int UserId, string? Title = null, bool? IsActive = null, bool? IsOnLeave = null, decimal? CashWithdrawalLimit = null);
public sealed record RoleUpdate(int RoleId, bool? IsActive = null, bool? IsInheritable = null);

public sealed class GroupCriterionDraft
{
    public string Attribute { get; set; } = default!;
    public List<string> Values { get; set; } = new();
}

public sealed class GroupFilterDraft
{
    public InclusionMode Mode { get; set; } = InclusionMode.Include;
    public string? Description { get; set; }
    public List<GroupCriterionDraft> Criteria { get; set; } = new();
}

public sealed record GroupFiltersReplacement(int GroupId, List<GroupFilterDraft> Filters);

public sealed class AuthorizationChangeSet
{
    public List<UserRoleChange> UserRoles { get; set; } = new();
    public List<UserUnitChange> UserUnits { get; set; } = new();
    public List<GroupMemberChange> GroupMembers { get; set; } = new();
    public List<GroupRoleChange> GroupRoles { get; set; } = new();
    public List<GroupFiltersReplacement> GroupFilters { get; set; } = new();
    public List<ActivationChange> GroupActivations { get; set; } = new();
    public List<RoleUpdate> RoleUpdates { get; set; } = new();
    public List<UserUpdate> UserUpdates { get; set; } = new();
}

/// <summary>Condition ifade ağacı taslağı: Predicate / AllOf / AnyOf / Not / Reference (PolicyCode: koşul olarak kullanılan policy).</summary>
public sealed class ConditionDraft
{
    public ConditionKind Kind { get; set; } = ConditionKind.Predicate;
    public string? ConditionTypeCode { get; set; }
    public string? PolicyCode { get; set; }
    public Dictionary<string, string> Parameters { get; set; } = new();
    public List<ConditionDraft> Children { get; set; } = new();
}

// ------------------------------ ModelPatch: kaydedilmemiş tanım değişikliği ------------------------------

public enum PatchOp { Add, Replace, Remove }

/// <summary>PDP ModelData tablosunda satır işlemi. Yeni kayıtlar negatif geçici id ile.</summary>
public sealed record ModelPatchOperation(string Table, PatchOp Op, IReadOnlyDictionary<string, object?>? Match = null, object? Row = null);

public static class ModelPatch
{
    public static ModelPatchOperation Add(string table, object row) => new(table, PatchOp.Add, null, row);
    public static ModelPatchOperation Remove(string table, object match) => new(table, PatchOp.Remove, ToMatch(match));
    public static ModelPatchOperation Replace(string table, object match, object row) => new(table, PatchOp.Replace, ToMatch(match), row);

    private static IReadOnlyDictionary<string, object?> ToMatch(object match) =>
        match.GetType().GetProperties().ToDictionary(p => p.Name, p => p.GetValue(match));
}

// PDP model satırları (ModelData). Sadece patch üretmek için.
public sealed record AppRow(int Id, int TenantId, string Code, string Name, ApplicationType Type, DecisionStrategy Strategy, bool IsActive);
public sealed record ResourceTypeRow(int Id, string Code, string Name, bool MatchesHttp, bool SupportsHierarchy, string? Color, bool IsActive);
public sealed record ResourceRow(int Id, int ApplicationId, int ResourceTypeId, int? ParentId, string Code, string Name, string? ExternalCode, int Order, bool IsActive);
public sealed record ResourceScopeRow(int Id, int ResourceId, int ScopeId, Severity RiskLevel);
public sealed record UriRow(int Id, int ResourceId, string Method, string Pattern, int ScopeId);
public sealed record PolicyRow(int Id, int TenantId, string Code, string Name, PolicyLogic Logic, DecisionStrategy Strategy, PolicyMode Mode, bool IsActive, int Version);
public sealed record GroupRow(int Id, int TenantId, string Code, string Name, bool IsActive);
public sealed record PermissionRow(int Id, int ApplicationId, string Code, string Name, PermissionTarget Target, int? ResourceTypeId, bool AllScopes,
    DecisionStrategy Strategy, bool IsActive, int Version);
public sealed record PermissionResourceRow(int PermissionId, int ResourceId);
public sealed record PermissionScopeRow(int PermissionId, int ScopeId);
public sealed record PermissionPolicyRow(int PermissionId, int PolicyId, int Order);

/// <summary>Etki analizi isteği: kimlik değişiklikleri, tanım satırı işlemleri ve/veya kural değişiklikleri.</summary>
public sealed class ImpactRequest
{
    public AuthorizationChangeSet? Changes { get; set; }
    public List<ModelPatchOperation>? Patch { get; set; }
    public PolicyChangeSet? PolicyChanges { get; set; }
}

/// <summary>Kaydedilmemiş kural değişiklikleri (PDP PolicyChangeSet'in PAP'ın kullandığı kısmı).</summary>
public sealed class PolicyChangeSet
{
    public List<RuleDraft> AddedRules { get; set; } = new();
    public List<int> RemovedRuleIds { get; set; } = new();
    public List<RuleReplacement> ReplacedRules { get; set; } = new();
}

public sealed record RuleReplacement(int RuleId, RuleDraft Rule);

public sealed class RuleDraft
{
    public int PolicyId { get; set; }
    public string Code { get; set; } = default!;
    public string? Name { get; set; }
    public int Order { get; set; }
    public string? ReasonCode { get; set; }
    public bool IsActive { get; set; } = true;
    public ConditionDraft Condition { get; set; } = new();
}

// ------------------------------ Kitle (KİM kartı = grup kuralı) ------------------------------

public sealed class AudienceOverlapRequest
{
    public int? PolicyId { get; set; }
    public int? RuleId { get; set; }
    public int? TenantId { get; set; }
    public List<GroupFilterDraft> Filters { get; set; } = new();
}

public sealed record AudienceRuleRef(int PolicyId, string Policy, string PolicyName, int RuleId, string Rule, string RuleName, int MemberCount);
public sealed record AudienceGroupRef(int GroupId, string Code, string Name, int MemberCount, bool SameMembers, bool HasExplicitMembers, IReadOnlyList<string> Roles);

/// <summary>Tanım aynı → öneri (SameDefinition*); sadece bugünkü üyeler aynı → bilgi (SameMembers*).</summary>
public sealed record AudienceOverlapResult(
    string Key, string Expression, bool CanBecomeGroup, IReadOnlyList<string> Members,
    IReadOnlyList<AudienceRuleRef> SameDefinition, IReadOnlyList<AudienceGroupRef> SameDefinitionGroups,
    IReadOnlyList<AudienceRuleRef> SameMembersRules, IReadOnlyList<AudienceGroupRef> SameMembersGroups);

public sealed record AudienceCondition(ConditionDraft Condition, string Expression);

// ------------------------------ Etki sonucu ------------------------------

public sealed record AccessDelta(int ResourceScopeId, string Key, string Name, string Path, bool Conditional, IReadOnlyList<string> Sources);
public sealed record AccessSourceChange(int ResourceScopeId, string Key, string Name, IReadOnlyList<string> Before, IReadOnlyList<string> After);
public sealed record SodMatchedMember(SodMemberType Type, int Id, string Code, string Name, IReadOnlyList<string> Paths);

public sealed record SodConflict(int SodRuleId, string Code, string Name, Severity Severity, SodEnforcement Enforcement, IReadOnlyList<SodMatchedMember> MatchedMembers)
{
    public string Describe() => $"{Code}: " + string.Join(" + ", MatchedMembers.Select(m => $"{m.Code} [{string.Join(" | ", m.Paths)}]"));
}

public sealed record ExternalChange(string System, string Code, string? ResourceClass, string? Level, string? PreviousLevel, IReadOnlyList<string> Reasons);

public sealed record UserImpact(
    int UserId, string UserName, string FullName, string Tenant,
    IReadOnlyList<AccessDelta> AddedAccesses, IReadOnlyList<AccessDelta> RemovedAccesses, IReadOnlyList<AccessSourceChange> RetainedAccesses,
    IReadOnlyList<string> AddedRoles, IReadOnlyList<string> RemovedRoles, IReadOnlyList<string> AddedGroups, IReadOnlyList<string> RemovedGroups,
    IReadOnlyList<SodConflict> NewSodConflicts, IReadOnlyList<ExternalChange> ExternalGrants, IReadOnlyList<ExternalChange> ExternalRevokes)
{
    public bool AccessesChanged => AddedAccesses.Count + RemovedAccesses.Count > 0;
    public bool HasChanges => AccessesChanged || RetainedAccesses.Count + AddedRoles.Count + RemovedRoles.Count + AddedGroups.Count + RemovedGroups.Count > 0;
}

public sealed record SodFinding(int UserId, string UserName, SodConflict Conflict);

/// <summary>Etki analizi (PDP hesaplar). DryRun / Applied PAP'ın uygulama durumudur.</summary>
public sealed class ChangeImpactResult
{
    public bool DryRun { get; set; }
    public bool Applied { get; set; }
    public bool Blocked { get; set; }
    public string Summary { get; set; } = "";
    public int AffectedUserCount { get; set; }
    public int EvaluatedUserCount { get; set; }
    public long ModelVersion { get; set; }
    public IReadOnlyList<UserImpact> Users { get; set; } = [];
    public IReadOnlyList<SodFinding> BlockingConflicts { get; set; } = [];
    public IReadOnlyList<SodFinding> Warnings { get; set; } = [];

    public static ChangeImpactResult Unchanged(string summary) => new() { Applied = true, Summary = summary };
}

// ------------------------------ Doğrulama ------------------------------

/// <summary>PDP'nin doğruladığı (normalize edilmiş) condition taslağı + okunur ifade + tip / referans policy id'leri.</summary>
public sealed record ConditionValidation(ConditionDraft Condition, string Expression, Dictionary<string, int> ConditionTypes, Dictionary<string, int> Policies);

public sealed record ObligationValidation(string Code, Dictionary<string, string> Parameters);

public sealed record PermissionDraftInfo(bool HasIdentityPolicy, int CoverageCount, IReadOnlyList<string> Coverage);

// ------------------------------ SoD ------------------------------

public sealed record SodUserConflicts(int UserId, string UserName, string FullName, IReadOnlyList<SodConflict> Conflicts);

public sealed record SodDetectionResult(int ScannedUsers, int ViolatingUsers, double DurationMs, long ModelVersion, IReadOnlyList<SodUserConflicts> Details);

public sealed class SodRulePreviewRequest
{
    public string Code { get; set; } = "DRAFT";
    public SodEnforcement Enforcement { get; set; } = SodEnforcement.Block;
    public List<int> ResourceScopeIds { get; set; } = new();
    public List<int> RoleIds { get; set; } = new();
}

// ------------------------------ Dış sistemler (RACF / LDAP) ------------------------------

public sealed record ExternalDependencyRow(int Id, int? ResourceId, int? ResourceScopeId, int ExternalPermissionId, ExternalAccessLevel? AccessLevel, string? Note);
public sealed record ExternalRequirementRow(int ExternalPermissionId, int RequiredExternalPermissionId, ExternalAccessLevel? AccessLevel);
public sealed record ExternalRequirementKey(int ExternalPermissionId, int RequiredExternalPermissionId);

public sealed class ExternalCatalogPatch
{
    public ExternalDependencyRow? AddDependency { get; set; }
    public int? RemoveDependencyId { get; set; }
    public ExternalRequirementRow? AddRequirement { get; set; }
    public ExternalRequirementKey? RemoveRequirement { get; set; }
    public string? Summary { get; set; }
}

public sealed record ExternalUserImpact(int UserId, string UserName, IReadOnlyList<ExternalChange> Grants, IReadOnlyList<ExternalChange> Modifies, IReadOnlyList<ExternalChange> Revokes);

public sealed record ExternalImpactResult(bool DryRun, string Summary, int AffectedUserCount, IReadOnlyList<ExternalUserImpact> Users);

public sealed record ExternalTarget(int ExternalPermissionId, string System, string Code, string? Name, string? ResourceClass, bool HasAccessLevels);

public sealed record ExternalDiffItem(ExternalTarget Target, ExternalAccessLevel? DesiredLevel, ExternalAccessLevel? CurrentLevel, string Action, IReadOnlyList<string> Reasons);

public sealed record UserExternalStatus(int UserId, string UserName, bool IsActive, bool InSync, IReadOnlyList<ExternalDiffItem> Items);

public sealed record ExternalNeed(ExternalTarget Target, ExternalAccessLevel? Level, IReadOnlyList<string> Reasons);

public sealed record UserExternalDesired(int UserId, string UserName, bool IsActive, IReadOnlyList<ExternalNeed> Needs);

public sealed record DriftUser(int UserId, string UserName, int Grants, int Modifies, int Revokes);

public sealed record DriftReport(int CheckedUsers, int DriftedUsers, IReadOnlyList<DriftUser> Users);

// ------------------------------ Ham iletim (görünümler, konsol kararı) ------------------------------

/// <summary>PDP cevabı olduğu gibi (görünümler PAP'ta yeniden şekillendirilmez).</summary>
public sealed record PdpResponse(int StatusCode, string ContentType, string Body);

public interface IPdpClient
{
    Task<ChangeImpactResult> ImpactAsync(ImpactRequest request, CancellationToken ct);
    /// <param name="policyId">Kuralın ait olduğu policy (referans kurum + döngü kontrolü).</param>
    Task<ConditionValidation> ValidateConditionAsync(ConditionDraft draft, int policyId, CancellationToken ct);
    Task<ObligationValidation> ValidateObligationAsync(string code, Dictionary<string, string> parameters, CancellationToken ct);
    Task<string> ValidateGroupFiltersAsync(List<GroupFilterDraft> filters, CancellationToken ct);
    Task<PermissionDraftInfo> PermissionDraftAsync(object draft, CancellationToken ct);
    Task<IReadOnlyList<SodUserConflicts>> SodRulePreviewAsync(SodRulePreviewRequest request, CancellationToken ct);
    Task<SodDetectionResult> SodDetectAsync(CancellationToken ct);
    Task<ExternalImpactResult> ExternalImpactAsync(ExternalCatalogPatch patch, CancellationToken ct);
    Task<UserExternalStatus> ExternalUserAsync(int userId, CancellationToken ct);
    Task<DriftReport> ExternalDriftAsync(CancellationToken ct);
    Task<IReadOnlyList<UserExternalDesired>> ExternalDesiredAsync(IReadOnlyCollection<int>? userIds, CancellationToken ct);
    Task<AudienceOverlapResult> AudienceOverlapAsync(AudienceOverlapRequest request, CancellationToken ct);
    /// <summary>Kitle satırları → KİM kartı koşul ağacı.</summary>
    Task<AudienceCondition> AudienceConditionAsync(List<GroupFilterDraft> filters, CancellationToken ct);
    /// <summary>Kuralın koşulu bir kitleyse satırları; değilse null.</summary>
    Task<List<GroupFilterDraft>?> RuleAudienceAsync(int ruleId, CancellationToken ct);
    Task<JsonElement> SummaryAsync(CancellationToken ct);
    /// <summary>Ham iletim: yol PDP köküne göre (ör. "api/analysis/views/users?q=a").</summary>
    Task<PdpResponse> ForwardAsync(HttpMethod method, string pathAndQuery, string? jsonBody, CancellationToken ct);
}
