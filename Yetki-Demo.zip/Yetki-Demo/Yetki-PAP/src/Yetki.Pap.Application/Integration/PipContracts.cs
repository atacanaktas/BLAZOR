using Yetki.Pap.Domain.Common;

namespace Yetki.Pap.Application.Integration;

// ============================================================================================
//  PIP (kimlik bilgi noktası) sözleşmesi. Kimlik verisinin (kullanıcı, rol, rol ataması, birim) sahibi PIP'tir.
//  PAP konsolu kimlik değişikliği yaptığında önce PDP'ye etkisini sorar (SoD, kim ne kazanır), sonra PIP'e yazar.
// ============================================================================================

public sealed record IdentityUser(int Id, int TenantId, string UserName, string FullName, string? Email,
    string? Title, string? EmployeeNo, UserKind Kind, bool IsActive, bool IsOnLeave, decimal CashWithdrawalLimit, string? CustomerNo);
public sealed record IdentityRole(int Id, int TenantId, string Code, string Name, string? Description, bool IsInheritable, bool IsActive);
public sealed record IdentityUserRole(int UserId, int RoleId, DateTime? ValidFrom, DateTime? ValidUntil, string? Reason, DateTime AssignedAt, string AssignedBy);
public sealed record IdentityUnit(int Id, int TenantId, int? ParentId, string Code, string Name, OrgUnitType Type, bool IsActive);
public sealed record IdentityUserUnit(int UserId, int OrgUnitId, bool IsPrimary);

public sealed class PipUserUpsert
{
    public int TenantId { get; set; }
    public string UserName { get; set; } = default!;
    public string FullName { get; set; } = default!;
    public string? Email { get; set; }
    public string? Title { get; set; }
    public string? EmployeeNo { get; set; }
    public UserKind Kind { get; set; } = UserKind.Person;
    public bool IsActive { get; set; } = true;
    public bool IsOnLeave { get; set; }
    public decimal CashWithdrawalLimit { get; set; }
    public string? CustomerNo { get; set; }
    public int? PrimaryOrgUnitId { get; set; }
}

public sealed class PipRoleUpsert
{
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsInheritable { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class PipUnitUpsert
{
    public int TenantId { get; set; }
    public int? ParentId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public OrgUnitType Type { get; set; } = OrgUnitType.Branch;
    public bool IsActive { get; set; } = true;
}

/// <summary>
/// Kimlik dizini (PIP istemcisi). Yazma çağrıları PIP'te HEMEN kalıcı olur (PAP'ın veritabanı işiyle aynı transaction değildir):
/// PAP önce PDP'ye etkiyi sorar, sonra PIP'e yazar, en son kendi audit / olay kaydını yazar.
/// </summary>
public interface IIdentityDirectory
{
    Task<IdentityUser?> GetUserAsync(int id, CancellationToken ct);
    Task<IdentityRole?> GetRoleAsync(int id, CancellationToken ct);
    Task<IReadOnlyList<IdentityRole>> GetRolesAsync(CancellationToken ct);
    Task<IReadOnlyList<IdentityUserRole>> GetUserRolesAsync(int userId, CancellationToken ct);
    Task<IReadOnlyList<IdentityUserUnit>> GetUserUnitsAsync(int userId, CancellationToken ct);
    Task<IReadOnlyList<IdentityUnit>> GetUnitsAsync(int? tenantId, CancellationToken ct);

    Task<IdentityUser> CreateUserAsync(PipUserUpsert user, CancellationToken ct);
    Task<IdentityUser> UpdateUserAsync(int id, PipUserUpsert user, CancellationToken ct);
    Task<IdentityRole> CreateRoleAsync(PipRoleUpsert role, CancellationToken ct);
    Task<IdentityRole> UpdateRoleAsync(int id, PipRoleUpsert role, CancellationToken ct);
    Task AssignRoleAsync(int userId, int roleId, DateTime? validUntil, string? reason, CancellationToken ct);
    Task RevokeRoleAsync(int userId, int roleId, CancellationToken ct);
    Task AddUserUnitAsync(int userId, int unitId, CancellationToken ct);
    Task RemoveUserUnitAsync(int userId, int unitId, CancellationToken ct);
    Task<IdentityUnit> CreateUnitAsync(PipUnitUpsert unit, CancellationToken ct);
}
