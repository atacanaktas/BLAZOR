using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Tenants;

namespace Yetki.Pap.Domain.Identity;

/// <summary>
/// Kimlik (subject). Personel veya servis hesabı (client credentials ile çalışan batch/servis).
/// Limit, izin durumu gibi alanlar PROTOTİPTE burada; üretimde HR / limit servisi gibi kaynaklardan
/// IAttributeValueProvider ile çözülür (policy motoru değerin nereden geldiğini bilmez).
/// </summary>
public class User : AuditableEntity
{
    public int TenantId { get; set; }
    public Tenant Tenant { get; set; } = default!;
    public string UserName { get; set; } = default!;
    public string FullName { get; set; } = default!;
    public string? Email { get; set; }
    public string? Title { get; set; }
    public string? EmployeeNo { get; set; }
    public UserKind Kind { get; set; } = UserKind.Person;
    public bool IsActive { get; set; } = true;
    public bool IsOnLeave { get; set; }
    public decimal CashWithdrawalLimit { get; set; }
    /// <summary>Personelin bankadaki kendi müşteri numarası (kendi hesabında işlem kontrolü).</summary>
    public string? CustomerNo { get; set; }

    public ICollection<UserOrgUnit> OrgUnits { get; set; } = new List<UserOrgUnit>();
}

public class UserOrgUnit : IAssignment
{
    public int UserId { get; set; }
    public User User { get; set; } = default!;
    public int OrgUnitId { get; set; }
    public OrgUnit OrgUnit { get; set; } = default!;
    public bool IsPrimary { get; set; }
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}
