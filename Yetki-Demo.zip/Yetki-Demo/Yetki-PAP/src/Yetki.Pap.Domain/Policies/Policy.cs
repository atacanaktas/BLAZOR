using Yetki.Pap.Domain.Catalog;
using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Tenants;

namespace Yetki.Pap.Domain.Policies;

// ============================================================================================
//  Keycloak Authorization Services modeli + gömülü ABAC
//
//  Policy       KİM / HANGİ KOŞULDA? Resource'tan bağımsız, tekrar kullanılabilir. TİPİ YOKTUR: tek tür.
//     Rule'lar (yönetim ekranında soru kartları: KİM, NEREDEN, NEREYE/KİME, NE KADAR, HANGİ SAAT, NE ZAMAN, HAZIR POLICY)
//     = koşul ağaçları; karar stratejisiyle birleşir. Kimlik KİM kartında, kanal NEREDEN kartında, başka bir policy
//     referansla (HAZIR POLICY) kullanılır. Logic Negative → sonuç tersine çevrilir.
//
//  Permission   HANGİ resource/scope'u HANGİ policy'lerle koruyorum?
//     Resources (boşsa ResourceType'taki / uygulamadaki tümü) × Scopes (boşsa tümü) ← Policies + karar stratejisi
//
//  Karar: istek → resource + scope → uygulanan permission'lar → her biri policy'lerini stratejisiyle birleştirir →
//         uygulamanın stratejisiyle (varsayılan Unanimous) nihai karar. Uygulanan permission yoksa DENY.
//  DB'de ASLA çalıştırılabilir kod/SQL/script tutulmaz; koşul davranışı C# handler'dadır.
// ============================================================================================

public class Policy : AuditableEntity
{
    /// <summary>Policy bir tenant'a aittir; o tenant ve ALT tenant'larında kullanılabilir.</summary>
    public int TenantId { get; set; }
    public Tenant Tenant { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public PolicyLogic Logic { get; set; } = PolicyLogic.Positive;
    /// <summary>Kuralların (kartların) birleştirilmesi.</summary>
    public DecisionStrategy DecisionStrategy { get; set; } = DecisionStrategy.Unanimous;
    public PolicyMode Mode { get; set; } = PolicyMode.Enforce;
    public bool IsActive { get; set; } = true;
    /// <summary>Policy veya kurallarında her değişiklikte artar; kararlar versiyonla audit'lenir.</summary>
    public int Version { get; set; } = 1;

    public ICollection<Rule> Rules { get; set; } = new List<Rule>();
    /// <summary>Karar ile PEP'e dönen yükümlülükler (ör. web kanalında TCKN maskele).</summary>
    public ICollection<PolicyObligation> Obligations { get; set; } = new List<PolicyObligation>();
}

/// <summary>
/// Keycloak permission: resource/scope'ları policy'lere bağlar.
/// Kapsam AÇIKÇA seçilir (Target); boş liste hiçbir zaman "tümü" anlamına gelmez:
///  - Resources: sadece listedeki resource'lar (liste boşsa / silinmişse permission atıldır, hiçbir şeyi etkilemez)
///  - ResourceType: ResourceTypeId tipindeki tüm resource'lar (sonradan eklenenler dahil)
///  - Application: uygulamadaki tüm resource'lar (sadece bilinçli seçimle)
/// Scope'lar: AllScopes = true ise kapsamdaki resource'ların tüm scope'ları; değilse sadece listedekiler (boşsa atıl).
/// </summary>
public class Permission : AuditableEntity
{
    public int ApplicationId { get; set; }
    public CatalogApplication Application { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public PermissionTarget Target { get; set; } = PermissionTarget.Resources;
    public bool AllScopes { get; set; }
    /// <summary>Sadece Target = ResourceType için.</summary>
    public int? ResourceTypeId { get; set; }
    public ResourceType? ResourceType { get; set; }
    public DecisionStrategy DecisionStrategy { get; set; } = DecisionStrategy.Unanimous;
    public bool IsActive { get; set; } = true;
    public int Version { get; set; } = 1;

    public ICollection<PermissionResource> Resources { get; set; } = new List<PermissionResource>();
    public ICollection<PermissionScope> Scopes { get; set; } = new List<PermissionScope>();
    public ICollection<PermissionPolicy> Policies { get; set; } = new List<PermissionPolicy>();
}

public class PermissionResource
{
    public int PermissionId { get; set; }
    public Permission Permission { get; set; } = default!;
    public int ResourceId { get; set; }
    public Resource Resource { get; set; } = default!;
}

public class PermissionScope
{
    public int PermissionId { get; set; }
    public Permission Permission { get; set; } = default!;
    public int ScopeId { get; set; }
    public Scope Scope { get; set; } = default!;
}

public class PermissionPolicy
{
    public int PermissionId { get; set; }
    public Permission Permission { get; set; } = default!;
    public int PolicyId { get; set; }
    public Policy Policy { get; set; } = default!;
    public int Order { get; set; }
}

/// <summary>
/// Yükümlülük (XACML obligation): karar verildiğinde PEP'in (gateway / servis) YERİNE GETİRMESİ gereken iş.
/// Tip kodu koddaki katalogdan (MASK_FIELDS, LIMIT_RESULTS, LOG_ACCESS); PEP tanımadığı yükümlülükte erişimi REDDEDER.
/// </summary>
public class PolicyObligation : Entity
{
    public int PolicyId { get; set; }
    public Policy Policy { get; set; } = default!;
    public string Code { get; set; } = default!;
    public ObligationFulfillOn FulfillOn { get; set; } = ObligationFulfillOn.Permit;
    public int Order { get; set; }
    public ICollection<PolicyObligationParameter> Parameters { get; set; } = new List<PolicyObligationParameter>();
}

public class PolicyObligationParameter : Entity
{
    public int ObligationId { get; set; }
    public PolicyObligation Obligation { get; set; } = default!;
    public string Key { get; set; } = default!;
    public string Value { get; set; } = default!;
}

/// <summary>
/// Condition policy içindeki tek koşul (gereksinim). Condition TRUE → sağlandı; FALSE → sağlanmadı (ReasonCode ile Deny);
/// belirsiz (eksik değer, hata) → Indeterminate (fail-closed).
/// </summary>
public class Rule : AuditableEntity
{
    public int PolicyId { get; set; }
    public Policy Policy { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public int Order { get; set; }
    /// <summary>Rule sağlanmadığında döndürülecek makine-okunur neden (ör. AMOUNT_EXCEEDS_USER_LIMIT).</summary>
    public string? ReasonCode { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<RuleCondition> Conditions { get; set; } = new List<RuleCondition>();
}

/// <summary>
/// Condition ifade ağacı düğümü (self-reference, ilişkisel; JSON blob yok).
/// Düğüm bir Rule'a aittir. Reference düğümü başka bir POLICY'yi koşul olarak kullanır (ReferencedPolicyId; kopya değil):
/// tekrar kullanılan parça (banka ağı, mesai) ayrı bir policy olarak yazılır ve kurallardan referansla çağrılır.
/// </summary>
public class RuleCondition : Entity
{
    public int RuleId { get; set; }
    public Rule Rule { get; set; } = default!;
    public int? ParentId { get; set; }
    public RuleCondition? Parent { get; set; }
    public ConditionKind Kind { get; set; } = ConditionKind.Predicate;
    public int? ConditionTypeId { get; set; }
    public ConditionType? ConditionType { get; set; }
    public int? ReferencedPolicyId { get; set; }
    public Policy? ReferencedPolicy { get; set; }
    public int Order { get; set; }

    public ICollection<RuleCondition> Children { get; set; } = new List<RuleCondition>();
    public ICollection<ConditionParameter> Parameters { get; set; } = new List<ConditionParameter>();
}

/// <summary>Predicate parametresi. Kullanıcıya özgü değer (ör. limit) BURADA TUTULMAZ; attribute olarak çözülür.</summary>
public class ConditionParameter : Entity
{
    public int ConditionId { get; set; }
    public RuleCondition Condition { get; set; } = default!;
    public string Key { get; set; } = default!;
    public string Value { get; set; } = default!;
}

/// <summary>Condition tipleri kataloğu; koddaki IConditionHandler'lardan açılışta senkronize edilir.</summary>
public class ConditionType : Entity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ConditionScope DefaultScope { get; set; }
    /// <summary>Parametre tanımları (JSON; sadece dokümantasyon/UI form üretimi).</summary>
    public string ParameterSchemaJson { get; set; } = "[]";
    public string? RequiredAttributes { get; set; }
    /// <summary>Koddaki handler'ı kalmayan tip false olur; bu tipteki condition'lar Indeterminate (fail-closed).</summary>
    public bool IsAvailable { get; set; } = true;
    /// <summary>Sadece kullanıcı attribute'larına bakar (istek bağlamı gerektirmez) → önceden hesaplanabilir.</summary>
    public bool IsSubjectOnly { get; set; }
    /// <summary>Policy ekranında hangi soru kartında yer alır (KİM, NEREDEN...). Boş: genel. PDP senkronize eder.</summary>
    public ConditionQuestion? Question { get; set; }
    /// <summary>Kimlik koşulu (rol, grup, birim, kullanıcı): istek olmadan kesin çözülür (kimde var, SoD, RACF).</summary>
    public bool IsIdentity { get; set; }
}
