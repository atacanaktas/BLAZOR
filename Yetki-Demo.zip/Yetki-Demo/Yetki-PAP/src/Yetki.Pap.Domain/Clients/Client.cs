using Yetki.Pap.Domain.Catalog;
using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Identity;

namespace Yetki.Pap.Domain.Clients;

/// <summary>
/// Client: motoru TÜKETEN uygulama (Nextral-Api, gateway, batch...). Kanal kısıtları Client policy'si ile permission'lara eklenir.
///
/// Motoru çağırırken client kendini kendi secret'ıyla doğrular (POST /api/v1/token → kısa ömürlü token). Soru soranın kimliği
/// bu token'dan çıkar; istekteki kullanıcı / yetki / bağlam bilgisinin doğruluğu client'ın sorumluluğundadır. Motor kendini
/// SORU KAPSAMI ile korur: client sadece izin verilen uygulamalar ve kurumlar hakkında soru sorabilir; sadece aracılar başka
/// client'lar adına konuşabilir; istek limiti vardır. Böylece hatalı / ele geçirilmiş bir client sadece kendi kapsamını etkiler.
/// </summary>
public class Client : AuditableEntity
{
    /// <summary>Client'ı kaydeden tenant. Client bu tenant ve alt tenant'larının isteklerinde kullanılabilir.</summary>
    public int TenantId { get; set; }
    public Tenants.Tenant Tenant { get; set; } = default!;
    /// <summary>Kimlik sağlayıcıdaki client_id (ör. nextral-api).</summary>
    public string ClientId { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ClientType Type { get; set; }
    /// <summary>Client'ın ait olduğu uygulama (bilgi/sahiplik).</summary>
    public int? ApplicationId { get; set; }
    public CatalogApplication? Application { get; set; }
    /// <summary>Service tipi client'lar (client credentials) bu servis hesabının kimliğiyle yetkilendirilir.</summary>
    public int? ServiceAccountUserId { get; set; }
    public User? ServiceAccountUser { get; set; }
    public bool IsActive { get; set; } = true;
    /// <summary>Dakikadaki en fazla karar isteği (boşsa motor varsayılanı). Bir tüketici motoru tıkayıp diğerlerini etkilemesin.</summary>
    public int? RateLimitPerMinute { get; set; }

    /// <summary>Soru kapsamı: client'ın hakkında soru sorabileceği uygulamalar. Boşsa hiçbiri.</summary>
    public ICollection<ClientQueryApplication> QueryApplications { get; set; } = new List<ClientQueryApplication>();
    /// <summary>Soru kapsamı: client'ın kullanıcıları için soru sorabileceği kurumlar (alt kurumlar dahil). Boşsa hiçbiri.</summary>
    public ICollection<ClientQueryTenant> QueryTenants { get; set; } = new List<ClientQueryTenant>();
    /// <summary>Sadece aracılar: adına soru sorabileceği (isteği başlatan) client'lar.</summary>
    public ICollection<ClientDelegation> Delegations { get; set; } = new List<ClientDelegation>();
    public ICollection<ClientSecret> Secrets { get; set; } = new List<ClientSecret>();
}

public class ClientQueryApplication
{
    public int ClientId { get; set; }
    public Client Client { get; set; } = default!;
    public int ApplicationId { get; set; }
    public CatalogApplication Application { get; set; } = default!;
}

public class ClientQueryTenant
{
    public int ClientId { get; set; }
    public Client Client { get; set; } = default!;
    public int TenantId { get; set; }
    public Tenants.Tenant Tenant { get; set; } = default!;
}

/// <summary>Aracı (ClientId) şu client adına konuşabilir (OnBehalfOfClientId): "bu istek nextral-api'den geldi" diyebilir.</summary>
public class ClientDelegation
{
    public int ClientId { get; set; }
    public Client Client { get; set; } = default!;
    public int OnBehalfOfClientId { get; set; }
    public Client OnBehalfOf { get; set; } = default!;
}

/// <summary>
/// Client'ın motora kimlik doğrulaması için secret. Düz metin sadece oluşturulurken bir kez gösterilir; burada SHA-256 özeti tutulur.
/// Kesintisiz değişim için aynı anda birden fazla geçerli secret olabilir; süresi dolan / iptal edilen kullanılamaz.
/// </summary>
public class ClientSecret : Entity
{
    public int ClientId { get; set; }
    public Client Client { get; set; } = default!;
    public string SecretHash { get; set; } = default!;
    /// <summary>Tanıma için ilk karakterler (ör. ysk_a1b2c3…).</summary>
    public string Prefix { get; set; } = default!;
    public string? Description { get; set; }
    public DateTime CreatedAt { get; set; }
    public string CreatedBy { get; set; } = default!;
    public DateTime? ExpiresAt { get; set; }
    public DateTime? RevokedAt { get; set; }
    public DateTime? LastUsedAt { get; set; }
}
