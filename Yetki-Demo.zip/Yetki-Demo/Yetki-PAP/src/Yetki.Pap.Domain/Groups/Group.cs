using Yetki.Pap.Domain.Common;
using Yetki.Pap.Domain.Tenants;
using Yetki.Pap.Domain.Identity;
using Yetki.Pap.Domain.Rbac;

namespace Yetki.Pap.Domain.Groups;

// ============================================================================================
//  Grup = KİŞİ KÜMESİ (Entra ID dynamic group / Okta group rules karşılığı)
//
//    Üyeler = (açık üyeler ∪ Include filtreleri) − Exclude filtreleri
//    Filtre içindeki kriterler VE, filtreler arası VEYA ile birleşir.
//    Kriter: Attribute (ROLE, ORG_UNIT, ORG_UNIT_TREE, TITLE...) ∈ Değerler   — davranış C# handler'dadır.
//
//  Grup üyelerine rol verebilir (GroupRole). Yetki ise Group policy'si (grubu üye alan) ve onu kullanan Permission ile verilir.
//  Üyelik statiktir (istek bağlamına bakmaz) → RACF/LDAP aktarımı, SoD, What-If ve yetki gözden geçirmede görünür.
//  Saat/IP/tutar gibi bağlam kontrolleri policy'nin işidir, grubun değil.
// ============================================================================================

public class Group : AuditableEntity
{
    public int TenantId { get; set; }
    public Tenant Tenant { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<GroupMember> Members { get; set; } = new List<GroupMember>();
    public ICollection<GroupFilter> Filters { get; set; } = new List<GroupFilter>();
    public ICollection<GroupRole> Roles { get; set; } = new List<GroupRole>();
}

/// <summary>Açık (elle eklenen) üye. Süreli olabilir.</summary>
public class GroupMember : IAssignment
{
    public int GroupId { get; set; }
    public Group Group { get; set; } = default!;
    public int UserId { get; set; }
    public User User { get; set; } = default!;
    public DateTime? ValidUntil { get; set; }
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}

/// <summary>Kitle kuralı. Include: eşleşenleri ekler. Exclude: eşleşenleri (açık üyeler dahil) çıkarır.</summary>
public class GroupFilter : Entity
{
    public int GroupId { get; set; }
    public Group Group { get; set; } = default!;
    public InclusionMode Mode { get; set; } = InclusionMode.Include;
    public int Order { get; set; }
    public string? Description { get; set; }

    public ICollection<GroupFilterCriterion> Criteria { get; set; } = new List<GroupFilterCriterion>();
}

/// <summary>Filtre kriteri: kullanıcının Attribute değeri Values listesinde mi? (Aynı filtredeki kriterler VE)</summary>
public class GroupFilterCriterion : Entity
{
    public int GroupFilterId { get; set; }
    public GroupFilter GroupFilter { get; set; } = default!;
    /// <summary>Kriter tipi kodu (IGroupCriterionHandler): ROLE, ORG_UNIT, ORG_UNIT_TREE, ORG_UNIT_TYPE, TITLE, TENANT, USER, USER_KIND.</summary>
    public string Attribute { get; set; } = default!;
    public int Order { get; set; }

    public ICollection<GroupFilterValue> Values { get; set; } = new List<GroupFilterValue>();
}

public class GroupFilterValue : Entity
{
    public int CriterionId { get; set; }
    public GroupFilterCriterion Criterion { get; set; } = default!;
    public string Value { get; set; } = default!;
}

/// <summary>Grubun üyelerine verdiği rol (Keycloak group role mapping).</summary>
public class GroupRole : IAssignment
{
    public int GroupId { get; set; }
    public Group Group { get; set; } = default!;
    public int RoleId { get; set; }
    public Role Role { get; set; } = default!;
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}
