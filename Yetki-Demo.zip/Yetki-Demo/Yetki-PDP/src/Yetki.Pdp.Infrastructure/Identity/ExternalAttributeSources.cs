using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Identity;

namespace Yetki.Pdp.Infrastructure.Identity;

/// <summary>
/// Kimlik dışı öznitelikler Yetki-PIP'ten. Kısa süreli önbellek: iş günü 10 dk (gün başına), izin ve müşteri 1 dk.
/// Hata yutulmaz; PDP tarafında koşul belirsiz (Indeterminate) olur.
/// </summary>
public sealed class PipExternalAttributeSource(HttpClient http, IMemoryCache cache) : IExternalAttributeSource
{
    public async Task<BusinessDayInfo> BusinessDayAsync(DateOnly date, CancellationToken ct) =>
        (await CachedAsync($"pip:bday:{date:yyyy-MM-dd}", TimeSpan.FromMinutes(10), $"api/calendar/business-days/{date:yyyy-MM-dd}", ct))
        .Deserialize<BusinessDayInfo>(PipIdentityProvider.Json)!;

    public async Task<LeaveInfo> LeaveAsync(int userId, DateOnly date, CancellationToken ct) =>
        (await CachedAsync($"pip:leave:{userId}:{date:yyyy-MM-dd}", TimeSpan.FromMinutes(1), $"api/identity/users/{userId}/leave?date={date:yyyy-MM-dd}", ct))
        .Deserialize<LeaveInfo>(PipIdentityProvider.Json)!;

    public async Task<CustomerInfo> CustomerAsync(string customerNo, CancellationToken ct) =>
        (await CachedAsync($"pip:customer:{customerNo}", TimeSpan.FromMinutes(1), $"api/customers/{Uri.EscapeDataString(customerNo)}", ct))
        .Deserialize<CustomerInfo>(PipIdentityProvider.Json)!;

    /// <summary>Kullanılan tutar işlem oldukça değişir: kısa önbellek (10 sn).</summary>
    public async Task<LimitInfo> CashLimitAsync(int userId, DateOnly date, CancellationToken ct) =>
        (await CachedAsync($"pip:limit:{userId}:{date:yyyy-MM-dd}", TimeSpan.FromSeconds(10), $"api/limits/users/{userId}?type=CASH&date={date:yyyy-MM-dd}", ct))
        .Deserialize<LimitInfo>(PipIdentityProvider.Json)!;

    private async Task<System.Text.Json.JsonElement> CachedAsync(string key, TimeSpan ttl, string path, CancellationToken ct)
    {
        if (cache.TryGetValue(key, out System.Text.Json.JsonElement hit)) return hit;
        using var res = await http.GetAsync(path, ct);
        if (!res.IsSuccessStatusCode)
            throw new InvalidOperationException($"PIP hatası {(int)res.StatusCode} ({path}): {await res.Content.ReadAsStringAsync(ct)}");
        var value = await res.Content.ReadFromJsonAsync<System.Text.Json.JsonElement>(PipIdentityProvider.Json, ct);
        cache.Set(key, value, ttl);
        return value;
    }
}

/// <summary>
/// Testler / tek süreç (Identity:Provider = LocalDb): PIP'in geçici kurallarının aynısı — hafta içi = iş günü, müşteri no öneki
/// (99 VIP, 98 personel). İzin, kullanıcı kaydındaki "izinde" alanından okunur (yerel veritabanı modu).
/// </summary>
public sealed class LocalExternalAttributeSource(IYetkiDbContext db) : IExternalAttributeSource
{
    public Task<BusinessDayInfo> BusinessDayAsync(DateOnly date, CancellationToken ct)
    {
        var weekday = date.DayOfWeek is not (DayOfWeek.Saturday or DayOfWeek.Sunday);
        return Task.FromResult(new BusinessDayInfo(date.ToString("yyyy-MM-dd"), weekday, weekday ? "hafta içi" : "hafta sonu", "local:hafta-ici"));
    }

    public async Task<LeaveInfo> LeaveAsync(int userId, DateOnly date, CancellationToken ct)
    {
        var onLeave = await db.Users.AsNoTracking().Where(u => u.Id == userId).Select(u => (bool?)u.IsOnLeave).FirstOrDefaultAsync(ct)
                      ?? throw new NotFoundException("Kullanıcı", userId);
        return new LeaveInfo(userId, date.ToString("yyyy-MM-dd"), onLeave, "kullanıcı kaydı", "local:kullanici-kaydi");
    }

    public Task<CustomerInfo> CustomerAsync(string customerNo, CancellationToken ct) =>
        Task.FromResult(new CustomerInfo(customerNo, customerNo.StartsWith("99", StringComparison.Ordinal), customerNo.StartsWith("98", StringComparison.Ordinal), "local:onek"));

    public async Task<LimitInfo> CashLimitAsync(int userId, DateOnly date, CancellationToken ct)
    {
        var perTransaction = await db.Users.AsNoTracking().Where(u => u.Id == userId).Select(u => (decimal?)u.CashWithdrawalLimit).FirstOrDefaultAsync(ct)
                             ?? throw new NotFoundException("Kullanıcı", userId);
        var daily = perTransaction * 3;
        return new LimitInfo(userId, "CASH", date.ToString("yyyy-MM-dd"), perTransaction, daily, 0, daily, "TRY", "local:kullanici-kaydi");
    }
}
