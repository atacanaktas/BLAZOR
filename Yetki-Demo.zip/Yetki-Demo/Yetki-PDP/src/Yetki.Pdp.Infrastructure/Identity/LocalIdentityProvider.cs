using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Identity;
using Yetki.Pdp.Domain.Identity;
using Yetki.Pdp.Domain.Rbac;

namespace Yetki.Pdp.Infrastructure.Identity;

/// <summary>Testler / tek süreç kurulumu: kimlik tabloları aynı veritabanından okunur. Revizyon model versiyonuna bağlıdır.</summary>
public sealed class LocalIdentityProvider(IYetkiDbContext db, IAuthorizationVersion version) : IIdentityProvider
{
    public string Name => "LocalDb";
    private static readonly Expression<Func<User, IdentityUser>> UserProjection = u => new(u.Id, u.TenantId, u.UserName, u.FullName, u.Email, u.Title, u.EmployeeNo, u.Kind, u.IsActive, u.IsOnLeave, u.CashWithdrawalLimit, u.CustomerNo);
    private static readonly Expression<Func<Role, IdentityRole>> RoleProjection = r => new(r.Id, r.TenantId, r.Code, r.Name, r.Description, r.IsInheritable, r.IsActive);
    private static readonly Expression<Func<UserRole, IdentityUserRole>> AssignmentProjection = x => new(x.UserId, x.RoleId, x.ValidFrom, x.ValidUntil, x.Reason, x.AssignedAt, x.AssignedBy);

    public Task<string> GetRevisionAsync(CancellationToken ct) { ct.ThrowIfCancellationRequested(); return Task.FromResult($"LocalDb:{version.Current}"); }

    public async Task<IdentitySnapshot> ReadSnapshotAsync(CancellationToken ct) => new(
        $"LocalDb:{version.Current}",
        await db.Users.AsNoTracking().Select(UserProjection).ToListAsync(ct),
        await db.Roles.AsNoTracking().Select(RoleProjection).ToListAsync(ct),
        await db.UserRoles.AsNoTracking().Select(AssignmentProjection).ToListAsync(ct),
        await db.OrgUnits.AsNoTracking().Select(u => new IdentityUnit(u.Id, u.TenantId, u.ParentId, u.Code, u.Name, u.Type, u.IsActive)).ToListAsync(ct),
        await db.UserOrgUnits.AsNoTracking().Select(x => new IdentityUserUnit(x.UserId, x.OrgUnitId, x.IsPrimary)).ToListAsync(ct));

    public Task<IdentityUser?> GetUserAsync(int id, CancellationToken ct) => db.Users.AsNoTracking().Where(x => x.Id == id).Select(UserProjection).FirstOrDefaultAsync(ct);

    public async Task<IReadOnlyList<IdentityUserRole>> GetUserRolesAsync(int userId, CancellationToken ct) =>
        await db.UserRoles.AsNoTracking().Where(x => x.UserId == userId).Select(AssignmentProjection).ToListAsync(ct);
}
