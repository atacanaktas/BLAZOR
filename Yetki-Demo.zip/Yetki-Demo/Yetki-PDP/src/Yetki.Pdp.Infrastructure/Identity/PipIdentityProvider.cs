using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Options;
using Yetki.Pdp.Application.Identity;

namespace Yetki.Pdp.Infrastructure.Identity;

public sealed class PipClientOptions
{
    public string BaseUrl { get; set; } = "http://localhost:5300";
    public string ServiceKey { get; set; } = "";
    /// <summary>Revizyonun yeniden sorulma aralığı. Kimlik değişikliği karara en geç bu süre sonra yansır.</summary>
    public int RevisionCacheMilliseconds { get; set; } = 1000;
}

/// <summary>Süreç genelinde son okunan PIP revizyonu (her istekte PIP'e gidilmesin).</summary>
public sealed class PipRevisionCache
{
    internal readonly SemaphoreSlim Lock = new(1, 1);
    internal string? Value;
    internal DateTime ReadAt = DateTime.MinValue;
}

/// <summary>
/// Kimlik verisi Yetki-PIP'ten okunur (X-Service-Key). Model önbelleği revizyon değişmedikçe görüntüyü yeniden istemez.
/// PIP erişilemezse hata yükselir: karar motoru eski / yerel veriye sessizce düşmez.
/// </summary>
public sealed class PipIdentityProvider(HttpClient http, PipRevisionCache cache, IOptions<PipClientOptions> options, Application.Abstractions.IFreshnessPolicy freshness) : IIdentityProvider
{
    public static readonly JsonSerializerOptions Json = CreateJson();

    public string Name => "Pip";

    public async Task<string> GetRevisionAsync(CancellationToken ct)
    {
        var ttl = freshness.FreshReadRequired ? TimeSpan.Zero : TimeSpan.FromMilliseconds(Math.Max(0, options.Value.RevisionCacheMilliseconds));
        if (cache.Value is { } cached && DateTime.UtcNow - cache.ReadAt < ttl) return cached;
        await cache.Lock.WaitAsync(ct);
        try
        {
            if (cache.Value is { } again && DateTime.UtcNow - cache.ReadAt < ttl) return again;
            var r = await GetAsync<RevisionView>("api/identity/revision", ct);
            cache.Value = r.Revision;
            cache.ReadAt = DateTime.UtcNow;
            return r.Revision;
        }
        finally { cache.Lock.Release(); }
    }

    public Task<IdentitySnapshot> ReadSnapshotAsync(CancellationToken ct) => GetAsync<IdentitySnapshot>("api/identity/snapshot", ct);

    public async Task<IdentityUser?> GetUserAsync(int id, CancellationToken ct)
    {
        using var res = await http.GetAsync($"api/identity/users/{id}", ct);
        if (res.StatusCode == System.Net.HttpStatusCode.NotFound) return null;
        await EnsureAsync(res, ct);
        return await res.Content.ReadFromJsonAsync<IdentityUser>(Json, ct);
    }

    public async Task<IReadOnlyList<IdentityUserRole>> GetUserRolesAsync(int userId, CancellationToken ct) =>
        await GetAsync<List<IdentityUserRole>>($"api/identity/users/{userId}/roles", ct);

    private async Task<T> GetAsync<T>(string path, CancellationToken ct)
    {
        using var res = await http.GetAsync(path, ct);
        await EnsureAsync(res, ct);
        return await res.Content.ReadFromJsonAsync<T>(Json, ct) ?? throw new InvalidOperationException($"PIP boş cevap döndü: {path}");
    }

    private static async Task EnsureAsync(HttpResponseMessage res, CancellationToken ct)
    {
        if (res.IsSuccessStatusCode) return;
        var body = await res.Content.ReadAsStringAsync(ct);
        throw new InvalidOperationException($"PIP hatası {(int)res.StatusCode} ({res.RequestMessage?.RequestUri}): {body}");
    }

    private static JsonSerializerOptions CreateJson()
    {
        var o = new JsonSerializerOptions(JsonSerializerDefaults.Web);
        o.Converters.Add(new JsonStringEnumConverter());
        return o;
    }

    private sealed record RevisionView(string Revision);
}
