using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Infrastructure.Persistence;

namespace Yetki.Pdp.Infrastructure.Services;

public sealed class SystemClock : IClock
{
    public DateTime UtcNow => DateTime.UtcNow;
}

/// <summary>Süreç içi versiyon sayacı: testler (InMemory) için.</summary>
public sealed class InProcessAuthorizationVersion : IAuthorizationVersion
{
    private long _value = 1;
    public long Current => Interlocked.Read(ref _value);
    public void Bump() => Interlocked.Increment(ref _value);
}

/// <summary>
/// Paylaşılan veritabanındaki model versiyonu (ModelState, PAP artırır). En fazla <see cref="RefreshInterval"/> aralıkla okunur:
/// PAP'taki bir değişiklik PDP'ye en geç bu süre sonra yansır. Okuma hata verirse son bilinen değer kullanılır.
/// Bump(): bu süreçte yerel artış (ör. dış kimlik kaynağı revizyonu değişti); paylaşılan değere eklenir.
/// </summary>
public sealed class DatabaseAuthorizationVersion(IServiceScopeFactory scopes, IFreshnessPolicy freshness, ILogger<DatabaseAuthorizationVersion> logger) : IAuthorizationVersion
{
    public static readonly TimeSpan RefreshInterval = TimeSpan.FromSeconds(1);

    private readonly Lock _lock = new();
    private long _shared;
    private long _local;
    private DateTime _readAt = DateTime.MinValue;

    public long Current
    {
        get
        {
            lock (_lock)
            {
                if (freshness.FreshReadRequired || DateTime.UtcNow - _readAt >= RefreshInterval)
                {
                    try
                    {
                        using var scope = scopes.CreateScope();
                        var db = scope.ServiceProvider.GetRequiredService<YetkiDbContext>();
                        _shared = db.ModelStates.AsNoTracking().Where(s => s.Id == 1).Select(s => s.Version).FirstOrDefault();
                    }
                    catch (Exception ex)
                    {
                        logger.LogWarning(ex, "Model versiyonu okunamadı; son bilinen değer ({Version}) kullanılıyor.", _shared);
                    }
                    _readAt = DateTime.UtcNow;
                }
                return _shared + _local;
            }
        }
    }

    public void Bump()
    {
        lock (_lock) _local++;
    }
}

/// <summary>Arka plan işleri ve testler için sabit aktör.</summary>
public sealed class SystemActor(string name = "system") : ICurrentActor
{
    public string Name { get; } = name;
}
