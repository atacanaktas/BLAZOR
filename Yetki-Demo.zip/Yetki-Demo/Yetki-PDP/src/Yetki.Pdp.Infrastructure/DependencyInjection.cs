using Yetki.Pdp.Application.Identity;
using Yetki.Pdp.Infrastructure.Identity;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;
using Yetki.Pdp.Application;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Evaluation;
using Yetki.Pdp.Application.PolicyEngine.Conditions;
using Yetki.Pdp.Infrastructure.Persistence;
using Yetki.Pdp.Infrastructure.Services;

namespace Yetki.Pdp.Infrastructure;

public static class DependencyInjection
{
    /// <summary>
    /// Persistence:Provider
    ///  - "Sqlite" (varsayılan): ConnectionStrings:Yetki — PAP ile PAYLAŞILAN veritabanı. Göreli yol <paramref name="basePath"/>'e göre çözülür.
    ///  - "InMemory": testler için (versiyon süreç içi sayaçtır).
    /// </summary>
    public static IServiceCollection AddYetkiInfrastructure(this IServiceCollection services, IConfiguration config, string? basePath = null)
    {
        services.AddYetkiApplication();

        var provider = config["Persistence:Provider"] ?? "Sqlite";
        services.AddDbContext<YetkiDbContext>(options =>
        {
            switch (provider)
            {
                case "Sqlite":
                    options.UseSqlite(ResolveSqlite(config.GetConnectionString("Yetki") ?? "Data Source=yetki.db", basePath));
                    break;
                case "InMemory":
                    options.UseInMemoryDatabase(config["Persistence:InMemoryDatabaseName"] ?? "YetkiDb")
                           .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning));
                    break;
                default:
                    throw new InvalidOperationException($"Desteklenmeyen persistence provider: {provider}");
            }
        });
        services.AddScoped<IYetkiDbContext>(sp => sp.GetRequiredService<YetkiDbContext>());

        // The single composition point for identity-source integration.
        // Kimlik kaynağı (PIP). Varsayılan: Yetki-PIP API'si; "LocalDb" testler / tek süreç içindir.
        switch (config["Identity:Provider"] ?? "Pip")
        {
            case "Pip":
                services.Configure<PipClientOptions>(config.GetSection("Pip"));
                services.AddSingleton<PipRevisionCache>();
                services.AddHttpClient<IIdentityProvider, PipIdentityProvider>((sp, c) =>
                {
                    var o = sp.GetRequiredService<Microsoft.Extensions.Options.IOptions<PipClientOptions>>().Value;
                    c.BaseAddress = new Uri(o.BaseUrl.TrimEnd('/') + "/");
                    c.Timeout = TimeSpan.FromSeconds(15);
                    c.DefaultRequestHeaders.Add("X-Service-Key", o.ServiceKey);
                });
                services.AddMemoryCache();
                services.AddHttpClient<IExternalAttributeSource, PipExternalAttributeSource>((sp, c) =>
                {
                    var o = sp.GetRequiredService<Microsoft.Extensions.Options.IOptions<PipClientOptions>>().Value;
                    c.BaseAddress = new Uri(o.BaseUrl.TrimEnd('/') + "/");
                    c.Timeout = TimeSpan.FromSeconds(5);
                    c.DefaultRequestHeaders.Add("X-Service-Key", o.ServiceKey);
                });
                break;
            case "LocalDb":
                services.AddScoped<IIdentityProvider, LocalIdentityProvider>();
                services.AddScoped<IExternalAttributeSource, LocalExternalAttributeSource>();
                break;
            default: throw new InvalidOperationException("Unsupported identity provider: " + config["Identity:Provider"]);
        }
        services.AddSingleton<IClock, SystemClock>();
        services.TryAddSingleton<IFreshnessPolicy, NoFreshnessRequired>();
        if (provider == "InMemory") services.AddSingleton<IAuthorizationVersion, InProcessAuthorizationVersion>();
        else services.AddSingleton<IAuthorizationVersion, DatabaseAuthorizationVersion>();
        services.Configure<AuthorizationEngineOptions>(o => config.GetSection("AuthorizationEngine").Bind(o));
        return services;
    }

    /// <summary>"Data Source=yetki.db" gibi göreli yolları verilen klasöre göre mutlak yapar (çalışma dizininden bağımsız).</summary>
    public static string ResolveSqlite(string connectionString, string? basePath)
    {
        var b = new SqliteConnectionStringBuilder(connectionString);
        if (basePath is not null && !string.IsNullOrWhiteSpace(b.DataSource) && b.DataSource != ":memory:" && !Path.IsPathRooted(b.DataSource))
            b.DataSource = Path.GetFullPath(Path.Combine(basePath, b.DataSource));
        return b.ToString();
    }

    /// <summary>
    /// PDP veritabanı hazırlığı. Şema PAP'a aittir: PDP migration ÇALIŞTIRMAZ, dosya yoksa oluşturmaz.
    /// İlişkisel sağlayıcıda veritabanı ve ModelState tablosu yoksa başlatma durur (önce PAP migration'ları uygulanmalı).
    /// Condition tipi kataloğu koddaki handler'larla senkronize edilir (handler'lar PDP'de çalıştığı için katalog PDP'nin sorumluluğu).
    /// InMemory'de (testler) şema EnsureCreated ile kurulur.
    /// </summary>
    public static async Task InitializeYetkiDatabaseAsync(this IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var sp = scope.ServiceProvider;
        var db = sp.GetRequiredService<YetkiDbContext>();
        if (db.Database.IsRelational())
        {
            var source = db.Database.GetDbConnection().DataSource;
            if (db.Database.ProviderName == "Microsoft.EntityFrameworkCore.Sqlite" && !File.Exists(source))
                throw new InvalidOperationException($"Veritabanı bulunamadı: {source}. PDP şema oluşturmaz; PAP (Yetki-PAP) migration'larını uygulayın.");
            try
            {
                await db.ModelStates.AsNoTracking().AnyAsync();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Veritabanı şeması PDP ile uyumsuz ({source}): ModelState okunamadı. PAP migration'larını uygulayın.", ex);
            }
        }
        else await db.Database.EnsureCreatedAsync();

        await sp.GetRequiredService<ConditionTypeCatalogSynchronizer>().SyncAsync();

        sp.GetRequiredService<ILoggerFactory>().CreateLogger("Yetki")
            .LogInformation("Yetki veritabanı hazır ({Provider}: {Source}).", db.Database.ProviderName, db.Database.IsRelational() ? db.Database.GetDbConnection().DataSource : "in-memory");
    }
}
