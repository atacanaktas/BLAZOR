using Yetki.Pdp.Domain.Common;
using Yetki.Pdp.Domain.Tenants;
using Yetki.Pdp.Domain.Identity;

namespace Yetki.Pdp.Domain.Rbac;

/// <summary>
/// İş rolü (HR / kimlik kaynağının verisi). Bir kuruma aittir; IsInheritable=true ise alt kurumların kullanıcılarına da atanabilir.
/// Rol yetki TAŞIMAZ: Keycloak modelinde yetki, rolü üye alan Role policy'si ve onu kullanan Permission ile verilir.
/// </summary>
public class Role : AuditableEntity
{
    public int TenantId { get; set; }
    public Tenant Tenant { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsInheritable { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>Kullanıcıya doğrudan rol ataması. Süreli olabilir (vekalet, geçici görev).</summary>
public class UserRole : IAssignment
{
    public int UserId { get; set; }
    public User User { get; set; } = default!;
    public int RoleId { get; set; }
    public Role Role { get; set; } = default!;
    public DateTime? ValidFrom { get; set; }
    public DateTime? ValidUntil { get; set; }
    public string? Reason { get; set; }
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}
