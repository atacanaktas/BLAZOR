namespace Yetki.Pdp.Domain.Common;

/// <summary>Tüm kalıcı varlıkların tabanı. Int identity anahtar SQL Server'a birebir taşınır.</summary>
public abstract class Entity
{
    public int Id { get; set; }
}

/// <summary>Yönetim ekranlarından değiştirilen varlıklar için izlenebilirlik alanları (DbContext otomatik doldurur).</summary>
public abstract class AuditableEntity : Entity
{
    public DateTime CreatedAt { get; set; }
    public string CreatedBy { get; set; } = "system";
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

/// <summary>
/// Yetki modelinin paylaşılan versiyonu (tek satır, Id = 1). Şema ve artırma PAP'a aittir; PDP sadece okur
/// ve önbellekteki modelin eskidiğini buradan anlar.
/// </summary>
public class ModelState
{
    public int Id { get; set; }
    public long Version { get; set; }
    public DateTime ChangedAt { get; set; }
}

/// <summary>Atama (ilişki) tabloları için ortak alanlar.</summary>
public interface IAssignment
{
    DateTime AssignedAt { get; set; }
    string AssignedBy { get; set; }
}

// ------------------------------ Tenant ------------------------------

public enum TenantType { Bank = 1, Subsidiary = 2 }

public enum OrgUnitType { HeadOffice = 1, Department = 2, Region = 3, Branch = 4 }

public enum UserKind { Person = 1, ServiceAccount = 2 }

// ------------------------------ Katalog ------------------------------

/// <summary>Resource server'ın (uygulamanın) türü.</summary>
public enum ApplicationType { ApiPlatform = 1, Desktop = 2, Mobile = 3, Web = 4, Batch = 5 }

/// <summary>
/// OAuth 2.0 client türü (RFC 6749): gizli anahtar tutabilen / tutamayan / servis (client credentials) /
/// ARACI (gateway, BFF, kullanıcı adına başka API çağıran servis — RFC 8693 "act"). Aracı isteği BAŞLATMAZ:
/// karar orijinal client'a (azp) göre verilir, aracı zinciri (via) ayrıca doğrulanır ve audit'e yazılır.
/// </summary>
public enum ClientType { Confidential = 1, Public = 2, Service = 3, Intermediary = 4 }

/// <summary>Yükümlülüğün hangi kararda PEP'e döneceği (XACML FulfillOn).</summary>
public enum ObligationFulfillOn { Permit = 1, Deny = 2 }

public enum InclusionMode { Include = 1, Exclude = 2 }

// ------------------------------ Policy / Permission (Keycloak Authorization Services) ------------------------------

/// <summary>Positive: sonuç olduğu gibi. Negative: sonuç tersine çevrilir (ör. "stajyer DEĞİLSE").</summary>
public enum PolicyLogic { Positive = 1, Negative = 2 }

/// <summary>
/// Karar stratejisi (Keycloak): birden fazla sonucun tek sonuca indirgenmesi.
/// Unanimous: hepsi izin vermeli · Affirmative: en az biri yeterli · Consensus: izin verenler reddedenlerden fazla olmalı.
/// Permission'da policy'leri, Aggregate policy'de alt policy'leri, Condition policy'de kuralları, uygulamada (resource server)
/// aynı resource/scope'a uygulanan permission'ları birleştirir.
/// </summary>
public enum DecisionStrategy { Unanimous = 1, Affirmative = 2, Consensus = 3 }

/// <summary>
/// Enforce: karara katılır. ReportOnly: değerlendirilir ve kaydedilir ama kararı etkilemez (güvenli devreye alma).
/// Advisory: kararı etkilemez; koşulu sağlanırsa yükümlülüklerini (ör. TCKN maskele) karara ekler.
/// </summary>
public enum PolicyMode { Enforce = 1, ReportOnly = 2, Advisory = 3 }

/// <summary>Permission'ın neye uygulandığı. Açıkça seçilir; boş resource listesi "tümü" değil, "hiçbiri" demektir.</summary>
public enum PermissionTarget { Resources = 1, ResourceType = 2, Application = 3 }

/// <summary>Condition tipinin kapsamı: ortak (mesai, IP, kanal) veya iş alanına özel.</summary>
public enum ConditionScope { Global = 1, Domain = 2 }

/// <summary>Condition ağacı düğüm tipi.</summary>
public enum ConditionKind { Predicate = 1, AllOf = 2, AnyOf = 3, Not = 4, Reference = 5 }

/// <summary>Koşulun cevapladığı soru (policy ekranındaki kart): KİM, NEREDEN, NEREYE / KİME, NE KADAR, HANGİ SAAT, NE ZAMAN.</summary>
public enum ConditionQuestion { Who = 1, From = 2, Target = 3, HowMuch = 4, Time = 5, When = 6 }

// ------------------------------ SoD / olaylar / audit ------------------------------

/// <summary>SoD üyesi: bir yetki (resource + scope, ör. anka.vadelihesap:close) veya bir rol.</summary>
public enum SodMemberType { ResourceScope = 1, Role = 2 }

/// <summary>Block: atama engellenir. Warn: atama yapılır, ihlal kaydı açılır ve uyarı döner.</summary>
public enum SodEnforcement { Warn = 1, Block = 2 }

public enum Severity { Low = 1, Medium = 2, High = 3, Critical = 4 }

public enum ViolationStatus { Open = 1, Acknowledged = 2, AcceptedRisk = 3, Resolved = 4 }

public enum ViolationDetectionSource { AssignmentCheck = 1, RetrospectiveScan = 2 }

public enum OutboxStatus { Pending = 1, Processed = 2, Failed = 3 }

/// <summary>Grant: dış yetki ver · Revoke: geri al · Modify: erişim seviyesini değiştir (ör. READ → UPDATE).</summary>
public enum ProvisioningActionType { Grant = 1, Revoke = 2, Modify = 3 }

/// <summary>
/// Dış sistemdeki erişim seviyesi (RACF PERMIT ACCESS). Sıralıdır: büyük seviye küçüğü kapsar.
/// Seviyesi olmayan sistemlerde (LDAP grup üyeliği) kullanılmaz (null).
/// </summary>
public enum ExternalAccessLevel { Read = 1, Update = 2, Control = 3, Alter = 4 }

public enum ProvisioningStatus { Pending = 1, Completed = 2, Failed = 3 }

public enum AuditCategory { AuthorizationDecision = 1, Management = 2, Simulation = 3, SodScan = 4 }
