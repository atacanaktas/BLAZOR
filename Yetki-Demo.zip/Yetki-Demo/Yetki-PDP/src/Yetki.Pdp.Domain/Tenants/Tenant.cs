using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Domain.Tenants;

/// <summary>
/// Tenant: yetkilendirme verisinin izolasyon sınırı (A Bankası → B İştiraki).
/// Kullanıcı, birim, rol, grup, policy, client ve katalog uygulaması bir tenant'a aittir.
/// Tek miras kuralı: bir tenant KENDİ ve ÜST tenant'larının tanımlarını kullanır (policy, uygulama, client;
/// rol için ayrıca IsInheritable gerekir). Bir tenant'ın kullanıcısı başka tenant'ın kaynağına erişemez (tenant izolasyonu).
/// </summary>
public class Tenant : AuditableEntity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public TenantType Type { get; set; }
    public int? ParentId { get; set; }
    public Tenant? Parent { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>Kurum birimi (Genel Müdürlük, daire, bölge, şube). Kod kurum içinde tekildir.</summary>
public class OrgUnit : AuditableEntity
{
    public int TenantId { get; set; }
    public Tenant Tenant { get; set; } = default!;
    public int? ParentId { get; set; }
    public OrgUnit? Parent { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public OrgUnitType Type { get; set; }
    public bool IsActive { get; set; } = true;
}
