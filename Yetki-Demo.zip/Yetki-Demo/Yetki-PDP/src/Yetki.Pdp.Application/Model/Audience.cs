using Yetki.Pdp.Application.PolicyEngine;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.Model;

/// <summary>Kitle satırı: kriterler VE ile; Include satırları VEYA ile birleşir, Exclude satırına uyan çıkarılır (grup kitle kuralıyla aynı biçim).</summary>
public sealed record AudienceRow(InclusionMode Mode, IReadOnlyList<CriterionRow> Criteria);

/// <summary>
/// KİTLE = grup kuralı = KİM kartı. Aynı biçimin iki gösterimi arasında çeviri:
///   grup kuralı satırları (ROLE ∈ {...} ∧ ORG_UNIT ∈ {...}; Include / Exclude)
///   ↔ koşul ağacı:  Include kısmı  [AND NOT (Exclude kısmı)]
///      kısım = tek satır veya satırların OR'u · satır = tek koşul veya koşulların AND'i · koşul = kimlik koşul tipi.
/// Kriter ↔ koşul tipi: ROLE ↔ SUBJECT_HAS_ROLE, ORG_UNIT ↔ SUBJECT_IN_UNIT, ORG_UNIT_TREE ↔ SUBJECT_IN_UNIT(IncludeSubtree),
/// ORG_UNIT_TYPE ↔ SUBJECT_UNIT_TYPE, TITLE ↔ SUBJECT_HAS_TITLE, TENANT ↔ SUBJECT_IN_TENANT, USER ↔ SUBJECT_IS_USER, USER_KIND ↔ SUBJECT_KIND.
/// GROUP (SUBJECT_IN_GROUP) sadece kartta vardır (grup içinde grup yok) → böyle bir satır gruba çevrilemez.
/// DİKKAT: grup ROLE kriteri DOĞRUDAN rollere, kart SUBJECT_HAS_ROLE ETKİN rollere (gruptan gelen dahil) bakar; çeviri sonrası
/// üye eşitliği bu yüzden ayrıca kontrol edilir.
/// </summary>
public static class Audience
{
    public const string GroupCriterion = "GROUP";

    private sealed record Map(string Criterion, string ConditionType, string Param, bool Subtree = false);

    private static readonly Map[] Maps =
    [
        new("ROLE", "SUBJECT_HAS_ROLE", "Roles"),
        new("ORG_UNIT", "SUBJECT_IN_UNIT", "Units"),
        new("ORG_UNIT_TREE", "SUBJECT_IN_UNIT", "Units", Subtree: true),
        new("ORG_UNIT_TYPE", "SUBJECT_UNIT_TYPE", "Types"),
        new("TITLE", "SUBJECT_HAS_TITLE", "Titles"),
        new("TENANT", "SUBJECT_IN_TENANT", "Tenants"),
        new("USER", "SUBJECT_IS_USER", "Users"),
        new("USER_KIND", "SUBJECT_KIND", "Kinds"),
        new(GroupCriterion, "SUBJECT_IN_GROUP", "Groups"),
    ];

    private static readonly IReadOnlyDictionary<string, string> NoParams = new Dictionary<string, string>();

    /// <summary>Koşul ağacı bir kitle mi? (KİM kartı) Değilse null.</summary>
    public static IReadOnlyList<AudienceRow>? Parse(ConditionNode? node)
    {
        if (node is null) return null;
        // Include [AND NOT Exclude]
        if (node.Kind == ConditionKind.AllOf && node.Children.Count == 2 && node.Children[1].Kind == ConditionKind.Not && node.Children[1].Children.Count == 1)
        {
            var inc = Part(node.Children[0], InclusionMode.Include);
            var exc = Part(node.Children[1].Children[0], InclusionMode.Exclude);
            return inc is null || exc is null ? null : [.. inc, .. exc];
        }
        return Part(node, InclusionMode.Include);
    }

    private static List<AudienceRow>? Part(ConditionNode node, InclusionMode mode)
    {
        var rows = node.Kind == ConditionKind.AnyOf ? node.Children : [node];
        var result = new List<AudienceRow>();
        foreach (var r in rows)
        {
            var row = Row(r);
            if (row is null) return null;
            result.Add(new AudienceRow(mode, row));
        }
        return result.Count == 0 ? null : result;
    }

    private static List<CriterionRow>? Row(ConditionNode node)
    {
        var preds = node.Kind == ConditionKind.AllOf ? node.Children : [node];
        var result = new List<CriterionRow>();
        foreach (var p in preds)
        {
            if (p.Kind != ConditionKind.Predicate || p.ConditionTypeCode is null) return null;
            var c = Criterion(p.ConditionTypeCode, p.Parameters);
            if (c is null) return null;
            result.Add(c);
        }
        return result.Count == 0 ? null : result;
    }

    private static CriterionRow? Criterion(string type, IReadOnlyDictionary<string, string> ps)
    {
        var subtree = ps.TryGetValue("IncludeSubtree", out var s) && bool.TryParse(s, out var b) && b;
        var map = Maps.FirstOrDefault(m => string.Equals(m.ConditionType, type, StringComparison.OrdinalIgnoreCase) && m.Subtree == subtree);
        if (map is null) return null;
        var extra = ps.Keys.Where(k => !string.Equals(k, map.Param, StringComparison.OrdinalIgnoreCase) && !string.Equals(k, "IncludeSubtree", StringComparison.OrdinalIgnoreCase));
        if (extra.Any()) return null;
        var values = ps.TryGetValue(map.Param, out var v) ? Common.Codes.SplitList(v) : [];
        return values.Count == 0 ? null : new CriterionRow(map.Criterion, values);
    }

    /// <summary>Kitleyi koşul ağacına çevirir (KİM kartının kaydedilen hali).</summary>
    public static ConditionDraft ToCondition(IEnumerable<AudienceRow> rows)
    {
        var list = rows.ToList();
        ConditionDraft? PartOf(InclusionMode mode)
        {
            var rs = list.Where(r => r.Mode == mode).Select(r =>
            {
                var preds = r.Criteria.Select(PredicateOf).ToList();
                return preds.Count == 1 ? preds[0] : new ConditionDraft { Kind = ConditionKind.AllOf, Children = preds };
            }).ToList();
            return rs.Count == 0 ? null : rs.Count == 1 ? rs[0] : new ConditionDraft { Kind = ConditionKind.AnyOf, Children = rs };
        }
        var inc = PartOf(InclusionMode.Include) ?? throw new Abstractions.ValidationException("Kitlede en az bir dahil (Include) satırı olmalı.");
        var exc = PartOf(InclusionMode.Exclude);
        return exc is null ? inc : new ConditionDraft
        {
            Kind = ConditionKind.AllOf,
            Children = [inc, new ConditionDraft { Kind = ConditionKind.Not, Children = [exc] }]
        };
    }

    private static ConditionDraft PredicateOf(CriterionRow c)
    {
        var map = Maps.FirstOrDefault(m => string.Equals(m.Criterion, c.Attribute, StringComparison.OrdinalIgnoreCase))
                  ?? throw new Abstractions.ValidationException($"Bilinmeyen kitle kriteri: {c.Attribute}");
        var ps = new Dictionary<string, string> { [map.Param] = string.Join(",", c.Values) };
        if (map.Subtree) ps["IncludeSubtree"] = "true";
        return new ConditionDraft { Kind = ConditionKind.Predicate, ConditionTypeCode = map.ConditionType, Parameters = ps };
    }

    /// <summary>
    /// Tanımın normal biçimi: satır ve kriter sırası, değer sırası ve büyük/küçük harf önemsiz.
    /// İki kitlenin anahtarı eşitse TANIMLARI aynıdır (üyeleri bugün de yarın da aynı olur — ROLE notu hariç).
    /// </summary>
    public static string Key(IEnumerable<AudienceRow> rows) =>
        string.Join(" | ", rows
            .Select(r => (r.Mode == InclusionMode.Include ? "+" : "-") + "(" + string.Join(" & ", r.Criteria
                .GroupBy(c => c.Attribute.ToUpperInvariant())
                .Select(g => $"{g.Key}={string.Join(",", g.SelectMany(c => c.Values).Select(v => v.Trim().ToUpperInvariant()).Distinct().OrderBy(v => v, StringComparer.Ordinal))}")
                .OrderBy(x => x, StringComparer.Ordinal)) + ")")
            .Distinct()
            .OrderBy(x => x, StringComparer.Ordinal));

    /// <summary>Gruba çevrilebilir mi? (GROUP kriteri grup içinde olamaz)</summary>
    public static bool CanBecomeGroup(IEnumerable<AudienceRow> rows) =>
        rows.All(r => r.Criteria.All(c => !string.Equals(c.Attribute, GroupCriterion, StringComparison.OrdinalIgnoreCase)));

    public static IReadOnlyList<AudienceRow> FromFilters(IEnumerable<GroupFilterRow> filters) =>
        filters.OrderBy(f => f.Order).Select(f => new AudienceRow(f.Mode, f.Criteria)).ToList();

    public static IReadOnlyList<AudienceRow> FromDrafts(IEnumerable<GroupFilterDraft> filters) =>
        filters.Select(f => new AudienceRow(f.Mode, f.Criteria.Select(c => new CriterionRow(c.Attribute.Trim().ToUpperInvariant(),
            c.Values.Select(v => v.Trim()).Where(v => v.Length > 0).ToList())).ToList())).ToList();

    /// <summary>Taslak koşulu ConditionNode'a çevirir (statik değerlendirme için).</summary>
    public static ConditionNode ToNode(ConditionDraft d)
    {
        var id = 0;
        return Convert(d);
        ConditionNode Convert(ConditionDraft x) => new(--id, x.Kind, x.ConditionTypeCode, true,
            x.Parameters.Count == 0 ? NoParams : new Dictionary<string, string>(x.Parameters, StringComparer.OrdinalIgnoreCase),
            x.Children.Select(Convert).ToList());
    }
}
