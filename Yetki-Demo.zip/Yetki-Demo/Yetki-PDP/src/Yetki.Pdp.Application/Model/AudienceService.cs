using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.PolicyEngine;

namespace Yetki.Pdp.Application.Model;

public sealed class AudienceOverlapRequest
{
    /// <summary>Kartın yazıldığı policy (kurum ve kendi kuralını dışlamak için).</summary>
    public int? PolicyId { get; set; }
    /// <summary>Düzenlenen kural (kendisiyle eşleşmesin).</summary>
    public int? RuleId { get; set; }
    public int? TenantId { get; set; }
    public List<GroupFilterDraft> Filters { get; set; } = new();
}

public sealed record AudienceRuleRef(int PolicyId, string Policy, string PolicyName, int RuleId, string Rule, string RuleName, int MemberCount);
public sealed record AudienceGroupRef(int GroupId, string Code, string Name, int MemberCount, bool SameMembers, bool HasExplicitMembers, IReadOnlyList<string> Roles);

/// <summary>
/// KİM kartı örtüşme sonucu.
///  SameDefinition / SameDefinitionGroups: TANIMI birebir aynı kitleler → "grup yapalım mı / bu grubu kullan" sorulur.
///  SameMembersRules / SameMembersGroups: tanım farklı ama BUGÜN aynı kişiler → sadece bilgi (tesadüf olabilir).
/// Kısmi örtüşme raporlanmaz.
/// </summary>
public sealed record AudienceOverlapResult(
    string Key, string Expression, bool CanBecomeGroup, IReadOnlyList<string> Members,
    IReadOnlyList<AudienceRuleRef> SameDefinition, IReadOnlyList<AudienceGroupRef> SameDefinitionGroups,
    IReadOnlyList<AudienceRuleRef> SameMembersRules, IReadOnlyList<AudienceGroupRef> SameMembersGroups);

/// <summary>KİM kartı (kitle) ↔ diğer KİM kartları ve gruplar: tanım ve üye karşılaştırması. Sadece aynı kurum zincirindekiler.</summary>
public sealed class AudienceService(AuthorizationModelProvider models, IClock clock)
{
    public async Task<AudienceOverlapResult> OverlapAsync(AudienceOverlapRequest r, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        var rows = Audience.FromDrafts(r.Filters);
        if (rows.Count == 0 || rows.Any(x => x.Criteria.Count == 0 || x.Criteria.Any(c => c.Values.Count == 0)))
            throw new ValidationException("Kitlede en az bir satır olmalı; her satırda en az bir kriter ve değer bulunmalı.");
        var condition = Audience.ToCondition(rows);
        var node = Audience.ToNode(condition);
        var key = Audience.Key(rows);
        var members = m.AudienceMembers(node, now).Select(u => u.UserName).ToList();
        var memberSet = members.ToHashSet(StringComparer.OrdinalIgnoreCase);

        var tenantId = r.TenantId ?? (r.PolicyId is { } pid && m.Policies.TryGetValue(pid, out var self) ? self.Row.TenantId : null);
        bool SameChain(int t) => tenantId is not { } tid || m.IsAvailableIn(t, tid) || m.IsAvailableIn(tid, t);

        var sameDef = new List<AudienceRuleRef>();
        var sameMembers = new List<AudienceRuleRef>();
        foreach (var p in m.Policies.Values.Where(p => p.Definition is not null && SameChain(p.Row.TenantId)))
            foreach (var rule in p.Definition!.Rules.Where(x => x.RuleId != r.RuleId))
            {
                var other = Audience.Parse(rule.Condition);
                if (other is null) continue;
                var otherMembers = m.AudienceMembers(rule.Condition!, now).Select(u => u.UserName).ToList();
                var reference = new AudienceRuleRef(p.Row.Id, p.Row.Code, p.Row.Name, rule.RuleId, rule.Code, rule.Name, otherMembers.Count);
                if (Audience.Key(other) == key) sameDef.Add(reference);
                else if (memberSet.Count > 0 && otherMembers.Count == memberSet.Count && otherMembers.All(memberSet.Contains)) sameMembers.Add(reference);
            }

        var sameDefGroups = new List<AudienceGroupRef>();
        var sameMemberGroups = new List<AudienceGroupRef>();
        foreach (var g in m.Groups.Values.Where(g => g.IsActive && SameChain(g.TenantId)))
        {
            var groupMembers = m.GroupMembersOf(g.Id, now).Select(x => x.User.UserName).ToList();
            var same = groupMembers.Count == memberSet.Count && groupMembers.All(memberSet.Contains);
            var explicitMembers = m.GroupMemberRows(g.Id).Any();
            var reference = new AudienceGroupRef(g.Id, g.Code, g.Name, groupMembers.Count, same, explicitMembers,
                m.GroupRoleIds(g.Id).Where(m.Roles.ContainsKey).Select(id => m.Roles[id].Code).ToList());
            var filters = m.GroupFilterRows(g.Id).ToList();
            if (filters.Count > 0 && !explicitMembers && Audience.Key(Audience.FromFilters(filters)) == key) sameDefGroups.Add(reference);
            else if (same && memberSet.Count > 0) sameMemberGroups.Add(reference);
        }

        return new AudienceOverlapResult(key, PolicyEvaluator.Render(node), Audience.CanBecomeGroup(rows), members,
            sameDef.OrderBy(x => x.Policy).ToList(), sameDefGroups, sameMembers.OrderBy(x => x.Policy).ToList(), sameMemberGroups);
    }

    /// <summary>Kuralın koşulu bir kitleyse satırları (KİM kartı → grup kuralı taşıma için).</summary>
    public async Task<IReadOnlyList<AudienceRow>?> RuleAudienceAsync(int ruleId, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var rule = m.Policies.Values.Where(p => p.Definition is not null).SelectMany(p => p.Definition!.Rules).FirstOrDefault(x => x.RuleId == ruleId)
                   ?? throw new NotFoundException("Kural", ruleId);
        return Audience.Parse(rule.Condition);
    }
}
