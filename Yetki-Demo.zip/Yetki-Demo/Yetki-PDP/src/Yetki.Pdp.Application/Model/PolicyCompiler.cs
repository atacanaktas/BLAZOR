using Yetki.Pdp.Application.PolicyEngine;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.Model;

/// <summary>Değerlendirmeye hazır policy: kural seti (kartlar) ve yükümlülükler.</summary>
public sealed record CompiledPolicy(PolicyRow Row, string TenantCode, PolicyDefinition Definition, IReadOnlyList<ObligationRow> Obligations);

/// <summary>Değerlendirmeye hazır Keycloak permission: kapsam (resource / tip / scope) + policy'ler.</summary>
public sealed record CompiledPermission(PermissionRow Row, AppRow App, IReadOnlySet<int> Resources, IReadOnlySet<int> Scopes, IReadOnlyList<int> PolicyIds)
{
    /// <summary>
    /// Permission bu yetkiye (resource:scope) uygulanır mı? Kapsam açıkça seçilir: boş resource / scope listesi
    /// "hiçbiri" demektir (permission atıl kalır), asla "tümü" değil — silinen resource yetkiyi genişletemez.
    /// </summary>
    public bool Applies(ResourceScopeInfo rs) =>
        rs.App.Id == Row.ApplicationId
        && Row.Target switch
        {
            PermissionTarget.Resources => Resources.Contains(rs.Resource.Id),
            PermissionTarget.ResourceType => Row.ResourceTypeId == rs.Resource.ResourceTypeId,
            PermissionTarget.Application => true,
            _ => false
        }
        && (Row.AllScopes || Scopes.Contains(rs.Scope.Id));
}

/// <summary>
/// Model verisinden (ve opsiyonel What-If policy değişikliklerinden) değerlendirmeye hazır policy'leri kurar.
///  - Pasif policy'ler de derlenir (yönetim ekranı için); değerlendirmede pasif policy izin vermez.
///  - Bulunamayan / pasif / döngüsel policy referansı değerlendirmede Indeterminate olur (fail-closed).
/// </summary>
public static class PolicyCompiler
{
    public static IReadOnlyList<CompiledPolicy> Compile(ModelData data, PolicyChangeSet? changes)
    {
        var resolver = new ConditionTreeResolver(data.Conditions, data.Policies, changes);
        var tenants = data.Tenants.ToDictionary(o => o.Id, o => o.Code);
        var removedRules = changes?.RemovedRuleIds.ToHashSet() ?? [];
        var rulesByPolicy = data.Rules.ToLookup(r => r.PolicyId);
        var obligationsByPolicy = data.Obligations.ToLookup(o => o.PolicyId);

        var result = new List<CompiledPolicy>();
        foreach (var p0 in data.Policies)
        {
            var p = p0 with
            {
                IsActive = changes?.PolicyActivations.LastOrDefault(a => a.PolicyId == p0.Id)?.IsActive ?? p0.IsActive,
                Mode = changes?.PolicyModes.LastOrDefault(a => a.PolicyId == p0.Id)?.Mode ?? p0.Mode,
                Strategy = changes?.PolicyStrategies.LastOrDefault(a => a.PolicyId == p0.Id)?.Strategy ?? p0.Strategy
            };

            var rules = rulesByPolicy[p.Id].Where(r => !removedRules.Contains(r.Id)).Select(r =>
            {
                var o = changes?.RuleOverrides.LastOrDefault(x => x.RuleId == r.Id);
                var rep = changes?.ReplacedRules.LastOrDefault(x => x.RuleId == r.Id);
                return rep is null
                    ? new RuleDefinition(r.Id, r.Code, r.Name, r.Description, o?.Order ?? r.Order, r.ReasonCode, o?.IsActive ?? r.IsActive, resolver.RuleRoot(r.Id))
                    : new RuleDefinition(r.Id, r.Code, rep.Rule.Name ?? r.Name, r.Description, rep.Rule.Order, rep.Rule.ReasonCode,
                        o?.IsActive ?? rep.Rule.IsActive, resolver.FromDraft(rep.Rule.Condition));
            }).ToList();
            if (changes is not null)
            {
                var draftRuleId = -1000 * p.Id - 1;
                foreach (var d in changes.AddedRules.Where(d => d.PolicyId == p.Id))
                    rules.Add(new RuleDefinition(draftRuleId--, d.Code, d.Name ?? d.Code, "What-If taslağı", d.Order, d.ReasonCode, d.IsActive, resolver.FromDraft(d.Condition)));
            }

            result.Add(new CompiledPolicy(p, tenants.GetValueOrDefault(p.TenantId, "?"), new PolicyDefinition(p.Id, p.Code, p.Name, p.Version, p.Strategy, rules),
                obligationsByPolicy[p.Id].OrderBy(o => o.Order).ThenBy(o => o.Code, StringComparer.Ordinal).ToList()));
        }
        return result;
    }

    public static IReadOnlyList<CompiledPermission> CompilePermissions(ModelData data)
    {
        var apps = data.Applications.ToDictionary(a => a.Id);
        var tenants = data.Tenants.ToDictionary(t => t.Id, t => t.ParentId);
        var policyRows = data.Policies.ToDictionary(p => p.Id);
        var res = data.PermissionResources.ToLookup(x => x.PermissionId, x => x.ResourceId);
        var scopes = data.PermissionScopes.ToLookup(x => x.PermissionId, x => x.ScopeId);
        var policies = data.PermissionPolicies.ToLookup(x => x.PermissionId);
        return data.Permissions.Where(p => apps.ContainsKey(p.ApplicationId)).Select(p => new CompiledPermission(p, apps[p.ApplicationId],
            res[p.Id].ToHashSet(), scopes[p.Id].ToHashSet(), policies[p.Id].OrderBy(x => x.Order).Select(x => x.PolicyId)
                // Eski/bozuk veri PAP doğrulamasını aşmış olsa bile başka tenant policy'si karar modeline giremez (fail-closed).
                .Where(policyId => policyRows.TryGetValue(policyId, out var policy) && IsAncestor(policy.TenantId, apps[p.ApplicationId].TenantId, tenants))
                .ToList())).ToList();

        static bool IsAncestor(int ownerTenantId, int targetTenantId, IReadOnlyDictionary<int, int?> parents)
        {
            var seen = new HashSet<int>();
            int? current = targetTenantId;
            while (current is { } tenantId && seen.Add(tenantId))
            {
                if (tenantId == ownerTenantId) return true;
                current = parents.GetValueOrDefault(tenantId);
            }
            return false;
        }
    }

    /// <summary>Taslak condition ağacını çözümsüz düğüme çevirir (referanslar sadece kodla; audit metni/önizleme için).</summary>
    public static ConditionNode FromDraftUnresolved(ConditionDraft d)
    {
        var id = 0;
        return Convert(d);

        ConditionNode Convert(ConditionDraft x) => x.Kind == ConditionKind.Reference
            ? new ConditionNode(--id, ConditionKind.Reference, null, true, ConditionTreeResolver.Empty, [], x.PolicyCode)
            : new ConditionNode(--id, x.Kind, x.Kind == ConditionKind.Predicate ? x.ConditionTypeCode : null, true,
                new Dictionary<string, string>(x.Parameters, StringComparer.OrdinalIgnoreCase), x.Children.Select(Convert).ToList());
    }
}

/// <summary>
/// Condition satırlarını ağaçlara çevirir; What-If değişikliklerini uygular. Policy referansı (Reference) sadece policy'ye bağlanır:
/// referans verilen policy'nin içeriği değerlendirme anında (güncel / What-If haliyle) değerlendirilir, ağaca kopyalanmaz.
/// </summary>
public sealed class ConditionTreeResolver
{
    public static readonly IReadOnlyDictionary<string, string> Empty = new Dictionary<string, string>();

    private readonly ILookup<(int, int?), ConditionRow> _ruleChildren;
    private readonly Dictionary<int, PolicyRow> _policyById;
    private readonly Dictionary<string, PolicyRow> _policyByCode;
    private readonly Dictionary<int, Dictionary<string, string>> _paramOverrides;
    private int _draftNodeId;

    public ConditionTreeResolver(IEnumerable<ConditionRow> rows, IEnumerable<PolicyRow> policies, PolicyChangeSet? changes)
    {
        _ruleChildren = rows.ToLookup(r => (r.RuleId, r.ParentId));
        _policyById = policies.ToDictionary(p => p.Id);
        _policyByCode = _policyById.Values.ToDictionary(p => p.Code, StringComparer.OrdinalIgnoreCase);
        _paramOverrides = changes?.ConditionOverrides.GroupBy(o => o.ConditionId).ToDictionary(g => g.Key, g => g.Last().Parameters) ?? [];
    }

    public ConditionNode? RuleRoot(int ruleId)
    {
        var root = _ruleChildren[(ruleId, null)].OrderBy(c => c.Order).FirstOrDefault();
        return root is null ? null : Build(root, id => _ruleChildren[(ruleId, id)]);
    }

    public ConditionNode FromDraft(ConditionDraft d)
    {
        var id = --_draftNodeId;
        if (d.Kind == ConditionKind.Reference) return Reference(d.PolicyCode is { } c ? _policyByCode.GetValueOrDefault(c) : null, d.PolicyCode, id);
        return new ConditionNode(id, d.Kind, d.Kind == ConditionKind.Predicate ? d.ConditionTypeCode : null, true,
            new Dictionary<string, string>(d.Parameters, StringComparer.OrdinalIgnoreCase),
            d.Children.Select(FromDraft).ToList());
    }

    private ConditionNode Build(ConditionRow row, Func<int?, IEnumerable<ConditionRow>> childrenOf)
    {
        if (row.Kind == ConditionKind.Reference)
            return Reference(row.RefPolicyId is { } pid ? _policyById.GetValueOrDefault(pid) : null, row.RefPolicyId is { } x ? $"#{x}" : null, row.Id);
        return new ConditionNode(row.Id, row.Kind, row.TypeCode, row.TypeAvailable,
            _paramOverrides.TryGetValue(row.Id, out var o) ? new Dictionary<string, string>(o, StringComparer.OrdinalIgnoreCase) : row.Params,
            childrenOf(row.Id).OrderBy(c => c.Order).ThenBy(c => c.Id).Select(c => Build(c, childrenOf)).ToList());
    }

    private static ConditionNode Reference(PolicyRow? policy, string? fallbackCode, int nodeId) => policy is null
        ? new ConditionNode(nodeId, ConditionKind.Reference, null, true, Empty, [], fallbackCode ?? "?")
        : new ConditionNode(nodeId, ConditionKind.Reference, null, true, Empty, [], policy.Code, policy.Version, policy.Id);
}
