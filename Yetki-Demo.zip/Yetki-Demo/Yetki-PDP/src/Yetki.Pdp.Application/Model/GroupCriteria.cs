using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.Model;

/// <summary>
/// Grup kitle kriteri tanımı. ValueSource: UI'da hangi seçicinin gösterileceği (role, orgUnit, orgUnitType, tenant, user, userKind, text).
/// </summary>
public sealed record GroupCriterionDescriptor(string Code, string Name, string Description, string ValueSource);

/// <summary>
/// Grup kitle kriterinin DAVRANIŞI (C#). DB sadece "Attribute ∈ Değerler" satırlarını tutar.
/// Kriterler STATİK kullanıcı özelliklerine bakar (istek bağlamına değil) → üyelik önceden hesaplanabilir.
/// Yeni kriter = yeni handler + DI kaydı.
/// </summary>
public interface IGroupCriterionHandler
{
    GroupCriterionDescriptor Descriptor { get; }
    bool Matches(AuthorizationModel model, UserRow user, IReadOnlyList<string> values, DateTime now, out string matched);
    /// <summary>Değerlerin modelde var olup olmadığını doğrular (bilinmeyen rol/birim kodu vb.).</summary>
    IReadOnlyList<string> Validate(AuthorizationModel model, IReadOnlyList<string> values);
}

public abstract class SetCriterionHandler : IGroupCriterionHandler
{
    public abstract GroupCriterionDescriptor Descriptor { get; }
    protected abstract IEnumerable<string> ValuesOf(AuthorizationModel model, UserRow user, DateTime now);
    protected virtual IEnumerable<string> KnownValues(AuthorizationModel model) => [];
    protected virtual bool ValidateKnown => true;

    public bool Matches(AuthorizationModel model, UserRow user, IReadOnlyList<string> values, DateTime now, out string matched)
    {
        var hit = ValuesOf(model, user, now).FirstOrDefault(v => values.Contains(v, StringComparer.OrdinalIgnoreCase));
        matched = hit ?? "";
        return hit is not null;
    }

    public IReadOnlyList<string> Validate(AuthorizationModel model, IReadOnlyList<string> values)
    {
        if (values.Count == 0) return [$"{Descriptor.Code}: en az bir değer gerekli."];
        if (!ValidateKnown) return [];
        var known = KnownValues(model).ToHashSet(StringComparer.OrdinalIgnoreCase);
        return values.Where(v => !known.Contains(v)).Select(v => $"{Descriptor.Code}: bilinmeyen değer '{v}'.").ToList();
    }
}

/// <summary>Kullanıcının DOĞRUDAN rolleri (gruptan gelen roller sayılmaz → gruplar arası zincir/döngü oluşmaz).</summary>
public sealed class RoleCriterion : SetCriterionHandler
{
    public override GroupCriterionDescriptor Descriptor { get; } = new("ROLE", "Rol", "Kullanıcının doğrudan atanmış rollerinden biri", "role");
    protected override IEnumerable<string> ValuesOf(AuthorizationModel m, UserRow u, DateTime now) => m.DirectRoleCodes(u.Id, now);
    protected override IEnumerable<string> KnownValues(AuthorizationModel m) => m.Roles.Values.Select(r => r.Code);
}

public sealed class OrgUnitCriterion : SetCriterionHandler
{
    public override GroupCriterionDescriptor Descriptor { get; } = new("ORG_UNIT", "Birim", "Kullanıcının bağlı olduğu birim (tam eşleşme)", "orgUnit");
    protected override IEnumerable<string> ValuesOf(AuthorizationModel m, UserRow u, DateTime now) => m.UnitCodesOf(u.Id);
    protected override IEnumerable<string> KnownValues(AuthorizationModel m) => m.Units.Values.Select(x => x.Code);
}

/// <summary>Kullanıcının birimi verilen birimin kendisi veya altında mı? (ör. BLG_IST → bölgedeki tüm şubeler)</summary>
public sealed class OrgUnitTreeCriterion : SetCriterionHandler
{
    public override GroupCriterionDescriptor Descriptor { get; } = new("ORG_UNIT_TREE", "Birim (alt birimler dahil)", "Kullanıcının birimi verilen birim veya onun alt birimi", "orgUnit");
    protected override IEnumerable<string> ValuesOf(AuthorizationModel m, UserRow u, DateTime now) => m.UnitAncestryOf(u.Id);
    protected override IEnumerable<string> KnownValues(AuthorizationModel m) => m.Units.Values.Select(x => x.Code);
}

public sealed class OrgUnitTypeCriterion : SetCriterionHandler
{
    public override GroupCriterionDescriptor Descriptor { get; } = new("ORG_UNIT_TYPE", "Birim tipi", "Kullanıcının biriminin tipi (Branch, Department, Region, HeadOffice)", "orgUnitType");
    protected override IEnumerable<string> ValuesOf(AuthorizationModel m, UserRow u, DateTime now) => m.UnitsOf(u.Id).Select(x => x.Type.ToString());
    protected override IEnumerable<string> KnownValues(AuthorizationModel m) => Enum.GetNames<OrgUnitType>();
}

public sealed class TitleCriterion : SetCriterionHandler
{
    public override GroupCriterionDescriptor Descriptor { get; } = new("TITLE", "Unvan", "Kullanıcının unvanı (tam eşleşme, büyük/küçük harf duyarsız)", "text");
    protected override IEnumerable<string> ValuesOf(AuthorizationModel m, UserRow u, DateTime now) => u.Title is null ? [] : [u.Title];
    protected override bool ValidateKnown => false;
}

/// <summary>Kullanıcının kurumu veya üst kurumları (A Bankası verilirse B İştiraki kullanıcıları da eşleşir).</summary>
public sealed class TenantCriterion : SetCriterionHandler
{
    public override GroupCriterionDescriptor Descriptor { get; } = new("TENANT", "Kurum (alt tenant dahil)", "Kullanıcı bu kurumda veya onun alt kurumunda", "tenant");
    protected override IEnumerable<string> ValuesOf(AuthorizationModel m, UserRow u, DateTime now) => m.TenantAncestors[u.TenantId].Select(id => m.Tenants[id].Code);
    protected override IEnumerable<string> KnownValues(AuthorizationModel m) => m.Tenants.Values.Select(o => o.Code);
}

public sealed class UserCriterion : SetCriterionHandler
{
    public override GroupCriterionDescriptor Descriptor { get; } = new("USER", "Kullanıcı", "Belirli kullanıcılar (genelde Exclude filtresinde istisna için)", "user");
    protected override IEnumerable<string> ValuesOf(AuthorizationModel m, UserRow u, DateTime now) => [u.UserName];
    protected override IEnumerable<string> KnownValues(AuthorizationModel m) => m.Users.Values.Select(x => x.UserName);
}

public sealed class UserKindCriterion : SetCriterionHandler
{
    public override GroupCriterionDescriptor Descriptor { get; } = new("USER_KIND", "Kimlik türü", "Person veya ServiceAccount", "userKind");
    protected override IEnumerable<string> ValuesOf(AuthorizationModel m, UserRow u, DateTime now) => [u.Kind.ToString()];
    protected override IEnumerable<string> KnownValues(AuthorizationModel m) => Enum.GetNames<UserKind>();
}

public sealed class GroupCriterionRegistry
{
    private readonly Dictionary<string, IGroupCriterionHandler> _handlers = new(StringComparer.OrdinalIgnoreCase);

    public GroupCriterionRegistry(IEnumerable<IGroupCriterionHandler> handlers)
    {
        foreach (var h in handlers)
            if (!_handlers.TryAdd(h.Descriptor.Code, h))
                throw new InvalidOperationException($"Grup kriteri birden fazla tanımlı: {h.Descriptor.Code}");
    }

    public IGroupCriterionHandler? Find(string code) => _handlers.GetValueOrDefault(code);

    public IReadOnlyCollection<IGroupCriterionHandler> All => _handlers.Values;
}
