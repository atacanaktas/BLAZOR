using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.Model;

// ============================================================================================
//  Uygulanmamış değişiklikler. What-If ve gerçek atama akışı AYNI change set'i ve AYNI modeli kullanır:
//  mevcut model verisi kopyalanır, değişiklik bellekte uygulanır, yeni model kurulur, önce/sonra karşılaştırılır.
//  Böylece simülasyon ile gerçek sonuç arasında semantik fark oluşamaz.
// ============================================================================================

public sealed record UserRoleChange(int UserId, int RoleId, bool Add, DateTime? ValidUntil = null);
public sealed record UserUnitChange(int UserId, int OrgUnitId, bool Add);
public sealed record GroupMemberChange(int GroupId, int UserId, bool Add, DateTime? ValidUntil = null);
public sealed record GroupRoleChange(int GroupId, int RoleId, bool Add);
public sealed record ActivationChange(int Id, bool IsActive);
/// <summary>Kullanıcı özelliği değişikliği (unvan grup kriterini, izin/limit policy'leri etkiler). Null = değişmez.</summary>
public sealed record UserUpdate(int UserId, string? Title = null, bool? IsActive = null, bool? IsOnLeave = null, decimal? CashWithdrawalLimit = null);
/// <summary>Rol ayarı değişikliği (pasifleştirme, miras alınabilirlik). Null = değişmez.</summary>
public sealed record RoleUpdate(int RoleId, bool? IsActive = null, bool? IsInheritable = null);

public sealed class GroupCriterionDraft
{
    public string Attribute { get; set; } = default!;
    public List<string> Values { get; set; } = new();
}

public sealed class GroupFilterDraft
{
    public InclusionMode Mode { get; set; } = InclusionMode.Include;
    public string? Description { get; set; }
    public List<GroupCriterionDraft> Criteria { get; set; } = new();
}

/// <summary>Bir grubun kitle kurallarının tamamen yenisiyle değiştirilmesi.</summary>
public sealed record GroupFiltersReplacement(int GroupId, List<GroupFilterDraft> Filters);

/// <summary>Kimlik tarafı (kullanıcı / rol ataması / grup) değişiklikleri.</summary>
public sealed class AuthorizationChangeSet
{
    public List<UserRoleChange> UserRoles { get; set; } = new();
    public List<UserUnitChange> UserUnits { get; set; } = new();
    public List<GroupMemberChange> GroupMembers { get; set; } = new();
    public List<GroupRoleChange> GroupRoles { get; set; } = new();
    public List<GroupFiltersReplacement> GroupFilters { get; set; } = new();
    public List<ActivationChange> GroupActivations { get; set; } = new();
    public List<RoleUpdate> RoleUpdates { get; set; } = new();
    public List<UserUpdate> UserUpdates { get; set; } = new();

    public bool IsEmpty =>
        UserRoles.Count + UserUnits.Count + GroupMembers.Count + GroupRoles.Count + GroupFilters.Count
        + GroupActivations.Count + RoleUpdates.Count + UserUpdates.Count == 0;
}

// ------------------------------ Condition (ABAC) What-If ------------------------------

public sealed record PolicyActivationChange(int PolicyId, bool IsActive);
public sealed record PolicyModeChange(int PolicyId, PolicyMode Mode);
public sealed record PolicyStrategyChange(int PolicyId, DecisionStrategy Strategy);

public sealed record RuleOverride(int RuleId, bool? IsActive = null, int? Order = null);

/// <summary>Bir predicate düğümünün parametrelerini değiştirir (ör. mesai bitişi 18:00 → 17:00).</summary>
public sealed record ConditionParameterOverride(int ConditionId, Dictionary<string, string> Parameters);

/// <summary>Condition ifade ağacı taslağı (yönetim API'si ve What-If). Predicate / AllOf / AnyOf / Not / Reference (PolicyCode: koşul olarak kullanılan policy).</summary>
public sealed class ConditionDraft
{
    public ConditionKind Kind { get; set; } = ConditionKind.Predicate;
    public string? ConditionTypeCode { get; set; }
    public string? PolicyCode { get; set; }
    public Dictionary<string, string> Parameters { get; set; } = new();
    public List<ConditionDraft> Children { get; set; } = new();
}

public sealed class RuleDraft
{
    public int PolicyId { get; set; }
    public string Code { get; set; } = "DRAFT_RULE";
    public string? Name { get; set; }
    public int Order { get; set; } = 50;
    public string? ReasonCode { get; set; }
    public bool IsActive { get; set; } = true;
    public ConditionDraft Condition { get; set; } = new();
}

public sealed record RuleReplacement(int RuleId, RuleDraft Rule);

/// <summary>Policy tarafı What-If: aktiflik, mod, strateji, kural ve koşul değişiklikleri (kaydedilmez).</summary>
public sealed class PolicyChangeSet
{
    public List<PolicyActivationChange> PolicyActivations { get; set; } = new();
    public List<PolicyModeChange> PolicyModes { get; set; } = new();
    public List<PolicyStrategyChange> PolicyStrategies { get; set; } = new();
    public List<RuleOverride> RuleOverrides { get; set; } = new();
    public List<ConditionParameterOverride> ConditionOverrides { get; set; } = new();
    public List<RuleDraft> AddedRules { get; set; } = new();
    public List<int> RemovedRuleIds { get; set; } = new();
    public List<RuleReplacement> ReplacedRules { get; set; } = new();

    public bool IsEmpty =>
        PolicyActivations.Count + PolicyModes.Count + PolicyStrategies.Count
        + RuleOverrides.Count + ConditionOverrides.Count + AddedRules.Count + RemovedRuleIds.Count + ReplacedRules.Count == 0;
}
