using System.Collections;
using System.Reflection;
using System.Text.Json;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Common;

namespace Yetki.Pdp.Application.Model;

public enum PatchOp { Add, Replace, Remove }

/// <summary>
/// Kaydedilmemiş TANIM değişikliğinin (permission, policy üyesi, resource, URI...) HTTP üzerinden taşınabilir hâli:
/// ModelData tablolarına satır düzeyinde işlem. PAP taslağı bu listeye çevirir, PDP güncel verinin kopyasına uygular ve
/// AYNI Build ile What-If modeli kurar.
///   Table: ModelData liste adı (ör. "Permissions", "PermissionResources", "PolicyMembers", "Uris").
///   Add: Row eklenir. Remove: Match'teki alanların hepsi eşit olan satırlar silinir. Replace: Match'lenen satırlar silinir, Row eklenir.
///   Row: satır kaydının JSON'u (alan adları ModelData kayıtlarındaki gibi, ör. PermissionRow).
/// Yeni (henüz id'si olmayan) kayıtlar için negatif geçici id kullanılır (ör. Id = -1 ve ilişkilerde -1).
/// </summary>
public sealed class ModelPatchOperation
{
    public string Table { get; set; } = default!;
    public PatchOp Op { get; set; }
    public Dictionary<string, JsonElement>? Match { get; set; }
    public JsonElement? Row { get; set; }
}

public static class ModelPatch
{
    private static readonly Dictionary<string, PropertyInfo> Tables = typeof(ModelData).GetProperties()
        .Where(p => p.PropertyType.IsGenericType && p.PropertyType.GetGenericTypeDefinition() == typeof(List<>))
        .ToDictionary(p => p.Name, StringComparer.OrdinalIgnoreCase);

    public static IReadOnlyCollection<string> TableNames => Tables.Keys;

    /// <summary>İşlemleri sırayla verilen veri kopyasına uygular. Geçersiz tablo / alan / satır → ValidationException.</summary>
    public static ModelData Apply(this ModelData data, IReadOnlyList<ModelPatchOperation>? ops)
    {
        if (ops is null) return data;
        for (var i = 0; i < ops.Count; i++)
        {
            var op = ops[i];
            if (!Tables.TryGetValue(op.Table ?? "", out var prop))
                throw new ValidationException($"Patch #{i}: bilinmeyen tablo '{op.Table}'. Geçerli: {string.Join(", ", Tables.Keys)}");
            var list = (IList)prop.GetValue(data)!;
            var rowType = prop.PropertyType.GetGenericArguments()[0];

            if (op.Op is PatchOp.Remove or PatchOp.Replace)
            {
                if (op.Match is not { Count: > 0 }) throw new ValidationException($"Patch #{i}: {op.Op} için Match zorunlu.");
                var match = op.Match.Select(kv =>
                {
                    var f = rowType.GetProperty(kv.Key, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase)
                            ?? throw new ValidationException($"Patch #{i}: {op.Table} için bilinmeyen alan '{kv.Key}'.");
                    return (Field: f, Value: Convert(kv.Value, f.PropertyType, i));
                }).ToList();
                for (var j = list.Count - 1; j >= 0; j--)
                    if (match.All(m => Equals(m.Field.GetValue(list[j]), m.Value))) list.RemoveAt(j);
            }

            if (op.Op is PatchOp.Add or PatchOp.Replace)
            {
                if (op.Row is not { ValueKind: JsonValueKind.Object } row) throw new ValidationException($"Patch #{i}: {op.Op} için Row zorunlu.");
                list.Add(Convert(row, rowType, i) ?? throw new ValidationException($"Patch #{i}: Row boş."));
            }
        }
        return data;
    }

    private static object? Convert(JsonElement value, Type type, int index)
    {
        try { return value.Deserialize(type, JsonDefaults.Options); }
        catch (Exception ex) when (ex is JsonException or NotSupportedException or ArgumentException)
        {
            throw new ValidationException($"Patch #{index}: değer {type.Name} tipine çevrilemedi: {ex.Message}");
        }
    }
}
