using System.Collections.Concurrent;
using Yetki.Pdp.Application.PolicyEngine;
using Yetki.Pdp.Application.PolicyEngine.Conditions;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.Model;

/// <summary>
/// Yetki = resource + scope (anka.vadelihesap:close). Path: türetilmiş konum (gruplama) —
/// HTTP resource'unda uygulama + URI'lerin ortak öneki (ANKA /v1/vadeli-hesap), UI resource'unda üst zinciri (NEXTRAL / Gişe menüsü).
/// </summary>
public sealed record ResourceScopeInfo(ResourceScopeRow Row, ResourceRow Resource, ScopeRow Scope, AppRow App, ResourceTypeRow Type, string Path)
{
    public int Id => Row.Id;
    public string Key => $"{Resource.Code}:{Scope.Code}";
    public string Name => $"{Resource.Name} · {Scope.Name}";
    public int TenantId => App.TenantId;
    public bool IsActive => Resource.IsActive && App.IsActive && Type.IsActive;
}

/// <summary>HTTP isteğinin eşlendiği URI kaydı ve yetki.</summary>
public sealed record HttpMatch(ResourceScopeInfo Access, UriRow Uri);

/// <summary>Statik (bağlamsız) policy sonucu: Permit / Deny / Indeterminate (= çalışma anı koşuluna bağlı) / NotApplicable.</summary>
public sealed record StaticPolicyResult(DecisionType Result, IReadOnlyList<(CompiledPolicy Policy, string Text)> Matches, IReadOnlyList<string> Conditions);

/// <summary>
/// BELLEK İÇİ YETKİ MODELİ (değişmez anlık görüntü). Kararlar, etkin erişim hesabı, grup üyeliği ve What-If bu model üzerinden yapılır.
/// Gerçek model veritabanı versiyonuyla önbelleklenir; What-If modeli, verinin değiştirilmiş kopyasından AYNI Build ile kurulur.
///
/// Ölçek notu: Prototip hacminde tüm model bellekte tutulur. 20K+ kullanıcıda kullanıcıya özgü dilimler ayrı yüklenmelidir (TODO).
/// </summary>
public sealed class AuthorizationModel
{
    public const int MaxPolicyDepth = 8;

    public long Version { get; }
    public bool IsSimulation { get; }
    public DateTime BuiltAt { get; }
    public ModelData Data { get; }
    public GroupCriterionRegistry Criteria { get; }

    public IReadOnlyDictionary<int, TenantRow> Tenants { get; }
    public IReadOnlyDictionary<string, TenantRow> TenantByCode { get; }
    /// <summary>Kurum → kendisi + üstleri (kendisi ilk).</summary>
    public IReadOnlyDictionary<int, IReadOnlyList<int>> TenantAncestors { get; }
    public IReadOnlyDictionary<int, UnitRow> Units { get; }
    public IReadOnlyDictionary<int, UserRow> Users { get; }
    public IReadOnlyDictionary<string, int> UserIdByName { get; }
    public IReadOnlyDictionary<int, AppRow> Apps { get; }
    public IReadOnlyDictionary<string, AppRow> AppByCode { get; }
    public IReadOnlyDictionary<int, ResourceTypeRow> ResourceTypes { get; }
    public IReadOnlyDictionary<int, ResourceRow> Resources { get; }
    public IReadOnlyDictionary<string, ResourceRow> ResourceByCode { get; }
    public IReadOnlyDictionary<int, ScopeRow> Scopes { get; }
    public IReadOnlyDictionary<int, ResourceScopeInfo> ResourceScopes { get; }
    public IReadOnlyDictionary<string, int> ResourceScopeIdByKey { get; }
    public IReadOnlyDictionary<string, ClientRow> ClientsById { get; }
    public IReadOnlyDictionary<int, ClientRow> ClientsByPk { get; }
    public IReadOnlyDictionary<int, ClientScopeRow> ClientScopes { get; }
    public IReadOnlyDictionary<int, RoleRow> Roles { get; }
    public IReadOnlyDictionary<string, int> RoleIdByCode { get; }
    public IReadOnlyDictionary<int, GroupRow> Groups { get; }
    public IReadOnlyDictionary<int, CompiledPolicy> Policies { get; }
    public IReadOnlyDictionary<int, CompiledPermission> Permissions { get; }

    private readonly ILookup<int, UserUnitRow> _userUnits;
    private readonly ILookup<int?, UnitRow> _unitChildren;
    private readonly ILookup<int, UserRoleRow> _userRoles;
    private readonly ILookup<int, GroupMemberRow> _groupMembers;
    private readonly ILookup<int, GroupFilterRow> _groupFilters;
    private readonly ILookup<int, int> _groupRoles;
    private readonly ILookup<int, UriRow> _urisByResource;
    private readonly ILookup<int, ResourceScopeInfo> _scopesByResource;

    private readonly ConcurrentDictionary<int, IReadOnlyList<CompiledPermission>> _permissionsFor = new();
    private readonly ConcurrentDictionary<(int UserId, long Minute), IdentityState> _identity = new();
    private readonly ConcurrentDictionary<(int UserId, long Minute), EffectiveAccessSet> _effective = new();

    /// <summary>Koşul tipleri: kimlik koşullarının istek olmadan (statik) çözümü için. Boşsa koşul policy'leri statik hesapta "koşullu" sayılır.</summary>
    private readonly ConditionHandlerRegistry? _conditions;
    private readonly System.Runtime.CompilerServices.ConditionalWeakTable<IdentityState, IdentityFacts> _facts = new();

    private AuthorizationModel(ModelData data, IReadOnlyList<CompiledPolicy> policies, IReadOnlyList<CompiledPermission> permissions,
        GroupCriterionRegistry criteria, ConditionHandlerRegistry? conditions, long version, bool isSimulation, DateTime builtAt)
    {
        Data = data;
        Criteria = criteria;
        _conditions = conditions;
        Version = version;
        IsSimulation = isSimulation;
        BuiltAt = builtAt;

        Tenants = data.Tenants.ToDictionary(o => o.Id);
        TenantByCode = data.Tenants.ToDictionary(o => o.Code, StringComparer.OrdinalIgnoreCase);
        TenantAncestors = data.Tenants.ToDictionary(o => o.Id, o => (IReadOnlyList<int>)Chain(o.Id, id => Tenants.GetValueOrDefault(id)?.ParentId));
        Units = data.Units.ToDictionary(u => u.Id);
        _unitChildren = data.Units.ToLookup(u => u.ParentId);
        Users = data.Users.ToDictionary(u => u.Id);
        UserIdByName = data.Users.ToDictionary(u => u.UserName, u => u.Id, StringComparer.OrdinalIgnoreCase);
        _userUnits = data.UserUnits.ToLookup(x => x.UserId);

        Apps = data.Applications.ToDictionary(a => a.Id);
        AppByCode = data.Applications.ToDictionary(a => a.Code, StringComparer.OrdinalIgnoreCase);
        ResourceTypes = data.ResourceTypes.ToDictionary(t => t.Id);
        Resources = data.Resources.Where(r => Apps.ContainsKey(r.ApplicationId) && ResourceTypes.ContainsKey(r.ResourceTypeId)).ToDictionary(r => r.Id);
        ResourceByCode = Resources.Values.ToDictionary(r => r.Code, StringComparer.OrdinalIgnoreCase);
        Scopes = data.Scopes.ToDictionary(s => s.Id);
        _urisByResource = data.Uris.ToLookup(u => u.ResourceId);
        var paths = Resources.Values.ToDictionary(r => r.Id, r => ComputePath(r));
        ResourceScopes = data.ResourceScopes
            .Where(rs => Resources.ContainsKey(rs.ResourceId) && Scopes.ContainsKey(rs.ScopeId))
            .ToDictionary(rs => rs.Id, rs =>
            {
                var r = Resources[rs.ResourceId];
                return new ResourceScopeInfo(rs, r, Scopes[rs.ScopeId], Apps[r.ApplicationId], ResourceTypes[r.ResourceTypeId], paths[r.Id]);
            });
        ResourceScopeIdByKey = ResourceScopes.Values.ToDictionary(x => x.Key, x => x.Id, StringComparer.OrdinalIgnoreCase);
        _scopesByResource = ResourceScopes.Values.ToLookup(x => x.Resource.Id);

        ClientsById = data.Clients.ToDictionary(c => c.ClientId, StringComparer.OrdinalIgnoreCase);
        ClientsByPk = data.Clients.ToDictionary(c => c.Id);
        ClientScopes = data.ClientScopes.ToDictionary(c => c.ClientId);
        Roles = data.Roles.ToDictionary(r => r.Id);
        RoleIdByCode = data.Roles.ToDictionary(r => r.Code, r => r.Id, StringComparer.OrdinalIgnoreCase);
        _userRoles = data.UserRoles.ToLookup(x => x.UserId);
        Groups = data.Groups.ToDictionary(g => g.Id);
        _groupMembers = data.GroupMembers.ToLookup(x => x.GroupId);
        _groupFilters = data.GroupFilters.ToLookup(x => x.GroupId);
        _groupRoles = data.GroupRoles.ToLookup(x => x.GroupId, x => x.RoleId);

        Policies = policies.ToDictionary(p => p.Row.Id);
        Permissions = permissions.ToDictionary(p => p.Row.Id);
    }

    // ================================ Türetilmiş konum (gruplama) ================================

    /// <summary>Resource'un türetilmiş konumu: HTTP'de "APP /url/öneki", UI'da "APP / üst / üst", diğerlerinde uygulama kodu.</summary>
    public string PathOf(int resourceId) => Resources.TryGetValue(resourceId, out var r) ? ComputePath(r) : "";

    private string ComputePath(ResourceRow r)
    {
        var app = Apps[r.ApplicationId].Code;
        if (ResourceTypes[r.ResourceTypeId].MatchesHttp)
        {
            var prefix = UrlGroup(_urisByResource[r.Id].Select(u => u.Pattern));
            return prefix.Length > 0 ? $"{app} {prefix}" : app;
        }
        var chain = new List<string>();
        var seen = new HashSet<int>();
        for (var p = r.ParentId; p is { } id && seen.Add(id) && Resources.TryGetValue(id, out var parent); p = parent.ParentId) chain.Add(parent.Name);
        chain.Reverse();
        return chain.Count > 0 ? $"{app} / {string.Join(" / ", chain)}" : app;
    }

    /// <summary>
    /// URI desenlerinin gruplama öneki: ortak literal segmentler, ilk parametre / joker segmentte durur.
    /// (/v1/vadeli-hesap, /v1/vadeli-hesap/{hesapNo}/kapat → /v1/vadeli-hesap)
    /// </summary>
    public static string UrlGroup(IEnumerable<string> patterns)
    {
        List<string>? common = null;
        foreach (var pattern in patterns)
        {
            var literal = pattern.Split('/', StringSplitOptions.RemoveEmptyEntries)
                .TakeWhile(s => !(s.StartsWith('{') || s == "*" || s == "**")).ToList();
            if (common is null) { common = literal; continue; }
            var n = 0;
            while (n < common.Count && n < literal.Count && string.Equals(common[n], literal[n], StringComparison.OrdinalIgnoreCase)) n++;
            common = common.Take(n).ToList();
        }
        return common is { Count: > 0 } ? "/" + string.Join('/', common) : "";
    }

    /// <summary>Modeli kurar. policyChanges: kaydedilmemiş condition/policy değişiklikleri (What-If).</summary>
    public static AuthorizationModel Build(ModelData data, PolicyChangeSet? policyChanges, GroupCriterionRegistry criteria,
        long version, bool isSimulation, DateTime now, ConditionHandlerRegistry? conditions = null) =>
        new(data, PolicyCompiler.Compile(data, policyChanges), PolicyCompiler.CompilePermissions(data), criteria, conditions, version, isSimulation, now);

    private static List<int> Chain(int start, Func<int, int?> parentOf)
    {
        var list = new List<int>();
        int? current = start;
        while (current is { } c && !list.Contains(c))
        {
            list.Add(c);
            current = parentOf(c);
        }
        return list;
    }

    // ================================ Kurum / birim ================================

    public IEnumerable<UnitRow> UnitsOf(int userId) =>
        _userUnits[userId].OrderByDescending(x => x.IsPrimary).Select(x => Units.GetValueOrDefault(x.OrgUnitId)).OfType<UnitRow>();

    public IEnumerable<string> UnitCodesOf(int userId) => UnitsOf(userId).Select(u => u.Code);

    /// <summary>Kullanıcının birimleri + tüm alt birimleri (veri kapsamı).</summary>
    public IEnumerable<string> UnitScopeOf(int userId) =>
        UnitsOf(userId).SelectMany(u => Descendants(u.Id)).Select(id => Units[id].Code).Distinct();

    /// <summary>Kullanıcının birimleri + tüm üst birimleri.</summary>
    public IEnumerable<string> UnitAncestryOf(int userId) =>
        UnitsOf(userId).SelectMany(u => Chain(u.Id, id => Units.GetValueOrDefault(id)?.ParentId)).Select(id => Units[id].Code).Distinct();

    public IEnumerable<int> Descendants(int unitId)
    {
        var stack = new Stack<int>([unitId]);
        var seen = new HashSet<int>();
        while (stack.Count > 0)
        {
            var id = stack.Pop();
            if (!seen.Add(id)) continue;
            yield return id;
            foreach (var c in _unitChildren[id]) stack.Push(c.Id);
        }
    }

    public string TenantCode(int tenantId) => Tenants.TryGetValue(tenantId, out var o) ? o.Code : $"#{tenantId}";

    /// <summary>
    /// Tenant miras kuralı: ownerTenantId'ye ait tanım (uygulama, client, rol) tenantId'de kullanılabilir mi?
    /// Aynı tenant veya owner, tenantId'nin üst tenant'ı ise evet.
    /// </summary>
    public bool IsAvailableIn(int ownerTenantId, int tenantId) =>
        TenantAncestors.TryGetValue(tenantId, out var chain) && chain.Contains(ownerTenantId);

    /// <summary>Rol bu kullanıcıya uygulanabilir mi? (aynı kurum veya üst kurumun miras alınabilir rolü)</summary>
    public bool RoleAppliesTo(RoleRow role, UserRow user) =>
        role.TenantId == user.TenantId || (role.IsInheritable && TenantAncestors[user.TenantId].Contains(role.TenantId));

    private static bool Valid(DateTime? from, DateTime? until, DateTime now) => (from is null || from <= now) && (until is null || until > now);

    public IEnumerable<UserRoleRow> UserRoleAssignments(int userId) => _userRoles[userId];

    public IEnumerable<string> DirectRoleCodes(int userId, DateTime now) =>
        _userRoles[userId].Where(r => Valid(r.ValidFrom, r.ValidUntil, now))
            .Select(r => Roles.GetValueOrDefault(r.RoleId)).OfType<RoleRow>().Where(r => r.IsActive).Select(r => r.Code);

    public IEnumerable<GroupMemberRow> GroupMemberRows(int groupId) => _groupMembers[groupId];
    public IEnumerable<GroupFilterRow> GroupFilterRows(int groupId) => _groupFilters[groupId].OrderBy(f => f.Order);
    public IEnumerable<int> GroupRoleIds(int groupId) => _groupRoles[groupId];
    // ================================ Soran (caller) kapsamı ================================

    /// <summary>Client'ın soru kapsamı (tanımlı değilse boş: hiçbir şey sorulamaz).</summary>
    public ClientScopeRow ScopeOf(ClientRow client) => ClientScopes.GetValueOrDefault(client.Id) ?? new ClientScopeRow(client.Id, [], [], [], null);

    /// <summary>Soran bu uygulama hakkında soru sorabilir mi?</summary>
    public bool CallerMayAskApplication(ClientRow caller, int applicationId) => ScopeOf(caller).Applications.Contains(applicationId);

    /// <summary>Soran bu kurumun kullanıcıları için soru sorabilir mi? (kapsamdaki kurum veya onun alt kurumu)</summary>
    public bool CallerMayAskTenant(ClientRow caller, int tenantId) => ScopeOf(caller).Tenants.Any(t => IsAvailableIn(t, tenantId));

    /// <summary>Soran (aracı) bu client adına konuşabilir mi?</summary>
    public bool CallerMaySpeakFor(ClientRow caller, ClientRow client) =>
        caller.Type == ClientType.Intermediary && ScopeOf(caller).OnBehalfOf.Contains(client.Id);

    public string ClientCodeOf(int clientPk) => ClientsByPk.TryGetValue(clientPk, out var c) ? c.ClientId : $"#{clientPk}";

    // ================================ Katalog ================================

    public IEnumerable<ResourceScopeInfo> ScopesOf(int resourceId) => _scopesByResource[resourceId];
    public IEnumerable<UriRow> UrisOf(int resourceId) => _urisByResource[resourceId];

    /// <summary>resource kodu + scope kodu → yetki (büyük/küçük harf duyarsız).</summary>
    public ResourceScopeInfo? FindResourceScope(string resourceCode, string scopeCode) =>
        ResourceScopeIdByKey.TryGetValue($"{resourceCode.Trim()}:{scopeCode.Trim()}", out var id) ? ResourceScopes[id] : null;

    public ResourceScopeInfo? FindByKey(string key) => ResourceScopeIdByKey.TryGetValue(key.Trim(), out var id) ? ResourceScopes[id] : null;

    /// <summary>
    /// HTTP isteğini (METHOD + path) kayıtlı URI desenlerine eşler. Sadece HTTP tipindeki, aktif ve tenant'ta kullanılabilir
    /// uygulamaların resource'ları aday olur. En özel desen kazanır (daha çok sabit segment, daha az joker, METHOD tam eşleşme);
    /// aynı özgüllükte farklı yetkiye eşlenen iki desen belirsizliktir (Ambiguous döner, karar reddeder).
    /// </summary>
    public (HttpMatch? Match, IReadOnlyList<HttpMatch> Ambiguous) MatchHttp(string? application, string method, string path, int tenantId)
    {
        var segments = Split(path);
        var m = method.Trim().ToUpperInvariant();
        var candidates = new List<(HttpMatch Match, (int Literals, int Tail, int Wild, int Method) Score)>();
        foreach (var r in Resources.Values)
        {
            var app = Apps[r.ApplicationId];
            if (application is not null && !string.Equals(app.Code, application, StringComparison.OrdinalIgnoreCase)) continue;
            if (!ResourceTypes[r.ResourceTypeId].MatchesHttp || !IsAvailableIn(app.TenantId, tenantId)) continue;
            foreach (var u in _urisByResource[r.Id])
            {
                if (u.Method != "*" && !string.Equals(u.Method, m, StringComparison.OrdinalIgnoreCase)) continue;
                if (!TryMatch(Split(u.Pattern), segments, out var score)) continue;
                var rs = _scopesByResource[r.Id].FirstOrDefault(x => x.Scope.Id == u.ScopeId);
                if (rs is null) continue;
                candidates.Add((new HttpMatch(rs, u), (score.Literals, score.Tail, score.Wild, u.Method == "*" ? 1 : 0)));
            }
        }
        if (candidates.Count == 0) return (null, []);
        var ordered = candidates.OrderByDescending(c => c.Score.Literals).ThenBy(c => c.Score.Tail).ThenBy(c => c.Score.Wild).ThenBy(c => c.Score.Method).ToList();
        var best = ordered[0];
        var ties = ordered.Where(c => c.Score == best.Score && c.Match.Access.Id != best.Match.Access.Id).Select(c => c.Match).ToList();
        return ties.Count > 0 ? (null, [best.Match, .. ties]) : (best.Match, []);

        static string[] Split(string p) => p.Split('?')[0].Split('/', StringSplitOptions.RemoveEmptyEntries);
    }

    /// <summary>Desen eşleştirme: {x} ve * tek segment, sonda ** kalan tüm segmentler; sabit segment büyük/küçük harf duyarsız.</summary>
    public static bool TryMatch(IReadOnlyList<string> pattern, IReadOnlyList<string> path, out (int Literals, int Tail, int Wild) score)
    {
        score = default;
        var literals = 0;
        var wild = 0;
        for (var i = 0; i < pattern.Count; i++)
        {
            var p = pattern[i];
            if (p == "**" && i == pattern.Count - 1)
            {
                score = (literals, 1, wild);
                return path.Count >= i;
            }
            if (i >= path.Count) return false;
            if (p == "*" || (p.StartsWith('{') && p.EndsWith('}'))) wild++;
            else if (string.Equals(p, path[i], StringComparison.OrdinalIgnoreCase)) literals++;
            else return false;
        }
        if (pattern.Count != path.Count) return false;
        score = (literals, 0, wild);
        return true;
    }

    // ================================ Permission kapsamı ================================

    /// <summary>Bu yetkiye (resource:scope) uygulanan aktif permission'lar.</summary>
    public IReadOnlyList<CompiledPermission> PermissionsFor(int resourceScopeId) =>
        _permissionsFor.GetOrAdd(resourceScopeId, id => ResourceScopes.TryGetValue(id, out var rs)
            ? Permissions.Values.Where(p => p.Row.IsActive && p.Applies(rs)).OrderBy(p => p.Row.Code, StringComparer.Ordinal).ToList()
            : []);

    /// <summary>Permission'ın kapsadığı yetkiler.</summary>
    public IEnumerable<ResourceScopeInfo> CoverageOf(CompiledPermission p) =>
        ResourceScopes.Values.Where(p.Applies).OrderBy(x => x.Key, StringComparer.Ordinal);

    /// <summary>Policy'yi doğrudan veya kural içi policy referansı (zincirleme) üzerinden kullanan permission'lar.</summary>
    public IEnumerable<CompiledPermission> PermissionsUsingPolicy(int policyId)
    {
        var holders = PoliciesUsing(policyId);
        return Permissions.Values.Where(p => p.PolicyIds.Any(holders.Contains)).OrderBy(p => p.Row.Code, StringComparer.Ordinal);
    }

    /// <summary>Policy'nin kendisi + onu kural içi referans olarak (zincirleme) kullanan policy'ler.</summary>
    public HashSet<int> PoliciesUsing(int policyId)
    {
        var holders = new HashSet<int> { policyId };
        var changed = true;
        while (changed)
        {
            changed = false;
            foreach (var p in Policies.Values.Where(p => !holders.Contains(p.Row.Id)))
                if (ReferencedPolicyIds(p).Any(holders.Contains))
                {
                    holders.Add(p.Row.Id);
                    changed = true;
                }
        }
        return holders;
    }

    /// <summary>Policy'nin kurallarında referans verilen policy'ler.</summary>
    public static IEnumerable<int> ReferencedPolicyIds(CompiledPolicy p, bool activeRulesOnly = false) =>
        p.Definition.Rules.Where(r => !activeRulesOnly || r.IsActive).SelectMany(r => PolicyEvaluator.Flatten(r.Condition))
            .Where(n => n.Kind == ConditionKind.Reference && n.ReferencePolicyId is not null).Select(n => n.ReferencePolicyId!.Value).Distinct();

    /// <summary>
    /// Kurallarında bu değeri (rol kodu, grup kodu, kullanıcı adı, client...) koşul parametresi olarak geçen policy'ler ve kuralları.
    /// ör. ("SUBJECT_HAS_ROLE", "Roles", "GISEAST") → GISEAST'i KİM kartında kullanan policy'ler.
    /// </summary>
    public IEnumerable<(CompiledPolicy Policy, RuleDefinition Rule)> PoliciesMentioning(string conditionType, string param, string value) =>
        Policies.Values.OrderBy(p => p.Row.Code, StringComparer.Ordinal).SelectMany(p => p.Definition.Rules
            .Where(r => PolicyEvaluator.Flatten(r.Condition).Any(n => n.Kind == ConditionKind.Predicate
                && string.Equals(n.ConditionTypeCode, conditionType, StringComparison.OrdinalIgnoreCase)
                && n.Parameters.TryGetValue(param, out var v) && Common.Codes.SplitList(v).Contains(value, StringComparer.OrdinalIgnoreCase)))
            .Select(r => (p, r)));

    /// <summary>Permission'da kimlik şartı (KİM kartı: rol / grup / birim / kullanıcı...) var mı? Yoksa koşulu sağlayan herkes erişir.</summary>
    public bool HasIdentityPolicy(CompiledPermission p) => p.PolicyIds.Any(id => IsIdentityPolicy(id, 0));

    private bool IsIdentityPolicy(int policyId, int depth, bool asReference = false) =>
        depth <= MaxPolicyDepth && Policies.TryGetValue(policyId, out var p) && (asReference || p.Row.Mode == PolicyMode.Enforce)
        && (HasIdentityCondition(p) || ReferencedPolicyIds(p, activeRulesOnly: true).Any(r => IsIdentityPolicy(r, depth + 1, asReference: true)));

    /// <summary>Policy'nin aktif bir kuralında kimlik koşulu (rol, grup, birim, kullanıcı) var mı? (KİM kartı)</summary>
    private bool HasIdentityCondition(CompiledPolicy p) =>
        _conditions is not null
        && p.Definition.Rules.Where(r => r.IsActive).SelectMany(r => PolicyEvaluator.Flatten(r.Condition))
            .Any(n => n.Kind == ConditionKind.Predicate && n.ConditionTypeCode is { } c && _conditions.Find(c) is IIdentityCondition);

    // ================================ Kimlik (rol + grup) ================================

    /// <summary>
    /// Kullanıcının etkin rolleri ve grupları. Kurallar:
    ///  1. Doğrudan roller (geçerlilik tarihi içinde, aktif, kurum kuralına uyan)
    ///  2. Grup üyeliği = (açık üye ∪ Include kuralı) − Exclude kuralı; grup kullanıcının kurum zincirinde olmalı
    ///  3. Grubun verdiği roller
    /// Grup kriteri ROLE sadece DOĞRUDAN rollere bakar → gruptan gelen rol başka grubu tetiklemez (zincir/döngü yok).
    /// </summary>
    public IdentityState GetIdentity(int userId, DateTime now) =>
        _identity.GetOrAdd((userId, now.Ticks / TimeSpan.TicksPerMinute), _ => ComputeIdentity(userId, now));

    private IdentityState ComputeIdentity(int userId, DateTime now)
    {
        if (!Users.TryGetValue(userId, out var user)) throw new KeyNotFoundException($"Kullanıcı modelde yok: {userId}");
        var ignored = new List<string>();
        var roleSources = new Dictionary<int, List<RoleSource>>();

        void AddRole(int roleId, RoleSource src)
        {
            if (!Roles.TryGetValue(roleId, out var role) || !role.IsActive) return;
            if (!RoleAppliesTo(role, user))
            {
                ignored.Add($"Rol '{role.Code}' ({TenantCode(role.TenantId)}) miras alınamaz; {TenantCode(user.TenantId)} kullanıcısına uygulanmadı ({src.Text}).");
                return;
            }
            if (!roleSources.TryGetValue(roleId, out var list)) roleSources[roleId] = list = new();
            list.Add(src);
        }

        foreach (var r in _userRoles[userId].Where(r => Valid(r.ValidFrom, r.ValidUntil, now)))
            AddRole(r.RoleId, new RoleSource("Direct", null, null,
                r.ValidUntil is { } until ? $"doğrudan atama ({until:yyyy-MM-dd}'e kadar)" : "doğrudan atama", r.ValidUntil));

        var (memberships, exclusions) = ComputeMemberships(user, now);
        foreach (var m in memberships)
            foreach (var roleId in _groupRoles[m.GroupId])
                AddRole(roleId, new RoleSource("Group", m.GroupId, m.Code, $"grup '{m.Code}' [{ReasonShort(m)}]", null));

        return new IdentityState
        {
            User = user,
            Roles = roleSources.Select(kv => new EffectiveRole(kv.Key, Roles[kv.Key].Code, Roles[kv.Key].Name, TenantCode(Roles[kv.Key].TenantId), kv.Value))
                .OrderBy(r => r.Code, StringComparer.Ordinal).ToList(),
            Groups = memberships,
            ExcludedFromGroups = exclusions,
            IgnoredAssignments = ignored
        };
    }

    /// <summary>Kullanıcının grup üyelikleri (neden eşleştiği ile) ve Exclude kuralıyla çıkarıldığı gruplar.</summary>
    public (List<GroupMembership> Memberships, List<GroupExclusion> Exclusions) ComputeMemberships(UserRow user, DateTime now)
    {
        var memberships = new List<GroupMembership>();
        var exclusions = new List<GroupExclusion>();
        var tenantChain = TenantAncestors[user.TenantId];

        foreach (var g in Groups.Values.Where(g => g.IsActive && tenantChain.Contains(g.TenantId)).OrderBy(g => g.Code, StringComparer.Ordinal))
        {
            var reasons = new List<MembershipReason>();
            if (_groupMembers[g.Id].Any(m => m.UserId == user.Id && Valid(null, m.ValidUntil, now)))
                reasons.Add(new MembershipReason("Member", null, "açık üye"));

            string? excludedBy = null;
            foreach (var f in _groupFilters[g.Id].OrderBy(f => f.Order))
            {
                if (!FilterMatches(f, user, now, out var text)) continue;
                if (f.Mode == InclusionMode.Include) reasons.Add(new MembershipReason("Filter", f.Order + 1, text));
                else excludedBy ??= $"Kural #{f.Order + 1} (hariç): {text}";
            }

            if (reasons.Count == 0) continue;
            if (excludedBy is not null) exclusions.Add(new GroupExclusion(g.Id, g.Code, excludedBy));
            else memberships.Add(new GroupMembership(g.Id, g.Code, g.Name, TenantCode(g.TenantId), reasons));
        }
        return (memberships, exclusions);
    }

    /// <summary>Filtredeki TÜM kriterler eşleşirse (VE) true. Kriteri olmayan veya bilinmeyen kriterli filtre eşleşmez (güvenli taraf).</summary>
    public bool FilterMatches(GroupFilterRow f, UserRow user, DateTime now, out string text)
    {
        var parts = new List<string>();
        text = "";
        if (f.Criteria.Count == 0) return false;
        foreach (var c in f.Criteria)
        {
            var handler = Criteria.Find(c.Attribute);
            if (handler is null || !handler.Matches(this, user, c.Values, now, out var matched)) return false;
            parts.Add($"{c.Attribute}={matched}");
        }
        text = string.Join(" ∧ ", parts);
        return true;
    }

    private static string ReasonShort(GroupMembership m) =>
        string.Join(" | ", m.Reasons.Select(r => r.Kind == "Member" ? "açık üye" : $"kural #{r.FilterOrder}: {r.Text}"));

    /// <summary>Grubun şu anki üyeleri (neden eşleştikleriyle).</summary>
    public IEnumerable<(UserRow User, GroupMembership Membership)> GroupMembersOf(int groupId, DateTime now)
    {
        foreach (var u in Users.Values.OrderBy(u => u.UserName, StringComparer.Ordinal))
        {
            var m = GetIdentity(u.Id, now).Groups.FirstOrDefault(g => g.GroupId == groupId);
            if (m is not null) yield return (u, m);
        }
    }

    // ================================ Statik (bağlamsız) policy değerlendirmesi ================================

    /// <summary>
    /// Policy'nin istek olmadan sonucu: kimlik kartları (KİM) kesin çözülür, kanal (NEREDEN / client) verilmişse kesinleşir; saat, IP, tutar
    /// gibi koşullar çalışma anına kalır (Indeterminate = "koşullu"). Pasif policy izin vermez; ReportOnly / Advisory karara katılmaz.
    /// </summary>
    public StaticPolicyResult EvaluateStatic(int policyId, IdentityState identity, ClientRow? client = null, int depth = 0, HashSet<int>? path = null) =>
        EvaluateStatic(policyId, identity, client, depth, path, asReference: false);

    /// <param name="asReference">Kural içindeki policy referansı: mod dikkate alınmaz; bulunamayan / pasif policy belirsizdir (çalışma anıyla aynı).</param>
    private StaticPolicyResult EvaluateStatic(int policyId, IdentityState identity, ClientRow? client, int depth, HashSet<int>? path, bool asReference)
    {
        if (!Policies.TryGetValue(policyId, out var p))
            return asReference ? new(DecisionType.Indeterminate, [], [$"#{policyId}: policy bulunamadı"]) : new(DecisionType.Deny, [], []);
        if (!p.Row.IsActive) return asReference ? new(DecisionType.Indeterminate, [], [$"{p.Row.Code}: pasif"]) : new(DecisionType.Deny, [], []);
        if (!asReference && p.Row.Mode != PolicyMode.Enforce) return new(DecisionType.NotApplicable, [], []);
        if (depth > MaxPolicyDepth || (path ??= []).Contains(policyId)) return new(DecisionType.Indeterminate, [], [$"{p.Row.Code} (döngü)"]);

        StaticPolicyResult raw;
        if (_conditions is null) raw = new(DecisionType.Indeterminate, [], [$"{p.Row.Code}: koşul"]);
        else
        {
            path.Add(policyId);
            raw = EvaluateConditionStatic(p, new StaticScope(identity, IdentityFactsOf(identity), client, depth, path));
            path.Remove(policyId);
        }

        if (p.Row.Logic == PolicyLogic.Positive) return raw;
        var inverted = DecisionStrategies.ApplyLogic(PolicyLogic.Negative, raw.Result);
        return inverted == DecisionType.Permit
            ? new(inverted, [(p, $"{p.Row.Code}: şartı sağlamıyor (negatif policy)")], [])
            : new(inverted, [], raw.Conditions);
    }

    // ------------------------------ Koşul policy'sinin statik (kısmi) değerlendirmesi ------------------------------

    /// <summary>
    /// Koşul policy'si istek olmadan: her kural ağacı üç değerli çözülür. KİMLİK koşulları (rol, grup, birim, kullanıcı) kişinin kimliğinden
    /// kesin doğru / yanlış olur; diğerleri (saat, IP, tutar, PIP öznitelikleri) bilinmez kalır. AND'de bir yanlış, OR'da bir doğru sonucu belirler.
    ///   Permit = kesin sağlanır · Deny = bu kişi için asla sağlanmaz · Indeterminate = istek anına bağlı (koşullu; kalan koşullar açıklanır).
    /// Çalışma anı değerlendirmesiyle aynı mantık ve aynı kural birleştirme stratejisi kullanılır.
    /// </summary>
    /// <summary>Statik değerlendirme bağlamı: kişi, (varsa) kanal, policy zinciri derinliği ve döngü yolu.</summary>
    private sealed record StaticScope(IdentityState Identity, IdentityFacts Facts, ClientRow? Client, int Depth, HashSet<int> Path);

    private StaticPolicyResult EvaluateConditionStatic(CompiledPolicy p, StaticScope scope)
    {
        var rules = p.Definition.Rules.OrderBy(r => r.Order).ThenBy(r => r.Code, StringComparer.Ordinal).ToList();
        var evaluated = rules.Select<RuleDefinition, (DecisionType Result, List<string> Matches, string? Residual)>(r =>
        {
            if (!r.IsActive) return (DecisionType.NotApplicable, [], null);
            if (r.Condition is null) return (DecisionType.Indeterminate, [], "(condition yok)");
            var (v, matches, residual) = StaticNode(r.Condition, scope, 0);
            return (v switch { TriState.True => DecisionType.Permit, TriState.False => DecisionType.Deny, _ => DecisionType.Indeterminate }, matches, residual);
        }).ToList();

        var combined = DecisionStrategies.Combine(p.Row.Strategy, evaluated.Select(e => e.Result).ToList()).Decision;
        if (combined == DecisionType.NotApplicable) combined = DecisionType.Indeterminate;   // aktif kural yok: çalışma anında da belirsiz
        if (combined == DecisionType.Deny) return new(DecisionType.Deny, [], []);

        var matched = evaluated.Where(e => e.Result != DecisionType.Deny).SelectMany(e => e.Matches).Distinct().Select(m => (p, m)).ToList();
        if (combined == DecisionType.Permit) return new(DecisionType.Permit, matched, []);
        var residuals = evaluated.Where(e => e.Result == DecisionType.Indeterminate && e.Residual is not null).Select(e => e.Residual!).ToList();
        var joiner = p.Row.Strategy == DecisionStrategy.Unanimous ? " AND " : " OR ";
        return new(DecisionType.Indeterminate, matched, [$"{p.Row.Code}: {(residuals.Count > 0 ? string.Join(joiner, residuals) : "koşul")}"]);
    }

    private (TriState Value, List<string> Matches, string? Residual) StaticNode(ConditionNode node, StaticScope scope, int depth)
    {
        if (depth > PolicyEvaluator.MaxConditionDepth) return (TriState.Indeterminate, [], PolicyEvaluator.Render(node));
        switch (node.Kind)
        {
            case ConditionKind.Predicate:
            {
                var handler = node.TypeAvailable && node.ConditionTypeCode is not null ? _conditions?.Find(node.ConditionTypeCode) : null;
                if (handler is IIdentityCondition identity)
                    return identity.EvaluateIdentity(node.Parameters, scope.Facts, out var because) ? (TriState.True, [because], null) : (TriState.False, [], null);
                // Kanal (NEREDEN / client): soran client biliniyorsa (giriş yetki listesi gibi) kesinleşir
                if (handler is IClientCondition clientCondition && scope.Client is { } c)
                    return clientCondition.EvaluateClient(node.Parameters, c.ClientId, out var why) ? (TriState.True, [why], null) : (TriState.False, [], null);
                return (TriState.Indeterminate, [], PolicyEvaluator.Render(node));
            }
            case ConditionKind.Not:
            {
                if (node.Children.Count != 1) return (TriState.Indeterminate, [], PolicyEvaluator.Render(node));
                var c = StaticNode(node.Children[0], scope, depth + 1);
                return c.Value switch
                {
                    TriState.True => (TriState.False, [], null),
                    TriState.False => (TriState.True, [], null),
                    _ => (TriState.Indeterminate, [], $"NOT {c.Residual}")
                };
            }
            case ConditionKind.Reference:
            {
                // Referans verilen policy aynı statik hesapla çözülür (rol policy'si kesin, koşul policy'si kısmen...).
                if (node.ReferencePolicyId is not { } refId) return (TriState.Indeterminate, [], PolicyEvaluator.Render(node));
                var r = EvaluateStatic(refId, scope.Identity, scope.Client, scope.Depth + 1, scope.Path, asReference: true);
                return r.Result switch
                {
                    DecisionType.Permit => (TriState.True, r.Matches.Select(m => $"@{node.ReferenceCode}: {m.Text}").ToList(), null),
                    DecisionType.Deny => (TriState.False, [], null),
                    _ => (TriState.Indeterminate, r.Matches.Select(m => $"@{node.ReferenceCode}: {m.Text}").ToList(),
                        r.Conditions.Count > 0 ? $"@{node.ReferenceCode}[{string.Join(" AND ", r.Conditions)}]" : PolicyEvaluator.Render(node))
                };
            }
            case ConditionKind.AllOf:
            case ConditionKind.AnyOf:
            {
                if (node.Children.Count == 0) return (TriState.Indeterminate, [], PolicyEvaluator.Render(node));
                var children = node.Children.Select(c => StaticNode(c, scope, depth + 1)).ToList();
                var unknown = children.Where(c => c.Value == TriState.Indeterminate).Select(c => c.Residual!).ToList();
                if (node.Kind == ConditionKind.AllOf)
                {
                    if (children.Any(c => c.Value == TriState.False)) return (TriState.False, [], null);
                    var all = children.SelectMany(c => c.Matches).ToList();
                    return unknown.Count == 0 ? (TriState.True, all, null)
                        : (TriState.Indeterminate, all, unknown.Count == 1 ? unknown[0] : "(" + string.Join(" AND ", unknown) + ")");
                }
                if (children.Any(c => c.Value == TriState.True))
                    return (TriState.True, children.Where(c => c.Value == TriState.True).SelectMany(c => c.Matches).ToList(), null);
                return unknown.Count == 0 ? (TriState.False, [], null)
                    : (TriState.Indeterminate, children.SelectMany(c => c.Matches).ToList(), unknown.Count == 1 ? unknown[0] : "(" + string.Join(" OR ", unknown) + ")");
            }
            default:
                return (TriState.Indeterminate, [], PolicyEvaluator.Render(node));
        }
    }

    /// <summary>Kimlik koşulu ağacı (KİM kartı / kitle) bu kişi için kesin sağlanıyor mu? Kimlik dışı koşul içeriyorsa sağlanmaz sayılır.</summary>
    public bool InAudience(ConditionNode node, IdentityState identity) =>
        _conditions is not null && StaticNode(node, new StaticScope(identity, IdentityFactsOf(identity), null, 0, []), 0).Value == TriState.True;

    /// <summary>Kitlenin şu anki üyeleri (kullanıcı adına göre sıralı).</summary>
    public IEnumerable<UserRow> AudienceMembers(ConditionNode node, DateTime now) =>
        Users.Values.OrderBy(u => u.UserName, StringComparer.Ordinal).Where(u => InAudience(node, GetIdentity(u.Id, now)));

    private IdentityFacts IdentityFactsOf(IdentityState identity) => _facts.GetValue(identity, s => new IdentityFacts
    {
        UserName = s.User.UserName,
        Roles = s.Roles.GroupBy(r => r.Code, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => string.Join(" | ", g.SelectMany(r => r.Sources).Select(x => x.Text)), StringComparer.OrdinalIgnoreCase),
        Groups = s.Groups.GroupBy(g => g.Code, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => ReasonShort(g.First()), StringComparer.OrdinalIgnoreCase),
        UnitCodes = UnitCodesOf(s.User.Id).ToList(),
        UnitAncestry = UnitAncestryOf(s.User.Id).ToList(),
        UnitTypes = UnitsOf(s.User.Id).Select(u => u.Type.ToString()).Distinct().ToList(),
        Title = s.User.Title,
        Kind = s.User.Kind.ToString(),
        TenantChain = TenantAncestors[s.User.TenantId].Select(TenantCode).ToList()
    });

    /// <summary>Permission'ın kullanıcı için statik sonucu (policy'leri stratejisiyle birleştirir). Policy'siz permission izin vermez.</summary>
    public (DecisionType Result, List<AccessSource> Sources, List<string> Conditions) EvaluatePermissionStatic(CompiledPermission perm, IdentityState identity, ClientRow? client = null)
    {
        if (perm.PolicyIds.Count == 0) return (DecisionType.Deny, [], []);
        var results = perm.PolicyIds.Select(id => EvaluateStatic(id, identity, client)).ToList();
        var combined = DecisionStrategies.Combine(perm.Row.Strategy, results.Select(r => r.Result).ToList());
        // Koşullu sonuçta, kimliği eşleşen koşul policy'lerinin (KİM kartı) eşleşmeleri de kaynaktır.
        var sources = results.Where(r => r.Result == DecisionType.Permit || (combined.Decision == DecisionType.Indeterminate && r.Result == DecisionType.Indeterminate))
            .SelectMany(r => r.Matches.Select(m => new AccessSource(perm.Row.Code, m.Policy.Row.Code, $"{perm.Row.Code} ← {m.Policy.Row.Code}: {m.Text}")))
            .ToList();
        var conditions = results.Where(r => r.Result == DecisionType.Indeterminate).SelectMany(r => r.Conditions).ToList();
        // NotApplicable: sadece ReportOnly/Advisory policy'si olan permission karara katılmaz (runtime ile aynı).
        return (combined.Decision, sources, conditions);
    }

    // ================================ Etkin erişim ================================

    /// <summary>
    /// Kullanıcının etkin erişim seti (statik). Bir yetki (resource:scope) için uygulanan permission'lar uygulamanın stratejisiyle
    /// birleştirilir: Permit → erişim var · Indeterminate → koşullu erişim (çalışma anında değerlendirilir) · Deny/uygulanan yok → erişim yok.
    /// SoD, RACF/LDAP provisioning, raporlar ve What-If bu seti kullanır. Dakika hassasiyetinde önbelleklenir.
    /// </summary>
    public EffectiveAccessSet GetEffective(int userId, DateTime now) =>
        _effective.GetOrAdd((userId, now.Ticks / TimeSpan.TicksPerMinute), _ => ComputeEffective(userId, now));

    /// <summary>Tek yetki için statik erişim (client verilirse Client policy'leri de kesinleşir). Erişim yoksa null.</summary>
    public EffectiveAccess? EvaluateAccessStatic(ResourceScopeInfo rs, IdentityState identity, ClientRow? client = null)
    {
        if (!rs.IsActive || !IsAvailableIn(rs.TenantId, identity.User.TenantId)) return null;
        var perms = PermissionsFor(rs.Id);
        if (perms.Count == 0) return null;
        var evaluated = perms.Select(p => EvaluatePermissionStatic(p, identity, client)).ToList();
        var combined = DecisionStrategies.Combine(rs.App.Strategy, evaluated.Select(x => x.Result).ToList()).Decision;
        if (combined is not (DecisionType.Permit or DecisionType.Indeterminate)) return null;
        return new EffectiveAccess(rs.Id, rs.Key, rs.Name, rs.App.Code, rs.Resource.Code, rs.Type.Code, rs.Scope.Code, rs.Path,
            rs.Row.RiskLevel, combined == DecisionType.Indeterminate,
            evaluated.SelectMany(x => x.Sources).DistinctBy(s => s.Path).ToList(),
            evaluated.SelectMany(x => x.Conditions).Distinct().ToList());
    }

    private EffectiveAccessSet ComputeEffective(int userId, DateTime now)
    {
        var identity = GetIdentity(userId, now);
        var user = identity.User;
        var accesses = ResourceScopes.Values.Select(rs => EvaluateAccessStatic(rs, identity)).OfType<EffectiveAccess>().ToList();

        return new EffectiveAccessSet
        {
            UserId = user.Id,
            UserName = user.UserName,
            FullName = user.FullName,
            Tenant = TenantCode(user.TenantId),
            IsActive = user.IsActive,
            ModelVersion = Version,
            ComputedAt = now,
            Roles = identity.Roles,
            Groups = identity.Groups,
            ExcludedFromGroups = identity.ExcludedFromGroups,
            IgnoredAssignments = identity.IgnoredAssignments,
            Accesses = accesses.OrderBy(a => a.Key, StringComparer.Ordinal).ToList()
        };
    }

    /// <summary>Yetkiye (etkin) sahip kullanıcılar ve kaynakları.</summary>
    public IEnumerable<(UserRow User, EffectiveAccess Access)> HoldersOf(int resourceScopeId, DateTime now)
    {
        foreach (var u in Users.Values.OrderBy(u => u.UserName, StringComparer.Ordinal))
        {
            var a = GetEffective(u.Id, now).Find(resourceScopeId);
            if (a is not null) yield return (u, a);
        }
    }
}
