using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Domain.Common;
using Yetki.Pdp.Domain.Governance;

namespace Yetki.Pdp.Application.Governance;

public sealed record SodMemberSnapshot(SodMemberType Type, int Id, string Code, string Name);

public sealed record SodRuleSnapshot(int Id, string Code, string Name, Severity Severity, SodEnforcement Enforcement, IReadOnlyList<SodMemberSnapshot> Members);

public sealed record SodMatchedMember(SodMemberType Type, int Id, string Code, string Name, IReadOnlyList<string> Paths);

public sealed record SodConflict(int SodRuleId, string Code, string Name, Severity Severity, SodEnforcement Enforcement, IReadOnlyList<SodMatchedMember> MatchedMembers)
{
    public string Describe() => $"{Code}: " + string.Join(" + ", MatchedMembers.Select(m => $"{m.Code} [{string.Join(" | ", m.Paths)}]"));
}

public sealed record SodUserConflicts(int UserId, string UserName, string FullName, IReadOnlyList<SodConflict> Conflicts);

/// <summary>Tarama hesabı: şu an çakışması olan kullanıcılar. İhlal kaydı açma / kapatma PAP'ındır.</summary>
public sealed record SodDetectionResult(int ScannedUsers, int ViolatingUsers, double DurationMs, long ModelVersion, IReadOnlyList<SodUserConflicts> Details);

/// <summary>
/// Saf SoD değerlendirici: etkin erişim seti + kurallar → çakışmalar (üyelerden 2+ tanesine sahip olmak ihlaldir).
/// Koşullu erişim (mesai içi, şube ağında...) da erişimdir: SoD açısından sahip sayılır.
/// </summary>
public static class SodEvaluator
{
    public static IReadOnlyList<SodConflict> Evaluate(EffectiveAccessSet set, IEnumerable<SodRuleSnapshot> rules)
    {
        var result = new List<SodConflict>();
        foreach (var rule in rules)
        {
            var matched = new List<SodMatchedMember>();
            foreach (var m in rule.Members)
            {
                if (m.Type == SodMemberType.ResourceScope)
                {
                    var p = set.Find(m.Id);
                    if (p is not null) matched.Add(new SodMatchedMember(m.Type, m.Id, m.Code, m.Name,
                        p.Sources.Select(s => s.Path).DefaultIfEmpty(p.Conditional ? $"koşullu: {string.Join(", ", p.Conditions)}" : "").ToList()));
                }
                else
                {
                    var r = set.Roles.FirstOrDefault(x => x.RoleId == m.Id);
                    if (r is not null) matched.Add(new SodMatchedMember(m.Type, m.Id, m.Code, m.Name, r.Sources.Select(s => s.Text).ToList()));
                }
            }
            if (matched.Count >= 2) result.Add(new SodConflict(rule.Id, rule.Code, rule.Name, rule.Severity, rule.Enforcement, matched));
        }
        return result;
    }
}

/// <summary>
/// SoD hesapları (SALT OKUNUR): aktif kurallar, tüm kullanıcılar için çakışma tespiti ve taslak kural önizlemesi.
/// İhlal kaydı açma / kapatma, kural tanımı ve sistemin yetkiyi otomatik silmemesi politikası PAP'ındır.
/// </summary>
public sealed class SodService(IYetkiDbContext db, AuthorizationModelProvider models, IClock clock)
{
    public async Task<IReadOnlyList<SodRuleSnapshot>> LoadActiveRulesAsync(CancellationToken ct = default)
    {
        var rules = await db.SodRules.AsNoTracking().Where(r => r.IsActive)
            .Select(r => new { r.Id, r.Code, r.Name, r.Severity, r.Enforcement, Members = r.Members.Select(m => new { m.MemberType, m.MemberId }).ToList() })
            .ToListAsync(ct);
        var model = await models.GetCurrentAsync(ct);
        return rules.Select(r => Snapshot(model, r.Id, r.Code, r.Name, r.Severity, r.Enforcement, r.Members.Select(m => (m.MemberType, m.MemberId)))).ToList();
    }

    public static SodRuleSnapshot Snapshot(AuthorizationModel model, int id, string code, string name, Severity severity, SodEnforcement enforcement,
        IEnumerable<(SodMemberType Type, int Id)> members) =>
        new(id, code, name, severity, enforcement, members.Select(m => m.Type == SodMemberType.ResourceScope
            ? new SodMemberSnapshot(m.Type, m.Id, model.ResourceScopes.TryGetValue(m.Id, out var p) ? p.Key : $"#{m.Id}", p?.Name ?? "?")
            : new SodMemberSnapshot(m.Type, m.Id, model.Roles.TryGetValue(m.Id, out var r) ? r.Code : $"#{m.Id}", r?.Name ?? "?")).ToList());

    /// <summary>Kural üyelerini model adlarıyla çözer (PAP'ın kural listesi için).</summary>
    public async Task<SodRuleSnapshot> DescribeAsync(int id, string code, string name, Severity severity, SodEnforcement enforcement,
        IEnumerable<(SodMemberType Type, int Id)> members, CancellationToken ct) =>
        Snapshot(await models.GetCurrentAsync(ct), id, code, name, severity, enforcement, members);

    /// <summary>Geriye dönük tarama hesabı: tüm aktif kullanıcılar × aktif kurallar.</summary>
    public async Task<SodDetectionResult> DetectAsync(CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        var rules = await LoadActiveRulesAsync(ct);
        var model = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        var users = model.Users.Values.Where(u => u.IsActive).ToList();
        var details = users
            .Select(u => (u, c: SodEvaluator.Evaluate(model.GetEffective(u.Id, now), rules)))
            .Where(x => x.c.Count > 0)
            .Select(x => new SodUserConflicts(x.u.Id, x.u.UserName, x.u.FullName, x.c))
            .ToList();
        sw.Stop();
        return new SodDetectionResult(users.Count, details.Count, Math.Round(sw.Elapsed.TotalMilliseconds, 1), model.Version, details);
    }

    /// <summary>What-If: verilen (kaydedilmemiş olabilir) kural şu an kaç kullanıcıda ihlal üretir?</summary>
    public async Task<IReadOnlyList<SodUserConflicts>> SimulateRuleAsync(SodRuleSnapshot draft, CancellationToken ct = default)
    {
        var model = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        return model.Users.Values.Where(u => u.IsActive)
            .Select(u => (u, c: SodEvaluator.Evaluate(model.GetEffective(u.Id, now), [draft])))
            .Where(x => x.c.Count > 0)
            .Select(x => new SodUserConflicts(x.u.Id, x.u.UserName, x.u.FullName, x.c))
            .ToList();
    }
}