using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Yetki.Pdp.Application.Audit;
using Yetki.Pdp.Application.Changes;
using Yetki.Pdp.Application.Definitions;
using Yetki.Pdp.Application.Evaluation;
using Yetki.Pdp.Application.Governance;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Application.PolicyEngine;
using Yetki.Pdp.Application.PolicyEngine.Attributes;
using Yetki.Pdp.Application.PolicyEngine.Conditions;
using Yetki.Pdp.Application.Simulation;

namespace Yetki.Pdp.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddYetkiApplication(this IServiceCollection services)
    {
        services.AddOptions<AuthorizationEngineOptions>();

        // ---- Policy condition tipleri (davranış C#'ta). Yeni tip = yeni handler + buraya kayıt ----
        services.AddSingleton<IConditionHandler, AlwaysConditionHandler>();
        services.AddSingleton<IConditionHandler, TimeWindowConditionHandler>();
        services.AddSingleton<IConditionHandler, IpInRangeConditionHandler>();
        services.AddSingleton<IConditionHandler, ChannelInConditionHandler>();
        services.AddSingleton<IConditionHandler, PlatformInConditionHandler>();
        services.AddSingleton<IConditionHandler, ClientInConditionHandler>();
        services.AddSingleton<IConditionHandler, AmountExceedsSubjectLimitConditionHandler>();
        services.AddSingleton<IConditionHandler, AmountGreaterThanConditionHandler>();
        services.AddSingleton<IConditionHandler, AmountExceedsDailyLimitConditionHandler>();
        services.AddSingleton<IConditionHandler, BranchInUserScopeConditionHandler>();
        services.AddSingleton<IConditionHandler, SubjectInUnitConditionHandler>();
        services.AddSingleton<IConditionHandler, SubjectHasRoleConditionHandler>();
        services.AddSingleton<IConditionHandler, SubjectInGroupConditionHandler>();
        services.AddSingleton<IConditionHandler, SubjectIsUserConditionHandler>();
        services.AddSingleton<IConditionHandler, SubjectHasTitleConditionHandler>();
        services.AddSingleton<IConditionHandler, SubjectUnitTypeConditionHandler>();
        services.AddSingleton<IConditionHandler, SubjectInTenantConditionHandler>();
        services.AddSingleton<IConditionHandler, SubjectKindConditionHandler>();
        services.AddSingleton<IConditionHandler, UserOnLeaveConditionHandler>();
        services.AddSingleton<IConditionHandler, CustomerIsSelfConditionHandler>();
        services.AddSingleton<IConditionHandler, BusinessDayConditionHandler>();
        services.AddSingleton<IConditionHandler, CustomerIsVipConditionHandler>();
        services.AddSingleton<IConditionHandler, CustomerIsStaffConditionHandler>();
        services.AddSingleton<ConditionHandlerRegistry>();
        services.AddScoped<ConditionTypeCatalogSynchronizer>();

        // ---- Grup kitle kriterleri (davranış C#'ta) ----
        services.AddSingleton<IGroupCriterionHandler, RoleCriterion>();
        services.AddSingleton<IGroupCriterionHandler, OrgUnitCriterion>();
        services.AddSingleton<IGroupCriterionHandler, OrgUnitTreeCriterion>();
        services.AddSingleton<IGroupCriterionHandler, OrgUnitTypeCriterion>();
        services.AddSingleton<IGroupCriterionHandler, TitleCriterion>();
        services.AddSingleton<IGroupCriterionHandler, TenantCriterion>();
        services.AddSingleton<IGroupCriterionHandler, UserCriterion>();
        services.AddSingleton<IGroupCriterionHandler, UserKindCriterion>();
        services.AddSingleton<GroupCriterionRegistry>();

        // ---- Attribute kaynakları: kayıt sırası önceliktir (PIP kimlik dışı öznitelikler için yetkili tek kaynak, en önde) ----
        services.AddScoped<IAttributeValueProvider, PipAttributeProvider>();
        services.AddScoped<IAttributeValueProvider, RequestContextAttributeProvider>();
        services.AddScoped<IAttributeValueProvider, ModelSubjectAttributeProvider>();
        services.TryAddSingleton<IAttributeRedactor, DefaultAttributeRedactor>();

        // ---- Yetki modeli ----
        services.AddSingleton<AuthorizationModelCache>();
        services.AddScoped<AuthorizationModelProvider>();

        services.AddScoped<PolicyEvaluator>();
        services.AddScoped<AuthorizationEvaluator>();
        services.AddScoped<EntitlementService>();
        services.AddScoped<AudienceService>();

        services.AddScoped<AuditWriter>();
        services.AddScoped<ClientCredentialService>();
        services.AddScoped<ConditionDraftValidator>();

        // ---- Analiz (salt okunur; PAP çağırır) ----
        services.AddScoped<SodService>();
        services.AddScoped<ImpactAnalysisService>();
        services.AddScoped<Inventory.InventoryService>();
        services.AddScoped<External.ExternalAnalysisService>();
        services.AddScoped<PolicyImpactService>();
        services.AddScoped<SimulationService>();
        return services;
    }
}
