using Microsoft.EntityFrameworkCore;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Common;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Domain.Catalog;

namespace Yetki.Pdp.Application.Inventory;

public enum CoverageStatus { Protected = 1, NoPermission = 2, Undefined = 3, Ambiguous = 4 }

public sealed record InventorySnapshotInfo(InventoryKind Kind, string Source, DateTime ImportedAt, string ImportedBy, int ItemCount);

public sealed record EndpointCoverage(
    string Method, string Path, string? Name, string Group, CoverageStatus Status,
    string? Key, int? ResourceId, string? MatchedUri, IReadOnlyList<string> Permissions, IReadOnlyList<string> Ambiguous,
    string SuggestedScope, int? SuggestedResourceId, string? SuggestedResourceCode, string SuggestedCode);

public sealed record StaleUri(int ResourceId, string Resource, string Method, string Pattern, string Key, string Group);

public sealed record UiCoverage(
    string Code, string? Name, string? ParentCode, string? ElementType, CoverageStatus Status,
    int? ResourceId, string? Resource, IReadOnlyList<ScopeState> Scopes,
    string SuggestedCode, int? SuggestedTypeId, int? SuggestedParentId);

public sealed record ScopeState(string Key, bool Protected);

public sealed record StaleUi(int ResourceId, string Code, string Name, string Type, string? ExternalCode);

public sealed record CoverageReport(
    int ApplicationId, string Application, InventorySnapshotInfo? Endpoints, InventorySnapshotInfo? UiElements,
    IReadOnlyList<EndpointCoverage> EndpointItems, IReadOnlyList<StaleUri> StaleUris,
    IReadOnlyList<UiCoverage> UiItems, IReadOnlyList<StaleUi> StaleUiResources);

/// <summary>
/// ENVANTER ve KAPSAMA (hesap; içe aktarma PAP'ındır): uygulamada gerçekte ne var (Swagger, ekran listesi) ↔ yetki tanımları.
/// Envanter sadece bilgidir: resource / permission üretmez, kararları etkilemez. Rapor dört durumu ayırır:
///  korunuyor · tanımlı ama permission yok (kapalı) · tanımsız (kapalı; çağrılırsa reddedilir) · tanımlı ama envanterde yok (atıl olabilir).
/// </summary>
public sealed class InventoryService(IYetkiDbContext db, AuthorizationModelProvider models)
{

    public async Task<CoverageReport> CoverageAsync(int applicationId, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Apps.TryGetValue(applicationId, out var app)) throw new NotFoundException("Uygulama", applicationId);
        var snapshots = await db.InventorySnapshots.AsNoTracking().Include(s => s.Items)
            .Where(s => s.ApplicationId == applicationId).ToListAsync(ct);
        var endpointSnap = snapshots.FirstOrDefault(s => s.Kind == InventoryKind.Endpoint);
        var uiSnap = snapshots.FirstOrDefault(s => s.Kind == InventoryKind.UiElement);
        var appResources = m.Resources.Values.Where(r => r.ApplicationId == app.Id).ToList();

        // ---- Endpoint'ler
        var endpoints = new List<EndpointCoverage>();
        var hitUris = new HashSet<int>();
        foreach (var item in endpointSnap?.Items.OrderBy(i => i.Path).ThenBy(i => i.Method) ?? Enumerable.Empty<InventoryItem>())
        {
            var method = item.Method ?? "GET";
            var path = item.Path ?? "/";
            var group = AuthorizationModel.UrlGroup([path]);
            var scope = SuggestScope(method);
            var (match, ambiguous) = m.MatchHttp(app.Code, method, path, app.TenantId);
            if (match is not null) hitUris.Add(match.Uri.Id);
            foreach (var a in ambiguous) hitUris.Add(a.Uri.Id);

            // Öneri: aynı URL grubundaki mevcut resource (yeni URI oraya eklenir) veya yeni resource kodu
            var sibling = match is null
                ? appResources.Where(r => m.ResourceTypes[r.ResourceTypeId].MatchesHttp)
                    .Select(r => (r, prefix: AuthorizationModel.UrlGroup(m.UrisOf(r.Id).Select(u => u.Pattern))))
                    .Where(x => x.prefix.Length > 0 && (group + "/").StartsWith(x.prefix + "/", StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(x => x.prefix.Length).Select(x => x.r).FirstOrDefault()
                : null;

            if (ambiguous.Count > 0)
                endpoints.Add(new(method, path, item.Name, group, CoverageStatus.Ambiguous, null, null, null, [], ambiguous.Select(a => $"{a.Uri.Method} {a.Uri.Pattern} → {a.Access.Key}").ToList(),
                    scope, null, null, SuggestCode(app.Code, group)));
            else if (match is null)
                endpoints.Add(new(method, path, item.Name, group, CoverageStatus.Undefined, null, null, null, [], [],
                    scope, sibling?.Id, sibling?.Code, SuggestCode(app.Code, group)));
            else
            {
                var perms = m.PermissionsFor(match.Access.Id).Select(p => p.Row.Code).ToList();
                endpoints.Add(new(method, path, item.Name, group, perms.Count > 0 ? CoverageStatus.Protected : CoverageStatus.NoPermission,
                    match.Access.Key, match.Access.Resource.Id, $"{match.Uri.Method} {match.Uri.Pattern}", perms, [], scope, null, null, SuggestCode(app.Code, group)));
            }
        }
        var staleUris = endpointSnap is null ? [] : appResources
            .SelectMany(r => m.UrisOf(r.Id).Where(u => !hitUris.Contains(u.Id)).Select(u => new StaleUri(r.Id, r.Code, u.Method, u.Pattern,
                $"{r.Code}:{m.Scopes.GetValueOrDefault(u.ScopeId)?.Code}", AuthorizationModel.UrlGroup([u.Pattern]))))
            .OrderBy(x => x.Pattern).ToList();

        // ---- UI öğeleri (kod eşleşmesi: resource.ExternalCode veya resource.Code)
        var uiResources = appResources.Where(r => !m.ResourceTypes[r.ResourceTypeId].MatchesHttp).ToList();
        ResourceRow? FindRes(string? code) => string.IsNullOrWhiteSpace(code) ? null : uiResources.FirstOrDefault(r =>
            string.Equals(r.ExternalCode, code, StringComparison.OrdinalIgnoreCase) || string.Equals(r.Code, code, StringComparison.OrdinalIgnoreCase));
        var ui = new List<UiCoverage>();
        var hitResources = new HashSet<int>();
        foreach (var item in uiSnap?.Items.OrderBy(i => i.ParentCode).ThenBy(i => i.Code) ?? Enumerable.Empty<InventoryItem>())
        {
            var r = FindRes(item.Code);
            var typeId = SuggestType(m, item.ElementType);
            var parentId = FindRes(item.ParentCode)?.Id;
            var suggested = $"{app.Code.ToLowerInvariant()}.{Slug(item.Code ?? item.Name ?? "oge")}";
            if (r is null)
            {
                ui.Add(new(item.Code ?? "", item.Name, item.ParentCode, item.ElementType, CoverageStatus.Undefined, null, null, [], suggested, typeId, parentId));
                continue;
            }
            hitResources.Add(r.Id);
            var scopes = m.ScopesOf(r.Id).Select(s => new ScopeState(s.Key, m.PermissionsFor(s.Id).Count > 0)).ToList();
            ui.Add(new(item.Code ?? "", item.Name, item.ParentCode, item.ElementType,
                scopes.Any(s => s.Protected) ? CoverageStatus.Protected : CoverageStatus.NoPermission, r.Id, r.Code, scopes, suggested, typeId, parentId));
        }
        var staleUi = uiSnap is null ? [] : uiResources.Where(r => !hitResources.Contains(r.Id))
            .Select(r => new StaleUi(r.Id, r.Code, r.Name, m.ResourceTypes[r.ResourceTypeId].Code, r.ExternalCode)).OrderBy(x => x.Code).ToList();

        return new CoverageReport(app.Id, app.Code,
            endpointSnap is null ? null : Info(endpointSnap, endpointSnap.Items.Count),
            uiSnap is null ? null : Info(uiSnap, uiSnap.Items.Count),
            endpoints, staleUris, ui, staleUi);
    }

    // ================================ Öneriler ================================

    /// <summary>HTTP metodundan scope önerisi (sadece öneri; karar yetki ekibinindir): GET → view, POST → create, PUT/PATCH → update, DELETE → delete.</summary>
    public static string SuggestScope(string method) => method.ToUpperInvariant() switch
    {
        "GET" => "view",
        "PUT" or "PATCH" => "update",
        "DELETE" => "delete",
        _ => "create"
    };

    private static string SuggestCode(string app, string group)
    {
        var segs = group.Split('/', StringSplitOptions.RemoveEmptyEntries).Where(s => !IsVersion(s)).ToList();
        return $"{app.ToLowerInvariant()}.{(segs.Count > 0 ? Slug(segs[^1]) : "yeni")}";
    }

    private static int? SuggestType(AuthorizationModel m, string? elementType) =>
        (elementType is null ? null : m.ResourceTypes.Values.FirstOrDefault(t => string.Equals(t.Code, elementType, StringComparison.OrdinalIgnoreCase))?.Id)
        ?? m.ResourceTypes.Values.Where(t => !t.MatchesHttp && t.IsActive).OrderBy(t => t.Code).Select(t => (int?)t.Id).FirstOrDefault();

    // ================================ Yardımcılar ================================

    private static InventorySnapshotInfo Info(InventorySnapshot s, int count) => new(s.Kind, s.Source, s.ImportedAt, s.ImportedBy, count);


    private static bool IsVersion(string s) => s.Length >= 2 && (s[0] == 'v' || s[0] == 'V') && s[1..].All(char.IsDigit);

    private static string Slug(string s)
    {
        var chars = s.ToLowerInvariant().Where(c => char.IsLetterOrDigit(c) && c < 128).ToArray();
        var slug = new string(chars);
        return slug.Length == 0 ? "oge" : char.IsLetter(slug[0]) ? slug : "x" + slug;
    }

    private static string? Trim(string? s, int max = 512) =>
        string.IsNullOrWhiteSpace(s) ? null : s.Trim().Length > max ? s.Trim()[..max] : s.Trim();
}
