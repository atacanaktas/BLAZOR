using System.Globalization;
using Yetki.Pdp.Application.Context;
using Yetki.Pdp.Application.PolicyEngine.Attributes;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.PolicyEngine.Conditions;

/// <summary>
/// Context tutarı &gt; kullanıcının limit attribute'u. Limit policy'de SABİT DEĞİLDİR; kullanıcı attribute'u olarak çözülür
/// (prototipte yetki modeli, üretimde limit yönetim servisi). Eksik değer → Indeterminate (fail-closed).
/// </summary>
public sealed class AmountExceedsSubjectLimitConditionHandler : ConditionHandlerBase
{
    public const string Code = "AMOUNT_EXCEEDS_SUBJECT_LIMIT";
    public override ConditionQuestion? Question => ConditionQuestion.HowMuch;

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Tutar kullanıcı limitini aşıyor", "İşlem tutarı kullanıcının limit attribute'undan BÜYÜK.", ConditionScope.Global,
        [
            new("AmountAttribute", "Tutar context anahtarı", "string", false, AuthContextKeys.TransactionAmount, null),
            new("LimitAttribute", "Kullanıcı limit attribute'u", "string", false, SubjectAttributes.CashWithdrawalLimit, null)
        ],
        [AttributeId.Ctx(AuthContextKeys.TransactionAmount).ToString(), AttributeId.Subject(SubjectAttributes.CashWithdrawalLimit).ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var amountId = AttributeId.Ctx(ctx.Param("AmountAttribute", AuthContextKeys.TransactionAmount));
        var limitId = AttributeId.Subject(ctx.Param("LimitAttribute", SubjectAttributes.CashWithdrawalLimit));
        var amount = await ctx.Attributes.GetDecimalAsync(amountId, ct);
        var limit = await ctx.Attributes.GetDecimalAsync(limitId, ct);
        if (amount is null || limit is null)
            return ConditionResult.Missing(new[] { (amountId, amount), (limitId, limit) }.Where(x => x.Item2 is null).Select(x => x.Item1).ToArray());
        return ConditionResult.Of(amount > limit, $"Tutar {F(amount)} > kullanıcı limiti {F(limit)}.", $"Tutar {F(amount)} ≤ kullanıcı limiti {F(limit)}.");
    }

    internal static string F(decimal? d) => d?.ToString("N2", CultureInfo.InvariantCulture) ?? "-";
}

/// <summary>Context tutarı sabit eşikten büyük mü? (domain eşiği)</summary>
public sealed class AmountGreaterThanConditionHandler : ConditionHandlerBase
{
    public const string Code = "AMOUNT_GREATER_THAN";
    public override ConditionQuestion? Question => ConditionQuestion.HowMuch;

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Tutar eşikten büyük", "İşlem tutarı parametredeki sabit eşikten BÜYÜK.", ConditionScope.Domain,
        [
            new("Threshold", "Eşik", "decimal", true, null, "Nokta ondalık ayırıcı"),
            new("AmountAttribute", "Tutar context anahtarı", "string", false, AuthContextKeys.TransactionAmount, null)
        ],
        [AttributeId.Ctx(AuthContextKeys.TransactionAmount).ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var amountId = AttributeId.Ctx(ctx.Param("AmountAttribute", AuthContextKeys.TransactionAmount));
        var amount = await ctx.Attributes.GetDecimalAsync(amountId, ct);
        if (amount is null) return ConditionResult.Missing(amountId);
        var threshold = ctx.DecimalParam("Threshold");
        if (threshold is null) return ConditionResult.Error("INVALID_PARAMETER", "Threshold tanımsız.");
        var F = AmountExceedsSubjectLimitConditionHandler.F;
        return ConditionResult.Of(amount > threshold, $"Tutar {F(amount)} > eşik {F(threshold)}.", $"Tutar {F(amount)} ≤ eşik {F(threshold)}.");
    }
}

/// <summary>Veri kapsamı: işlemin şubesi (Context.BranchCode) kullanıcının birimleri veya ALT birimleri içinde mi? (bölge müdürü → bölgedeki şubeler)</summary>
public sealed class BranchInUserScopeConditionHandler : ConditionHandlerBase
{
    public const string Code = "BRANCH_IN_USER_SCOPE";
    public override ConditionQuestion? Question => ConditionQuestion.Target;
    private static readonly AttributeId Branch = AttributeId.Ctx(AuthContextKeys.BranchCode);
    private static readonly AttributeId Scope = AttributeId.Subject(SubjectAttributes.OrgUnitScope);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Şube kullanıcının veri kapsamında",
        "İşlemin/kaydın şubesi kullanıcının birimi veya onun alt birimlerinden biri.", ConditionScope.Global, [],
        [Branch.ToString(), Scope.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var branch = await ctx.Attributes.GetStringAsync(Branch, ct);
        if (branch is null) return ConditionResult.Missing(Branch);
        var scope = await ctx.Attributes.GetAsync(Scope, ct);
        if (scope is null) return ConditionResult.Missing(Scope);
        var codes = ConditionEvaluationContext.SplitList(scope.Value);
        return ConditionResult.Of(codes.Contains(branch, StringComparer.OrdinalIgnoreCase),
            $"{branch} şubesi kullanıcının kapsamında.",
            $"{branch} şubesi kullanıcının kapsamı dışında (kapsam: {string.Join(",", codes)}).");
    }
}

/// <summary>Kullanıcı verilen birimlerden birinde mi? IncludeSubtree=true: birimin alt birimleri de sayılır (GM → tüm daireler).</summary>
public sealed class SubjectInUnitConditionHandler : ConditionHandlerBase, IIdentityCondition
{
    public bool EvaluateIdentity(IReadOnlyDictionary<string, string> parameters, IdentityFacts facts, out string because)
    {
        var subtree = parameters.TryGetValue("IncludeSubtree", out var s) && bool.TryParse(s, out var b) && b;
        var hit = (subtree ? facts.UnitAncestry : facts.UnitCodes).Intersect(ListParam(parameters, "Units"), StringComparer.OrdinalIgnoreCase).FirstOrDefault();
        because = hit is null ? "" : $"birim {hit}" + (subtree ? " (alt birimleri dahil)" : "");
        return hit is not null;
    }

    public const string Code = "SUBJECT_IN_UNIT";
    public override ConditionQuestion? Question => ConditionQuestion.Who;
    private static readonly AttributeId Units = AttributeId.Subject(SubjectAttributes.OrgUnitCodes);
    private static readonly AttributeId Ancestry = AttributeId.Subject(SubjectAttributes.OrgUnitAncestry);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcı birimde", "Kullanıcı verilen birimlerden birinde (opsiyonel: alt birimleri dahil).", ConditionScope.Global,
        [
            new("Units", "Birim kodları", "list", true, null, "ör. 101,737 veya GM"),
            new("IncludeSubtree", "Alt birimler dahil", "bool", false, "false", "true: GM verilirse GM altındaki daireler de sayılır")
        ],
        [Units.ToString(), Ancestry.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var attr = ctx.BoolParam("IncludeSubtree", false) ? Ancestry : Units;
        var v = await ctx.Attributes.GetAsync(attr, ct);
        if (v is null) return ConditionResult.Missing(attr);
        var mine = ConditionEvaluationContext.SplitList(v.Value);
        var wanted = ConditionEvaluationContext.SplitList(ctx.Param("Units"));
        var hit = mine.Intersect(wanted, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
        return ConditionResult.Of(hit is not null, $"Kullanıcı {hit} biriminde.", $"Kullanıcı {string.Join(",", wanted)} birimlerinde değil.");
    }
}

/// <summary>Kullanıcının etkin rolleri (doğrudan + gruptan) arasında verilenlerden biri var mı?</summary>
public sealed class SubjectHasRoleConditionHandler : ConditionHandlerBase, IIdentityCondition
{
    public bool EvaluateIdentity(IReadOnlyDictionary<string, string> parameters, IdentityFacts facts, out string because)
    {
        // Eşleşen TÜM roller yazılır: biri kaldırılınca erişimin başka rolden korunduğu görünsün
        var hits = ListParam(parameters, "Roles").Where(facts.Roles.ContainsKey).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        because = string.Join("; ", hits.Select(h => $"rol {h} ({facts.Roles[h]})"));
        return hits.Count > 0;
    }

    public const string Code = "SUBJECT_HAS_ROLE";
    public override ConditionQuestion? Question => ConditionQuestion.Who;
    private static readonly AttributeId Roles = AttributeId.Subject(SubjectAttributes.RoleCodes);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcı rolde", "Kullanıcının etkin rollerinden biri verilen listede.", ConditionScope.Global,
        [new("Roles", "Roller", "list", true, null, "ör. GM850UZYTK,SUBEMDR")],
        [Roles.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var v = await ctx.Attributes.GetAsync(Roles, ct);
        if (v is null) return ConditionResult.Missing(Roles);
        var hit = ConditionEvaluationContext.SplitList(v.Value).Intersect(ConditionEvaluationContext.SplitList(ctx.Param("Roles")), StringComparer.OrdinalIgnoreCase).FirstOrDefault();
        return ConditionResult.Of(hit is not null, $"Kullanıcı {hit} rolünde.", $"Kullanıcı {ctx.Param("Roles")} rollerinde değil.");
    }
}

/// <summary>Kullanıcı verilen gruplardan birinin üyesi mi? (kişi listesi policy'ye yazılmaz, gruba referans verilir)</summary>
public sealed class SubjectInGroupConditionHandler : ConditionHandlerBase, IIdentityCondition
{
    public bool EvaluateIdentity(IReadOnlyDictionary<string, string> parameters, IdentityFacts facts, out string because)
    {
        var hits = ListParam(parameters, "Groups").Where(facts.Groups.ContainsKey).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        because = string.Join("; ", hits.Select(h => $"grup {h} ({facts.Groups[h]})"));
        return hits.Count > 0;
    }

    public const string Code = "SUBJECT_IN_GROUP";
    public override ConditionQuestion? Question => ConditionQuestion.Who;
    private static readonly AttributeId Groups = AttributeId.Subject(SubjectAttributes.GroupCodes);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcı grupta", "Kullanıcı verilen gruplardan birinin üyesi.", ConditionScope.Global,
        [new("Groups", "Gruplar", "list", true, null, "ör. GISE_101_AST")],
        [Groups.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var v = await ctx.Attributes.GetAsync(Groups, ct);
        if (v is null) return ConditionResult.Missing(Groups);
        var hit = ConditionEvaluationContext.SplitList(v.Value).Intersect(ConditionEvaluationContext.SplitList(ctx.Param("Groups")), StringComparer.OrdinalIgnoreCase).FirstOrDefault();
        return ConditionResult.Of(hit is not null, $"Kullanıcı {hit} grubunun üyesi.", $"Kullanıcı {ctx.Param("Groups")} gruplarının üyesi değil.");
    }
}

/// <summary>Kullanıcı izinde mi?</summary>
public sealed class UserOnLeaveConditionHandler : ConditionHandlerBase
{
    public const string Code = "USER_ON_LEAVE";
    /// <summary>Kimlik değil, o günün durumu (PIP izin kaynağı) → NE ZAMAN kartı.</summary>
    public override ConditionQuestion? Question => ConditionQuestion.When;
    private static readonly AttributeId OnLeave = AttributeId.Subject(SubjectAttributes.IsOnLeave);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcı izinde", "Kullanıcı şu an izinde.", ConditionScope.Global, [], [OnLeave.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var onLeave = await ctx.Attributes.GetBoolAsync(OnLeave, ct);
        return onLeave is null ? ConditionResult.Missing(OnLeave) : ConditionResult.Of(onLeave.Value, "Kullanıcı izinde.", "Kullanıcı aktif görevde.");
    }
}

/// <summary>İşlemdeki müşteri personelin kendisi mi? (Context.CustomerId == Subject.CustomerId)</summary>
public sealed class CustomerIsSelfConditionHandler : ConditionHandlerBase
{
    public const string Code = "CUSTOMER_IS_SELF";
    public override ConditionQuestion? Question => ConditionQuestion.Target;
    private static readonly AttributeId Customer = AttributeId.Ctx(AuthContextKeys.CustomerId);
    private static readonly AttributeId Own = AttributeId.Subject(SubjectAttributes.CustomerId);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Müşteri personelin kendisi", "İşlemdeki müşteri, personelin kendi müşteri numarası.", ConditionScope.Global, [],
        [Customer.ToString(), Own.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var customer = await ctx.Attributes.GetStringAsync(Customer, ct);
        if (customer is null) return ConditionResult.Missing(Customer);
        var own = await ctx.Attributes.GetAsync(Own, ct);
        if (own is null) return ConditionResult.Missing(Own);
        return ConditionResult.Of(own.Value is not null && string.Equals(own.Value, customer, StringComparison.OrdinalIgnoreCase),
            "İşlem personelin kendi müşteri hesabında.", "Müşteri personelin kendisi değil.");
    }
}

/// <summary>İşlemdeki müşteri VIP mi? (PIP müşteri kaynağı; bugün geçici kural: müşteri no "99" ile başlar)</summary>
public sealed class CustomerIsVipConditionHandler : ConditionHandlerBase
{
    public const string Code = "CUSTOMER_IS_VIP";
    public override ConditionQuestion? Question => ConditionQuestion.Target;
    private static readonly AttributeId Vip = AttributeId.Customer(CustomerAttributes.IsVip);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Müşteri VIP", "İşlemdeki müşteri (Context.CustomerId) VIP segmentinde.", ConditionScope.Global, [],
        [AttributeId.Ctx(AuthContextKeys.CustomerId).ToString(), Vip.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var v = await ctx.Attributes.GetBoolAsync(Vip, ct);
        return v is null ? ConditionResult.Missing(Vip) : ConditionResult.Of(v.Value, "Müşteri VIP.", "Müşteri VIP değil.");
    }
}

/// <summary>
/// İşlemdeki müşteri bir PERSONEL müşterisi mi? (PIP; bugün geçici kural: müşteri no "98" ile başlar).
/// Kullanım: personel maaş bilgisini sadece yetkili personel görsün → NOT(CUSTOMER_IS_STAFF) OR SUBJECT_HAS_ROLE(yetkili rol).
/// </summary>
public sealed class CustomerIsStaffConditionHandler : ConditionHandlerBase
{
    public const string Code = "CUSTOMER_IS_STAFF";
    public override ConditionQuestion? Question => ConditionQuestion.Target;
    private static readonly AttributeId Staff = AttributeId.Customer(CustomerAttributes.IsStaff);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Personel müşterisi", "İşlemdeki müşteri (Context.CustomerId) bankanın bir personeli.", ConditionScope.Global, [],
        [AttributeId.Ctx(AuthContextKeys.CustomerId).ToString(), Staff.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var v = await ctx.Attributes.GetBoolAsync(Staff, ct);
        return v is null ? ConditionResult.Missing(Staff) : ConditionResult.Of(v.Value, "Müşteri bir personel.", "Müşteri personel değil.");
    }
}
/// <summary>
/// Bugün kullanılan + bu işlemin tutarı, kullanıcının GÜNLÜK toplam limitini aşıyor mu? Limit ve kullanılan tutar PIP limit kaynağındandır
/// (bugün geçici: günlük = işlem başı × 3, kullanılan = 0). İşlem başı limit için AMOUNT_EXCEEDS_SUBJECT_LIMIT kullanılır.
/// </summary>
public sealed class AmountExceedsDailyLimitConditionHandler : ConditionHandlerBase
{
    public const string Code = "AMOUNT_EXCEEDS_DAILY_LIMIT";
    public override ConditionQuestion? Question => ConditionQuestion.HowMuch;
    private static readonly AttributeId Amount = AttributeId.Ctx(AuthContextKeys.TransactionAmount);
    private static readonly AttributeId Daily = AttributeId.Subject(SubjectAttributes.DailyCashLimit);
    private static readonly AttributeId Used = AttributeId.Subject(SubjectAttributes.CashUsedToday);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Günlük limit aşılıyor", "Bugün kullanılan + işlem tutarı kullanıcının günlük toplam limitini aşıyor.", ConditionScope.Global, [],
        [Amount.ToString(), Daily.ToString(), Used.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var amount = await ctx.Attributes.GetDecimalAsync(Amount, ct);
        if (amount is null) return ConditionResult.Missing(Amount);
        var daily = await ctx.Attributes.GetDecimalAsync(Daily, ct);
        if (daily is null) return ConditionResult.Missing(Daily);
        var used = await ctx.Attributes.GetDecimalAsync(Used, ct);
        if (used is null) return ConditionResult.Missing(Used);
        var total = used.Value + amount.Value;
        return ConditionResult.Of(total > daily.Value,
            $"Günlük toplam {total:N0} > limit {daily:N0} (bugün kullanılan {used:N0}).",
            $"Günlük toplam {total:N0} ≤ limit {daily:N0} (bugün kullanılan {used:N0}).");
    }
}
/// <summary>
/// "Kullanıcının X değeri listede mi?" kimlik koşulları için taban. Grup kitle kriterleriyle AYNI değerlere bakar
/// (KİM kartı satırı ↔ grup kuralı birebir taşınabilsin): unvan ↔ TITLE, birim tipi ↔ ORG_UNIT_TYPE, kurum ↔ TENANT, tür ↔ USER_KIND.
/// </summary>
public abstract class SubjectValueInListConditionHandler : ConditionHandlerBase, IIdentityCondition
{
    protected abstract string ParamKey { get; }
    protected abstract AttributeId Attribute { get; }
    protected abstract string Noun { get; }
    protected abstract IEnumerable<string> FactValues(IdentityFacts facts);
    /// <summary>Attribute tek değer mi (unvan virgül içerebilir) yoksa virgüllü liste mi?</summary>
    protected virtual bool SingleValue => false;
    public override ConditionQuestion? Question => ConditionQuestion.Who;

    public bool EvaluateIdentity(IReadOnlyDictionary<string, string> parameters, IdentityFacts facts, out string because)
    {
        var wanted = ListParam(parameters, ParamKey);
        var hit = FactValues(facts).FirstOrDefault(v => wanted.Contains(v, StringComparer.OrdinalIgnoreCase));
        because = hit is null ? "" : $"{Noun} {hit}";
        return hit is not null;
    }

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var v = await ctx.Attributes.GetAsync(Attribute, ct);
        if (v is null) return ConditionResult.Missing(Attribute);
        var mine = SingleValue ? (v.Value is null ? [] : [v.Value]) : ConditionEvaluationContext.SplitList(v.Value);
        var wanted = ConditionEvaluationContext.SplitList(ctx.Param(ParamKey));
        var hit = mine.FirstOrDefault(x => wanted.Contains(x, StringComparer.OrdinalIgnoreCase));
        return ConditionResult.Of(hit is not null, $"Kullanıcının {Noun}: {hit}.", $"Kullanıcının {Noun} ({string.Join(",", mine)}) listede değil: {string.Join(",", wanted)}.");
    }
}

/// <summary>Kullanıcının unvanı listede mi? (grup TITLE kriteri ile aynı: tam eşleşme, büyük/küçük harf duyarsız)</summary>
public sealed class SubjectHasTitleConditionHandler : SubjectValueInListConditionHandler
{
    public const string Code = "SUBJECT_HAS_TITLE";
    protected override string ParamKey => "Titles";
    protected override AttributeId Attribute { get; } = AttributeId.Subject(SubjectAttributes.Title);
    protected override string Noun => "unvan";
    protected override bool SingleValue => true;
    protected override IEnumerable<string> FactValues(IdentityFacts f) => f.Title is null ? [] : [f.Title];
    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcı unvanı", "Kullanıcının unvanı verilenlerden biri (tam eşleşme).", ConditionScope.Global,
        [new("Titles", "Unvanlar", "list", true, null, "ör. Stajyer Gişe Asistanı")], [AttributeId.Subject(SubjectAttributes.Title).ToString()]);
}

/// <summary>Kullanıcının biriminin tipi (grup ORG_UNIT_TYPE kriteri ile aynı).</summary>
public sealed class SubjectUnitTypeConditionHandler : SubjectValueInListConditionHandler
{
    public const string Code = "SUBJECT_UNIT_TYPE";
    protected override string ParamKey => "Types";
    protected override AttributeId Attribute { get; } = AttributeId.Subject(SubjectAttributes.OrgUnitTypes);
    protected override string Noun => "birim tipi";
    protected override IEnumerable<string> FactValues(IdentityFacts f) => f.UnitTypes;
    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcının birim tipi", "Kullanıcının biriminin tipi verilenlerden biri (Branch, Department, Region, HeadOffice).", ConditionScope.Global,
        [new("Types", "Birim tipleri", "list", true, null, "ör. Branch")], [AttributeId.Subject(SubjectAttributes.OrgUnitTypes).ToString()]);
}

/// <summary>Kullanıcı bu kurumda veya alt kurumunda (grup TENANT kriteri ile aynı).</summary>
public sealed class SubjectInTenantConditionHandler : SubjectValueInListConditionHandler
{
    public const string Code = "SUBJECT_IN_TENANT";
    protected override string ParamKey => "Tenants";
    protected override AttributeId Attribute { get; } = AttributeId.Subject(SubjectAttributes.TenantChain);
    protected override string Noun => "kurum";
    protected override IEnumerable<string> FactValues(IdentityFacts f) => f.TenantChain;
    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcının kurumu (alt kurumlar dahil)", "Kullanıcı verilen kurumlardan birinde veya onun alt kurumunda.", ConditionScope.Global,
        [new("Tenants", "Kurumlar", "list", true, null, "ör. ABANK")], [AttributeId.Subject(SubjectAttributes.TenantChain).ToString()]);
}

/// <summary>Kimlik türü: kişi veya servis hesabı (grup USER_KIND kriteri ile aynı).</summary>
public sealed class SubjectKindConditionHandler : SubjectValueInListConditionHandler
{
    public const string Code = "SUBJECT_KIND";
    protected override string ParamKey => "Kinds";
    protected override AttributeId Attribute { get; } = AttributeId.Subject(SubjectAttributes.Kind);
    protected override string Noun => "kimlik türü";
    protected override bool SingleValue => true;
    protected override IEnumerable<string> FactValues(IdentityFacts f) => [f.Kind];
    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kimlik türü", "Kullanıcı kişi (Person) veya servis hesabı (ServiceAccount).", ConditionScope.Global,
        [new("Kinds", "Türler", "list", true, null, "Person veya ServiceAccount")], [AttributeId.Subject(SubjectAttributes.Kind).ToString()]);
}

/// <summary>
/// Kullanıcı verilen kişilerden biri mi? Klasik RBAC'taki "doğrudan kişiye atanmış yetki"nin karşılığı: kişiler KİM kartında
/// rol ve gruplarla birlikte (VEYA) yazılır; ayrı kullanıcı policy'si gerekmez.
/// </summary>
public sealed class SubjectIsUserConditionHandler : ConditionHandlerBase, IIdentityCondition
{
    public const string Code = "SUBJECT_IS_USER";
    public override ConditionQuestion? Question => ConditionQuestion.Who;
    private static readonly AttributeId UserName = AttributeId.Subject(SubjectAttributes.UserName);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcı", "Kullanıcı verilen kişilerden biri.", ConditionScope.Global,
        [new("Users", "Kullanıcılar", "list", true, null, "kullanıcı adları, ör. sibel.ates,ali.demir")],
        [UserName.ToString()]);

    public bool EvaluateIdentity(IReadOnlyDictionary<string, string> parameters, IdentityFacts facts, out string because)
    {
        var hit = ListParam(parameters, "Users").Any(u => string.Equals(u, facts.UserName, StringComparison.OrdinalIgnoreCase));
        because = hit ? $"kullanıcı {facts.UserName} (policy'de adıyla)" : "";
        return hit;
    }

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var name = await ctx.Attributes.GetStringAsync(UserName, ct);
        if (name is null) return ConditionResult.Missing(UserName);
        var users = ConditionEvaluationContext.SplitList(ctx.Param("Users"));
        return ConditionResult.Of(users.Contains(name, StringComparer.OrdinalIgnoreCase), $"Kullanıcı {name} listede.", $"Kullanıcı {name} listede değil.");
    }
}