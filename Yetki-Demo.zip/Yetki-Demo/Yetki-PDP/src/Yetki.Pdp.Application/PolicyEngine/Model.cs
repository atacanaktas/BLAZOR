using System.Text.Json.Serialization;
using Yetki.Pdp.Application.PolicyEngine.Attributes;
using Yetki.Pdp.Application.PolicyEngine.Conditions;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.PolicyEngine;

/// <summary>Karar durumu (XACML / AuthZEN kavramları).</summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum DecisionType
{
    Permit = 1,
    Deny = 2,
    /// <summary>Etkisiz: bu girdi karara katılmadı (pasif kural, ReportOnly/Advisory policy, uygulanmayan permission).</summary>
    NotApplicable = 3,
    /// <summary>Karar verilemedi (eksik attribute, hata). Enforcement tarafında İZİN VERİLMEZ (fail-closed).</summary>
    Indeterminate = 4
}

/// <summary>
/// Condition ağacı (bellek içi). Id negatifse What-If taslağıdır.
/// Kind=Reference: başka bir policy koşul olarak kullanılır. ReferencePolicyId = policy (bulunamadıysa boş → Indeterminate),
/// ReferenceCode = policy kodu. Policy değerlendirmesi: Permit → doğru, Deny → yanlış, diğerleri → belirsiz.
/// </summary>
public sealed record ConditionNode(
    int Id,
    ConditionKind Kind,
    string? ConditionTypeCode,
    bool TypeAvailable,
    IReadOnlyDictionary<string, string> Parameters,
    IReadOnlyList<ConditionNode> Children,
    string? ReferenceCode = null,
    int? ReferenceVersion = null,
    int? ReferencePolicyId = null);

/// <summary>Referans verilen policy'nin bu istekteki sonucu (logic uygulanmış; mod dikkate alınmaz — referans bir yapı taşıdır).</summary>
public sealed record PolicyReferenceResult(DecisionType Result, string Detail, IReadOnlyList<string>? MissingAttributes);

/// <summary>Reference düğümü için policy değerlendirici (karar akışı verir; döngü / derinlik korumalı).</summary>
public delegate Task<PolicyReferenceResult> PolicyReferenceEvaluator(int policyId, CancellationToken ct);

/// <summary>Condition policy içindeki tek koşul (gereksinim). ReasonCode: sağlanmadığında dönen neden.</summary>
public sealed record RuleDefinition(
    int RuleId, string Code, string Name, string? Description, int Order, string? ReasonCode,
    bool IsActive, ConditionNode? Condition);

/// <summary>Condition policy'nin kural seti ve kuralları birleştirme stratejisi.</summary>
public sealed record PolicyDefinition(
    int PolicyId, string Code, string Name, int Version, DecisionStrategy Strategy, IReadOnlyList<RuleDefinition> Rules);

public sealed record ConditionTrace(
    ConditionKind Kind,
    string? ConditionType,
    string Expression,
    TriState Value,
    string? Message,
    IReadOnlyList<string>? MissingAttributes,
    IReadOnlyList<UsedAttribute>? Evidence,
    IReadOnlyList<ConditionTrace>? Children);

/// <summary>Rule sonucu. Result: Permit = sağlandı · Deny = sağlanmadı · Indeterminate = belirsiz · NotApplicable = pasif.</summary>
public sealed record RuleEvaluation(
    int RuleId,
    string Code,
    string Name,
    int Order,
    bool IsActive,
    TriState ConditionValue,
    DecisionType Result,
    string? ReasonCode,
    string Message,
    string Expression,
    ConditionTrace? Condition,
    IReadOnlyList<string> MissingAttributes,
    IReadOnlyList<UsedAttribute> Evidence)
{
    public bool IsDeciding { get; init; }
}

/// <summary>Condition policy'nin kural değerlendirmesi (logic uygulanmadan önceki ham sonuç).</summary>
public sealed record RuleSetEvaluation(DecisionType Result, string? DecidingRule, IReadOnlyList<RuleEvaluation> Rules);
