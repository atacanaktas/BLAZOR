using System.Globalization;
using Yetki.Pdp.Application.Context;
using Yetki.Pdp.Application.Model;

namespace Yetki.Pdp.Application.PolicyEngine.Attributes;

/// <summary>Attribute kategorisi (NIST ABAC: subject / resource / action / environment + iş bağlamı).</summary>
public enum AttributeCategory
{
    Subject = 1,
    Resource = 2,
    Action = 3,
    /// <summary>Motor/platform tarafından güvenilir şekilde üretilen ortam bilgisi (zaman, IP, kanal, client, cihaz).</summary>
    Environment = 4,
    /// <summary>İş bağlamı: SDK'da DTO attribute'u ile gelen değerler (tutar, müşteri, şube...).</summary>
    Context = 5,
    /// <summary>İşlemdeki müşterinin öznitelikleri (VIP, personel müşterisi...): PIP'ten, istekten DEĞİL.</summary>
    Customer = 6
}

public readonly record struct AttributeId(AttributeCategory Category, string Name)
{
    public override string ToString() => $"{Category}.{Name}";

    public static AttributeId Subject(string name) => new(AttributeCategory.Subject, name);
    public static AttributeId Env(string name) => new(AttributeCategory.Environment, name);
    public static AttributeId Ctx(string name) => new(AttributeCategory.Context, name);
    public static AttributeId Customer(string name) => new(AttributeCategory.Customer, name);

    public static AttributeId ForRequestKey(string key) => AuthContextKeys.IsEnvironment(key) ? Env(key) : Ctx(key);
}

/// <summary>Çözülmüş değer. Value=null → kaynak "bilinen boş" diyor. Provider çözemediyse AttributeValue'nun kendisi null (→ Indeterminate).</summary>
public sealed record AttributeValue(string? Value, string Source);

public sealed record SubjectRef(int UserId, string UserName);

public sealed record ResourceRef(string? Type, string? Id)
{
    public override string ToString() => Type is null ? Id ?? "" : $"{Type}:{Id}";
}

/// <summary>Attribute çözümlemesi için istek kapsamı. Model: kararın verildiği (gerçek veya What-If) yetki modeli.</summary>
public sealed class AttributeResolutionScope
{
    public required SubjectRef Subject { get; init; }
    public required AuthorizationContext Context { get; init; }
    public required string Action { get; init; }
    public ResourceRef? Resource { get; init; }
    public required AuthorizationModel Model { get; init; }
    public required DateTime Now { get; init; }
}

/// <summary>
/// Attribute değer kaynağı. Policy motoru değerin nereden geldiğini bilmez: bugün yetki modeli / istek bağlamı,
/// yarın HR, limit yönetimi, core banking servisleri. Yeni kaynak = yeni provider + DI kaydı (kayıt sırası önceliktir).
/// </summary>
public interface IAttributeValueProvider
{
    string Name { get; }
    bool CanResolve(AttributeId id);
    ValueTask<AttributeValue?> ResolveAsync(AttributeId id, AttributeResolutionScope scope, CancellationToken ct);
}

/// <summary>Çözebildiği özniteliklerin TEK kaynağı: sonuç vermezse başka kaynağa bakılmaz (değer belirsiz kalır).</summary>
public interface IExclusiveAttributeProvider : IAttributeValueProvider;

public sealed record UsedAttribute(string Attribute, string? Value, string Source, bool Resolved);

/// <summary>Hassas değerlerin audit/log'a nasıl yazılacağı. Karar daima gerçek değerle verilir.</summary>
public interface IAttributeRedactor
{
    string? Redact(string attribute, string? value);
}

public sealed class DefaultAttributeRedactor : IAttributeRedactor
{
    private readonly HashSet<string> _sensitive = new(
        ["Context.CustomerId", "Context.AccountNo", "Subject.CustomerId", "Environment.DeviceId"], StringComparer.OrdinalIgnoreCase);

    public string? Redact(string attribute, string? value)
    {
        if (value is null || !_sensitive.Contains(attribute)) return value;
        return value.Length <= 2 ? "**" : new string('*', value.Length - 2) + value[^2..];
    }
}

/// <summary>Tek değerlendirme boyunca attribute'ları çözer, önbelleğe alır ve hangi değerin kullanıldığını kaydeder.</summary>
public sealed class AttributeResolver(IReadOnlyList<IAttributeValueProvider> providers, AttributeResolutionScope scope)
{
    private readonly Dictionary<AttributeId, AttributeValue?> _cache = new();
    private readonly List<UsedAttribute> _used = new();

    public AttributeResolutionScope Scope => scope;
    public IReadOnlyList<UsedAttribute> Used => _used;

    public async ValueTask<AttributeValue?> GetAsync(AttributeId id, CancellationToken ct)
    {
        if (!_cache.TryGetValue(id, out var value))
        {
            value = null;
            foreach (var p in providers.Where(p => p.CanResolve(id)))
            {
                value = await p.ResolveAsync(id, scope, ct);
                // Yetkili kaynak çözemediyse sıradaki kaynağa (ör. istek bağlamına) DÜŞÜLMEZ: değer taklit edilemesin.
                if (value is not null || p is IExclusiveAttributeProvider) break;
            }
            _cache[id] = value;
        }
        _used.Add(new UsedAttribute(id.ToString(), value?.Value, value?.Source ?? "unresolved", value is not null));
        return value;
    }

    public async ValueTask<string?> GetStringAsync(AttributeId id, CancellationToken ct) =>
        (await GetAsync(id, ct)) is { Value: { Length: > 0 } v } ? v : null;

    public async ValueTask<decimal?> GetDecimalAsync(AttributeId id, CancellationToken ct) =>
        AuthorizationContext.TryParseDecimal(await GetStringAsync(id, ct), out var d) ? d : null;

    public async ValueTask<bool?> GetBoolAsync(AttributeId id, CancellationToken ct) =>
        bool.TryParse(await GetStringAsync(id, ct), out var b) ? b : null;

    public async ValueTask<DateTime?> GetDateTimeUtcAsync(AttributeId id, CancellationToken ct)
    {
        var s = await GetStringAsync(id, ct);
        return s is not null && DateTimeOffset.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var dto)
            ? dto.UtcDateTime : null;
    }
}

/// <summary>İstek bağlamı (Environment + Context + Action) ve subject kimliği.</summary>
public sealed class RequestContextAttributeProvider : IAttributeValueProvider
{
    public string Name => "Request";

    public bool CanResolve(AttributeId id) =>
        id.Category is AttributeCategory.Environment or AttributeCategory.Context or AttributeCategory.Action or AttributeCategory.Resource;

    public ValueTask<AttributeValue?> ResolveAsync(AttributeId id, AttributeResolutionScope scope, CancellationToken ct)
    {
        AttributeValue? v = id.Category switch
        {
            AttributeCategory.Action => new AttributeValue(scope.Action, "Request"),
            AttributeCategory.Resource when id.Name == "Type" => new AttributeValue(scope.Resource?.Type, "Request"),
            AttributeCategory.Resource when id.Name == "Id" => new AttributeValue(scope.Resource?.Id, "Request"),
            _ => scope.Context.GetString(id.Name) is { } s
                ? new AttributeValue(s, id.Name is AuthContextKeys.CurrentTime or AuthContextKeys.ClientId ? "Engine" : "Request")
                : null
        };
        return ValueTask.FromResult(v);
    }
}

/// <summary>
/// Subject attribute'larını yetki modelinden çözer (kullanıcı kaydı, birim hiyerarşisi, etkin roller/gruplar).
/// Üretimde bunun ÖNÜNE HR / limit servisi provider'ları eklenebilir (ör. CashWithdrawalLimit gerçek limit sisteminden).
/// </summary>
public sealed class ModelSubjectAttributeProvider : IAttributeValueProvider
{
    public string Name => "AuthorizationModel";

    public bool CanResolve(AttributeId id) => id.Category == AttributeCategory.Subject;

    public ValueTask<AttributeValue?> ResolveAsync(AttributeId id, AttributeResolutionScope scope, CancellationToken ct)
    {
        var m = scope.Model;
        if (!m.Users.TryGetValue(scope.Subject.UserId, out var u)) return ValueTask.FromResult<AttributeValue?>(null);

        string? value;
        switch (id.Name)
        {
            case SubjectAttributes.UserName: value = u.UserName; break;
            case SubjectAttributes.Tenant: value = m.Tenants[u.TenantId].Code; break;
            case SubjectAttributes.Title: value = u.Title; break;
            case SubjectAttributes.Kind: value = u.Kind.ToString(); break;
            case SubjectAttributes.CustomerId: value = u.CustomerNo; break;
            case SubjectAttributes.OrgUnitCodes: value = string.Join(",", m.UnitCodesOf(u.Id)); break;
            case SubjectAttributes.OrgUnitScope: value = string.Join(",", m.UnitScopeOf(u.Id)); break;
            case SubjectAttributes.OrgUnitAncestry: value = string.Join(",", m.UnitAncestryOf(u.Id)); break;
            case SubjectAttributes.RoleCodes: value = string.Join(",", m.GetIdentity(u.Id, scope.Now).Roles.Select(r => r.Code)); break;
            case SubjectAttributes.GroupCodes: value = string.Join(",", m.GetIdentity(u.Id, scope.Now).Groups.Select(g => g.Code)); break;
            case SubjectAttributes.TenantChain: value = string.Join(",", m.TenantAncestors[u.TenantId].Select(m.TenantCode)); break;
            case SubjectAttributes.OrgUnitTypes: value = string.Join(",", m.UnitsOf(u.Id).Select(x => x.Type.ToString()).Distinct()); break;
            default: return ValueTask.FromResult<AttributeValue?>(null);
        }
        return ValueTask.FromResult<AttributeValue?>(new AttributeValue(value, Name));
    }
}

/// <summary>
/// Kimlik dışı öznitelikler PIP'ten (iş takvimi, izin, müşteri). YETKİLİ TEK KAYNAK: istek bağlamında aynı adla değer gönderilse de
/// kullanılmaz; PIP cevap veremezse değer belirsiz kalır ve koşul Indeterminate olur (kapalı başarısızlık).
///  - Environment.IsBusinessDay: karar anının günü (İstanbul) iş günü mü
///  - Subject.IsOnLeave: kullanıcı o gün izinde mi
///  - Customer.IsVip / Customer.IsStaff: işlemdeki müşteri (Context.CustomerId)
/// </summary>
public sealed class PipAttributeProvider(Identity.IExternalAttributeSource source, Microsoft.Extensions.Logging.ILogger<PipAttributeProvider> logger)
    : IExclusiveAttributeProvider
{
    public string Name => "PIP";

    public bool CanResolve(AttributeId id) =>
        (id.Category == AttributeCategory.Environment && id.Name == EnvironmentAttributes.IsBusinessDay)
        || (id.Category == AttributeCategory.Subject && id.Name is SubjectAttributes.IsOnLeave or SubjectAttributes.CashWithdrawalLimit
            or SubjectAttributes.DailyCashLimit or SubjectAttributes.CashUsedToday)
        || id.Category == AttributeCategory.Customer;

    public async ValueTask<AttributeValue?> ResolveAsync(AttributeId id, AttributeResolutionScope scope, CancellationToken ct)
    {
        try
        {
            if (id.Category == AttributeCategory.Environment)
            {
                var r = await source.BusinessDayAsync(LocalDate(scope.Now), ct);
                return new AttributeValue(r.IsBusinessDay.ToString(), $"PIP:{r.Source}");
            }
            if (id.Category == AttributeCategory.Subject && id.Name == SubjectAttributes.IsOnLeave)
            {
                var r = await source.LeaveAsync(scope.Subject.UserId, LocalDate(scope.Now), ct);
                return new AttributeValue(r.OnLeave.ToString(), $"PIP:{r.Source}");
            }
            if (id.Category == AttributeCategory.Subject)
            {
                var l = await source.CashLimitAsync(scope.Subject.UserId, LocalDate(scope.Now), ct);
                var amount = id.Name switch
                {
                    SubjectAttributes.CashWithdrawalLimit => l.PerTransactionLimit,
                    SubjectAttributes.DailyCashLimit => l.DailyLimit,
                    _ => l.UsedToday
                };
                return new AttributeValue(amount.ToString(CultureInfo.InvariantCulture), $"PIP:{l.Source}");
            }
            var customerNo = scope.Context.GetString(AuthContextKeys.CustomerId);
            if (customerNo is null) return null;   // müşteri yok → koşul "eksik öznitelik"
            var c = await source.CustomerAsync(customerNo, ct);
            string? value = id.Name switch
            {
                CustomerAttributes.IsVip => c.IsVip.ToString(),
                CustomerAttributes.IsStaff => c.IsStaff.ToString(),
                _ => null
            };
            return value is null ? null : new AttributeValue(value, $"PIP:{c.Source}");
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            Microsoft.Extensions.Logging.LoggerExtensions.LogWarning(logger, ex, "PIP özniteliği çözülemedi: {Attribute}", id);
            return null;
        }
    }

    private static readonly TimeZoneInfo Istanbul = FindIstanbul();

    private static DateOnly LocalDate(DateTime utc) =>
        DateOnly.FromDateTime(TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(utc, DateTimeKind.Utc), Istanbul));

    private static TimeZoneInfo FindIstanbul()
    {
        try { return TimeZoneInfo.FindSystemTimeZoneById("Europe/Istanbul"); }
        catch (TimeZoneNotFoundException) { return TimeZoneInfo.FindSystemTimeZoneById("Turkey Standard Time"); }
    }
}