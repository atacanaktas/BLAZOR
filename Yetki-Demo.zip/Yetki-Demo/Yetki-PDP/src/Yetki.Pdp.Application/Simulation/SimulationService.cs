using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Changes;
using Yetki.Pdp.Application.Evaluation;
using Yetki.Pdp.Application.Governance;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.Simulation;

/// <summary>
/// Analiz kararı: gerçek karar motoru, istenirse taslak değişikliklerle (What-If) ve/veya geçmiş/gelecek bir an için.
/// Değişiklik yoksa güncel model kullanılır. Caller verilirse "şu client sorsaydı" kapsam kuralları da uygulanır.
/// </summary>
public sealed class SimulatedEvaluateRequest
{
    public AuthorizationRequest Request { get; set; } = new();
    public AuthorizationChangeSet? Changes { get; set; }
    public PolicyChangeSet? PolicyChanges { get; set; }
    public List<ModelPatchOperation>? Patch { get; set; }
    /// <summary>Kararın hangi an için simüle edileceği (UTC). Boşsa şimdi.</summary>
    public DateTime? AsOfUtc { get; set; }
    /// <summary>Audit'te simülasyon olarak işaretlensin mi? Boşsa: taslak değişiklik veya AsOfUtc varsa simülasyon.</summary>
    public bool? IsSimulation { get; set; }
    /// <summary>Audit'e yazılacak aktör (PAP'taki kullanıcı). Boşsa "yetki-konsol".</summary>
    public string? Actor { get; set; }
}

public sealed class SodRuleImpactRequest
{
    public string Code { get; set; } = "DRAFT";
    public SodEnforcement Enforcement { get; set; } = SodEnforcement.Block;
    public List<int> ResourceScopeIds { get; set; } = new();
    public List<int> RoleIds { get; set; } = new();
}

/// <summary>What-If. KENDİ karar mantığı yoktur: aynı model kurucusu, aynı evaluator, aynı etki analizi.</summary>
public sealed class SimulationService(
    ImpactAnalysisService impact,
    AuthorizationEvaluator evaluator,
    AuthorizationModelProvider models,
    PolicyImpactService policyImpact,
    SodService sod)
{
    public Task<ChangeImpactResult> ImpactAsync(ImpactRequest request, CancellationToken ct) => impact.AnalyzeAsync(request, ct);

    public async Task<AuthorizationDecision> EvaluateAsync(SimulatedEvaluateRequest request, CancellationToken ct)
    {
        var simulated = request.Changes is { IsEmpty: false } || request.PolicyChanges is { IsEmpty: false } || request.Patch is { Count: > 0 };
        var model = await models.BuildWhatIfAsync(request.Changes, request.PolicyChanges, request.Patch, ct);
        return await evaluator.EvaluateAsync(request.Request, new EvaluationOptions
        {
            Model = model, AsOfUtc = request.AsOfUtc, IsSimulation = request.IsSimulation ?? (simulated || request.AsOfUtc is not null), WriteAudit = true,
            Actor = string.IsNullOrWhiteSpace(request.Actor) ? "yetki-konsol" : request.Actor
        }, ct);
    }

    public Task<PolicyImpactResult> PolicyImpactAsync(PolicyImpactRequest request, CancellationToken ct) => policyImpact.AnalyzeAsync(request, ct);

    public async Task<IReadOnlyList<SodUserConflicts>> SodRuleImpactAsync(SodRuleImpactRequest request, CancellationToken ct)
    {
        var members = request.ResourceScopeIds.Select(id => (SodMemberType.ResourceScope, id)).Concat(request.RoleIds.Select(id => (SodMemberType.Role, id))).ToList();
        if (members.Count < 2) throw new ValidationException("SoD kuralı en az 2 üye içermelidir.");
        var model = await models.GetCurrentAsync(ct);
        return await sod.SimulateRuleAsync(SodService.Snapshot(model, 0, request.Code, request.Code, Severity.High, request.Enforcement, members), ct);
    }
}
