using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Application.PolicyEngine;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.Evaluation;

public sealed class EntitlementRequest
{
    public string User { get; set; } = default!;
    /// <summary>OAuth client. Verilirse Client (kanal) policy'leri de kesinleşir.</summary>
    public string? Client { get; set; }
    /// <summary>UI resource ağacı (menü / ekran / buton) istenecek uygulama (ör. NEXTRAL).</summary>
    public string? Application { get; set; }
    /// <summary>true: koşullu yetkiler için verilen bağlamla (IP, kanal...) şu anki karar da hesaplanır (buton gri/aktif ipucu).</summary>
    public bool Evaluate { get; set; }
    public Dictionary<string, string?> Context { get; set; } = new();
    /// <summary>Soran (doğrulanmış) client; /api/v1 uçlarında token'dan doldurulur. Boşsa iç çağrı (konsol): kapsam uygulanmaz.</summary>
    public string? Caller { get; set; }
}

public sealed record RuntimeCheck(DecisionType Decision, string ReasonCode, string Reason);

public sealed record EntitledAccess(
    int ResourceScopeId, string Key, string Name, string Application, string Resource, string ResourceType, string Scope, string Path,
    Severity RiskLevel, IReadOnlyList<string> Sources, bool Conditional, IReadOnlyList<string> Conditions, RuntimeCheck? Runtime);

public sealed record UiScopeEntitlement(string Scope, string Key, bool Enabled, string Reason, RuntimeCheck? Runtime);

public sealed record UiEntitlement(
    int ResourceId, string Code, string Name, string ResourceType, string? ParentCode, int Order, string Path,
    bool Enabled, string Reason, IReadOnlyList<UiScopeEntitlement> Scopes);

public sealed class EntitlementResult
{
    public string UserName { get; init; } = default!;
    public string FullName { get; init; } = default!;
    public string Tenant { get; init; } = default!;
    public string? Client { get; init; }
    public long ModelVersion { get; init; }
    public DateTime ComputedAt { get; init; }
    /// <summary>İstemci önbelleği için: model versiyonu + kullanıcı + client. Değişmediyse istemci eski listeyi kullanabilir.</summary>
    public string ETag { get; init; } = default!;
    public IReadOnlyList<EntitledAccess> Accesses { get; init; } = [];
    public IReadOnlyList<UiEntitlement> UiResources { get; init; } = [];
}

/// <summary>
/// Login-time toplu yetki listesi (Nextral gibi masaüstü istemciler menü / ekran / buton açıp kapamak için).
/// Liste STATİKTİR. Koşullu (Condition policy'li) yetkiler Conditional=true döner: istemci butonu açsa bile işlem anında
/// PDP tekrar karar verir (asıl güvenlik sunucudadır). Evaluate=true ile "şu an" kararı da ipucu olarak döner.
/// UI resource'ları: HTTP ile eşleşmeyen tiplerdeki resource'lar; üst öğe kapalıysa alt öğe de kapalıdır.
/// </summary>
public sealed class EntitlementService(AuthorizationModelProvider models, AuthorizationEvaluator evaluator, IClock clock)
{
    public async Task<EntitlementResult> GetAsync(EntitlementRequest request, CancellationToken ct = default)
    {
        var model = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        if (!model.UserIdByName.TryGetValue(request.User.Trim(), out var userId)) throw new NotFoundException("Kullanıcı", request.User);
        var user = model.Users[userId];

        // Soran (caller): kapsamı dışındaki kullanıcı / uygulama için liste veremez; başka client adına sadece yetkili aracı sorabilir
        ClientRow? caller = null;
        if (!string.IsNullOrWhiteSpace(request.Caller))
        {
            if (!model.ClientsById.TryGetValue(request.Caller.Trim(), out caller) || !caller.IsActive)
                throw new ForbiddenException("CALLER_UNKNOWN", $"Soran '{request.Caller}' kayıtlı veya aktif bir client değil.");
            if (string.IsNullOrWhiteSpace(request.Client)) request.Client = caller.ClientId;
            else if (!string.Equals(request.Client.Trim(), caller.ClientId, StringComparison.OrdinalIgnoreCase)
                     && !(model.ClientsById.TryGetValue(request.Client.Trim(), out var original) && model.CallerMaySpeakFor(caller, original)))
                throw new ForbiddenException("CLIENT_ASSERTION_NOT_ALLOWED", $"'{caller.ClientId}', '{request.Client}' adına soru soramaz.");
            if (!model.CallerMayAskTenant(caller, user.TenantId))
                throw new ForbiddenException("CALLER_TENANT_SCOPE", $"'{caller.ClientId}' client'ının soru kapsamında '{model.TenantCode(user.TenantId)}' kurumu yok.");
            if (!string.IsNullOrWhiteSpace(request.Application) && model.AppByCode.TryGetValue(request.Application.Trim(), out var askedApp)
                && !model.CallerMayAskApplication(caller, askedApp.Id))
                throw new ForbiddenException("CALLER_APP_SCOPE", $"'{caller.ClientId}' client'ının soru kapsamında '{askedApp.Code}' uygulaması yok.");
        }

        ClientRow? client = null;
        if (!string.IsNullOrWhiteSpace(request.Client) && (!model.ClientsById.TryGetValue(request.Client.Trim(), out client) || !client.IsActive))
            throw new NotFoundException("Client", request.Client);
        if (client is { Type: ClientType.Intermediary })
            throw new ValidationException($"'{client.ClientId}' bir aracıdır (gateway/BFF); entitlement orijinal client için istenmeli.");
        if (client is not null && !model.IsAvailableIn(client.TenantId, user.TenantId))
            throw new ValidationException($"'{client.ClientId}' client'ı {model.TenantCode(client.TenantId)} tenant'ında kayıtlı; {model.TenantCode(user.TenantId)} kullanıcıları için kullanılamaz.");

        var identity = model.GetIdentity(userId, now);
        var accesses = new List<EntitledAccess>();
        foreach (var rs in model.ResourceScopes.Values.OrderBy(x => x.Key, StringComparer.Ordinal))
        {
            if (caller is not null && !model.CallerMayAskApplication(caller, rs.App.Id)) continue;   // soranın kapsamı dışındaki uygulamalar listelenmez
            var a = user.IsActive ? model.EvaluateAccessStatic(rs, identity, client) : null;
            if (a is null) continue;
            RuntimeCheck? runtime = null;
            if (request.Evaluate && a.Conditional)
            {
                var decision = await evaluator.EvaluateAsync(new AuthorizationRequest
                {
                    Subject = new SubjectInfo { UserId = userId }, AccessKey = a.Key, Client = client?.ClientId, Context = request.Context
                }, new EvaluationOptions { Model = model, WriteAudit = false }, ct);
                runtime = new RuntimeCheck(decision.Decision, decision.ReasonCode, decision.HumanReadableReason);
            }
            accesses.Add(new EntitledAccess(a.ResourceScopeId, a.Key, a.Name, a.Application, a.Resource, a.ResourceType, a.Scope, a.Path,
                a.RiskLevel, a.Sources.Select(s => s.Path).ToList(), a.Conditional, a.Conditions, runtime));
        }

        var ui = new List<UiEntitlement>();
        if (!string.IsNullOrWhiteSpace(request.Application) && model.AppByCode.TryGetValue(request.Application.Trim(), out var app))
        {
            var byId = accesses.ToDictionary(a => a.ResourceScopeId);
            var resources = model.Resources.Values.Where(r => r.ApplicationId == app.Id && !model.ResourceTypes[r.ResourceTypeId].MatchesHttp).ToList();
            var byResource = resources.ToDictionary(r => r.Id);
            var enabled = new Dictionary<int, bool>();
            foreach (var r in resources.OrderBy(r => Depth(r)).ThenBy(r => r.Order).ThenBy(r => r.Code, StringComparer.Ordinal))
            {
                var parentOn = r.ParentId is not { } pid || !byResource.ContainsKey(pid) || enabled.GetValueOrDefault(pid, true);
                var scopes = model.ScopesOf(r.Id).OrderBy(s => s.Scope.Code, StringComparer.Ordinal).Select(s =>
                {
                    if (!parentOn) return new UiScopeEntitlement(s.Scope.Code, s.Key, false, "Üst menü/ekran kapalı.", null);
                    if (!r.IsActive) return new UiScopeEntitlement(s.Scope.Code, s.Key, false, "Resource pasif.", null);
                    if (!byId.TryGetValue(s.Id, out var ent)) return new UiScopeEntitlement(s.Scope.Code, s.Key, false, "Yetki yok.", null);
                    if (ent.Runtime is { } rt)
                        return new UiScopeEntitlement(s.Scope.Code, s.Key, rt.Decision == DecisionType.Permit,
                            rt.Decision == DecisionType.Permit ? "Yetkili; şu an koşullar sağlanıyor." : $"Yetkili ama şu an kullanılamaz: {rt.Reason}", rt);
                    return new UiScopeEntitlement(s.Scope.Code, s.Key, true,
                        ent.Conditional ? $"Yetkili; işlem anında koşul kontrolü ({string.Join(", ", ent.Conditions)})." : "Yetkili.", null);
                }).ToList();
                var on = scopes.Any(s => s.Enabled);
                enabled[r.Id] = on;
                ui.Add(new UiEntitlement(r.Id, r.Code, r.Name, model.ResourceTypes[r.ResourceTypeId].Code,
                    r.ParentId is { } par && byResource.TryGetValue(par, out var parent) ? parent.Code : null, r.Order,
                    model.PathOf(r.Id),
                    on, !parentOn ? "Üst menü/ekran kapalı." : on ? "Görünür." : scopes.Count == 0 ? "Scope tanımlı değil." : "Yetki yok.", scopes));
            }

            int Depth(ResourceRow r)
            {
                var depth = 0;
                var cur = r;
                while (cur.ParentId is { } p && depth < 10 && byResource.TryGetValue(p, out var parent)) { depth++; cur = parent; }
                return depth;
            }
        }

        return new EntitlementResult
        {
            UserName = user.UserName,
            FullName = user.FullName,
            Tenant = model.TenantCode(user.TenantId),
            Client = client?.ClientId,
            ModelVersion = model.Version,
            ComputedAt = now,
            ETag = $"\"{model.Version}-{userId}-{client?.Id ?? 0}\"",
            Accesses = accesses,
            UiResources = ui
        };
    }
}
