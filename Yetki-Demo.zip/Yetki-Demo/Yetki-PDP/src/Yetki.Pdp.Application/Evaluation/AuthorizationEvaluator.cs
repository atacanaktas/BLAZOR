using System.Diagnostics;
using System.Globalization;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Audit;
using Yetki.Pdp.Application.Common;
using Yetki.Pdp.Application.Context;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Application.PolicyEngine;
using Yetki.Pdp.Application.PolicyEngine.Attributes;
using Yetki.Pdp.Domain.Common;
using Yetki.Pdp.Domain.Governance;

namespace Yetki.Pdp.Application.Evaluation;

/// <summary>
/// Yetkilendirme karar noktası (PDP) — Keycloak Authorization Services akışı + gömülü ABAC:
///
///   0 Subject      kimlik: kullanıcı (veya servis client'ının servis hesabı) var ve aktif mi?
///   1 Tenant       istek tenant'ı geçerli mi, kullanıcı bu tenant'a mı ait, kaydın tenant'ı aynı mı? (tenant izolasyonu)
///   2 Client       client kayıtlı/aktif mi, bu tenant'ta kullanılabilir mi? Aracı zinciri geçerli mi?
///   3 Resource     HTTP (METHOD + URI deseni) veya resource + scope → YETKİ (resource:scope). Tanımsızsa DENY.
///   4 Permission   bu yetkiye uygulanan permission'lar; yoksa DENY (varsayılan kapalı)
///   5 Policy       her permission policy'lerini (rol / grup / kullanıcı / client / condition / aggregate) stratejisiyle birleştirir
///   Karar          uygulamanın stratejisiyle (varsayılan Unanimous: hepsi izin vermeli) permission sonuçları → PERMIT / DENY /
///                  INDETERMINATE (belirsiz → izin yok, fail-closed)
///
/// Gerçek karar ve What-If aynı metodu kullanır (model parametresi ile).
/// </summary>
public sealed class AuthorizationEvaluator(
    AuthorizationModelProvider models,
    PolicyEvaluator ruleEvaluator,
    IEnumerable<IAttributeValueProvider> attributeProviders,
    IAttributeRedactor redactor,
    IOptions<AuthorizationEngineOptions> engineOptions,
    AuditWriter audit,
    IYetkiDbContext db,
    IClock clock,
    ILogger<AuthorizationEvaluator> logger)
{
    private readonly IReadOnlyList<IAttributeValueProvider> _providers = attributeProviders.ToList();

    public async Task<AuthorizationDecision> EvaluateAsync(AuthorizationRequest request, EvaluationOptions? options = null, CancellationToken ct = default)
    {
        options ??= EvaluationOptions.Default;
        var sw = Stopwatch.StartNew();
        var model = options.Model ?? await models.GetCurrentAsync(ct);
        var now = options.IsSimulation && options.AsOfUtc is { } asOf ? asOf.ToUniversalTime() : clock.UtcNow;

        var decision = new AuthorizationDecision
        {
            DecisionId = Guid.NewGuid(),
            EvaluatedAt = now,
            IsSimulation = options.IsSimulation || model.IsSimulation,
            ModelVersion = model.Version,
            Client = string.IsNullOrWhiteSpace(request.Client) ? null : Codes.Lower(request.Client),
            Resource = request.Resource?.Id is null ? null : new ResourceRef(request.Resource.Type, request.Resource.Id).ToString(),
            Http = request.Http is null ? null : $"{request.Http.Method.ToUpperInvariant()} {request.Http.Path}"
        };
        // 0) Soran (caller): kimliği doğrulanmış tüketici. İsteği başlatan client'ı belirler (aracı başkası adına konuşabilir).
        var caller = ResolveCaller(request, model, decision);
        var context = BuildContext(request, decision.Client, now);
        decision.Context = context.Values;

        try
        {
            if (decision.ReasonCode is null) await EvaluateCoreAsync(request, model, now, context, decision, caller, ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogError(ex, "Authorization evaluation failed for {User}/{AccessKey}", request.Subject?.Id, request.AccessKey);
            Set(decision, DecisionType.Indeterminate, "ENGINE_ERROR", "Karar motorunda hata oluştu; güvenli tarafta kalınarak izin verilmedi.");
        }

        sw.Stop();
        decision.DurationMs = Math.Round(sw.Elapsed.TotalMilliseconds, 3);
        if (options.WriteAudit)
        {
            WriteAudit(decision, request, options);
            await db.SaveChangesAsync(ct);
        }
        return decision;
    }

    /// <summary>
    /// Soran client'ı doğrular ve isteği başlatan client'ı belirler:
    ///  - istekte client yoksa soranın kendisi;
    ///  - istekteki client sorandan farklıysa soran, o client adına konuşma yetkisi olan bir aracı olmalı (ve via zincirine eklenir).
    /// Hata durumunda karar burada verilir (ReasonCode dolar). Soran yoksa iç çağrıdır (konsol / simülasyon): kapsam uygulanmaz.
    /// </summary>
    private static ClientRow? ResolveCaller(AuthorizationRequest request, AuthorizationModel model, AuthorizationDecision d)
    {
        if (string.IsNullOrWhiteSpace(request.Caller))
        {
            Step(d, "Caller", "Info", "İç çağrı (yönetim konsolu / simülasyon): soru kapsamı uygulanmadı.");
            return null;
        }
        var code = Codes.Lower(request.Caller);
        d.Caller = code;
        if (!model.ClientsById.TryGetValue(code, out var caller) || !caller.IsActive)
        {
            Step(d, "Caller", "Fail", $"Soran '{code}' kayıtlı / aktif bir client değil.");
            Set(d, DecisionType.Deny, "CALLER_UNKNOWN", $"Soruyu soran '{code}' kayıtlı veya aktif bir client değil.");
            return null;
        }
        if (d.Client is null)
        {
            if (caller.Type == ClientType.Intermediary)
            {
                Step(d, "Caller", "Fail", $"'{caller.ClientId}' bir aracıdır; isteği başlatan client'ı belirtmelidir.");
                Set(d, DecisionType.Deny, "CLIENT_REQUIRED", $"Aracı '{caller.ClientId}' kendi adına soru soramaz; isteği başlatan client belirtilmeli.");
                return null;
            }
            d.Client = caller.ClientId;
        }
        else if (!string.Equals(d.Client, caller.ClientId, StringComparison.OrdinalIgnoreCase))
        {
            if (!model.ClientsById.TryGetValue(d.Client, out var original) || !model.CallerMaySpeakFor(caller, original))
            {
                Step(d, "Caller", "Fail", $"'{caller.ClientId}', '{d.Client}' adına soru soramaz (adına konuşma yetkisi yok).");
                Set(d, DecisionType.Deny, "CLIENT_ASSERTION_NOT_ALLOWED",
                    $"Soran '{caller.ClientId}' başka bir client ('{d.Client}') adına soru soramaz. Sadece yetkili aracılar başka client adına konuşabilir.");
                return null;
            }
            if (!request.Via.Any(v => string.Equals(v, caller.ClientId, StringComparison.OrdinalIgnoreCase))) request.Via.Add(caller.ClientId);
        }
        var scope = model.ScopeOf(caller);
        Step(d, "Caller", "Pass", $"Soran '{caller.ClientId}' doğrulandı" + (d.Client != caller.ClientId ? $" · '{d.Client}' adına (aracı)" : "")
            + $" · kapsam: {(scope.Applications.Count == 0 ? "uygulama yok" : string.Join(",", scope.Applications.Select(a => model.Apps.GetValueOrDefault(a)?.Code)))}"
            + $" / {(scope.Tenants.Count == 0 ? "kurum yok" : string.Join(",", scope.Tenants.Select(model.TenantCode)))}.");
        return caller;
    }

    private async Task EvaluateCoreAsync(AuthorizationRequest request, AuthorizationModel model, DateTime now,
        AuthorizationContext context, AuthorizationDecision d, ClientRow? caller, CancellationToken ct)
    {
        // ---------------- Kimlik (subject) ----------------
        // Servis client'ı (client credentials) kullanıcı olmadan kendi servis hesabıyla gelir; bu yüzden client önce bulunur.
        ClientRow? client = d.Client is null ? null : model.ClientsById.GetValueOrDefault(d.Client);
        int? userId = request.Subject?.UserId;
        if (userId is null && !string.IsNullOrWhiteSpace(request.Subject?.Id) && model.UserIdByName.TryGetValue(request.Subject.Id.Trim(), out var byName))
            userId = byName;
        var viaServiceAccount = false;
        if (userId is null && string.IsNullOrWhiteSpace(request.Subject?.Id) && client is { IsActive: true, Type: ClientType.Service, ServiceAccountUserId: { } svc })
        {
            userId = svc;
            viaServiceAccount = true;
        }
        if (userId is null || !model.Users.TryGetValue(userId.Value, out var user))
        {
            Step(d, "Subject", "Fail", $"Kullanıcı bulunamadı: {request.Subject?.Id ?? request.Subject?.UserId?.ToString() ?? "(boş)"}");
            Set(d, DecisionType.Deny, "USER_NOT_FOUND", "Kullanıcı bulunamadı.");
            return;
        }
        d.UserName = user.UserName;
        if (!user.IsActive)
        {
            Step(d, "Subject", "Fail", $"'{user.UserName}' pasif.");
            Set(d, DecisionType.Deny, "USER_INACTIVE", $"Kullanıcı '{user.UserName}' pasif.");
            return;
        }
        Step(d, "Subject", "Pass", viaServiceAccount
            ? $"Kullanıcı yok; servis client'ı '{client!.ClientId}' servis hesabı {user.UserName} ile değerlendirildi (client credentials)."
            : $"{user.UserName} ({user.FullName}) · {model.TenantCode(user.TenantId)} · {string.Join(",", model.UnitCodesOf(user.Id))}");

        // ---------------- 1) Tenant ----------------
        TenantRow? tenant;
        var tenantNote = "";
        if (string.IsNullOrWhiteSpace(request.Tenant))
        {
            tenant = model.Tenants.GetValueOrDefault(user.TenantId);
            tenantNote = " (istekte tenant yok; kullanıcının tenant'ı kullanıldı)";
        }
        else if (!model.TenantByCode.TryGetValue(request.Tenant.Trim(), out tenant))
        {
            Step(d, "Tenant", "Fail", $"'{request.Tenant}' kayıtlı bir tenant değil.");
            Set(d, DecisionType.Deny, "TENANT_UNKNOWN", $"'{request.Tenant}' kayıtlı bir tenant değil.");
            return;
        }
        if (tenant is null || !tenant.IsActive)
        {
            Step(d, "Tenant", "Fail", $"Tenant '{tenant?.Code ?? request.Tenant}' pasif veya yok.");
            Set(d, DecisionType.Deny, "TENANT_INACTIVE", $"Tenant '{tenant?.Code ?? request.Tenant}' pasif veya tanımsız.");
            return;
        }
        d.Tenant = tenant.Code;
        if (user.TenantId != tenant.Id)
        {
            Step(d, "Tenant", "Fail", $"{user.UserName} '{model.TenantCode(user.TenantId)}' tenant'ına ait; '{tenant.Code}' adına işlem yapamaz.");
            Set(d, DecisionType.Deny, "TENANT_MISMATCH",
                $"'{user.UserName}' kullanıcısı '{model.TenantCode(user.TenantId)}' tenant'ına ait; '{tenant.Code}' tenant'ı adına işlem yapamaz (tenant izolasyonu).");
            return;
        }
        if (context.GetString(AuthContextKeys.ResourceTenant) is { Length: > 0 } resourceTenant
            && !string.Equals(resourceTenant, tenant.Code, StringComparison.OrdinalIgnoreCase))
        {
            Step(d, "Tenant", "Fail", $"Kaynak '{resourceTenant}' tenant'ına ait; istek tenant'ı '{tenant.Code}'.");
            Set(d, DecisionType.Deny, "RESOURCE_TENANT_MISMATCH",
                $"Erişilmek istenen kayıt '{resourceTenant}' tenant'ına ait; '{tenant.Code}' kullanıcıları başka tenant'ın kaydına erişemez.");
            return;
        }
        if (caller is not null && !model.CallerMayAskTenant(caller, tenant.Id))
        {
            Step(d, "Tenant", "Fail", $"Soran '{caller.ClientId}' {tenant.Code} kurumunun kullanıcıları için soru soramaz (soru kapsamı dışında).");
            Set(d, DecisionType.Deny, "CALLER_TENANT_SCOPE",
                $"'{caller.ClientId}' client'ının soru kapsamında '{tenant.Code}' kurumu yok; bu kurumun kullanıcıları adına soru soramaz.");
            return;
        }
        Step(d, "Tenant", "Pass", $"{tenant.Code} ({tenant.Name}){tenantNote}; kullanıcı bu tenant'a ait.");

        // ---------------- 2) Client ----------------
        if (d.Client is not null)
        {
            if (client is null || !client.IsActive)
            {
                Step(d, "Client", "Fail", $"'{d.Client}' kayıtlı/aktif bir client değil.");
                Set(d, DecisionType.Deny, "CLIENT_UNKNOWN", $"'{d.Client}' kayıtlı veya aktif bir client değil.");
                return;
            }
            if (!model.IsAvailableIn(client.TenantId, tenant.Id))
            {
                Step(d, "Client", "Fail", $"'{client.ClientId}' {model.TenantCode(client.TenantId)} tenant'ında kayıtlı; {tenant.Code} için kullanılamaz.");
                Set(d, DecisionType.Deny, "CLIENT_TENANT_MISMATCH",
                    $"'{client.Name}' uygulaması '{model.TenantCode(client.TenantId)}' tenant'ına kayıtlı; '{tenant.Code}' tenant'ında kullanılamaz.");
                return;
            }
            if (client.Type == ClientType.Intermediary)
            {
                Step(d, "Client", "Fail", $"'{client.ClientId}' bir aracıdır (gateway/BFF); orijinal client (azp) client alanında, aracı 'via' alanında gelmeli.");
                Set(d, DecisionType.Deny, "CLIENT_IS_INTERMEDIARY",
                    $"'{client.Name}' bir aracıdır ve isteği başlatan uygulama olamaz. Orijinal client (token'daki azp) iletilmeli; aracı 'via' zincirinde yer alır.");
                return;
            }
        }
        else if (engineOptions.Value.RequireClient)
        {
            Step(d, "Client", "Fail", "Client belirtilmedi.");
            Set(d, DecisionType.Deny, "CLIENT_REQUIRED", "İstek bir client (uygulama) kimliği içermelidir.");
            return;
        }

        var intermediaries = new List<ClientRow>();
        foreach (var code in request.Via.Where(v => !string.IsNullOrWhiteSpace(v)).Select(Codes.Lower))
        {
            if (!model.ClientsById.TryGetValue(code, out var hop) || !hop.IsActive || hop.Type != ClientType.Intermediary)
            {
                Step(d, "Client", "Fail", $"Aracı '{code}' kayıtlı/aktif bir aracı (Intermediary) değil.");
                Set(d, DecisionType.Deny, "INTERMEDIARY_UNKNOWN", $"'{code}' kayıtlı bir aracı değil; bilinmeyen aracıdan gelen istek kabul edilmez.");
                return;
            }
            if (!model.IsAvailableIn(hop.TenantId, tenant.Id))
            {
                Step(d, "Client", "Fail", $"Aracı '{hop.ClientId}' {tenant.Code} için kullanılamaz.");
                Set(d, DecisionType.Deny, "INTERMEDIARY_TENANT_MISMATCH", $"Aracı '{hop.ClientId}' '{tenant.Code}' tenant'ında kullanılamaz.");
                return;
            }
            intermediaries.Add(hop);
        }
        d.Via = intermediaries.Select(v => v.ClientId).ToList();
        var viaText = intermediaries.Count > 0 ? $" · aracı: {string.Join(" → ", d.Via)}" : "";
        if (client is not null)
            Step(d, "Client", "Pass", $"'{client.ClientId}' ({client.Type}) kayıtlı ve aktif · tenant {model.TenantCode(client.TenantId)}"
                + (client.TenantId != tenant.Id ? " (üst tenant'tan miras)" : "") + viaText + ".");
        else
            Step(d, "Client", "Skip", "Client belirtilmedi (motor ayarı: zorunlu değil)" + viaText + ".");

        // ---------------- 3) Resource + scope ----------------
        ResourceScopeInfo? rs;
        if (request.Http is { } http)
        {
            var appCode = string.IsNullOrWhiteSpace(http.Application) ? null : http.Application.Trim();
            if (appCode is not null && !model.AppByCode.ContainsKey(appCode))
            {
                Step(d, "Resource", "Fail", $"Uygulama (resource server) bulunamadı: {appCode}");
                Set(d, DecisionType.Deny, "APPLICATION_UNKNOWN", $"'{appCode}' kayıtlı bir uygulama değil.");
                return;
            }
            var (match, ambiguous) = model.MatchHttp(appCode, http.Method, http.Path, tenant.Id);
            if (ambiguous.Count > 0)
            {
                Step(d, "Resource", "Fail", $"{d.Http} birden fazla yetkiye eşleşiyor: {string.Join(", ", ambiguous.Select(a => $"{a.Uri.Method} {a.Uri.Pattern} → {a.Access.Key}"))}");
                Set(d, DecisionType.Deny, "AMBIGUOUS_URI", $"'{d.Http}' birden fazla URI desenine aynı özgüllükte eşleşiyor; katalog düzeltilmeli (fail-closed).");
                return;
            }
            if (match is null)
            {
                Step(d, "Resource", "Fail", $"{d.Http} hiçbir resource'un URI desenine eşleşmiyor.");
                Set(d, DecisionType.Deny, "URI_NOT_REGISTERED", $"'{d.Http}' yetki kataloğunda tanımlı değil. Tanımsız uç noktaya erişim kapalıdır.");
                return;
            }
            rs = match.Access;
            d.MatchedUri = $"{match.Uri.Method} {match.Uri.Pattern}";
        }
        else if (!string.IsNullOrWhiteSpace(request.AccessKey))
        {
            rs = model.FindByKey(request.AccessKey);
            if (rs is null)
            {
                d.AccessKey = Codes.Lower(request.AccessKey);
                Step(d, "Resource", "Fail", $"'{d.AccessKey}' katalogda yok.");
                Set(d, DecisionType.Deny, "PERMISSION_UNKNOWN", $"'{d.AccessKey}' katalogda tanımlı bir resource:scope değil.");
                return;
            }
        }
        else if (!string.IsNullOrWhiteSpace(request.Resource?.Type) && !string.IsNullOrWhiteSpace(request.Scope))
        {
            rs = model.FindResourceScope(request.Resource.Type, request.Scope);
            if (rs is null)
            {
                var resourceExists = model.ResourceByCode.ContainsKey(request.Resource.Type.Trim());
                d.AccessKey = $"{request.Resource.Type}:{request.Scope}";
                Step(d, "Resource", "Fail", resourceExists ? $"'{request.Resource.Type}' resource'unda '{request.Scope}' scope'u yok." : $"'{request.Resource.Type}' resource'u yok.");
                Set(d, DecisionType.Deny, resourceExists ? "SCOPE_UNKNOWN" : "RESOURCE_UNKNOWN",
                    resourceExists ? $"'{request.Resource.Type}' üzerinde '{request.Scope}' işlemi tanımlı değil." : $"'{request.Resource.Type}' katalogda tanımlı bir resource değil.");
                return;
            }
        }
        else
        {
            Step(d, "Resource", "Fail", "İstekte HTTP isteği, resource + scope veya permission yok.");
            Set(d, DecisionType.Deny, "RESOURCE_REQUIRED", "İstek hangi kaynak üzerinde hangi işlemin yapılacağını belirtmelidir (http | resource + scope).");
            return;
        }

        d.AccessKey = rs.Key;
        d.PermissionName = rs.Name;
        d.ResourceCode = rs.Resource.Code;
        d.ResourceType = rs.Type.Code;
        d.Scope = rs.Scope.Code;
        d.Application = rs.App.Code;
        d.CatalogPath = rs.Path;
        if (!rs.IsActive)
        {
            Step(d, "Resource", "Fail", !rs.App.IsActive ? $"{rs.App.Code} uygulaması pasif." : $"{rs.Resource.Code} (veya tipi) pasif.");
            Set(d, DecisionType.Deny, "RESOURCE_INACTIVE", !rs.App.IsActive ? $"'{rs.App.Code}' uygulaması pasif." : $"'{rs.Resource.Code}' pasif.");
            return;
        }
        if (caller is not null && !model.CallerMayAskApplication(caller, rs.App.Id))
        {
            Step(d, "Resource", "Fail", $"Soran '{caller.ClientId}' {rs.App.Code} uygulaması hakkında soru soramaz (soru kapsamı dışında).");
            Set(d, DecisionType.Deny, "CALLER_APP_SCOPE",
                $"'{caller.ClientId}' client'ının soru kapsamında '{rs.App.Code}' uygulaması yok; bu uygulamanın yetkileri hakkında soru soramaz.");
            return;
        }
        if (!model.IsAvailableIn(rs.TenantId, tenant.Id))
        {
            Step(d, "Resource", "Fail", $"{rs.App.Code} uygulaması {model.TenantCode(rs.TenantId)} tenant'ına ait; {tenant.Code} için tanımlı değil.");
            Set(d, DecisionType.Deny, "RESOURCE_NOT_IN_TENANT", $"'{rs.App.Code}' uygulaması '{model.TenantCode(rs.TenantId)}' tenant'ına ait; '{tenant.Code}' tenant'ında kullanılamaz.");
            return;
        }
        Step(d, "Resource", "Pass", $"{(d.MatchedUri is null ? "" : $"{d.Http} → URI {d.MatchedUri} → ")}{rs.Type.Name} {rs.Resource.Code} · scope {rs.Scope.Code} → {rs.Key} · risk={rs.Row.RiskLevel}");

        // ---------------- 4) Permission'lar ----------------
        var permissions = model.PermissionsFor(rs.Id);
        if (permissions.Count == 0)
        {
            Step(d, "Permission", "Fail", $"'{rs.Key}' yetkisine uygulanan permission yok.");
            Set(d, DecisionType.Deny, "NO_PERMISSION", $"'{rs.Key}' için tanımlı permission yok; varsayılan olarak erişim kapalıdır.");
            return;
        }

        // ---------------- 5) Policy'ler ----------------
        var identity = model.GetIdentity(user.Id, now);
        var resolver = new AttributeResolver(_providers, new AttributeResolutionScope
        {
            Subject = new SubjectRef(user.Id, user.UserName),
            Context = context,
            Action = rs.Key,
            Resource = request.Resource is null ? null : new ResourceRef(request.Resource.Type ?? rs.Resource.Code, request.Resource.Id),
            Model = model,
            Now = now
        });
        var evaluator = new PolicyRun(model, resolver, ruleEvaluator, rs.Key, ct);

        var evaluations = new List<PermissionEvaluation>();
        foreach (var perm in permissions)
        {
            var policyResults = new List<PolicyEvaluation>();
            foreach (var pid in perm.PolicyIds) policyResults.Add(await evaluator.EvaluateAsync(pid, 0, []));
            var combined = policyResults.Count == 0
                ? new CombiningResult(DecisionType.Deny, null)
                : DecisionStrategies.Combine(perm.Row.Strategy, policyResults.Select(Effective).ToList());
            if (combined.DecidingIndex is { } pi) policyResults[pi] = policyResults[pi] with { IsDeciding = true };
            evaluations.Add(new PermissionEvaluation(perm.Row.Id, perm.Row.Code, perm.Row.Name, perm.Row.Strategy, combined.Decision, policyResults));
        }

        var final = DecisionStrategies.Combine(rs.App.Strategy, evaluations.Select(e => e.Result).ToList());
        if (final.DecidingIndex is { } di) evaluations[di] = evaluations[di] with { IsDeciding = true };
        d.Permissions = evaluations;
        d.Evidence = resolver.Used.DistinctBy(u => u.Attribute).ToList();

        var all = evaluations.SelectMany(e => e.Policies.SelectMany(Flatten)).ToList();
        var enforcedRules = all.Where(p => p.Mode == PolicyMode.Enforce).SelectMany(p => p.Rules).ToList();
        d.FailedRules = enforcedRules.Where(r => r.Result is DecisionType.Deny or DecisionType.Indeterminate).Select(r => r.Code).Distinct().ToList();
        d.MissingAttributes = enforcedRules.SelectMany(r => r.MissingAttributes).Distinct().ToList();
        d.ReportOnlyDenials = all.Where(p => p.Mode == PolicyMode.ReportOnly && p.Result is DecisionType.Deny or DecisionType.Indeterminate)
            .Select(p => $"{p.Code} → {p.Result}").Distinct().ToList();

        foreach (var e in evaluations)
            Step(d, $"Permission {e.Code}", e.Result switch { DecisionType.Permit => "Pass", DecisionType.NotApplicable => "Info", _ => "Fail" },
                $"{e.Result} ({DecisionStrategies.Describe(e.Strategy)}) · " +
                string.Join(" · ", e.Policies.Select(p => $"{p.Code}{(p.Mode == PolicyMode.Enforce ? "" : $" [{p.Mode}]")}: {p.Result} — {p.Detail}")));

        var decidingPermission = evaluations.FirstOrDefault(e => e.IsDeciding);
        var decidingPolicy = decidingPermission?.Policies.FirstOrDefault(p => p.IsDeciding);
        var leaf = decidingPolicy is null ? null : DecidingLeaf(decidingPolicy);
        var decidingRule = leaf?.Rules.FirstOrDefault(r => r.IsDeciding);
        d.DecidingPermission = decidingPermission?.Code;
        d.DecidingPolicy = leaf?.Code ?? decidingPolicy?.Code;
        d.DecidingRule = decidingRule?.Code;

        // Yükümlülükler: izin vermiş (veya etkisiz) permission'lardaki, sonucu yükümlülüğün FulfillOn'u ile eşleşen policy'lerden.
        var outcome = final.Decision == DecisionType.Permit ? DecisionType.Permit : DecisionType.Deny;
        var byId = model.Policies;
        d.Obligations = evaluations
            .Where(e => outcome == DecisionType.Permit ? e.Result is DecisionType.Permit or DecisionType.NotApplicable : e.Result == DecisionType.Deny)
            .SelectMany(e => e.Policies.SelectMany(Flatten))
            .Where(p => p.Result == outcome && p.Mode != PolicyMode.ReportOnly && byId.ContainsKey(p.PolicyId))
            .SelectMany(p => byId[p.PolicyId].Obligations
                .Where(o => o.FulfillOn == (outcome == DecisionType.Permit ? ObligationFulfillOn.Permit : ObligationFulfillOn.Deny))
                .Select(o => new DecisionObligation(o.Code, p.Code, o.Params)))
            .DistinctBy(o => $"{o.Code}|{o.Policy}")
            .ToList();
        if (d.Obligations.Count > 0)
            Step(d, "Obligation", "Info", string.Join(" · ", d.Obligations.Select(o => $"{o.Code}({string.Join(", ", o.Parameters.Select(p => $"{p.Key}={p.Value}"))}) ← {o.Policy}")));

        switch (final.Decision)
        {
            case DecisionType.Permit:
                var granted = evaluations.Where(e => e.Result == DecisionType.Permit).ToList();
                Set(d, DecisionType.Permit, "PERMIT",
                    $"'{rs.Key}' için {granted.Count} permission izin verdi ({string.Join(", ", granted.Select(g => g.Code))})." +
                    (d.ReportOnlyDenials.Count > 0 ? $" ReportOnly uyarısı: {string.Join("; ", d.ReportOnlyDenials)}." : ""));
                break;
            case DecisionType.Indeterminate:
                Set(d, DecisionType.Indeterminate, d.MissingAttributes.Count > 0 ? "MISSING_ATTRIBUTE" : "EVALUATION_ERROR",
                    d.MissingAttributes.Count > 0
                        ? $"Karar için gerekli değer eksik: {string.Join(", ", d.MissingAttributes)} ({d.DecidingPermission}/{d.DecidingPolicy}). Güvenli tarafta kalınarak izin verilmedi."
                        : $"{d.DecidingPermission}/{d.DecidingPolicy} değerlendirilemedi: {leaf?.Detail}. Güvenli tarafta kalınarak izin verilmedi.");
                break;
            case DecisionType.NotApplicable:
                Set(d, DecisionType.Deny, "NO_EFFECTIVE_PERMISSION", $"'{rs.Key}' için karara katılan (Enforce) policy'si olan permission yok; varsayılan olarak erişim kapalıdır.");
                break;
            default:
                Set(d, DecisionType.Deny, decidingRule?.ReasonCode ?? ReasonOf(leaf),
                    $"'{d.DecidingPermission}' izin vermedi: {d.DecidingPolicy} — {decidingRule?.Message ?? leaf?.Detail}");
                break;
        }
    }

    private static DecisionType Effective(PolicyEvaluation p) => p.Mode == PolicyMode.Enforce ? p.Result : DecisionType.NotApplicable;

    private static IEnumerable<PolicyEvaluation> Flatten(PolicyEvaluation p) => new[] { p }.Concat(p.Children.SelectMany(Flatten));

    /// <summary>Kararı veren en alt policy: kararı veren kural tek bir policy referansıysa (HAZIR POLICY kartı) o policy'ye iner.</summary>
    private static PolicyEvaluation DecidingLeaf(PolicyEvaluation p) =>
        p.Children.FirstOrDefault(c => c.IsDeciding) is { } c ? DecidingLeaf(c) : p;

    private static string ReasonOf(PolicyEvaluation? p) =>
        p is null ? "DENIED" : p.Logic == PolicyLogic.Negative ? "NEGATIVE_POLICY_MATCHED" : p.DecidingRule ?? "CONDITION_NOT_MET";

    /// <summary>Tek istekteki policy değerlendirmesi: kurallar (kartlar) stratejiyle birleşir, logic uygulanır; kural içi referanslar alt sonuç olur.</summary>
    private sealed class PolicyRun(AuthorizationModel model, AttributeResolver resolver, PolicyEvaluator rules, string permissionKey, CancellationToken ct)
    {
        public async Task<PolicyEvaluation> EvaluateAsync(int policyId, int depth, HashSet<int> path)
        {
            if (!model.Policies.TryGetValue(policyId, out var p))
                return new PolicyEvaluation(policyId, $"#{policyId}", "?", PolicyLogic.Positive, PolicyMode.Enforce,
                    DecisionStrategy.Unanimous, 0, DecisionType.Deny, "Policy bulunamadı (izin vermez).", null, [], []);
            var row = p.Row;
            PolicyEvaluation Result(DecisionType r, string detail, string? decidingRule = null, IReadOnlyList<RuleEvaluation>? ruleResults = null,
                IReadOnlyList<PolicyEvaluation>? children = null) =>
                new(row.Id, row.Code, row.Name, row.Logic, row.Mode, row.Strategy, row.Version,
                    DecisionStrategies.ApplyLogic(row.Logic, r), row.Logic == PolicyLogic.Negative ? $"[negatif] {detail}" : detail,
                    decidingRule, ruleResults ?? [], children ?? []);

            if (!row.IsActive) return Result(DecisionType.Deny, "Policy pasif (izin vermez).") with { Result = DecisionType.Deny };
            if (depth > AuthorizationModel.MaxPolicyDepth || path.Contains(policyId)) return Result(DecisionType.Indeterminate, "Policy referansı döngüsü veya çok derin zincir.");

            var children = new List<PolicyEvaluation>();
            path.Add(policyId);
            var e = await rules.EvaluateAsync(p.Definition, resolver, permissionKey, ct, async (refId, _) =>
            {
                var (result, child) = await ReferenceAsync(refId, depth + 1, path);
                if (child is not null) children.Add(child);
                return result;
            });
            path.Remove(policyId);
            var deciding = e.Rules.FirstOrDefault(x => x.IsDeciding);
            // Kararı veren kart "hazır policy" ise açıklama o policy'ye iner (ör. GISE_GUVENLI_ISLEM → IZINLI → USER_ON_LEAVE)
            if (deciding is not null && p.Definition.Rules.FirstOrDefault(r => r.RuleId == deciding.RuleId)?.Condition is { Kind: ConditionKind.Reference, ReferencePolicyId: { } via })
            {
                var i = children.FindIndex(c => c.PolicyId == via);
                if (i >= 0) children[i] = children[i] with { IsDeciding = true };
            }
            return Result(e.Result, deciding?.Message ?? $"{e.Rules.Count} kural ({DecisionStrategies.Describe(row.Strategy)})", deciding?.ReasonCode ?? deciding?.Code, e.Rules, children);
        }

        /// <summary>
        /// Kural içindeki policy referansı: policy bu istekte tam değerlendirilir (logic uygulanır, mod dikkate alınmaz).
        /// Bulunamayan, pasif veya döngüye giren referans belirsizdir (fail-closed; NOT içinde de izin açamaz).
        /// </summary>
        private async Task<(PolicyReferenceResult Result, PolicyEvaluation? Child)> ReferenceAsync(int policyId, int depth, HashSet<int> path)
        {
            if (!model.Policies.TryGetValue(policyId, out var target)) return (new(DecisionType.Indeterminate, "policy bulunamadı", null), null);
            if (!target.Row.IsActive) return (new(DecisionType.Indeterminate, "policy pasif", null), null);
            var r = await EvaluateAsync(policyId, depth, path);
            return (new(r.Result, r.Detail, Missing(r).Distinct().ToList()), r);

            static IEnumerable<string> Missing(PolicyEvaluation x) => x.Rules.SelectMany(r => r.MissingAttributes).Concat(x.Children.SelectMany(Missing));
        }
    }

    private static AuthorizationContext BuildContext(AuthorizationRequest request, string? client, DateTime now)
    {
        var values = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
        if (request.Resource?.Properties is { } props)
            foreach (var (k, v) in props) values[k] = v;
        foreach (var (k, v) in request.Context) values[k] = v;
        var context = new AuthorizationContext(values);

        // Zaman ve client otoritesi motordur: çağıranın gönderdiği zaman sadece audit için saklanır.
        if (context.GetString(AuthContextKeys.CurrentTime) is { } callerTime) context.Set(AuthContextKeys.CallerTime, callerTime);
        context.Set(AuthContextKeys.CurrentTime, now.ToString("o", CultureInfo.InvariantCulture));
        context.Set(AuthContextKeys.ClientId, client);
        return context;
    }

    private static void Step(AuthorizationDecision d, string step, string outcome, string detail) => d.Steps.Add(new DecisionStep(step, outcome, detail));

    private static void Set(AuthorizationDecision d, DecisionType type, string reasonCode, string message)
    {
        d.Decision = type;
        d.ReasonCode = reasonCode;
        d.HumanReadableReason = message.Trim();
    }

    private void WriteAudit(AuthorizationDecision d, AuthorizationRequest request, EvaluationOptions options)
    {
        string? R(string attribute, string? value) => redactor.Redact(attribute, value);
        audit.Add(new AuditLog
        {
            Id = d.DecisionId,
            Timestamp = d.EvaluatedAt,
            Category = d.IsSimulation ? AuditCategory.Simulation : AuditCategory.AuthorizationDecision,
            Actor = options.Actor ?? d.Caller ?? d.Client ?? "unknown-client",
            Action = d.IsSimulation ? "SimulatedEvaluate" : "Evaluate",
            SubjectUserName = d.UserName ?? request.Subject?.Id,
            ClientId = d.Client,
            PermissionCode = d.AccessKey,
            Resource = d.Resource ?? d.Http,
            Decision = d.Decision.ToString(),
            ReasonCode = d.ReasonCode,
            Summary = d.HumanReadableReason,
            CorrelationId = request.CorrelationId,
            DetailsJson = JsonDefaults.Serialize(new
            {
                d.Caller,
                d.Http,
                d.MatchedUri,
                d.ResourceType,
                Context = d.Context.ToDictionary(kv => kv.Key, kv => R(AttributeId.ForRequestKey(kv.Key).ToString(), kv.Value)),
                Evidence = d.Evidence.Select(e => e with { Value = R(e.Attribute, e.Value) }),
                d.Steps,
                d.Via,
                d.Obligations,
                d.DecidingPermission,
                d.DecidingPolicy,
                d.DecidingRule,
                Permissions = d.Permissions.Select(p => new
                {
                    p.Code, p.Strategy, p.Result,
                    Policies = p.Policies.Select(x => new { x.Code, x.Logic, x.Mode, x.Version, x.Result, x.Detail, Rules = x.Rules.Select(r => new { r.Code, r.Result, r.ReasonCode, r.Expression }) })
                }),
                d.ReportOnlyDenials,
                d.FailedRules,
                d.MissingAttributes,
                d.ModelVersion,
                d.DurationMs
            })
        });
    }
}
