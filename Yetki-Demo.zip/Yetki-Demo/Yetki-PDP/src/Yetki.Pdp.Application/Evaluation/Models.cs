using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Application.PolicyEngine;
using Yetki.Pdp.Application.PolicyEngine.Attributes;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.Evaluation;

public sealed class SubjectInfo
{
    /// <summary>Kullanıcı adı (AuthZEN subject.id).</summary>
    public string? Id { get; set; }
    public int? UserId { get; set; }
}

/// <summary>
/// HTTP isteği (gateway / framework PEP): motor METHOD + path'i kayıtlı URI desenlerinden resource + scope'a çözer.
/// Kayıtlı olmayan URI'ye erişim her zaman reddedilir.
/// </summary>
public sealed class HttpRequestInfo
{
    /// <summary>Opsiyonel resource server (uygulama) kodu. Boşsa tenant'ta kullanılabilen tüm uygulamaların URI'leri aranır.</summary>
    public string? Application { get; set; }
    public string Method { get; set; } = "GET";
    public string Path { get; set; } = "/";
}

/// <summary>
/// İşlem yapılan kayıt. Id + Properties: ör. hesap no; Tenant, BranchCode, CustomerId. Properties bağlama eklenir.
/// Type: resource kodu (anka.vadelihesap) — Http verilmediyse Scope ile birlikte yetkiyi belirler.
/// </summary>
public sealed class ResourceInfo
{
    public string? Type { get; set; }
    public string? Id { get; set; }
    /// <summary>Kaydın nitelikleri (ör. Tenant, BranchCode, CustomerId). Bağlama eklenir; aynı anahtar Context'te varsa Context kazanır.</summary>
    public Dictionary<string, string?> Properties { get; set; } = new();
}

/// <summary>
/// Yetkilendirme isteği: { tenant, client, subject, (http | resource + scope | accessKey), context }.
/// Yetki üç biçimden biriyle belirtilir: Http (gateway: METHOD + path) · Resource.Type + Scope · AccessKey ("resource:scope").
/// Context'teki hiçbir alan zorunlu değildir; policy ihtiyaç duyduğu değeri bulamazsa sonuç Indeterminate olur (asla Permit değil).
/// </summary>
public sealed class AuthorizationRequest
{
    private string? _accessKey;
    /// <summary>İsteğin yapıldığı tenant kodu (ör. ABANK). Boşsa kullanıcının tenant'ı kabul edilir.</summary>
    public string? Tenant { get; set; }
    public SubjectInfo Subject { get; set; } = new();
    public HttpRequestInfo? Http { get; set; }
    /// <summary>Resource üzerinde yapılacak işlem (Keycloak scope: view, create, close...).</summary>
    public string? Scope { get; set; }
    /// <summary>Atomik yetki anahtarı: "resource:scope" (ör. anka.vadelihesap:close). Permission entity'si ile karışmaması için AccessKey adını kullanır.</summary>
    public string? AccessKey { get => _accessKey; set => _accessKey = value; }
    /// <summary>Geriye uyumlu eski alan. Yeni istemciler AccessKey kullanmalıdır.</summary>
    [Obsolete("Use AccessKey. This alias will be removed after clients migrate.")]
    public string? Permission { get => _accessKey; set { if (string.IsNullOrWhiteSpace(_accessKey)) _accessKey = value; } }
    public ResourceInfo? Resource { get; set; }
    public Dictionary<string, string?> Context { get; set; } = new();
    /// <summary>İsteği BAŞLATAN OAuth client (token'daki azp / client_id). Gateway / BFF üzerinden gelse bile orijinal client'tır.</summary>
    public string? Client { get; set; }
    /// <summary>Aracı zinciri (dıştan içe): isteği kullanıcı adına ileten gateway / BFF / servisler (RFC 8693 "act").</summary>
    public List<string> Via { get; set; } = new();
    /// <summary>
    /// SORAN: motora soruyu soran, kimliği doğrulanmış client (token'dan). /api/v1 uçlarında gövdedeki değer yok sayılır ve token'dan doldurulur.
    /// Boşsa iç çağrı (yönetim konsolu / simülasyon): soru kapsamı uygulanmaz. Konsol, "şu client sorsaydı" testi için doldurabilir.
    /// </summary>
    public string? Caller { get; set; }
    public string? CorrelationId { get; set; }
}

/// <summary>Motor davranış ayarları (appsettings: "AuthorizationEngine").</summary>
public sealed class AuthorizationEngineOptions
{
    /// <summary>true: client belirtilmeyen istekler reddedilir.</summary>
    public bool RequireClient { get; set; }
}

/// <summary>Karar akışının bir adımı (açıklanabilirlik): Pass / Fail / Info / Skip.</summary>
public sealed record DecisionStep(string Step, string Outcome, string Detail);

/// <summary>Bir policy'nin bu istekteki sonucu: kuralları (kartlar) ve kurallarda referansla kullanılan policy'lerin sonuçları (Children).</summary>
public sealed record PolicyEvaluation(
    int PolicyId, string Code, string Name, PolicyLogic Logic, PolicyMode Mode, DecisionStrategy Strategy, int Version,
    DecisionType Result, string Detail, string? DecidingRule, IReadOnlyList<RuleEvaluation> Rules, IReadOnlyList<PolicyEvaluation> Children)
{
    public bool IsDeciding { get; init; }
}

/// <summary>Bir Keycloak permission'ının bu istekteki sonucu.</summary>
public sealed record PermissionEvaluation(int PermissionId, string Code, string Name, DecisionStrategy Strategy, DecisionType Result,
    IReadOnlyList<PolicyEvaluation> Policies)
{
    public bool IsDeciding { get; init; }
}

/// <summary>Açıklanabilir karar: karar + neden + adımlar + kararı veren permission/policy/rule + kullanılan değerler.</summary>
public sealed class AuthorizationDecision
{
    private string? _accessKey;
    public Guid DecisionId { get; set; }
    public DecisionType Decision { get; set; }
    /// <summary>Enforcement için tek doğru: yalnızca Permit izin verir.</summary>
    public bool IsAllowed => Decision == DecisionType.Permit;
    public string ReasonCode { get; set; } = default!;
    public string HumanReadableReason { get; set; } = default!;

    public string? UserName { get; set; }
    public string? Tenant { get; set; }
    public string? Client { get; set; }
    /// <summary>Soruyu soran (doğrulanmış) client. Boşsa iç çağrı (konsol / simülasyon).</summary>
    public string? Caller { get; set; }
    /// <summary>Doğrulanmış aracı zinciri (gateway, BFF, kullanıcı adına çağıran servisler).</summary>
    public IReadOnlyList<string> Via { get; set; } = [];
    /// <summary>PEP'in yerine getirmesi gereken yükümlülükler (ör. MASK_FIELDS). Yerine getiremiyorsa erişimi reddetmeli.</summary>
    public IReadOnlyList<DecisionObligation> Obligations { get; set; } = [];
    /// <summary>Atomik yetki anahtarı: resource:scope.</summary>
    public string? AccessKey { get => _accessKey; set => _accessKey = value; }
    /// <summary>Geriye uyumlu eski çıktı alanı. Yeni istemciler AccessKey kullanmalıdır.</summary>
    [Obsolete("Use AccessKey. This alias will be removed after clients migrate.")]
    public string? Permission { get => _accessKey; set => _accessKey = value; }
    public string? PermissionName { get; set; }
    public string? ResourceCode { get; set; }
    public string? ResourceType { get; set; }
    public string? Scope { get; set; }
    public string? Application { get; set; }
    public string? CatalogPath { get; set; }
    /// <summary>HTTP isteği (METHOD path) ve eşlendiği URI deseni.</summary>
    public string? Http { get; set; }
    public string? MatchedUri { get; set; }
    /// <summary>İstekteki kayıt (resource.type:id).</summary>
    public string? Resource { get; set; }
    public string? DecidingPermission { get; set; }
    public string? DecidingPolicy { get; set; }
    public string? DecidingRule { get; set; }

    public DateTime EvaluatedAt { get; set; }
    public bool IsSimulation { get; set; }
    public long ModelVersion { get; set; }
    public double DurationMs { get; set; }

    public List<DecisionStep> Steps { get; set; } = new();
    public IReadOnlyList<PermissionEvaluation> Permissions { get; set; } = [];
    /// <summary>ReportOnly policy'lerden Enforce olsaydı reddedecek olanlar (kararı etkilemez).</summary>
    public IReadOnlyList<string> ReportOnlyDenials { get; set; } = [];
    public IReadOnlyList<string> FailedRules { get; set; } = [];
    public IReadOnlyList<string> MissingAttributes { get; set; } = [];
    public IReadOnlyList<UsedAttribute> Evidence { get; set; } = [];
    public IReadOnlyDictionary<string, string?> Context { get; set; } = new Dictionary<string, string?>();
}

/// <summary>Aynı evaluator'ın simülasyon parametreleri. Gerçek kararda hepsi varsayılandır.</summary>
public sealed class EvaluationOptions
{
    /// <summary>Kararın verileceği model (What-If). Boşsa güncel model.</summary>
    public AuthorizationModel? Model { get; init; }
    /// <summary>Sadece simülasyonda: kararın hangi an için verileceği. Gerçek kararda motor saati kullanılır.</summary>
    public DateTime? AsOfUtc { get; init; }
    public bool IsSimulation { get; init; }
    public bool WriteAudit { get; init; } = true;
    public string? Actor { get; init; }

    public static readonly EvaluationOptions Default = new();
}
