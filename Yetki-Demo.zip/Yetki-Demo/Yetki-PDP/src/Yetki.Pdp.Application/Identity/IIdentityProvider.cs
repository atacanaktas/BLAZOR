using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.Identity;

// PIP sözleşmesinin PDP tarafındaki karşılığı (kaynaktan bağımsız değerler; EF varlığı / IQueryable sınırı geçmez).
public sealed record IdentityUser(int Id, int TenantId, string UserName, string FullName, string? Email,
    string? Title, string? EmployeeNo, UserKind Kind, bool IsActive, bool IsOnLeave,
    decimal CashWithdrawalLimit, string? CustomerNo);
public sealed record IdentityRole(int Id, int TenantId, string Code, string Name, string? Description, bool IsInheritable, bool IsActive);
public sealed record IdentityUserRole(int UserId, int RoleId, DateTime? ValidFrom, DateTime? ValidUntil,
    string? Reason, DateTime AssignedAt, string AssignedBy);
public sealed record IdentityUnit(int Id, int TenantId, int? ParentId, string Code, string Name, OrgUnitType Type, bool IsActive);
public sealed record IdentityUserUnit(int UserId, int OrgUnitId, bool IsPrimary);
public sealed record IdentitySnapshot(string Revision, IReadOnlyList<IdentityUser> Users, IReadOnlyList<IdentityRole> Roles,
    IReadOnlyList<IdentityUserRole> UserRoles, IReadOnlyList<IdentityUnit> Units, IReadOnlyList<IdentityUserUnit> UserUnits);

/// <summary>
/// PDP'nin kimlik kaynağı (PIP). SALT OKUNUR: kimlik yazımı PIP'in (İK) işidir.
///  - "Pip" (varsayılan): Yetki-PIP API'si (revizyon kısa süre önbelleklenir; görüntü sadece revizyon değişince okunur).
///  - "LocalDb": aynı veritabanındaki tablolar (testler / tek süreç).
/// Revizyon kaynak verisi her değiştiğinde değişmelidir; hata yutulmaz (eski / yerel veriye sessizce düşülmez).
/// </summary>
public interface IIdentityProvider
{
    string Name { get; }
    Task<string> GetRevisionAsync(CancellationToken ct);
    Task<IdentitySnapshot> ReadSnapshotAsync(CancellationToken ct);
    /// <summary>Ekranlar için ayrıntı (e-posta, atama nedeni / kim / ne zaman) — karar modelinde tutulmayan alanlar.</summary>
    Task<IdentityUser?> GetUserAsync(int id, CancellationToken ct);
    Task<IReadOnlyList<IdentityUserRole>> GetUserRolesAsync(int userId, CancellationToken ct);
}
