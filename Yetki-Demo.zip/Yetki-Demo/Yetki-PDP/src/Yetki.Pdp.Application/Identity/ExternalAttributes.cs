namespace Yetki.Pdp.Application.Identity;

// PIP'in kimlik dışı öznitelik sözleşmesi (iş takvimi, izin, müşteri). Alan adları PIP cevabıyla aynı.
public sealed record BusinessDayInfo(string Date, bool IsBusinessDay, string Reason, string Source);
public sealed record LeaveInfo(int UserId, string Date, bool OnLeave, string Reason, string Source);
public sealed record CustomerInfo(string CustomerNo, bool IsVip, bool IsStaff, string Source);
public sealed record LimitInfo(int UserId, string Type, string Date, decimal PerTransactionLimit, decimal DailyLimit, decimal UsedToday,
    decimal RemainingToday, string Currency, string Source);

/// <summary>
/// Policy koşullarının kimlik dışı öznitelik kaynağı (PIP). Bu değerler İSTEKTEN alınmaz: client "iş günü", "VIP" veya
/// "izinde değil" diyerek kararı değiştiremez. Kaynak erişilemezse hata yükselir; koşul belirsiz (Indeterminate) sayılır.
/// </summary>
public interface IExternalAttributeSource
{
    Task<BusinessDayInfo> BusinessDayAsync(DateOnly date, CancellationToken ct);
    Task<LeaveInfo> LeaveAsync(int userId, DateOnly date, CancellationToken ct);
    Task<CustomerInfo> CustomerAsync(string customerNo, CancellationToken ct);
    /// <summary>Nakit limitleri (type = CASH): işlem başı, günlük toplam, bugün kullanılan.</summary>
    Task<LimitInfo> CashLimitAsync(int userId, DateOnly date, CancellationToken ct);
}
