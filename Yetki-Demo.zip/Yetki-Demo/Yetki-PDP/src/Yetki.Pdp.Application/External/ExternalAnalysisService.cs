using Microsoft.EntityFrameworkCore;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.External;

public sealed record ExternalChange(string System, string Code, string? ResourceClass, string? Level, string? PreviousLevel, IReadOnlyList<string> Reasons);

public sealed record ExternalUserImpact(int UserId, string UserName, IReadOnlyList<ExternalChange> Grants, IReadOnlyList<ExternalChange> Modifies, IReadOnlyList<ExternalChange> Revokes);

/// <summary>Dış bağımlılık değişikliğinin etkisi: hangi kullanıcıya dış sistemde ne açılır / değişir / kapanır.</summary>
public sealed record ExternalImpactResult(string Summary, int AffectedUserCount, IReadOnlyList<ExternalUserImpact> Users);

/// <summary>Kullanıcının dış sistem durumu: olması gereken ↔ dış sistemde açık olan (kalem kalem, nedenleriyle).</summary>
public sealed record UserExternalStatus(int UserId, string UserName, bool IsActive, bool InSync, IReadOnlyList<ExternalDiffItem> Items);

public sealed record DriftUser(int UserId, string UserName, int Grants, int Modifies, int Revokes);

public sealed record DriftReport(int CheckedUsers, int DriftedUsers, IReadOnlyList<DriftUser> Users);

/// <summary>Kullanıcının olması gereken dış durumu (provisioning worker'ı baseline / mutabakat için kullanır).</summary>
public sealed record UserExternalDesired(int UserId, string UserName, bool IsActive, IReadOnlyList<ExternalNeed> Needs);

/// <summary>
/// Kaydedilmemiş dış bağımlılık değişikliği (PAP önizlemesi). Varlık / tekrar kontrolleri PAP'ındır; PDP sadece etkiyi hesaplar
/// (zincirde döngü oluşursa reddeder).
/// </summary>
public sealed class ExternalCatalogPatch
{
    public ExternalDependencyRow? AddDependency { get; set; }
    public int? RemoveDependencyId { get; set; }
    public ExternalRequirementRow? AddRequirement { get; set; }
    public ExternalRequirementKey? RemoveRequirement { get; set; }
    /// <summary>Özet metni (ör. "resource X → RACF:Y bağımlılığı"). Boşsa genel metin.</summary>
    public string? Summary { get; set; }
}

public sealed record ExternalRequirementKey(int ExternalPermissionId, int RequiredExternalPermissionId);

/// <summary>
/// Dış sistem (RACF/LDAP) analizleri — SALT OKUNUR. Tanımları yazmak ve provisioning'i yürütmek PAP'ın (ve worker'ının) işidir;
/// "olması gereken durum" ve farkı burada, karar motoruyla aynı etkin yetki hesabından üretilir.
/// </summary>
public sealed class ExternalAnalysisService(IYetkiDbContext db, AuthorizationModelProvider models, IClock clock)
{
    public async Task<ExternalImpactResult> ImpactAsync(ExternalCatalogPatch patch, CancellationToken ct)
    {
        var before = await ExternalRequirementCatalog.LoadAsync(db, ct);
        var after = before;
        if (patch.AddDependency is not null || patch.RemoveDependencyId is not null)
        {
            if (patch.AddDependency is { } d && (d.ResourceId is null) == (d.ResourceScopeId is null))
                throw new ValidationException("Bağımlılık tam olarak bir resource (tüm scope'ları) veya bir resource:scope yetkisine bağlanmalı.");
            after = after.With(patch.AddDependency is { } add ? add with { Id = -1 } : null, patch.RemoveDependencyId);
        }
        if (patch.AddRequirement is { } r)
        {
            if (r.ExternalPermissionId == r.RequiredExternalPermissionId || before.WouldCreateCycle(r.ExternalPermissionId, r.RequiredExternalPermissionId))
                throw new ValidationException("Döngüsel zincir oluşur.");
            after = after.WithRequirement(added: r);
        }
        if (patch.RemoveRequirement is { } rr) after = after.WithRequirement(removed: (rr.ExternalPermissionId, rr.RequiredExternalPermissionId));

        var model = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        var users = new List<ExternalUserImpact>();
        foreach (var u in model.Users.Values.OrderBy(u => u.UserName, StringComparer.Ordinal))
        {
            var set = model.GetEffective(u.Id, now);
            var b = before.ForUser(model, set);
            var a = after.ForUser(model, set);
            var diff = ExternalDiff.Compute(a, ExternalDiff.ToState(b), before.Target, previous: b);
            if (diff.Count == 0) continue;
            users.Add(new ExternalUserImpact(u.Id, u.UserName,
                diff.Where(x => x.Action == "Grant").Select(ToChange).ToList(),
                diff.Where(x => x.Action == "Modify").Select(ToChange).ToList(),
                diff.Where(x => x.Action == "Revoke").Select(ToChange).ToList()));
        }
        var summary = patch.Summary ?? "Dış bağımlılık değişikliği";
        return new ExternalImpactResult($"{summary}: {users.Count} kullanıcının dış sistem yetkisi değişir.", users.Count, users);
    }

    public async Task<UserExternalStatus> UserStatusAsync(int userId, CancellationToken ct)
    {
        var (model, catalog) = await LoadAsync(ct);
        if (!model.Users.TryGetValue(userId, out var user)) throw new NotFoundException("Kullanıcı", userId);
        var state = await StateAsync(userId, ct);
        var items = Diff(model, catalog, userId, state[userId].ToDictionary(g => g.ExternalPermissionId, g => g.AccessLevel), includeUnchanged: true);
        return new UserExternalStatus(userId, user.UserName, user.IsActive, items.All(i => i.Action == "None"), items);
    }

    public async Task<DriftReport> DriftAsync(CancellationToken ct)
    {
        var (model, catalog) = await LoadAsync(ct);
        var state = await StateAsync(null, ct);
        var users = new List<DriftUser>();
        foreach (var u in model.Users.Values.OrderBy(u => u.UserName, StringComparer.Ordinal))
        {
            var items = Diff(model, catalog, u.Id, state[u.Id].ToDictionary(g => g.ExternalPermissionId, g => g.AccessLevel), false);
            if (items.Count > 0)
                users.Add(new DriftUser(u.Id, u.UserName, items.Count(i => i.Action == "Grant"), items.Count(i => i.Action == "Modify"), items.Count(i => i.Action == "Revoke")));
        }
        return new DriftReport(model.Users.Count, users.Count, users);
    }

    /// <summary>Olması gereken dış durum. userIds boşsa tüm kullanıcılar.</summary>
    public async Task<IReadOnlyList<UserExternalDesired>> DesiredAsync(IReadOnlyCollection<int>? userIds, CancellationToken ct)
    {
        var (model, catalog) = await LoadAsync(ct);
        var now = clock.UtcNow;
        return model.Users.Values.Where(u => userIds is null || userIds.Count == 0 || userIds.Contains(u.Id)).OrderBy(u => u.Id)
            .Select(u => new UserExternalDesired(u.Id, u.UserName, u.IsActive, catalog.ForUser(model, model.GetEffective(u.Id, now))))
            .ToList();
    }

    /// <summary>Bir yetkinin (resource:scope) dış gereksinimleri (resource mirası + zincir, nedenleriyle).</summary>
    public async Task<IReadOnlyList<ExternalNeed>> AccessNeedsAsync(int resourceScopeId, CancellationToken ct)
    {
        var (model, catalog) = await LoadAsync(ct);
        if (!model.ResourceScopes.TryGetValue(resourceScopeId, out var access)) throw new NotFoundException("Yetki", resourceScopeId);
        return catalog.ForAccess(access);
    }

    public static ExternalChange ToChange(ExternalDiffItem d) =>
        new(d.Target.System, d.Target.Code, d.Target.ResourceClass, d.DesiredLevel?.ToString().ToUpperInvariant(), d.CurrentLevel?.ToString().ToUpperInvariant(), d.Reasons);

    private async Task<(AuthorizationModel, ExternalRequirementCatalog)> LoadAsync(CancellationToken ct) =>
        (await models.GetCurrentAsync(ct), await ExternalRequirementCatalog.LoadAsync(db, ct));

    private async Task<ILookup<int, (int ExternalPermissionId, ExternalAccessLevel? AccessLevel)>> StateAsync(int? userId, CancellationToken ct) =>
        (await db.UserExternalGrants.AsNoTracking().Where(g => userId == null || g.UserId == userId)
            .Select(g => new { g.UserId, g.ExternalPermissionId, g.AccessLevel }).ToListAsync(ct))
        .ToLookup(g => g.UserId, g => (g.ExternalPermissionId, g.AccessLevel));

    private List<ExternalDiffItem> Diff(AuthorizationModel model, ExternalRequirementCatalog catalog, int userId,
        IReadOnlyDictionary<int, ExternalAccessLevel?> current, bool includeUnchanged) =>
        ExternalDiff.Compute(catalog.ForUser(model, model.GetEffective(userId, clock.UtcNow)), current, catalog.Target, includeUnchanged);
}
