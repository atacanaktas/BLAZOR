using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Governance;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.Changes;

public sealed record AccessDelta(int ResourceScopeId, string Key, string Name, string Path, bool Conditional, IReadOnlyList<string> Sources);

/// <summary>Kullanıcı yetkiyi KORUR ama kaynağı (veya koşulluluğu) değişir.</summary>
public sealed record AccessSourceChange(int ResourceScopeId, string Key, string Name, IReadOnlyList<string> Before, IReadOnlyList<string> After);

public sealed record UserImpact(
    int UserId, string UserName, string FullName, string Tenant,
    IReadOnlyList<AccessDelta> AddedAccesses,
    IReadOnlyList<AccessDelta> RemovedAccesses,
    IReadOnlyList<AccessSourceChange> RetainedAccesses,
    IReadOnlyList<string> AddedRoles, IReadOnlyList<string> RemovedRoles,
    IReadOnlyList<string> AddedGroups, IReadOnlyList<string> RemovedGroups,
    IReadOnlyList<SodConflict> NewSodConflicts,
    /// <summary>Dış sistemde (RACF/LDAP) açılacak veya seviyesi değişecek yetkiler (PreviousLevel doluysa seviye değişimi).</summary>
    IReadOnlyList<External.ExternalChange> ExternalGrants,
    /// <summary>Dış sistemde kapanacak yetkiler (kalan hiçbir etkin yetki onları gerektirmiyor).</summary>
    IReadOnlyList<External.ExternalChange> ExternalRevokes)
{
    public bool AccessesChanged => AddedAccesses.Count + RemovedAccesses.Count > 0;
    public bool HasChanges => AccessesChanged || RetainedAccesses.Count + AddedRoles.Count + RemovedRoles.Count + AddedGroups.Count + RemovedGroups.Count > 0;
}

public sealed record SodFinding(int UserId, string UserName, SodConflict Conflict);

/// <summary>Bir değişikliğin etki analizi. Blocked: engelleyici SoD çakışması var (PAP değişikliği uygulamamalı).</summary>
public sealed class ChangeImpactResult
{
    public bool Blocked { get; set; }
    public string Summary { get; set; } = "";
    public int AffectedUserCount { get; init; }
    public int EvaluatedUserCount { get; init; }
    /// <summary>Analizin yapıldığı model versiyonu (PAP uygularken eski analize dayanmadığını kontrol edebilir).</summary>
    public long ModelVersion { get; init; }
    public IReadOnlyList<UserImpact> Users { get; init; } = [];
    public IReadOnlyList<SodFinding> BlockingConflicts { get; init; } = [];
    public IReadOnlyList<SodFinding> Warnings { get; init; } = [];
}

/// <summary>
/// Etki analizi isteği: kimlik değişiklikleri (rol ataması, grup...) ve/veya tanım satırı işlemleri (ModelPatch) ve/veya
/// policy/condition değişiklikleri — hepsi kaydedilmemiş taslaktır.
/// </summary>
public sealed class ImpactRequest
{
    public AuthorizationChangeSet? Changes { get; set; }
    public List<ModelPatchOperation>? Patch { get; set; }
    public PolicyChangeSet? PolicyChanges { get; set; }
}

/// <summary>
/// Erişimi etkileyen değişikliklerin etki analizi (SALT OKUNUR). Uygulama (entity yazımı, audit, outbox, SoD ihlal kaydı) PAP'ındır.
///   1. Güncel model ve değişiklik uygulanmış What-If modeli kurulur (karar motoruyla AYNI Build)
///   2. Her kullanıcı için önce/sonra etkin erişim karşılaştırılır (kazanır / kaybeder / başka kaynaktan korur)
///   3. Yeni SoD çakışmaları (Block / Warn) ve RACF/LDAP gereksinim farkı
/// </summary>
public sealed class ImpactAnalysisService(IYetkiDbContext db, AuthorizationModelProvider models, SodService sod, IClock clock)
{
    public async Task<ChangeImpactResult> AnalyzeAsync(ImpactRequest request, CancellationToken ct = default) =>
        await AnalyzeAsync(await models.GetCurrentAsync(ct),
            await models.BuildWhatIfAsync(request.Changes, request.PolicyChanges, request.Patch, ct), ct);

    public Task<ChangeImpactResult> AnalyzeAsync(AuthorizationChangeSet changes, CancellationToken ct = default) =>
        AnalyzeAsync(new ImpactRequest { Changes = changes }, ct);

    public async Task<ChangeImpactResult> AnalyzeAsync(AuthorizationModel before, AuthorizationModel after, CancellationToken ct)
    {
        var now = clock.UtcNow;
        var rules = await sod.LoadActiveRulesAsync(ct);

        // TODO(perf): 20K+ kullanıcıda aday kullanıcıları değişikliğe göre daralt ve asenkron job'a taşı.
        var raw = new List<(EffectiveAccessSet Before, EffectiveAccessSet After)>();
        foreach (var u in after.Users.Values)
        {
            if (!before.Users.ContainsKey(u.Id)) continue;
            var b = before.GetEffective(u.Id, now);
            var a = after.GetEffective(u.Id, now);
            if (!Same(b, a)) raw.Add((b, a));
        }

        // Dış sistem (RACF/LDAP): önce/sonra OLMASI GEREKEN durum farkı (kalan yetkilerden hâlâ gerekenler geri alınmaz)
        var externalCatalog = await External.ExternalRequirementCatalog.LoadAsync(db, ct);

        var impacts = new List<UserImpact>();
        foreach (var (b, a) in raw)
        {
            var bp = b.Accesses.ToDictionary(p => p.ResourceScopeId);
            var ap = a.Accesses.ToDictionary(p => p.ResourceScopeId);
            AccessDelta Delta(EffectiveAccess p) => new(p.ResourceScopeId, p.Key, p.Name, p.Path, p.Conditional, Describe(p));
            var added = ap.Values.Where(p => !bp.ContainsKey(p.ResourceScopeId)).Select(Delta).ToList();
            var removed = bp.Values.Where(p => !ap.ContainsKey(p.ResourceScopeId)).Select(Delta).ToList();
            var retained = ap.Values
                .Where(p => bp.TryGetValue(p.ResourceScopeId, out var x) && !Describe(x).ToHashSet().SetEquals(Describe(p)))
                .Select(p => new AccessSourceChange(p.ResourceScopeId, p.Key, p.Name, Describe(bp[p.ResourceScopeId]), Describe(p)))
                .ToList();

            var beforeRules = SodEvaluator.Evaluate(b, rules).Select(c => c.SodRuleId).ToHashSet();
            var newConflicts = SodEvaluator.Evaluate(a, rules).Where(c => !beforeRules.Contains(c.SodRuleId)).ToList();

            var extBefore = externalCatalog.ForUser(before, b);
            var extDiff = External.ExternalDiff.Compute(externalCatalog.ForUser(after, a),
                External.ExternalDiff.ToState(extBefore), externalCatalog.Target, previous: extBefore);

            impacts.Add(new UserImpact(a.UserId, a.UserName, a.FullName, a.Tenant, added, removed, retained,
                a.Roles.Select(r => r.Code).Except(b.Roles.Select(r => r.Code)).ToList(),
                b.Roles.Select(r => r.Code).Except(a.Roles.Select(r => r.Code)).ToList(),
                a.Groups.Select(g => g.Code).Except(b.Groups.Select(g => g.Code)).ToList(),
                b.Groups.Select(g => g.Code).Except(a.Groups.Select(g => g.Code)).ToList(),
                newConflicts,
                extDiff.Where(x => x.Action is "Grant" or "Modify").Select(External.ExternalAnalysisService.ToChange).ToList(),
                extDiff.Where(x => x.Action == "Revoke").Select(External.ExternalAnalysisService.ToChange).ToList()));
        }

        var changed = impacts.Where(i => i.HasChanges).OrderBy(i => i.UserName, StringComparer.Ordinal).ToList();
        var blocking = changed.SelectMany(u => u.NewSodConflicts.Where(c => c.Enforcement == SodEnforcement.Block).Select(c => new SodFinding(u.UserId, u.UserName, c))).ToList();
        var warnings = changed.SelectMany(u => u.NewSodConflicts.Where(c => c.Enforcement == SodEnforcement.Warn).Select(c => new SodFinding(u.UserId, u.UserName, c))).ToList();

        return new ChangeImpactResult
        {
            AffectedUserCount = changed.Count(u => u.AccessesChanged),
            EvaluatedUserCount = after.Users.Count,
            ModelVersion = before.Version,
            Users = changed,
            BlockingConflicts = blocking,
            Warnings = warnings,
            Blocked = blocking.Count > 0,
            Summary = BuildSummary(changed, blocking, warnings)
        };
    }

    private static IReadOnlyList<string> Describe(EffectiveAccess p) =>
        p.Sources.Select(s => s.Path).Concat(p.Conditional ? [$"koşullu: {string.Join(", ", p.Conditions)}"] : []).ToList();

    private static bool Same(EffectiveAccessSet a, EffectiveAccessSet b) =>
        a.Accesses.Count == b.Accesses.Count && a.Roles.Count == b.Roles.Count && a.Groups.Count == b.Groups.Count
        && a.Groups.Select(g => g.GroupId).SequenceEqual(b.Groups.Select(g => g.GroupId))
        && a.Roles.Select(r => r.RoleId).SequenceEqual(b.Roles.Select(r => r.RoleId))
        && a.Accesses.Zip(b.Accesses).All(x => x.First.ResourceScopeId == x.Second.ResourceScopeId && x.First.Conditional == x.Second.Conditional
            && x.First.Sources.Select(s => s.Path).SequenceEqual(x.Second.Sources.Select(s => s.Path)));

    private static string BuildSummary(List<UserImpact> users, List<SodFinding> blocking, List<SodFinding> warnings)
    {
        var added = users.Sum(u => u.AddedAccesses.Count);
        var removed = users.Sum(u => u.RemovedAccesses.Count);
        var s = $"{users.Count(u => u.AccessesChanged)} kullanıcının erişimi değişir " +
                $"({users.Count(u => u.AddedAccesses.Count > 0)} kullanıcı +{added} yetki kazanır, {users.Count(u => u.RemovedAccesses.Count > 0)} kullanıcı -{removed} yetki kaybeder).";
        var retained = users.Sum(u => u.RetainedAccesses.Count);
        if (retained > 0) s += $" {retained} yetkinin kaynağı değişir (başka policy'den korunur).";
        var groupMoves = users.Sum(u => u.AddedGroups.Count + u.RemovedGroups.Count);
        if (groupMoves > 0) s += $" {groupMoves} grup üyeliği değişir.";
        if (blocking.Count > 0) s += $" {blocking.Count} ENGELLEYİCİ SoD çakışması.";
        if (warnings.Count > 0) s += $" {warnings.Count} SoD uyarısı.";
        return s;
    }
}
