using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Yetki.Pdp.Application.Abstractions;

namespace Yetki.Pdp.Application.Definitions;

/// <summary>
/// Client'ların motora kimlik doğrulaması (doğrulama tarafı). Secret oluşturma / iptal PAP'ındır; burada sadece
/// SHA-256 özetiyle sabit zamanlı karşılaştırma yapılır ve secret'ın son kullanım zamanı güncellenir.
/// </summary>
public sealed class ClientCredentialService(IYetkiDbContext db, IClock clock)
{
    /// <summary>client_id + secret doğrulaması. Başarılıysa client kodu döner.</summary>
    public async Task<string?> ValidateAsync(string clientId, string secret, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(secret)) return null;
        var code = clientId.Trim().ToLowerInvariant();
        var client = await db.Clients.FirstOrDefaultAsync(c => c.ClientId == code, ct);
        if (client is null || !client.IsActive) return null;
        var hash = Hash(secret.Trim());
        var now = clock.UtcNow;
        var candidates = await db.ClientSecrets.Where(s => s.ClientId == client.Id && s.RevokedAt == null).ToListAsync(ct);
        var match = candidates.FirstOrDefault(s => (s.ExpiresAt == null || s.ExpiresAt > now)
            && CryptographicOperations.FixedTimeEquals(Encoding.ASCII.GetBytes(s.SecretHash), Encoding.ASCII.GetBytes(hash)));
        if (match is null) return null;
        match.LastUsedAt = now;
        await db.SaveChangesAsync(ct);
        return client.ClientId;
    }

    public static string Hash(string plain) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(plain))).ToLowerInvariant();
}
