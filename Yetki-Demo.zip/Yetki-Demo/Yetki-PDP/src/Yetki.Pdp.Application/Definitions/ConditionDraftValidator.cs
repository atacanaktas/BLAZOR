using Microsoft.EntityFrameworkCore;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Common;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Application.PolicyEngine;
using Yetki.Pdp.Application.PolicyEngine.Conditions;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Application.Definitions;

/// <summary>
/// Condition taslağı doğrulaması. Condition tiplerinin davranışı (handler'lar) PDP'de yaşadığı için doğrulama da buradadır:
/// PAP bir rule kaydetmeden önce /api/analysis/conditions/validate ile doğrulatır (normalize edilmiş taslak + id'ler döner).
/// </summary>
public sealed class ConditionDraftValidator(IYetkiDbContext db, ConditionHandlerRegistry handlers)
{

    public sealed record ConditionValidation(IReadOnlyDictionary<string, int> Types, IReadOnlyDictionary<string, int> Policies);

    /// <summary>
    /// Condition ağacını doğrular (yapı, derinlik, predicate parametreleri, policy referansları).
    /// selfPolicyId: kuralın ait olduğu policy — referans verilen policy o policy'nin kurumunda (veya üst kurumunda) olmalı ve
    /// doğrudan / dolaylı (aggregate üyesi veya kural referansı zinciriyle) kendisine dönmemeli (döngü).
    /// </summary>
    public async Task<ConditionValidation> ValidateConditionAsync(ConditionDraft root, CancellationToken ct, int? selfPolicyId = null)
    {
        var errors = new List<string>();
        var codes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var refs = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        void Walk(ConditionDraft n, int depth, string path)
        {
            if (depth > PolicyEvaluator.MaxConditionDepth) { errors.Add($"{path}: ağaç en fazla {PolicyEvaluator.MaxConditionDepth} seviye olabilir."); return; }
            switch (n.Kind)
            {
                case ConditionKind.Predicate:
                    if (string.IsNullOrWhiteSpace(n.ConditionTypeCode)) { errors.Add($"{path}: condition tipi zorunlu."); return; }
                    if (n.Children.Count > 0) errors.Add($"{path}: predicate çocuk içeremez.");
                    var handler = handlers.Find(n.ConditionTypeCode);
                    if (handler is null) { errors.Add($"{path}: bilinmeyen condition tipi '{n.ConditionTypeCode}'."); return; }
                    codes.Add(handler.Descriptor.Code);
                    var ps = n.Parameters.Where(kv => !string.IsNullOrWhiteSpace(kv.Value))
                        .ToDictionary(kv => kv.Key.Trim(), kv => kv.Value.Trim(), StringComparer.OrdinalIgnoreCase);
                    errors.AddRange(handler.ValidateParameters(ps).Select(e => $"{path} ({handler.Descriptor.Code}): {e}"));
                    n.Parameters = ps;
                    n.ConditionTypeCode = handler.Descriptor.Code;
                    break;
                case ConditionKind.Reference:
                    if (string.IsNullOrWhiteSpace(n.PolicyCode)) { errors.Add($"{path}: policy seçilmeli."); return; }
                    if (n.Children.Count > 0) errors.Add($"{path}: policy referansı çocuk içeremez.");
                    n.PolicyCode = Codes.Normalize(n.PolicyCode);
                    refs.Add(n.PolicyCode);
                    n.Parameters = new();
                    n.ConditionTypeCode = null;
                    break;
                case ConditionKind.Not:
                    if (n.Children.Count != 1) errors.Add($"{path}: NOT tam olarak bir alt koşul içermeli.");
                    break;
                default:
                    if (n.Children.Count == 0) errors.Add($"{path}: AND/OR en az bir alt koşul içermeli.");
                    break;
            }
            for (var i = 0; i < n.Children.Count; i++) Walk(n.Children[i], depth + 1, $"{path}.{i + 1}");
        }

        Walk(root, 0, "condition");

        var refList = refs.ToList();
        var policies = await db.Policies.AsNoTracking().Where(x => refList.Contains(x.Code)).Select(x => new { x.Id, x.Code, x.TenantId, x.IsActive }).ToListAsync(ct);
        foreach (var r in refList)
        {
            var p = policies.FirstOrDefault(x => x.Code == r);
            if (p is null) errors.Add($"Policy bulunamadı: {r}");
            else if (!p.IsActive) errors.Add($"Policy pasif: {r}");
        }
        if (selfPolicyId is { } self && policies.Count > 0)
        {
            var owner = await db.Policies.AsNoTracking().Where(x => x.Id == self).Select(x => new { x.TenantId }).FirstOrDefaultAsync(ct);
            if (owner is not null)
            {
                var chain = await TenantChainAsync(owner.TenantId, ct);
                foreach (var p in policies.Where(p => !chain.Contains(p.TenantId)))
                    errors.Add($"Policy {p.Code} bu policy'nin kurumunda (veya üst kurumunda) değil; kullanılamaz.");
            }
            if (policies.Any(p => p.Id == self) || (await ReachableAsync(policies.Select(x => x.Id), ct)).Contains(self))
                errors.Add("Döngüsel referans: policy doğrudan veya dolaylı olarak kendine referans veriyor.");
        }

        if (errors.Count > 0) throw ValidationException.Of("condition", errors);

        var codeList = codes.ToList();
        var types = await db.ConditionTypes.Where(t => codeList.Contains(t.Code) && t.IsAvailable).ToDictionaryAsync(t => t.Code, t => t.Id, StringComparer.OrdinalIgnoreCase, ct);
        var missing = codeList.Where(c => !types.ContainsKey(c)).ToList();
        if (missing.Count > 0) throw new ValidationException($"Katalogda olmayan condition tipi: {string.Join(", ", missing)}");
        return new ConditionValidation(types, policies.ToDictionary(x => x.Code, x => x.Id, StringComparer.OrdinalIgnoreCase));
    }

    /// <summary>Kurum + üst kurumları.</summary>
    private async Task<HashSet<int>> TenantChainAsync(int tenantId, CancellationToken ct)
    {
        var parents = await db.Tenants.AsNoTracking().ToDictionaryAsync(t => t.Id, t => t.ParentId, ct);
        var chain = new HashSet<int>();
        for (int? t = tenantId; t is { } id && chain.Add(id); t = parents.GetValueOrDefault(id)) { }
        return chain;
    }

    /// <summary>Policy'lerden kural içi referanslar üzerinden ulaşılabilen policy'ler.</summary>
    private async Task<HashSet<int>> ReachableAsync(IEnumerable<int> start, CancellationToken ct)
    {
        var edges = (await db.RuleConditions.AsNoTracking().Where(c => c.ReferencedPolicyId != null)
            .Select(c => new { From = c.Rule.PolicyId, To = c.ReferencedPolicyId!.Value }).ToListAsync(ct)).ToLookup(e => e.From, e => e.To);
        var seen = new HashSet<int>();
        var stack = new Stack<int>(start);
        while (stack.Count > 0)
        {
            var id = stack.Pop();
            if (!seen.Add(id)) continue;
            foreach (var next in edges[id]) stack.Push(next);
        }
        return seen;
    }
}
