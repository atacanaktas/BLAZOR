using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Pdp.Api.Infrastructure;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Evaluation;
using Yetki.Pdp.Application.External;
using Yetki.Pdp.Application.Governance;
using Yetki.Pdp.Application.Identity;
using Yetki.Pdp.Application.Inventory;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Application.PolicyEngine;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Api.Controllers;

// ============================================================================================
//  YÖNETİM GÖRÜNÜMLERİ (/api/analysis/views/*) — sadece PAP çağırır (X-Service-Key).
//  Derlenmiş yetki modeli üzerinden hesaplanan okuma ekranları: "kimde var, neden?", kapsam, etkin yetki, üyelik, kullanım.
//  PAP'ta motor yoktur; PAP bu uçları aynı yol ve aynı JSON ile yönetim konsoluna iletir (yol: /api/<x> → /api/analysis/views/<x>).
//  Hiçbiri veri yazmaz.
// ============================================================================================

/// <summary>Condition ağacının UI gösterimi (What-If parametre değişikliği için id'li). Reference düğümü: Policy / PolicyId = koşul olarak kullanılan policy.</summary>
public sealed record ConditionView(int Id, ConditionKind Kind, string? ConditionType, IReadOnlyDictionary<string, string> Parameters,
    IReadOnlyList<ConditionView> Children, string? Policy, int? PolicyId, int? PolicyVersion);

public static class Views
{
    public static ConditionView? Condition(ConditionNode? n) => n is null ? null : new ConditionView(
        n.Id, n.Kind, n.ConditionTypeCode, n.Parameters, n.Children.Select(c => Condition(c)!).ToList(), n.ReferenceCode, n.ReferencePolicyId, n.ReferenceVersion);

    /// <summary>
    /// Bu değeri (rol kodu, grup kodu, kullanıcı adı, client) kartlarında kullanan policy'ler: hangi kart (kural) ve policy'yi kullanan
    /// permission'lar. Rol / grup / kullanıcı / client sayfalarının "nerede kullanılıyor?" cevabı.
    /// </summary>
    public static IReadOnlyList<CardUsage> Mentions(AuthorizationModel m, string conditionType, string param, string value) =>
        m.PoliciesMentioning(conditionType, param, value)
            .Select(x => new CardUsage(x.Policy.Row.Id, x.Policy.Row.Code, x.Policy.Row.Name, x.Rule.RuleId, x.Rule.Code, x.Rule.Name,
                m.PermissionsUsingPolicy(x.Policy.Row.Id).Select(p => p.Row.Code).ToList()))
            .ToList();

    public static string Describe(IEnumerable<GroupFilterRow> filters)
    {
        var list = filters.ToList();
        if (list.Count == 0) return "(kural yok — sadece açık üyeler)";
        return string.Join(" ∪ ", list.Where(f => f.Mode == InclusionMode.Include).Select(Part))
               + string.Concat(list.Where(f => f.Mode == InclusionMode.Exclude).Select(f => " − " + Part(f)));

        static string Part(GroupFilterRow f) => "(" + string.Join(" ∧ ", f.Criteria.Select(c => $"{c.Attribute}∈{{{string.Join(",", c.Values)}}}")) + ")";
    }

    /// <summary>Policy'yi kuralında (HAZIR POLICY kartı) referansla kullanan policy'ler (doğrudan).</summary>
    public static IReadOnlyList<object> UsedBy(AuthorizationModel m, int policyId) =>
        m.Policies.Values.Where(p => p.Row.Id != policyId)
            .Select(p => new
            {
                p, rules = p.Definition.Rules.Where(r => PolicyEvaluator.Flatten(r.Condition).Any(n => n.Kind == ConditionKind.Reference && n.ReferencePolicyId == policyId))
                    .Select(r => r.Code).ToList()
            })
            .Where(x => x.rules.Count > 0)
            .OrderBy(x => x.p.Row.Code, StringComparer.Ordinal)
            .Select(x => (object)new { id = x.p.Row.Id, code = x.p.Row.Code, name = x.p.Row.Name, via = $"kural {string.Join(", ", x.rules)}" })
            .ToList();
}

/// <summary>Bir değerin (rol, grup, kullanıcı, client) bir policy kartında kullanımı.</summary>
public sealed record CardUsage(int PolicyId, string Policy, string PolicyName, int RuleId, string Rule, string RuleName, IReadOnlyList<string> Permissions);

// ================================ Katalog ================================

[ApiController]
[Route("api/analysis/views")]
[RequireServiceKey]
public sealed class CatalogViewsController(AuthorizationModelProvider models, IYetkiDbContext db, IClock clock) : ControllerBase
{
    /// <summary>Tenant → uygulama → resource listesi. Ağaç (URL kırılımı / üst-alt) istemcide bu listeden kurulur.</summary>
    [HttpGet("resources/tree")]
    public async Task<object> Tree([FromQuery] int? applicationId, [FromQuery] bool includeResources = true, CancellationToken ct = default)
    {
        var m = await models.GetCurrentAsync(ct);
        object ResourceView(ResourceRow r) => new
        {
            r.Id, r.Code, r.Name, r.IsActive, r.ParentId, r.ExternalCode, r.Order,
            type = m.ResourceTypes[r.ResourceTypeId].Code, typeName = m.ResourceTypes[r.ResourceTypeId].Name,
            color = m.ResourceTypes[r.ResourceTypeId].Color, matchesHttp = m.ResourceTypes[r.ResourceTypeId].MatchesHttp,
            scopes = m.ScopesOf(r.Id).Select(s => s.Scope.Code).OrderBy(s => s).ToList(),
            uris = m.UrisOf(r.Id).OrderBy(u => u.Pattern, StringComparer.Ordinal).Select(u => new { u.Method, u.Pattern }).ToList(),
            group = AuthorizationModel.UrlGroup(m.UrisOf(r.Id).Select(u => u.Pattern)),
            protectedScopes = m.ScopesOf(r.Id).Count(s => m.PermissionsFor(s.Id).Count > 0)
        };

        return m.Tenants.Values.OrderBy(t => t.Id).Select(t => new
        {
            t.Id, t.Code, t.Name,
            applications = m.Apps.Values.Where(a => a.TenantId == t.Id && (applicationId is null || a.Id == applicationId.Value)).OrderBy(a => a.Code, StringComparer.Ordinal).Select(a => new
            {
                a.Id, a.Code, a.Name, a.Type, a.IsActive, strategy = a.Strategy,
                resourceCount = m.Resources.Values.Count(r => r.ApplicationId == a.Id),
                scopeCount = m.Scopes.Values.Count(s => s.ApplicationId == a.Id),
                permissionCount = m.Permissions.Values.Count(p => p.Row.ApplicationId == a.Id),
                resourcesLoaded = includeResources,
                resources = includeResources
                    ? m.Resources.Values.Where(r => r.ApplicationId == a.Id).OrderBy(r => r.Order).ThenBy(r => r.Code, StringComparer.Ordinal).Select(ResourceView).ToList()
                    : []
            }).ToList()
        }).Where(t => applicationId is null || t.applications.Count > 0).ToList();
    }

    [HttpGet("applications/{id:int}")]
    public async Task<object> Application(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Apps.TryGetValue(id, out var a)) throw new NotFoundException("Uygulama", id);
        var meta = await db.Applications.AsNoTracking().Where(x => x.Id == id).Select(x => new
        {
            x.Description, x.OwnerTeamId, ownerTeam = x.OwnershipTeam != null ? x.OwnershipTeam.Name : null, x.OwnerUserId
        }).FirstAsync(ct);
        return new
        {
            application = new { a.Id, a.Code, a.Name, a.Type, a.IsActive, a.TenantId, tenant = m.TenantCode(a.TenantId), decisionStrategy = a.Strategy, meta.Description, meta.OwnerTeamId, meta.ownerTeam, meta.OwnerUserId },
            scopes = m.Scopes.Values.Where(s => s.ApplicationId == id).OrderBy(s => s.Code, StringComparer.Ordinal)
                .Select(s => new { s.Id, s.Code, s.Name, resourceCount = m.ResourceScopes.Values.Count(x => x.Scope.Id == s.Id) }).ToList(),
            permissions = m.Permissions.Values.Where(p => p.Row.ApplicationId == id).OrderBy(p => p.Row.Code, StringComparer.Ordinal)
                .Select(p => new { p.Row.Id, p.Row.Code, p.Row.Name, p.Row.IsActive, coverage = m.CoverageOf(p).Count() }).ToList(),
            clients = m.ClientsById.Values.Where(c => c.ApplicationId == id).Select(c => new { c.Id, c.ClientId, c.Name }).ToList()
        };
    }

    [HttpGet("resource-types")]
    public async Task<object> ResourceTypes(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var meta = await db.ResourceTypes.AsNoTracking().ToDictionaryAsync(t => t.Id, t => t.Description, ct);
        return m.ResourceTypes.Values.OrderBy(t => t.Code, StringComparer.Ordinal).Select(t => new
        {
            t.Id, t.Code, t.Name, description = meta.GetValueOrDefault(t.Id), t.MatchesHttp, t.SupportsHierarchy, t.Color, t.IsActive,
            resourceCount = m.Resources.Values.Count(r => r.ResourceTypeId == t.Id),
            permissionCount = m.Permissions.Values.Count(p => p.Row.ResourceTypeId == t.Id)
        }).ToList();
    }

    [HttpGet("scopes")]
    public async Task<object> Scopes([FromQuery] int? applicationId, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var meta = await db.Scopes.AsNoTracking().ToDictionaryAsync(s => s.Id, s => s.Description, ct);
        return m.Scopes.Values.Where(s => applicationId is null || s.ApplicationId == applicationId)
            .OrderBy(s => s.ApplicationId).ThenBy(s => s.Code, StringComparer.Ordinal).Select(s => new
            {
                s.Id, s.Code, s.Name, description = meta.GetValueOrDefault(s.Id), s.ApplicationId, application = m.Apps.GetValueOrDefault(s.ApplicationId)?.Code,
                resourceCount = m.ResourceScopes.Values.Count(x => x.Scope.Id == s.Id)
            }).ToList();
    }

    /// <summary>Resource detayı: scope'lar (yetkiler) ve her birini koruyan permission'lar, URI eşlemeleri, üst/alt resource'lar.</summary>
    [HttpGet("resources/{id:int}")]
    public async Task<object> Resource(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Resources.TryGetValue(id, out var r)) throw new NotFoundException("Resource", id);
        var now = clock.UtcNow;
        var meta = await db.Resources.AsNoTracking().Where(x => x.Id == id).Select(x => new
        {
            x.Description, x.OwnerTeamId, ownerTeam = x.OwnershipTeam != null ? x.OwnershipTeam.Name : null
        }).FirstAsync(ct);
        var type = m.ResourceTypes[r.ResourceTypeId];
        return new
        {
            resource = new
            {
                r.Id, r.Code, r.Name, r.IsActive, r.Order, r.ApplicationId, application = m.Apps[r.ApplicationId].Code, r.ExternalCode,
                path = m.PathOf(r.Id), r.ResourceTypeId, type = type.Code, typeName = type.Name,
                type.MatchesHttp, type.SupportsHierarchy, r.ParentId, parent = r.ParentId is { } p && m.Resources.TryGetValue(p, out var pr) ? pr.Code : null,
                meta.Description, meta.OwnerTeamId, meta.ownerTeam
            },
            scopes = m.ScopesOf(id).OrderBy(s => s.Scope.Code, StringComparer.Ordinal).Select(s => new
            {
                resourceScopeId = s.Id, scopeId = s.Scope.Id, s.Scope.Code, s.Scope.Name, s.Key, riskLevel = s.Row.RiskLevel,
                permissions = m.PermissionsFor(s.Id).Select(p => new { p.Row.Id, p.Row.Code, p.Row.Name, identity = m.HasIdentityPolicy(p) }).ToList(),
                holderCount = m.HoldersOf(s.Id, now).Count()
            }).ToList(),
            uris = m.UrisOf(id).OrderBy(u => u.Pattern, StringComparer.Ordinal).ThenBy(u => u.Method).Select(u => new
            {
                u.Id, u.Method, u.Pattern, u.ScopeId, scope = m.Scopes.GetValueOrDefault(u.ScopeId)?.Code
            }).ToList(),
            children = m.Resources.Values.Where(c => c.ParentId == id).OrderBy(c => c.Order).Select(c => new { c.Id, c.Code, c.Name, type = m.ResourceTypes[c.ResourceTypeId].Code }).ToList()
        };
    }

    /// <summary>URI eşleştirme testi: bu METHOD + path hangi yetkiye eşlenir? (karar vermez, katalog kontrolü)</summary>
    [HttpGet("uri-match")]
    public async Task<object> MatchUri([FromQuery] string method, [FromQuery] string path, [FromQuery] string? application, [FromQuery] string? tenant, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var tenantId = tenant is not null && m.TenantByCode.TryGetValue(tenant, out var t) ? t.Id : m.Tenants.Keys.Min();
        var (match, ambiguous) = m.MatchHttp(application, method, path, tenantId);
        return new
        {
            matched = match is null ? null : new { match.Access.Key, match.Access.Name, uri = $"{match.Uri.Method} {match.Uri.Pattern}", application = match.Access.App.Code, resourceId = match.Access.Resource.Id },
            ambiguous = ambiguous.Select(a => new { a.Access.Key, uri = $"{a.Uri.Method} {a.Uri.Pattern}" }).ToList()
        };
    }

    [HttpGet("resource-scopes")]
    public async Task<object> ResourceScopes([FromQuery] string? q, [FromQuery] int? applicationId, [FromQuery] string? type, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        return m.ResourceScopes.Values
            .Where(x => applicationId is null || x.App.Id == applicationId)
            .Where(x => type is null || x.Type.Code.Equals(type, StringComparison.OrdinalIgnoreCase))
            .Where(x => string.IsNullOrWhiteSpace(q) || x.Key.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Name.Contains(q, StringComparison.OrdinalIgnoreCase))
            .OrderBy(x => x.Key, StringComparer.Ordinal)
            .Select(x => new
            {
                x.Id, x.Key, x.Name, application = x.App.Code, resourceId = x.Resource.Id, resource = x.Resource.Code, resourceType = x.Type.Code, color = x.Type.Color,
                scope = x.Scope.Code, x.Path, riskLevel = x.Row.RiskLevel, x.IsActive,
                permissions = m.PermissionsFor(x.Id).Select(p => p.Row.Code).ToList(),
                uris = m.UrisOf(x.Resource.Id).Where(u => u.ScopeId == x.Scope.Id).Select(u => $"{u.Method} {u.Pattern}").ToList(),
                holderCount = m.HoldersOf(x.Id, now).Count()
            }).ToList();
    }

    /// <summary>"Kimde var, neden?" — etkin sahipler ve kaynak yolları.</summary>
    [HttpGet("resource-scopes/{id:int}/holders")]
    public async Task<object> Holders(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.ResourceScopes.ContainsKey(id)) throw new NotFoundException("Yetki", id);
        return m.HoldersOf(id, clock.UtcNow).Select(h => new
        {
            userId = h.User.Id, h.User.UserName, h.User.FullName, tenant = m.TenantCode(h.User.TenantId), units = m.UnitCodesOf(h.User.Id).ToList(),
            h.Access.Conditional, h.Access.Conditions, sources = h.Access.Sources.Select(s => new { s.Permission, s.Policy, s.Path }).ToList()
        }).ToList();
    }

    [HttpGet("clients")]
    public async Task<object> Clients(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var meta = await db.Clients.AsNoTracking().ToDictionaryAsync(c => c.Id, c => c.Description, ct);
        var now = clock.UtcNow;
        var secrets = (await db.ClientSecrets.AsNoTracking().Select(s => new { s.ClientId, s.RevokedAt, s.ExpiresAt, s.LastUsedAt }).ToListAsync(ct))
            .GroupBy(s => s.ClientId).ToDictionary(g => g.Key, g => new
            {
                active = g.Count(s => s.RevokedAt == null && (s.ExpiresAt == null || s.ExpiresAt > now)),
                lastUsedAt = g.Max(s => s.LastUsedAt)
            });
        return m.ClientsById.Values.OrderBy(c => c.Id).Select(c => new
        {
            c.Id, c.ClientId, c.Name, c.Type, c.IsActive, description = meta.GetValueOrDefault(c.Id), c.TenantId, tenant = m.TenantCode(c.TenantId),
            application = c.ApplicationId is { } a && m.Apps.TryGetValue(a, out var app) ? app.Code : null, c.ApplicationId,
            serviceAccount = c.ServiceAccountUserId is { } u && m.Users.TryGetValue(u, out var user) ? user.UserName : null, c.ServiceAccountUserId,
            policies = Views.Mentions(m, "CLIENT_IN", "Clients", c.ClientId).Select(x => x.Policy).Distinct().ToList(),
            queryApplicationIds = m.ScopeOf(c).Applications, queryApplications = m.ScopeOf(c).Applications.Select(a => m.Apps.GetValueOrDefault(a)?.Code).ToList(),
            queryTenantIds = m.ScopeOf(c).Tenants, queryTenants = m.ScopeOf(c).Tenants.Select(m.TenantCode).ToList(),
            onBehalfOfClientIds = m.ScopeOf(c).OnBehalfOf, onBehalfOf = m.ScopeOf(c).OnBehalfOf.Select(m.ClientCodeOf).ToList(),
            rateLimitPerMinute = m.ScopeOf(c).RateLimitPerMinute,
            activeSecrets = secrets.GetValueOrDefault(c.Id)?.active ?? 0, secretLastUsedAt = secrets.GetValueOrDefault(c.Id)?.lastUsedAt
        }).ToList();
    }

    [HttpGet("inventory/{applicationId:int}/coverage")]
    public Task<CoverageReport> Coverage(int applicationId, [FromServices] InventoryService inventory, CancellationToken ct) => inventory.CoverageAsync(applicationId, ct);

    /// <summary>
    /// UI seçim listeleri: users, roles, groups, tenants, units, applications, teams, resource-types, resources, scopes,
    /// resource-scopes, clients, policies, permissions, external-permissions.
    /// </summary>
    [HttpGet("options/{kind}")]
    public async Task<object> Options(string kind, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return kind switch
        {
            "users" => m.Users.Values.OrderBy(u => u.UserName).Select(u => O(u.Id, $"{u.UserName} — {u.FullName}", m.TenantCode(u.TenantId), u.UserName)).ToList(),
            "roles" => m.Roles.Values.OrderBy(r => r.Code).Select(r => O(r.Id, $"{r.Code} — {r.Name}", m.TenantCode(r.TenantId), r.Code)).ToList(),
            "groups" => m.Groups.Values.OrderBy(g => g.Code).Select(g => O(g.Id, $"{g.Code} — {g.Name}", m.TenantCode(g.TenantId), g.Code)).ToList(),
            "tenants" => m.Tenants.Values.OrderBy(o => o.Id).Select(o => O(o.Id, $"{o.Code} — {o.Name}", null, o.Code)).ToList(),
            "units" => m.Units.Values.OrderBy(u => u.TenantId).ThenBy(u => u.Code).Select(u => O(u.Id, $"{u.Code} — {u.Name}", m.TenantCode(u.TenantId), u.Code)).ToList(),
            "applications" => m.Apps.Values.OrderBy(a => a.Id).Select(a => O(a.Id, $"{a.Code} — {a.Name}", m.TenantCode(a.TenantId), a.Code)).ToList(),
            "teams" => await db.OwnershipTeams.AsNoTracking().Where(t => t.IsActive).OrderBy(t => t.Tenant.Code).ThenBy(t => t.Code)
                .Select(t => O(t.Id, t.Code + " — " + t.Name, t.Tenant.Code, t.Code)).ToListAsync(ct),
            "resource-types" => m.ResourceTypes.Values.OrderBy(t => t.Code).Select(t => O(t.Id, $"{t.Code} — {t.Name}", t.MatchesHttp ? "HTTP" : "UI / mantıksal", t.Code)).ToList(),
            "resources" => m.Resources.Values.OrderBy(r => r.Code).Select(r => O(r.Id, $"{r.Code} — {r.Name} ({m.ResourceTypes[r.ResourceTypeId].Code})", m.Apps[r.ApplicationId].Code, r.Code)).ToList(),
            "scopes" => m.Scopes.Values.OrderBy(s => s.ApplicationId).ThenBy(s => s.Code).Select(s => O(s.Id, $"{s.Code} — {s.Name}", m.Apps.GetValueOrDefault(s.ApplicationId)?.Code, s.Code)).ToList(),
            "resource-scopes" => m.ResourceScopes.Values.OrderBy(x => x.Key).Select(x => O(x.Id, $"{x.Key} — {x.Name}", x.App.Code, x.Key)).ToList(),
            "clients" => m.ClientsById.Values.OrderBy(c => c.Id).Select(c => O(c.Id, $"{c.ClientId} — {c.Name} ({m.TenantCode(c.TenantId)})", m.TenantCode(c.TenantId), c.ClientId)).ToList(),
            "policies" => m.Policies.Values.OrderBy(p => p.Row.Code).Select(p => O(p.Row.Id, $"{p.Row.Code} — {p.Row.Name}", p.TenantCode, p.Row.Code)).ToList(),
            "permissions" => m.Permissions.Values.OrderBy(p => p.Row.Code).Select(p => O(p.Row.Id, $"{p.Row.Code} — {p.Row.Name}", p.App.Code, p.Row.Code)).ToList(),
            "external-permissions" => await db.ExternalPermissions.AsNoTracking().OrderBy(p => p.Code)
                .Select(p => O(p.Id, p.ExternalSystem.Code + ":" + p.Code + " — " + p.Name, p.ExternalSystem.Code, p.Code)).ToListAsync(ct),
            _ => throw new NotFoundException("Seçim listesi", kind)
        };
    }

    private static object O(int value, string label, string? group, string code) => new { value, label, group, code };
}

// ================================ Kurum / kimlik ================================

[ApiController]
[Route("api/analysis/views")]
[RequireServiceKey]
public sealed class IdentityViewsController(AuthorizationModelProvider models, IIdentityProvider identities, EntitlementService entitlements,
    ExternalAnalysisService external, IYetkiDbContext db, IClock clock) : ControllerBase
{
    [HttpGet("tenants")]
    public async Task<object> Tenants(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.Tenants.Values.OrderBy(o => o.Id).Select(o => new
        {
            o.Id, o.Code, o.Name, o.Type, o.ParentId, parent = o.ParentId is { } p ? m.TenantCode(p) : null, o.IsActive,
            userCount = m.Users.Values.Count(u => u.TenantId == o.Id),
            roleCount = m.Roles.Values.Count(r => r.TenantId == o.Id),
            inheritedRoles = m.Roles.Values.Where(r => r.IsInheritable && r.TenantId != o.Id && m.TenantAncestors[o.Id].Contains(r.TenantId)).Select(r => r.Code).ToList(),
            groupCount = m.Groups.Values.Count(g => g.TenantId == o.Id),
            ownPolicies = m.Policies.Values.Where(p => p.Row.TenantId == o.Id).Select(p => p.Row.Code).ToList(),
            ownApplications = m.Apps.Values.Where(a => a.TenantId == o.Id).Select(a => a.Code).ToList(),
            inheritedApplications = m.Apps.Values.Where(a => a.TenantId != o.Id && m.IsAvailableIn(a.TenantId, o.Id)).Select(a => a.Code).ToList(),
            ownClients = m.ClientsById.Values.Where(c => c.TenantId == o.Id).Select(c => c.ClientId).ToList(),
            inheritedClients = m.ClientsById.Values.Where(c => c.TenantId != o.Id && m.IsAvailableIn(c.TenantId, o.Id)).Select(c => c.ClientId).ToList()
        }).ToList();
    }

    [HttpGet("org-units")]
    public async Task<object> Units([FromQuery] int? tenantId, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.Units.Values.Where(u => tenantId is null || u.TenantId == tenantId).OrderBy(u => u.TenantId).ThenBy(u => u.Id)
            .Select(u => new
            {
                u.Id, u.Code, u.Name, u.Type, u.ParentId, u.TenantId, tenant = m.TenantCode(u.TenantId),
                userCount = m.Data.UserUnits.Count(x => x.OrgUnitId == u.Id)
            }).ToList();
    }

    [HttpGet("users")]
    public async Task<object> Users([FromQuery] string? q, [FromQuery] int? tenantId, [FromQuery] int? page, [FromQuery] int pageSize = 20, CancellationToken ct = default)
    {
        var m = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        var filtered = m.Users.Values
            .Where(u => tenantId is null || u.TenantId == tenantId)
            .Where(u => string.IsNullOrWhiteSpace(q) || u.UserName.Contains(q, StringComparison.OrdinalIgnoreCase) || u.FullName.Contains(q, StringComparison.OrdinalIgnoreCase))
            .OrderBy(u => u.UserName, StringComparer.Ordinal);
        var total = filtered.Count();
        var safePageSize = Math.Clamp(pageSize, 10, 200);
        var selected = page is { } pageNumber ? filtered.Skip((Math.Max(1, pageNumber) - 1) * safePageSize).Take(safePageSize) : filtered;
        var items = selected
            .Select(u =>
            {
                var e = m.GetEffective(u.Id, now);
                return new
                {
                    u.Id, u.UserName, u.FullName, u.Title, u.Kind, u.IsActive, u.IsOnLeave, tenant = m.TenantCode(u.TenantId),
                    units = m.UnitCodesOf(u.Id).ToList(),
                    directRoles = m.DirectRoleCodes(u.Id, now).ToList(),
                    groups = e.Groups.Select(g => g.Code).ToList(),
                    accessCount = e.Accesses.Count,
                    conditionalCount = e.Accesses.Count(a => a.Conditional)
                };
            }).ToList();
        return page is null ? items : new { items, total, page = Math.Max(1, page.Value), pageSize = safePageSize };
    }

    [HttpGet("users/{id:int}")]
    public async Task<object> UserDetail(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Users.TryGetValue(id, out var u)) throw new NotFoundException("Kullanıcı", id);
        var user = await identities.GetUserAsync(id, ct) ?? throw new NotFoundException("Kullanıcı", id);
        var roles = (await identities.GetUserRolesAsync(id, ct))
            .Select(x => new { x.RoleId, Code = m.Roles.GetValueOrDefault(x.RoleId)?.Code,
                Name = m.Roles.GetValueOrDefault(x.RoleId)?.Name, x.ValidFrom, x.ValidUntil, x.Reason, x.AssignedAt, x.AssignedBy }).ToList();
        var units = m.Data.UserUnits.Where(x => x.UserId == id && m.Units.ContainsKey(x.OrgUnitId))
            .Select(x => new { x.OrgUnitId, m.Units[x.OrgUnitId].Code, m.Units[x.OrgUnitId].Name, m.Units[x.OrgUnitId].Type, x.IsPrimary }).ToList();
        var explicitGroups = await db.GroupMembers.AsNoTracking().Where(x => x.UserId == id)
            .Select(x => new { x.GroupId, x.Group.Code, x.ValidUntil }).ToListAsync(ct);
        var violations = await db.SodViolations.AsNoTracking().Where(v => v.UserId == id && v.Status != ViolationStatus.Resolved)
            .Select(v => new { v.Id, v.SodRule.Code, v.Status, v.Details, v.DetectedAt }).ToListAsync(ct);
        return new
        {
            user = new
            {
                user.Id, user.UserName, user.FullName, user.Email, user.Title, user.EmployeeNo, user.Kind, user.IsActive, user.IsOnLeave,
                user.CashWithdrawalLimit, user.CustomerNo, user.TenantId, tenant = m.TenantCode(user.TenantId)
            },
            roles, units, explicitGroups, violations,
            policies = Views.Mentions(m, "SUBJECT_IS_USER", "Users", u.UserName),
            tenantChain = m.TenantAncestors[u.TenantId].Select(m.TenantCode).ToList()
        };
    }

    [HttpGet("users/{id:int}/effective")]
    public async Task<EffectiveAccessSet> Effective(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Users.ContainsKey(id)) throw new NotFoundException("Kullanıcı", id);
        return m.GetEffective(id, clock.UtcNow);
    }

    [HttpGet("users/{id:int}/entitlements")]
    public async Task<EntitlementResult> Entitlements(int id, [FromQuery] string? client, [FromQuery] string? application,
        [FromQuery] bool evaluate, [FromQuery] string? ip, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Users.TryGetValue(id, out var u)) throw new NotFoundException("Kullanıcı", id);
        return await entitlements.GetAsync(new EntitlementRequest
        {
            User = u.UserName, Client = client, Application = application, Evaluate = evaluate,
            Context = ip is null ? new() : new() { ["IpAddress"] = ip }
        }, ct);
    }

    [HttpGet("users/{id:int}/external")]
    public Task<UserExternalStatus> External(int id, CancellationToken ct) => external.UserStatusAsync(id, ct);

    [HttpGet("roles")]
    public async Task<object> Roles(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        return m.Roles.Values.OrderBy(r => r.TenantId).ThenBy(r => r.Code, StringComparer.Ordinal).Select(r => new
        {
            r.Id, r.Code, r.Name, r.IsInheritable, r.IsActive, r.TenantId, tenant = m.TenantCode(r.TenantId),
            policies = Views.Mentions(m, "SUBJECT_HAS_ROLE", "Roles", r.Code).Select(x => x.Policy).Distinct().ToList(),
            directHolders = m.Data.UserRoles.Count(x => x.RoleId == r.Id && (x.ValidUntil == null || x.ValidUntil > now)),
            grantingGroups = m.Data.GroupRoles.Where(x => x.RoleId == r.Id && m.Groups.ContainsKey(x.GroupId)).Select(x => m.Groups[x.GroupId].Code).ToList()
        }).ToList();
    }

    /// <summary>Rol detayı: rolü KİM kartında kullanan policy'ler → onları kullanan permission'lar → kapsadıkları yetkiler; rol sahipleri.</summary>
    [HttpGet("roles/{id:int}")]
    public async Task<object> Role(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Roles.TryGetValue(id, out var r)) throw new NotFoundException("Rol", id);
        var now = clock.UtcNow;
        var holders = m.Users.Values.Select(u => (u, e: m.GetIdentity(u.Id, now).Roles.FirstOrDefault(x => x.RoleId == id)))
            .Where(x => x.e is not null)
            .Select(x => new { userId = x.u.Id, x.u.UserName, x.u.FullName, tenant = m.TenantCode(x.u.TenantId), sources = x.e!.Sources.Select(s => s.Text).ToList() })
            .ToList();
        var cards = Views.Mentions(m, "SUBJECT_HAS_ROLE", "Roles", r.Code);
        var policies = cards.Select(c => m.Policies[c.PolicyId]).DistinctBy(p => p.Row.Id).ToList();
        var permissions = policies.SelectMany(p => m.PermissionsUsingPolicy(p.Row.Id)).DistinctBy(p => p.Row.Id).OrderBy(p => p.Row.Code, StringComparer.Ordinal).ToList();
        return new
        {
            role = new { r.Id, r.Code, r.Name, r.IsInheritable, r.IsActive, r.TenantId, tenant = m.TenantCode(r.TenantId) },
            policies = policies.Select(p => new { p.Row.Id, p.Row.Code, p.Row.Name, p.Row.Logic, p.Row.IsActive }).ToList(),
            cards,
            permissions = permissions.Select(p => new
            {
                p.Row.Id, p.Row.Code, p.Row.Name, application = p.App.Code,
                otherPolicies = p.PolicyIds.Where(pid => policies.All(x => x.Row.Id != pid)).Select(pid => m.Policies.GetValueOrDefault(pid)?.Row.Code ?? $"#{pid}").ToList(),
                accesses = m.CoverageOf(p).Select(x => x.Key).ToList()
            }).ToList(),
            holders,
            grantingGroups = m.Data.GroupRoles.Where(x => x.RoleId == id && m.Groups.ContainsKey(x.GroupId)).Select(x => new { x.GroupId, m.Groups[x.GroupId].Code, m.Groups[x.GroupId].Name }).ToList()
        };
    }

    [HttpGet("groups")]
    public async Task<object> Groups(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        return m.Groups.Values.OrderBy(g => g.TenantId).ThenBy(g => g.Code, StringComparer.Ordinal).Select(g => new
        {
            g.Id, g.Code, g.Name, g.IsActive, g.TenantId, tenant = m.TenantCode(g.TenantId),
            rule = Views.Describe(m.GroupFilterRows(g.Id)),
            explicitMembers = m.GroupMemberRows(g.Id).Count(),
            memberCount = m.GroupMembersOf(g.Id, now).Count(),
            roles = m.GroupRoleIds(g.Id).Where(m.Roles.ContainsKey).Select(r => m.Roles[r].Code).ToList(),
            policies = Views.Mentions(m, "SUBJECT_IN_GROUP", "Groups", g.Code).Select(x => x.Policy).Distinct().ToList()
        }).ToList();
    }

    [HttpGet("groups/{id:int}")]
    public async Task<object> Group(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Groups.TryGetValue(id, out var g)) throw new NotFoundException("Grup", id);
        var now = clock.UtcNow;
        var description = await db.Groups.AsNoTracking().Where(x => x.Id == id).Select(x => x.Description).FirstOrDefaultAsync(ct);
        var excluded = m.Users.Values.Select(u => (u, x: m.GetIdentity(u.Id, now).ExcludedFromGroups.FirstOrDefault(e => e.GroupId == id)))
            .Where(t => t.x is not null).Select(t => new { userId = t.u.Id, t.u.UserName, t.u.FullName, reason = t.x!.Reason }).ToList();
        return new
        {
            group = new { g.Id, g.Code, g.Name, g.IsActive, g.TenantId, tenant = m.TenantCode(g.TenantId), description },
            filters = m.GroupFilterRows(id).Select(f => new
            {
                f.Order, f.Mode, f.Description, criteria = f.Criteria.Select(c => new { c.Attribute, c.Values }).ToList()
            }).ToList(),
            rule = Views.Describe(m.GroupFilterRows(id)),
            explicitMembers = m.GroupMemberRows(id).Where(x => m.Users.ContainsKey(x.UserId))
                .Select(x => new { x.UserId, m.Users[x.UserId].UserName, m.Users[x.UserId].FullName, x.ValidUntil }).ToList(),
            members = m.GroupMembersOf(id, now).Select(x => new
            {
                userId = x.User.Id, x.User.UserName, x.User.FullName, x.User.Title, tenant = m.TenantCode(x.User.TenantId),
                units = m.UnitCodesOf(x.User.Id).ToList(), reasons = x.Membership.Reasons
            }).ToList(),
            excluded,
            roles = m.GroupRoleIds(id).Where(m.Roles.ContainsKey).Select(r => new { m.Roles[r].Id, m.Roles[r].Code, m.Roles[r].Name }).ToList(),
            // KİM kartlarında (kural içinde SUBJECT_IN_GROUP) kullanım
            cards = Views.Mentions(m, "SUBJECT_IN_GROUP", "Groups", g.Code)
        };
    }

    [HttpGet("group-criteria")]
    public async Task<object> Criteria(CancellationToken ct) =>
        (await models.GetCurrentAsync(ct)).Criteria.All.Select(h => h.Descriptor).OrderBy(d => d.Code).ToList();
}

// ================================ Policy / permission ================================

[ApiController]
[Route("api/analysis/views")]
[RequireServiceKey]
public sealed class PolicyViewsController(AuthorizationModelProvider models, IYetkiDbContext db) : ControllerBase
{
    [HttpGet("policies")]
    public async Task<object> Policies(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.Policies.Values.OrderBy(p => p.Row.Code, StringComparer.Ordinal).Select(p => new
        {
            p.Row.Id, p.Row.Code, p.Row.Name, p.Row.Logic, p.Row.Mode, p.Row.IsActive, strategy = p.Row.Strategy, p.Row.Version, tenant = p.TenantCode,
            rules = p.Definition.Rules.OrderBy(r => r.Order).Select(r => new { r.Code, r.Name, r.IsActive, expression = PolicyEvaluator.Render(r.Condition), condition = Views.Condition(r.Condition) }).ToList(),
            obligations = p.Obligations.Select(o => o.Code).ToList(),
            permissions = m.PermissionsUsingPolicy(p.Row.Id).Select(x => x.Row.Code).ToList()
        }).ToList();
    }

    [HttpGet("policies/{id:int}")]
    public async Task<object> Policy(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Policies.TryGetValue(id, out var p)) throw new NotFoundException("Policy", id);
        var meta = await db.Policies.AsNoTracking().Where(x => x.Id == id).Select(x => new { x.Description, x.UpdatedAt, x.UpdatedBy, x.TenantId }).FirstAsync(ct);
        var ruleMeta = await db.Rules.AsNoTracking().Where(r => r.PolicyId == id).ToDictionaryAsync(r => r.Id, r => r.Description, ct);
        var permissions = m.PermissionsUsingPolicy(id).ToList();
        return new
        {
            policy = new
            {
                p.Row.Id, p.Row.Code, p.Row.Name, meta.Description, p.Row.Logic, p.Row.Mode, p.Row.IsActive, decisionStrategy = p.Row.Strategy,
                p.Row.Version, meta.TenantId, tenant = p.TenantCode, meta.UpdatedAt, meta.UpdatedBy
            },
            obligations = p.Obligations.Select(o => new { o.Id, o.Code, o.FulfillOn, o.Order, parameters = o.Params }).ToList(),
            rules = p.Definition.Rules.OrderBy(r => r.Order).ThenBy(r => r.Code).Select(r => new
            {
                id = r.RuleId, r.Code, r.Name, description = ruleMeta.GetValueOrDefault(r.RuleId), r.Order, r.ReasonCode, r.IsActive,
                expression = PolicyEvaluator.Render(r.Condition), condition = Views.Condition(r.Condition)
            }).ToList(),
            usedBy = new
            {
                permissions = permissions.Select(x => new { x.Row.Id, x.Row.Code, x.Row.Name, application = x.App.Code, coverage = m.CoverageOf(x).Count() }).ToList(),
                policies = Views.UsedBy(m, id)
            }
        };
    }

    [HttpGet("rules")]
    public async Task<object> Rules(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.Policies.Values.SelectMany(p => p.Definition.Rules.Select(r => new
        {
            id = r.RuleId, policyId = p.Row.Id, policy = p.Row.Code, r.Code, r.Name, r.Order, r.ReasonCode, r.IsActive,
            expression = PolicyEvaluator.Render(r.Condition), condition = Views.Condition(r.Condition)
        })).OrderBy(r => r.policy).ThenBy(r => r.Order).ToList();
    }

    /// <summary>Yükümlülük tipleri (koddaki katalog; PEP bunları yerine getirir).</summary>
    [HttpGet("obligation-types")]
    public IReadOnlyList<ObligationTypeDef> ObligationTypeList() => ObligationTypes.All;

    [HttpGet("permissions")]
    public async Task<object> Permissions([FromQuery] int? applicationId, [FromQuery] string? q, [FromQuery] int? page, [FromQuery] int pageSize = 20, CancellationToken ct = default)
    {
        var m = await models.GetCurrentAsync(ct);
        var filtered = m.Permissions.Values.Where(p => applicationId is null || p.Row.ApplicationId == applicationId)
            .Where(p => string.IsNullOrWhiteSpace(q)
                || p.Row.Code.Contains(q, StringComparison.OrdinalIgnoreCase)
                || p.Row.Name.Contains(q, StringComparison.OrdinalIgnoreCase)
                || p.Resources.Any(resourceId => m.Resources.GetValueOrDefault(resourceId)?.Code.Contains(q, StringComparison.OrdinalIgnoreCase) == true)
                || p.PolicyIds.Any(policyId => m.Policies.GetValueOrDefault(policyId)?.Row.Code.Contains(q, StringComparison.OrdinalIgnoreCase) == true))
            .OrderBy(p => p.App.Code).ThenBy(p => p.Row.Code, StringComparer.Ordinal);
        var total = filtered.Count();
        var safePageSize = Math.Clamp(pageSize, 10, 200);
        var selected = page is { } pageNumber ? filtered.Skip((Math.Max(1, pageNumber) - 1) * safePageSize).Take(safePageSize) : filtered;
        var items = selected.Select(p => new
            {
                p.Row.Id, p.Row.Code, p.Row.Name, p.Row.IsActive, strategy = p.Row.Strategy, application = p.App.Code, applicationId = p.App.Id,
                p.Row.Target, p.Row.AllScopes, resourceType = p.Row.ResourceTypeId is { } t && m.ResourceTypes.TryGetValue(t, out var rt) ? rt.Code : null,
                resources = p.Resources.Select(r => m.Resources.GetValueOrDefault(r)?.Code ?? $"#{r}").ToList(),
                scopes = p.Scopes.Select(s => m.Scopes.GetValueOrDefault(s)?.Code ?? $"#{s}").ToList(),
                policies = p.PolicyIds.Select(id => new { id, code = m.Policies.GetValueOrDefault(id)?.Row.Code ?? $"#{id}" }).ToList(),
                coverage = m.CoverageOf(p).Count(),
                hasIdentityPolicy = m.HasIdentityPolicy(p)
            }).ToList();
        return page is null ? items : new { items, total, page = Math.Max(1, page.Value), pageSize = safePageSize };
    }

    [HttpGet("permissions/{id:int}")]
    public async Task<object> Permission(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Permissions.TryGetValue(id, out var p)) throw new NotFoundException("Permission", id);
        var meta = await db.Permissions.AsNoTracking().Where(x => x.Id == id).Select(x => new { x.Description, x.UpdatedAt, x.UpdatedBy }).FirstAsync(ct);
        return new
        {
            permission = new
            {
                p.Row.Id, p.Row.Code, p.Row.Name, meta.Description, p.Row.IsActive, decisionStrategy = p.Row.Strategy, p.Row.Version,
                applicationId = p.App.Id, application = p.App.Code, applicationStrategy = p.App.Strategy, p.Row.Target, p.Row.AllScopes, p.Row.ResourceTypeId,
                resourceType = p.Row.ResourceTypeId is { } t && m.ResourceTypes.TryGetValue(t, out var rt) ? rt.Code : null,
                meta.UpdatedAt, meta.UpdatedBy, hasIdentityPolicy = m.HasIdentityPolicy(p)
            },
            resourceIds = p.Resources.ToList(),
            scopeIds = p.Scopes.ToList(),
            policyIds = p.PolicyIds,
            resources = p.Resources.Select(r => m.Resources.TryGetValue(r, out var row) ? new { row.Id, row.Code, row.Name } : new { Id = r, Code = $"#{r}", Name = "?" }).ToList(),
            scopes = p.Scopes.Select(s => m.Scopes.TryGetValue(s, out var row) ? new { row.Id, row.Code, row.Name } : new { Id = s, Code = $"#{s}", Name = "?" }).ToList(),
            policies = p.PolicyIds.Select(pid => m.Policies.TryGetValue(pid, out var pol)
                ? new { pol.Row.Id, pol.Row.Code, pol.Row.Name, pol.Row.Logic, pol.Row.Mode, pol.Row.IsActive, decisionStrategy = pol.Row.Strategy, rules = pol.Definition.Rules.OrderBy(r => r.Order).Select(r => new { r.Code, r.Name, expression = PolicyEvaluator.Render(r.Condition) }).ToList() }
                : null).Where(x => x is not null).ToList(),
            coverage = m.CoverageOf(p).Select(x => new
            {
                x.Id, x.Key, x.Name, resourceType = x.Type.Code, otherPermissions = m.PermissionsFor(x.Id).Where(o => o.Row.Id != id).Select(o => o.Row.Code).ToList()
            }).ToList()
        };
    }
}

// ================================ SoD / dış sistem ================================

[ApiController]
[Route("api/analysis/views")]
[RequireServiceKey]
public sealed class GovernanceViewsController(AuthorizationModelProvider models, ExternalAnalysisService external, IYetkiDbContext db) : ControllerBase
{
    [HttpGet("sod/rules")]
    public async Task<object> SodRules(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var rules = await db.SodRules.AsNoTracking().Include(r => r.Members).OrderBy(r => r.Code).ToListAsync(ct);
        var open = await db.SodViolations.AsNoTracking().Where(v => v.Status != ViolationStatus.Resolved).GroupBy(v => v.SodRuleId)
            .Select(g => new { g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.Count, ct);
        return rules.Select(r => new
        {
            r.Id, r.Code, r.Name, r.Description, r.Severity, r.Enforcement, r.IsActive, openViolations = open.GetValueOrDefault(r.Id),
            members = SodService.Snapshot(m, r.Id, r.Code, r.Name, r.Severity, r.Enforcement, r.Members.Select(x => (x.MemberType, x.MemberId))).Members
        }).ToList();
    }

    [HttpGet("sod/violations")]
    public async Task<object> SodViolations([FromQuery] bool includeResolved, CancellationToken ct)
    {
        var model = await models.GetCurrentAsync(ct);
        var rows = await db.SodViolations.AsNoTracking().Where(v => includeResolved || v.Status != ViolationStatus.Resolved).OrderByDescending(v => v.DetectedAt)
            .Select(v => new
            {
                v.Id, rule = v.SodRule.Code, ruleName = v.SodRule.Name, v.SodRule.Severity, v.SodRule.Enforcement, v.UserId,
                v.Status, v.DetectedBy, v.DetectedAt, v.LastSeenAt, v.ClosedAt, v.ClosedBy, v.Note, v.Details
            }).ToListAsync(ct);

        return rows.Select(v => new
        {
            v.Id, v.rule, v.ruleName, v.Severity, v.Enforcement, v.UserId,
            UserName = model.Users.GetValueOrDefault(v.UserId)?.UserName,
            FullName = model.Users.GetValueOrDefault(v.UserId)?.FullName,
            v.Status, v.DetectedBy, v.DetectedAt, v.LastSeenAt, v.ClosedAt, v.ClosedBy, v.Note, v.Details
        }).ToList();
    }

    [HttpGet("external/systems")]
    public async Task<object> ExternalSystems(CancellationToken ct)
    {
        var catalog = await ExternalRequirementCatalog.LoadAsync(db, ct);
        var usage = catalog.Dependencies.GroupBy(d => d.ExternalPermissionId).ToDictionary(g => g.Key, g => g.Count());
        var holders = await db.UserExternalGrants.AsNoTracking().GroupBy(g => g.ExternalPermissionId).Select(g => new { g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.Count, ct);
        var requires = catalog.Requirements.ToLookup(r => r.ExternalPermissionId);
        var requiredBy = catalog.Requirements.ToLookup(r => r.RequiredExternalPermissionId);
        var meta = await db.ExternalPermissions.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Description, ct);
        return catalog.Systems.Values.OrderBy(s => s.Code).Select(s => new
        {
            s.Id, s.Code, s.Name, s.HasAccessLevels,
            permissions = catalog.Permissions.Values.Where(p => p.SystemId == s.Id).OrderBy(p => p.ResourceClass).ThenBy(p => p.Code, StringComparer.Ordinal).Select(p => new
            {
                p.Id, p.Code, p.Name, p.ResourceClass, description = meta.GetValueOrDefault(p.Id),
                dependencyCount = usage.GetValueOrDefault(p.Id), userCount = holders.GetValueOrDefault(p.Id),
                requires = requires[p.Id].Select(r => new { id = r.RequiredExternalPermissionId, key = catalog.Target(r.RequiredExternalPermissionId).Key, level = r.AccessLevel }).ToList(),
                requiredBy = requiredBy[p.Id].Select(r => catalog.Target(r.ExternalPermissionId).Key).ToList()
            }).ToList()
        }).ToList();
    }

    /// <summary>Bağımlılıklar (filtre: resourceId, resourceScopeId; forResource = resource'un kendisi + scope'larınınki). Sahibi açıklamasıyla.</summary>
    [HttpGet("external/dependencies")]
    public async Task<object> Dependencies([FromQuery] int? resourceId, [FromQuery] int? resourceScopeId, [FromQuery] int? forResource, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var catalog = await ExternalRequirementCatalog.LoadAsync(db, ct);
        HashSet<int> resourceScopes = forResource is null ? [] : m.ScopesOf(forResource.Value).Select(s => s.Id).ToHashSet();
        return catalog.Dependencies
            .Where(d => forResource == null || d.ResourceId == forResource || (d.ResourceScopeId is { } rs && resourceScopes.Contains(rs)))
            .Where(d => (resourceId == null || d.ResourceId == resourceId) && (resourceScopeId == null || d.ResourceScopeId == resourceScopeId))
            .Select(d => DependencyView(m, catalog, d)).ToList();
    }

    [HttpGet("external/drift")]
    public Task<DriftReport> Drift(CancellationToken ct) => external.DriftAsync(ct);

    /// <summary>Yetkinin (resource:scope) dış gereksinimleri (doğrudan + resource mirası + zincir) ve ilgili bağımlılıklar.</summary>
    [HttpGet("resource-scopes/{id:int}/external")]
    public async Task<object> AccessRequirements(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.ResourceScopes.TryGetValue(id, out var p)) throw new NotFoundException("Yetki", id);
        var catalog = await ExternalRequirementCatalog.LoadAsync(db, ct);
        return new
        {
            defaultLevel = ExternalRequirementCatalog.DefaultLevel(p.Scope.Code),
            requirements = catalog.ForAccess(p).Select(n => new
            {
                n.Target.ExternalPermissionId, n.Target.System, n.Target.Code, n.Target.Name, n.Target.ResourceClass, level = n.Level, n.Reasons
            }).ToList(),
            dependencies = catalog.Dependencies
                .Where(d => d.ResourceScopeId == id || d.ResourceId == p.Resource.Id)
                .Select(d => DependencyView(m, catalog, d)).ToList()
        };
    }

    private static object DependencyView(AuthorizationModel m, ExternalRequirementCatalog catalog, ExternalDependencyRow d)
    {
        var t = catalog.Target(d.ExternalPermissionId);
        string owner, ownerType;
        int? ownerResourceId;
        if (d.ResourceId is { } r)
        {
            ownerType = "Resource";
            ownerResourceId = r;
            owner = m.Resources.TryGetValue(r, out var res) ? $"{res.Code} (tüm scope'lar)" : $"resource #{r}";
        }
        else
        {
            ownerType = "ResourceScope";
            var rs = m.ResourceScopes.GetValueOrDefault(d.ResourceScopeId!.Value);
            ownerResourceId = rs?.Resource.Id;
            owner = rs?.Key ?? $"yetki #{d.ResourceScopeId}";
        }
        return new
        {
            d.Id, ownerType, owner, resourceId = d.ResourceId, resourceScopeId = d.ResourceScopeId, ownerResourceId,
            t.ExternalPermissionId, t.System, t.Code, t.Name, t.ResourceClass, t.HasAccessLevels, level = d.AccessLevel, d.Note
        };
    }
}
