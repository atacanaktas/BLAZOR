using Microsoft.AspNetCore.Mvc;
using Yetki.Pdp.Api.Infrastructure;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Changes;
using Yetki.Pdp.Application.Evaluation;
using Yetki.Pdp.Application.External;
using Yetki.Pdp.Application.Governance;
using Yetki.Pdp.Application.Inventory;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Application.Simulation;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Api.Controllers;

public sealed class GroupPreviewRequest
{
    public int TenantId { get; set; }
    public List<GroupFilterDraft> Filters { get; set; } = new();
    public List<int>? ExplicitMemberIds { get; set; }
}

public sealed class ExternalDesiredRequest
{
    public List<int>? UserIds { get; set; }
}

public sealed class ObligationDraft
{
    public string? Code { get; set; }
    public Dictionary<string, string>? Parameters { get; set; }
}

public sealed class PermissionDraftCheck
{
    public int ApplicationId { get; set; }
    public string? Code { get; set; }
    public string? Name { get; set; }
    public PermissionTarget Target { get; set; } = PermissionTarget.Resources;
    public int? ResourceTypeId { get; set; }
    public List<int> ResourceIds { get; set; } = new();
    public bool AllScopes { get; set; }
    public List<int> ScopeIds { get; set; } = new();
    public List<int> PolicyIds { get; set; } = new();
    public DecisionStrategy DecisionStrategy { get; set; } = DecisionStrategy.Unanimous;
    public bool IsActive { get; set; } = true;
}

/// <summary>
/// ANALİZ uçları — yalnızca PAP çağırır (X-Service-Key). Karar motoruyla AYNI model ve AYNI evaluator kullanılır; PAP'ta ikinci bir
/// motor yoktur. Hiçbiri model verisi yazmaz (karar / What-If audit kaydı hariç). Taslak tanım değişiklikleri ModelPatch ile taşınır.
/// İleride bu uçlar karar trafiğinden ayrı, analiz için ayrılmış bir PDP instance'ında çalıştırılabilir.
/// </summary>
[ApiController]
[Route("api/analysis")]
[RequireServiceKey]
public sealed class AnalysisController(
    AuthorizationModelProvider models,
    SimulationService simulation,
    EntitlementService entitlements,
    SodService sod,
    InventoryService inventory,
    ExternalAnalysisService external,
    IClock clock) : ControllerBase
{
    /// <summary>Bu PDP'nin gördüğü model versiyonu ve özet sayılar (dashboard).</summary>
    [HttpGet("summary")]
    public async Task<object> Summary(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return new
        {
            modelVersion = m.Version, modelBuiltAt = m.BuiltAt,
            counts = new
            {
                tenants = m.Tenants.Count, units = m.Units.Count, users = m.Users.Count, roles = m.Roles.Count, groups = m.Groups.Count,
                applications = m.Apps.Count, resourceTypes = m.ResourceTypes.Count, resources = m.Resources.Count,
                scopes = m.Scopes.Count, resourceScopes = m.ResourceScopes.Count, uris = m.Data.Uris.Count,
                unprotectedAccesses = m.ResourceScopes.Keys.Count(id => m.PermissionsFor(id).Count == 0),
                permissions = m.Permissions.Count, permissionsWithoutIdentity = m.Permissions.Values.Count(p => p.Row.IsActive && !m.HasIdentityPolicy(p)),
                clients = m.ClientsById.Count, policies = m.Policies.Count, reportOnlyPolicies = m.Policies.Values.Count(p => p.Row.Mode == PolicyMode.ReportOnly)
            }
        };
    }

    /// <summary>ModelPatch'te kullanılabilecek tablolar (ModelData listeleri).</summary>
    [HttpGet("patch-tables")]
    public IReadOnlyCollection<string> PatchTables() => ModelPatch.TableNames;

    // ------------------------------ Karar ------------------------------

    /// <summary>
    /// Konsol kararı (Yetki testi, gateway simülatörü): Request.Caller verilirse o client'ın soru kapsamı uygulanır, boşsa iç çağrıdır.
    /// Changes / PolicyChanges / Patch / AsOfUtc ile What-If kararı.
    /// </summary>
    [HttpPost("decide")]
    public Task<AuthorizationDecision> Decide(SimulatedEvaluateRequest request, CancellationToken ct) => simulation.EvaluateAsync(request, ct);

    /// <summary>Konsol yetki listesi (Nextral ekranı vb.). Caller verilirse kapsam kuralları uygulanır.</summary>
    [HttpPost("entitlements")]
    public Task<EntitlementResult> Entitlements(EntitlementRequest request, CancellationToken ct) => entitlements.GetAsync(request, ct);

    // ------------------------------ Etkin yetki / sahipler ------------------------------

    [HttpGet("users/{id:int}/effective")]
    public async Task<EffectiveAccessSet> Effective(int id, [FromQuery] DateTime? asOf, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Users.ContainsKey(id)) throw new NotFoundException("Kullanıcı", id);
        return m.GetEffective(id, asOf ?? clock.UtcNow);
    }

    /// <summary>Grup kitle kuralı önizlemesi: bu kurallarla kimler üye olurdu? (kural geçerliliği PAP'ta kontrol edilir)</summary>
    [HttpPost("group-preview")]
    public async Task<object> GroupPreview(GroupPreviewRequest r, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        ValidateFilters(m, r.Filters);
        var now = clock.UtcNow;
        var rows = r.Filters.Select((f, i) => new GroupFilterRow(0, i, f.Mode, f.Description,
            f.Criteria.Select(c => new CriterionRow(c.Attribute.Trim().ToUpperInvariant(), c.Values)).ToList())).ToList();
        var explicitIds = r.ExplicitMemberIds?.ToHashSet() ?? [];
        var members = new List<object>();
        var excluded = new List<object>();
        foreach (var u in m.Users.Values.Where(u => m.TenantAncestors[u.TenantId].Contains(r.TenantId)).OrderBy(u => u.UserName, StringComparer.Ordinal))
        {
            var reasons = new List<string>();
            if (explicitIds.Contains(u.Id)) reasons.Add("açık üye");
            string? ex = null;
            foreach (var f in rows)
            {
                if (!m.FilterMatches(f, u, now, out var text)) continue;
                if (f.Mode == InclusionMode.Include) reasons.Add($"kural #{f.Order + 1}: {text}");
                else ex ??= $"kural #{f.Order + 1} (hariç): {text}";
            }
            if (reasons.Count == 0) continue;
            var item = new { userId = u.Id, u.UserName, u.FullName, u.Title, units = m.UnitCodesOf(u.Id).ToList(), reasons, excludedBy = ex };
            (ex is null ? members : excluded).Add(item);
        }
        return new { rule = DescribeDrafts(r.Filters), members, excluded };
    }

    // ------------------------------ Taslak doğrulamaları (davranış PDP'de: kriter / condition / yükümlülük handler'ları) ------------------------------

    /// <summary>Grup kitle kuralları koddaki kriter handler'larına ve güncel modele göre doğrulanır (geçersizse 400). rule: okunur özet.</summary>
    [HttpPost("group-filters/validate")]
    public async Task<object> ValidateGroupFilters(List<GroupFilterDraft> filters, CancellationToken ct)
    {
        ValidateFilters(await models.GetCurrentAsync(ct), filters);
        return new { valid = true, rule = DescribeDrafts(filters) };
    }

    /// <summary>Yükümlülük kodu ve parametreleri (koddaki yükümlülük kataloğu). Normalize edilmiş parametreler döner.</summary>
    [HttpPost("obligations/validate")]
    public object ValidateObligation(ObligationDraft draft)
    {
        var code = (draft.Code ?? "").Trim().ToUpperInvariant();
        var parameters = Application.PolicyEngine.ObligationTypes.Validate(code, draft.Parameters ?? new());
        return new { code, parameters };
    }

    /// <summary>
    /// Permission taslağının modele göre özellikleri: kimlik policy'si içeriyor mu (yoksa koşulu sağlayan herkes erişir),
    /// kaç yetkiyi (resource:scope) kapsıyor. PAP uyarı metinlerini buna göre üretir.
    /// </summary>
    [HttpPost("permission-draft")]
    public async Task<object> PermissionDraft(PermissionDraftCheck d, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Apps.TryGetValue(d.ApplicationId, out var app)) throw new NotFoundException("Uygulama", d.ApplicationId);
        var draft = new CompiledPermission(new PermissionRow(0, d.ApplicationId, d.Code ?? "DRAFT", d.Name ?? "", d.Target, d.ResourceTypeId, d.AllScopes, d.DecisionStrategy, d.IsActive, 1),
            app, d.ResourceIds.ToHashSet(), d.ScopeIds.ToHashSet(), d.PolicyIds);
        var coverage = m.ResourceScopes.Values.Where(draft.Applies).Select(x => x.Key).OrderBy(k => k, StringComparer.Ordinal).ToList();
        return new { hasIdentityPolicy = m.HasIdentityPolicy(draft), coverageCount = coverage.Count, coverage };
    }

    private static void ValidateFilters(AuthorizationModel model, List<GroupFilterDraft> filters)
    {
        var errors = new List<string>();
        for (var i = 0; i < filters.Count; i++)
        {
            if (filters[i].Criteria.Count == 0) errors.Add($"Kural #{i + 1}: en az bir kriter gerekli.");
            foreach (var c in filters[i].Criteria)
            {
                var h = model.Criteria.Find(c.Attribute ?? "");
                if (h is null) { errors.Add($"Kural #{i + 1}: bilinmeyen kriter '{c.Attribute}'."); continue; }
                errors.AddRange(h.Validate(model, c.Values.Where(v => !string.IsNullOrWhiteSpace(v)).ToList()).Select(e => $"Kural #{i + 1}: {e}"));
            }
        }
        if (errors.Count > 0) throw ValidationException.Of("filters", errors);
    }

    private static string DescribeDrafts(IEnumerable<GroupFilterDraft> filters) =>
        string.Join(" ∪ ", filters.Select(f => (f.Mode == InclusionMode.Exclude ? "HARİÇ " : "") +
            "(" + string.Join(" ∧ ", f.Criteria.Select(c => $"{c.Attribute}∈{{{string.Join(",", c.Values)}}}")) + ")"));

    // ------------------------------ Etki analizi (What-If) ------------------------------

    /// <summary>Taslak değişikliğin (kimlik change set'i + ModelPatch + policy değişiklikleri) kullanıcı bazında etkisi, SoD ve dış sistem farkı.</summary>
    [HttpPost("impact")]
    public Task<ChangeImpactResult> Impact(ImpactRequest request, CancellationToken ct) => simulation.ImpactAsync(request, ct);

    [HttpPost("policy-impact")]
    public Task<PolicyImpactResult> PolicyImpact(PolicyImpactRequest request, CancellationToken ct) => simulation.PolicyImpactAsync(request, ct);

    /// <summary>
    /// Condition taslağı doğrulaması (handler'lar PDP'de). Geçerliyse normalize edilmiş taslak + condition tipi / referans policy id'leri döner;
    /// geçersizse 400. policyId: kuralın ait olduğu policy (referans kurum kontrolü ve döngü kontrolü için).
    /// </summary>
    [HttpPost("conditions/validate")]
    public async Task<object> ValidateCondition(ConditionDraft condition, [FromQuery] int? policyId,
        [FromServices] Application.Definitions.ConditionDraftValidator validator, CancellationToken ct)
    {
        var v = await validator.ValidateConditionAsync(condition, ct, policyId);
        var expression = Application.PolicyEngine.PolicyEvaluator.Render(PolicyCompiler.FromDraftUnresolved(condition));
        return new { condition, expression, conditionTypes = v.Types, policies = v.Policies };
    }

    // ------------------------------ Kitle (KİM kartı = grup kuralı) ------------------------------

    /// <summary>KİM kartı başka KİM kartları / gruplarla örtüşüyor mu? (tanım aynı → öneri, sadece üyeler aynı → bilgi)</summary>
    [HttpPost("audiences/overlap")]
    public Task<AudienceOverlapResult> AudienceOverlap(AudienceOverlapRequest request, [FromServices] AudienceService audiences, CancellationToken ct) =>
        audiences.OverlapAsync(request, ct);

    /// <summary>Kitle satırları → KİM kartının koşul ağacı (grubu karta geri almak için).</summary>
    [HttpPost("audiences/condition")]
    public object AudienceCondition(List<GroupFilterDraft> filters)
    {
        var condition = Audience.ToCondition(Audience.FromDrafts(filters));
        return new { condition, expression = Application.PolicyEngine.PolicyEvaluator.Render(Audience.ToNode(condition)) };
    }

    /// <summary>Kuralın koşulu bir kitleyse (KİM kartı) grup kuralı satırları; değilse null.</summary>
    [HttpGet("audiences/rules/{ruleId:int}")]
    public async Task<object> RuleAudience(int ruleId, [FromServices] AudienceService audiences, CancellationToken ct) => new
    {
        filters = (await audiences.RuleAudienceAsync(ruleId, ct))?
            .Select(r => new GroupFilterDraft { Mode = r.Mode, Criteria = r.Criteria.Select(c => new GroupCriterionDraft { Attribute = c.Attribute, Values = c.Values.ToList() }).ToList() }).ToList()
    };

    // ------------------------------ SoD ------------------------------

    /// <summary>Taslak SoD kuralı şu an kimlerde ihlal üretir?</summary>
    [HttpPost("sod/rule-preview")]
    public Task<IReadOnlyList<SodUserConflicts>> SodRulePreview(SodRuleImpactRequest request, CancellationToken ct) => simulation.SodRuleImpactAsync(request, ct);

    /// <summary>Tarama hesabı (ihlal kayıtlarını PAP yazar / kapatır).</summary>
    [HttpPost("sod/detect")]
    public Task<SodDetectionResult> SodDetect(CancellationToken ct) => sod.DetectAsync(ct);

    // ------------------------------ Kapsama ------------------------------

    [HttpGet("coverage/{applicationId:int}")]
    public Task<CoverageReport> Coverage(int applicationId, CancellationToken ct) => inventory.CoverageAsync(applicationId, ct);

    // ------------------------------ Dış sistemler (RACF / LDAP) ------------------------------

    [HttpPost("external/impact")]
    public Task<ExternalImpactResult> ExternalImpact(ExternalCatalogPatch patch, CancellationToken ct) => external.ImpactAsync(patch, ct);

    /// <summary>Kullanıcının olması gereken ↔ dış sistemde açık olan durumu (kalem kalem). Provisioning worker'ı mutabakatta kullanır.</summary>
    [HttpGet("external/users/{id:int}")]
    public Task<UserExternalStatus> ExternalUser(int id, CancellationToken ct) => external.UserStatusAsync(id, ct);

    [HttpGet("external/resource-scopes/{id:int}")]
    public Task<IReadOnlyList<ExternalNeed>> ExternalAccess(int id, CancellationToken ct) => external.AccessNeedsAsync(id, ct);

    /// <summary>Olması gereken dış durum (baseline / toplu mutabakat). UserIds boşsa tüm kullanıcılar.</summary>
    [HttpPost("external/desired")]
    public Task<IReadOnlyList<UserExternalDesired>> ExternalDesired(ExternalDesiredRequest request, CancellationToken ct) =>
        external.DesiredAsync(request.UserIds, ct);
}
