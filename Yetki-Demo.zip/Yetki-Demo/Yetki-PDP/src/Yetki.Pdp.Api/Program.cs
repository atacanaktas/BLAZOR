using System.Globalization;
using System.Text.Json.Serialization;
using Yetki.Pdp.Api.Infrastructure;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Infrastructure;

// Türkçe kültürde sayı/tarih/büyük-küçük harf sürprizlerini önlemek için invariant.
CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.InvariantCulture;

var builder = WebApplication.CreateBuilder(args);

// PDP (karar noktası). Veritabanı PAP ile paylaşılır (DataBase klasörü); şema PAP'ındır, PDP migration çalıştırmaz.
builder.Services.AddYetkiInfrastructure(builder.Configuration, builder.Environment.ContentRootPath);
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentActor, HttpCurrentActor>();
builder.Services.AddSingleton<IFreshnessPolicy, HttpFreshnessPolicy>();

// Motor API kimlik doğrulaması: client secret → kısa ömürlü token. İmza anahtarı yoksa süreç başına rastgele üretilir
// (yeniden başlatınca eski token'lar geçersiz olur). Birden fazla PDP instance'ı varsa anahtar ORTAK verilmeli (gizli yönetiminden).
builder.Services.Configure<EngineAuthOptions>(builder.Configuration.GetSection("EngineAuth"));
builder.Services.PostConfigure<EngineAuthOptions>(o =>
{
    if (string.IsNullOrWhiteSpace(o.SigningKey)) o.SigningKey = Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(32));
});
builder.Services.AddSingleton<EngineTokenService>();
// Analiz uçları (/api/analysis) sadece PAP içindir: servis anahtarı
builder.Services.Configure<AnalysisOptions>(builder.Configuration.GetSection("Analysis"));

builder.Services.AddControllers(o => o.Filters.Add<ApiExceptionFilter>())
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        o.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "Yetki PDP", Version = "v1",
        Description = "Karar noktası: /api/v1 (motor token'ı) · AuthZEN · /api/analysis (sadece PAP, X-Service-Key)" });
    c.CustomSchemaIds(t => t.FullName!.Replace("+", "."));
    c.AddSecurityDefinition("Bearer", new() { Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http, Scheme = "bearer", BearerFormat = "JWT",
        Description = "POST /api/v1/token (client_id + client_secret) ile alınan motor token'ı" });
    c.AddSecurityDefinition("ServiceKey", new() { Type = Microsoft.OpenApi.Models.SecuritySchemeType.ApiKey, In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Name = AnalysisOptions.HeaderName, Description = "Analiz uçları için PAP servis anahtarı" });
    c.AddSecurityRequirement(new()
    {
        [new Microsoft.OpenApi.Models.OpenApiSecurityScheme { Reference = new() { Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme, Id = "Bearer" } }] = [],
        [new Microsoft.OpenApi.Models.OpenApiSecurityScheme { Reference = new() { Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme, Id = "ServiceKey" } }] = []
    });
});

var app = builder.Build();

await app.Services.InitializeYetkiDatabaseAsync(); // şema kontrolü + condition tipi senkronu; migration YOK

app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();
app.MapGet("/", () => Results.Redirect("/swagger")).ExcludeFromDescription();

app.Run();

public partial class Program;
