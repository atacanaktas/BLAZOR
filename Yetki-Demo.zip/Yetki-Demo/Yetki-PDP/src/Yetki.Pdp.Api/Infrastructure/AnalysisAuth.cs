using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;

namespace Yetki.Pdp.Api.Infrastructure;

/// <summary>
/// Analiz uçlarının (/api/analysis) servis anahtarı. Bu uçları SADECE PAP çağırır (yönetim konsolu → PAP → PDP);
/// istemciler (client) motor token'ıyla /api/v1 karar uçlarını kullanır. Anahtar boşsa analiz uçları kapalıdır (503).
/// ÜRETİMDE anahtar gizli yönetiminden verilmeli (veya mTLS / ağ seviyesinde kısıt).
/// </summary>
public sealed class AnalysisOptions
{
    public string ServiceKey { get; set; } = "";
    public const string HeaderName = "X-Service-Key";
}

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public sealed class RequireServiceKeyAttribute() : TypeFilterAttribute(typeof(RequireServiceKeyFilter));

public sealed class RequireServiceKeyFilter(IOptions<AnalysisOptions> options) : IAuthorizationFilter
{
    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var expected = options.Value.ServiceKey;
        if (string.IsNullOrWhiteSpace(expected))
        {
            context.Result = new ObjectResult(new ProblemDetails { Status = 503, Title = "Analiz uçları kapalı", Detail = "Analysis:ServiceKey yapılandırılmamış." }) { StatusCode = 503 };
            return;
        }
        var given = context.HttpContext.Request.Headers[AnalysisOptions.HeaderName].ToString();
        if (!CryptographicOperations.FixedTimeEquals(SHA256.HashData(Encoding.UTF8.GetBytes(given)), SHA256.HashData(Encoding.UTF8.GetBytes(expected))))
            context.Result = new ObjectResult(new ProblemDetails { Status = 401, Title = "Servis anahtarı geçersiz", Detail = $"{AnalysisOptions.HeaderName} başlığı eksik veya hatalı." }) { StatusCode = 401 };
    }
}

/// <summary>Analiz / görünüm istekleri (/api/analysis) önbelleği beklemeden en güncel model ve kimlik revizyonunu okur.</summary>
public sealed class HttpFreshnessPolicy(IHttpContextAccessor http) : Application.Abstractions.IFreshnessPolicy
{
    public bool FreshReadRequired => http.HttpContext?.Request.Path.StartsWithSegments("/api/analysis") == true;
}