using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Pdp.Application.Abstractions;
using Yetki.Pdp.Application.Changes;
using Yetki.Pdp.Application.External;
using Yetki.Pdp.Application.Governance;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Application.Simulation;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Tests;

/// <summary>Grup kitle kuralları, kurum mirası, SoD hesabı, RACF/LDAP gereksinim farkı, What-If ve ModelPatch (salt okunur analizler).</summary>
public class GovernanceTests
{
    [Fact]
    public async Task Filtreler_arasi_VEYA_filtre_ici_VE_haric_kurali()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var komite = m.GroupMembersOf(await host.GroupIdAsync("KREDI_KOMITESI"), host.Clock.UtcNow).Select(x => x.User.UserName).ToHashSet();
        Assert.Equal(new HashSet<string> { "ali.demir", "sibel.ates" }, komite);   // emre SUBEMDR ama 737; burak'ın SUBEMDR'si gruptan (ROLE sadece doğrudan)

        var gise101 = m.GroupMembersOf(await host.GroupIdAsync("GISE_101_AST"), host.Clock.UtcNow).Select(x => x.User.UserName).ToHashSet();
        Assert.Contains("ayse.yilmaz", gise101);
        Assert.DoesNotContain("mert.kaya", gise101);                                // stajyer: HARİÇ kuralı
    }

    [Fact]
    public async Task Miras_alinabilir_rol_alt_kuruma_gecer()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var nil = m.GetIdentity(m.UserIdByName["nil.sezer"], host.Clock.UtcNow);
        Assert.Contains(nil.Groups, g => g.Code == "TUM_PERSONEL");
        Assert.Contains(nil.Roles, r => r.Code == "PERSONEL" && r.Tenant == "ABANK");
        Assert.DoesNotContain(m.GetIdentity(m.UserIdByName["svc.rapor-batch"], host.Clock.UtcNow).Groups, g => g.Code == "TUM_PERSONEL");
    }

    [Fact]
    public async Task SoD_Block_rol_atamasi_analizde_engelleyici_cikar()
    {
        await using var host = await TestHost.CreateAsync();
        var changes = new AuthorizationChangeSet();
        changes.UserRoles.Add(new UserRoleChange(await host.UserIdAsync("ayse.yilmaz"), await host.RoleIdAsync("SUBEMDR"), true));
        var impact = await host.WithAsync(sp => sp.GetRequiredService<ImpactAnalysisService>().AnalyzeAsync(changes, default));
        Assert.True(impact.Blocked);
        Assert.Contains(impact.BlockingConflicts, f => f.UserName == "ayse.yilmaz");
    }

    [Fact]
    public async Task SoD_tespiti_yetki_uyelerini_etkin_erisimden_bulur_ve_yazmaz()
    {
        await using var host = await TestHost.CreateAsync();
        var scan = await host.WithAsync(sp => sp.GetRequiredService<SodService>().DetectAsync(default));
        var users = scan.Details.Where(d => d.Conflicts.Any(c => c.Code == "SOD_KREDI_ONAY_KULLANDIRIM")).Select(d => d.UserName).ToHashSet();
        Assert.Equal(new HashSet<string> { "ali.demir", "sibel.ates" }, users);
        Assert.False(await host.WithAsync(sp => sp.GetRequiredService<IYetkiDbContext>().SodViolations.AnyAsync()));   // ihlal kaydı PAP'ın işi
    }

    [Fact]
    public async Task Rol_atamasi_analizi_RACF_gereksinimini_zincirle_birlikte_verir()
    {
        await using var host = await TestHost.CreateAsync();
        var elif = await host.UserIdAsync("elif.sahin");
        var changes = new AuthorizationChangeSet();
        changes.UserRoles.Add(new UserRoleChange(elif, await host.RoleIdAsync("GISEYTK"), true));
        var impact = await host.WithAsync(sp => sp.GetRequiredService<ImpactAnalysisService>().AnalyzeAsync(changes, default));

        var u = Assert.Single(impact.Users, x => x.UserName == "elif.sahin");
        Assert.Contains(u.AddedAccesses, a => a.Key == "anka.nakitcekim:create");
        Assert.Contains(u.ExternalGrants, g => g.Code == "NKC1" && g.Level == "UPDATE");
        Assert.Contains(u.ExternalGrants, g => g.Code == "BNK.KASA.HAREKET");                 // zincir
        Assert.DoesNotContain(u.ExternalGrants, g => g.Code == "CICSNKT");                    // görüntüleme yetkisinden zaten vardı
    }

    [Fact]
    public async Task Dis_sistem_durumu_baseline_sonrasi_senkron_bagimlilik_eklenince_fark_cikar()
    {
        await using var host = await TestHost.CreateAsync();
        var elif = await host.UserIdAsync("elif.sahin");
        var status = await host.WithAsync(sp => sp.GetRequiredService<ExternalAnalysisService>().UserStatusAsync(elif, default));
        Assert.True(status.InSync);
        Assert.Equal(0, (await host.WithAsync(sp => sp.GetRequiredService<ExternalAnalysisService>().DriftAsync(default))).DriftedUsers);

        // Taslak: anka.vadelihesap:view → NKC1 (READ) bağımlılığı
        var (accessId, extId) = await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<IYetkiDbContext>();
            return (await host.AccessIdAsync("anka.vadelihesap:view"), await db.ExternalPermissions.Where(p => p.Code == "NKC1").Select(p => p.Id).SingleAsync());
        });
        var impact = await host.WithAsync(sp => sp.GetRequiredService<ExternalAnalysisService>().ImpactAsync(new ExternalCatalogPatch
        {
            AddDependency = new ExternalDependencyRow(0, null, accessId, extId, ExternalAccessLevel.Read, null)
        }, default));
        Assert.True(impact.AffectedUserCount > 0);
        var model = await host.ModelAsync();
        Assert.All(impact.Users, x => Assert.NotNull(model.GetEffective(x.UserId, host.Clock.UtcNow).Find(accessId)));   // sadece yetkiyi tutanlar etkilenir
        Assert.Contains(impact.Users, x => x.Grants.Concat(x.Modifies).Any(g => g.Code == "NKC1"));
    }

    [Fact]
    public async Task ModelPatch_permission_policy_baglantisini_kaldirma_etkisi()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var burak = await host.UserIdAsync("burak.arslan");
        // burak'ın vadelihesap:create yetkisinin geldiği permission → policy bağlantısını taslakta kaldır
        var source = m.GetEffective(burak, host.Clock.UtcNow).Find(await host.AccessIdAsync("anka.vadelihesap:create"))!.Sources.First();
        var permId = await host.PermissionIdAsync(source.Permission);
        var policyId = await host.PolicyIdAsync(source.Policy);
        var patch = new List<ModelPatchOperation>
        {
            new() { Table = "PermissionPolicies", Op = PatchOp.Remove, Match = new()
            {
                ["PermissionId"] = JsonSerializer.SerializeToElement(permId), ["PolicyId"] = JsonSerializer.SerializeToElement(policyId)
            } }
        };
        var impact = await host.WithAsync(sp => sp.GetRequiredService<ImpactAnalysisService>().AnalyzeAsync(new ImpactRequest { Patch = patch }, default));
        var b = Assert.Single(impact.Users, u => u.UserName == "burak.arslan");   // ya kaybeder ya da kaynağı değişir
        Assert.True(b.RemovedAccesses.Any(a => a.Key == "anka.vadelihesap:create") || b.RetainedAccesses.Any(a => a.Key == "anka.vadelihesap:create"));

        // Gerçek model değişmedi
        Assert.NotNull((await host.ModelAsync()).GetEffective(burak, host.Clock.UtcNow).Find(await host.AccessIdAsync("anka.vadelihesap:create")));
    }

    [Fact]
    public async Task ModelPatch_bilinmeyen_tablo_ve_alan_reddedilir()
    {
        await using var host = await TestHost.CreateAsync();
        await Assert.ThrowsAsync<ValidationException>(() => host.WithAsync(sp => sp.GetRequiredService<ImpactAnalysisService>().AnalyzeAsync(
            new ImpactRequest { Patch = [new() { Table = "Yok", Op = PatchOp.Add, Row = JsonSerializer.SerializeToElement(new { Id = 1 }) }] }, default)));
        await Assert.ThrowsAsync<ValidationException>(() => host.WithAsync(sp => sp.GetRequiredService<ImpactAnalysisService>().AnalyzeAsync(
            new ImpactRequest { Patch = [new() { Table = "Permissions", Op = PatchOp.Remove, Match = new() { ["Yok"] = JsonSerializer.SerializeToElement(1) } }] }, default)));
    }

    [Fact]
    public async Task Kosul_What_If_mesai_saati_degisikligi_kimi_etkiler()
    {
        await using var host = await TestHost.CreateAsync();
        int conditionId = await host.WithAsync(async sp => await sp.GetRequiredService<IYetkiDbContext>().RuleConditions
            .Where(c => c.Rule.Policy.Code == "MESAI" && c.Kind == ConditionKind.Predicate).Select(c => c.Id).SingleAsync());
        var changes = new PolicyChangeSet
        {
            ConditionOverrides = [new ConditionParameterOverride(conditionId, new() { ["Start"] = "09:00", ["End"] = "10:00", ["Days"] = "MON,TUE,WED,THU,FRI", ["TimeZone"] = "Europe/Istanbul" })]
        };
        var result = await host.WithAsync(sp => sp.GetRequiredService<PolicyImpactService>().AnalyzeAsync(new PolicyImpactRequest
        {
            Changes = changes,
            Scenarios = [new ImpactScenario { Name = "Şubeden 11:00", Client = "nextral-api", Context = new() { ["IpAddress"] = TestHost.BankIp } }]
        }, default));

        Assert.Contains(result.Accesses, a => a.Key == "anka.vadelihesap:view");
        Assert.True(result.NewlyDenied > 0);
        Assert.Contains(result.Rows, r => r.UserName == "ayse.yilmaz" && r.Permission == "anka.vadelihesap:view" && r.Change == "NEWLY_DENIED");
    }

    [Fact]
    public async Task Policy_What_If_daha_once_holder_olmayan_yeni_kazananlari_da_degerlendirir()
    {
        await using var host = await TestHost.CreateAsync();
        var (policyId, ruleId) = await host.WithAsync(async sp => await sp.GetRequiredService<IYetkiDbContext>().Rules
            .Where(r => r.Policy.Code == "ROL_VADELI_KAPATAN")
            .Select(r => new ValueTuple<int, int>(r.PolicyId, r.Id)).SingleAsync());

        var changes = new PolicyChangeSet
        {
            ReplacedRules = [new RuleReplacement(ruleId, new RuleDraft
            {
                PolicyId = policyId, Code = "KIM", Name = "Vadeli kapatabilen roller", Order = 10,
                Condition = new ConditionDraft
                {
                    Kind = ConditionKind.Predicate, ConditionTypeCode = "SUBJECT_HAS_ROLE",
                    Parameters = new() { ["Roles"] = "SUBEMDR,BRYSLYTK,GISEAST" }
                }
            })]
        };

        var result = await host.WithAsync(sp => sp.GetRequiredService<PolicyImpactService>().AnalyzeAsync(new PolicyImpactRequest
        {
            Changes = changes,
            Scenarios = [new ImpactScenario { Name = "Nextral", Client = "nextral-api", Context = new() { ["IpAddress"] = TestHost.BankIp } }]
        }, default));

        Assert.True(result.NewlyAllowed > 0);
        Assert.Contains(result.Rows, r => r.UserName == "ayse.yilmaz"
            && r.Permission == "nextral.buton.vadelikapat:execute" && r.Change == "NEWLY_ALLOWED");
    }

    [Fact]
    public async Task Kimlik_What_If_rol_kaldirma_kaynagi_baska_yerden_korunan_yetkiyi_ayirir()
    {
        await using var host = await TestHost.CreateAsync();
        var burak = await host.UserIdAsync("burak.arslan");
        var changes = new AuthorizationChangeSet();
        changes.UserRoles.Add(new UserRoleChange(burak, await host.RoleIdAsync("BRYSLYTK"), false));
        var impact = await host.WithAsync(sp => sp.GetRequiredService<ImpactAnalysisService>().AnalyzeAsync(changes, default));

        var u = Assert.Single(impact.Users, x => x.UserName == "burak.arslan");
        Assert.Contains(u.RemovedAccesses, a => a.Key == "anka.vadelihesap:create");            // sadece portföy rolünden geliyordu
        Assert.DoesNotContain(u.RemovedAccesses, a => a.Key == "anka.vadelihesap:close");       // vekalet grubundaki SUBEMDR'den korunur
        Assert.Contains(u.RetainedAccesses, a => a.Key == "anka.vadelihesap:close");
    }
}
