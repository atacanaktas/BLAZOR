using Microsoft.Extensions.DependencyInjection;
using Yetki.Pdp.Application.Evaluation;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Application.PolicyEngine;
using Yetki.Pdp.Application.Simulation;
using Yetki.Pdp.Domain.Common;

namespace Yetki.Pdp.Tests;

/// <summary>
/// PIP'ten gelen kimlik dışı öznitelikler (iş günü, müşteri VIP / personel) ve bunların istekten taklit edilememesi.
/// Kurallar What-If ile MESAI policy'sine eklenir (nakit çekim izni bu policy'yi içeren aggregate'e bağlı).
/// Testlerde kaynak yereldir (PIP'in geçici kurallarının aynısı: hafta içi, 99 → VIP, 98 → personel).
/// </summary>
public class PipAttributeTests
{
    private static readonly DateTime Tuesday11 = new(2026, 9, 22, 8, 0, 0, DateTimeKind.Utc);
    private static readonly DateTime Saturday11 = new(2026, 9, 26, 8, 0, 0, DateTimeKind.Utc);

    private static ConditionDraft Pred(string type) => new() { Kind = ConditionKind.Predicate, ConditionTypeCode = type };
    private static ConditionDraft Not(ConditionDraft c) => new() { Kind = ConditionKind.Not, Children = [c] };

    private static async Task<AuthorizationDecision> DecideAsync(TestHost host, ConditionDraft rule, string reason, DateTime asOf,
        params (string Key, string Value)[] context)
    {
        var policyId = await host.PolicyIdAsync("MESAI");
        var request = new AuthorizationRequest
        {
            Subject = new SubjectInfo { Id = "ayse.yilmaz" }, AccessKey = "anka.nakitcekim:create",
            Context = { ["IpAddress"] = TestHost.BankIp, ["TransactionAmount"] = "1000" }
        };
        foreach (var (k, v) in context) request.Context[k] = v;
        return await host.WithAsync(sp => sp.GetRequiredService<SimulationService>().EvaluateAsync(new SimulatedEvaluateRequest
        {
            Request = request, AsOfUtc = asOf,
            PolicyChanges = new PolicyChangeSet { AddedRules = [new RuleDraft { PolicyId = policyId, Code = "TEST_RULE", Order = 1, ReasonCode = reason, Condition = rule }] }
        }, default));
    }

    [Fact]
    public async Task Is_gunu_kosulu_hafta_ici_saglanir_hafta_sonu_reddeder()
    {
        await using var host = await TestHost.CreateAsync();
        var weekday = await DecideAsync(host, Pred("BUSINESS_DAY"), "NOT_BUSINESS_DAY", Tuesday11, ("CustomerId", "C-9"));
        Assert.Equal(DecisionType.Permit, weekday.Decision);

        var weekend = await DecideAsync(host, Pred("BUSINESS_DAY"), "NOT_BUSINESS_DAY", Saturday11, ("CustomerId", "C-9"));
        Assert.Equal(DecisionType.Deny, weekend.Decision);
        Assert.Contains(weekend.Evidence, a => a.Attribute == "Environment.IsBusinessDay" && a.Value == "False" && a.Source.StartsWith("PIP"));
    }

    [Fact]
    public async Task Istek_baglami_is_gunu_ve_VIP_bilgisini_taklit_edemez()
    {
        await using var host = await TestHost.CreateAsync();
        var spoofDay = await DecideAsync(host, Pred("BUSINESS_DAY"), "NOT_BUSINESS_DAY", Saturday11, ("CustomerId", "C-9"), ("IsBusinessDay", "true"));
        Assert.Contains(spoofDay.Evidence, a => a.Attribute == "Environment.IsBusinessDay" && a.Value == "False");

        var spoofVip = await DecideAsync(host, Pred("CUSTOMER_IS_VIP"), "NOT_VIP", Tuesday11, ("CustomerId", "12345678"), ("IsVip", "true"));
        Assert.Equal(DecisionType.Deny, spoofVip.Decision);
        Assert.Equal("NOT_VIP", spoofVip.ReasonCode);
    }

    [Fact]
    public async Task VIP_musteri_99_onekiyle_taninir()
    {
        await using var host = await TestHost.CreateAsync();
        Assert.Equal(DecisionType.Permit, (await DecideAsync(host, Pred("CUSTOMER_IS_VIP"), "NOT_VIP", Tuesday11, ("CustomerId", "99123456"))).Decision);
        Assert.Equal(DecisionType.Deny, (await DecideAsync(host, Pred("CUSTOMER_IS_VIP"), "NOT_VIP", Tuesday11, ("CustomerId", "12345678"))).Decision);
    }

    [Fact]
    public async Task Personel_musterisinde_islem_reddedilir_digerlerinde_etkisizdir()
    {
        await using var host = await TestHost.CreateAsync();
        var rule = Not(Pred("CUSTOMER_IS_STAFF"));   // "müşteri personel değilse" — yetkili rol için OR ile genişletilir
        var staff = await DecideAsync(host, rule, "STAFF_CUSTOMER", Tuesday11, ("CustomerId", "98123456"));
        Assert.Equal(DecisionType.Deny, staff.Decision);
        Assert.Equal("STAFF_CUSTOMER", staff.ReasonCode);

        Assert.Equal(DecisionType.Permit, (await DecideAsync(host, rule, "STAFF_CUSTOMER", Tuesday11, ("CustomerId", "12345678"))).Decision);
    }

    [Fact]
    public async Task Gunluk_limit_PIPten_gelir_bugun_kullanilan_sifir_kabul_edilir()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await DecideAsync(host, Not(Pred("AMOUNT_EXCEEDS_DAILY_LIMIT")), "DAILY_LIMIT_EXCEEDED", Tuesday11, ("CustomerId", "C-9"), ("CashUsedToday", "999999999"));
        Assert.Equal(DecisionType.Permit, d.Decision);
        var ayse = await host.UserIdAsync("ayse.yilmaz");
        var info = await host.WithAsync(sp => sp.GetRequiredService<Yetki.Pdp.Application.Identity.IExternalAttributeSource>().CashLimitAsync(ayse, new DateOnly(2026, 9, 22), default));
        Assert.Contains(d.Evidence, a => a.Attribute == "Subject.DailyCashLimit" && a.Value == (info.PerTransactionLimit * 3).ToString(System.Globalization.CultureInfo.InvariantCulture));
        Assert.Contains(d.Evidence, a => a.Attribute == "Subject.CashUsedToday" && a.Value == "0");   // istekteki CashUsedToday yok sayılır
    }

    [Fact]
    public async Task Islem_basi_limit_de_PIP_limit_kaynagindan_gelir()
    {
        await using var host = await TestHost.CreateAsync();
        var over = await host.EvaluateAsync("ayse.yilmaz", "anka.nakitcekim:create", null, ("TransactionAmount", "75000"), ("CustomerId", "C-9999"), ("CashWithdrawalLimit", "999999999"));
        Assert.Equal("AMOUNT_EXCEEDS_USER_LIMIT", over.ReasonCode);
        Assert.Contains(over.Evidence, a => a.Attribute == "Subject.CashWithdrawalLimit" && a.Source.StartsWith("PIP"));
    }

    [Fact]
    public async Task Musteri_numarasi_yoksa_musteri_kosulu_belirsizdir_ve_izin_vermez()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await DecideAsync(host, Not(Pred("CUSTOMER_IS_STAFF")), "STAFF_CUSTOMER", Tuesday11);
        Assert.NotEqual(DecisionType.Permit, d.Decision);
    }
}
