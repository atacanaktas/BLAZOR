﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Pdp.Application.External;
using Yetki.Pdp.Application.Governance;
using Yetki.Pdp.Application.PolicyEngine;
using Yetki.Pdp.Domain.Catalog;
using Yetki.Pdp.Domain.Common;
using Yetki.Pdp.Domain.Governance;
using Yetki.Pdp.Domain.Groups;
using Yetki.Pdp.Domain.Policies;
using Yetki.Pdp.Infrastructure.Persistence;

namespace Yetki.Pdp.Tests;

/// <summary>
/// Kimlik koşul policy'sinin içinde (KİM kartı): aynı kural iki yolla kurulur ve her hesap aynı çıkmalıdır.
///   ESKİ: rol policy'si + grup policy'si + kullanıcı policy'si → Affirmative aggregate (VEYA) + ayrı saat policy'si
///   YENİ: tek koşul policy'si; kural KİM = (rol GISEAST VEYA grup SUBE_101_PERSONEL VEYA kullanıcı sibel.ates), kural SAAT = 12:30-13:30
/// Karşılaştırılan: kimde var (koşullu bayrağı, kaynaklar, kalan koşullar), RACF olması gereken durum, SoD, çalışma anı kararları.
/// </summary>
public class InlineIdentityTests
{
    private const string Eski = "ornek.eski:view", Yeni = "ornek.yeni:view";

    private static readonly string[] Everyone =
    [
        "ayse.yilmaz", "mert.kaya", "zeynep.acar", "ali.demir", "elif.sahin", "can.ozturk", "selin.aydin", "hakan.tekin", "ahmet.kaya",
        "deniz.koc", "burak.arslan", "emre.yildiz", "kemal.sari", "murat.aksoy", "gul.yuce", "sibel.ates", "svc.rapor-batch", "nil.sezer"
    ];

    private static async Task<TestHost> CreateAsync()
    {
        var host = await TestHost.CreateAsync();
        await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<YetkiDbContext>();
            var abank = await db.Tenants.SingleAsync(t => t.Code == "ABANK");
            var anka = await db.Applications.SingleAsync(a => a.Code == "ANKA");
            var view = await db.Scopes.SingleAsync(s => s.ApplicationId == anka.Id && s.Code == "view");
            var type = await db.ResourceTypes.SingleAsync(t => t.Code == "BUTTON");
            var types = await db.ConditionTypes.ToDictionaryAsync(t => t.Code);
            var gise = await db.Roles.SingleAsync(r => r.Code == "GISEAST");
            var sibel = await db.Users.SingleAsync(u => u.UserName == "sibel.ates");
            var racf = await db.ExternalSystems.SingleAsync(s => s.Code == "RACF");
            var krediOnay = await db.ResourceScopes.SingleAsync(rs => rs.Resource.Code == "anka.kredionay" && rs.Scope.Code == "approve");

            var g101 = new Group { Tenant = abank, Code = "SUBE_101_PERSONEL", Name = "101 Şube personeli" };
            g101.Filters.Add(new GroupFilter
            {
                Mode = InclusionMode.Include, Description = "101'deki herkes",
                Criteria = [new GroupFilterCriterion { Attribute = "ORG_UNIT", Values = [new GroupFilterValue { Value = "101" }] }]
            });
            db.Groups.Add(g101);
            await db.SaveChangesAsync();

            Resource Res(string code)
            {
                var r = new Resource { Application = anka, ResourceType = type, Code = code, Name = code, Scopes = [new ResourceScope { Scope = view }] };
                db.Resources.Add(r);
                return r;
            }
            var rEski = Res("ornek.eski");
            var rYeni = Res("ornek.yeni");

            Policy PolicyOf(string code, DecisionStrategy strategy = DecisionStrategy.Unanimous)
            {
                var p = new Policy { Tenant = abank, Code = code, Name = code, DecisionStrategy = strategy };
                db.Policies.Add(p);
                return p;
            }
            RuleCondition Pred(string code, string key, string value) =>
                new() { Kind = ConditionKind.Predicate, ConditionType = types[code], Parameters = [new ConditionParameter { Key = key, Value = value }] };
            RuleCondition Saat() => new()
            {
                Kind = ConditionKind.Predicate, ConditionType = types["TIME_WINDOW"],
                Parameters = [new() { Key = "Start", Value = "12:30" }, new() { Key = "End", Value = "13:30" }, new() { Key = "TimeZone", Value = "Europe/Istanbul" }]
            };
            void RuleOf(Policy p, string code, int order, RuleCondition root)
            {
                var rule = new Rule { Policy = p, Code = code, Name = code, Order = order, ReasonCode = code };
                db.Rules.Add(rule);
                void Attach(RuleCondition n) { n.Rule = rule; foreach (var c in n.Children) Attach(c); }
                Attach(root);
                db.RuleConditions.Add(root);
            }

            RuleCondition Ref(Policy target) => new() { Kind = ConditionKind.Reference, ReferencedPolicy = target };

            // PARÇALI yapı (eski "rol + grup + kullanıcı policy'si → birleşik VEYA" düzeninin tipsiz karşılığı):
            // tek kartlı rol / grup / kullanıcı policy'leri, onları VEYA (Affirmative) ile referanslayan policy, ayrı saat policy'si
            var pRol = PolicyOf("ORNEK_ROL"); RuleOf(pRol, "KIM", 10, Pred("SUBJECT_HAS_ROLE", "Roles", "GISEAST"));
            var pGrup = PolicyOf("ORNEK_GRUP"); RuleOf(pGrup, "KIM", 10, Pred("SUBJECT_IN_GROUP", "Groups", "SUBE_101_PERSONEL"));
            var pKul = PolicyOf("ORNEK_KUL"); RuleOf(pKul, "KIM", 10, Pred("SUBJECT_IS_USER", "Users", "sibel.ates"));
            await db.SaveChangesAsync();
            var pKim = PolicyOf("ORNEK_KIM", DecisionStrategy.Affirmative);
            RuleOf(pKim, "ROL", 10, Ref(pRol)); RuleOf(pKim, "GRUP", 20, Ref(pGrup)); RuleOf(pKim, "KUL", 30, Ref(pKul));
            var pSaat = PolicyOf("ORNEK_SAAT");
            RuleOf(pSaat, "SAAT", 10, Saat());

            // YENİ yapı: tek policy, KİM kartı + SAAT kartı
            var pYeni = PolicyOf("ORNEK_TEK");
            var kim = new RuleCondition { Kind = ConditionKind.AnyOf };
            kim.Children.Add(Pred("SUBJECT_HAS_ROLE", "Roles", "GISEAST"));
            kim.Children.Add(Pred("SUBJECT_IN_GROUP", "Groups", "SUBE_101_PERSONEL"));
            kim.Children.Add(Pred("SUBJECT_IS_USER", "Users", "sibel.ates"));
            for (var i = 0; i < kim.Children.Count; i++) { kim.Children.ElementAt(i).Order = i; kim.Children.ElementAt(i).Parent = kim; }
            RuleOf(pYeni, "KIM", 10, kim);
            RuleOf(pYeni, "SAAT", 20, Saat());
            await db.SaveChangesAsync();

            // REFERANSLI yapı: mevcut policy'ler kural içinden çağrılır (tekrar kullanım birimi policy)
            var rRef = Res("ornek.ref");
            var pRef = PolicyOf("ORNEK_REF");
            var kimRef = new RuleCondition { Kind = ConditionKind.AnyOf };
            foreach (var (target, i) in new[] { pRol, pGrup, pKul }.Select((t, i) => (t, i)))
            {
                var n = Ref(target); n.Order = i; n.Parent = kimRef; kimRef.Children.Add(n);
            }
            RuleOf(pRef, "KIM", 10, kimRef);
            RuleOf(pRef, "SAAT", 20, Ref(pSaat));
            await db.SaveChangesAsync();

            Permission Perm(string code, Resource r, params Policy[] policies) => new()
            {
                Application = anka, Code = code, Name = code, Target = PermissionTarget.Resources, AllScopes = true,
                Resources = [new PermissionResource { Resource = r }],
                Policies = policies.Select((p, i) => new PermissionPolicy { Policy = p, Order = i }).ToList()
            };
            db.Permissions.Add(Perm("ORNEK_ESKI", rEski, pKim, pSaat));
            db.Permissions.Add(Perm("ORNEK_YENI", rYeni, pYeni));
            db.Permissions.Add(Perm("ORNEK_REF", rRef, pRef));

            // RACF: iki resource da ayrı bir dış yetki ister; SoD: ikisi de kredi onayıyla çatışır
            foreach (var (r, code) in new[] { (rEski, "ORNESKI"), (rYeni, "ORNYENI") })
            {
                var ext = new ExternalPermission { ExternalSystem = racf, Code = code, ResourceClass = "TCICSTRN", Name = code };
                db.ExternalPermissions.Add(ext);
                db.ExternalDependencies.Add(new ExternalDependency { Resource = r, ExternalPermission = ext, AccessLevel = ExternalAccessLevel.Read });
                db.SodRules.Add(new SodRule
                {
                    Code = "SOD_" + code, Name = code, Severity = Severity.High, Enforcement = SodEnforcement.Warn,
                    Members =
                    [
                        new SodRuleMember { MemberType = SodMemberType.ResourceScope, MemberId = r.Scopes.Single().Id },
                        new SodRuleMember { MemberType = SodMemberType.ResourceScope, MemberId = krediOnay.Id }
                    ]
                });
            }
            await db.SaveChangesAsync();
        });
        return host;
    }

    /// <summary>"POLICY: [@REF: ...] metin" → metin (iki yapıda policy kodları / referans zinciri farklıdır, gerisi aynı olmalı).</summary>
    private static string Text(string s)
    {
        var t = s[(s.IndexOf(": ", StringComparison.Ordinal) + 2)..];
        while (t.StartsWith('@')) t = t[(t.IndexOf(": ", StringComparison.Ordinal) + 2)..];
        return t;
    }

    [Fact]
    public async Task Kimde_var_kaynaklar_ve_kosullar_iki_yapida_ayni()
    {
        await using var host = await CreateAsync();
        var m = await host.ModelAsync();
        var now = host.Clock.UtcNow;

        var eski = m.HoldersOf(m.ResourceScopeIdByKey[Eski], now).Select(h => h.User.UserName).ToHashSet();
        var yeni = m.HoldersOf(m.ResourceScopeIdByKey[Yeni], now).Select(h => h.User.UserName).ToHashSet();
        Assert.Equal(new HashSet<string>
        {
            "ayse.yilmaz", "mert.kaya", "deniz.koc",                                                  // GISEAST
            "zeynep.acar", "ali.demir", "elif.sahin", "can.ozturk", "selin.aydin", "hakan.tekin", "ahmet.kaya",   // 101 birimi
            "sibel.ates"                                                                               // adıyla
        }, eski);
        Assert.Equal(eski, yeni);

        foreach (var user in Everyone)
        {
            var set = m.GetEffective(m.UserIdByName[user], now);
            var a = set.Find(Eski);
            var b = set.Find(Yeni);
            Assert.Equal(a is null, b is null);
            if (a is null || b is null) continue;
            Assert.True(a.Conditional);                         // saat istek anına bağlı
            Assert.Equal(a.Conditional, b.Conditional);
            Assert.Equal(a.Sources.Select(s => Text(s.Path)).OrderBy(x => x), b.Sources.Select(s => Text(s.Path)).OrderBy(x => x));
            Assert.Equal(a.Conditions.Select(Text), b.Conditions.Select(Text));
            Assert.Contains("TIME_WINDOW", Assert.Single(b.Conditions));
            Assert.All(b.Sources, s => Assert.Equal("ORNEK_TEK", s.Policy));
        }

        var ayse = m.GetEffective(m.UserIdByName["ayse.yilmaz"], now).Find(Yeni)!;
        Assert.Contains(ayse.Sources, s => s.Path.Contains("rol GISEAST"));
        Assert.Contains(ayse.Sources, s => s.Path.Contains("grup SUBE_101_PERSONEL"));
        Assert.Contains(m.GetEffective(m.UserIdByName["sibel.ates"], now).Find(Yeni)!.Sources, s => s.Path.Contains("kullanıcı sibel.ates"));
    }

    [Fact]
    public async Task RACF_olmasi_gereken_durum_ve_SoD_iki_yapida_ayni()
    {
        await using var host = await CreateAsync();
        var desired = await host.WithAsync(sp => sp.GetRequiredService<ExternalAnalysisService>().DesiredAsync(null, default));
        HashSet<string> Needing(string code) =>
            desired.Where(u => u.Needs.Any(n => n.Target.Code == code)).Select(u => u.UserName).ToHashSet();
        var eski = Needing("ORNESKI");
        Assert.Equal(11, eski.Count);
        Assert.Equal(eski, Needing("ORNYENI"));

        var scan = await host.WithAsync(sp => sp.GetRequiredService<SodService>().DetectAsync(default));
        HashSet<string> Violators(string code) =>
            scan.Details.Where(d => d.Conflicts.Any(c => c.Code == code)).Select(d => d.UserName).ToHashSet();
        Assert.Equal(new HashSet<string> { "ali.demir", "hakan.tekin", "sibel.ates" }, Violators("SOD_ORNESKI"));
        Assert.Equal(Violators("SOD_ORNESKI"), Violators("SOD_ORNYENI"));
    }

    [Theory]
    [InlineData(10, 0, true)]    // 13:00 İstanbul: öğle arası içinde
    [InlineData(11, 0, false)]   // 14:00 İstanbul: dışında
    public async Task Calisma_ani_kararlari_iki_yapida_ayni(int hourUtc, int minuteUtc, bool inWindow)
    {
        await using var host = await CreateAsync();
        host.Clock.UtcNow = new DateTime(2026, 9, 22, hourUtc, minuteUtc, 0, DateTimeKind.Utc);
        foreach (var user in Everyone)
        {
            var a = await host.EvaluateAsync(user, Eski);
            var b = await host.EvaluateAsync(user, Yeni);
            Assert.Equal(a.Decision, b.Decision);
            if (user == "sibel.ates" || user == "deniz.koc" || user == "elif.sahin")
                Assert.Equal(inWindow ? DecisionType.Permit : DecisionType.Deny, b.Decision);
            if (user == "gul.yuce") Assert.Equal(DecisionType.Deny, b.Decision);
            Assert.Equal(a.Decision, (await host.EvaluateAsync(user, "ornek.ref:view")).Decision);
        }
    }

    [Fact]
    public async Task Policy_referansi_aggregate_ile_ayni_sahipleri_verir_ve_kullananlara_yansir()
    {
        await using var host = await CreateAsync();
        var m = await host.ModelAsync();
        var now = host.Clock.UtcNow;
        var eski = m.HoldersOf(m.ResourceScopeIdByKey[Eski], now).Select(h => h.User.UserName).ToHashSet();
        var refHolders = m.HoldersOf(m.ResourceScopeIdByKey["ornek.ref:view"], now).ToList();
        Assert.Equal(eski, refHolders.Select(h => h.User.UserName).ToHashSet());

        var sibel = m.GetEffective(m.UserIdByName["sibel.ates"], now).Find("ornek.ref:view")!;
        Assert.True(sibel.Conditional);
        Assert.Contains(sibel.Sources, s => s.Path.Contains("@ORNEK_KUL: kullanıcı sibel.ates"));
        Assert.Contains(sibel.Conditions, c => c.Contains("@ORNEK_SAAT"));

        // Referans verilen policy'yi değiştiren, onu kullanan permission'ları da etkiler
        Assert.Contains(m.PermissionsUsingPolicy(await host.PolicyIdAsync("ORNEK_SAAT")), p => p.Row.Code == "ORNEK_REF");
        Assert.Contains(m.PermissionsUsingPolicy(await host.PolicyIdAsync("ORNEK_ROL")), p => p.Row.Code == "ORNEK_REF");
        Assert.True(m.HasIdentityPolicy(m.Permissions.Values.Single(p => p.Row.Code == "ORNEK_REF")));
    }

    [Fact]
    public async Task Dongusel_ve_baska_kurumdaki_policy_referansi_reddedilir()
    {
        await using var host = await CreateAsync();
        var saat = await host.PolicyIdAsync("ORNEK_SAAT");
        var draft = new Yetki.Pdp.Application.Model.ConditionDraft { Kind = ConditionKind.Reference, PolicyCode = "ORNEK_REF" };   // ORNEK_REF → ORNEK_SAAT
        var ex = await Assert.ThrowsAsync<Yetki.Pdp.Application.Abstractions.ValidationException>(() => host.WithAsync(sp =>
            sp.GetRequiredService<Yetki.Pdp.Application.Definitions.ConditionDraftValidator>().ValidateConditionAsync(draft, default, saat)));
        Assert.Contains("Döngüsel", string.Join(" ", ex.Errors.SelectMany(e => e.Value)));

        // ABANK policy'si alt kurum BISTIRAK policy'sine referans veremez (tersi verebilir: üst kurumun policy'si mirastır)
        var bPolicy = await host.PolicyIdAsync("ROL_B_PORTFOY");
        var cross = new Yetki.Pdp.Application.Model.ConditionDraft { Kind = ConditionKind.Reference, PolicyCode = "ROL_B_PORTFOY" };
        await Assert.ThrowsAsync<Yetki.Pdp.Application.Abstractions.ValidationException>(() => host.WithAsync(sp =>
            sp.GetRequiredService<Yetki.Pdp.Application.Definitions.ConditionDraftValidator>().ValidateConditionAsync(cross, default, saat)));
        var inherited = new Yetki.Pdp.Application.Model.ConditionDraft { Kind = ConditionKind.Reference, PolicyCode = "ORNEK_SAAT" };
        await host.WithAsync(sp => sp.GetRequiredService<Yetki.Pdp.Application.Definitions.ConditionDraftValidator>().ValidateConditionAsync(inherited, default, bPolicy));
    }

    [Fact]
    public async Task Pasif_policy_referansi_belirsizdir_NOT_icinde_de_izin_acmaz()
    {
        await using var host = await CreateAsync();
        host.Clock.UtcNow = new DateTime(2026, 9, 22, 10, 0, 0, DateTimeKind.Utc);
        await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<YetkiDbContext>();
            (await db.Policies.SingleAsync(p => p.Code == "ORNEK_SAAT")).IsActive = false;
            var rule = await db.Rules.Include(r => r.Conditions).SingleAsync(r => r.Policy.Code == "ORNEK_REF" && r.Code == "SAAT");
            var root = rule.Conditions.Single();
            var not = new RuleCondition { Rule = rule, Kind = ConditionKind.Not };
            root.Parent = not;
            db.RuleConditions.Add(not);
            await db.SaveChangesAsync();
        });
        var d = await host.EvaluateAsync("sibel.ates", "ornek.ref:view");
        Assert.Equal(DecisionType.Indeterminate, d.Decision);
        Assert.False(d.IsAllowed);
    }
}
