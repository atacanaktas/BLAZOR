﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Pdp.Application.Model;
using Yetki.Pdp.Application.PolicyEngine;
using Yetki.Pdp.Domain.Common;
using Yetki.Pdp.Domain.Groups;
using Yetki.Pdp.Domain.Policies;
using Yetki.Pdp.Infrastructure.Persistence;

namespace Yetki.Pdp.Tests;

/// <summary>
/// KİTLE = grup kuralı = KİM kartı. Aynı satırlar grup kuralı olarak da KİM kartı (koşul ağacı) olarak da AYNI kişileri vermeli;
/// ki KİM kartı gruba çevrilebilsin, grup karta geri alınabilsin. Örtüşme: tanım aynı → öneri, sadece üyeler aynı → bilgi.
/// </summary>
public class AudienceTests
{
    private static AudienceRow Row(InclusionMode mode, params (string Attr, string[] Values)[] criteria) =>
        new(mode, criteria.Select(c => new CriterionRow(c.Attr, c.Values)).ToList());
    private static AudienceRow Inc(params (string, string[])[] c) => Row(InclusionMode.Include, c);
    private static AudienceRow Exc(params (string, string[])[] c) => Row(InclusionMode.Exclude, c);

    /// <summary>Kitleyi hem grup olarak kaydeder hem kart olarak değerlendirir; iki üye listesini döner.</summary>
    private static async Task<(HashSet<string> Group, HashSet<string> Card)> BothAsync(TestHost host, string code, IReadOnlyList<AudienceRow> rows)
    {
        await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<YetkiDbContext>();
            var g = new Group { TenantId = (await db.Tenants.SingleAsync(t => t.Code == "ABANK")).Id, Code = code, Name = code };
            for (var i = 0; i < rows.Count; i++)
                g.Filters.Add(new GroupFilter
                {
                    Mode = rows[i].Mode, Order = i,
                    Criteria = rows[i].Criteria.Select((c, j) => new GroupFilterCriterion { Attribute = c.Attribute, Order = j, Values = c.Values.Select(v => new GroupFilterValue { Value = v }).ToList() }).ToList()
                });
            db.Groups.Add(g);
            await db.SaveChangesAsync();
        });
        var m = await host.ModelAsync();
        var groupId = m.Groups.Values.Single(g => g.Code == code).Id;
        var group = m.GroupMembersOf(groupId, host.Clock.UtcNow).Select(x => x.User.UserName).ToHashSet();
        var card = m.AudienceMembers(Audience.ToNode(Audience.ToCondition(rows)), host.Clock.UtcNow).Select(u => u.UserName).ToHashSet();
        return (group, card);
    }

    public static IEnumerable<object[]> Cases() =>
    [
        ["BIRIM", new[] { Inc(("ORG_UNIT", ["101"])) }],
        ["BIRIM_AGAC", new[] { Inc(("ORG_UNIT_TREE", ["BLG_IST"])) }],
        ["BIRIM_TIPI", new[] { Inc(("ORG_UNIT_TYPE", ["Department"])) }],
        ["UNVAN", new[] { Inc(("TITLE", ["gişe yetkilisi", "Uzman Yetkili"])) }],
        ["KURUM", new[] { Inc(("TENANT", ["ABANK"])) }],
        ["KISI", new[] { Inc(("USER", ["sibel.ates", "ali.demir"])) }],
        ["TUR", new[] { Inc(("USER_KIND", ["ServiceAccount"])) }],
        ["ROL_DOGRUDAN", new[] { Inc(("ROLE", ["GISEAST"])) }],
        // satır içi VE + satırlar arası VEYA + hariç
        ["KARMA", new[] { Inc(("ROLE", ["GISEAST", "GISEYTK"]), ("ORG_UNIT", ["101"])), Inc(("USER", ["sibel.ates"])), Exc(("TITLE", ["Stajyer Gişe Asistanı"])) }],
        ["KURUM_HARIC_SERVIS", new[] { Inc(("TENANT", ["ABANK"])), Exc(("USER_KIND", ["ServiceAccount"])) }],
    ];

    [Theory]
    [MemberData(nameof(Cases))]
    public async Task Grup_kurali_ve_KIM_karti_ayni_kisileri_verir(string code, AudienceRow[] rows)
    {
        await using var host = await TestHost.CreateAsync();
        var (group, card) = await BothAsync(host, "T_" + code, rows);
        Assert.NotEmpty(group);
        Assert.Equal(group.OrderBy(x => x), card.OrderBy(x => x));
    }

    [Fact]
    public async Task Rol_farki_grup_dogrudan_kart_etkin_role_bakar()
    {
        // burak.arslan SUBEMDR rolünü SUBEMDR_VEKALET_737 grubundan alıyor (doğrudan değil)
        await using var host = await TestHost.CreateAsync();
        var (group, card) = await BothAsync(host, "T_SUBEMDR", [Inc(("ROLE", ["SUBEMDR"]))]);
        Assert.DoesNotContain("burak.arslan", group);
        Assert.Contains("burak.arslan", card);
        Assert.Equal(group, card.Where(u => u != "burak.arslan").ToHashSet());
    }

    [Fact]
    public void Kosul_agaci_ve_satirlar_birbirine_cevrilir_tanim_anahtari_sirasiz()
    {
        IReadOnlyList<AudienceRow> rows = [Inc(("ROLE", ["GISEAST"]), ("ORG_UNIT", ["101"])), Inc(("USER", ["sibel.ates"])), Exc(("TITLE", ["Stajyer"]))];
        var back = Audience.Parse(Audience.ToNode(Audience.ToCondition(rows)));
        Assert.NotNull(back);
        Assert.Equal(Audience.Key(rows), Audience.Key(back!));
        IReadOnlyList<AudienceRow> shuffled = [Exc(("TITLE", ["stajyer"])), Inc(("user", ["SIBEL.ATES"])), Inc(("ORG_UNIT", ["101"]), ("ROLE", ["GISEAST"]))];
        Assert.Equal(Audience.Key(rows), Audience.Key(shuffled));
        Assert.NotEqual(Audience.Key(rows), Audience.Key([Inc(("ROLE", ["GISEAST"]), ("ORG_UNIT", ["101"]))]));
        Assert.False(Audience.CanBecomeGroup([Inc(("GROUP", ["KREDI_KOMITESI"]))]));
        // eski düz KİM kartı (rol VEYA grup VEYA kişi) da kitle olarak okunur
        Assert.NotNull(Audience.Parse(Audience.ToNode(Audience.ToCondition([Inc(("ROLE", ["GISEAST"])), Inc(("GROUP", ["X"])), Inc(("USER", ["a"]))]))));
    }

    /// <summary>PAP'ın "gruba çevir" önizlemesiyle aynı istek: yeni grup (-1) + kitle kuralı + kuralın "grup X" ile değişmesi.</summary>
    private static Yetki.Pdp.Application.Changes.ImpactRequest PromoteRequest(int tenantId, string code, IReadOnlyList<AudienceRow> rows, RuleDefinition rule, int policyId) => new()
    {
        Patch = [new ModelPatchOperation { Table = "Groups", Op = PatchOp.Add, Row = System.Text.Json.JsonSerializer.SerializeToElement(new GroupRow(-1, tenantId, code, code, true)) }],
        Changes = new AuthorizationChangeSet
        {
            GroupFilters = [new GroupFiltersReplacement(-1, rows.Select(r => new GroupFilterDraft { Mode = r.Mode, Criteria = r.Criteria.Select(c => new GroupCriterionDraft { Attribute = c.Attribute, Values = c.Values.ToList() }).ToList() }).ToList())]
        },
        PolicyChanges = new PolicyChangeSet
        {
            ReplacedRules = [new RuleReplacement(rule.RuleId, new RuleDraft
            {
                PolicyId = policyId, Code = rule.Code, Name = rule.Name, Order = rule.Order, ReasonCode = rule.ReasonCode,
                Condition = new ConditionDraft { Kind = ConditionKind.Predicate, ConditionTypeCode = "SUBJECT_IN_GROUP", Parameters = new() { ["Groups"] = code } }
            })]
        }
    };

    [Fact]
    public async Task Gruba_cevirme_onizlemesi_ayni_tanimda_kimseyi_etkilemez_rol_farkinda_etkileneni_gosterir()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var abank = m.TenantByCode["ABANK"].Id;
        var impact = (IServiceProvider sp) => sp.GetRequiredService<Yetki.Pdp.Application.Changes.ImpactAnalysisService>();

        // SUBE_KAPSAMI / HQ_928 = "birim 928" KİM kartı → grup ORG_UNIT 928
        var kapsam = m.Policies.Values.Single(p => p.Row.Code == "SUBE_KAPSAMI");
        var hq = kapsam.Definition!.Rules.Single(r => r.Code == "HQ_928");
        var rows = Audience.Parse(hq.Condition)!;
        var same = await host.WithAsync(sp => impact(sp).AnalyzeAsync(PromoteRequest(abank, "GM_928", rows, hq, kapsam.Row.Id), default));
        Assert.Equal(0, same.Users.Count(u => u.AccessesChanged));

        // Kart "rol SUBEMDR" (etkin rol) → grup ROLE SUBEMDR (doğrudan rol): vekaletten gelen burak.arslan düşer
        var gm850 = m.Policies.Values.Single(p => p.Row.Code == "KREDI_SUBE_LIMITI");
        var limit = gm850.Definition!.Rules.Single();
        IReadOnlyList<AudienceRow> mdr = [Inc(("ROLE", ["SUBEMDR"]))];
        var asCard = new RuleReplacement(limit.RuleId, new RuleDraft { PolicyId = gm850.Row.Id, Code = limit.Code, Order = limit.Order, Condition = Audience.ToCondition(mdr) });
        var cardModel = new Yetki.Pdp.Application.Changes.ImpactRequest { PolicyChanges = new PolicyChangeSet { ReplacedRules = [asCard] } };
        var promote = PromoteRequest(abank, "MDR", mdr, limit with { }, gm850.Row.Id);
        // önce kart hali, sonra grup hali: aradaki fark burak.arslan
        var before = await host.WithAsync(sp => sp.GetRequiredService<AuthorizationModelProvider>().BuildWhatIfAsync(null, cardModel.PolicyChanges, null, default));
        var after = await host.WithAsync(sp => sp.GetRequiredService<AuthorizationModelProvider>().BuildWhatIfAsync(promote.Changes, promote.PolicyChanges, promote.Patch, default));
        var diff = await host.WithAsync(sp => impact(sp).AnalyzeAsync(before, after, default));
        var changed = diff.Users.Where(u => u.AccessesChanged).Select(u => u.UserName).ToList();
        Assert.Equal(["burak.arslan"], changed);
    }

    [Fact]
    public async Task Ortusme_tanim_ayniysa_kart_ve_grup_onerir_sadece_uyeler_ayniysa_bilgi_verir()
    {
        await using var host = await TestHost.CreateAsync();
        // GISE_101_AST grubu: ROLE GISEAST ∧ ORG_UNIT 101 − TITLE Stajyer Gişe Asistanı (örnek veri)
        IReadOnlyList<AudienceRow> gise101 = [Inc(("ORG_UNIT", ["101"]), ("ROLE", ["GISEAST"])), Exc(("TITLE", ["Stajyer Gişe Asistanı"]))];
        await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<YetkiDbContext>();
            var abank = await db.Tenants.SingleAsync(t => t.Code == "ABANK");
            var types = await db.ConditionTypes.ToDictionaryAsync(t => t.Code);
            var p = new Policy { Tenant = abank, Code = "KART_SAHIBI", Name = "x" };
            db.Policies.Add(p);
            var rule = new Rule { Policy = p, Code = "KIM", Name = "KİM", Order = 10 };
            db.Rules.Add(rule);
            RuleCondition Build(Yetki.Pdp.Application.Model.ConditionDraft d) => new()
            {
                Rule = rule, Kind = d.Kind, ConditionType = d.ConditionTypeCode is null ? null : types[d.ConditionTypeCode],
                Parameters = d.Parameters.Select(kv => new ConditionParameter { Key = kv.Key, Value = kv.Value }).ToList(),
                Children = d.Children.Select((c, i) => { var n = Build(c); n.Order = i; return n; }).ToList()
            };
            db.RuleConditions.Add(Build(Audience.ToCondition(gise101)));
            await db.SaveChangesAsync();
        });

        var svc = (IServiceProvider sp) => sp.GetRequiredService<AudienceService>();
        GroupFilterDraft Draft(AudienceRow r) => new() { Mode = r.Mode, Criteria = r.Criteria.Select(c => new GroupCriterionDraft { Attribute = c.Attribute, Values = c.Values.ToList() }).ToList() };

        // 1) Aynı tanım (satır / kriter sırası farklı) → hem kart hem grup eşleşir
        var same = await host.WithAsync(sp => svc(sp).OverlapAsync(new AudienceOverlapRequest { Filters = gise101.Reverse().Select(Draft).ToList() }, default));
        Assert.Equal(new HashSet<string> { "ayse.yilmaz" }, same.Members.ToHashSet());
        Assert.Contains(same.SameDefinition, x => x.Policy == "KART_SAHIBI" && x.Rule == "KIM");
        var g = Assert.Single(same.SameDefinitionGroups);
        Assert.Equal("GISE_101_AST", g.Code);
        Assert.True(g.SameMembers);

        // 2) Tanım farklı, bugün aynı kişi (ayse.yilmaz) → sadece bilgi
        var info = await host.WithAsync(sp => svc(sp).OverlapAsync(new AudienceOverlapRequest { Filters = [Draft(Inc(("USER", ["ayse.yilmaz"])))] }, default));
        Assert.Empty(info.SameDefinition);
        Assert.Empty(info.SameDefinitionGroups);
        Assert.Contains(info.SameMembersRules, x => x.Policy == "KART_SAHIBI");
        Assert.Contains(info.SameMembersGroups, x => x.Code == "GISE_101_AST");

        // 3) Kendi kuralı kendisiyle eşleşmez; kısmi örtüşme raporlanmaz
        var ruleId = (await host.ModelAsync()).Policies.Values.Single(p => p.Row.Code == "KART_SAHIBI").Definition!.Rules.Single().RuleId;
        var self = await host.WithAsync(sp => svc(sp).OverlapAsync(new AudienceOverlapRequest { RuleId = ruleId, Filters = gise101.Select(Draft).ToList() }, default));
        Assert.DoesNotContain(self.SameDefinition, x => x.RuleId == ruleId);
        var partial = await host.WithAsync(sp => svc(sp).OverlapAsync(new AudienceOverlapRequest { Filters = [Draft(Inc(("ORG_UNIT", ["101"])))] }, default));
        Assert.Empty(partial.SameDefinition);
        Assert.DoesNotContain(partial.SameMembersRules, x => x.Policy == "KART_SAHIBI");
    }
}
