using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Extensions.Logging;

namespace Yetki.Sdk;

/// <summary>Motorun kararla döndürdüğü yükümlülük (PEP yerine getirmek ZORUNDA).</summary>
public sealed class DecisionObligationDto
{
    public string Code { get; set; } = default!;
    public string Policy { get; set; } = default!;
    public Dictionary<string, string> Parameters { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

/// <summary>
/// PEP tarafı yükümlülük uygulayıcısı. XACML kuralı: PEP yerine getiremediği yükümlülükte erişimi REDDETMELİ.
///   MASK_FIELDS(Fields, KeepLast?)  yanıt JSON'unda alanları maskeler (iç içe nesne/dizilerde de, alan adı büyük/küçük harf duyarsız)
///   LIMIT_RESULTS(Max)              yanıt bir dizi ise (veya "items" dizisi varsa) en fazla Max kayıt bırakır
///   LOG_ACCESS(Category?)           hassas veri erişim loguna yazar
/// </summary>
public static class ObligationEnforcer
{
    public static readonly IReadOnlySet<string> Supported = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "MASK_FIELDS", "LIMIT_RESULTS", "LOG_ACCESS" };

    public static IReadOnlyList<string> Unsupported(IEnumerable<DecisionObligationDto> obligations) =>
        obligations.Select(o => o.Code).Where(c => !Supported.Contains(c)).Distinct().ToList();

    /// <summary>Yanıt nesnesine yükümlülükleri uygular; değiştirilmiş JSON düğümünü döner (değişiklik yoksa null).</summary>
    public static JsonNode? Apply(object? value, IReadOnlyList<DecisionObligationDto> obligations, JsonSerializerOptions json)
    {
        var shaping = obligations.Where(o => o.Code.Equals("MASK_FIELDS", StringComparison.OrdinalIgnoreCase) || o.Code.Equals("LIMIT_RESULTS", StringComparison.OrdinalIgnoreCase)).ToList();
        if (value is null || shaping.Count == 0) return null;
        var node = JsonSerializer.SerializeToNode(value, value.GetType(), json);
        if (node is null) return null;
        foreach (var o in shaping)
        {
            if (o.Code.Equals("MASK_FIELDS", StringComparison.OrdinalIgnoreCase))
            {
                var fields = (o.Parameters.GetValueOrDefault("Fields") ?? "").Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
                    .ToHashSet(StringComparer.OrdinalIgnoreCase);
                var keepLast = int.TryParse(o.Parameters.GetValueOrDefault("KeepLast"), out var k) ? k : 0;
                Mask(node, fields, keepLast);
            }
            else if (int.TryParse(o.Parameters.GetValueOrDefault("Max"), out var max))
            {
                Limit(node, max);
            }
        }
        return node;
    }

    public static void Log(ILogger logger, IReadOnlyList<DecisionObligationDto> obligations, string? user, string permission)
    {
        foreach (var o in obligations.Where(o => o.Code.Equals("LOG_ACCESS", StringComparison.OrdinalIgnoreCase)))
            logger.LogWarning("[HASSAS ERİŞİM] {Category}: {User} → {Permission} (policy {Policy})",
                o.Parameters.GetValueOrDefault("Category") ?? "GENEL", user, permission, o.Policy);
    }

    public static string MaskValue(string s, int keepLast) =>
        s.Length <= keepLast ? new string('*', s.Length) : new string('*', s.Length - keepLast) + s[^keepLast..];

    private static void Mask(JsonNode node, HashSet<string> fields, int keepLast)
    {
        switch (node)
        {
            case JsonObject obj:
                foreach (var (key, child) in obj.ToList())
                {
                    if (fields.Contains(key) && child is JsonValue v)
                        obj[key] = MaskValue(v.ToString(), keepLast);
                    else if (child is not null) Mask(child, fields, keepLast);
                }
                break;
            case JsonArray arr:
                foreach (var child in arr) if (child is not null) Mask(child, fields, keepLast);
                break;
        }
    }

    private static void Limit(JsonNode node, int max)
    {
        var arr = node as JsonArray ?? (node as JsonObject)?["items"] as JsonArray;
        while (arr is not null && arr.Count > max) arr.RemoveAt(arr.Count - 1);
    }
}
