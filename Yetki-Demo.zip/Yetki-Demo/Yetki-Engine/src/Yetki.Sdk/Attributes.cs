namespace Yetki.Sdk;

/// <summary>RACF erişim seviyesi (PERMIT ACCESS). Boş bırakılırsa motor permission'ın action'ından türetir.</summary>
public enum ExternalAccess { Read = 1, Update = 2, Control = 3, Alter = 4 }

/// <summary>
/// Endpoint'in çağırdığı mainframe kaynağı. Kimlik yayılımında CICS, ÇAĞIRAN KULLANICININ RACF yetkisini arar;
/// motor bu bilgiyle permission'ı alan kullanıcıya RACF'te gerekeni açar. Manifestle kataloğa aktarılır.
/// Örn: [RequiresExternal("RACF", "MUS1", ResourceClass = "TCICSTRN")]
/// </summary>
[AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
public sealed class RequiresExternalAttribute(string system, string code) : Attribute
{
    public string System { get; } = system;
    public string Code { get; } = code;
    public string? ResourceClass { get; init; }
    public string? Name { get; init; }
    /// <summary>0 = belirtilmedi (action'dan türetilir).</summary>
    public ExternalAccess Access { get; init; }
}

/// <summary>
/// İş (business) bağlamı türleri. Framework'ün kendisinin bilemediği değerler için DTO property'si bu türlerle işaretlenir.
/// Property adı önemsizdir (Amount / Tutar / TransactionAmount...). Enum adı motorun context anahtarıdır.
/// IP, zaman, kanal, platform, cihaz, client SDK tarafından otomatik toplanır; iş ekibinden İSTENMEZ.
/// </summary>
public enum AuthContextType
{
    TransactionAmount,
    Currency,
    CustomerId,
    AccountNo,
    BranchCode
}

/// <summary>Motorun tanıdığı environment anahtarları (SDK otomatik toplar).</summary>
public static class AuthContextKey
{
    public const string CurrentTime = "CurrentTime";
    public const string IpAddress = "IpAddress";
    public const string Channel = "Channel";
    public const string Platform = "Platform";
    public const string DeviceId = "DeviceId";
    public const string DeviceCompliant = "DeviceCompliant";

    public static string Of(AuthContextType type) => type.ToString();
}

/// <summary>
/// Endpoint'in gerektirdiği permission (katalogdaki iş işlemi). Deklaratif: iş kodunda yetki if'i yazılmaz.
/// Birden fazla kullanılırsa HEPSİ Permit olmalıdır. SDK manifest'i bu attribute'lardan üretilir.
/// <code>[RequiresPermission("anka.nakit.cekim.gise:create")]</code>
/// </summary>
[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
public sealed class RequiresPermissionAttribute(string permission) : Attribute
{
    public string Permission { get; } = permission;
    /// <summary>Opsiyonel kaynak tipi (ör. "account"); değer [AuthContext(AccountNo)] ile gelirse Resource = {account, TR12...}.</summary>
    public string? ResourceType { get; init; }
    /// <summary>Manifest'te permission kataloğda yoksa oluşturulacak ad.</summary>
    public string? Name { get; init; }
}

/// <summary>
/// DTO property'sinin (veya action parametresinin) yetki bağlamındaki SEMANTİK anlamı.
/// <code>[AuthContext(AuthContextType.TransactionAmount)] public decimal Tutar { get; set; }</code>
/// Domain'e özgü değer için özel anahtar: <c>[AuthContext("CreditScore")]</c>
/// </summary>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter, AllowMultiple = false)]
public sealed class AuthContextAttribute : Attribute
{
    public AuthContextAttribute(AuthContextType type) => Key = AuthContextKey.Of(type);
    public AuthContextAttribute(string customKey) => Key = customKey;

    public string Key { get; }
}

/// <summary>Bilinçli olarak yetki gerektirmeyen endpoint (health, public). Manifest'te "eşlenmemiş" bulgusu üretmez.</summary>
[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
public sealed class AllowWithoutPermissionAttribute : Attribute;
