using System.Collections;
using System.Collections.Concurrent;
using System.Globalization;
using System.Reflection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;

namespace Yetki.Sdk;

public sealed class ContextBuildResult
{
    public Dictionary<string, string?> Values { get; } = new(StringComparer.OrdinalIgnoreCase);
    public List<string> Conflicts { get; } = new();
}

/// <summary>
/// Normalize yetki bağlamını üretir:
///  - Teknik bağlam (IP, zaman, kanal, platform, cihaz) framework'ten OTOMATİK toplanır.
///  - İş bağlamı, action argümanlarında [AuthContext] ile işaretlenmiş property/parametrelerden toplanır (isim eşlemesi YOK).
///  - Aynı anahtar farklı değerlerle birden fazla yerde bulunursa çakışma raporlanır (fail-closed).
/// </summary>
public sealed class AuthorizationContextBuilder(IOptions<YetkiAuthorizationOptions> options)
{
    private static readonly ConcurrentDictionary<Type, (PropertyInfo Prop, string? Key)[]> PropertyCache = new();
    private readonly YetkiAuthorizationOptions _options = options.Value;

    public string? ResolveUserName(HttpContext http)
    {
        if (http.User.Identity?.IsAuthenticated == true && !string.IsNullOrWhiteSpace(http.User.Identity.Name)) return http.User.Identity.Name;
        return _options.AllowDemoHeaders && http.Request.Headers[_options.DemoUserHeader].ToString() is { Length: > 0 } h ? h.Trim() : null;
    }

    /// <summary>İsteği gönderen OAuth client (token'daki azp/client_id; demo'da header).</summary>
    public string? ResolveClient(HttpContext http)
    {
        foreach (var claim in _options.ClientClaims)
            if (http.User.FindFirst(claim)?.Value is { Length: > 0 } v) return v;
        return _options.AllowDemoHeaders && http.Request.Headers[_options.DemoClientHeader].ToString() is { Length: > 0 } h ? h.Trim() : null;
    }

    /// <summary>Tenant: token claim'i (tenant/tid); demo modunda X-Tenant-Id başlığı. Yoksa motor kullanıcının tenant'ını kullanır.</summary>
    public string? ResolveTenant(HttpContext http)
    {
        foreach (var claim in _options.TenantClaims)
            if (http.User.FindFirst(claim)?.Value is { Length: > 0 } v) return v;
        return _options.AllowDemoHeaders && http.Request.Headers[_options.DemoTenantHeader].ToString() is { Length: > 0 } h ? h.Trim() : null;
    }

    /// <summary>Token'ın scope/scp claim'lerinden granted scope değerlerini okur.</summary>
    public List<string> ResolveGrantedScopes(HttpContext http)
    {
        var scopes = _options.ScopeClaims.SelectMany(http.User.FindAll)
            .SelectMany(c => c.Value.Split(' ', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries))
            .Distinct(StringComparer.Ordinal).ToList();
        if (scopes.Count == 0 && _options.AllowDemoHeaders && http.Request.Headers[_options.DemoScopeHeader].ToString() is { Length: > 0 } header)
            scopes.AddRange(header.Split(' ', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries));
        return scopes.Distinct(StringComparer.Ordinal).ToList();
    }

    /// <summary>
    /// Aracı zinciri: token'daki RFC 8693 "act" claim'i (iç içe: {"client_id":"anka-gateway","act":{...}}) veya gateway'in eklediği X-Via başlığı.
    /// Orijinal client (azp) ResolveClient'tan gelir; aracılar burada. Motor her aracıyı ayrıca doğrular.
    /// </summary>
    public List<string> ResolveVia(HttpContext http)
    {
        var chain = new List<string>();
        if (http.User.FindFirst("act")?.Value is { Length: > 0 } act)
        {
            try
            {
                var node = System.Text.Json.Nodes.JsonNode.Parse(act);
                while (node is System.Text.Json.Nodes.JsonObject o)
                {
                    if ((o["client_id"] ?? o["sub"])?.ToString() is { Length: > 0 } id) chain.Add(id);
                    node = o["act"];
                }
            }
            catch (System.Text.Json.JsonException) { /* bozuk act claim'i: zincir boş kalır, motor doğrular */ }
        }
        if (chain.Count == 0 && http.Request.Headers[_options.ViaHeader].ToString() is { Length: > 0 } header)
            chain.AddRange(header.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries));
        return chain;
    }

    public ContextBuildResult Build(ActionExecutingContext context)
    {
        var result = new ContextBuildResult();
        var http = context.HttpContext;

        result.Values[AuthContextKey.CurrentTime] = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture); // bilgi; motor kendi saatini kullanır
        var ip = http.Connection.RemoteIpAddress;
        if (ip is not null) result.Values[AuthContextKey.IpAddress] = (ip.IsIPv4MappedToIPv6 ? ip.MapToIPv4() : ip).ToString();
        void Header(string header, string key)
        {
            var v = http.Request.Headers[header].ToString();
            if (!string.IsNullOrWhiteSpace(v)) result.Values[key] = v.Trim();
        }
        Header(_options.ChannelHeader, AuthContextKey.Channel);
        Header(_options.PlatformHeader, AuthContextKey.Platform);
        Header(_options.DeviceIdHeader, AuthContextKey.DeviceId);
        Header(_options.DeviceCompliantHeader, AuthContextKey.DeviceCompliant);

        if (context.ActionDescriptor is ControllerActionDescriptor action)
        {
            foreach (var p in action.MethodInfo.GetParameters())
            {
                if (p.Name is null || !context.ActionArguments.TryGetValue(p.Name, out var arg) || arg is null) continue;
                var paramAttr = p.GetCustomAttribute<AuthContextAttribute>();
                if (paramAttr is not null) Add(result, paramAttr.Key, arg, $"param:{p.Name}");
                else Scan(arg, result, 0, p.Name, new HashSet<object>(ReferenceEqualityComparer.Instance));
            }
        }
        return result;
    }

    private void Scan(object obj, ContextBuildResult result, int depth, string path, HashSet<object> visited)
    {
        if (depth >= _options.MaxContextScanDepth || IsSimple(obj.GetType()) || !visited.Add(obj)) return;
        if (obj is IEnumerable and not string) return; // koleksiyonlarda hangi elemanın kullanılacağı belirsiz
        foreach (var (prop, key) in GetProperties(obj.GetType()))
        {
            object? value;
            try { value = prop.GetValue(obj); } catch { continue; }
            if (value is null) continue;
            if (key is not null) Add(result, key, value, $"{path}.{prop.Name}");
            else if (!IsSimple(prop.PropertyType)) Scan(value, result, depth + 1, $"{path}.{prop.Name}", visited);
        }
    }

    private static void Add(ContextBuildResult result, string key, object value, string source)
    {
        var text = Format(value);
        if (text is null) return;
        if (result.Values.TryGetValue(key, out var existing) && existing is not null && !IsTechnical(key) && existing != text)
        {
            result.Conflicts.Add($"{key}: '{existing}' ve '{text}' ({source})");
            return;
        }
        result.Values[key] = text;
    }

    private static bool IsTechnical(string key) =>
        key is AuthContextKey.CurrentTime or AuthContextKey.IpAddress or AuthContextKey.Channel or AuthContextKey.Platform
            or AuthContextKey.DeviceId or AuthContextKey.DeviceCompliant;

    private static string? Format(object value) => value switch
    {
        string s => string.IsNullOrWhiteSpace(s) ? null : s.Trim(),
        DateTime d => d.ToUniversalTime().ToString("o", CultureInfo.InvariantCulture),
        DateTimeOffset d => d.UtcDateTime.ToString("o", CultureInfo.InvariantCulture),
        IFormattable f => f.ToString(null, CultureInfo.InvariantCulture),
        _ => value.ToString()
    };

    private static (PropertyInfo, string?)[] GetProperties(Type type) => PropertyCache.GetOrAdd(type, t =>
        t.GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(p => p.CanRead && p.GetIndexParameters().Length == 0)
            .Select(p => (p, p.GetCustomAttribute<AuthContextAttribute>()?.Key))
            .ToArray());

    private static bool IsSimple(Type t)
    {
        t = Nullable.GetUnderlyingType(t) ?? t;
        return t.IsPrimitive || t.IsEnum || t == typeof(string) || t == typeof(decimal) || t == typeof(DateTime)
               || t == typeof(DateTimeOffset) || t == typeof(Guid) || t == typeof(TimeSpan);
    }
}
