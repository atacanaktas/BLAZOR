using System.Text.Json.Serialization;

namespace Yetki.Sdk;

public sealed class EvaluateSubject
{
    public string? Id { get; set; }
}

public sealed class EvaluateResource
{
    public string? Type { get; set; }
    public string? Id { get; set; }
}

/// <summary>Motorun standart isteği (POST /api/v1/authorize): Subject + Permission + Resource + Context + Client.</summary>
public sealed class EvaluateRequest
{
    /// <summary>İsteğin tenant'ı (token'daki tenant claim'i). Motor kullanıcının bu tenant'a ait olduğunu doğrular.</summary>
    public string? Tenant { get; set; }
    public EvaluateSubject Subject { get; set; } = new();
    public string Permission { get; set; } = default!;
    public EvaluateResource? Resource { get; set; }
    public Dictionary<string, string?> Context { get; set; } = new();
    public string? Client { get; set; }
    /// <summary>Access token'a verilmiş OAuth 2.0 scope değerleri.</summary>
    public List<string> Scopes { get; set; } = new();
    /// <summary>Aracı zinciri (gateway / BFF / kullanıcı adına çağıran servisler), dıştan içe.</summary>
    public List<string> Via { get; set; } = new();
    public string? CorrelationId { get; set; }
}

/// <summary>Motorun karar cevabının SDK'nın ihtiyaç duyduğu kısmı.</summary>
public sealed class EvaluateResponse
{
    public Guid DecisionId { get; set; }
    /// <summary>Permit / Deny / NotApplicable / Indeterminate</summary>
    public string Decision { get; set; } = "Deny";
    /// <summary>Sadece Permit'te true. Enforcement bu alana göre yapılır.</summary>
    public bool IsAllowed { get; set; }
    public string ReasonCode { get; set; } = default!;
    public string HumanReadableReason { get; set; } = default!;
    public string? UserName { get; set; }
    public string? Client { get; set; }
    public string? Permission { get; set; }
    public string? DecidingPolicy { get; set; }
    public string? DecidingRule { get; set; }
    public List<string> FailedRules { get; set; } = new();
    public List<string> MissingAttributes { get; set; } = new();
    /// <summary>PEP'in yerine getirmesi gereken yükümlülükler (ör. MASK_FIELDS).</summary>
    public List<DecisionObligationDto> Obligations { get; set; } = new();

    [JsonIgnore]
    public bool IsSdkGenerated { get; init; }

    public static EvaluateResponse LocalDeny(string permission, string reasonCode, string reason) => new()
    {
        DecisionId = Guid.Empty, Decision = "Deny", IsAllowed = false, Permission = permission,
        ReasonCode = reasonCode, HumanReadableReason = reason, IsSdkGenerated = true
    };
}

public sealed class YetkiAuthorizationOptions
{
    /// <summary>Yetki Motoru adresi (ör. http://localhost:5100).</summary>
    public string EngineBaseUrl { get; set; } = "http://localhost:5100";

    public TimeSpan Timeout { get; set; } = TimeSpan.FromSeconds(3);

    /// <summary>Manifest: bu servisin katalogdaki uygulaması ve yolu (ör. ANKA, NAKIT/CEKIM/GISE) ve API kimliği.</summary>
    public string Application { get; set; } = "ANKA";
    public string CatalogPath { get; set; } = default!;
    public string ApiCode { get; set; } = default!;
    public string ApiName { get; set; } = default!;
    public string? Audience { get; set; }
    /// <summary>API'nin tüm endpoint'lerinin ortak mainframe bağımlılıkları (ör. CICS bölgesi APPL profili).</summary>
    public List<RequiresExternalAttribute> ApiExternalDependencies { get; set; } = new();

    /// <summary>
    /// Client kimliği token'daki bu claim'lerden okunur (OAuth: azp / client_id). Gateway kullanıcı token'ını iletirken
    /// ORİJİNAL client (ör. nextral-desktop) korunur.
    /// </summary>
    public string[] ClientClaims { get; set; } = ["azp", "client_id"];
    /// <summary>Tenant'ın okunacağı token claim'leri (sırayla).</summary>
    public string[] TenantClaims { get; set; } = ["tenant", "tid"];
    /// <summary>OAuth scope claim adları. RFC 9068 için scope, Entra uyumluluğu için scp.</summary>
    public string[] ScopeClaims { get; set; } = ["scope", "scp"];
    /// <summary>Demo: token yokken tenant başlığı.</summary>
    public string DemoTenantHeader { get; set; } = "X-Tenant-Id";
    /// <summary>Aracı zinciri başlığı (gateway ekler): "anka-gateway, kredi-service". Token'da RFC 8693 "act" claim'i varsa o önceliklidir.</summary>
    public string ViaHeader { get; set; } = "X-Via";

    /// <summary>Kanal/platform/cihaz header'ları: SADECE güvenilir gateway yazmalı (istemciden geleni ezmeli).</summary>
    public string ChannelHeader { get; set; } = "X-Channel";
    public string PlatformHeader { get; set; } = "X-Platform";
    public string DeviceIdHeader { get; set; } = "X-Device-Id";
    public string DeviceCompliantHeader { get; set; } = "X-Device-Compliant";

    /// <summary>
    /// PROTOTİP: Kimlik doğrulama yoksa kullanıcı ve client header'dan okunur. Üretimde MUTLAKA false olmalı;
    /// kimlik doğrulanmış token'dan (HttpContext.User) gelir.
    /// </summary>
    public bool AllowDemoHeaders { get; set; }
    public string DemoUserHeader { get; set; } = "X-User";
    public string DemoClientHeader { get; set; } = "X-Client-Id";
    public string DemoScopeHeader { get; set; } = "X-OAuth-Scopes";

    /// <summary>İş DTO'larında [AuthContext] aranacak maksimum iç içe derinlik.</summary>
    public int MaxContextScanDepth { get; set; } = 3;
}
