using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Yetki.Sdk;

public interface IYetkiEngineClient
{
    Task<EvaluateResponse> EvaluateAsync(EvaluateRequest request, CancellationToken ct);
}

/// <summary>Motor HTTP istemcisi. Erişilemezse / hata dönerse FAIL CLOSED (Deny).</summary>
public sealed class YetkiEngineClient(HttpClient http, ILogger<YetkiEngineClient> logger) : IYetkiEngineClient
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { Converters = { new JsonStringEnumConverter() } };

    public async Task<EvaluateResponse> EvaluateAsync(EvaluateRequest request, CancellationToken ct)
    {
        try
        {
            using var response = await http.PostAsJsonAsync("api/v1/authorize", request, Json, ct);
            if (!response.IsSuccessStatusCode)
            {
                logger.LogWarning("Yetki motoru {Status} döndü ({Permission})", (int)response.StatusCode, request.Permission);
                return EvaluateResponse.LocalDeny(request.Permission, "ENGINE_ERROR", $"Yetki motoru hata döndü: {(int)response.StatusCode}");
            }
            return await response.Content.ReadFromJsonAsync<EvaluateResponse>(Json, ct)
                   ?? EvaluateResponse.LocalDeny(request.Permission, "ENGINE_ERROR", "Yetki motoru boş cevap döndü.");
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or JsonException)
        {
            logger.LogError(ex, "Yetki motoruna erişilemedi ({Permission})", request.Permission);
            return EvaluateResponse.LocalDeny(request.Permission, "ENGINE_UNAVAILABLE", "Yetki motoruna erişilemedi; güvenli tarafta kalınarak reddedildi.");
        }
    }
}

/// <summary>
/// Global action filter (PEP): [RequiresPermission] taşıyan endpoint'lerde model binding'den SONRA, iş kodundan ÖNCE çalışır.
/// Bağlamı toplar, motoru çağırır; Permit dışındaki her sonuçta action'ı hiç çalıştırmaz (403 / 503).
/// </summary>
public sealed class YetkiAuthorizationFilter(
    IYetkiEngineClient client,
    AuthorizationContextBuilder contextBuilder,
    ILogger<YetkiAuthorizationFilter> logger) : IAsyncActionFilter, IOrderedFilter
{
    public const string DecisionItemKey = "Yetki.AuthorizationDecisions";

    public int Order => -10_000;

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var requirements = context.ActionDescriptor.EndpointMetadata.OfType<RequiresPermissionAttribute>().ToList();
        if (requirements.Count == 0)
        {
            await next();
            return;
        }

        var http = context.HttpContext;
        var userName = contextBuilder.ResolveUserName(http);
        var clientId = contextBuilder.ResolveClient(http);
        var tenant = contextBuilder.ResolveTenant(http);
        var scopes = contextBuilder.ResolveGrantedScopes(http);
        var via = contextBuilder.ResolveVia(http);
        if (userName is null && clientId is null)
        {
            context.Result = new UnauthorizedObjectResult(new ProblemDetails { Status = 401, Title = "Kimlik doğrulanmamış", Detail = "Kullanıcı veya client kimliği bulunamadı." });
            return;
        }

        var built = contextBuilder.Build(context);
        var decisions = new List<EvaluateResponse>();
        foreach (var req in requirements)
        {
            EvaluateResponse decision;
            if (built.Conflicts.Count > 0)
                decision = EvaluateResponse.LocalDeny(req.Permission, "AMBIGUOUS_CONTEXT", "Aynı bağlam anahtarı için birden fazla farklı değer: " + string.Join("; ", built.Conflicts));
            else
            {
                EvaluateResource? resource = null;
                if (req.ResourceType is not null && built.Values.TryGetValue(AuthContextKey.Of(AuthContextType.AccountNo), out var acc) && acc is not null)
                    resource = new EvaluateResource { Type = req.ResourceType, Id = acc };
                decision = await client.EvaluateAsync(new EvaluateRequest
                {
                    Tenant = tenant,
                    Via = via,
                    Subject = new EvaluateSubject { Id = userName }, Permission = req.Permission, Resource = resource,
                    Context = new Dictionary<string, string?>(built.Values), Client = clientId, Scopes = scopes, CorrelationId = http.TraceIdentifier
                }, http.RequestAborted);
            }
            // Yükümlülük: PEP yerine getiremediği yükümlülükte erişimi REDDEDER (XACML)
            if (decision.IsAllowed && ObligationEnforcer.Unsupported(decision.Obligations) is { Count: > 0 } unknown)
                decision = EvaluateResponse.LocalDeny(req.Permission, "OBLIGATION_NOT_SUPPORTED",
                    $"Bu servis şu yükümlülükleri yerine getiremiyor: {string.Join(", ", unknown)}. Güvenli tarafta kalınarak erişim reddedildi.");
            decisions.Add(decision);
            if (!decision.IsAllowed)
            {
                logger.LogInformation("Yetki reddedildi: {User}/{Client} {Permission} {Reason}", userName, clientId, req.Permission, decision.ReasonCode);
                if (decision.ReasonCode is "TOKEN_SCOPE_REQUIRED" or "INSUFFICIENT_SCOPE")
                    http.Response.Headers.WWWAuthenticate = $"Bearer error=\"insufficient_scope\", scope=\"{req.Permission}\"";
                context.Result = Deny(decision);
                http.Items[DecisionItemKey] = decisions;
                return;
            }
        }
        http.Items[DecisionItemKey] = decisions;
        var obligations = decisions.SelectMany(d => d.Obligations).ToList();
        ObligationEnforcer.Log(logger, obligations, userName, string.Join(",", requirements.Select(r => r.Permission)));

        var executed = await next();
        // Yanıt şekillendirme yükümlülükleri (maskeleme, sonuç sınırı) — action'ın ürettiği nesneye uygulanır
        if (obligations.Count > 0 && executed.Result is ObjectResult { Value: not null } result && executed.Exception is null)
        {
            var shaped = ObligationEnforcer.Apply(result.Value, obligations, ResponseJson);
            if (shaped is not null) result.Value = shaped;
            http.Response.Headers["X-Yetki-Obligations"] = string.Join(",", obligations.Select(o => o.Code).Distinct());
        }
    }

    private static readonly JsonSerializerOptions ResponseJson = new(JsonSerializerDefaults.Web);

    private static IActionResult Deny(EvaluateResponse d)
    {
        var status = d.ReasonCode is "ENGINE_UNAVAILABLE" or "ENGINE_ERROR" ? StatusCodes.Status503ServiceUnavailable : StatusCodes.Status403Forbidden;
        var problem = new ProblemDetails
        {
            Status = status,
            Title = status == 403 ? $"Yetki reddedildi ({d.Decision})" : "Yetki kontrolü yapılamadı",
            Detail = d.HumanReadableReason,
            Extensions =
            {
                ["decisionId"] = d.DecisionId, ["decision"] = d.Decision, ["permission"] = d.Permission, ["client"] = d.Client,
                ["reasonCode"] = d.ReasonCode, ["decidingPolicy"] = d.DecidingPolicy, ["decidingRule"] = d.DecidingRule,
                ["failedRules"] = d.FailedRules, ["missingAttributes"] = d.MissingAttributes
            }
        };
        return new ObjectResult(problem) { StatusCode = status };
    }
}

public sealed record ManifestExternalDto(string System, string Code, string? ResourceClass, string? Name, string? Access);

public sealed record ManifestEndpointDto(string Method, string Path, string? OperationId, string? Summary, string? Permission, string? PermissionName,
    IReadOnlyList<ManifestExternalDto> External);

public sealed record ManifestDto(string Application, string CatalogPath, object Api, IReadOnlyList<ManifestEndpointDto> Endpoints);

public static class YetkiSdkExtensions
{
    /// <summary>
    /// SDK kaydı: <c>builder.Services.AddYetkiAuthorization(o => { o.EngineBaseUrl = "..."; o.CatalogPath = "NAKIT/CEKIM/GISE"; ... });</c>
    /// Ardından controller'larda sadece [RequiresPermission] ve DTO'larda [AuthContext] kullanılır.
    /// </summary>
    public static IServiceCollection AddYetkiAuthorization(this IServiceCollection services, Action<YetkiAuthorizationOptions> configure)
    {
        services.Configure(configure);
        services.AddSingleton<AuthorizationContextBuilder>();
        services.AddHttpClient<IYetkiEngineClient, YetkiEngineClient>((sp, http) =>
        {
            var o = sp.GetRequiredService<IOptions<YetkiAuthorizationOptions>>().Value;
            http.BaseAddress = new Uri(o.EngineBaseUrl.TrimEnd('/') + "/");
            http.Timeout = o.Timeout;
        });
        services.AddScoped<YetkiAuthorizationFilter>();
        services.Configure<MvcOptions>(mvc => mvc.Filters.AddService<YetkiAuthorizationFilter>());
        return services;
    }

    /// <summary>
    /// GET /.well-known/yetki-manifest: servisin endpoint → permission eşlemesi (motor kataloğuna içe aktarılır).
    /// [RequiresPermission] taşımayan endpoint'ler Permission=null ile listelenir (denetim: eşlenmemiş endpoint).
    /// </summary>
    public static IEndpointRouteBuilder MapYetkiManifest(this IEndpointRouteBuilder app)
    {
        app.MapGet("/.well-known/yetki-manifest", (IActionDescriptorCollectionProvider actions, IOptions<YetkiAuthorizationOptions> options) =>
        {
            var o = options.Value;
            var endpoints = actions.ActionDescriptors.Items.OfType<ControllerActionDescriptor>()
                .Where(a => a.EndpointMetadata.OfType<AllowWithoutPermissionAttribute>().Any() == false)
                .SelectMany(a =>
                {
                    var methods = a.EndpointMetadata.OfType<HttpMethodMetadata>().FirstOrDefault()?.HttpMethods ?? ["GET"];
                    var path = "/" + (a.AttributeRouteInfo?.Template ?? "").Trim('/');
                    var perms = a.EndpointMetadata.OfType<RequiresPermissionAttribute>().ToList();
                    var external = a.EndpointMetadata.OfType<RequiresExternalAttribute>()
                        .Select(x => new ManifestExternalDto(x.System, x.Code, x.ResourceClass, x.Name, x.Access == 0 ? null : x.Access.ToString())).ToList();
                    return methods.Select(m => new ManifestEndpointDto(m, path, a.ActionName, $"{a.ControllerName}.{a.ActionName}",
                        perms.FirstOrDefault()?.Permission, perms.FirstOrDefault()?.Name, external));
                })
                .OrderBy(e => e.Path).ThenBy(e => e.Method).ToList();
            return Results.Ok(new ManifestDto(o.Application, o.CatalogPath,
                new
                {
                    code = o.ApiCode, name = o.ApiName, audience = o.Audience, version = "v1",
                    external = o.ApiExternalDependencies.Select(x => new ManifestExternalDto(x.System, x.Code, x.ResourceClass, x.Name, x.Access == 0 ? null : x.Access.ToString()))
                }, endpoints));
        }).ExcludeFromDescription();
        return app;
    }

    /// <summary>İş kodunda (loglama vb. için) bu isteğe ait yetki kararları.</summary>
    public static IReadOnlyList<EvaluateResponse> GetAuthorizationDecisions(this HttpContext http) =>
        http.Items.TryGetValue(YetkiAuthorizationFilter.DecisionItemKey, out var v) && v is List<EvaluateResponse> list ? list : [];
}
