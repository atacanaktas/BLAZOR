using Microsoft.AspNetCore.Mvc;
using Yetki.Application.Abstractions;
using Yetki.Application.Model;

namespace Yetki.Api.Controllers;

// Bounded read model for the management canvas. Not an authorization decision.
[ApiController]
[Route("api/structure/flow")]
public sealed class StructureFlowController(AuthorizationModelProvider models, IClock clock) : ControllerBase
{
    public sealed record Entry(string Kind, int Id, string Code, string Name, int TenantId);
    [HttpGet("search")]
    public async Task<object> Search(string kind = "user", string? q = null, int page = 1, CancellationToken ct = default)
    {
        var m = await models.GetCurrentAsync(ct);
        IEnumerable<Entry> rows = kind switch
        {
            "user" => m.Users.Values.Select(x => new Entry(kind, x.Id, x.UserName, x.FullName, x.TenantId)),
            "role" => m.Roles.Values.Select(x => new Entry(kind, x.Id, x.Code, x.Name, x.TenantId)),
            "permission" => m.Permissions.Values.Select(x => new Entry(kind, x.Id, x.Code, x.Row.Name, x.TenantId)),
            "policy" => m.Policies.Values.Select(x => new Entry(kind, x.Row.Id, x.Row.Code, x.Row.Name, x.Row.TenantId)),
            _ => throw new ValidationException("Unsupported search kind.")
        };
        var filtered = rows.Where(x => string.IsNullOrWhiteSpace(q) || x.Code.Contains(q.Trim(), StringComparison.OrdinalIgnoreCase) || x.Name.Contains(q.Trim(), StringComparison.OrdinalIgnoreCase)).OrderBy(x => x.Code).ThenBy(x => x.Id).ToList();
        page = Math.Clamp(page, 1, Math.Max(1, (filtered.Count + 11) / 12));
        return new { total = filtered.Count, page, items = filtered.Skip((page - 1) * 12).Take(12) };
    }

    [HttpGet("{kind}/{id:int}")]
    public async Task<object> Flow(string kind, int id, string? q = null, int page = 1, string relation = "permissions", CancellationToken ct = default)
    {
        var m = await models.GetCurrentAsync(ct);
        EffectivePermissionSet? effective = null;
        IEnumerable<int> ids;
        Entry subject;
        if (kind == "user" && m.Users.TryGetValue(id, out var user))
        {
            effective = m.GetEffective(id, clock.UtcNow);
            subject = new(kind, id, user.UserName, user.FullName, user.TenantId);
            ids = effective.Permissions.Select(x => x.PermissionId);
        }
        else if (kind == "role" && m.Roles.TryGetValue(id, out var role))
        {
            subject = new(kind, id, role.Code, role.Name, role.TenantId);
            ids = m.RolePermissionIds(id);
        }
        else if (kind == "group" && m.Groups.TryGetValue(id, out var group))
        {
            subject = new(kind, id, group.Code, group.Name, group.TenantId);
            ids = m.GroupPermissionIds(id).Concat(m.GroupRoleIds(id).SelectMany(m.RolePermissionIds));
        }
        else if (kind == "permission" && m.Permissions.TryGetValue(id, out var permission))
        {
            subject = new(kind, id, permission.Code, permission.Row.Name, permission.TenantId);
            ids = [id];
        }
        else throw new NotFoundException(kind, id);
        bool Matches(string code, string name) => string.IsNullOrWhiteSpace(q) || code.Contains(q.Trim(), StringComparison.OrdinalIgnoreCase) || name.Contains(q.Trim(), StringComparison.OrdinalIgnoreCase);
        if (relation == "roles" && effective is not null)
        {
            var roles = effective.Roles.Where(x => Matches(x.Code, x.Name)).OrderBy(x => x.Code).ToList();
            page = Math.Clamp(page, 1, Math.Max(1, (roles.Count + 11) / 12));
            return new { subject, total = roles.Count, page, items = roles.Skip((page - 1) * 12).Take(12).Select(x => new { kind = "role", id = x.RoleId, x.Code, x.Name, tenantId = subject.TenantId, sources = x.Sources.Take(4), sourceCount = x.Sources.Count }) };
        }
        if (relation == "groups" && effective is not null)
        {
            var groups = effective.Groups.Where(x => Matches(x.Code, x.Name)).OrderBy(x => x.Code).ToList();
            page = Math.Clamp(page, 1, Math.Max(1, (groups.Count + 11) / 12));
            return new { subject, total = groups.Count, page, items = groups.Skip((page - 1) * 12).Take(12).Select(x => new { kind = "group", id = x.GroupId, x.Code, x.Name, tenantId = subject.TenantId }) };
        }
        if (relation != "permissions") throw new ValidationException("Unsupported relation.");
        var permissions = ids.Distinct().Where(m.Permissions.ContainsKey).Select(x => m.Permissions[x]).Where(x => Matches(x.Code, x.Row.Name) || (!string.IsNullOrWhiteSpace(q) && x.Path.Contains(q.Trim(), StringComparison.OrdinalIgnoreCase))).OrderBy(x => x.Code).ToList();
        page = Math.Clamp(page, 1, Math.Max(1, (permissions.Count + 3) / 4));
        return new
        {
            subject, total = permissions.Count, page, roleCount = effective?.Roles.Count, groupCount = effective?.Groups.Count,
            active = effective?.IsActive ?? (kind == "role" ? m.Roles[id].IsActive : kind == "group" ? m.Groups[id].IsActive : true),
            items = permissions.Skip((page - 1) * 4).Take(4).Select(x => new
            {
                permission = new Entry("permission", x.Id, x.Code, x.Row.Name, subject.TenantId),
                resource = new { id = x.Node?.Id, name = x.Node?.Name ?? x.Path, path = x.Path, application = x.App?.Code, action = x.Row.Action },
                sources = effective?.Find(x.Id)?.Sources.Take(4).Select(s => s.Path).ToArray() ?? (kind == "role" ? new[] { subject.Code } : Array.Empty<string>()),
                sourceCount = effective?.Find(x.Id)?.Sources.Count ?? (kind == "role" ? 1 : 0)
            })
        };
    }
}
