using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine;

namespace Yetki.Api.Controllers;

/// <summary>Karar noktası (PDP): tekil / toplu karar ve login-time yetki listesi (entitlements).</summary>
[ApiController]
[Route("api/v1")]
public sealed class AuthorizationController(AuthorizationEvaluator evaluator, EntitlementService entitlements) : ControllerBase
{
    /// <summary>Tekil karar: Subject + (Permission | Endpoint) + Resource + Context + Client.</summary>
    [HttpPost("authorize")]
    public Task<AuthorizationDecision> Authorize(AuthorizationRequest request, CancellationToken ct)
    {
        request.Client ??= Request.Headers["X-Client-Id"].FirstOrDefault();
        if (request.Scopes.Count == 0) request.Scopes = GrantedScopes(User);
        // Aracı zinciri gövdede yoksa başlıktan (gateway ekler): X-Via: anka-gateway, kredi-service
        if (request.Via.Count == 0 && Request.Headers["X-Via"].ToString() is { Length: > 0 } via)
            request.Via = via.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).ToList();
        return evaluator.EvaluateAsync(request, null, ct);
    }

    /// <summary>Toplu karar (ör. bir ekrandaki tüm işlemler). Her biri bağımsız değerlendirilir ve audit'lenir.</summary>
    [HttpPost("authorize/batch")]
    public async Task<IReadOnlyList<AuthorizationDecision>> AuthorizeBatch(List<AuthorizationRequest> requests, CancellationToken ct)
    {
        if (requests.Count > 100) throw new Application.Abstractions.ValidationException("Tek seferde en fazla 100 istek.");
        var result = new List<AuthorizationDecision>();
        foreach (var r in requests)
        {
            if (r.Scopes.Count == 0) r.Scopes = GrantedScopes(User);
            result.Add(await evaluator.EvaluateAsync(r, null, ct));
        }
        return result;
    }

    /// <summary>
    /// Login-time yetki listesi (Nextral gibi istemciler buton/menü açıp kapamak için). ETag desteklidir:
    /// If-None-Match eşleşirse 304 döner (yetki modeli değişmediyse istemci önbelleğini kullanır).
    /// </summary>
    [HttpGet("entitlements/{user}")]
    public async Task<IActionResult> Entitlements(string user, [FromQuery] string? client, [FromQuery] string? application,
        [FromQuery] bool evaluate = false, [FromQuery] string? ip = null, [FromQuery] string? scope = null, CancellationToken ct = default)
    {
        var grantedScopes = GrantedScopes(User);
        if (grantedScopes.Count == 0) grantedScopes = ParseScopes(scope);
        var result = await entitlements.GetAsync(new EntitlementRequest
        {
            User = user, Client = client ?? Request.Headers["X-Client-Id"].FirstOrDefault(), Application = application, Evaluate = evaluate,
            Scopes = grantedScopes,
            Context = ip is null ? new() : new() { ["IpAddress"] = ip }
        }, ct);
        if (!evaluate && Request.Headers.IfNoneMatch.ToString() == result.ETag) return StatusCode(StatusCodes.Status304NotModified);
        Response.Headers.ETag = result.ETag;
        return Ok(result);
    }

    [HttpPost("entitlements")]
    public Task<EntitlementResult> EntitlementsPost(EntitlementRequest request, CancellationToken ct)
    {
        if (request.Scopes.Count == 0) request.Scopes = GrantedScopes(User);
        return entitlements.GetAsync(request, ct);
    }

    private static List<string> GrantedScopes(System.Security.Claims.ClaimsPrincipal principal) =>
        principal.FindAll("scope").Concat(principal.FindAll("scp"))
            .SelectMany(c => c.Value.Split(' ', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries))
            .Distinct(StringComparer.Ordinal).ToList();

    private static List<string> ParseScopes(string? value) => (value ?? "")
        .Split(' ', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
        .Distinct(StringComparer.Ordinal).ToList();
}

// ================================ OpenID AuthZEN (Authorization API 1.0) ================================

public sealed class AzEntity
{
    public string Type { get; set; } = default!;
    /// <summary>Kaydın id'si. Resource tipi düzeyinde kontrolde (ör. "bu ekranı açabilir mi?") boş olabilir.</summary>
    public string? Id { get; set; }
    public Dictionary<string, JsonElement>? Properties { get; set; }
}

public sealed class AzAction
{
    public string Name { get; set; } = default!;
    public Dictionary<string, JsonElement>? Properties { get; set; }
}

public class AzEvaluationRequest
{
    public AzEntity? Subject { get; set; }
    public AzAction? Action { get; set; }
    public AzEntity? Resource { get; set; }
    public Dictionary<string, JsonElement>? Context { get; set; }
}

public sealed class AzEvaluationsOptions
{
    /// <summary>execute_all | deny_on_first_deny | permit_on_first_permit</summary>
    [System.Text.Json.Serialization.JsonPropertyName("evaluations_semantic")]
    public string? EvaluationsSemantic { get; set; }
}

public sealed class AzEvaluationsRequest : AzEvaluationRequest
{
    public List<AzEvaluationRequest> Evaluations { get; set; } = new();
    public AzEvaluationsOptions? Options { get; set; }
}

public sealed record AzDecision(bool Decision, Dictionary<string, object?> Context);

/// <summary>
/// OpenID AuthZEN Authorization API uyumlu uç noktalar (sektör standardı PEP ↔ PDP sözleşmesi).
///   subject {type:"user", id:"ayse.yilmaz", properties:{tenant:"ABANK"}}
///   resource {type:"ANKA/NAKIT/CEKIM/GISE", id:"TR12...", properties:{Tenant, BranchCode...}} · action {name:"create"} · context {}
///   (Eski biçim: action.name = permission kodu "anka.nakit.cekim.gise:create".) Tenant: subject.properties.tenant veya context.tenant.
///   Endpoint bazlı: resource {type:"api_endpoint", id:"api://anka/nakit-cekim-gise-api", properties:{path:"/v1/..."}}, action.name = HTTP metodu.
///   Client: context.client_id veya X-Client-Id header'ı. Servis: subject.type = "client".
/// </summary>
[ApiController]
public sealed class AuthZenController(AuthorizationEvaluator evaluator) : ControllerBase
{
    [HttpGet("/.well-known/authzen-configuration")]
    public object Configuration()
    {
        var baseUrl = $"{Request.Scheme}://{Request.Host}";
        return new Dictionary<string, string>
        {
            ["policy_decision_point"] = baseUrl,
            ["access_evaluation_endpoint"] = $"{baseUrl}/access/v1/evaluation",
            ["access_evaluations_endpoint"] = $"{baseUrl}/access/v1/evaluations"
        };
    }

    [HttpPost("/access/v1/evaluation")]
    public async Task<AzDecision> Evaluation(AzEvaluationRequest request, CancellationToken ct) =>
        ToResponse(await evaluator.EvaluateAsync(Map(request, null), null, ct));

    [HttpPost("/access/v1/evaluations")]
    public async Task<object> Evaluations(AzEvaluationsRequest request, CancellationToken ct)
    {
        var semantic = request.Options?.EvaluationsSemantic ?? "execute_all";
        var results = new List<AzDecision>();
        var items = request.Evaluations.Count == 0 ? [request] : request.Evaluations;
        foreach (var item in items)
        {
            var d = ToResponse(await evaluator.EvaluateAsync(Map(item, request), null, ct));
            results.Add(d);
            if (semantic == "deny_on_first_deny" && !d.Decision) break;
            if (semantic == "permit_on_first_permit" && d.Decision) break;
        }
        return new { evaluations = results };
    }

    private AuthorizationRequest Map(AzEvaluationRequest r, AzEvaluationRequest? defaults)
    {
        var subject = r.Subject ?? defaults?.Subject;
        var action = r.Action ?? defaults?.Action;
        var resource = r.Resource ?? defaults?.Resource;
        var context = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
        foreach (var src in new[] { defaults?.Context, r.Context, resource?.Properties })
            if (src is not null)
                foreach (var (k, v) in src) context[k] = Str(v);

        var client = context.TryGetValue("client_id", out var cid) ? cid : Request.Headers["X-Client-Id"].FirstOrDefault();
        context.Remove("client_id");
        var scopesText = context.TryGetValue("scope", out var scope) ? scope : null;
        context.Remove("scope");
        // Aracı zinciri: context.via ("anka-gateway,kredi-service") veya X-Via başlığı
        var viaText = context.TryGetValue("via", out var viaValue) ? viaValue : Request.Headers["X-Via"].FirstOrDefault();
        context.Remove("via");
        if (subject is { Type: "client" or "service" }) client ??= subject.Id;
        var tenant = subject?.Properties is { } sp && sp.TryGetValue("tenant", out var st) ? Str(st)
            : context.TryGetValue("tenant", out var ct) && !(resource?.Properties?.ContainsKey("tenant") ?? false) ? ct : null;

        var request = new AuthorizationRequest
        {
            Tenant = tenant,
            Via = (viaText ?? "").Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).ToList(),
            Subject = new SubjectInfo { Id = subject is { Type: "user" } ? subject.Id : null },
            Client = client,
            Scopes = (scopesText ?? "").Split(' ', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).ToList(),
            Context = context,
            Resource = resource is null || resource.Type == "api_endpoint" ? null : new ResourceInfo { Type = resource.Type, Id = resource.Id }
        };
        if (resource is { Type: "api_endpoint" })
        {
            context.Remove("path");
            request.Endpoint = new EndpointInfo
            {
                Api = resource.Id ?? throw new Application.Abstractions.ValidationException("api_endpoint için resource.id (API kodu veya audience) zorunlu."), Method = action?.Name ?? "GET",
                Path = resource.Properties is not null && resource.Properties.TryGetValue("path", out var p) ? Str(p) ?? "/" : "/"
            };
        }
        else if (action?.Name is { } name && name.Contains(':')) request.Permission = name;   // eski biçim: permission kodu
        else request.Action = action?.Name;                                                 // resource.type + action.name
        return request;
    }

    private static AzDecision ToResponse(AuthorizationDecision d) => new(d.IsAllowed, new Dictionary<string, object?>
    {
        ["id"] = d.DecisionId,
        ["decision_type"] = d.Decision.ToString(),
        ["reason_code"] = d.ReasonCode,
        ["reason_admin"] = new Dictionary<string, string> { ["tr"] = d.HumanReadableReason },
        ["reason_user"] = new Dictionary<string, string>
        {
            ["tr"] = d.IsAllowed ? "İzin verildi." : d.Decision == DecisionType.Indeterminate ? "Yetki kontrolü tamamlanamadı; işlem yapılamaz." : "Bu işlem için yetkiniz yok."
        },
        ["deciding_policy"] = d.DecidingPolicy,
        ["deciding_rule"] = d.DecidingRule,
        ["via"] = d.Via.Count > 0 ? d.Via : null,
        // PEP bunları yerine getirmek ZORUNDA; getiremiyorsa erişimi reddetmeli
        ["obligations"] = d.Obligations.Count > 0 ? d.Obligations.Select(o => new { id = o.Code, policy = o.Policy, parameters = o.Parameters }) : null
    });

    private static string? Str(JsonElement e) => e.ValueKind switch
    {
        JsonValueKind.String => e.GetString(),
        JsonValueKind.Number => e.GetRawText(),
        JsonValueKind.True => "true",
        JsonValueKind.False => "false",
        JsonValueKind.Null or JsonValueKind.Undefined => null,
        _ => e.GetRawText()
    };
}
