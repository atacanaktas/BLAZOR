using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Yetki.Application.Definitions;

namespace Yetki.Api.Controllers;

public sealed class RenameStructureNodeRequest
{
    [Required, StringLength(200)]
    public string Name { get; set; } = "";
}
public sealed record StructurePermissionRequest(int? PermissionId);

[ApiController]
[Route("api/structure")]
public sealed class StructureController(StructureService service, StructureExplorer explorer) : ControllerBase
{
    [HttpPut("{kind}/{id:int}/permission")]
    public async Task<IActionResult> MapPermission(string kind, int id, StructurePermissionRequest request, CancellationToken ct)
    {
        await service.MapPermissionAsync(kind, id, request.PermissionId, ct);
        return NoContent();
    }

    [HttpGet("explore")]
    public Task<ExplorerPage> Explore(string kind = "root", int id = 0, int? tenantId = null,
        string? relation = null, string? q = null, int page = 1, int pageSize = 12, CancellationToken ct = default) =>
        explorer.BrowseAsync(kind, id, tenantId, relation, q, page, pageSize, ct);

    [HttpPut("{kind}/{id:int}/name")]
    public async Task<IActionResult> Rename(string kind, int id, RenameStructureNodeRequest request, CancellationToken ct)
    {
        await service.RenameAsync(kind, id, request.Name, ct);
        return NoContent();
    }
}
