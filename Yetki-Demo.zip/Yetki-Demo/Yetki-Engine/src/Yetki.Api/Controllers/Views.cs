using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Domain.Common;

namespace Yetki.Api.Controllers;

/// <summary>Condition ağacının UI gösterimi. Reference düğümünün Children'ı çözülmüş ortak koşul köküdür (What-If parametre değişikliği için id'li).</summary>
public sealed record ConditionView(int Id, ConditionKind Kind, string? ConditionType, IReadOnlyDictionary<string, string> Parameters,
    IReadOnlyList<ConditionView> Children, string? SharedCondition, int? SharedConditionVersion);

public sealed record TargetView(int Id, InclusionMode Mode, TargetType TargetType, int? TargetId, string Description, string? Actions = null);

public static class Views
{
    public static ConditionView? Condition(ConditionNode? n) => n is null ? null : new ConditionView(
        n.Id, n.Kind, n.ConditionTypeCode, n.Parameters, n.Children.Select(c => Condition(c)!).ToList(), n.ReferenceCode, n.ReferenceVersion);

    public static int? TargetId(TargetRef t) => t.Type switch
    {
        TargetType.Application => t.ApplicationId,
        TargetType.CatalogNode => t.CatalogNodeId,
        TargetType.Permission => t.PermissionId,
        _ => null
    };

    public static TargetView Target(AuthorizationModel m, int id, InclusionMode mode, TargetRef t, string? actions = null) =>
        new(id, mode, t.Type, TargetId(t), m.Describe(t), actions);

    /// <summary>Hedef bir katalog düğümünü (kendisi veya üstleri üzerinden) kapsıyor mu?</summary>
    public static bool CoversNode(AuthorizationModel m, TargetRef t, NodeRow node, IReadOnlyList<int> chain) => t.Type switch
    {
        TargetType.All => true,
        TargetType.Application => t.ApplicationId == node.ApplicationId,
        TargetType.CatalogNode => t.CatalogNodeId is { } id && chain.Contains(id),
        _ => false
    };

    public static List<int> NodeChain(AuthorizationModel m, int nodeId)
    {
        var list = new List<int>();
        int? cur = nodeId;
        while (cur is { } c && !list.Contains(c) && m.Nodes.TryGetValue(c, out var n)) { list.Add(c); cur = n.ParentId; }
        return list;
    }
}
