using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Definitions;
using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Domain.Common;

namespace Yetki.Api.Controllers;

[ApiController]
[Route("api/policies")]
public sealed class PoliciesController(AuthorizationModelProvider models, PolicyManagementService service, IYetkiDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<object> List(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.Policies.Values.OrderBy(p => p.Row.TenantId).ThenBy(p => p.Row.Code, StringComparer.Ordinal).Select(p => new
        {
            p.Row.Id, p.Row.Code, p.Row.Name, p.Row.Mode, p.Row.IsActive, p.Row.Algorithm, p.Row.Version, tenant = p.TenantCode,
            includes = p.Includes.Select(t => DescribeTarget(m, t)).ToList(),
            excludes = p.Excludes.Select(t => DescribeTarget(m, t)).ToList(),
            clients = p.IncludeClients.Select(c => m.ClientCodeOf(c.ClientId)).ToList(),
            excludedClients = p.ExcludeClients.Select(c => m.ClientCodeOf(c.ClientId)).ToList(),
            obligations = p.Obligations.Select(o => o.Code).ToList(),
            rules = p.Definition.Rules.OrderBy(r => r.Order).Select(r => new { r.Code, r.Name, r.ReasonCode, r.IsActive, expression = PolicyEvaluator.Render(r.Condition) }).ToList(),
            coverage = Coverage(m, p).Count
        }).ToList();
    }

    [HttpGet("{id:int}")]
    public async Task<object> Detail(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Policies.TryGetValue(id, out var p)) throw new NotFoundException("Policy", id);
        var meta = await db.Policies.AsNoTracking().Where(x => x.Id == id).Select(x => new { x.Description, x.UpdatedAt, x.UpdatedBy }).FirstAsync(ct);
        var ruleMeta = await db.Rules.AsNoTracking().Where(r => r.PolicyId == id).ToDictionaryAsync(r => r.Id, r => r.Description, ct);
        var coverage = Coverage(m, p);
        return new
        {
            policy = new
            {
                p.Row.Id, p.Row.Code, p.Row.Name, meta.Description, p.Row.Mode, p.Row.IsActive, p.Row.Algorithm, p.Row.Version,
                p.Row.TenantId, tenant = p.TenantCode, meta.UpdatedAt, meta.UpdatedBy,
                appliesToTenants = m.Tenants.Values.Where(o => m.TenantAncestors[o.Id].Contains(p.Row.TenantId)).Select(o => o.Code).ToList()
            },
            targets = p.Includes.Select(t => Views.Target(m, t.Id, t.Mode, t.Target, t.Actions)).Concat(p.Excludes.Select(t => Views.Target(m, t.Id, t.Mode, t.Target, t.Actions))).ToList(),
            clientTargets = p.IncludeClients.Concat(p.ExcludeClients).Select(c => new
            {
                c.Id, c.Mode, c.ClientId, client = m.ClientCodeOf(c.ClientId),
                name = m.ClientsById.Values.FirstOrDefault(x => x.Id == c.ClientId)?.Name
            }).ToList(),
            obligations = p.Obligations.Select(o => new { o.Id, o.Code, o.FulfillOn, o.Order, parameters = o.Params }).ToList(),
            rules = p.Definition.Rules.OrderBy(r => r.Order).ThenBy(r => r.Code).Select(r => new
            {
                id = r.RuleId, r.Code, r.Name, description = ruleMeta.GetValueOrDefault(r.RuleId), r.Order, r.ReasonCode, r.IsActive,
                expression = PolicyEvaluator.Render(r.Condition), condition = Views.Condition(r.Condition)
            }).ToList(),
            coverage = new
            {
                count = coverage.Count,
                byApplication = coverage.GroupBy(x => x.App?.Code ?? m.TenantCode(x.TenantId)).Select(g => new { application = g.Key, count = g.Count() }).ToList(),
                sample = coverage.Take(200).Select(x => new { x.Id, x.Code, x.Row.Name, x.Path }).ToList()
            }
        };
    }

    /// <summary>Policy'nin (kurum ayrımı olmadan) uygulandığı permission'lar.</summary>
    private static List<PermInfo> Coverage(AuthorizationModel m, CompiledPolicy p) =>
        m.Permissions.Values.Where(perm => p.Includes.Any(t => m.Matches(t, perm)) && !p.Excludes.Any(t => m.Matches(t, perm)))
            .OrderBy(x => x.Code, StringComparer.Ordinal).ToList();

    private static string DescribeTarget(AuthorizationModel m, PolicyTargetRow target) =>
        m.Describe(target.Target) + (string.IsNullOrWhiteSpace(target.Actions) ? "" : $" · Action: {target.Actions}");

    [HttpPost]
    public async Task<object> Create(PolicyUpsert dto, CancellationToken ct) => new { (await service.CreatePolicyAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task Update(int id, PolicyUpsert dto, CancellationToken ct) => service.UpdatePolicyAsync(id, dto, ct);

    [HttpPost("{id:int}/targets")]
    public async Task<object> AddTarget(int id, TargetUpsert dto, CancellationToken ct) => new { (await service.AddTargetAsync(id, dto, ct)).Id };

    [HttpDelete("/api/policy-targets/{targetId:int}")]
    public Task RemoveTarget(int targetId, CancellationToken ct) => service.RemoveTargetAsync(targetId, ct);

    /// <summary>Kanal hedefi: Include = policy sadece bu client'tan gelen isteklere; Exclude = bu client hariç.</summary>
    [HttpPost("{id:int}/clients")]
    public async Task<object> AddClientTarget(int id, ClientTargetUpsert dto, CancellationToken ct) => new { (await service.AddClientTargetAsync(id, dto, ct)).Id };

    [HttpDelete("/api/policy-clients/{targetId:int}")]
    public Task RemoveClientTarget(int targetId, CancellationToken ct) => service.RemoveClientTargetAsync(targetId, ct);

    [HttpPost("{id:int}/obligations")]
    public async Task<object> AddObligation(int id, ObligationUpsert dto, CancellationToken ct) => new { (await service.AddObligationAsync(id, dto, ct)).Id };

    [HttpDelete("/api/policy-obligations/{obligationId:int}")]
    public Task RemoveObligation(int obligationId, CancellationToken ct) => service.RemoveObligationAsync(obligationId, ct);

    /// <summary>Yükümlülük tipleri (koddaki katalog; PEP bunları yerine getirir).</summary>
    [HttpGet("/api/obligation-types")]
    public IReadOnlyList<ObligationTypeDef> ObligationTypes() => Application.PolicyEngine.ObligationTypes.All;

    [HttpPost("{id:int}/rules")]
    public async Task<object> CreateRule(int id, RuleUpsert dto, CancellationToken ct) => new { (await service.CreateRuleAsync(id, dto, ct)).Id };

    [HttpPut("/api/rules/{ruleId:int}")]
    public Task UpdateRule(int ruleId, RuleUpsert dto, CancellationToken ct) => service.UpdateRuleAsync(ruleId, dto, ct);

    [HttpDelete("/api/rules/{ruleId:int}")]
    public Task DeleteRule(int ruleId, CancellationToken ct) => service.DeleteRuleAsync(ruleId, ct);

    [HttpGet("/api/rules")]
    public async Task<object> AllRules(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.Policies.Values.SelectMany(p => p.Definition.Rules.Select(r => new
        {
            id = r.RuleId, policyId = p.Row.Id, policy = p.Row.Code, r.Code, r.Name, r.Order, r.ReasonCode, r.IsActive,
            expression = PolicyEvaluator.Render(r.Condition), condition = Views.Condition(r.Condition)
        })).OrderBy(r => r.policy).ThenBy(r => r.Order).ToList();
    }

    [HttpGet("/api/condition-types")]
    public async Task<object> ConditionTypes(CancellationToken ct) =>
        await db.ConditionTypes.AsNoTracking().OrderBy(t => t.Code)
            .Select(t => new { t.Id, t.Code, t.Name, t.Description, t.DefaultScope, t.ParameterSchemaJson, t.RequiredAttributes, t.IsAvailable, t.IsSubjectOnly })
            .ToListAsync(ct);
}

[ApiController]
[Route("api/shared-conditions")]
public sealed class SharedConditionsController(AuthorizationModelProvider models, SharedConditionService service, IYetkiDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<object> List(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var resolver = new ConditionTreeResolver(m.Data.Conditions, m.Data.SharedConditions, null);
        var rows = await db.SharedConditions.AsNoTracking().OrderBy(s => s.Code).ToListAsync(ct);
        var result = new List<object>();
        foreach (var s in rows)
        {
            var usages = await service.UsagesAsync(s.Id, ct);
            result.Add(new
            {
                s.Id, s.Code, s.Name, s.Description, s.Scope, s.Domain, s.IsActive, s.Version,
                expression = PolicyEvaluator.Render(resolver.SharedRoot(s.Id)),
                usageCount = usages.Count, policies = usages.Select(u => u.Policy).Distinct().ToList()
            });
        }
        return result;
    }

    [HttpGet("{id:int}")]
    public async Task<object> Detail(int id, CancellationToken ct)
    {
        var s = await db.SharedConditions.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Ortak koşul", id);
        var m = await models.GetCurrentAsync(ct);
        var root = new ConditionTreeResolver(m.Data.Conditions, m.Data.SharedConditions, null).SharedRoot(id);
        return new
        {
            sharedCondition = new { s.Id, s.Code, s.Name, s.Description, s.Scope, s.Domain, s.IsActive, s.Version },
            expression = PolicyEvaluator.Render(root), expandedExpression = PolicyEvaluator.Render(root, expand: true),
            condition = Views.Condition(root), usages = await service.UsagesAsync(id, ct)
        };
    }

    [HttpPost]
    public async Task<object> Create(SharedConditionUpsert dto, CancellationToken ct) => new { (await service.CreateAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task Update(int id, SharedConditionUpsert dto, CancellationToken ct) => service.UpdateAsync(id, dto, ct);

    [HttpDelete("{id:int}")]
    public Task Delete(int id, CancellationToken ct) => service.DeleteAsync(id, ct);
}
