using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Definitions;
using Yetki.Application.Model;
using Yetki.Domain.Common;

namespace Yetki.Api.Controllers;

[ApiController]
[Route("api/catalog")]
public sealed class CatalogController(AuthorizationModelProvider models, CatalogService catalog, IYetkiDbContext db) : ControllerBase
{
    /// <summary>
    /// Uygulama → Domain → Modül → Alt modül → API → Endpoint ağacı (sayılarla). Büyük katalogda UI bu ağaçla gezinir.
    /// Alt modülün API'leri ve endpoint'leri (eşlendiği permission ile) <c>apiList</c> içinde gelir.
    /// </summary>
    [HttpGet("tree")]
    public async Task<object> Tree(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var ext = await Application.External.ExternalRequirementCatalog.LoadAsync(db, ct);
        var extByApi = ext.Dependencies.Where(d => d.ApiId != null).ToLookup(d => d.ApiId!.Value, d => ext.Target(d.ExternalPermissionId).Key);
        var extByEndpoint = ext.Dependencies.Where(d => d.EndpointId != null).ToLookup(d => d.EndpointId!.Value, d => ext.Target(d.ExternalPermissionId).Key);
        var endpointMeta = await db.ApiEndpoints.AsNoTracking().Select(e => new { e.Id, e.OperationId, e.Summary }).ToDictionaryAsync(e => e.Id, ct);
        var permsByNode = m.Permissions.Values.Where(p => p.Node is not null).ToLookup(p => p.Node!.Id);
        var apisByNode = m.Apis.Values.ToLookup(a => a.CatalogNodeId);
        var uiByNode = m.Data.UiElements.ToLookup(u => u.CatalogNodeId);
        var children = m.Nodes.Values.ToLookup(n => n.ParentId);

        object ApiView(ApiRow a) => new
        {
            a.Id, a.Code, a.Name, a.Audience, a.IsActive, external = extByApi[a.Id].ToList(),
            endpoints = m.EndpointsOf(a.Id).OrderBy(e => e.Path, StringComparer.Ordinal).ThenBy(e => e.Method).Select(e => new
            {
                e.Id, e.Method, e.Path, e.PermissionId,
                operationId = endpointMeta.GetValueOrDefault(e.Id)?.OperationId,
                summary = endpointMeta.GetValueOrDefault(e.Id)?.Summary,
                permission = e.PermissionId is { } pid && m.Permissions.TryGetValue(pid, out var p) ? p.Code : null,
                external = extByEndpoint[e.Id].ToList()
            }).ToList()
        };

        object NodeView(NodeRow n) => new
        {
            n.Id, n.TenantId, n.ApplicationId, n.Code, n.Name, n.Type, n.Path,
            permissions = permsByNode[n.Id].Count(), apis = apisByNode[n.Id].Count(), uiElements = uiByNode[n.Id].Count(),
            children = children[n.Id].OrderBy(c => c.Code, StringComparer.Ordinal).Select(NodeView).ToList(),
            apiList = apisByNode[n.Id].OrderBy(a => a.Code, StringComparer.Ordinal).Select(ApiView).ToList()
        };

        var roots = m.Apps.Values.OrderBy(a => a.Id).Select(a => (object)new
        {
            a.Id, a.Code, a.Name, a.Type, a.IsActive, a.TenantId, tenant = m.TenantCode(a.TenantId),
            isTenantRoot = false,
            permissionCount = m.Permissions.Values.Count(p => p.App?.Id == a.Id),
            apiCount = m.Apis.Values.Count(x => x.ApplicationId == a.Id),
            endpointCount = m.Data.Endpoints.Count(e => m.Apis.TryGetValue(e.ApiId, out var api) && api.ApplicationId == a.Id),
            children = children[null].Where(n => n.ApplicationId == a.Id).OrderBy(c => c.Code, StringComparer.Ordinal).Select(NodeView).ToList(),
            apiList = m.Apis.Values.Where(x => x.ApplicationId == a.Id && x.CatalogNodeId is null).OrderBy(x => x.Code).Select(ApiView).ToList()
        }).ToList();

        foreach (var t in m.Tenants.Values)
        {
            var directNodes = children[null].Where(n => n.TenantId == t.Id && n.ApplicationId is null)
                .OrderBy(n => n.Code).Select(NodeView).ToList();
            var directApis = m.Apis.Values.Where(a => a.TenantId == t.Id && a.ApplicationId is null && a.CatalogNodeId is null)
                .OrderBy(a => a.Code).Select(ApiView).ToList();
            if (directNodes.Count == 0 && directApis.Count == 0) continue;
            roots.Add(new
            {
                id = -t.Id, code = t.Code, name = t.Name, type = "TenantRoot", isActive = t.IsActive, tenantId = t.Id, tenant = t.Code,
                isTenantRoot = true,
                permissionCount = m.Permissions.Values.Count(p => p.TenantId == t.Id && p.App is null),
                apiCount = m.Apis.Values.Count(a => a.TenantId == t.Id && a.ApplicationId is null),
                endpointCount = m.Data.Endpoints.Count(e => m.Apis.TryGetValue(e.ApiId, out var api) && api.TenantId == t.Id && api.ApplicationId is null),
                children = directNodes,
                apiList = directApis
            });
        }
        return roots;
    }

    [HttpGet("applications")]
    public async Task<object> Applications(CancellationToken ct) =>
        await db.Applications.AsNoTracking().OrderBy(a => a.Id).Select(a => new
        {
            a.Id, a.Code, a.Name, a.Type, a.Description, a.OwnerTeamId, ownerTeam = a.OwnershipTeam != null ? a.OwnershipTeam.Name : a.OwnerTeam,
            a.OwnerUserId, a.IsActive, a.TenantId, tenant = a.Tenant.Code
        }).ToListAsync(ct);

    /// <summary>Düğüm detayı: permission'lar, API'ler, UI öğeleri, bu düğüme (miras dahil) uygulanan policy'ler ve erişebilen client'lar.</summary>
    [HttpGet("nodes/{id:int}")]
    public async Task<object> Node(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Nodes.TryGetValue(id, out var n)) throw new NotFoundException("Düğüm", id);
        var chain = Views.NodeChain(m, id);
        var meta = await db.CatalogNodes.AsNoTracking().Where(x => x.Id == id).Select(x => new
        {
            x.Description, x.OwnerTeamId, ownerTeam = x.OwnershipTeam != null ? x.OwnershipTeam.Name : x.OwnerTeam, x.OwnerUserId
        }).FirstAsync(ct);

        var policies = m.Policies.Values.Select(p => new
        {
            p,
            include = p.Includes.Where(t => Views.CoversNode(m, t.Target, n, chain)).OrderByDescending(t => m.Specificity(t.Target)).FirstOrDefault(),
            exclude = p.Excludes.Where(t => Views.CoversNode(m, t.Target, n, chain)).OrderByDescending(t => m.Specificity(t.Target)).FirstOrDefault(),
            below = p.Includes.Where(t => t.Target.Type == TargetType.CatalogNode && t.Target.CatalogNodeId is { } tn && tn != id && Views.NodeChain(m, tn).Contains(id))
                .Select(t => m.Describe(t.Target)).ToList()
        })
        .Where(x => x.include is not null || x.below.Count > 0)
        .Select(x => new
        {
            x.p.Row.Id, x.p.Row.Code, x.p.Row.Name, x.p.Row.Mode, x.p.Row.IsActive, tenant = x.p.TenantCode,
            matchedBy = x.include is null ? null : m.Describe(x.include.Target),
            inherited = x.include is not null && !(x.include.Target.Type == TargetType.CatalogNode && x.include.Target.CatalogNodeId == id),
            excludedBy = x.exclude is null ? null : m.Describe(x.exclude.Target),
            onDescendants = x.below
        }).ToList();

        var clients = m.ClientsById.Values.Select(c => new
        {
            c.Id, c.ClientId, c.Name,
            allowedPermissions = m.ClientAllowedPermissionRows(c.Id).Where(g => Views.CoversNode(m, g.Target, n, chain)).Select(g => m.Describe(g.Target) + (g.Actions is null ? "" : $" [{g.Actions}]")).ToList()
        }).Where(c => c.allowedPermissions.Count > 0).ToList();

        return new
        {
            node = new
            {
                n.Id, n.TenantId, n.Code, n.Name, n.Type, n.Path, n.ParentId, n.ApplicationId,
                application = n.ApplicationId is { } appId ? m.Apps[appId].Code : null,
                tenant = m.TenantCode(n.TenantId), meta.Description, meta.OwnerTeamId, meta.ownerTeam, meta.OwnerUserId
            },
            breadcrumb = chain.AsEnumerable().Reverse().Select(i => new { m.Nodes[i].Id, m.Nodes[i].Code, m.Nodes[i].Name }).ToList(),
            children = m.Nodes.Values.Where(c => c.ParentId == id).OrderBy(c => c.Code).Select(c => new { c.Id, c.Code, c.Name, c.Type }).ToList(),
            permissions = m.Permissions.Values.Where(p => p.Node?.Id == id).OrderBy(p => p.Code).Select(p => new { p.Id, p.Code, p.Row.Name, p.Row.Action, p.Row.RiskLevel, p.Row.IsActive }).ToList(),
            apis = m.Apis.Values.Where(a => a.CatalogNodeId == id).Select(a => new
            {
                a.Id, a.Code, a.Name, a.Audience,
                endpoints = m.EndpointsOf(a.Id).Select(e => new { e.Id, e.Method, e.Path, e.PermissionId, permission = e.PermissionId is { } pid ? m.Permissions[pid].Code : null }).ToList()
            }).ToList(),
            uiElements = m.Data.UiElements.Where(u => u.CatalogNodeId == id).OrderBy(u => u.Order).Select(u => new
            {
                u.Id, u.Code, u.Name, u.Kind, u.ParentId, u.Order, u.PermissionId, permission = u.PermissionId is { } pid ? m.Permissions[pid].Code : null
            }).ToList(),
            policies, clients
        };
    }

    [HttpPost("applications")]
    public async Task<object> CreateApplication(ApplicationUpsert dto, CancellationToken ct) => new { (await catalog.CreateApplicationAsync(dto, ct)).Id };

    [HttpPut("applications/{id:int}")]
    public Task UpdateApplication(int id, ApplicationUpsert dto, CancellationToken ct) => catalog.UpdateApplicationAsync(id, dto, ct);

    [HttpPost("nodes")]
    public async Task<object> CreateNode(NodeUpsert dto, CancellationToken ct) { var n = await catalog.CreateNodeAsync(dto, ct); return new { n.Id, n.Path }; }

    [HttpPut("nodes/{id:int}")]
    public Task UpdateNode(int id, NodeUpsert dto, CancellationToken ct) => catalog.UpdateNodeAsync(id, dto, ct);

    [HttpDelete("nodes/{id:int}")]
    public Task DeleteNode(int id, CancellationToken ct) => catalog.DeleteNodeAsync(id, ct);

    /// <summary>Servis manifestini içe aktarır (mikroservis /.well-known/yetki-manifest çıktısı).</summary>
    [HttpPost("import")]
    public Task<ManifestImportReport> Import(ServiceManifest manifest, CancellationToken ct) => catalog.ImportManifestAsync(manifest, ct);


}

[ApiController]
[Route("api/ownership-teams")]
public sealed class OwnershipTeamsController(IYetkiDbContext db, OwnershipTeamService service) : ControllerBase
{
    [HttpGet]
    public async Task<object> List([FromQuery] int? tenantId, CancellationToken ct) =>
        await db.OwnershipTeams.AsNoTracking()
            .Where(t => tenantId == null || t.TenantId == tenantId)
            .OrderBy(t => t.Tenant.Code).ThenBy(t => t.Code)
            .Select(t => new
            {
                t.Id, t.TenantId, tenant = t.Tenant.Code, t.Code, t.Name, t.Description, t.IsActive,
                t.ParentId, parent = t.Parent != null ? t.Parent.Code : null,
                applicationCount = db.Applications.Count(a => a.OwnerTeamId == t.Id),
                catalogLevelCount = db.CatalogNodes.Count(n => n.OwnerTeamId == t.Id),
                childTeamCount = db.OwnershipTeams.Count(c => c.ParentId == t.Id)
            }).ToListAsync(ct);

    [HttpPost]
    public async Task<object> Create(OwnershipTeamUpsert dto, CancellationToken ct) =>
        new { (await service.CreateAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task Update(int id, OwnershipTeamUpsert dto, CancellationToken ct) => service.UpdateAsync(id, dto, ct);

    [HttpDelete("{id:int}")]
    public Task Delete(int id, CancellationToken ct) => service.DeleteAsync(id, ct);
}

[ApiController]
[Route("api/permissions")]
public sealed class PermissionsController(AuthorizationModelProvider models, CatalogService catalog, IYetkiDbContext db, IClock clock) : ControllerBase
{
    [HttpGet]
    public async Task<object> List([FromQuery] string? q, [FromQuery] string? application, [FromQuery] int? nodeId, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var rolesByPerm = m.Data.RolePermissions.ToLookup(x => x.PermissionId, x => m.Roles[x.RoleId].Code);
        var groupsByPerm = m.Data.GroupPermissions.ToLookup(x => x.PermissionId, x => m.Groups[x.GroupId].Code);
        return m.Permissions.Values
            .Where(p => application is null || (p.App?.Code ?? m.TenantCode(p.TenantId)).Equals(application, StringComparison.OrdinalIgnoreCase))
            .Where(p => nodeId is null || p.NodeChain.Contains(nodeId.Value))
            .Where(p => string.IsNullOrWhiteSpace(q) || p.Code.Contains(q, StringComparison.OrdinalIgnoreCase) || p.Row.Name.Contains(q, StringComparison.OrdinalIgnoreCase))
            .OrderBy(p => p.Code, StringComparer.Ordinal)
            .Select(p => new
            {
                p.Id, p.Code, p.Row.Name, application = p.App?.Code, tenant = m.TenantCode(p.TenantId), p.Path, p.Row.Action, p.Row.RiskLevel, p.Row.IsActive,
                sourceEndpointId = p.Row.SourceEndpointId,
                endpoint = p.Row.SourceEndpointId is { } eid && m.Data.Endpoints.FirstOrDefault(e => e.Id == eid) is { } ep && m.Apis.TryGetValue(ep.ApiId, out var api)
                    ? $"{api.Code} · {ep.Method} {ep.Path}" : null,
                roles = rolesByPerm[p.Id].ToList(), groups = groupsByPerm[p.Id].ToList()
            }).ToList();
    }

    [HttpGet("{id:int}")]
    public async Task<object> Detail(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Permissions.TryGetValue(id, out var p)) throw new NotFoundException("Permission", id);
        var now = clock.UtcNow;
        var meta = await db.Permissions.AsNoTracking().Where(x => x.Id == id).Select(x => new { x.Description }).FirstAsync(ct);

        return new
        {
            permission = new
            {
                p.Id, p.Code, p.Row.Name, meta.Description, resource = p.Path, p.Row.Action, p.Row.RiskLevel, p.Row.IsActive,
                sourceEndpointId = p.Row.SourceEndpointId,
                application = p.App?.Code, tenant = m.TenantCode(p.TenantId), p.Path, nodeId = p.Node?.Id
            },
            breadcrumb = p.NodeChain.AsEnumerable().Reverse().Select(i => new { m.Nodes[i].Id, m.Nodes[i].Code, m.Nodes[i].Name }).ToList(),
            endpoints = m.Data.Endpoints.Where(e => e.PermissionId == id).Select(e => new { e.Id, e.Method, e.Path, api = m.Apis[e.ApiId].Code }).ToList(),
            uiElements = m.Data.UiElements.Where(u => u.PermissionId == id).Select(u => new { u.Id, u.Code, u.Name, u.Kind, path = m.Nodes[u.CatalogNodeId].Path }).ToList(),
            roles = m.Data.RolePermissions.Where(x => x.PermissionId == id).Select(x => new { m.Roles[x.RoleId].Id, m.Roles[x.RoleId].Code, m.Roles[x.RoleId].Name }).ToList(),
            groups = m.Data.GroupPermissions.Where(x => x.PermissionId == id).Select(x => new { m.Groups[x.GroupId].Id, m.Groups[x.GroupId].Code }).ToList(),
            policiesByTenant = m.Tenants.Values.Select(o =>
            {
                var a = m.GetApplicablePolicies(id, o.Id);
                return new
                {
                    tenant = o.Code,
                    applied = a.Applied.Select(x => new { x.Policy.Row.Id, x.Policy.Row.Code, x.Policy.Row.Name, x.Policy.Row.Mode, x.MatchedBy, owner = x.Policy.TenantCode }).ToList(),
                    excluded = a.Excluded.Select(x => new { x.Policy.Row.Id, x.Policy.Row.Code, x.MatchedBy, x.ExcludedBy }).ToList()
                };
            }).ToList(),
            clients = m.ClientsById.Values.Select(c => new { c.ClientId, c.Name, allowed = m.ClientAllows(c, p, out var via), via }).ToList(),
            holderCount = m.HoldersOf(id, now).Count()
        };
    }

    /// <summary>"Kimde var, neden?" — etkin sahipler ve kaynak yolları.</summary>
    [HttpGet("{id:int}/holders")]
    public async Task<object> Holders(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.HoldersOf(id, clock.UtcNow).Select(h => new
        {
            userId = h.User.Id, h.User.UserName, h.User.FullName, tenant = m.TenantCode(h.User.TenantId), units = m.UnitCodesOf(h.User.Id).ToList(),
            sources = h.Permission.Sources.Select(s => new { s.Type, s.Path }).ToList()
        }).ToList();
    }

    [HttpPost]
    public async Task<object> Create(PermissionUpsert dto, CancellationToken ct) { var p = await catalog.CreatePermissionAsync(dto, ct); return new { p.Id, p.Code }; }

    [HttpPut("{id:int}")]
    public Task Update(int id, PermissionUpsert dto, CancellationToken ct) => catalog.UpdatePermissionAsync(id, dto, ct);
}

[ApiController]
[Route("api")]
public sealed class ApisController(AuthorizationModelProvider models, CatalogService catalog, IYetkiDbContext db) : ControllerBase
{
    [HttpGet("apis/{id:int}")]
    public async Task<object> Detail(int id, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        if (!m.Apis.TryGetValue(id, out var a)) throw new NotFoundException("API", id);
        var endpointMeta = await db.ApiEndpoints.AsNoTracking().Where(e => e.ApiResourceId == id)
            .Select(e => new { e.Id, e.OperationId, e.Summary }).ToDictionaryAsync(e => e.Id, ct);
        return new
        {
            api = new
            {
                a.Id, a.Code, a.Name, a.Audience, a.IsActive,
                path = a.CatalogNodeId is { } nodeId ? m.Nodes[nodeId].Path : a.ApplicationId is { } appId ? m.Apps[appId].Code : m.TenantCode(a.TenantId),
                nodeId = a.CatalogNodeId,
                application = a.ApplicationId is { } appId2 ? m.Apps[appId2].Code : null,
                tenant = m.TenantCode(a.TenantId),
                breadcrumb = a.CatalogNodeId is { } breadcrumbNodeId
                    ? Views.NodeChain(m, breadcrumbNodeId).AsEnumerable().Reverse().Select(i => (object)new { m.Nodes[i].Id, m.Nodes[i].Code, m.Nodes[i].Name }).ToList()
                    : []
            },
            endpoints = m.EndpointsOf(id).OrderBy(e => e.Path).ThenBy(e => e.Method).Select(e => new
            {
                e.Id, e.Method, e.Path, e.PermissionId,
                operationId = endpointMeta.GetValueOrDefault(e.Id)?.OperationId,
                summary = endpointMeta.GetValueOrDefault(e.Id)?.Summary,
                permission = e.PermissionId is { } pid ? m.Permissions[pid].Code : null
            }).ToList()
        };
    }

    [HttpPost("apis")]
    public async Task<object> Create(ApiUpsert dto, CancellationToken ct) { var a = await catalog.CreateApiAsync(dto, ct); return new { a.Id, a.Audience }; }

    [HttpDelete("apis/{id:int}")]
    public Task DeleteApi(int id, CancellationToken ct) => catalog.DeleteApiAsync(id, ct);

    [HttpPost("apis/{id:int}/endpoints")]
    public async Task<object> AddEndpoint(int id, EndpointUpsert dto, CancellationToken ct) => new { (await catalog.AddEndpointAsync(id, dto, ct)).Id };

    [HttpPut("endpoints/{id:int}")]
    public Task UpdateEndpoint(int id, EndpointUpsert dto, CancellationToken ct) => catalog.UpdateEndpointAsync(id, dto, ct);

    [HttpDelete("endpoints/{id:int}")]
    public Task DeleteEndpoint(int id, CancellationToken ct) => catalog.DeleteEndpointAsync(id, ct);

    [HttpGet("ui-elements")]
    public async Task<object> UiElements([FromQuery] string? application, CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        return m.Data.UiElements
            .Where(u => application is null || (m.Nodes[u.CatalogNodeId].ApplicationId is { } appId
                && m.Apps[appId].Code.Equals(application, StringComparison.OrdinalIgnoreCase)))
            .OrderBy(u => m.Nodes[u.CatalogNodeId].Path).ThenBy(u => u.Order)
            .Select(u => new
            {
                u.Id, u.Code, u.Name, u.Kind, u.ParentId, u.Order, u.PermissionId, nodeId = u.CatalogNodeId, path = m.Nodes[u.CatalogNodeId].Path,
                permission = u.PermissionId is { } pid ? m.Permissions[pid].Code : null
            }).ToList();
    }

    [HttpPost("ui-elements")]
    public async Task<object> CreateUi(UiElementUpsert dto, CancellationToken ct) => new { (await catalog.CreateUiElementAsync(dto, ct)).Id };

    [HttpPut("ui-elements/{id:int}")]
    public Task UpdateUi(int id, UiElementUpsert dto, CancellationToken ct) => catalog.UpdateUiElementAsync(id, dto, ct);
}

[ApiController]
[Route("api/clients")]
public sealed class ClientsController(AuthorizationModelProvider models, ClientService clients, IYetkiDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<object> List(CancellationToken ct)
    {
        var m = await models.GetCurrentAsync(ct);
        var meta = await db.Clients.AsNoTracking().ToDictionaryAsync(c => c.Id, c => c.Description, ct);
        return m.ClientsById.Values.OrderBy(c => c.Id).Select(c => new
        {
            c.Id, c.ClientId, c.Name, c.Type, c.IsActive, description = meta.GetValueOrDefault(c.Id), c.TenantId, tenant = m.TenantCode(c.TenantId),
            application = c.ApplicationId is { } a ? m.Apps[a].Code : null, c.ApplicationId,
            serviceAccount = c.ServiceAccountUserId is { } u ? m.Users[u].UserName : null, c.ServiceAccountUserId,
            allowedPermissions = m.ClientAllowedPermissionRows(c.Id).Select(g => Views.Target(m, g.Id, InclusionMode.Include, g.Target, g.Actions)).ToList(),
            reachablePermissions = m.Permissions.Values.Count(p => m.ClientAllows(c, p, out _))
        }).ToList();
    }

    [HttpPost]
    public async Task<object> Create(ClientUpsert dto, CancellationToken ct) => new { (await clients.CreateAsync(dto, ct)).Id };

    [HttpPut("{id:int}")]
    public Task Update(int id, ClientUpsert dto, CancellationToken ct) => clients.UpdateAsync(id, dto, ct);

    [HttpPost("{id:int}/allowed-permissions")]
    public async Task<object> AddAllowedPermission(int id, ClientAllowedPermissionUpsert dto, CancellationToken ct) => new { (await clients.AddAllowedPermissionAsync(id, dto, ct)).Id };

    [HttpDelete("/api/client-permission-grants/{grantId:int}")]
    public Task RemoveAllowedPermission(int grantId, CancellationToken ct) => clients.RemoveAllowedPermissionAsync(grantId, ct);
}
