using Yetki.Domain.Common;

namespace Yetki.Application.Model;

// ============================================================================================
//  Uygulanmamış değişiklikler. What-If ve gerçek atama akışı AYNI change set'i ve AYNI modeli kullanır:
//  mevcut model verisi kopyalanır, değişiklik bellekte uygulanır, yeni model kurulur, önce/sonra karşılaştırılır.
//  Böylece simülasyon ile gerçek sonuç arasında semantik fark oluşamaz.
// ============================================================================================

public enum GroupGrantKind { Role = 1, Permission = 2 }

public sealed record UserRoleChange(int UserId, int RoleId, bool Add, DateTime? ValidUntil = null);
public sealed record UserPermissionChange(int UserId, int PermissionId, bool Add, DateTime? ValidUntil = null);
public sealed record UserUnitChange(int UserId, int OrgUnitId, bool Add);
public sealed record RolePermissionChange(int RoleId, int PermissionId, bool Add);
public sealed record GroupMemberChange(int GroupId, int UserId, bool Add, DateTime? ValidUntil = null);
public sealed record GroupGrantChange(int GroupId, GroupGrantKind Kind, int TargetId, bool Add);
public sealed record ActivationChange(int Id, bool IsActive);
/// <summary>Kullanıcı özelliği değişikliği (unvan grup kriterini, izin/limit policy'leri etkiler). Null = değişmez.</summary>
public sealed record UserUpdate(int UserId, string? Title = null, bool? IsActive = null, bool? IsOnLeave = null, decimal? CashWithdrawalLimit = null);
/// <summary>Rol ayarı değişikliği (pasifleştirme, miras alınabilirlik). Null = değişmez.</summary>
public sealed record RoleUpdate(int RoleId, bool? IsActive = null, bool? IsInheritable = null);

public sealed class GroupCriterionDraft
{
    public string Attribute { get; set; } = default!;
    public List<string> Values { get; set; } = new();
}

public sealed class GroupFilterDraft
{
    public InclusionMode Mode { get; set; } = InclusionMode.Include;
    public string? Description { get; set; }
    public List<GroupCriterionDraft> Criteria { get; set; } = new();
}

/// <summary>Bir grubun kitle kurallarının tamamen yenisiyle değiştirilmesi.</summary>
public sealed record GroupFiltersReplacement(int GroupId, List<GroupFilterDraft> Filters);

/// <summary>RBAC tarafı (kullanıcı/rol/grup) değişiklikleri.</summary>
public sealed class AuthorizationChangeSet
{
    public List<UserRoleChange> UserRoles { get; set; } = new();
    public List<UserPermissionChange> UserPermissions { get; set; } = new();
    public List<UserUnitChange> UserUnits { get; set; } = new();
    public List<RolePermissionChange> RolePermissions { get; set; } = new();
    public List<GroupMemberChange> GroupMembers { get; set; } = new();
    public List<GroupGrantChange> GroupGrants { get; set; } = new();
    public List<GroupFiltersReplacement> GroupFilters { get; set; } = new();
    public List<ActivationChange> GroupActivations { get; set; } = new();
    public List<RoleUpdate> RoleUpdates { get; set; } = new();
    public List<UserUpdate> UserUpdates { get; set; } = new();

    public bool IsEmpty =>
        UserRoles.Count + UserPermissions.Count + UserUnits.Count + RolePermissions.Count + GroupMembers.Count
        + GroupGrants.Count + GroupFilters.Count + GroupActivations.Count + RoleUpdates.Count + UserUpdates.Count == 0;
}

// ------------------------------ Policy tarafı ------------------------------

public sealed record PolicyActivationChange(int PolicyId, bool IsActive);
public sealed record PolicyModeChange(int PolicyId, PolicyMode Mode);
public sealed record PolicyAlgorithmChange(int PolicyId, CombiningAlgorithm Algorithm);

/// <summary>Policy'ye eklenecek hedef. TargetId tipine göre uygulama / katalog düğümü / permission id (All için boş).</summary>
public sealed record PolicyTargetDraft(int PolicyId, InclusionMode Mode, TargetType TargetType, int? TargetId, string? Actions = null);

/// <summary>Policy'ye eklenecek kanal (client) hedefi.</summary>
public sealed record PolicyClientTargetDraft(int PolicyId, InclusionMode Mode, int ClientId);

public sealed record RuleOverride(int RuleId, bool? IsActive = null, int? Order = null);

/// <summary>Bir predicate düğümünün parametrelerini değiştirir (ör. mesai bitişi 18:00 → 17:00).</summary>
public sealed record ConditionParameterOverride(int ConditionId, Dictionary<string, string> Parameters);

/// <summary>Condition ifade ağacı taslağı (yönetim API'si ve What-If). Predicate / AllOf / AnyOf / Not / Reference.</summary>
public sealed class ConditionDraft
{
    public ConditionKind Kind { get; set; } = ConditionKind.Predicate;
    public string? ConditionTypeCode { get; set; }
    public string? SharedConditionCode { get; set; }
    public Dictionary<string, string> Parameters { get; set; } = new();
    public List<ConditionDraft> Children { get; set; } = new();
}

public sealed class RuleDraft
{
    public int PolicyId { get; set; }
    public string Code { get; set; } = "DRAFT_RULE";
    public string? Name { get; set; }
    public int Order { get; set; } = 50;
    public string? ReasonCode { get; set; }
    public ConditionDraft Condition { get; set; } = new();
}

public sealed record RuleReplacement(int RuleId, RuleDraft Rule);

public sealed record SharedConditionReplacement(int SharedConditionId, ConditionDraft Condition);

public sealed class PolicyChangeSet
{
    public List<PolicyActivationChange> PolicyActivations { get; set; } = new();
    public List<PolicyModeChange> PolicyModes { get; set; } = new();
    public List<PolicyAlgorithmChange> PolicyAlgorithms { get; set; } = new();
    public List<PolicyTargetDraft> AddedTargets { get; set; } = new();
    public List<int> RemovedTargetIds { get; set; } = new();
    public List<PolicyClientTargetDraft> AddedClientTargets { get; set; } = new();
    public List<int> RemovedClientTargetIds { get; set; } = new();
    public List<RuleOverride> RuleOverrides { get; set; } = new();
    public List<ConditionParameterOverride> ConditionOverrides { get; set; } = new();
    public List<RuleDraft> AddedRules { get; set; } = new();
    public List<int> RemovedRuleIds { get; set; } = new();
    public List<RuleReplacement> ReplacedRules { get; set; } = new();
    public List<SharedConditionReplacement> SharedConditionReplacements { get; set; } = new();

    public bool IsEmpty =>
        PolicyActivations.Count + PolicyModes.Count + PolicyAlgorithms.Count + AddedTargets.Count + RemovedTargetIds.Count
        + AddedClientTargets.Count + RemovedClientTargetIds.Count
        + RuleOverrides.Count + ConditionOverrides.Count + AddedRules.Count + RemovedRuleIds.Count + ReplacedRules.Count
        + SharedConditionReplacements.Count == 0;
}
