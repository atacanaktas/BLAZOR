using System.Collections.Concurrent;
using Yetki.Application.PolicyEngine;
using Yetki.Domain.Common;

namespace Yetki.Application.Model;

/// <summary>Permission + katalogdaki yeri (uygulama, düğüm zinciri). NodeChain: kendi düğümünden köke doğru.</summary>
public sealed record PermInfo(PermRow Row, int TenantId, AppRow? App, NodeRow? Node, IReadOnlyList<int> NodeChain, string Path)
{
    public int Id => Row.Id;
    public string Code => Row.Code;
}

public sealed record CompiledPolicy(PolicyRow Row, string TenantCode, PolicyDefinition Definition,
    IReadOnlyList<PolicyTargetRow> Includes, IReadOnlyList<PolicyTargetRow> Excludes)
{
    /// <summary>Kanal hedefi: boş değilse policy SADECE bu client'lardan gelen isteklere uygulanır.</summary>
    public IReadOnlyList<PolicyClientTargetRow> IncludeClients { get; init; } = [];
    public IReadOnlyList<PolicyClientTargetRow> ExcludeClients { get; init; } = [];
    public IReadOnlyList<ObligationRow> Obligations { get; init; } = [];
}

/// <summary>Policy bu permission'a hangi hedef üzerinden uygulandı.</summary>
public sealed record AppliedPolicy(CompiledPolicy Policy, string MatchedBy);

public sealed record ExcludedPolicy(CompiledPolicy Policy, string MatchedBy, string ExcludedBy);

public sealed record PolicyApplicability(IReadOnlyList<AppliedPolicy> Applied, IReadOnlyList<ExcludedPolicy> Excluded);

/// <summary>
/// BELLEK İÇİ YETKİ MODELİ (değişmez anlık görüntü). Tüm kararlar, etkin yetki hesabı, grup üyeliği, policy hedefleme,
/// client allowed permissions ve What-If bu model üzerinden yapılır. Gerçek model veritabanı versiyonuyla önbelleklenir;
/// What-If modeli, verinin değiştirilmiş kopyasından AYNI Build ile kurulur (simülasyon = gerçek semantik).
///
/// Ölçek notu: Prototip hacminde (yüzlerce kullanıcı, binlerce permission) tüm model bellekte tutulur.
/// 20K+ kullanıcıda kullanıcıya özgü dilimler (atamalar) ayrı yüklenmeli, katalog/policy/grup tanımları paylaşılmalıdır (TODO).
/// </summary>
public sealed class AuthorizationModel
{
    public long Version { get; }
    public bool IsSimulation { get; }
    public DateTime BuiltAt { get; }
    public ModelData Data { get; }
    public GroupCriterionRegistry Criteria { get; }

    public IReadOnlyDictionary<int, TenantRow> Tenants { get; }
    public IReadOnlyDictionary<string, TenantRow> TenantByCode { get; }
    /// <summary>Kurum → kendisi + üstleri (kendisi ilk).</summary>
    public IReadOnlyDictionary<int, IReadOnlyList<int>> TenantAncestors { get; }
    public IReadOnlyDictionary<int, UnitRow> Units { get; }
    public IReadOnlyDictionary<int, UserRow> Users { get; }
    public IReadOnlyDictionary<string, int> UserIdByName { get; }
    public IReadOnlyDictionary<int, AppRow> Apps { get; }
    public IReadOnlyDictionary<string, AppRow> AppByCode { get; }
    public IReadOnlyDictionary<int, NodeRow> Nodes { get; }
    public IReadOnlyDictionary<int, PermInfo> Permissions { get; }
    public IReadOnlyDictionary<string, int> PermissionIdByCode { get; }
    public IReadOnlyDictionary<int, ApiRow> Apis { get; }
    public IReadOnlyDictionary<string, ClientRow> ClientsById { get; }
    public IReadOnlyDictionary<int, RoleRow> Roles { get; }
    public IReadOnlyDictionary<string, int> RoleIdByCode { get; }
    public IReadOnlyDictionary<int, GroupRow> Groups { get; }
    public IReadOnlyDictionary<int, CompiledPolicy> Policies { get; }

    private readonly ILookup<int, UserUnitRow> _userUnits;
    private readonly ILookup<int?, UnitRow> _unitChildren;
    private readonly ILookup<int, UserRoleRow> _userRoles;
    private readonly ILookup<int, UserPermRow> _userPerms;
    private readonly ILookup<int, int> _rolePerms;
    private readonly ILookup<int, GroupMemberRow> _groupMembers;
    private readonly ILookup<int, GroupFilterRow> _groupFilters;
    private readonly ILookup<int, int> _groupRoles;
    private readonly ILookup<int, int> _groupPerms;
    private readonly ILookup<int, ClientAllowedPermissionRow> _clientAllowedPermissions;
    private readonly ILookup<int, EndpointRow> _endpointsByApi;

    private readonly Dictionary<(string Path, string Action), int> _permByResourceAction;
    private readonly ConcurrentDictionary<(int UserId, long Minute), EffectivePermissionSet> _effective = new();
    private readonly ConcurrentDictionary<(int PermissionId, int TenantId), PolicyApplicability> _applicability = new();

    private AuthorizationModel(ModelData data, IReadOnlyList<CompiledPolicy> policies, GroupCriterionRegistry criteria, long version, bool isSimulation, DateTime builtAt)
    {
        Data = data;
        Criteria = criteria;
        Version = version;
        IsSimulation = isSimulation;
        BuiltAt = builtAt;

        Tenants = data.Tenants.ToDictionary(o => o.Id);
        TenantByCode = data.Tenants.ToDictionary(o => o.Code, StringComparer.OrdinalIgnoreCase);
        TenantAncestors = data.Tenants.ToDictionary(o => o.Id, o => (IReadOnlyList<int>)Chain(o.Id, id => Tenants.GetValueOrDefault(id)?.ParentId));
        Units = data.Units.ToDictionary(u => u.Id);
        _unitChildren = data.Units.ToLookup(u => u.ParentId);
        Users = data.Users.ToDictionary(u => u.Id);
        UserIdByName = data.Users.ToDictionary(u => u.UserName, u => u.Id, StringComparer.OrdinalIgnoreCase);
        _userUnits = data.UserUnits.ToLookup(x => x.UserId);

        Apps = data.Applications.ToDictionary(a => a.Id);
        AppByCode = data.Applications.ToDictionary(a => a.Code, StringComparer.OrdinalIgnoreCase);
        Nodes = data.Nodes.ToDictionary(n => n.Id);
        Permissions = data.Permissions.ToDictionary(p => p.Id, p =>
        {
            var node = p.CatalogNodeId is { } nodeId ? Nodes.GetValueOrDefault(nodeId) : null;
            var app = p.ApplicationId is { } appId ? Apps.GetValueOrDefault(appId) : null;
            var path = node?.Path ?? app?.Code ?? TenantCode(p.TenantId);
            return new PermInfo(p, p.TenantId, app, node, node is null ? [] : Chain(node.Id, id => Nodes.GetValueOrDefault(id)?.ParentId), path);
        });
        PermissionIdByCode = Permissions.Values.ToDictionary(p => p.Code, p => p.Id, StringComparer.OrdinalIgnoreCase);
        _permByResourceAction = Permissions.Values
            .Where(p => p.Row.SourceEndpointId is null)
            .GroupBy(p => (p.Path.ToUpperInvariant(), p.Row.Action.ToLowerInvariant()))
            .ToDictionary(g => g.Key, g => g.First().Id);
        Apis = data.Apis.ToDictionary(a => a.Id);
        _endpointsByApi = data.Endpoints.ToLookup(e => e.ApiId);

        ClientsById = data.Clients.ToDictionary(c => c.ClientId, StringComparer.OrdinalIgnoreCase);
        _clientAllowedPermissions = data.ClientAllowedPermissions.ToLookup(g => g.ClientId);

        Roles = data.Roles.ToDictionary(r => r.Id);
        RoleIdByCode = data.Roles.ToDictionary(r => r.Code, r => r.Id, StringComparer.OrdinalIgnoreCase);
        _rolePerms = data.RolePermissions.ToLookup(x => x.RoleId, x => x.PermissionId);
        _userRoles = data.UserRoles.ToLookup(x => x.UserId);
        _userPerms = data.UserPermissions.ToLookup(x => x.UserId);

        Groups = data.Groups.ToDictionary(g => g.Id);
        _groupMembers = data.GroupMembers.ToLookup(x => x.GroupId);
        _groupFilters = data.GroupFilters.ToLookup(x => x.GroupId);
        _groupRoles = data.GroupRoles.ToLookup(x => x.GroupId, x => x.RoleId);
        _groupPerms = data.GroupPermissions.ToLookup(x => x.GroupId, x => x.PermissionId);

        Policies = policies.ToDictionary(p => p.Row.Id);
    }

    /// <summary>Modeli kurar. policyChanges: kaydedilmemiş policy değişiklikleri (What-If).</summary>
    public static AuthorizationModel Build(ModelData data, PolicyChangeSet? policyChanges, GroupCriterionRegistry criteria,
        long version, bool isSimulation, DateTime now)
    {
        var policies = PolicyCompiler.Compile(data, policyChanges);
        return new AuthorizationModel(data, policies, criteria, version, isSimulation, now);
    }

    private static List<int> Chain(int start, Func<int, int?> parentOf)
    {
        var list = new List<int>();
        int? current = start;
        while (current is { } c && !list.Contains(c))
        {
            list.Add(c);
            current = parentOf(c);
        }
        return list;
    }

    // ================================ Kurum / birim ================================

    public IEnumerable<UnitRow> UnitsOf(int userId) =>
        _userUnits[userId].OrderByDescending(x => x.IsPrimary).Select(x => Units.GetValueOrDefault(x.OrgUnitId)).OfType<UnitRow>();

    public IEnumerable<string> UnitCodesOf(int userId) => UnitsOf(userId).Select(u => u.Code);

    /// <summary>Kullanıcının birimleri + tüm alt birimleri (veri kapsamı).</summary>
    public IEnumerable<string> UnitScopeOf(int userId) =>
        UnitsOf(userId).SelectMany(u => Descendants(u.Id)).Select(id => Units[id].Code).Distinct();

    /// <summary>Kullanıcının birimleri + tüm üst birimleri.</summary>
    public IEnumerable<string> UnitAncestryOf(int userId) =>
        UnitsOf(userId).SelectMany(u => Chain(u.Id, id => Units.GetValueOrDefault(id)?.ParentId)).Select(id => Units[id].Code).Distinct();

    public IEnumerable<int> Descendants(int unitId)
    {
        var stack = new Stack<int>([unitId]);
        var seen = new HashSet<int>();
        while (stack.Count > 0)
        {
            var id = stack.Pop();
            if (!seen.Add(id)) continue;
            yield return id;
            foreach (var c in _unitChildren[id]) stack.Push(c.Id);
        }
    }

    public string TenantCode(int tenantId) => Tenants.TryGetValue(tenantId, out var o) ? o.Code : $"#{tenantId}";

    /// <summary>
    /// Tenant miras kuralı: ownerTenantId'ye ait tanım (uygulama, client, policy) tenantId'de kullanılabilir mi?
    /// Aynı tenant veya owner, tenantId'nin üst tenant'ı ise evet.
    /// </summary>
    public bool IsAvailableIn(int ownerTenantId, int tenantId) =>
        TenantAncestors.TryGetValue(tenantId, out var chain) && chain.Contains(ownerTenantId);

    /// <summary>
    /// Resource + Action → permission. Resource: katalog yolu (ANKA/NAKIT/CEKIM/GISE) veya kod biçimi (anka.nakit.cekim.gise).
    /// Action: create, read, approve... (büyük/küçük harf duyarsız).
    /// </summary>
    public PermInfo? FindPermission(string resource, string action)
    {
        var r = resource.Trim();
        var a = action.Trim().ToLowerInvariant();
        if (r.Contains('/'))
            return _permByResourceAction.TryGetValue((r.Trim('/').ToUpperInvariant(), a), out var id) ? Permissions[id] : null;
        return PermissionIdByCode.TryGetValue($"{r.ToLowerInvariant()}:{a}", out var pid) ? Permissions.GetValueOrDefault(pid) : null;
    }

    /// <summary>Rol bu kullanıcıya uygulanabilir mi? (aynı kurum veya üst kurumun miras alınabilir rolü)</summary>
    public bool RoleAppliesTo(RoleRow role, UserRow user) =>
        role.TenantId == user.TenantId || (role.IsInheritable && TenantAncestors[user.TenantId].Contains(role.TenantId));

    private static bool Valid(DateTime? from, DateTime? until, DateTime now) => (from is null || from <= now) && (until is null || until > now);

    public IEnumerable<UserRoleRow> UserRoleAssignments(int userId) => _userRoles[userId];

    public IEnumerable<string> DirectRoleCodes(int userId, DateTime now) =>
        _userRoles[userId].Where(r => Valid(r.ValidFrom, r.ValidUntil, now))
            .Select(r => Roles.GetValueOrDefault(r.RoleId)).OfType<RoleRow>().Where(r => r.IsActive).Select(r => r.Code);

    public IEnumerable<int> RolePermissionIds(int roleId) => _rolePerms[roleId];
    public IEnumerable<GroupMemberRow> GroupMemberRows(int groupId) => _groupMembers[groupId];
    public IEnumerable<GroupFilterRow> GroupFilterRows(int groupId) => _groupFilters[groupId].OrderBy(f => f.Order);
    public IEnumerable<int> GroupRoleIds(int groupId) => _groupRoles[groupId];
    public IEnumerable<int> GroupPermissionIds(int groupId) => _groupPerms[groupId];
    public IEnumerable<ClientAllowedPermissionRow> ClientAllowedPermissionRows(int clientId) => _clientAllowedPermissions[clientId];

    // ================================ Katalog hedefleme (miras) ================================

    /// <summary>Hedef bu permission'ı kapsıyor mu? Düğüm hedefi, düğümün altındaki her şeyi kapsar.</summary>
    public bool Matches(TargetRef t, PermInfo p) => t.Type switch
    {
        TargetType.All => true,
        TargetType.Application => p.App is not null && t.ApplicationId == p.App.Id,
        TargetType.CatalogNode => t.CatalogNodeId is { } n && p.NodeChain.Contains(n),
        TargetType.Permission => t.PermissionId == p.Id,
        _ => false
    };

    /// <summary>Policy hedefi katalog kapsamına ek olarak opsiyonel action filtresini de sağlamalıdır.</summary>
    public bool Matches(PolicyTargetRow t, PermInfo p) =>
        Matches(t.Target, p)
        && (string.IsNullOrWhiteSpace(t.Actions)
            || Common.Codes.SplitList(t.Actions).Contains(p.Row.Action, StringComparer.OrdinalIgnoreCase));

    /// <summary>Özgüllük: permission &gt; derin düğüm &gt; sığ düğüm &gt; uygulama &gt; tümü.</summary>
    public int Specificity(TargetRef t) => t.Type switch
    {
        TargetType.Permission => 1000,
        TargetType.CatalogNode when t.CatalogNodeId is { } n && Nodes.TryGetValue(n, out var node) => 100 + node.Path.Count(ch => ch == '/'),
        TargetType.Application => 10,
        _ => 1
    };

    public string Describe(TargetRef t) => t.Type switch
    {
        TargetType.All => "Tümü",
        TargetType.Application => $"Uygulama {(t.ApplicationId is { } a && Apps.TryGetValue(a, out var app) ? app.Code : "?")}",
        TargetType.CatalogNode => $"Düğüm {(t.CatalogNodeId is { } n && Nodes.TryGetValue(n, out var node) ? node.Path : "?")}",
        TargetType.Permission => $"Permission {(t.PermissionId is { } p && Permissions.TryGetValue(p, out var perm) ? perm.Code : "?")}",
        _ => "?"
    };

    /// <summary>
    /// Permission'a (kullanıcının kurumu için) uygulanan policy'ler: aktif, kurumu kullanıcının kurum
    /// zincirinde, Include hedeflerinden biri eşleşen ve hiçbir Exclude hedefi eşleşmeyenler. Enforce ve ReportOnly birlikte döner.
    /// </summary>
    public PolicyApplicability GetApplicablePolicies(int permissionId, int tenantId) =>
        _applicability.GetOrAdd((permissionId, tenantId), key =>
        {
            var applied = new List<AppliedPolicy>();
            var excluded = new List<ExcludedPolicy>();
            if (!Permissions.TryGetValue(key.PermissionId, out var perm)) return new PolicyApplicability(applied, excluded);
            var tenantChain = TenantAncestors.GetValueOrDefault(key.TenantId) ?? [];

            foreach (var p in Policies.Values.Where(p => p.Row.IsActive && tenantChain.Contains(p.Row.TenantId)).OrderBy(p => p.Row.Code, StringComparer.Ordinal))
            {
                var include = p.Includes.Where(t => Matches(t, perm)).OrderByDescending(t => Specificity(t.Target)).FirstOrDefault();
                if (include is null) continue;
                var exclude = p.Excludes.Where(t => Matches(t, perm)).OrderByDescending(t => Specificity(t.Target)).FirstOrDefault();
                if (exclude is null) applied.Add(new AppliedPolicy(p, Describe(include.Target) + DescribeActions(include.Actions)));
                else excluded.Add(new ExcludedPolicy(p, Describe(include.Target) + DescribeActions(include.Actions), Describe(exclude.Target) + DescribeActions(exclude.Actions)));
            }
            return new PolicyApplicability(applied, excluded);
        });

    private static string DescribeActions(string? actions) =>
        string.IsNullOrWhiteSpace(actions) ? "" : $" · Action: {string.Join(", ", Common.Codes.SplitList(actions))}";

    /// <summary>
    /// Kanal (client) filtresiyle uygulanabilir policy'ler: katalog hedefi (önbellekli) + policy'nin client hedefi.
    /// Include client'ı olan policy, istek client'ı listede değilse (veya client yoksa) uygulanmaz; Exclude client'ı eşleşirse hariç tutulur.
    /// </summary>
    public PolicyApplicability GetApplicablePolicies(int permissionId, int tenantId, ClientRow? client)
    {
        var baseline = GetApplicablePolicies(permissionId, tenantId);
        var applied = new List<AppliedPolicy>();
        var excluded = baseline.Excluded.ToList();
        foreach (var ap in baseline.Applied)
        {
            var p = ap.Policy;
            if (client is not null && p.ExcludeClients.Any(c => c.ClientId == client.Id))
            {
                excluded.Add(new ExcludedPolicy(p, ap.MatchedBy, $"Client {client.ClientId}"));
                continue;
            }
            if (p.IncludeClients.Count > 0)
            {
                if (client is null || p.IncludeClients.All(c => c.ClientId != client.Id)) continue; // bu kanala ait değil
                applied.Add(ap with { MatchedBy = $"{ap.MatchedBy} · client {client.ClientId}" });
                continue;
            }
            applied.Add(ap);
        }
        return new PolicyApplicability(applied, excluded);
    }

    public string ClientCodeOf(int clientId) => ClientsById.Values.FirstOrDefault(c => c.Id == clientId)?.ClientId ?? $"#{clientId}";

    /// <summary>Permission, Client için kayıtlı Allowed Permissions içinde mi?</summary>
    public bool ClientAllows(ClientRow client, PermInfo p, out string via)
    {
        var grant = ClientAllowedPermissionRows(client.Id)
            .Where(g => Matches(g.Target, p))
            .Where(g => g.Actions is null || Common.Codes.SplitList(g.Actions).Contains(p.Row.Action, StringComparer.OrdinalIgnoreCase))
            .OrderByDescending(g => Specificity(g.Target))
            .FirstOrDefault();
        via = grant is null ? "" : Describe(grant.Target) + (grant.Actions is null ? "" : $" [{grant.Actions}]");
        return grant is not null;
    }

    // ================================ Endpoint → permission ================================

    public ApiRow? FindApi(string key) =>
        Apis.Values.FirstOrDefault(a => string.Equals(a.Code, key, StringComparison.OrdinalIgnoreCase) || string.Equals(a.Audience, key, StringComparison.OrdinalIgnoreCase));

    public IEnumerable<EndpointRow> EndpointsOf(int apiId) => _endpointsByApi[apiId];

    /// <summary>HTTP metodu ve path'i şablonlarla eşleştirir ({id} herhangi bir segment). Sorgu dizesi yok sayılır.</summary>
    public EndpointRow? MatchEndpoint(ApiRow api, string method, string path)
    {
        var segments = Split(path);
        return EndpointsOf(api.Id)
            .Where(e => string.Equals(e.Method, method, StringComparison.OrdinalIgnoreCase))
            .Select(e => (e, tpl: Split(e.Path)))
            .Where(x => x.tpl.Length == segments.Length && x.tpl.Zip(segments).All(p =>
                (p.First.StartsWith('{') && p.First.EndsWith('}')) || string.Equals(p.First, p.Second, StringComparison.OrdinalIgnoreCase)))
            // En az joker içeren şablon kazanır (/v1/x/summary, /v1/x/{id}'den önce)
            .OrderBy(x => x.tpl.Count(s => s.StartsWith('{')))
            .Select(x => x.e)
            .FirstOrDefault();

        static string[] Split(string p) => p.Split('?')[0].Split('/', StringSplitOptions.RemoveEmptyEntries);
    }

    // ================================ Etkin yetki (RBAC + grup) ================================

    /// <summary>
    /// Kullanıcının etkin yetki seti. Kurallar:
    ///  1. Doğrudan roller (geçerlilik tarihi içinde, aktif, kurum kuralına uyan)
    ///  2. Grup üyeliği = (açık üye ∪ Include kuralı) − Exclude kuralı; grup kullanıcının kurum zincirinde olmalı
    ///  3. Grubun verdiği roller ve permission'lar
    ///  4. Doğrudan permission (legacy)
    /// Grup kriteri ROLE sadece DOĞRUDAN rollere bakar → gruptan gelen rol başka grubu tetiklemez (zincir/döngü yok).
    /// Pasif rol/grup/permission hesaba girmez. Sonuç model başına (dakika hassasiyetinde) önbelleklenir.
    /// </summary>
    public EffectivePermissionSet GetEffective(int userId, DateTime now) =>
        _effective.GetOrAdd((userId, now.Ticks / TimeSpan.TicksPerMinute), _ => ComputeEffective(userId, now));

    private EffectivePermissionSet ComputeEffective(int userId, DateTime now)
    {
        if (!Users.TryGetValue(userId, out var user))
            throw new KeyNotFoundException($"Kullanıcı modelde yok: {userId}");

        var ignored = new List<string>();
        var roleSources = new Dictionary<int, List<RoleSource>>();
        var permSources = new Dictionary<int, List<PermissionSource>>();

        void AddRole(int roleId, RoleSource src)
        {
            if (!Roles.TryGetValue(roleId, out var role) || !role.IsActive) return;
            if (!RoleAppliesTo(role, user))
            {
                ignored.Add($"Rol '{role.Code}' ({TenantCode(role.TenantId)}) miras alınamaz; {TenantCode(user.TenantId)} kullanıcısına uygulanmadı ({src.Text}).");
                return;
            }
            if (!roleSources.TryGetValue(roleId, out var list)) roleSources[roleId] = list = new();
            list.Add(src);
        }

        void AddPerm(int permissionId, PermissionSource src)
        {
            if (!Permissions.TryGetValue(permissionId, out var p) || !p.Row.IsActive) return;
            if (!IsAvailableIn(p.TenantId, user.TenantId))
            {
                var owner = p.App is null ? TenantCode(p.TenantId) : $"{p.App.Code} uygulaması";
                ignored.Add($"'{p.Code}' permission'ı başka tenant'a ait ({owner}, {TenantCode(p.TenantId)}); {TenantCode(user.TenantId)} kullanıcısına uygulanmadı ({src.Path}).");
                return;
            }
            if (!permSources.TryGetValue(permissionId, out var list)) permSources[permissionId] = list = new();
            list.Add(src);
        }

        // 1) Doğrudan roller
        foreach (var r in _userRoles[userId].Where(r => Valid(r.ValidFrom, r.ValidUntil, now)))
            AddRole(r.RoleId, new RoleSource("Direct", null, null,
                r.ValidUntil is { } until ? $"Doğrudan atama ({until:yyyy-MM-dd}'e kadar)" : "Doğrudan atama", r.ValidUntil));

        // 2) Grup üyelikleri
        var (memberships, exclusions) = ComputeMemberships(user, now);

        // 3) Gruptan gelen roller
        foreach (var m in memberships)
            foreach (var roleId in _groupRoles[m.GroupId])
                AddRole(roleId, new RoleSource("Group", m.GroupId, m.Code, $"Grup '{m.Code}' [{ReasonShort(m)}]", null));

        foreach (var (roleId, sources) in roleSources)
        {
            var role = Roles[roleId];
            foreach (var s in sources)
                foreach (var pid in _rolePerms[roleId])
                    AddPerm(pid, s.Kind == "Direct"
                        ? new PermissionSource(PermissionSourceType.DirectRole, roleId, role.Code, null, null, $"Rol '{role.Code}' ({s.Text.ToLowerInvariant()})")
                        : new PermissionSource(PermissionSourceType.GroupRole, roleId, role.Code, s.GroupId, s.GroupCode, $"{s.Text} → Rol '{role.Code}'"));
        }

        foreach (var m in memberships)
            foreach (var pid in _groupPerms[m.GroupId])
                AddPerm(pid, new PermissionSource(PermissionSourceType.GroupPermission, null, null, m.GroupId, m.Code,
                    $"Grup '{m.Code}' [{ReasonShort(m)}] → doğrudan permission"));

        // 4) Doğrudan permission (legacy)
        foreach (var up in _userPerms[userId].Where(x => Valid(null, x.ValidUntil, now)))
            AddPerm(up.PermissionId, new PermissionSource(PermissionSourceType.DirectPermission, null, null, null, null,
                up.ValidUntil is { } until ? $"Doğrudan permission (legacy/istisna, {until:yyyy-MM-dd}'e kadar)" : "Doğrudan permission (legacy/istisna)"));

        return new EffectivePermissionSet
        {
            UserId = user.Id,
            UserName = user.UserName,
            FullName = user.FullName,
            Tenant = TenantCode(user.TenantId),
            IsActive = user.IsActive,
            ModelVersion = Version,
            ComputedAt = now,
            IgnoredAssignments = ignored,
            Groups = memberships,
            ExcludedFromGroups = exclusions,
            Roles = roleSources
                .Select(kv => new EffectiveRole(kv.Key, Roles[kv.Key].Code, Roles[kv.Key].Name, TenantCode(Roles[kv.Key].TenantId), kv.Value))
                .OrderBy(r => r.Code, StringComparer.Ordinal).ToList(),
            Permissions = permSources
                .Select(kv =>
                {
                    var p = Permissions[kv.Key];
                    return new EffectivePermission(p.Id, p.Code, p.Row.Name, p.App?.Code ?? TenantCode(p.TenantId), p.Path, p.Row.Action, p.Row.RiskLevel, kv.Value);
                })
                .OrderBy(p => p.Code, StringComparer.Ordinal).ToList()
        };
    }

    /// <summary>Kullanıcının grup üyelikleri (neden eşleştiği ile) ve Exclude kuralıyla çıkarıldığı gruplar.</summary>
    public (List<GroupMembership> Memberships, List<GroupExclusion> Exclusions) ComputeMemberships(UserRow user, DateTime now)
    {
        var memberships = new List<GroupMembership>();
        var exclusions = new List<GroupExclusion>();
        var tenantChain = TenantAncestors[user.TenantId];

        foreach (var g in Groups.Values.Where(g => g.IsActive && tenantChain.Contains(g.TenantId)).OrderBy(g => g.Code, StringComparer.Ordinal))
        {
            var reasons = new List<MembershipReason>();
            if (_groupMembers[g.Id].Any(m => m.UserId == user.Id && Valid(null, m.ValidUntil, now)))
                reasons.Add(new MembershipReason("Member", null, "açık üye"));

            string? excludedBy = null;
            foreach (var f in _groupFilters[g.Id].OrderBy(f => f.Order))
            {
                if (!FilterMatches(f, user, now, out var text)) continue;
                if (f.Mode == InclusionMode.Include) reasons.Add(new MembershipReason("Filter", f.Order + 1, text));
                else excludedBy ??= $"Kural #{f.Order + 1} (hariç): {text}";
            }

            if (reasons.Count == 0) continue;
            if (excludedBy is not null) exclusions.Add(new GroupExclusion(g.Id, g.Code, excludedBy));
            else memberships.Add(new GroupMembership(g.Id, g.Code, g.Name, TenantCode(g.TenantId), reasons));
        }
        return (memberships, exclusions);
    }

    /// <summary>Filtredeki TÜM kriterler eşleşirse (VE) true. Kriteri olmayan veya bilinmeyen kriterli filtre eşleşmez (güvenli taraf).</summary>
    public bool FilterMatches(GroupFilterRow f, UserRow user, DateTime now, out string text)
    {
        var parts = new List<string>();
        text = "";
        if (f.Criteria.Count == 0) return false;
        foreach (var c in f.Criteria)
        {
            var handler = Criteria.Find(c.Attribute);
            if (handler is null || !handler.Matches(this, user, c.Values, now, out var matched)) return false;
            parts.Add($"{c.Attribute}={matched}");
        }
        text = string.Join(" ∧ ", parts);
        return true;
    }

    private static string ReasonShort(GroupMembership m) =>
        string.Join(" | ", m.Reasons.Select(r => r.Kind == "Member" ? "açık üye" : $"kural #{r.FilterOrder}: {r.Text}"));

    /// <summary>Grubun şu anki üyeleri (neden eşleştikleriyle).</summary>
    public IEnumerable<(UserRow User, GroupMembership Membership)> GroupMembersOf(int groupId, DateTime now)
    {
        foreach (var u in Users.Values.OrderBy(u => u.UserName, StringComparer.Ordinal))
        {
            var m = GetEffective(u.Id, now).Groups.FirstOrDefault(g => g.GroupId == groupId);
            if (m is not null) yield return (u, m);
        }
    }

    /// <summary>Permission'a (etkin) sahip kullanıcılar ve kaynakları.</summary>
    public IEnumerable<(UserRow User, EffectivePermission Permission)> HoldersOf(int permissionId, DateTime now)
    {
        foreach (var u in Users.Values.OrderBy(u => u.UserName, StringComparer.Ordinal))
        {
            var p = GetEffective(u.Id, now).Find(permissionId);
            if (p is not null) yield return (u, p);
        }
    }
}
