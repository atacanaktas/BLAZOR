using Yetki.Application.Identity;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;

namespace Yetki.Application.Model;

/// <summary>Güncel modeli tutan tekil önbellek (singleton). Anahtar: IAuthorizationVersion.</summary>
public sealed class AuthorizationModelCache
{
    internal AuthorizationModel? Current;
    internal string? IdentityRevision;
    internal readonly SemaphoreSlim Lock = new(1, 1);

    public long? CurrentVersion => Current?.Version;
}

/// <summary>
/// Yetki modelinin tek giriş noktası.
///  - GetCurrentAsync: veritabanı versiyonu değişmediyse önbellekteki modeli döner; değiştiyse yeniden yükler.
///  - BuildWhatIfAsync: güncel verinin kopyasına kaydedilmemiş değişiklikleri uygular ve AYNI Build ile simülasyon modeli kurar.
/// </summary>
public sealed class AuthorizationModelProvider(
    IYetkiDbContext db,
    IIdentityProvider identities,
    AuthorizationModelCache cache,
    IAuthorizationVersion version,
    GroupCriterionRegistry criteria,
    IClock clock)
{
    public async Task<AuthorizationModel> GetCurrentAsync(CancellationToken ct = default)
    {
        // Versiyon yüklemeden ÖNCE okunur: yükleme sırasında değişiklik olursa model eski versiyonla saklanır ve sonraki çağrı yeniler.
        var v = version.Current;
        var identityRevision = await identities.GetRevisionAsync(ct);
        if (cache.Current is { } m && m.Version == v && cache.IdentityRevision == identityRevision) return m;

        await cache.Lock.WaitAsync(ct);
        try
        {
            v = version.Current;
            identityRevision = await identities.GetRevisionAsync(ct);
            if (cache.Current is { } again && again.Version == v && cache.IdentityRevision == identityRevision) return again;
            // External identity changes must also advance decision/ETag model versions.
            if (cache.Current is { } old && old.Version == v && cache.IdentityRevision != identityRevision)
            {
                version.Bump(); v = version.Current;
            }
            var data = await LoadAsync(ct);
            var model = AuthorizationModel.Build(data, null, criteria, v, isSimulation: false, clock.UtcNow);
            cache.Current = model;
            cache.IdentityRevision = identityRevision;
            return model;
        }
        finally
        {
            cache.Lock.Release();
        }
    }

    public async Task<AuthorizationModel> BuildWhatIfAsync(AuthorizationChangeSet? rbac, PolicyChangeSet? policy, CancellationToken ct = default)
    {
        var current = await GetCurrentAsync(ct);
        if ((rbac is null || rbac.IsEmpty) && (policy is null || policy.IsEmpty)) return current;
        var data = current.Data.Clone().Apply(rbac);
        return AuthorizationModel.Build(data, policy is { IsEmpty: false } ? policy : null, criteria, current.Version, isSimulation: true, clock.UtcNow);
    }

    private async Task<ModelData> LoadAsync(CancellationToken ct)
    {
        var identity = await identities.ReadSnapshotAsync(ct);
        return new()
    {
        Tenants = await db.Tenants.AsNoTracking()
            .Select(o => new TenantRow(o.Id, o.Code, o.Name, o.Type, o.ParentId, o.IsActive)).ToListAsync(ct),
        Units = await db.OrgUnits.AsNoTracking()
            .Select(u => new UnitRow(u.Id, u.TenantId, u.ParentId, u.Code, u.Name, u.Type, u.IsActive)).ToListAsync(ct),
        Users = identity.Users.Select(u => new UserRow(u.Id, u.TenantId, u.UserName, u.FullName, u.Title, u.EmployeeNo, u.Kind, u.IsActive, u.IsOnLeave, u.CashWithdrawalLimit, u.CustomerNo)).ToList(),
        UserUnits = await db.UserOrgUnits.AsNoTracking()
            .Select(x => new UserUnitRow(x.UserId, x.OrgUnitId, x.IsPrimary)).ToListAsync(ct),

        Applications = await db.Applications.AsNoTracking()
            .Select(a => new AppRow(a.Id, a.TenantId, a.Code, a.Name, a.Type, a.IsActive)).ToListAsync(ct),
        Nodes = await db.CatalogNodes.AsNoTracking()
            .Select(n => new NodeRow(n.Id, n.TenantId, n.ApplicationId, n.ParentId, n.Type, n.Code, n.Name, n.Path)).ToListAsync(ct),
        Permissions = await db.Permissions.AsNoTracking()
            .Select(p => new PermRow(p.Id, p.TenantId, p.ApplicationId, p.CatalogNodeId, p.Code, p.Name, p.Action, p.RiskLevel, p.IsActive, p.SourceEndpointId)).ToListAsync(ct),
        Apis = await db.ApiResources.AsNoTracking()
            .Select(a => new ApiRow(a.Id, a.TenantId, a.ApplicationId, a.CatalogNodeId, a.Code, a.Name, a.Audience, a.IsActive)).ToListAsync(ct),
        Endpoints = await db.ApiEndpoints.AsNoTracking()
            .Select(e => new EndpointRow(e.Id, e.ApiResourceId, e.Method, e.Path, e.PermissionId)).ToListAsync(ct),
        UiElements = await db.UiElements.AsNoTracking()
            .Select(e => new UiRow(e.Id, e.CatalogNodeId, e.ParentId, e.Kind, e.Code, e.Name, e.Order, e.PermissionId)).ToListAsync(ct),

        Clients = await db.Clients.AsNoTracking()
            .Select(c => new ClientRow(c.Id, c.TenantId, c.ClientId, c.Name, c.Type, c.ApplicationId, c.ServiceAccountUserId, c.IsActive)).ToListAsync(ct),
        ClientAllowedPermissions = await db.ClientPermissionGrants.AsNoTracking()
            .Select(g => new ClientAllowedPermissionRow(g.Id, g.ClientId, new TargetRef(g.TargetType, g.ApplicationId, g.CatalogNodeId, g.PermissionId), g.Actions))
            .ToListAsync(ct),

        Roles = identity.Roles.Select(r => new RoleRow(r.Id, r.TenantId, r.Code, r.Name, r.IsInheritable, r.IsActive)).ToList(),
        RolePermissions = await db.RolePermissions.AsNoTracking()
            .Select(x => new RolePermRow(x.RoleId, x.PermissionId)).ToListAsync(ct),
        UserRoles = identity.UserRoles.Select(x => new UserRoleRow(x.UserId, x.RoleId, x.ValidFrom, x.ValidUntil)).ToList(),
        UserPermissions = await db.UserPermissions.AsNoTracking()
            .Select(x => new UserPermRow(x.UserId, x.PermissionId, x.ValidUntil)).ToListAsync(ct),

        Groups = await db.Groups.AsNoTracking()
            .Select(g => new GroupRow(g.Id, g.TenantId, g.Code, g.Name, g.IsActive)).ToListAsync(ct),
        GroupMembers = await db.GroupMembers.AsNoTracking()
            .Select(x => new GroupMemberRow(x.GroupId, x.UserId, x.ValidUntil)).ToListAsync(ct),
        GroupFilters = (await db.GroupFilters.AsNoTracking()
                .Select(f => new
                {
                    f.GroupId, f.Order, f.Mode, f.Description,
                    Criteria = f.Criteria.OrderBy(c => c.Order).Select(c => new { c.Attribute, Values = c.Values.Select(v => v.Value).ToList() }).ToList()
                }).ToListAsync(ct))
            .Select(f => new GroupFilterRow(f.GroupId, f.Order, f.Mode, f.Description,
                f.Criteria.Select(c => new CriterionRow(c.Attribute, c.Values)).ToList()))
            .ToList(),
        GroupRoles = await db.GroupRoles.AsNoTracking().Select(x => new GroupRoleRow(x.GroupId, x.RoleId)).ToListAsync(ct),
        GroupPermissions = await db.GroupPermissions.AsNoTracking().Select(x => new GroupPermRow(x.GroupId, x.PermissionId)).ToListAsync(ct),

        Policies = await db.Policies.AsNoTracking()
            .Select(p => new PolicyRow(p.Id, p.TenantId, p.Code, p.Name, p.CombiningAlgorithm, p.Mode, p.IsActive, p.Version)).ToListAsync(ct),
        PolicyTargets = await db.PolicyTargets.AsNoTracking()
            .Select(t => new PolicyTargetRow(t.Id, t.PolicyId, t.Mode, new TargetRef(t.TargetType, t.ApplicationId, t.CatalogNodeId, t.PermissionId), t.Actions))
            .ToListAsync(ct),
        PolicyClientTargets = await db.PolicyClientTargets.AsNoTracking()
            .Select(t => new PolicyClientTargetRow(t.Id, t.PolicyId, t.Mode, t.ClientId)).ToListAsync(ct),
        Obligations = (await db.PolicyObligations.AsNoTracking()
                .Select(o => new { o.Id, o.PolicyId, o.Code, o.FulfillOn, o.Order, Params = o.Parameters.Select(p => new { p.Key, p.Value }).ToList() })
                .ToListAsync(ct))
            .Select(o => new ObligationRow(o.Id, o.PolicyId, o.Code, o.FulfillOn, o.Order, o.Params.ToDictionary(p => p.Key, p => p.Value, StringComparer.OrdinalIgnoreCase)))
            .ToList(),
        Rules = await db.Rules.AsNoTracking()
            .Select(r => new RuleRow(r.Id, r.PolicyId, r.Code, r.Name, r.Description, r.Order, r.ReasonCode, r.IsActive)).ToListAsync(ct),
        Conditions = (await db.RuleConditions.AsNoTracking()
                .Select(c => new
                {
                    c.Id, c.RuleId, c.SharedConditionId, c.ParentId, c.Kind, c.Order, c.ReferencedSharedConditionId,
                    TypeCode = c.ConditionType != null ? c.ConditionType.Code : null,
                    TypeAvailable = c.ConditionType == null || c.ConditionType.IsAvailable,
                    Params = c.Parameters.Select(p => new { p.Key, p.Value }).ToList()
                }).ToListAsync(ct))
            .Select(c => new ConditionRow(c.Id, c.RuleId, c.SharedConditionId, c.ParentId, c.Kind, c.Order, c.TypeCode, c.TypeAvailable,
                c.ReferencedSharedConditionId, c.Params.ToDictionary(p => p.Key, p => p.Value, StringComparer.OrdinalIgnoreCase)))
            .ToList(),
        SharedConditions = await db.SharedConditions.AsNoTracking()
            .Select(s => new SharedRow(s.Id, s.Code, s.IsActive, s.Version)).ToListAsync(ct)
    };
    }
}
