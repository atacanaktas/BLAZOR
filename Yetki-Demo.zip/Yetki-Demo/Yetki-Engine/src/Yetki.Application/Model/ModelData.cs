using Yetki.Domain.Common;

namespace Yetki.Application.Model;

// Ham model satırları (değişmez kayıtlar). Veritabanından tek seferde yüklenir; What-If için kopyalanıp değiştirilir.

public sealed record TenantRow(int Id, string Code, string Name, TenantType Type, int? ParentId, bool IsActive);
public sealed record UnitRow(int Id, int TenantId, int? ParentId, string Code, string Name, OrgUnitType Type, bool IsActive);
public sealed record UserRow(int Id, int TenantId, string UserName, string FullName, string? Title, string? EmployeeNo,
    UserKind Kind, bool IsActive, bool IsOnLeave, decimal CashWithdrawalLimit, string? CustomerNo);
public sealed record UserUnitRow(int UserId, int OrgUnitId, bool IsPrimary);

public sealed record AppRow(int Id, int TenantId, string Code, string Name, ApplicationType Type, bool IsActive);
public sealed record NodeRow(int Id, int TenantId, int? ApplicationId, int? ParentId, CatalogNodeType Type, string Code, string Name, string Path);
public sealed record PermRow(int Id, int TenantId, int? ApplicationId, int? CatalogNodeId, string Code, string Name, string Action, Severity RiskLevel, bool IsActive, int? SourceEndpointId);
public sealed record ApiRow(int Id, int TenantId, int? ApplicationId, int? CatalogNodeId, string Code, string Name, string Audience, bool IsActive)
{
    public ApiRow(int id, int catalogNodeId, string code, string name, string audience, bool isActive)
        : this(id, 0, null, catalogNodeId, code, name, audience, isActive) { }
}
public sealed record EndpointRow(int Id, int ApiId, string Method, string Path, int? PermissionId);
public sealed record UiRow(int Id, int CatalogNodeId, int? ParentId, UiElementKind Kind, string Code, string Name, int Order, int? PermissionId);

/// <summary>Katalog kapsamı referansı (policy hedefi ve client izni ortak eşleştirme mantığını kullanır).</summary>
public sealed record TargetRef(TargetType Type, int? ApplicationId, int? CatalogNodeId, int? PermissionId);

public sealed record ClientRow(int Id, int TenantId, string ClientId, string Name, ClientType Type, int? ApplicationId, int? ServiceAccountUserId, bool IsActive);
public sealed record ClientAllowedPermissionRow(int Id, int ClientId, TargetRef Target, string? Actions);

public sealed record RoleRow(int Id, int TenantId, string Code, string Name, bool IsInheritable, bool IsActive);
public sealed record RolePermRow(int RoleId, int PermissionId);
public sealed record UserRoleRow(int UserId, int RoleId, DateTime? ValidFrom, DateTime? ValidUntil);
public sealed record UserPermRow(int UserId, int PermissionId, DateTime? ValidUntil);

public sealed record GroupRow(int Id, int TenantId, string Code, string Name, bool IsActive);
public sealed record GroupMemberRow(int GroupId, int UserId, DateTime? ValidUntil);
public sealed record CriterionRow(string Attribute, IReadOnlyList<string> Values);
public sealed record GroupFilterRow(int GroupId, int Order, InclusionMode Mode, string? Description, IReadOnlyList<CriterionRow> Criteria);
public sealed record GroupRoleRow(int GroupId, int RoleId);
public sealed record GroupPermRow(int GroupId, int PermissionId);

public sealed record PolicyRow(int Id, int TenantId, string Code, string Name, CombiningAlgorithm Algorithm, PolicyMode Mode, bool IsActive, int Version);
public sealed record PolicyTargetRow(int Id, int PolicyId, InclusionMode Mode, TargetRef Target, string? Actions);
/// <summary>Policy'nin kanal (client) hedefi. ClientId = Client tablosunun Id'si.</summary>
public sealed record PolicyClientTargetRow(int Id, int PolicyId, InclusionMode Mode, int ClientId);
/// <summary>Policy yükümlülüğü (PEP yerine getirir).</summary>
public sealed record ObligationRow(int Id, int PolicyId, string Code, ObligationFulfillOn FulfillOn, int Order, IReadOnlyDictionary<string, string> Params);
public sealed record RuleRow(int Id, int PolicyId, string Code, string Name, string? Description, int Order, string? ReasonCode, bool IsActive);
public sealed record ConditionRow(int Id, int? RuleId, int? SharedId, int? ParentId, ConditionKind Kind, int Order,
    string? TypeCode, bool TypeAvailable, int? RefId, IReadOnlyDictionary<string, string> Params);
public sealed record SharedRow(int Id, string Code, bool IsActive, int Version);

/// <summary>Yetki modelinin ham verisi. Clone() sığ kopyadır: satırlar değişmez, listeler yenidir.</summary>
public sealed class ModelData
{
    public List<TenantRow> Tenants { get; init; } = new();
    public List<UnitRow> Units { get; init; } = new();
    public List<UserRow> Users { get; init; } = new();
    public List<UserUnitRow> UserUnits { get; init; } = new();
    public List<AppRow> Applications { get; init; } = new();
    public List<NodeRow> Nodes { get; init; } = new();
    public List<PermRow> Permissions { get; init; } = new();
    public List<ApiRow> Apis { get; init; } = new();
    public List<EndpointRow> Endpoints { get; init; } = new();
    public List<UiRow> UiElements { get; init; } = new();
    public List<ClientRow> Clients { get; init; } = new();
    public List<ClientAllowedPermissionRow> ClientAllowedPermissions { get; init; } = new();
    public List<RoleRow> Roles { get; init; } = new();
    public List<RolePermRow> RolePermissions { get; init; } = new();
    public List<UserRoleRow> UserRoles { get; init; } = new();
    public List<UserPermRow> UserPermissions { get; init; } = new();
    public List<GroupRow> Groups { get; init; } = new();
    public List<GroupMemberRow> GroupMembers { get; init; } = new();
    public List<GroupFilterRow> GroupFilters { get; init; } = new();
    public List<GroupRoleRow> GroupRoles { get; init; } = new();
    public List<GroupPermRow> GroupPermissions { get; init; } = new();
    public List<PolicyRow> Policies { get; init; } = new();
    public List<PolicyTargetRow> PolicyTargets { get; init; } = new();
    public List<PolicyClientTargetRow> PolicyClientTargets { get; init; } = new();
    public List<ObligationRow> Obligations { get; init; } = new();
    public List<RuleRow> Rules { get; init; } = new();
    public List<ConditionRow> Conditions { get; init; } = new();
    public List<SharedRow> SharedConditions { get; init; } = new();

    public ModelData Clone() => new()
    {
        Tenants = [.. Tenants], Units = [.. Units], Users = [.. Users], UserUnits = [.. UserUnits],
        Applications = [.. Applications], Nodes = [.. Nodes], Permissions = [.. Permissions], Apis = [.. Apis],
        Endpoints = [.. Endpoints], UiElements = [.. UiElements], Clients = [.. Clients], ClientAllowedPermissions = [.. ClientAllowedPermissions],
        Roles = [.. Roles], RolePermissions = [.. RolePermissions], UserRoles = [.. UserRoles], UserPermissions = [.. UserPermissions],
        Groups = [.. Groups], GroupMembers = [.. GroupMembers], GroupFilters = [.. GroupFilters], GroupRoles = [.. GroupRoles],
        GroupPermissions = [.. GroupPermissions], Policies = [.. Policies], PolicyTargets = [.. PolicyTargets], Rules = [.. Rules],
        PolicyClientTargets = [.. PolicyClientTargets], Obligations = [.. Obligations],
        Conditions = [.. Conditions], SharedConditions = [.. SharedConditions]
    };

    /// <summary>RBAC değişikliklerini (kaydedilmemiş) bu veriye uygular.</summary>
    public ModelData Apply(AuthorizationChangeSet? c)
    {
        if (c is null || c.IsEmpty) return this;

        foreach (var x in c.UserRoles)
        {
            UserRoles.RemoveAll(r => r.UserId == x.UserId && r.RoleId == x.RoleId);
            if (x.Add) UserRoles.Add(new UserRoleRow(x.UserId, x.RoleId, null, x.ValidUntil));
        }
        foreach (var x in c.UserPermissions)
        {
            UserPermissions.RemoveAll(r => r.UserId == x.UserId && r.PermissionId == x.PermissionId);
            if (x.Add) UserPermissions.Add(new UserPermRow(x.UserId, x.PermissionId, x.ValidUntil));
        }
        foreach (var x in c.UserUnits)
        {
            UserUnits.RemoveAll(r => r.UserId == x.UserId && r.OrgUnitId == x.OrgUnitId);
            if (x.Add) UserUnits.Add(new UserUnitRow(x.UserId, x.OrgUnitId, !UserUnits.Any(u => u.UserId == x.UserId)));
        }
        foreach (var x in c.RolePermissions)
        {
            RolePermissions.RemoveAll(r => r.RoleId == x.RoleId && r.PermissionId == x.PermissionId);
            if (x.Add) RolePermissions.Add(new RolePermRow(x.RoleId, x.PermissionId));
        }
        foreach (var x in c.GroupMembers)
        {
            GroupMembers.RemoveAll(r => r.GroupId == x.GroupId && r.UserId == x.UserId);
            if (x.Add) GroupMembers.Add(new GroupMemberRow(x.GroupId, x.UserId, x.ValidUntil));
        }
        foreach (var x in c.GroupGrants)
        {
            if (x.Kind == GroupGrantKind.Role)
            {
                GroupRoles.RemoveAll(r => r.GroupId == x.GroupId && r.RoleId == x.TargetId);
                if (x.Add) GroupRoles.Add(new GroupRoleRow(x.GroupId, x.TargetId));
            }
            else
            {
                GroupPermissions.RemoveAll(r => r.GroupId == x.GroupId && r.PermissionId == x.TargetId);
                if (x.Add) GroupPermissions.Add(new GroupPermRow(x.GroupId, x.TargetId));
            }
        }
        foreach (var x in c.GroupFilters)
        {
            GroupFilters.RemoveAll(f => f.GroupId == x.GroupId);
            GroupFilters.AddRange(x.Filters.Select((f, i) => new GroupFilterRow(x.GroupId, i, f.Mode, f.Description,
                f.Criteria.Select(cr => new CriterionRow(cr.Attribute.Trim().ToUpperInvariant(), cr.Values.Select(v => v.Trim()).Where(v => v.Length > 0).ToList())).ToList())));
        }
        foreach (var x in c.GroupActivations)
        {
            var i = Groups.FindIndex(g => g.Id == x.Id);
            if (i >= 0) Groups[i] = Groups[i] with { IsActive = x.IsActive };
        }
        foreach (var x in c.RoleUpdates)
        {
            var i = Roles.FindIndex(r => r.Id == x.RoleId);
            if (i >= 0) Roles[i] = Roles[i] with { IsActive = x.IsActive ?? Roles[i].IsActive, IsInheritable = x.IsInheritable ?? Roles[i].IsInheritable };
        }
        foreach (var x in c.UserUpdates)
        {
            var i = Users.FindIndex(u => u.Id == x.UserId);
            if (i >= 0)
                Users[i] = Users[i] with
                {
                    Title = x.Title ?? Users[i].Title, IsActive = x.IsActive ?? Users[i].IsActive, IsOnLeave = x.IsOnLeave ?? Users[i].IsOnLeave,
                    CashWithdrawalLimit = x.CashWithdrawalLimit ?? Users[i].CashWithdrawalLimit
                };
        }
        return this;
    }
}
