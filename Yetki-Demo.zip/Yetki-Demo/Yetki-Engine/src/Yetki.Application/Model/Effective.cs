using System.Text.Json.Serialization;
using Yetki.Domain.Common;

namespace Yetki.Application.Model;

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum PermissionSourceType
{
    /// <summary>Kullanıcıya doğrudan atanmış rol.</summary>
    DirectRole = 1,
    /// <summary>Üyesi olunan grubun verdiği rol.</summary>
    GroupRole = 2,
    /// <summary>Üyesi olunan grubun doğrudan verdiği permission.</summary>
    GroupPermission = 3,
    /// <summary>Kullanıcıya doğrudan permission (legacy / istisna).</summary>
    DirectPermission = 4
}

public sealed record PermissionSource(PermissionSourceType Type, int? RoleId, string? RoleCode, int? GroupId, string? GroupCode, string Path);

/// <summary>Grup üyelik nedeni: açık üye veya kitle kuralı (hangi kriterlerle eşleşti).</summary>
public sealed record MembershipReason(string Kind, int? FilterOrder, string Text);

public sealed record GroupMembership(int GroupId, string Code, string Name, string Tenant, IReadOnlyList<MembershipReason> Reasons);

/// <summary>Include kuralıyla eşleşip Exclude kuralıyla çıkarılan grup (açıklama için).</summary>
public sealed record GroupExclusion(int GroupId, string Code, string Reason);

public sealed record RoleSource(string Kind, int? GroupId, string? GroupCode, string Text, DateTime? ValidUntil);

public sealed record EffectiveRole(int RoleId, string Code, string Name, string Tenant, IReadOnlyList<RoleSource> Sources);

public sealed record EffectivePermission(
    int PermissionId, string Code, string Name, string Application, string Path, string Action, Severity RiskLevel,
    IReadOnlyList<PermissionSource> Sources);

/// <summary>Açıklanabilir etkin yetki seti ("kim neye sahip, neden?"). Statiktir: istek bağlamına bakmaz.</summary>
public sealed class EffectivePermissionSet
{
    public int UserId { get; init; }
    public string UserName { get; init; } = default!;
    public string FullName { get; init; } = default!;
    public string Tenant { get; init; } = default!;
    public bool IsActive { get; init; }
    public long ModelVersion { get; init; }
    public DateTime ComputedAt { get; init; }
    public IReadOnlyList<EffectiveRole> Roles { get; init; } = [];
    public IReadOnlyList<GroupMembership> Groups { get; init; } = [];
    public IReadOnlyList<GroupExclusion> ExcludedFromGroups { get; init; } = [];
    public IReadOnlyList<EffectivePermission> Permissions { get; init; } = [];
    /// <summary>Kurum kuralı nedeniyle yok sayılan atamalar (ör. alt kurum kullanıcısına miras alınamaz rol).</summary>
    public IReadOnlyList<string> IgnoredAssignments { get; init; } = [];

    private Dictionary<int, EffectivePermission>? _byId;

    public EffectivePermission? Find(int permissionId) =>
        (_byId ??= Permissions.ToDictionary(p => p.PermissionId)).GetValueOrDefault(permissionId);

    public EffectivePermission? Find(string code) =>
        Permissions.FirstOrDefault(p => string.Equals(p.Code, code, StringComparison.OrdinalIgnoreCase));
}
