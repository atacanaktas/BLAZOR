using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Events;
using Yetki.Domain.Catalog;

namespace Yetki.Application.Definitions;

public sealed class OwnershipTeamUpsert
{
    public int TenantId { get; set; }
    public int? ParentId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class OwnershipTeamService(IYetkiDbContext db, AuditWriter audit, OutboxWriter outbox)
{
    public async Task<OwnershipTeam> CreateAsync(OwnershipTeamUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (!await db.Tenants.AnyAsync(t => t.Id == dto.TenantId, ct)) throw new NotFoundException("Tenant", dto.TenantId);
        if (await db.OwnershipTeams.AnyAsync(t => t.TenantId == dto.TenantId && t.Code == code, ct))
            throw new ConflictException($"Ownership Team kodu zaten var: {code}");
        var parentId = await ResolveParentAsync(dto.TenantId, dto.ParentId, null, ct);
        var team = new OwnershipTeam
        {
            TenantId = dto.TenantId, ParentId = parentId, Code = code, Name = dto.Name.Trim(),
            Description = dto.Description, IsActive = dto.IsActive
        };
        db.OwnershipTeams.Add(team);
        Changed("OwnershipTeamCreated", code, $"Ownership Team oluşturuldu: {code}", dto);
        await db.SaveChangesAsync(ct);
        return team;
    }

    public async Task UpdateAsync(int id, OwnershipTeamUpsert dto, CancellationToken ct)
    {
        var team = await db.OwnershipTeams.FindAsync([id], ct) ?? throw new NotFoundException("Ownership Team", id);
        team.ParentId = await ResolveParentAsync(team.TenantId, dto.ParentId, id, ct);
        team.Name = dto.Name.Trim();
        team.Description = dto.Description;
        team.IsActive = dto.IsActive;
        Changed("OwnershipTeamUpdated", team.Code, $"Ownership Team güncellendi: {team.Code}", dto);
        await db.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(int id, CancellationToken ct)
    {
        var team = await db.OwnershipTeams.FindAsync([id], ct) ?? throw new NotFoundException("Ownership Team", id);
        var appCount = await db.Applications.CountAsync(a => a.OwnerTeamId == id, ct);
        var nodeCount = await db.CatalogNodes.CountAsync(n => n.OwnerTeamId == id, ct);
        var childCount = await db.OwnershipTeams.CountAsync(t => t.ParentId == id, ct);
        if (appCount + nodeCount + childCount > 0)
            throw new ConflictException(
                $"'{team.Code}' kullanımda; silinemez.",
                new { applications = appCount, catalogNodes = nodeCount, childTeams = childCount });
        db.OwnershipTeams.Remove(team);
        Changed("OwnershipTeamDeleted", team.Code, $"Ownership Team silindi: {team.Code}", new { id });
        await db.SaveChangesAsync(ct);
    }

    private async Task<int?> ResolveParentAsync(int tenantId, int? parentId, int? selfId, CancellationToken ct)
    {
        if (parentId is not { } p) return null;
        if (p == selfId) throw new ValidationException("Üst Ownership Team kendisi olamaz.");
        var parent = await db.OwnershipTeams.FindAsync([p], ct) ?? throw new NotFoundException("Üst Ownership Team", p);
        if (parent.TenantId != tenantId) throw new ValidationException("Üst Ownership Team aynı kurumda olmalı.");
        return p;
    }

    private void Changed(string action, string id, string summary, object details)
    {
        audit.Management(action, "OwnershipTeam", id, summary, details);
        outbox.Add(EventTypes.CatalogChanged, "OwnershipTeam", id, new { action, id });
    }
}
