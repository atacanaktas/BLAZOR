using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Events;
using Yetki.Application.Identity;
using Yetki.Domain.Catalog;
using Yetki.Domain.Common;
using Yetki.Domain.Governance;

namespace Yetki.Application.Definitions;

public sealed class ApplicationUpsert
{
    /// <summary>Sahip tenant (oluştururken zorunlu; sonradan değiştirilemez).</summary>
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ApplicationType Type { get; set; }
    public string? OwnerTeam { get; set; }
    public int? OwnerTeamId { get; set; }
    public int? OwnerUserId { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class NodeUpsert
{
    public int TenantId { get; set; }
    public int? ApplicationId { get; set; }
    public int? ParentId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public string? OwnerTeam { get; set; }
    public int? OwnerTeamId { get; set; }
    public int? OwnerUserId { get; set; }
}

public sealed class PermissionUpsert
{
    public int? CatalogNodeId { get; set; }
    public int? ApiEndpointId { get; set; }
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public string Action { get; set; } = "execute";
    public Severity RiskLevel { get; set; } = Severity.Medium;
    public bool IsActive { get; set; } = true;
}

public sealed class ApiUpsert
{
    public int TenantId { get; set; }
    public int? ApplicationId { get; set; }
    public int? CatalogNodeId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Audience { get; set; }
    public string Version { get; set; } = "v1";
    public string? BasePath { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class EndpointUpsert
{
    public string Method { get; set; } = "GET";
    public string Path { get; set; } = "/";
    public string? OperationId { get; set; }
    public string? Summary { get; set; }
    public int? PermissionId { get; set; }
}

public sealed class UiElementUpsert
{
    public int CatalogNodeId { get; set; }
    public int? ParentId { get; set; }
    public UiElementKind Kind { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public int Order { get; set; }
    public int? PermissionId { get; set; }
}

// ------------------------------ Servis manifesti (mikroservis kendini kataloğa kaydeder) ------------------------------

/// <summary>Dış sistem bağımlılığı bildirimi (ör. RACF · MUS1 · TCICSTRN · READ). Access boşsa action'dan türetilir.</summary>
public sealed class ManifestExternal
{
    public string System { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string? ResourceClass { get; set; }
    public string? Name { get; set; }
    public ExternalAccessLevel? Access { get; set; }
}

public sealed class ManifestApi
{
    /// <summary>API'nin tüm endpoint'lerinin ortak dış bağımlılıkları (ör. CICS bölgesi).</summary>
    public List<ManifestExternal> External { get; set; } = new();
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Audience { get; set; }
    public string Version { get; set; } = "v1";
    public string? BasePath { get; set; }
}

public sealed class ManifestEndpoint
{
    public string Method { get; set; } = "GET";
    public string Path { get; set; } = "/";
    public string? OperationId { get; set; }
    public string? Summary { get; set; }
    /// <summary>Endpoint'in Resource üzerinde gerçekleştirdiği iş. Permission, Resource + Action ilişkisinden sistem tarafından üretilir.</summary>
    public string? Action { get; set; }
    /// <summary>Eski manifestlerle geriye uyumluluk. Yeni manifestler Action göndermelidir.</summary>
    public string? Permission { get; set; }
    public string? PermissionName { get; set; }
    public Severity? RiskLevel { get; set; }
    /// <summary>Endpoint'in çağırdığı mainframe kaynakları (kullanıcının kendi RACF yetkisiyle).</summary>
    public List<ManifestExternal> External { get; set; } = new();
}

/// <summary>
/// Servis manifesti: SDK'lı bir mikroservis /.well-known/yetki-manifest ile yayınlar, CI/CD veya yönetim ekranı içe aktarır.
/// Böylece 200+ API'nin endpoint → permission eşlemesi elle girilmez ve eşlenmemiş endpoint'ler görünür olur.
/// </summary>
public sealed class ServiceManifest
{
    public string Application { get; set; } = default!;
    /// <summary>Uygulama altındaki yol: NAKIT/CEKIM/GISE (eksik düğümler oluşturulur).</summary>
    public string CatalogPath { get; set; } = default!;
    public Dictionary<string, string>? NodeNames { get; set; }
    public ManifestApi Api { get; set; } = new();
    public List<ManifestEndpoint> Endpoints { get; set; } = new();
}

public sealed record ManifestImportReport(
    string Api, int CreatedNodes, int CreatedPermissions, int CreatedEndpoints, int UpdatedEndpoints,
    IReadOnlyList<string> UnmappedEndpoints, IReadOnlyList<string> Warnings, int CreatedExternalDependencies = 0);

/// <summary>
/// Esnek kaynak kataloğu yönetimi. Catalog Level kodu değiştirilemez; seviye sayısı sınırsızdır.
/// Bir level Tenant, optional Application veya başka bir Catalog Level altında bulunabilir.
/// </summary>
public sealed class CatalogService(IYetkiDbContext db, OutboxWriter outbox, AuditWriter audit, IIdentityProvider identities)
{
    public async Task<CatalogApplication> CreateApplicationAsync(ApplicationUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Applications.AnyAsync(a => a.Code == code, ct)) throw new ConflictException($"Uygulama kodu zaten var: {code}");
        if (!await db.Tenants.AnyAsync(t => t.Id == dto.TenantId, ct)) throw new ValidationException("Uygulamanın sahibi olan tenant seçilmeli.");
        var ownerTeam = await ValidateOwnershipAsync(dto.TenantId, dto.OwnerTeamId, dto.OwnerUserId, ct);
        var app = new CatalogApplication
        {
            TenantId = dto.TenantId, Code = code, Name = dto.Name, Description = dto.Description, Type = dto.Type,
            OwnerTeamId = dto.OwnerTeamId, OwnerUserId = dto.OwnerUserId, OwnerTeam = ownerTeam, IsActive = dto.IsActive
        };
        db.Applications.Add(app);
        Changed("ApplicationCreated", code, $"Uygulama eklendi: {code} ({dto.Type})", dto);
        await db.SaveChangesAsync(ct);
        return app;
    }

    public async Task UpdateApplicationAsync(int id, ApplicationUpsert dto, CancellationToken ct)
    {
        var app = await db.Applications.FindAsync([id], ct) ?? throw new NotFoundException("Uygulama", id);
        var ownerTeam = await ValidateOwnershipAsync(app.TenantId, dto.OwnerTeamId, dto.OwnerUserId, ct);
        app.Name = dto.Name; app.Description = dto.Description; app.Type = dto.Type;
        app.OwnerTeamId = dto.OwnerTeamId; app.OwnerUserId = dto.OwnerUserId; app.OwnerTeam = ownerTeam; app.IsActive = dto.IsActive;
        Changed("ApplicationUpdated", app.Code, $"Uygulama güncellendi: {app.Code}", dto);
        await db.SaveChangesAsync(ct);
    }

    public async Task<CatalogNode> CreateNodeAsync(NodeUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (code.Contains('/') || code.Contains('.') || code.Contains(':')) throw new ValidationException("Düğüm kodu '/', '.', ':' içeremez.");
        CatalogNode? parent = null;
        CatalogApplication? app = null;
        int tenantId;
        if (dto.ParentId is { } pid)
        {
            parent = await db.CatalogNodes.FindAsync([pid], ct) ?? throw new NotFoundException("Düğüm", pid);
            tenantId = parent.TenantId;
            if (parent.ApplicationId is { } parentAppId) app = await db.Applications.FindAsync([parentAppId], ct);
        }
        else if (dto.ApplicationId is { } appId)
        {
            app = await db.Applications.FindAsync([appId], ct) ?? throw new NotFoundException("Application", appId);
            tenantId = app.TenantId;
            if (dto.TenantId != 0 && dto.TenantId != tenantId) throw new ValidationException("Application farklı bir Tenant'a ait.");
        }
        else
        {
            if (dto.TenantId == 0) throw new ValidationException("Root Catalog Level için Tenant veya Application seçilmelidir.");
            if (!await db.Tenants.AnyAsync(t => t.Id == dto.TenantId, ct)) throw new NotFoundException("Tenant", dto.TenantId);
            tenantId = dto.TenantId;
        }
        var applicationId = app?.Id;
        if (await db.CatalogNodes.AnyAsync(n => n.TenantId == tenantId && n.ApplicationId == applicationId && n.ParentId == dto.ParentId && n.Code == code, ct))
            throw new ConflictException($"Bu seviyede '{code}' zaten var.");

        var ownerTeam = await ValidateOwnershipAsync(tenantId, dto.OwnerTeamId, dto.OwnerUserId, ct);
        var node = new CatalogNode
        {
            TenantId = tenantId, ApplicationId = app?.Id, ParentId = parent?.Id, Code = code, Name = dto.Name, Description = dto.Description,
            OwnerTeamId = dto.OwnerTeamId, OwnerUserId = dto.OwnerUserId, OwnerTeam = ownerTeam,
            Type = CatalogNodeType.Level,
            Path = $"{parent?.Path ?? app?.Code ?? (await db.Tenants.Where(t => t.Id == tenantId).Select(t => t.Code).FirstAsync(ct))}/{code}"
        };
        db.CatalogNodes.Add(node);
        Changed("CatalogNodeCreated", node.Path, $"Katalog düğümü eklendi: {node.Path} ({node.Type})", dto);
        await db.SaveChangesAsync(ct);
        return node;
    }

    public async Task UpdateNodeAsync(int id, NodeUpsert dto, CancellationToken ct)
    {
        var node = await db.CatalogNodes.FindAsync([id], ct) ?? throw new NotFoundException("Düğüm", id);
        var ownerTeam = await ValidateOwnershipAsync(node.TenantId, dto.OwnerTeamId, dto.OwnerUserId, ct);
        node.Name = dto.Name; node.Description = dto.Description;
        node.OwnerTeamId = dto.OwnerTeamId; node.OwnerUserId = dto.OwnerUserId; node.OwnerTeam = ownerTeam;
        Changed("CatalogNodeUpdated", node.Path, $"Katalog düğümü güncellendi: {node.Path}", dto);
        await db.SaveChangesAsync(ct);
    }

    public async Task DeleteNodeAsync(int id, CancellationToken ct)
    {
        var node = await db.CatalogNodes.FindAsync([id], ct) ?? throw new NotFoundException("Düğüm", id);
        var childCount = await db.CatalogNodes.CountAsync(n => n.ParentId == id, ct);
        var permCount = await db.Permissions.CountAsync(p => p.CatalogNodeId == id, ct);
        var apiCount = await db.ApiResources.CountAsync(a => a.CatalogNodeId == id, ct);
        var uiCount = await db.UiElements.CountAsync(u => u.CatalogNodeId == id, ct);
        var policyTargetCount = await db.PolicyTargets.CountAsync(t => t.CatalogNodeId == id, ct);
        var grantCount = await db.ClientPermissionGrants.CountAsync(g => g.CatalogNodeId == id, ct);
        if (childCount + permCount + apiCount + uiCount + policyTargetCount + grantCount > 0)
            throw new ConflictException($"'{node.Path}' kullanımda; silinemez.", new
            {
                children = childCount, permissions = permCount, apis = apiCount,
                uiElements = uiCount, policyTargets = policyTargetCount, clientGrants = grantCount
            });
        db.CatalogNodes.Remove(node);
        Changed("CatalogNodeDeleted", node.Path, $"Katalog düğümü silindi: {node.Path}", new { id });
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Düğüm yolundan permission kodu: ANKA/NAKIT/CEKIM/GISE + create → anka.nakit.cekim.gise:create</summary>
    public static string PermissionCodeFor(string nodePath, string action) =>
        $"{string.Join('.', nodePath.Split('/')).ToLowerInvariant()}:{Codes.Lower(action)}";

    /// <summary>Endpoint operationId'si; yoksa HTTP method + path üzerinden kararlı ve okunabilir bir segment üretir.</summary>
    public static string EndpointOperationKey(string? operationId, string method, string path)
    {
        var raw = string.IsNullOrWhiteSpace(operationId) ? $"{method}.{path}" : operationId;
        var key = Regex.Replace(raw.Trim().ToLowerInvariant(), "[^a-z0-9]+", ".").Trim('.');
        if (string.IsNullOrWhiteSpace(key)) key = "operation";
        if (key.Length <= 72) return key;
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(key)))[..8].ToLowerInvariant();
        return $"{key[..63].TrimEnd('.')}.{hash}";
    }

    public static string PermissionCodeForEndpoint(string nodePath, string apiCode, string? operationId, string method, string path, string action)
    {
        var suffix = $":{Codes.Lower(action)}";
        var prefix = $"{string.Join('.', nodePath.Split('/')).ToLowerInvariant()}.{Codes.Lower(apiCode)}.{EndpointOperationKey(operationId, method, path)}";
        if (prefix.Length + suffix.Length <= 160) return prefix + suffix;
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(prefix)))[..8].ToLowerInvariant();
        var take = 160 - suffix.Length - hash.Length - 1;
        return $"{prefix[..take].TrimEnd('.')}.{hash}{suffix}";
    }

    public async Task<Permission> CreatePermissionAsync(PermissionUpsert dto, CancellationToken ct)
    {
        ApiEndpoint? endpoint = null;
        CatalogNode? node = null;
        CatalogApplication? app = null;
        int tenantId;
        string ownerPath;
        if (dto.ApiEndpointId is { } endpointId)
        {
            endpoint = await db.ApiEndpoints
                .Include(e => e.ApiResource).ThenInclude(a => a.CatalogNode)
                .Include(e => e.ApiResource).ThenInclude(a => a.Application)
                .FirstOrDefaultAsync(e => e.Id == endpointId, ct) ?? throw new NotFoundException("Endpoint", endpointId);
            if (endpoint.PermissionId is not null)
                throw new ConflictException($"{endpoint.Method} {endpoint.Path} zaten bir permission'a eşlenmiş. Önce mevcut eşlemeyi kaldırın.");
            node = endpoint.ApiResource.CatalogNode;
            app = endpoint.ApiResource.Application;
            tenantId = endpoint.ApiResource.TenantId;
            ownerPath = node?.Path ?? app?.Code ?? await db.Tenants.Where(t => t.Id == tenantId).Select(t => t.Code).FirstAsync(ct);
            if (dto.CatalogNodeId is { } requestedNode && requestedNode != node?.Id)
                throw new ValidationException("Endpoint ile Resource aynı katalog düğümünde olmalıdır.");
        }
        else
        {
            if (dto.CatalogNodeId is not { } nodeId) throw new ValidationException("Resource permission için Catalog Level seçilmelidir.");
            node = await db.CatalogNodes.Include(n => n.Application).FirstOrDefaultAsync(n => n.Id == nodeId, ct) ?? throw new NotFoundException("Catalog Level", nodeId);
            app = node.Application;
            tenantId = node.TenantId;
            ownerPath = node.Path;
        }
        var action = Codes.Lower(dto.Action);
        var code = endpoint is null
            ? PermissionCodeFor(ownerPath, action)
            : PermissionCodeForEndpoint(ownerPath, endpoint.ApiResource.Code, endpoint.OperationId, endpoint.Method, endpoint.Path, action);
        var exists = endpoint is null
            ? await db.Permissions.AnyAsync(p => p.CatalogNodeId == node!.Id && p.SourceEndpointId == null && p.Action == action, ct)
            : await db.Permissions.AnyAsync(p => p.SourceEndpointId == endpoint.Id && p.Action == action, ct);
        if (exists)
            throw new ConflictException(endpoint is null
                ? $"Bu Resource üzerinde '{action}' action'ı zaten tanımlı."
                : $"Bu Endpoint üzerinde '{action}' action'ı zaten tanımlı.");
        var p = new Permission
        {
            TenantId = tenantId, ApplicationId = app?.Id, CatalogNodeId = node?.Id, SourceEndpointId = endpoint?.Id,
            Code = code, Name = dto.Name, Description = dto.Description, Action = action,
            RiskLevel = dto.RiskLevel, IsActive = dto.IsActive
        };
        db.Permissions.Add(p);
        if (endpoint is not null) endpoint.Permission = p;
        Changed("PermissionCreated", code, endpoint is null
            ? $"Permission eklendi: {code} ({ownerPath})"
            : $"Endpoint permission eklendi: {code} ({endpoint.Method} {endpoint.Path})", dto);
        await db.SaveChangesAsync(ct);
        return p;
    }

    public async Task UpdatePermissionAsync(int id, PermissionUpsert dto, CancellationToken ct)
    {
        var p = await db.Permissions.FindAsync([id], ct) ?? throw new NotFoundException("Permission", id);
        p.Name = dto.Name; p.Description = dto.Description; p.RiskLevel = dto.RiskLevel; p.IsActive = dto.IsActive;
        Changed("PermissionUpdated", p.Code, $"Permission güncellendi: {p.Code} (aktif={dto.IsActive})", dto);
        await db.SaveChangesAsync(ct);
    }

    public async Task<ApiResource> CreateApiAsync(ApiUpsert dto, CancellationToken ct)
    {
        CatalogNode? node = null;
        CatalogApplication? app = null;
        int tenantId;
        if (dto.CatalogNodeId is { } nodeId)
        {
            node = await db.CatalogNodes.Include(n => n.Application).FirstOrDefaultAsync(n => n.Id == nodeId, ct) ?? throw new NotFoundException("Catalog Level", nodeId);
            app = node.Application;
            tenantId = node.TenantId;
        }
        else if (dto.ApplicationId is { } appId)
        {
            app = await db.Applications.FindAsync([appId], ct) ?? throw new NotFoundException("Application", appId);
            tenantId = app.TenantId;
        }
        else
        {
            if (dto.TenantId == 0 || !await db.Tenants.AnyAsync(t => t.Id == dto.TenantId, ct)) throw new NotFoundException("Tenant", dto.TenantId);
            tenantId = dto.TenantId;
        }
        var code = Codes.Lower(dto.Code);
        if (string.IsNullOrWhiteSpace(code)) throw new ValidationException("API kodu zorunlu.");
        if (await db.ApiResources.AnyAsync(a => a.Code == code, ct)) throw new ConflictException($"API kodu zaten var: {code}");
        var api = new ApiResource
        {
            TenantId = tenantId, ApplicationId = app?.Id, CatalogNodeId = node?.Id, Code = code, Name = dto.Name, Version = dto.Version, BasePath = dto.BasePath, IsActive = dto.IsActive,
            Audience = string.IsNullOrWhiteSpace(dto.Audience) ? $"api://{(app?.Code ?? await db.Tenants.Where(t => t.Id == tenantId).Select(t => t.Code).FirstAsync(ct)).ToLowerInvariant()}/{code}" : dto.Audience.Trim()
        };
        db.ApiResources.Add(api);
        Changed("ApiCreated", code, $"API eklendi: {code} ({node?.Path ?? app?.Code ?? $"Tenant #{tenantId}"})", dto);
        await db.SaveChangesAsync(ct);
        return api;
    }

    public async Task DeleteApiAsync(int id, CancellationToken ct)
    {
        var api = await db.ApiResources.FindAsync([id], ct) ?? throw new NotFoundException("API", id);
        var endpointCount = await db.ApiEndpoints.CountAsync(e => e.ApiResourceId == id, ct);
        var depCount = await db.ExternalDependencies.CountAsync(d => d.ApiResourceId == id, ct);
        if (endpointCount + depCount > 0)
            throw new ConflictException($"'{api.Code}' kullanımda; silinemez.", new { endpoints = endpointCount, externalDependencies = depCount });
        db.ApiResources.Remove(api);
        Changed("ApiDeleted", api.Code, $"API silindi: {api.Code}", new { id });
        await db.SaveChangesAsync(ct);
    }

    public async Task<ApiEndpoint> AddEndpointAsync(int apiId, EndpointUpsert dto, CancellationToken ct)
    {
        var api = await db.ApiResources.FindAsync([apiId], ct) ?? throw new NotFoundException("API", apiId);
        var method = dto.Method.Trim().ToUpperInvariant();
        var path = NormalizePath(dto.Path);
        if (await db.ApiEndpoints.AnyAsync(e => e.ApiResourceId == apiId && e.Method == method && e.Path == path, ct)) throw new ConflictException($"{method} {path} zaten var.");
        if (dto.PermissionId is { } pid && !await db.Permissions.AnyAsync(p => p.Id == pid, ct)) throw new NotFoundException("Permission", pid);
        var e = new ApiEndpoint { ApiResourceId = apiId, Method = method, Path = path, OperationId = dto.OperationId, Summary = dto.Summary, PermissionId = dto.PermissionId };
        db.ApiEndpoints.Add(e);
        Changed("EndpointCreated", api.Code, $"Endpoint eklendi: {method} {api.Code}{path}", dto);
        await db.SaveChangesAsync(ct);
        return e;
    }

    public async Task UpdateEndpointAsync(int id, EndpointUpsert dto, CancellationToken ct)
    {
        var e = await db.ApiEndpoints.Include(x => x.ApiResource).FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Endpoint", id);
        if (dto.PermissionId is { } pid && !await db.Permissions.AnyAsync(p => p.Id == pid, ct)) throw new NotFoundException("Permission", pid);
        e.Summary = dto.Summary; e.OperationId = dto.OperationId; e.PermissionId = dto.PermissionId;
        Changed("EndpointUpdated", e.ApiResource.Code, $"Endpoint eşlemesi güncellendi: {e.Method} {e.ApiResource.Code}{e.Path} → #{dto.PermissionId}", dto);
        await db.SaveChangesAsync(ct);
    }

    public async Task DeleteEndpointAsync(int id, CancellationToken ct)
    {
        var e = await db.ApiEndpoints.Include(x => x.ApiResource).FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Endpoint", id);
        var permCount = await db.Permissions.CountAsync(p => p.SourceEndpointId == id, ct);
        var depCount = await db.ExternalDependencies.CountAsync(d => d.ApiEndpointId == id, ct);
        if (permCount + depCount > 0)
            throw new ConflictException($"'{e.Method} {e.ApiResource.Code}{e.Path}' kullanımda; silinemez.", new { permissions = permCount, externalDependencies = depCount });
        db.ApiEndpoints.Remove(e);
        Changed("EndpointDeleted", e.ApiResource.Code, $"Endpoint silindi: {e.Method} {e.ApiResource.Code}{e.Path}");
        await db.SaveChangesAsync(ct);
    }

    public async Task<UiElement> CreateUiElementAsync(UiElementUpsert dto, CancellationToken ct)
    {
        var node = await db.CatalogNodes.FindAsync([dto.CatalogNodeId], ct) ?? throw new NotFoundException("Düğüm", dto.CatalogNodeId);
        var code = Codes.Normalize(dto.Code);
        if (await db.UiElements.AnyAsync(e => e.CatalogNodeId == node.Id && e.Code == code, ct)) throw new ConflictException($"UI öğesi zaten var: {code}");
        if (dto.ParentId is { } p && !await db.UiElements.AnyAsync(e => e.Id == p, ct)) throw new NotFoundException("Üst UI öğesi", p);
        var e = new UiElement { CatalogNodeId = node.Id, ParentId = dto.ParentId, Kind = dto.Kind, Code = code, Name = dto.Name, Order = dto.Order, PermissionId = dto.PermissionId };
        db.UiElements.Add(e);
        Changed("UiElementCreated", code, $"UI öğesi eklendi: {node.Path}/{code} ({dto.Kind})", dto);
        await db.SaveChangesAsync(ct);
        return e;
    }

    public async Task UpdateUiElementAsync(int id, UiElementUpsert dto, CancellationToken ct)
    {
        var e = await db.UiElements.FindAsync([id], ct) ?? throw new NotFoundException("UI öğesi", id);
        e.Name = dto.Name; e.Order = dto.Order; e.PermissionId = dto.PermissionId; e.Kind = dto.Kind;
        Changed("UiElementUpdated", e.Code, $"UI öğesi güncellendi: {e.Code} → #{dto.PermissionId}", dto);
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Servis manifestini içe aktarır (idempotent): eksik düğümler, permission'lar, API ve endpoint'ler oluşturulur/güncellenir.</summary>
    public async Task<ManifestImportReport> ImportManifestAsync(ServiceManifest m, CancellationToken ct)
    {
        var warnings = new List<string>();
        var app = await db.Applications.FirstOrDefaultAsync(a => a.Code == Codes.Normalize(m.Application), ct) ?? throw new NotFoundException("Uygulama", m.Application);
        var segments = m.CatalogPath.Split('/', StringSplitOptions.RemoveEmptyEntries).Select(Codes.Normalize).ToList();
        if (segments.Count < 1) throw new ValidationException("CatalogPath en az bir seviye içermelidir.");

        var createdNodes = 0;
        CatalogNode? node = null;
        foreach (var seg in segments)
        {
            var parentId = node?.Id;
            var existing = await db.CatalogNodes.FirstOrDefaultAsync(n => n.ApplicationId == app.Id && n.ParentId == parentId && n.Code == seg, ct);
            if (existing is null)
            {
                existing = new CatalogNode
                {
                    TenantId = app.TenantId, ApplicationId = app.Id, ParentId = parentId, Code = seg, Name = m.NodeNames?.GetValueOrDefault(seg) ?? seg,
                    Type = CatalogNodeType.Level,
                    Path = $"{node?.Path ?? app.Code}/{seg}"
                };
                db.CatalogNodes.Add(existing);
                await db.SaveChangesAsync(ct);
                createdNodes++;
            }
            node = existing;
        }

        var apiCode = Codes.Lower(m.Api.Code);
        var api = await db.ApiResources.FirstOrDefaultAsync(a => a.Code == apiCode, ct);
        if (api is null)
        {
            api = new ApiResource
            {
                TenantId = app.TenantId, ApplicationId = app.Id, CatalogNodeId = node!.Id, Code = apiCode, Name = m.Api.Name, Version = m.Api.Version, BasePath = m.Api.BasePath,
                Audience = m.Api.Audience ?? $"api://{app.Code.ToLowerInvariant()}/{apiCode}"
            };
            db.ApiResources.Add(api);
            await db.SaveChangesAsync(ct);
        }
        else if (api.CatalogNodeId != node!.Id) warnings.Add($"API '{apiCode}' kataloğun başka bir yerinde kayıtlı; yeri değiştirilmedi.");

        int createdPerms = 0, createdEps = 0, updatedEps = 0, createdDeps = 0;
        var unmapped = new List<string>();
        createdDeps += await ImportExternalAsync(m.Api.External, api.Id, null, $"API {apiCode}", warnings, ct);
        foreach (var ep in m.Endpoints)
        {
            var method = ep.Method.Trim().ToUpperInvariant();
            var path = NormalizePath(ep.Path);
            var existing = await db.ApiEndpoints.FirstOrDefaultAsync(e => e.ApiResourceId == api.Id && e.Method == method && e.Path == path, ct);
            var endpointCreated = existing is null;
            if (existing is null)
            {
                existing = new ApiEndpoint { ApiResourceId = api.Id, Method = method, Path = path, OperationId = ep.OperationId, Summary = ep.Summary };
                db.ApiEndpoints.Add(existing);
                await db.SaveChangesAsync(ct);
                createdEps++;
            }

            int? permissionId = null;
            var action = !string.IsNullOrWhiteSpace(ep.Action)
                ? Codes.Lower(ep.Action)
                : !string.IsNullOrWhiteSpace(ep.Permission) ? Codes.ActionOf(Codes.Lower(ep.Permission)) : null;
            if (action is not null)
            {
                var code = PermissionCodeForEndpoint(node!.Path, api.Code, ep.OperationId, method, path, action);
                if (!string.IsNullOrWhiteSpace(ep.Permission) && !string.Equals(Codes.Lower(ep.Permission), code, StringComparison.Ordinal))
                    warnings.Add($"Legacy permission '{ep.Permission}' yerine Endpoint operation + Action anahtarı '{code}' kullanıldı.");
                var perm = await db.Permissions.FirstOrDefaultAsync(p => p.Code == code, ct);
                if (perm is null)
                {
                    perm = new Permission
                    {
                        TenantId = app.TenantId, ApplicationId = app.Id, CatalogNodeId = node.Id, SourceEndpointId = existing.Id, Code = code, Name = ep.PermissionName ?? ep.Summary ?? action, Action = action,
                        RiskLevel = ep.RiskLevel ?? Severity.Medium
                    };
                    db.Permissions.Add(perm);
                    await db.SaveChangesAsync(ct);
                    createdPerms++;
                }
                else if (perm.SourceEndpointId != existing.Id) warnings.Add($"{code} başka bir endpoint üzerinde tanımlı; mevcut tanım kullanıldı.");
                permissionId = perm.Id;
            }
            else unmapped.Add($"{method} {path}");

            if (existing.PermissionId != permissionId || existing.Summary != ep.Summary || existing.OperationId != ep.OperationId)
            {
                if (existing.PermissionId is not null && permissionId is not null && existing.PermissionId != permissionId)
                    warnings.Add($"{method} {path}: permission eşlemesi değişti (servis manifesti otoritedir).");
                existing.PermissionId = permissionId; existing.Summary = ep.Summary; existing.OperationId = ep.OperationId;
                if (!endpointCreated) updatedEps++;
                await db.SaveChangesAsync(ct);
            }
            createdDeps += await ImportExternalAsync(ep.External, null, existing.Id, $"{method} {apiCode}{path}", warnings, ct);
        }

        if (createdDeps > 0)
            outbox.Add(EventTypes.ExternalRequirementsChanged, "Catalog", apiCode, new ExternalRequirementsChangedPayload([], $"Manifest {apiCode}: {createdDeps} yeni dış bağımlılık"));
        var report = new ManifestImportReport(apiCode, createdNodes, createdPerms, createdEps, updatedEps, unmapped, warnings, createdDeps);
        Changed("ManifestImported", apiCode,
            $"Manifest içe aktarıldı: {apiCode} ({node!.Path}) — {createdPerms} yeni permission, {createdEps} yeni / {updatedEps} güncellenen endpoint, {unmapped.Count} eşlenmemiş", report);
        await db.SaveChangesAsync(ct);
        return report;
    }

    /// <summary>
    /// Manifestteki dış bağımlılıkları ekler (idempotent; manifestte olmayan mevcut bağımlılıklar silinmez).
    /// Dış sistem kayıtlı olmalı; dış yetki yoksa oluşturulur (uyarıyla).
    /// </summary>
    private async Task<int> ImportExternalAsync(List<ManifestExternal> items, int? apiId, int? endpointId, string owner, List<string> warnings, CancellationToken ct)
    {
        var created = 0;
        foreach (var x in items)
        {
            var sysCode = Codes.Normalize(x.System);
            var sys = await db.ExternalSystems.FirstOrDefaultAsync(s => s.Code == sysCode, ct);
            if (sys is null) { warnings.Add($"{owner}: dış sistem '{sysCode}' kayıtlı değil; bağımlılık atlandı."); continue; }
            var code = x.Code.Trim().ToUpperInvariant();
            var ext = await db.ExternalPermissions.FirstOrDefaultAsync(p => p.ExternalSystemId == sys.Id && p.Code == code, ct);
            if (ext is null)
            {
                ext = new ExternalPermission { ExternalSystemId = sys.Id, Code = code, Name = x.Name, ResourceClass = x.ResourceClass?.Trim().ToUpperInvariant() };
                db.ExternalPermissions.Add(ext);
                await db.SaveChangesAsync(ct);
                warnings.Add($"{owner}: yeni dış yetki oluşturuldu {sysCode}:{code} (sahibi ekip tarafından gözden geçirilmeli).");
            }
            if (await db.ExternalDependencies.AnyAsync(d => d.ApiResourceId == apiId && d.ApiEndpointId == endpointId && d.PermissionId == null && d.ExternalPermissionId == ext.Id, ct))
                continue;
            db.ExternalDependencies.Add(new ExternalDependency
            {
                ApiResourceId = apiId, ApiEndpointId = endpointId, ExternalPermissionId = ext.Id,
                AccessLevel = sys.HasAccessLevels ? x.Access : null, Note = "manifest"
            });
            created++;
        }
        return created;
    }

    private static string NormalizePath(string path)
    {
        var p = "/" + path.Trim().Split('?')[0].Trim('/');
        return p == "/" ? p : p.TrimEnd('/');
    }

    private async Task<string?> ValidateOwnershipAsync(int tenantId, int? teamId, int? userId, CancellationToken ct)
    {
        string? teamName = null;
        if (teamId is { } tid)
        {
            var team = await db.OwnershipTeams.AsNoTracking().FirstOrDefaultAsync(t => t.Id == tid, ct)
                ?? throw new NotFoundException("Ownership Team", tid);
            if (team.TenantId != tenantId) throw new ValidationException("Ownership Team katalog kaydıyla aynı Tenant'a ait olmalıdır.");
            if (!team.IsActive) throw new ValidationException("Pasif Ownership Team seçilemez.");
            teamName = team.Name;
        }
        if (userId is { } uid)
        {
            var user = await identities.GetUserAsync(uid, ct) ?? throw new NotFoundException("Owner User", uid);
            if (user.TenantId != tenantId) throw new ValidationException("Owner User katalog kaydıyla aynı Tenant'a ait olmalıdır.");
            if (!user.IsActive) throw new ValidationException("Pasif User sahip olarak seçilemez.");
        }
        return teamName;
    }

    private void Changed(string action, string id, string summary, object? details = null)
    {
        audit.Management(action, "Catalog", id, summary, details);
        outbox.Add(EventTypes.CatalogChanged, "Catalog", id, new { action, id });
    }
}
