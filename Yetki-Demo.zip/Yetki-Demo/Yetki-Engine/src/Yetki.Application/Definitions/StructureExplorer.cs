using Yetki.Application.Identity;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;

namespace Yetki.Application.Definitions;

public sealed record ExplorerItem
{
    public string Kind { get; init; } = "";
    public int Id { get; init; }
    public string Code { get; init; } = "";
    public string Name { get; init; } = "";
    public string Type { get; init; } = "";
    public string? Description { get; init; }
    public bool? Active { get; init; }
    public int? TenantId { get; init; }
    public int? ApplicationId { get; init; }
    public int? ResourceId { get; init; }
    public int? PermissionId { get; init; }
    public int? ParentId { get; init; }
    public string? Annotation { get; init; }
    public int Order { get; init; }
}

public sealed record ExplorerRelation(string Key, string Label, int Count);
public sealed record ExplorerPage(ExplorerItem? Current, IReadOnlyList<ExplorerRelation> Relations,
    string Relation, IReadOnlyList<ExplorerItem> Items, int Total, int Page, int PageSize, string? Notice);

/// <summary>Loads only one catalog level. Catalog pagination runs in SQL; policy matching uses the existing engine.</summary>
public sealed class StructureExplorer(IYetkiDbContext db, AuthorizationModelProvider models, IIdentityProvider identities)
{
    private IQueryable<ExplorerItem> Tenants => db.Tenants.AsNoTracking().Select(x => new ExplorerItem { Kind = "tenant", Id = x.Id, Code = x.Code, Name = x.Name, Type = x.Type.ToString(), Active = x.IsActive, TenantId = x.Id, ParentId = x.ParentId });
    private IQueryable<ExplorerItem> Apps => db.Applications.AsNoTracking().Select(x => new ExplorerItem { Kind = "application", Id = x.Id, Code = x.Code, Name = x.Name, Type = x.Type.ToString(), Active = x.IsActive, TenantId = x.TenantId, ApplicationId = x.Id, Description = x.Description });
    private IQueryable<ExplorerItem> Resources => db.CatalogNodes.AsNoTracking().Select(x => new ExplorerItem { Kind = "resource", Id = x.Id, Code = x.Code, Name = x.Name, Type = "Catalog Level", TenantId = x.TenantId, ApplicationId = x.ApplicationId, ResourceId = x.Id, ParentId = x.ParentId, Description = x.Path });
    private IQueryable<ExplorerItem> Apis => db.ApiResources.AsNoTracking().Select(x => new ExplorerItem { Kind = "api", Id = x.Id, Code = x.Code, Name = x.Name, Type = "API", Active = x.IsActive, TenantId = x.TenantId, ApplicationId = x.ApplicationId, ResourceId = x.CatalogNodeId, Description = x.Audience });
    private IQueryable<ExplorerItem> Endpoints => db.ApiEndpoints.AsNoTracking().Select(x => new ExplorerItem { Kind = "endpoint", Id = x.Id, Code = x.Method + " " + x.Path, Name = x.Summary ?? x.Path, Type = x.Method, TenantId = x.ApiResource.TenantId, ApplicationId = x.ApiResource.ApplicationId, ResourceId = x.ApiResource.CatalogNodeId, ParentId = x.ApiResourceId, PermissionId = x.PermissionId, Description = x.OperationId });
    private IQueryable<ExplorerItem> Ui => db.UiElements.AsNoTracking().Select(x => new ExplorerItem { Kind = "ui", Id = x.Id, Code = x.Code, Name = x.Name, Type = x.Kind.ToString(), TenantId = x.CatalogNode.TenantId, ApplicationId = x.CatalogNode.ApplicationId, ResourceId = x.CatalogNodeId, ParentId = x.ParentId, PermissionId = x.PermissionId });
    private IQueryable<ExplorerItem> Permissions => db.Permissions.AsNoTracking().Select(x => new ExplorerItem { Kind = "permission", Id = x.Id, Code = x.Code, Name = x.Name, Type = x.Action, Active = x.IsActive, TenantId = x.TenantId, ApplicationId = x.ApplicationId, ResourceId = x.CatalogNodeId, Description = x.Description });
    private IQueryable<ExplorerItem> Clients => db.Clients.AsNoTracking().Select(x => new ExplorerItem { Kind = "client", Id = x.Id, Code = x.ClientId, Name = x.Name, Type = x.Type.ToString(), Active = x.IsActive, TenantId = x.TenantId, ApplicationId = x.ApplicationId, Description = x.Description });
    private IQueryable<ExplorerItem> Policies => db.Policies.AsNoTracking().Select(x => new ExplorerItem { Kind = "policy", Id = x.Id, Code = x.Code, Name = x.Name, Type = x.Mode.ToString(), Active = x.IsActive, TenantId = x.TenantId, Description = x.Description });
    private IQueryable<ExplorerItem> External => db.ExternalPermissions.AsNoTracking().Select(x => new ExplorerItem { Kind = "externalPermission", Id = x.Id, Code = x.ExternalSystem.Code + ":" + x.Code, Name = x.Name ?? x.Code, Type = x.ResourceClass ?? "External Permission", ParentId = x.ExternalSystemId, Description = x.Description });

    public async Task<ExplorerPage> BrowseAsync(string kind = "root", int id = 0, int? tenantId = null,
        string? relation = null, string? q = null, int page = 1, int pageSize = 12, CancellationToken ct = default)
    {
        if (page < 1 || page > 100000 || pageSize < 1 || pageSize > 48 || q?.Length > 200)
            throw new ValidationException("Invalid pagination or search query.");
        var queries = new Dictionary<string, (string Label, IQueryable<ExplorerItem> Query)>();
        var lists = new Dictionary<string, (string Label, IReadOnlyList<ExplorerItem> Items)>();
        string? notice = null;
        ExplorerItem? current = null;
        if (kind != "root" && kind != "permissionCatalog")
        {
            var source = kind switch
            {
                "tenant" => Tenants, "application" => Apps, "resource" => Resources, "api" => Apis,
                "endpoint" => Endpoints, "ui" => Ui, "permission" => Permissions, "policy" => Policies,
                "client" => Clients, "externalPermission" => External,
                _ => throw new ValidationException("Unsupported explorer type.")
            };
            current = await source.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException(kind, id);
            if (kind == "tenant") tenantId = id;
        }
        var ancestors = new HashSet<int>();
        if (tenantId is { } tid)
        {
            int? cursor = tid;
            while (cursor is { } t && ancestors.Add(t))
            {
                var tenant = await db.Tenants.AsNoTracking().Where(x => x.Id == t).Select(x => new { x.ParentId }).FirstOrDefaultAsync(ct)
                    ?? throw new NotFoundException("Tenant", t);
                cursor = tenant.ParentId;
            }
            if (current?.TenantId is { } owner && !ancestors.Contains(owner))
                throw new ValidationException("This definition is not available in the selected Tenant.");
        }
        void Add(string key, string label, IQueryable<ExplorerItem> query) => queries.Add(key, (label, query));
        switch (kind)
        {
            case "root": Add("tenants", "Tenants", Tenants); break;
            case "permissionCatalog":
                if (tenantId is null) throw new ValidationException("Tenant is required for Permission search.");
                Add("permissions", "Permissions", Permissions.Where(x => ancestors.Contains(x.TenantId!.Value)));
                break;
            case "tenant":
                Add("platforms", "Platforms", Apps.Where(x => ancestors.Contains(x.TenantId!.Value)));
                Add("levels", "Catalog Levels", Resources.Where(x => x.TenantId == id && x.ApplicationId == null && x.ParentId == null));
                Add("apis", "APIs", Apis.Where(x => x.TenantId == id && x.ApplicationId == null && x.ResourceId == null));
                Add("clients", "Clients", Clients.Where(x => ancestors.Contains(x.TenantId!.Value)));
                notice = "Applications are optional. Catalog Levels and APIs can also be owned directly by this Tenant.";
                break;
            case "application":
                Add("resources", "Catalog Levels", Resources.Where(x => x.ApplicationId == id && x.ParentId == null));
                Add("apis", "APIs", Apis.Where(x => x.ApplicationId == id && x.ResourceId == null));
                break;
            case "resource":
                Add("resources", "Child Catalog Levels", Resources.Where(x => x.ParentId == id));
                Add("apis", "APIs", Apis.Where(x => x.ResourceId == id));
                // A UI parent can live in another catalog node. Such entries must remain reachable here.
                var localUiIds = db.UiElements.Where(x => x.CatalogNodeId == id).Select(x => x.Id);
                Add("ui", "Screens & UI", Ui.Where(x => x.ResourceId == id && (x.ParentId == null || !localUiIds.Contains(x.ParentId.Value))));
                Add("permissions", "Permissions", Permissions.Where(x => x.ResourceId == id));
                break;
            case "api":
                Add("endpoints", "Endpoints", Endpoints.Where(x => x.ParentId == id));
                Add("external", "External Dependencies", External.Where(x => db.ExternalDependencies.Any(d => d.ApiResourceId == id && d.ExternalPermissionId == x.Id)));
                break;
            case "endpoint":
                Add("permissions", "Permission", Permissions.Where(x => x.Id == current!.PermissionId));
                Add("external", "External Dependencies", External.Where(x => db.ExternalDependencies.Any(d => (d.ApiEndpointId == id || d.ApiResourceId == current!.ParentId) && d.ExternalPermissionId == x.Id)));
                if (current!.PermissionId is null) notice = "Unmapped Endpoint. The authorization engine denies requests until a Permission is assigned.";
                break;
            case "ui":
                Add("ui", "UI Elements", Ui.Where(x => x.ParentId == id));
                Add("permissions", "Permission", Permissions.Where(x => x.Id == current!.PermissionId));
                if (current!.PermissionId is null) notice = "No direct Permission mapping. Visibility can still depend on the parent UI Element.";
                break;
            case "permission":
                var model = await models.GetCurrentAsync(ct);
                var matching = model.GetApplicablePolicies(id, tenantId ?? current!.TenantId!.Value);
                string TargetLabel(string value) => value == "Tümü" ? "All Resources" : value.StartsWith("Uygulama ") ? "Platform " + value[9..] : value.StartsWith("Düğüm ") ? "Resource " + value[6..] : value;
                ExplorerItem PolicyItem(CompiledPolicy p, string match, string? excluded = null) => new()
                {
                    Kind = "policy", Id = p.Row.Id, Code = p.Row.Code, Name = p.Row.Name, Type = p.Row.Mode.ToString(),
                    TenantId = p.Row.TenantId, Active = p.Row.IsActive,
                    Annotation = excluded is null ? "Matched: " + TargetLabel(match) : "Excluded: " + TargetLabel(excluded),
                    Description = p.IncludeClients.Count + p.ExcludeClients.Count > 0 ? "Client targeting applies. Inspect the Policy before interpreting its runtime effect." : "Tenant and Resource targeting"
                };
                lists.Add("policies", ("Policies", matching.Applied.Select(x => PolicyItem(x.Policy, x.MatchedBy)).ToList()));
                lists.Add("excluded", ("Excluded Policies", matching.Excluded.Select(x => PolicyItem(x.Policy, x.MatchedBy, x.ExcludedBy)).ToList()));
                lists.Add("roles", ("Roles", model.Roles.Values.Where(r => model.RolePermissionIds(r.Id).Contains(id)
                    && (r.TenantId == (tenantId ?? current!.TenantId) || (r.IsInheritable && ancestors.Contains(r.TenantId))))
                    .Select(r => new ExplorerItem { Kind = "role", Id = r.Id, Code = r.Code, Name = r.Name, Active = r.IsActive, Type = "Role", TenantId = r.TenantId }).ToList()));
                Add("endpoints", "Endpoints", Endpoints.Where(x => x.PermissionId == id));
                Add("ui", "UI Elements", Ui.Where(x => x.PermissionId == id));
                Add("external", "External Dependencies", External.Where(x => db.ExternalDependencies.Any(d => d.ExternalPermissionId == x.Id &&
                    (d.PermissionId == id || db.ApiEndpoints.Any(e => e.PermissionId == id && (d.ApiEndpointId == e.Id || d.ApiResourceId == e.ApiResourceId))))));
                notice = "Policies are matched for the selected Tenant, including inherited targets and exclusions. Client targeting and runtime conditions are evaluated when a request is made.";
                break;
            case "policy":
                var policyModel = await models.GetCurrentAsync(ct);
                var policy = policyModel.Policies[id];
                lists.Add("rules", ("Rules", policy.Definition.Rules.OrderBy(r => r.Order).Select(r => new ExplorerItem
                { Kind = "rule", Id = r.RuleId, Code = r.Code, Name = r.Name, Type = "Rule", Active = r.IsActive, ParentId = id, Order = r.Order, Description = PolicyEvaluator.Render(r.Condition), Annotation = $"Order {r.Order} · {r.ReasonCode}" }).ToList()));
                var clientIds = policy.IncludeClients.Concat(policy.ExcludeClients).Select(x => x.ClientId).ToArray();
                var includedClientIds = policy.IncludeClients.Select(x => x.ClientId).ToArray();
                Add("clients", "Client Targets", Clients.Where(x => clientIds.Contains(x.Id)).Select(x => new ExplorerItem
                { Kind = x.Kind, Id = x.Id, Code = x.Code, Name = x.Name, Type = x.Type, TenantId = x.TenantId, Active = x.Active, Annotation = includedClientIds.Contains(x.Id) ? "Include" : "Exclude" }));
                notice = $"{policy.Row.Algorithm} · {policy.Row.Mode}. Client targets: {policy.IncludeClients.Count} Include / {policy.ExcludeClients.Count} Exclude. Open Policy management to edit targets and conditions.";
                break;
            case "externalPermission":
                Add("external", "Requires", External.Where(x => db.ExternalPermissionRequirements.Any(d => d.ExternalPermissionId == id && d.RequiredExternalPermissionId == x.Id)));
                break;
            case "client":
                notice = "Client identifies the caller. Manage its Resource Scope from Client management.";
                Add("platforms", "Owned Application", Apps.Where(x => x.Id == current!.ApplicationId));
                break;
        }
        var relations = new List<ExplorerRelation>();
        foreach (var (key, value) in lists) relations.Add(new(key, value.Label, value.Items.Count));
        foreach (var (key, value) in queries) relations.Add(new(key, value.Label, await value.Query.CountAsync(ct)));
        if (kind == "tenant") relations.Add(new("users", "Users", (await identities.SearchUsersAsync(new(id, PageSize: 1), ct)).Total));
        var defaultRelation = kind is "resource" or "ui" ? relations.FirstOrDefault(x => x.Count > 0) ?? relations.First() : relations.First();
        var selected = string.IsNullOrEmpty(relation) ? defaultRelation.Key : relation;
        if (!queries.ContainsKey(selected) && !lists.ContainsKey(selected) && !(kind == "tenant" && selected == "users")) throw new ValidationException("Invalid relation for this level.");
        int total;
        IReadOnlyList<ExplorerItem> items;
        if (kind == "tenant" && selected == "users")
        {
            var result = await identities.SearchUsersAsync(new(id, q, page, pageSize), ct);
            total = result.Total; page = result.Page;
            items = result.Items.Select(x => new ExplorerItem
            { Kind = "user", Id = x.Id, Code = x.UserName, Name = x.FullName, Type = x.Kind.ToString(), TenantId = x.TenantId, Active = x.IsActive, Description = x.Title }).ToList();
        }
        else if (queries.TryGetValue(selected, out var dbQuery))
        {
            var query = dbQuery.Query;
            if (!string.IsNullOrWhiteSpace(q)) { var term = q.Trim().ToLower(); query = query.Where(x => x.Code.ToLower().Contains(term) || x.Name.ToLower().Contains(term)); }
            total = await query.CountAsync(ct);
            page = Math.Min(page, Math.Max(1, (int)Math.Ceiling(total / (double)pageSize)));
            items = await query.OrderBy(x => x.Code).ThenBy(x => x.Id).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        }
        else
        {
            var query = lists[selected].Items.Where(x => string.IsNullOrWhiteSpace(q) || x.Code.Contains(q.Trim(), StringComparison.OrdinalIgnoreCase) || x.Name.Contains(q.Trim(), StringComparison.OrdinalIgnoreCase)).OrderBy(x => x.Order).ThenBy(x => x.Code, StringComparer.Ordinal).ThenBy(x => x.Id).ToList();
            total = query.Count;
            page = Math.Min(page, Math.Max(1, (int)Math.Ceiling(total / (double)pageSize)));
            items = query.Skip((page - 1) * pageSize).Take(pageSize).ToList();
        }
        return new(current, relations, selected, items, total, page, pageSize, notice);
    }
}
