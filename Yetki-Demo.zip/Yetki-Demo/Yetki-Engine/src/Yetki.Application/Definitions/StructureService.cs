using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Events;

namespace Yetki.Application.Definitions;

/// <summary>Haritadan yalnızca görünen adı günceller; kod, sahiplik ve erişim tanımları korunur.</summary>
public sealed class StructureService(IYetkiDbContext db, AuditWriter audit, OutboxWriter outbox)
{
    public async Task MapPermissionAsync(string kind, int id, int? permissionId, CancellationToken ct)
    {
        if (permissionId is { } pid && !await db.Permissions.AnyAsync(x => x.Id == pid, ct))
            throw new NotFoundException("Permission", pid);
        int? before;
        if (kind == "endpoint")
        {
            var entity = await db.ApiEndpoints.FindAsync([id], ct) ?? throw new NotFoundException("Endpoint", id);
            before = entity.PermissionId;
            entity.PermissionId = permissionId;
        }
        else if (kind == "ui")
        {
            var entity = await db.UiElements.FindAsync([id], ct) ?? throw new NotFoundException("UI Element", id);
            before = entity.PermissionId;
            entity.PermissionId = permissionId;
        }
        else throw new ValidationException("Only Endpoint and UI Element mappings are supported.");
        if (before == permissionId) return;
        var change = new { kind, id, before, after = permissionId };
        audit.Management("StructurePermissionMapped", kind, id, "Permission mapping updated", change);
        outbox.Add("StructurePermissionMapped", kind, id, change);
        await db.SaveChangesAsync(ct);
    }

    public async Task RenameAsync(string kind, int id, string name, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(name) || name.Trim().Length > 200)
            throw new ValidationException("Ad 1–200 karakter olmalıdır.");
        name = name.Trim();
        switch (kind)
        {
            case "tenant": await Rename(db.Tenants, e => e.Name, (e, v) => e.Name = v); break;
            case "client": await Rename(db.Clients, e => e.Name, (e, v) => e.Name = v); break;
            case "application": await Rename(db.Applications, e => e.Name, (e, v) => e.Name = v); break;
            case "resource": await Rename(db.CatalogNodes, e => e.Name, (e, v) => e.Name = v); break;
            case "permission": await Rename(db.Permissions, e => e.Name, (e, v) => e.Name = v); break;
            case "api": await Rename(db.ApiResources, e => e.Name, (e, v) => e.Name = v); break;
            case "ui": await Rename(db.UiElements, e => e.Name, (e, v) => e.Name = v); break;
            case "externalSystem": await Rename(db.ExternalSystems, e => e.Name, (e, v) => e.Name = v); break;
            case "externalPermission": await Rename(db.ExternalPermissions, e => e.Name, (e, v) => e.Name = v); break;
            default: throw new ValidationException("Desteklenmeyen düğüm türü.");
        }
        await db.SaveChangesAsync(ct);

        async Task Rename<T>(DbSet<T> set, Func<T, string?> getName, Action<T, string> setName) where T : class
        {
            var entity = await set.FindAsync([id], ct) ?? throw new NotFoundException(kind, id);
            var before = getName(entity);
            if (before == name) return;
            setName(entity, name);
            var change = new { kind, id, before, after = name };
            audit.Management("StructureNodeRenamed", kind, id, $"Düğüm adı güncellendi: {before} → {name}", change);
            outbox.Add("StructureNodeRenamed", kind, id, change);
        }
    }
}
