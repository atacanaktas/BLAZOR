using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Events;
using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Domain.Common;
using Yetki.Domain.Policies;

namespace Yetki.Application.Definitions;

public sealed class PolicyUpsert
{
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public CombiningAlgorithm CombiningAlgorithm { get; set; } = CombiningAlgorithm.AllRulesMustPass;
    public PolicyMode Mode { get; set; } = PolicyMode.Enforce;
    public bool IsActive { get; set; } = true;
}

public sealed class RuleUpsert
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public int Order { get; set; }
    public string? ReasonCode { get; set; }
    public bool IsActive { get; set; } = true;
    public ConditionDraft Condition { get; set; } = new();
}

public sealed class TargetUpsert
{
    public InclusionMode Mode { get; set; } = InclusionMode.Include;
    public TargetType TargetType { get; set; }
    public int? TargetId { get; set; }
    /// <summary>Opsiyonel action filtresi. Virgülle ayrılır; boşsa hedefteki tüm action'lar kapsanır.</summary>
    public string? Actions { get; set; }
}

/// <summary>Kanal hedefi: Include = policy sadece bu client'tan gelen isteklere; Exclude = bu client hariç.</summary>
public sealed class ClientTargetUpsert
{
    public int ClientId { get; set; }
    public InclusionMode Mode { get; set; } = InclusionMode.Include;
}

public sealed class ObligationUpsert
{
    public string Code { get; set; } = default!;
    public ObligationFulfillOn FulfillOn { get; set; } = ObligationFulfillOn.Permit;
    public int Order { get; set; }
    public Dictionary<string, string> Parameters { get; set; } = new();
}

/// <summary>
/// Policy / hedef / rule / condition yönetimi.
///  - Condition parametreleri ilgili IConditionHandler'a doğrulatılır.
///  - Her değişiklik Policy.Version'ı artırır; kararlar versiyonla audit'lenir; PolicyChanged event'i üretilir.
///  - Etkisi önceden What-If "policy impact" ile görülür (UI kaydetmeden önce önizletir).
/// </summary>
public sealed class PolicyManagementService(
    IYetkiDbContext db,
    ConditionHandlerRegistry handlers,
    OutboxWriter outbox,
    AuditWriter audit)
{
    // ================================ Policy ================================

    public async Task<Policy> CreatePolicyAsync(PolicyUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Policies.AnyAsync(p => p.Code == code, ct)) throw new ConflictException($"Policy kodu zaten var: {code}");
        if (!await db.Tenants.AnyAsync(o => o.Id == dto.TenantId, ct)) throw new NotFoundException("Kurum", dto.TenantId);
        var p = new Policy
        {
            TenantId = dto.TenantId, Code = code, Name = dto.Name, Description = dto.Description,
            CombiningAlgorithm = dto.CombiningAlgorithm, Mode = dto.Mode, IsActive = dto.IsActive, Version = 1
        };
        db.Policies.Add(p);
        audit.Management("PolicyCreated", "Policy", code, $"Policy oluşturuldu: {code} ({dto.Mode}, {dto.CombiningAlgorithm})", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", code, new { action = "created", code });
        await db.SaveChangesAsync(ct);
        return p;
    }

    public async Task UpdatePolicyAsync(int id, PolicyUpsert dto, CancellationToken ct)
    {
        var p = await db.Policies.FindAsync([id], ct) ?? throw new NotFoundException("Policy", id);
        p.Name = dto.Name; p.Description = dto.Description; p.CombiningAlgorithm = dto.CombiningAlgorithm; p.Mode = dto.Mode; p.IsActive = dto.IsActive;
        p.Version++;
        audit.Management("PolicyUpdated", "Policy", p.Code, $"Policy güncellendi: {p.Code} v{p.Version} ({dto.Mode}, {dto.CombiningAlgorithm}, aktif={dto.IsActive})", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", p.Code, new { action = "updated", p.Code, p.Version, dto.Mode, dto.IsActive });
        await db.SaveChangesAsync(ct);
    }

    // ================================ Hedefler ================================

    public async Task<PolicyTarget> AddTargetAsync(int policyId, TargetUpsert dto, CancellationToken ct)
    {
        var p = await db.Policies.FindAsync([policyId], ct) ?? throw new NotFoundException("Policy", policyId);
        var target = await BuildTargetAsync(dto.TargetType, dto.TargetId, ct);
        var actions = NormalizeActions(dto.Actions);
        if (target.Type == TargetType.Permission && actions is not null)
            throw new ValidationException("Permission hedefi zaten tek bir Resource + Action ilişkisidir; ayrıca action filtresi kullanmayın.");
        if (await db.PolicyTargets.AnyAsync(t => t.PolicyId == policyId && t.Mode == dto.Mode && t.TargetType == target.Type
                && t.ApplicationId == target.ApplicationId && t.CatalogNodeId == target.CatalogNodeId && t.PermissionId == target.PermissionId
                && t.Actions == actions, ct))
            throw new ConflictException("Bu hedef zaten tanımlı.");

        var row = new PolicyTarget
        {
            PolicyId = policyId, Mode = dto.Mode, TargetType = target.Type,
            ApplicationId = target.ApplicationId, CatalogNodeId = target.CatalogNodeId, PermissionId = target.PermissionId, Actions = actions
        };
        db.PolicyTargets.Add(row);
        p.Version++;
        var text = (await DescribeAsync(target, ct)) + DescribeActions(actions);
        audit.Management("PolicyTargetAdded", "Policy", p.Code, $"'{p.Code}' v{p.Version}: {(dto.Mode == InclusionMode.Include ? "hedef" : "hariç")} eklendi → {text}", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", p.Code, new { action = "target-added", policy = p.Code, dto.Mode, target = text, p.Version });
        await db.SaveChangesAsync(ct);
        return row;
    }

    public async Task RemoveTargetAsync(int targetId, CancellationToken ct)
    {
        var t = await db.PolicyTargets.Include(x => x.Policy).FirstOrDefaultAsync(x => x.Id == targetId, ct) ?? throw new NotFoundException("Policy hedefi", targetId);
        var text = (await DescribeAsync(new TargetRef(t.TargetType, t.ApplicationId, t.CatalogNodeId, t.PermissionId), ct)) + DescribeActions(t.Actions);
        db.PolicyTargets.Remove(t);
        t.Policy.Version++;
        audit.Management("PolicyTargetRemoved", "Policy", t.Policy.Code, $"'{t.Policy.Code}' v{t.Policy.Version}: {(t.Mode == InclusionMode.Include ? "hedef" : "hariç")} kaldırıldı → {text}");
        outbox.Add(EventTypes.PolicyChanged, "Policy", t.Policy.Code, new { action = "target-removed", policy = t.Policy.Code, target = text, t.Policy.Version });
        await db.SaveChangesAsync(ct);
    }

    // ------------------------------ Kanal (client) hedefi ------------------------------

    public async Task<PolicyClientTarget> AddClientTargetAsync(int policyId, ClientTargetUpsert dto, CancellationToken ct)
    {
        var p = await db.Policies.FindAsync([policyId], ct) ?? throw new NotFoundException("Policy", policyId);
        var client = await db.Clients.FindAsync([dto.ClientId], ct) ?? throw new NotFoundException("Client", dto.ClientId);
        if (client.Type == ClientType.Intermediary)
            throw new ValidationException($"'{client.ClientId}' bir aracıdır (gateway/BFF); kanal hedefi isteği başlatan client olmalı.");
        if (await db.PolicyClientTargets.AnyAsync(t => t.PolicyId == policyId && t.ClientId == dto.ClientId, ct))
            throw new ConflictException($"'{client.ClientId}' bu policy'de zaten kanal hedefi.");
        var row = new PolicyClientTarget { PolicyId = policyId, ClientId = client.Id, Mode = dto.Mode };
        db.PolicyClientTargets.Add(row);
        p.Version++;
        var text = $"{(dto.Mode == InclusionMode.Include ? "sadece" : "hariç")} client {client.ClientId}";
        audit.Management("PolicyClientTargetAdded", "Policy", p.Code, $"'{p.Code}' v{p.Version}: kanal hedefi eklendi → {text}", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", p.Code, new { action = "client-target-added", policy = p.Code, client = client.ClientId, dto.Mode, p.Version });
        await db.SaveChangesAsync(ct);
        return row;
    }

    public async Task RemoveClientTargetAsync(int id, CancellationToken ct)
    {
        var t = await db.PolicyClientTargets.Include(x => x.Policy).Include(x => x.Client).FirstOrDefaultAsync(x => x.Id == id, ct)
                ?? throw new NotFoundException("Kanal hedefi", id);
        db.PolicyClientTargets.Remove(t);
        t.Policy.Version++;
        audit.Management("PolicyClientTargetRemoved", "Policy", t.Policy.Code, $"'{t.Policy.Code}' v{t.Policy.Version}: kanal hedefi kaldırıldı → {t.Mode} client {t.Client.ClientId}");
        outbox.Add(EventTypes.PolicyChanged, "Policy", t.Policy.Code, new { action = "client-target-removed", policy = t.Policy.Code, client = t.Client.ClientId, t.Policy.Version });
        await db.SaveChangesAsync(ct);
    }

    // ------------------------------ Yükümlülük ------------------------------

    public async Task<PolicyObligation> AddObligationAsync(int policyId, ObligationUpsert dto, CancellationToken ct)
    {
        var p = await db.Policies.FindAsync([policyId], ct) ?? throw new NotFoundException("Policy", policyId);
        var code = Codes.Normalize(dto.Code);
        var parameters = PolicyEngine.ObligationTypes.Validate(code, dto.Parameters);
        var row = new PolicyObligation
        {
            PolicyId = policyId, Code = code, FulfillOn = dto.FulfillOn, Order = dto.Order,
            Parameters = parameters.Select(kv => new PolicyObligationParameter { Key = kv.Key, Value = kv.Value }).ToList()
        };
        db.PolicyObligations.Add(row);
        p.Version++;
        var text = $"{code}({string.Join(", ", parameters.Select(kv => $"{kv.Key}={kv.Value}"))}) · {dto.FulfillOn}";
        audit.Management("PolicyObligationAdded", "Policy", p.Code, $"'{p.Code}' v{p.Version}: yükümlülük eklendi → {text}", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", p.Code, new { action = "obligation-added", policy = p.Code, obligation = text, p.Version });
        await db.SaveChangesAsync(ct);
        return row;
    }

    public async Task RemoveObligationAsync(int id, CancellationToken ct)
    {
        var o = await db.PolicyObligations.Include(x => x.Policy).FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Yükümlülük", id);
        db.PolicyObligations.Remove(o);
        o.Policy.Version++;
        audit.Management("PolicyObligationRemoved", "Policy", o.Policy.Code, $"'{o.Policy.Code}' v{o.Policy.Version}: yükümlülük kaldırıldı → {o.Code}");
        outbox.Add(EventTypes.PolicyChanged, "Policy", o.Policy.Code, new { action = "obligation-removed", policy = o.Policy.Code, obligation = o.Code, o.Policy.Version });
        await db.SaveChangesAsync(ct);
    }

    public async Task<TargetRef> BuildTargetAsync(TargetType type, int? id, CancellationToken ct)
    {
        switch (type)
        {
            case TargetType.All: return new TargetRef(TargetType.All, null, null, null);
            case TargetType.Application when id is { } a && await db.Applications.AnyAsync(x => x.Id == a, ct): return new TargetRef(type, a, null, null);
            case TargetType.CatalogNode when id is { } n && await db.CatalogNodes.AnyAsync(x => x.Id == n, ct): return new TargetRef(type, null, n, null);
            case TargetType.Permission when id is { } p && await db.Permissions.AnyAsync(x => x.Id == p, ct): return new TargetRef(type, null, null, p);
            default: throw new ValidationException($"Geçersiz hedef: {type} #{id}");
        }
    }

    public async Task<string> DescribeAsync(TargetRef t, CancellationToken ct) => t.Type switch
    {
        TargetType.All => "Tümü",
        TargetType.Application => "Uygulama " + await db.Applications.Where(a => a.Id == t.ApplicationId).Select(a => a.Code).FirstOrDefaultAsync(ct),
        TargetType.CatalogNode => "Düğüm " + await db.CatalogNodes.Where(n => n.Id == t.CatalogNodeId).Select(n => n.Path).FirstOrDefaultAsync(ct),
        _ => "Permission " + await db.Permissions.Where(p => p.Id == t.PermissionId).Select(p => p.Code).FirstOrDefaultAsync(ct)
    };

    private static string? NormalizeActions(string? actions)
    {
        var values = Codes.SplitList(actions).Select(Codes.Lower).Distinct(StringComparer.Ordinal).OrderBy(x => x, StringComparer.Ordinal).ToList();
        return values.Count == 0 ? null : string.Join(',', values);
    }

    private static string DescribeActions(string? actions) =>
        actions is null ? "" : $" · Action: {string.Join(", ", Codes.SplitList(actions))}";

    // ================================ Rule ================================

    public async Task<Rule> CreateRuleAsync(int policyId, RuleUpsert dto, CancellationToken ct)
    {
        var policy = await db.Policies.FindAsync([policyId], ct) ?? throw new NotFoundException("Policy", policyId);
        var code = Codes.Normalize(dto.Code);
        if (await db.Rules.AnyAsync(r => r.PolicyId == policyId && r.Code == code, ct))
            throw new ConflictException($"'{policy.Code}' policy'sinde bu rule kodu zaten var: {code}");
        var v = await ValidateConditionAsync(dto.Condition, ct);

        var rule = new Rule
        {
            PolicyId = policyId, Code = code, Name = dto.Name, Description = dto.Description,
            Order = dto.Order, ReasonCode = NormalizeReason(dto.ReasonCode), IsActive = dto.IsActive
        };
        db.Rules.Add(rule);
        AddConditionTree(rule, null, null, dto.Condition, 0, v);
        policy.Version++;
        audit.Management("RuleCreated", "Policy", policy.Code, $"'{policy.Code}' v{policy.Version}: rule eklendi {code} (sağlanmalı: {Render(dto.Condition)})", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", policy.Code, new { action = "rule-created", policy = policy.Code, rule = code, policy.Version });
        await db.SaveChangesAsync(ct);
        return rule;
    }

    public async Task UpdateRuleAsync(int ruleId, RuleUpsert dto, CancellationToken ct)
    {
        var rule = await db.Rules.Include(r => r.Policy).FirstOrDefaultAsync(r => r.Id == ruleId, ct) ?? throw new NotFoundException("Rule", ruleId);
        var v = await ValidateConditionAsync(dto.Condition, ct);
        rule.Name = dto.Name; rule.Description = dto.Description;
        rule.Order = dto.Order; rule.ReasonCode = NormalizeReason(dto.ReasonCode); rule.IsActive = dto.IsActive;
        RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.RuleId == ruleId).ToListAsync(ct));
        AddConditionTree(rule, null, null, dto.Condition, 0, v);
        rule.Policy.Version++;
        audit.Management("RuleUpdated", "Policy", rule.Policy.Code, $"'{rule.Policy.Code}' v{rule.Policy.Version}: rule güncellendi {rule.Code} (sağlanmalı: {Render(dto.Condition)})", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", rule.Policy.Code, new { action = "rule-updated", policy = rule.Policy.Code, rule = rule.Code, rule.Policy.Version });
        await db.SaveChangesAsync(ct);
    }

    public async Task DeleteRuleAsync(int ruleId, CancellationToken ct)
    {
        var rule = await db.Rules.Include(r => r.Policy).FirstOrDefaultAsync(r => r.Id == ruleId, ct) ?? throw new NotFoundException("Rule", ruleId);
        RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.RuleId == ruleId).ToListAsync(ct));
        db.Rules.Remove(rule);
        rule.Policy.Version++;
        audit.Management("RuleDeleted", "Policy", rule.Policy.Code, $"'{rule.Policy.Code}' v{rule.Policy.Version}: rule silindi {rule.Code}");
        outbox.Add(EventTypes.PolicyChanged, "Policy", rule.Policy.Code, new { action = "rule-deleted", policy = rule.Policy.Code, rule = rule.Code, rule.Policy.Version });
        await db.SaveChangesAsync(ct);
    }

    // ================================ Condition ağacı ================================

    public sealed record ConditionValidation(IReadOnlyDictionary<string, int> Types, IReadOnlyDictionary<string, int> Shared);

    /// <summary>
    /// Condition ağacını doğrular (yapı, derinlik, predicate parametreleri, ortak koşul referansları).
    /// selfSharedId verilirse (ortak koşul düzenlerken) doğrudan/dolaylı kendine referans (döngü) reddedilir.
    /// </summary>
    public async Task<ConditionValidation> ValidateConditionAsync(ConditionDraft root, CancellationToken ct, int? selfSharedId = null)
    {
        var errors = new List<string>();
        var codes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var refs = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        void Walk(ConditionDraft n, int depth, string path)
        {
            if (depth > PolicyEvaluator.MaxConditionDepth) { errors.Add($"{path}: ağaç en fazla {PolicyEvaluator.MaxConditionDepth} seviye olabilir."); return; }
            switch (n.Kind)
            {
                case ConditionKind.Predicate:
                    if (string.IsNullOrWhiteSpace(n.ConditionTypeCode)) { errors.Add($"{path}: condition tipi zorunlu."); return; }
                    if (n.Children.Count > 0) errors.Add($"{path}: predicate çocuk içeremez.");
                    var handler = handlers.Find(n.ConditionTypeCode);
                    if (handler is null) { errors.Add($"{path}: bilinmeyen condition tipi '{n.ConditionTypeCode}'."); return; }
                    codes.Add(handler.Descriptor.Code);
                    var ps = n.Parameters.Where(kv => !string.IsNullOrWhiteSpace(kv.Value))
                        .ToDictionary(kv => kv.Key.Trim(), kv => kv.Value.Trim(), StringComparer.OrdinalIgnoreCase);
                    errors.AddRange(handler.ValidateParameters(ps).Select(e => $"{path} ({handler.Descriptor.Code}): {e}"));
                    n.Parameters = ps;
                    n.ConditionTypeCode = handler.Descriptor.Code;
                    break;
                case ConditionKind.Reference:
                    if (string.IsNullOrWhiteSpace(n.SharedConditionCode)) { errors.Add($"{path}: ortak koşul seçilmeli."); return; }
                    if (n.Children.Count > 0) errors.Add($"{path}: ortak koşul referansı çocuk içeremez.");
                    n.SharedConditionCode = Codes.Normalize(n.SharedConditionCode);
                    refs.Add(n.SharedConditionCode);
                    n.Parameters = new();
                    break;
                case ConditionKind.Not:
                    if (n.Children.Count != 1) errors.Add($"{path}: NOT tam olarak bir alt koşul içermeli.");
                    break;
                default:
                    if (n.Children.Count == 0) errors.Add($"{path}: AND/OR en az bir alt koşul içermeli.");
                    break;
            }
            for (var i = 0; i < n.Children.Count; i++) Walk(n.Children[i], depth + 1, $"{path}.{i + 1}");
        }

        Walk(root, 0, "condition");

        var refList = refs.ToList();
        var shared = await db.SharedConditions.AsNoTracking().Where(x => refList.Contains(x.Code)).Select(x => new { x.Id, x.Code, x.IsActive }).ToListAsync(ct);
        foreach (var r in refList)
        {
            var sc = shared.FirstOrDefault(x => x.Code == r);
            if (sc is null) errors.Add($"Ortak koşul bulunamadı: {r}");
            else if (!sc.IsActive) errors.Add($"Ortak koşul pasif: {r}");
        }
        if (selfSharedId is { } self && shared.Count > 0 && (await ReachableSharedAsync(shared.Select(x => x.Id), ct)).Contains(self))
            errors.Add("Döngüsel referans: ortak koşul doğrudan veya dolaylı olarak kendine referans veriyor.");

        if (errors.Count > 0) throw ValidationException.Of("condition", errors);

        var codeList = codes.ToList();
        var types = await db.ConditionTypes.Where(t => codeList.Contains(t.Code) && t.IsAvailable).ToDictionaryAsync(t => t.Code, t => t.Id, StringComparer.OrdinalIgnoreCase, ct);
        var missing = codeList.Where(c => !types.ContainsKey(c)).ToList();
        if (missing.Count > 0) throw new ValidationException($"Katalogda olmayan condition tipi: {string.Join(", ", missing)}");
        return new ConditionValidation(types, shared.ToDictionary(x => x.Code, x => x.Id, StringComparer.OrdinalIgnoreCase));
    }

    private async Task<HashSet<int>> ReachableSharedAsync(IEnumerable<int> start, CancellationToken ct)
    {
        var edges = (await db.RuleConditions.AsNoTracking().Where(c => c.SharedConditionId != null && c.ReferencedSharedConditionId != null)
                .Select(c => new { From = c.SharedConditionId!.Value, To = c.ReferencedSharedConditionId!.Value }).ToListAsync(ct))
            .ToLookup(e => e.From, e => e.To);
        var seen = new HashSet<int>();
        var stack = new Stack<int>(start);
        while (stack.Count > 0)
        {
            var id = stack.Pop();
            if (!seen.Add(id)) continue;
            foreach (var next in edges[id]) stack.Push(next);
        }
        return seen;
    }

    /// <summary>Condition ağacını entity olarak ekler. Sahibi ya bir rule ya da bir ortak koşuldur.</summary>
    internal void AddConditionTree(Rule? rule, SharedCondition? owner, RuleCondition? parent, ConditionDraft draft, int order, ConditionValidation v)
    {
        var node = new RuleCondition
        {
            Rule = rule, SharedCondition = owner, Parent = parent, Kind = draft.Kind, Order = order,
            ConditionTypeId = draft.Kind == ConditionKind.Predicate ? v.Types[draft.ConditionTypeCode!] : null,
            ReferencedSharedConditionId = draft.Kind == ConditionKind.Reference ? v.Shared[draft.SharedConditionCode!] : null,
            Parameters = draft.Kind == ConditionKind.Predicate
                ? draft.Parameters.Select(kv => new ConditionParameter { Key = kv.Key, Value = kv.Value }).ToList()
                : new List<ConditionParameter>()
        };
        db.RuleConditions.Add(node);
        for (var i = 0; i < draft.Children.Count; i++) AddConditionTree(rule, owner, node, draft.Children[i], i, v);
    }

    internal void RemoveNodes(List<RuleCondition> nodes)
    {
        foreach (var n in nodes)
        {
            foreach (var p in n.Parameters.ToList()) db.ConditionParameters.Remove(p);
            db.RuleConditions.Remove(n);
        }
    }

    private static string? NormalizeReason(string? reason) => string.IsNullOrWhiteSpace(reason) ? null : Codes.Normalize(reason);

    public static string Render(ConditionDraft d) => PolicyEvaluator.Render(PolicyCompiler.FromDraftUnresolved(d));
}
