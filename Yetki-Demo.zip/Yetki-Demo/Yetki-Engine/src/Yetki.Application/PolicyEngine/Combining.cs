using Yetki.Domain.Common;

namespace Yetki.Application.PolicyEngine;

/// <summary>Birleştirme sonucu: karar + kararı belirleyen girdinin indeksi (açıklanabilirlik için).</summary>
public readonly record struct CombiningResult(DecisionType Decision, int? DecidingIndex);

/// <summary>
/// Rule sonuçlarını tek policy kararına indirger. Girdi: rule başına Permit (sağlandı) / Deny (sağlanmadı) /
/// Indeterminate (belirsiz) / NotApplicable (pasif). Girdi sırası deterministiktir (Order, sonra Code).
/// </summary>
public interface ICombiningAlgorithm
{
    CombiningAlgorithm Id { get; }
    CombiningResult Combine(IReadOnlyList<DecisionType> results);
}

/// <summary>
/// Tüm rule'lar sağlanmalı (AND): sağlanmayan varsa Deny; yoksa belirsiz varsa Indeterminate; yoksa Permit.
/// Belirsizlik Permit'i daima bloklar (güvenli taraf). Aktif rule yoksa NotApplicable.
/// Aynı mantık policy'ler arası birleştirmede de kullanılır: nihai Permit için tüm policy'ler Permit (veya kısıtsız) olmalı.
/// </summary>
public sealed class AllRulesMustPassAlgorithm : ICombiningAlgorithm
{
    public CombiningAlgorithm Id => CombiningAlgorithm.AllRulesMustPass;

    public CombiningResult Combine(IReadOnlyList<DecisionType> r) => Evaluate(r);

    public static CombiningResult Evaluate(IReadOnlyList<DecisionType> r) =>
        First(r, DecisionType.Deny) ?? First(r, DecisionType.Indeterminate) ?? First(r, DecisionType.Permit)
        ?? new CombiningResult(DecisionType.NotApplicable, null);

    internal static CombiningResult? First(IReadOnlyList<DecisionType> r, DecisionType d)
    {
        for (var i = 0; i < r.Count; i++)
            if (r[i] == d) return new CombiningResult(d, i);
        return null;
    }
}

/// <summary>En az bir rule sağlanmalı (OR): sağlanan varsa Permit; yoksa belirsiz varsa Indeterminate; yoksa Deny.</summary>
public sealed class AnyRuleMustPassAlgorithm : ICombiningAlgorithm
{
    public CombiningAlgorithm Id => CombiningAlgorithm.AnyRuleMustPass;

    public CombiningResult Combine(IReadOnlyList<DecisionType> r) =>
        AllRulesMustPassAlgorithm.First(r, DecisionType.Permit) ?? AllRulesMustPassAlgorithm.First(r, DecisionType.Indeterminate)
        ?? AllRulesMustPassAlgorithm.First(r, DecisionType.Deny) ?? new CombiningResult(DecisionType.NotApplicable, null);
}

public sealed class CombiningAlgorithmRegistry(IEnumerable<ICombiningAlgorithm> algorithms)
{
    private readonly Dictionary<CombiningAlgorithm, ICombiningAlgorithm> _algorithms = algorithms.ToDictionary(a => a.Id);

    public ICombiningAlgorithm Get(CombiningAlgorithm id) =>
        _algorithms.TryGetValue(id, out var a) ? a : throw new InvalidOperationException($"Desteklenmeyen karar stratejisi: {id}");
}
