using System.Text.Json.Serialization;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Domain.Common;

namespace Yetki.Application.PolicyEngine;

/// <summary>Karar durumu (XACML / AuthZEN kavramları).</summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum DecisionType
{
    Permit = 1,
    Deny = 2,
    /// <summary>Hiçbir rule uygulanamadı (policy seviyesinde: "bu policy kısıt koymadı").</summary>
    NotApplicable = 3,
    /// <summary>Karar verilemedi (eksik attribute, hata). Enforcement tarafında İZİN VERİLMEZ (fail-closed).</summary>
    Indeterminate = 4
}

/// <summary>
/// Condition ağacı (bellek içi). Id negatifse What-If taslağıdır.
/// Kind=Reference: ReferenceCode = ortak koşul kodu; Children[0] = çözülmüş ortak koşul kökü (çözülemediyse boş → Indeterminate).
/// </summary>
public sealed record ConditionNode(
    int Id,
    ConditionKind Kind,
    string? ConditionTypeCode,
    bool TypeAvailable,
    IReadOnlyDictionary<string, string> Parameters,
    IReadOnlyList<ConditionNode> Children,
    string? ReferenceCode = null,
    int? ReferenceVersion = null);

/// <summary>Policy içindeki tek koşul (gereksinim). ReasonCode: sağlanmadığında dönen neden.</summary>
public sealed record RuleDefinition(
    int RuleId, string Code, string Name, string? Description, int Order, string? ReasonCode,
    bool IsActive, ConditionNode? Condition);

public sealed record PolicyDefinition(
    int PolicyId, string Code, string Name, int Version, CombiningAlgorithm Algorithm, IReadOnlyList<RuleDefinition> Rules);

public sealed record ConditionTrace(
    ConditionKind Kind,
    string? ConditionType,
    string Expression,
    TriState Value,
    string? Message,
    IReadOnlyList<string>? MissingAttributes,
    IReadOnlyList<UsedAttribute>? Evidence,
    IReadOnlyList<ConditionTrace>? Children);

/// <summary>Rule sonucu. Result: Permit = sağlandı · Deny = sağlanmadı · Indeterminate = belirsiz · NotApplicable = pasif.</summary>
public sealed record RuleEvaluation(
    int RuleId,
    string Code,
    string Name,
    int Order,
    bool IsActive,
    TriState ConditionValue,
    DecisionType Result,
    string? ReasonCode,
    string Message,
    string Expression,
    ConditionTrace? Condition,
    IReadOnlyList<string> MissingAttributes,
    IReadOnlyList<UsedAttribute> Evidence)
{
    public bool IsDeciding { get; init; }
}

public sealed record PolicyEvaluation(
    int PolicyId,
    string Code,
    string Name,
    int Version,
    CombiningAlgorithm Algorithm,
    DecisionType Result,
    string? DecidingRule,
    IReadOnlyList<RuleEvaluation> Rules)
{
    public bool IsDeciding { get; init; }
    /// <summary>Policy bu isteğe hangi hedef üzerinden uygulandı (ör. "Düğüm ANKA/NAKIT").</summary>
    public string? MatchedBy { get; init; }
    public PolicyMode Mode { get; init; } = PolicyMode.Enforce;
    /// <summary>Policy'nin sahibi tenant (alt tenant'a miras geldiyse üst tenant).</summary>
    public string? Tenant { get; init; }
}
