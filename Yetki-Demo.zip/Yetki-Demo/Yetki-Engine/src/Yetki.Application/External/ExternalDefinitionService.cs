using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Events;
using Yetki.Application.Model;
using Yetki.Domain.Common;
using Yetki.Domain.Governance;

namespace Yetki.Application.External;

public sealed class ExternalSystemUpsert
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool HasAccessLevels { get; set; }
}

public sealed class ExternalPermissionUpsert
{
    public int ExternalSystemId { get; set; }
    public string Code { get; set; } = default!;
    public string? Name { get; set; }
    public string? ResourceClass { get; set; }
    public string? Description { get; set; }
}

/// <summary>Katalog öğesine (API / endpoint / permission — tam olarak biri) dış bağımlılık.</summary>
public sealed class ExternalDependencyUpsert
{
    public int? ApiId { get; set; }
    public int? EndpointId { get; set; }
    public int? PermissionId { get; set; }
    public int ExternalPermissionId { get; set; }
    /// <summary>Boş: permission'ın action'ından türetilir.</summary>
    public ExternalAccessLevel? AccessLevel { get; set; }
    public string? Note { get; set; }
}

public sealed class ExternalRequirementUpsert
{
    public int RequiredExternalPermissionId { get; set; }
    public ExternalAccessLevel? AccessLevel { get; set; }
}

public sealed record ExternalChange(string System, string Code, string? ResourceClass, string? Level, string? PreviousLevel, IReadOnlyList<string> Reasons);

public sealed record ExternalUserImpact(int UserId, string UserName, IReadOnlyList<ExternalChange> Grants, IReadOnlyList<ExternalChange> Modifies, IReadOnlyList<ExternalChange> Revokes);

/// <summary>Dış bağımlılık değişikliğinin etkisi: hangi kullanıcıya dış sistemde ne açılır / değişir / kapanır.</summary>
public sealed record ExternalImpactResult(bool DryRun, string Summary, int AffectedUserCount, IReadOnlyList<ExternalUserImpact> Users);

/// <summary>
/// Dış sistem tanımları ve katalog bağımlılıkları. Her bağımlılık değişikliği önce/sonra katalogla TÜM kullanıcılar için
/// olması gereken dış durumu karşılaştırır (dryRun = sadece etki). Uygulanınca ExternalRequirementsChanged olayı etkilenen
/// kullanıcılar için mutabakatı tetikler.
/// </summary>
public sealed class ExternalDefinitionService(
    IYetkiDbContext db, AuthorizationModelProvider models, OutboxWriter outbox, AuditWriter audit, IClock clock)
{
    public async Task<ExternalSystem> CreateSystemAsync(ExternalSystemUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.ExternalSystems.AnyAsync(s => s.Code == code, ct)) throw new ConflictException($"Dış sistem kodu zaten var: {code}");
        var s = new ExternalSystem { Code = code, Name = dto.Name, Description = dto.Description, HasAccessLevels = dto.HasAccessLevels };
        db.ExternalSystems.Add(s);
        audit.Management("ExternalSystemCreated", "ExternalSystem", code, $"Dış sistem eklendi: {code}", dto);
        await db.SaveChangesAsync(ct);
        return s;
    }

    public async Task<ExternalPermission> CreatePermissionAsync(ExternalPermissionUpsert dto, CancellationToken ct)
    {
        var sys = await db.ExternalSystems.FindAsync([dto.ExternalSystemId], ct) ?? throw new NotFoundException("Dış sistem", dto.ExternalSystemId);
        var code = dto.Code.Trim().ToUpperInvariant();
        if (code.Length == 0) throw new ValidationException("Kod zorunlu.");
        if (await db.ExternalPermissions.AnyAsync(p => p.ExternalSystemId == sys.Id && p.Code == code, ct)) throw new ConflictException($"{sys.Code}:{code} zaten var.");
        var p = new ExternalPermission
        {
            ExternalSystemId = sys.Id, Code = code, Name = dto.Name, Description = dto.Description,
            ResourceClass = string.IsNullOrWhiteSpace(dto.ResourceClass) ? null : dto.ResourceClass.Trim().ToUpperInvariant()
        };
        db.ExternalPermissions.Add(p);
        audit.Management("ExternalPermissionCreated", "ExternalPermission", $"{sys.Code}:{code}", $"Dış yetki eklendi: {sys.Code}:{code} ({p.ResourceClass})", dto);
        await db.SaveChangesAsync(ct);
        return p;
    }

    // ------------------------------ Katalog bağımlılığı ------------------------------

    public async Task<ExternalImpactResult> AddDependencyAsync(ExternalDependencyUpsert dto, bool dryRun, CancellationToken ct)
    {
        var owners = new[] { dto.ApiId, dto.EndpointId, dto.PermissionId }.Count(x => x is not null);
        if (owners != 1) throw new ValidationException("Bağımlılık tam olarak bir API, endpoint veya permission'a bağlanmalı.");
        var ext = await db.ExternalPermissions.Include(e => e.ExternalSystem).FirstOrDefaultAsync(e => e.Id == dto.ExternalPermissionId, ct)
                  ?? throw new NotFoundException("Dış yetki", dto.ExternalPermissionId);
        if (!ext.ExternalSystem.HasAccessLevels && dto.AccessLevel is not null)
            throw new ValidationException($"{ext.ExternalSystem.Code} erişim seviyesi desteklemiyor (sadece üyelik).");

        string owner;
        if (dto.ApiId is { } apiId)
            owner = "API " + (await db.ApiResources.Where(a => a.Id == apiId).Select(a => a.Code).FirstOrDefaultAsync(ct) ?? throw new NotFoundException("API", apiId));
        else if (dto.EndpointId is { } epId)
            owner = await db.ApiEndpoints.Where(e => e.Id == epId).Select(e => e.Method + " " + e.ApiResource.Code + e.Path).FirstOrDefaultAsync(ct) ?? throw new NotFoundException("Endpoint", epId);
        else
            owner = "permission " + (await db.Permissions.Where(p => p.Id == dto.PermissionId).Select(p => p.Code).FirstOrDefaultAsync(ct) ?? throw new NotFoundException("Permission", dto.PermissionId!));

        if (await db.ExternalDependencies.AnyAsync(d => d.ApiResourceId == dto.ApiId && d.ApiEndpointId == dto.EndpointId && d.PermissionId == dto.PermissionId
                                                        && d.ExternalPermissionId == dto.ExternalPermissionId, ct))
            throw new ConflictException($"{owner} zaten {ext.ExternalSystem.Code}:{ext.Code} bağımlılığına sahip.");

        var before = await ExternalRequirementCatalog.LoadAsync(db, ct);
        var after = before.With(added: new ExternalDependencyRow(-1, dto.ApiId, dto.EndpointId, dto.PermissionId, dto.ExternalPermissionId, dto.AccessLevel, dto.Note));
        var summary = $"{owner} → {ext.ExternalSystem.Code}:{ext.Code}{(dto.AccessLevel is { } l ? $" ({l.ToString().ToUpperInvariant()})" : "")} bağımlılığı";
        var impact = await ImpactAsync(before, after, summary, dryRun, ct);
        if (dryRun) return impact;

        db.ExternalDependencies.Add(new ExternalDependency
        {
            ApiResourceId = dto.ApiId, ApiEndpointId = dto.EndpointId, PermissionId = dto.PermissionId,
            ExternalPermissionId = dto.ExternalPermissionId, AccessLevel = dto.AccessLevel, Note = dto.Note
        });
        await CommitAsync("ExternalDependencyAdded", summary + " eklendi", impact, dto, ct);
        return impact;
    }

    public async Task<ExternalImpactResult> RemoveDependencyAsync(int id, bool dryRun, CancellationToken ct)
    {
        var d = await db.ExternalDependencies.Include(x => x.ExternalPermission).ThenInclude(x => x.ExternalSystem)
                    .Include(x => x.ApiResource).Include(x => x.ApiEndpoint).ThenInclude(x => x!.ApiResource).Include(x => x.Permission)
                    .FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NotFoundException("Dış bağımlılık", id);
        var owner = d.ApiResource is not null ? $"API {d.ApiResource.Code}"
            : d.ApiEndpoint is not null ? $"{d.ApiEndpoint.Method} {d.ApiEndpoint.ApiResource.Code}{d.ApiEndpoint.Path}" : $"permission {d.Permission!.Code}";
        var summary = $"{owner} → {d.ExternalPermission.ExternalSystem.Code}:{d.ExternalPermission.Code} bağımlılığı";

        var before = await ExternalRequirementCatalog.LoadAsync(db, ct);
        var impact = await ImpactAsync(before, before.With(removedDependencyId: id), summary, dryRun, ct);
        if (dryRun) return impact;

        db.ExternalDependencies.Remove(d);
        await CommitAsync("ExternalDependencyRemoved", summary + " kaldırıldı", impact, new { id }, ct);
        return impact;
    }

    // ------------------------------ Zincir (dış yetki → dış yetki) ------------------------------

    public async Task<ExternalImpactResult> SetRequirementAsync(int externalPermissionId, ExternalRequirementUpsert dto, bool add, bool dryRun, CancellationToken ct)
    {
        var from = await db.ExternalPermissions.Include(e => e.ExternalSystem).FirstOrDefaultAsync(e => e.Id == externalPermissionId, ct)
                   ?? throw new NotFoundException("Dış yetki", externalPermissionId);
        var to = await db.ExternalPermissions.Include(e => e.ExternalSystem).FirstOrDefaultAsync(e => e.Id == dto.RequiredExternalPermissionId, ct)
                 ?? throw new NotFoundException("Dış yetki", dto.RequiredExternalPermissionId);
        var existing = await db.ExternalPermissionRequirements.FirstOrDefaultAsync(r => r.ExternalPermissionId == from.Id && r.RequiredExternalPermissionId == to.Id, ct);
        var before = await ExternalRequirementCatalog.LoadAsync(db, ct);
        ExternalRequirementCatalog after;
        if (add)
        {
            if (existing is not null) throw new ConflictException("Bu zincir zaten var.");
            if (from.Id == to.Id || before.WouldCreateCycle(from.Id, to.Id)) throw new ValidationException("Döngüsel zincir oluşur.");
            if (!to.ExternalSystem.HasAccessLevels && dto.AccessLevel is not null) throw new ValidationException($"{to.ExternalSystem.Code} erişim seviyesi desteklemiyor.");
            after = before.WithRequirement(added: new ExternalRequirementRow(from.Id, to.Id, dto.AccessLevel));
        }
        else
        {
            if (existing is null) throw new NotFoundException("Zincir", $"{from.Id}/{to.Id}");
            after = before.WithRequirement(removed: (from.Id, to.Id));
        }
        var summary = $"{from.ExternalSystem.Code}:{from.Code} → {to.ExternalSystem.Code}:{to.Code} zinciri";
        var impact = await ImpactAsync(before, after, summary, dryRun, ct);
        if (dryRun) return impact;

        if (add) db.ExternalPermissionRequirements.Add(new ExternalPermissionRequirement { ExternalPermissionId = from.Id, RequiredExternalPermissionId = to.Id, AccessLevel = dto.AccessLevel });
        else db.ExternalPermissionRequirements.Remove(existing!);
        await CommitAsync(add ? "ExternalRequirementAdded" : "ExternalRequirementRemoved", summary + (add ? " eklendi" : " kaldırıldı"), impact, dto, ct);
        return impact;
    }

    // ------------------------------------------------------------------------------------------

    private async Task<ExternalImpactResult> ImpactAsync(ExternalRequirementCatalog before, ExternalRequirementCatalog after, string summary, bool dryRun, CancellationToken ct)
    {
        var model = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        var users = new List<ExternalUserImpact>();
        foreach (var u in model.Users.Values.OrderBy(u => u.UserName, StringComparer.Ordinal))
        {
            var set = model.GetEffective(u.Id, now);
            var b = before.ForUser(model, set);
            var a = after.ForUser(model, set);
            var diff = ExternalDiff.Compute(a, ExternalDiff.ToState(b), before.Target, previous: b);
            if (diff.Count == 0) continue;
            users.Add(new ExternalUserImpact(u.Id, u.UserName,
                diff.Where(d => d.Action == "Grant").Select(ToChange).ToList(),
                diff.Where(d => d.Action == "Modify").Select(ToChange).ToList(),
                diff.Where(d => d.Action == "Revoke").Select(ToChange).ToList()));
        }
        return new ExternalImpactResult(dryRun, $"{summary}: {users.Count} kullanıcının dış sistem yetkisi değişir.", users.Count, users);
    }

    public static ExternalChange ToChange(ExternalDiffItem d) =>
        new(d.Target.System, d.Target.Code, d.Target.ResourceClass, d.DesiredLevel?.ToString().ToUpperInvariant(), d.CurrentLevel?.ToString().ToUpperInvariant(), d.Reasons);

    private async Task CommitAsync(string action, string summary, ExternalImpactResult impact, object? details, CancellationToken ct)
    {
        audit.Management(action, "ExternalDependency", null, $"{summary} ({impact.AffectedUserCount} kullanıcı etkilendi)", details);
        if (impact.AffectedUserCount > 0)
            outbox.Add(EventTypes.ExternalRequirementsChanged, "ExternalDependency", null,
                new ExternalRequirementsChangedPayload(impact.Users.Select(u => u.UserId).ToList(), summary));
        await db.SaveChangesAsync(ct);
    }
}
