using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Yetki.Application.Abstractions;
using Yetki.Application.Events;
using Yetki.Application.Model;
using Yetki.Domain.Common;
using Yetki.Domain.Governance;

namespace Yetki.Application.External;

/// <summary>Kullanıcının dış sistem durumu: olması gereken ↔ dış sistemde açık olan (kalem kalem, nedenleriyle).</summary>
public sealed record UserExternalStatus(int UserId, string UserName, bool IsActive, bool InSync, IReadOnlyList<ExternalDiffItem> Items);

public sealed record DriftUser(int UserId, string UserName, int Grants, int Modifies, int Revokes);

public sealed record DriftReport(int CheckedUsers, int DriftedUsers, IReadOnlyList<DriftUser> Users);

/// <summary>
/// Dış sistem provisioning'i = MUTABAKAT (desired-state reconcile):
///   olması gereken (etkin permission'lardan) − dış sistemde açık olan (UserExternalGrant) → Grant / Modify / Revoke → adaptör.
/// Sadece başarılı aksiyonlar durumu günceller; başarısızlar bir sonraki mutabakatta tekrar denenir. İdempotent: aynı olay
/// iki kez işlenirse ikincisi fark bulamaz. Başka bir permission'dan dolayı hâlâ gereken dış yetki GERİ ALINMAZ.
/// </summary>
public sealed class ExternalProvisioningService(
    IYetkiDbContext db, AuthorizationModelProvider models, IEnumerable<IProvisioningAdapter> adapters, IClock clock, ICurrentActor actor,
    ILogger<ExternalProvisioningService> logger)
{
    public async Task<UserExternalStatus> GetUserStatusAsync(int userId, CancellationToken ct)
    {
        var (model, catalog) = await LoadAsync(ct);
        if (!model.Users.TryGetValue(userId, out var user)) throw new NotFoundException("Kullanıcı", userId);
        var items = await DiffAsync(model, catalog, userId, includeUnchanged: true, ct);
        return new UserExternalStatus(userId, user.UserName, user.IsActive, items.All(i => i.Action == "None"), items);
    }

    public async Task<IReadOnlyList<ProvisioningAction>> ReconcileUserAsync(int userId, Guid? eventId, CancellationToken ct)
    {
        var (model, catalog) = await LoadAsync(ct);
        return await ReconcileAsync(model, catalog, userId, eventId, ct);
    }

    public async Task<DriftReport> DriftAsync(CancellationToken ct)
    {
        var (model, catalog) = await LoadAsync(ct);
        var state = await StateAsync(null, ct);
        var users = new List<DriftUser>();
        foreach (var u in model.Users.Values.OrderBy(u => u.UserName, StringComparer.Ordinal))
        {
            var items = Diff(model, catalog, u.Id, state[u.Id].ToDictionary(g => g.ExternalPermissionId, g => g.AccessLevel), false);
            if (items.Count > 0)
                users.Add(new DriftUser(u.Id, u.UserName, items.Count(i => i.Action == "Grant"), items.Count(i => i.Action == "Modify"), items.Count(i => i.Action == "Revoke")));
        }
        return new DriftReport(model.Users.Count, users.Count, users);
    }

    public async Task<int> ReconcileAllAsync(Guid? eventId, CancellationToken ct)
    {
        var (model, catalog) = await LoadAsync(ct);
        var count = 0;
        foreach (var u in model.Users.Values) count += (await ReconcileAsync(model, catalog, u.Id, eventId, ct)).Count;
        return count;
    }

    /// <summary>
    /// Başlangıç yüklemesi (baseline): dış sistemdeki mevcut durumun olması gerekenle aynı olduğu kabul edilir; komut gönderilmez.
    /// Gerçekte RACF'ten okunan mevcut durum (IRRDBU00 / LDAP export) içe aktarılır; demo verisi için bu kullanılır.
    /// </summary>
    public async Task BaselineAsync(CancellationToken ct)
    {
        var (model, catalog) = await LoadAsync(ct);
        db.UserExternalGrants.RemoveRange(await db.UserExternalGrants.ToListAsync(ct));
        var now = clock.UtcNow;
        foreach (var u in model.Users.Values)
            foreach (var need in catalog.ForUser(model, model.GetEffective(u.Id, now)))
                db.UserExternalGrants.Add(new UserExternalGrant
                {
                    UserId = u.Id, ExternalPermissionId = need.Target.ExternalPermissionId, AccessLevel = need.Level, ProvisionedAt = now, ProvisionedBy = "baseline"
                });
        await db.SaveChangesAsync(ct);
    }

    // ------------------------------------------------------------------------------------------

    private async Task<(AuthorizationModel, ExternalRequirementCatalog)> LoadAsync(CancellationToken ct) =>
        (await models.GetCurrentAsync(ct), await ExternalRequirementCatalog.LoadAsync(db, ct));

    private async Task<ILookup<int, UserExternalGrant>> StateAsync(int? userId, CancellationToken ct) =>
        (await db.UserExternalGrants.AsNoTracking().Where(g => userId == null || g.UserId == userId).ToListAsync(ct)).ToLookup(g => g.UserId);

    private async Task<List<ExternalDiffItem>> DiffAsync(AuthorizationModel model, ExternalRequirementCatalog catalog, int userId, bool includeUnchanged, CancellationToken ct)
    {
        var state = await StateAsync(userId, ct);
        return Diff(model, catalog, userId, state[userId].ToDictionary(g => g.ExternalPermissionId, g => g.AccessLevel), includeUnchanged);
    }

    private List<ExternalDiffItem> Diff(AuthorizationModel model, ExternalRequirementCatalog catalog, int userId,
        IReadOnlyDictionary<int, ExternalAccessLevel?> current, bool includeUnchanged)
    {
        var desired = catalog.ForUser(model, model.GetEffective(userId, clock.UtcNow));
        return ExternalDiff.Compute(desired, current, catalog.Target, includeUnchanged);
    }

    private async Task<List<ProvisioningAction>> ReconcileAsync(AuthorizationModel model, ExternalRequirementCatalog catalog, int userId, Guid? eventId, CancellationToken ct)
    {
        if (!model.Users.TryGetValue(userId, out var user)) return [];
        var items = await DiffAsync(model, catalog, userId, includeUnchanged: false, ct);
        if (items.Count == 0) return [];

        var now = clock.UtcNow;
        var actions = items.Select(i => new ProvisioningAction
        {
            OutboxEventId = eventId ?? Guid.Empty, UserId = userId, UserName = user.UserName,
            PermissionCode = Truncate(string.Join(" | ", i.Reasons.Take(3)), 512),
            ExternalSystemCode = i.Target.System, ExternalPermissionCode = i.Target.Code, ResourceClass = i.Target.ResourceClass,
            ActionType = i.Action switch { "Grant" => ProvisioningActionType.Grant, "Modify" => ProvisioningActionType.Modify, _ => ProvisioningActionType.Revoke },
            AccessLevel = i.DesiredLevel, PreviousAccessLevel = i.CurrentLevel, Status = ProvisioningStatus.Pending, CreatedAt = now
        }).ToList();
        db.ProvisioningActions.AddRange(actions);

        var grants = await db.UserExternalGrants.Where(g => g.UserId == userId).ToDictionaryAsync(g => g.ExternalPermissionId, ct);
        foreach (var (action, item) in actions.Zip(items))
        {
            var adapter = adapters.FirstOrDefault(a => string.Equals(a.SystemCode, action.ExternalSystemCode, StringComparison.OrdinalIgnoreCase))
                          ?? adapters.FirstOrDefault(a => a.SystemCode == "*");
            if (adapter is null)
            {
                action.Status = ProvisioningStatus.Failed;
                action.ResultMessage = "Bu sistem için adaptör yok.";
                continue;
            }
            try
            {
                var outcome = await adapter.ExecuteAsync(new ProvisioningRequest(userId, user.UserName, action.PermissionCode, action.ExternalSystemCode,
                    action.ExternalPermissionCode, action.ActionType, action.ResourceClass, action.AccessLevel, action.PreviousAccessLevel), ct);
                action.AdapterName = adapter.Name;
                action.Status = outcome.Success ? ProvisioningStatus.Completed : ProvisioningStatus.Failed;
                action.ResultMessage = outcome.Message;
                if (outcome.Success) ApplyState(grants, userId, item, now);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogError(ex, "Provisioning adapter {Adapter} failed", adapter.Name);
                action.AdapterName = adapter.Name;
                action.Status = ProvisioningStatus.Failed;
                action.ResultMessage = ex.Message;
            }
            action.CompletedAt = clock.UtcNow;
        }
        await db.SaveChangesAsync(ct);
        return actions;
    }

    private void ApplyState(Dictionary<int, UserExternalGrant> grants, int userId, ExternalDiffItem item, DateTime now)
    {
        var id = item.Target.ExternalPermissionId;
        switch (item.Action)
        {
            case "Grant":
                var g = new UserExternalGrant { UserId = userId, ExternalPermissionId = id, AccessLevel = item.DesiredLevel, ProvisionedAt = now, ProvisionedBy = actor.Name };
                db.UserExternalGrants.Add(g);
                grants[id] = g;
                break;
            case "Modify":
                grants[id].AccessLevel = item.DesiredLevel;
                grants[id].ProvisionedAt = now;
                grants[id].ProvisionedBy = actor.Name;
                break;
            case "Revoke":
                db.UserExternalGrants.Remove(grants[id]);
                grants.Remove(id);
                break;
        }
    }

    private static string Truncate(string s, int max) => s.Length <= max ? s : s[..(max - 1)] + "…";
}
