using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Yetki.Application.Audit;
using Yetki.Application.Changes;
using Yetki.Application.Definitions;
using Yetki.Application.Evaluation;
using Yetki.Application.Events;
using Yetki.Application.Governance;
using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Application.Simulation;

namespace Yetki.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddYetkiApplication(this IServiceCollection services)
    {
        services.AddOptions<AuthorizationEngineOptions>();

        // ---- Policy condition tipleri (davranış C#'ta). Yeni tip = yeni handler + buraya kayıt ----
        services.AddSingleton<IConditionHandler, AlwaysConditionHandler>();
        services.AddSingleton<IConditionHandler, TimeWindowConditionHandler>();
        services.AddSingleton<IConditionHandler, IpInRangeConditionHandler>();
        services.AddSingleton<IConditionHandler, ChannelInConditionHandler>();
        services.AddSingleton<IConditionHandler, PlatformInConditionHandler>();
        services.AddSingleton<IConditionHandler, ClientInConditionHandler>();
        services.AddSingleton<IConditionHandler, DeviceCompliantConditionHandler>();
        services.AddSingleton<IConditionHandler, AmountExceedsSubjectLimitConditionHandler>();
        services.AddSingleton<IConditionHandler, AmountGreaterThanConditionHandler>();
        services.AddSingleton<IConditionHandler, BranchInUserScopeConditionHandler>();
        services.AddSingleton<IConditionHandler, SubjectInUnitConditionHandler>();
        services.AddSingleton<IConditionHandler, SubjectHasRoleConditionHandler>();
        services.AddSingleton<IConditionHandler, SubjectInGroupConditionHandler>();
        services.AddSingleton<IConditionHandler, UserOnLeaveConditionHandler>();
        services.AddSingleton<IConditionHandler, CustomerIsSelfConditionHandler>();
        services.AddSingleton<ConditionHandlerRegistry>();
        services.AddScoped<ConditionTypeCatalogSynchronizer>();

        // ---- Grup kitle kriterleri (davranış C#'ta) ----
        services.AddSingleton<IGroupCriterionHandler, RoleCriterion>();
        services.AddSingleton<IGroupCriterionHandler, OrgUnitCriterion>();
        services.AddSingleton<IGroupCriterionHandler, OrgUnitTreeCriterion>();
        services.AddSingleton<IGroupCriterionHandler, OrgUnitTypeCriterion>();
        services.AddSingleton<IGroupCriterionHandler, TitleCriterion>();
        services.AddSingleton<IGroupCriterionHandler, TenantCriterion>();
        services.AddSingleton<IGroupCriterionHandler, UserCriterion>();
        services.AddSingleton<IGroupCriterionHandler, UserKindCriterion>();
        services.AddSingleton<GroupCriterionRegistry>();

        // ---- Combining algoritmaları ----
        services.AddSingleton<ICombiningAlgorithm, AllRulesMustPassAlgorithm>();
        services.AddSingleton<ICombiningAlgorithm, AnyRuleMustPassAlgorithm>();
        services.AddSingleton<CombiningAlgorithmRegistry>();

        // ---- Attribute kaynakları: kayıt sırası önceliktir ----
        services.AddScoped<IAttributeValueProvider, RequestContextAttributeProvider>();
        services.AddScoped<IAttributeValueProvider, ModelSubjectAttributeProvider>();
        services.TryAddSingleton<IAttributeRedactor, DefaultAttributeRedactor>();

        // ---- Yetki modeli ----
        services.AddSingleton<AuthorizationModelCache>();
        services.AddScoped<AuthorizationModelProvider>();

        services.AddScoped<PolicyEvaluator>();
        services.AddScoped<AuthorizationEvaluator>();
        services.AddScoped<EntitlementService>();

        services.AddScoped<AuditWriter>();
        services.AddScoped<OutboxWriter>();
        services.AddScoped<SodService>();
        services.AddScoped<AuthorizationChangeService>();
        services.AddScoped<AssignmentService>();
        services.AddScoped<PolicyManagementService>();
        services.AddScoped<SharedConditionService>();
        services.AddScoped<CatalogService>();
        services.AddScoped<OwnershipTeamService>();
        services.AddScoped<ClientService>();
        services.AddScoped<TenantService>();
        services.AddScoped<StructureService>();
        services.AddScoped<StructureExplorer>();
        services.AddScoped<GovernanceService>();
        services.AddScoped<External.ExternalDefinitionService>();
        services.AddScoped<External.ExternalProvisioningService>();
        services.AddScoped<PolicyImpactService>();
        services.AddScoped<SimulationService>();

        services.AddScoped<IOutboxEventHandler, ProvisioningEventHandler>();
        return services;
    }
}
