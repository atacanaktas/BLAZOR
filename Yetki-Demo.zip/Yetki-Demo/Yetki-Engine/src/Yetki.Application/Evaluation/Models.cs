using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Attributes;

namespace Yetki.Application.Evaluation;

public sealed class SubjectInfo
{
    /// <summary>Kullanıcı adı (AuthZEN subject.id).</summary>
    public string? Id { get; set; }
    public int? UserId { get; set; }
}

/// <summary>Endpoint bazlı istek (gateway entegrasyonu): motor endpoint'i katalogdan permission'a çözer.</summary>
public sealed class EndpointInfo
{
    /// <summary>API kodu veya audience (api://...).</summary>
    public string Api { get; set; } = default!;
    public string Method { get; set; } = "GET";
    public string Path { get; set; } = "/";
}

/// <summary>
/// Korunan kaynak. Type: katalogdaki resource (yol: ANKA/NAKIT/CEKIM/GISE veya kod: anka.nakit.cekim.gise).
/// Id + Properties: işlem yapılan kaydın kendisi (ör. hesap no; Tenant, BranchCode, CustomerId). Properties bağlama eklenir.
/// </summary>
public sealed class ResourceInfo
{
    public string? Type { get; set; }
    public string? Id { get; set; }
    /// <summary>Kaydın nitelikleri (ör. Tenant, BranchCode, CustomerId). Bağlama eklenir; aynı anahtar Context'te varsa Context kazanır.</summary>
    public Dictionary<string, string?> Properties { get; set; } = new();
}

/// <summary>
/// Standart yetkilendirme isteği: { tenant, client, subject, resource, action, context }.
/// İşlem üç biçimden biriyle belirtilir: Resource.Type + Action (önerilen) · Permission kodu · Endpoint (gateway).
/// Context'teki hiçbir alan zorunlu değildir; rule ihtiyaç duyduğu değeri bulamazsa sonuç Indeterminate olur (asla Permit değil).
/// </summary>
public sealed class AuthorizationRequest
{
    /// <summary>İsteğin yapıldığı tenant kodu (ör. ABANK). Boşsa kullanıcının tenant'ı kabul edilir.</summary>
    public string? Tenant { get; set; }
    public SubjectInfo Subject { get; set; } = new();
    /// <summary>Resource üzerinde yapılacak işlem (create, read, approve...). Resource.Type ile birlikte permission'ı belirler.</summary>
    public string? Action { get; set; }
    /// <summary>Permission kodu (ör. anka.nakit.cekim.gise:create). Resource + Action veya Endpoint verilmişse boş olabilir.</summary>
    public string? Permission { get; set; }
    public EndpointInfo? Endpoint { get; set; }
    public ResourceInfo? Resource { get; set; }
    public Dictionary<string, string?> Context { get; set; } = new();
    /// <summary>
    /// İsteği BAŞLATAN OAuth client (token'daki azp / client_id): Nextral, Anka Web, mobil tablet...
    /// Gateway / BFF üzerinden gelse bile orijinal client'tır; karar buna göre verilir.
    /// </summary>
    public string? Client { get; set; }
    /// <summary>
    /// Access token'a verilmiş OAuth 2.0 scope değerleri. RFC 6749 gereği case-sensitive değerlerdir.
    /// Permission kodu, bu sistemde aynı zamanda ilgili ince taneli OAuth scope değeridir.
    /// </summary>
    public List<string> Scopes { get; set; } = new();
    /// <summary>
    /// Aracı zinciri (dıştan içe): isteği kullanıcı adına ileten gateway / BFF / servisler (RFC 8693 "act").
    /// Her biri kayıtlı Intermediary client olmalı ve bu API'yi iletmeye yetkili olmalı; karar audit'inde görünür.
    /// </summary>
    public List<string> Via { get; set; } = new();
    public string? CorrelationId { get; set; }
}

/// <summary>Motor davranış ayarları (appsettings: "AuthorizationEngine").</summary>
public sealed class AuthorizationEngineOptions
{
    /// <summary>true: client belirtilmeyen istekler reddedilir.</summary>
    public bool RequireClient { get; set; }
    /// <summary>true: access token'ın scope listesi istenen Permission kodunu içermelidir.</summary>
    public bool RequireGrantedScopes { get; set; }
}

/// <summary>Karar akışının bir adımı (açıklanabilirlik): Pass / Fail / Info / Skip.</summary>
public sealed record DecisionStep(string Step, string Outcome, string Detail);

public sealed record ExcludedPolicyInfo(string Code, string MatchedBy, string ExcludedBy);

/// <summary>Açıklanabilir karar: karar + neden + adımlar + kararı veren policy/rule + kullanılan değerler.</summary>
public sealed class AuthorizationDecision
{
    public Guid DecisionId { get; set; }
    public DecisionType Decision { get; set; }
    /// <summary>Enforcement için tek doğru: yalnızca Permit izin verir.</summary>
    public bool IsAllowed => Decision == DecisionType.Permit;
    public string ReasonCode { get; set; } = default!;
    public string HumanReadableReason { get; set; } = default!;

    public string? UserName { get; set; }
    public string? Tenant { get; set; }
    public string? Client { get; set; }
    /// <summary>Doğrulanmış aracı zinciri (gateway, BFF, kullanıcı adına çağıran servisler).</summary>
    public IReadOnlyList<string> Via { get; set; } = [];
    /// <summary>PEP'in yerine getirmesi gereken yükümlülükler (ör. MASK_FIELDS). Yerine getiremiyorsa erişimi reddetmeli.</summary>
    public IReadOnlyList<DecisionObligation> Obligations { get; set; } = [];
    public string? Permission { get; set; }
    public string? Action { get; set; }
    public string? PermissionName { get; set; }
    public string? Application { get; set; }
    public string? CatalogPath { get; set; }
    public string? Endpoint { get; set; }
    public string? Resource { get; set; }
    public string? DecidingPolicy { get; set; }
    public string? DecidingRule { get; set; }

    public DateTime EvaluatedAt { get; set; }
    public bool IsSimulation { get; set; }
    public long ModelVersion { get; set; }
    public double DurationMs { get; set; }

    public List<DecisionStep> Steps { get; set; } = new();
    public IReadOnlyList<PermissionSource> PermissionSources { get; set; } = [];
    /// <summary>Client kaydında bu Permission'a izin veren kayıtlı izin.</summary>
    public string? ClientAllowedPermission { get; set; }
    /// <summary>Access token ile sunulan OAuth scope değerleri.</summary>
    public IReadOnlyList<string> GrantedScopes { get; set; } = [];
    /// <summary>İstenen Permission ile eşleşen token scope değeri.</summary>
    public string? MatchedScope { get; set; }
    public IReadOnlyList<PolicyEvaluation> Policies { get; set; } = [];
    public IReadOnlyList<ExcludedPolicyInfo> ExcludedPolicies { get; set; } = [];
    /// <summary>ReportOnly modundaki ve Enforce olsaydı reddedecek policy'ler (kararı etkilemez).</summary>
    public IReadOnlyList<string> ReportOnlyDenials { get; set; } = [];
    public IReadOnlyList<string> FailedRules { get; set; } = [];
    public IReadOnlyList<string> MissingAttributes { get; set; } = [];
    public IReadOnlyList<UsedAttribute> Evidence { get; set; } = [];
    public IReadOnlyDictionary<string, string?> Context { get; set; } = new Dictionary<string, string?>();
}

/// <summary>Aynı evaluator'ın simülasyon parametreleri. Gerçek kararda hepsi varsayılandır.</summary>
public sealed class EvaluationOptions
{
    /// <summary>Kararın verileceği model (What-If). Boşsa güncel model.</summary>
    public AuthorizationModel? Model { get; init; }
    /// <summary>Sadece simülasyonda: kararın hangi an için verileceği. Gerçek kararda motor saati kullanılır.</summary>
    public DateTime? AsOfUtc { get; init; }
    public bool IsSimulation { get; init; }
    public bool WriteAudit { get; init; } = true;
    public string? Actor { get; init; }

    public static readonly EvaluationOptions Default = new();
}
