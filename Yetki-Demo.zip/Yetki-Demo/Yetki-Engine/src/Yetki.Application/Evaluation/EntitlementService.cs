using Yetki.Application.Abstractions;
using Yetki.Application.Common;
using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Domain.Common;
using Microsoft.Extensions.Options;

namespace Yetki.Application.Evaluation;

public sealed class EntitlementRequest
{
    public string User { get; set; } = default!;
    /// <summary>OAuth Client. Verilirse erişimler Client Allowed Permissions ile kesiştirilir.</summary>
    public string? Client { get; set; }
    /// <summary>Access token'a verilmiş OAuth scope değerleri.</summary>
    public List<string> Scopes { get; set; } = new();
    /// <summary>UI öğeleri istenecek uygulama (ör. NEXTRAL).</summary>
    public string? Application { get; set; }
    /// <summary>true: policy'li yetkiler için verilen bağlamla (IP, kanal...) şu anki karar da hesaplanır (buton gri/aktif ipucu).</summary>
    public bool Evaluate { get; set; }
    public Dictionary<string, string?> Context { get; set; } = new();
}

public sealed record RuntimeCheck(DecisionType Decision, string ReasonCode, string Reason);

public sealed record EntitledPermission(
    int PermissionId, string Code, string Name, string Application, string Path, string Action, Severity RiskLevel,
    IReadOnlyList<string> Sources, string? ClientAllowedPermission, string? MatchedScope,
    IReadOnlyList<string> Policies, bool RequiresRuntimeCheck, RuntimeCheck? Runtime);

public sealed record UiEntitlement(
    int Id, string Code, string Name, UiElementKind Kind, string? ParentCode, string Path, string? Permission,
    bool Enabled, string Reason, RuntimeCheck? Runtime);

public sealed class EntitlementResult
{
    public string UserName { get; init; } = default!;
    public string FullName { get; init; } = default!;
    public string Tenant { get; init; } = default!;
    public string? Client { get; init; }
    public long ModelVersion { get; init; }
    public DateTime ComputedAt { get; init; }
    /// <summary>İstemci önbelleği için: model versiyonu + kullanıcı + client. Değişmediyse istemci eski listeyi kullanabilir.</summary>
    public string ETag { get; init; } = default!;
    public IReadOnlyList<EntitledPermission> Permissions { get; init; } = [];
    /// <summary>Kullanıcının sahip olduğu ama bu client üzerinden kullanamayacağı yetkiler.</summary>
    public IReadOnlyList<string> BlockedByClientPermission { get; init; } = [];
    public IReadOnlyList<string> BlockedByTokenScope { get; init; } = [];
    public IReadOnlyList<UiEntitlement> UiElements { get; init; } = [];
}

/// <summary>
/// Login-time toplu yetki listesi (Nextral gibi masaüstü istemciler buton/menü açıp kapamak için).
/// Liste STATİKTİR (RBAC ∩ client). Policy'li yetkiler RequiresRuntimeCheck=true döner: istemci butonu açsa bile
/// işlem anında API/PDP tekrar karar verir (asıl güvenlik sunucudadır). Evaluate=true ile "şu an" kararı da ipucu olarak döner.
/// </summary>
public sealed class EntitlementService(AuthorizationModelProvider models, AuthorizationEvaluator evaluator,
    IOptions<AuthorizationEngineOptions> engineOptions, IClock clock)
{
    public async Task<EntitlementResult> GetAsync(EntitlementRequest request, CancellationToken ct = default)
    {
        var model = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        if (!model.UserIdByName.TryGetValue(request.User.Trim(), out var userId)) throw new NotFoundException("Kullanıcı", request.User);
        var user = model.Users[userId];

        ClientRow? client = null;
        if (!string.IsNullOrWhiteSpace(request.Client) && (!model.ClientsById.TryGetValue(request.Client.Trim(), out client) || !client.IsActive))
            throw new NotFoundException("Client", request.Client);
        if (client is { Type: ClientType.Intermediary })
            throw new ValidationException($"'{client.ClientId}' bir aracıdır (gateway/BFF); entitlement orijinal client için istenmeli.");
        if (client is not null && !model.IsAvailableIn(client.TenantId, user.TenantId))
            throw new ValidationException($"'{client.ClientId}' client'ı {model.TenantCode(client.TenantId)} tenant'ında kayıtlı; {model.TenantCode(user.TenantId)} kullanıcıları için kullanılamaz.");

        var set = model.GetEffective(userId, now);
        var permissions = new List<EntitledPermission>();
        var blockedByClientPermission = new List<string>();
        var blockedByScope = new List<string>();
        var scopes = request.Scopes.Where(s => !string.IsNullOrWhiteSpace(s)).Select(s => s.Trim()).Distinct(StringComparer.Ordinal).ToHashSet(StringComparer.Ordinal);

        foreach (var ep in set.Permissions)
        {
            var info = model.Permissions[ep.PermissionId];
            string? via = null;
            if (client is not null && !model.ClientAllows(client, info, out via))
            {
                blockedByClientPermission.Add(ep.Code);
                continue;
            }
            var matchedScope = scopes.Contains(ep.Code) ? ep.Code : null;
            if ((engineOptions.Value.RequireGrantedScopes || scopes.Count > 0) && matchedScope is null)
            {
                blockedByScope.Add(ep.Code);
                continue;
            }
            var policies = model.GetApplicablePolicies(ep.PermissionId, user.TenantId, client).Applied
                .Where(a => a.Policy.Row.Mode == PolicyMode.Enforce).Select(a => a.Policy.Row.Code).ToList();

            RuntimeCheck? runtime = null;
            if (request.Evaluate && policies.Count > 0 && user.IsActive)
            {
                var decision = await evaluator.EvaluateAsync(new AuthorizationRequest
                {
                    Subject = new SubjectInfo { UserId = userId },
                    Permission = ep.Code,
                    Client = client?.ClientId,
                    Scopes = request.Scopes,
                    Context = request.Context
                }, new EvaluationOptions { Model = model, WriteAudit = false }, ct);
                runtime = new RuntimeCheck(decision.Decision, decision.ReasonCode, decision.HumanReadableReason);
            }

            permissions.Add(new EntitledPermission(ep.PermissionId, ep.Code, ep.Name, ep.Application, ep.Path, ep.Action, ep.RiskLevel,
                ep.Sources.Select(s => s.Path).ToList(), via, matchedScope, policies, policies.Count > 0, runtime));
        }

        var ui = new List<UiEntitlement>();
        if (!string.IsNullOrWhiteSpace(request.Application) && model.AppByCode.TryGetValue(request.Application.Trim(), out var app))
        {
            var byId = permissions.ToDictionary(p => p.PermissionId);
            var elements = model.Data.UiElements.Where(e => model.Nodes.TryGetValue(e.CatalogNodeId, out var n) && n.ApplicationId == app.Id).ToList();
            var codes = elements.ToDictionary(e => e.Id, e => e.Code);
            var enabled = new Dictionary<int, bool>();

            // Üst öğe kapalıysa alt öğeler de kapalı: önce ebeveynler (derinliğe göre).
            foreach (var e in elements.OrderBy(e => Depth(e, elements)).ThenBy(e => e.Order))
            {
                var parentOn = e.ParentId is not { } pid || enabled.GetValueOrDefault(pid, true);
                string reason;
                bool on;
                RuntimeCheck? rt = null;
                string? permCode = e.PermissionId is { } p && model.Permissions.TryGetValue(p, out var pi) ? pi.Code : null;

                if (!parentOn) { on = false; reason = "Üst ekran/menü kapalı."; }
                else if (e.PermissionId is null) { on = true; reason = "Yetki gerektirmez."; }
                else if (byId.TryGetValue(e.PermissionId.Value, out var ent))
                {
                    rt = ent.Runtime;
                    on = rt is null || rt.Decision == DecisionType.Permit;
                    reason = rt is null
                        ? ent.RequiresRuntimeCheck ? $"Yetkili; işlem anında policy kontrolü ({string.Join(", ", ent.Policies)})." : "Yetkili."
                        : rt.Decision == DecisionType.Permit ? "Yetkili; şu an policy'ler izin veriyor." : $"Yetkili ama şu an kullanılamaz: {rt.Reason}";
                }
                else if (permCode is not null && blockedByClientPermission.Contains(permCode)) { on = false; reason = $"Yetki var ama '{client?.ClientId}' için bu Permission izinli değil."; }
                else if (permCode is not null && blockedByScope.Contains(permCode)) { on = false; reason = $"Token '{permCode}' scope'una sahip değil."; }
                else { on = false; reason = $"Yetki yok ({permCode})."; }

                enabled[e.Id] = on;
                ui.Add(new UiEntitlement(e.Id, e.Code, e.Name, e.Kind, e.ParentId is { } par ? codes.GetValueOrDefault(par) : null,
                    model.Nodes[e.CatalogNodeId].Path, permCode, on, reason, rt));
            }
        }

        return new EntitlementResult
        {
            UserName = user.UserName,
            FullName = user.FullName,
            Tenant = model.TenantCode(user.TenantId),
            Client = client?.ClientId,
            ModelVersion = model.Version,
            ComputedAt = now,
            ETag = $"\"{model.Version}-{userId}-{client?.Id ?? 0}-{string.Join(',', scopes.Order())}\"",
            Permissions = permissions,
            BlockedByClientPermission = blockedByClientPermission,
            BlockedByTokenScope = blockedByScope,
            UiElements = ui
        };

        static int Depth(UiRow e, List<UiRow> all)
        {
            var d = 0;
            var cur = e;
            while (cur.ParentId is { } p && d < 10 && all.FirstOrDefault(x => x.Id == p) is { } parent) { d++; cur = parent; }
            return d;
        }
    }
}
