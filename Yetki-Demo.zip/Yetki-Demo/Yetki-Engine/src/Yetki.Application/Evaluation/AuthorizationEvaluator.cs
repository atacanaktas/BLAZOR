using System.Diagnostics;
using System.Globalization;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Context;
using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Domain.Common;
using Yetki.Domain.Governance;

namespace Yetki.Application.Evaluation;

/// <summary>
/// Yetkilendirme karar noktası (PDP). Akış (hibrit RBAC + policy):
///
///   0 Subject    kimlik: kullanıcı (veya servis client'ının servis hesabı) var ve aktif mi?
///   1 Tenant     istek tenant'ı geçerli mi, kullanıcı bu tenant'a mı ait, kaydın tenant'ı aynı mı? (tenant izolasyonu)
///   2 Client     client kayıtlı/aktif mi, bu tenant'ta (veya üst tenant'ta) kayıtlı mı?
///   3 Resource   resource + action (veya permission kodu / endpoint) → permission; kaynak bu tenant'ta mı?
///   4 OAuth      client için permission önceden izinli mi ve access token scope'u permission'ı kapsıyor mu?
///   5 RBAC       User → Role / Group → Permission: temel yetki var mı? Yoksa DENY (policy'ye geçilmez)
///   6 Policy     permission'a bağlı (miras dahil) policy'ler → Rule'lar: koşullar sağlanıyor mu?
///   Karar        RBAC Permit ∧ tüm Enforce policy'ler Permit → PERMIT; biri Deny → DENY; belirsizlik → INDETERMINATE (fail-closed)
///
/// Policy yetki VERMEZ, RBAC'ın verdiği yetkiyi koşullara bağlar. ReportOnly policy'ler değerlendirilir, kaydedilir ama kararı etkilemez.
/// Gerçek karar ve What-If aynı metodu kullanır (model parametresi ile).
/// </summary>
public sealed class AuthorizationEvaluator(
    AuthorizationModelProvider models,
    PolicyEvaluator policyEvaluator,
    IEnumerable<IAttributeValueProvider> attributeProviders,
    IAttributeRedactor redactor,
    IOptions<AuthorizationEngineOptions> engineOptions,
    AuditWriter audit,
    IYetkiDbContext db,
    IClock clock,
    ILogger<AuthorizationEvaluator> logger)
{
    private readonly IReadOnlyList<IAttributeValueProvider> _providers = attributeProviders.ToList();

    public async Task<AuthorizationDecision> EvaluateAsync(AuthorizationRequest request, EvaluationOptions? options = null, CancellationToken ct = default)
    {
        options ??= EvaluationOptions.Default;
        var sw = Stopwatch.StartNew();
        var model = options.Model ?? await models.GetCurrentAsync(ct);
        var now = options.IsSimulation && options.AsOfUtc is { } asOf ? asOf.ToUniversalTime() : clock.UtcNow;

        var decision = new AuthorizationDecision
        {
            DecisionId = Guid.NewGuid(),
            EvaluatedAt = now,
            IsSimulation = options.IsSimulation || model.IsSimulation,
            ModelVersion = model.Version,
            Client = string.IsNullOrWhiteSpace(request.Client) ? null : Codes.Lower(request.Client),
            GrantedScopes = request.Scopes.Where(s => !string.IsNullOrWhiteSpace(s)).Select(s => s.Trim()).Distinct(StringComparer.Ordinal).ToArray(),
            Resource = request.Resource is null ? null : new ResourceRef(request.Resource.Type, request.Resource.Id).ToString(),
            Endpoint = request.Endpoint is null ? null : $"{request.Endpoint.Method.ToUpperInvariant()} {request.Endpoint.Api}{request.Endpoint.Path}"
        };
        var context = BuildContext(request, decision.Client, now);
        decision.Context = context.Values;

        try
        {
            await EvaluateCoreAsync(request, model, now, context, decision, ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogError(ex, "Authorization evaluation failed for {User}/{Permission}", request.Subject?.Id, request.Permission);
            Set(decision, DecisionType.Indeterminate, "ENGINE_ERROR", "Karar motorunda hata oluştu; güvenli tarafta kalınarak izin verilmedi.");
        }

        sw.Stop();
        decision.DurationMs = Math.Round(sw.Elapsed.TotalMilliseconds, 3);
        if (options.WriteAudit)
        {
            WriteAudit(decision, request, options);
            await db.SaveChangesAsync(ct);
        }
        return decision;
    }

    private async Task EvaluateCoreAsync(AuthorizationRequest request, AuthorizationModel model, DateTime now,
        AuthorizationContext context, AuthorizationDecision d, CancellationToken ct)
    {
        // ---------------- Kimlik (subject) ----------------
        // Servis client'ı (client credentials) kullanıcı olmadan kendi servis hesabıyla gelir; bu yüzden client önce bulunur.
        ClientRow? client = d.Client is null ? null : model.ClientsById.GetValueOrDefault(d.Client);
        int? userId = request.Subject?.UserId;
        if (userId is null && !string.IsNullOrWhiteSpace(request.Subject?.Id) && model.UserIdByName.TryGetValue(request.Subject.Id.Trim(), out var byName))
            userId = byName;
        var viaServiceAccount = false;
        if (userId is null && string.IsNullOrWhiteSpace(request.Subject?.Id) && client is { IsActive: true, Type: ClientType.Service, ServiceAccountUserId: { } svc })
        {
            userId = svc;
            viaServiceAccount = true;
        }
        if (userId is null || !model.Users.TryGetValue(userId.Value, out var user))
        {
            Step(d, "Subject", "Fail", $"Kullanıcı bulunamadı: {request.Subject?.Id ?? request.Subject?.UserId?.ToString() ?? "(boş)"}");
            Set(d, DecisionType.Deny, "USER_NOT_FOUND", "Kullanıcı bulunamadı.");
            return;
        }
        d.UserName = user.UserName;
        if (!user.IsActive)
        {
            Step(d, "Subject", "Fail", $"'{user.UserName}' pasif.");
            Set(d, DecisionType.Deny, "USER_INACTIVE", $"Kullanıcı '{user.UserName}' pasif.");
            return;
        }
        Step(d, "Subject", "Pass", viaServiceAccount
            ? $"Kullanıcı yok; servis client'ı '{client!.ClientId}' servis hesabı {user.UserName} ile değerlendirildi (client credentials)."
            : $"{user.UserName} ({user.FullName}) · {model.TenantCode(user.TenantId)} · {string.Join(",", model.UnitCodesOf(user.Id))}");

        // ---------------- 1) Tenant ----------------
        TenantRow? tenant;
        var tenantNote = "";
        if (string.IsNullOrWhiteSpace(request.Tenant))
        {
            tenant = model.Tenants.GetValueOrDefault(user.TenantId);
            tenantNote = " (istekte tenant yok; kullanıcının tenant'ı kullanıldı)";
        }
        else if (!model.TenantByCode.TryGetValue(request.Tenant.Trim(), out tenant))
        {
            Step(d, "Tenant", "Fail", $"'{request.Tenant}' kayıtlı bir tenant değil.");
            Set(d, DecisionType.Deny, "TENANT_UNKNOWN", $"'{request.Tenant}' kayıtlı bir tenant değil.");
            return;
        }
        if (tenant is null || !tenant.IsActive)
        {
            Step(d, "Tenant", "Fail", $"Tenant '{tenant?.Code ?? request.Tenant}' pasif veya yok.");
            Set(d, DecisionType.Deny, "TENANT_INACTIVE", $"Tenant '{tenant?.Code ?? request.Tenant}' pasif veya tanımsız.");
            return;
        }
        d.Tenant = tenant.Code;
        if (user.TenantId != tenant.Id)
        {
            Step(d, "Tenant", "Fail", $"{user.UserName} '{model.TenantCode(user.TenantId)}' tenant'ına ait; '{tenant.Code}' adına işlem yapamaz.");
            Set(d, DecisionType.Deny, "TENANT_MISMATCH",
                $"'{user.UserName}' kullanıcısı '{model.TenantCode(user.TenantId)}' tenant'ına ait; '{tenant.Code}' tenant'ı adına işlem yapamaz (tenant izolasyonu).");
            return;
        }
        // Kaynağın (kaydın) tenant'ı: resource.properties.Tenant (veya context.Tenant). Verildiyse istek tenant'ıyla aynı olmalı.
        if (context.GetString(AuthContextKeys.ResourceTenant) is { Length: > 0 } resourceTenant
            && !string.Equals(resourceTenant, tenant.Code, StringComparison.OrdinalIgnoreCase))
        {
            Step(d, "Tenant", "Fail", $"Kaynak '{resourceTenant}' tenant'ına ait; istek tenant'ı '{tenant.Code}'.");
            Set(d, DecisionType.Deny, "RESOURCE_TENANT_MISMATCH",
                $"Erişilmek istenen kayıt '{resourceTenant}' tenant'ına ait; '{tenant.Code}' kullanıcıları başka tenant'ın kaydına erişemez.");
            return;
        }
        Step(d, "Tenant", "Pass", $"{tenant.Code} ({tenant.Name}){tenantNote}; kullanıcı bu tenant'a ait.");

        // ---------------- 2) Client ----------------
        if (d.Client is not null)
        {
            if (client is null || !client.IsActive)
            {
                Step(d, "Client", "Fail", $"'{d.Client}' kayıtlı/aktif bir client değil.");
                Set(d, DecisionType.Deny, "CLIENT_UNKNOWN", $"'{d.Client}' kayıtlı veya aktif bir client değil.");
                return;
            }
            if (!model.IsAvailableIn(client.TenantId, tenant.Id))
            {
                Step(d, "Client", "Fail", $"'{client.ClientId}' {model.TenantCode(client.TenantId)} tenant'ında kayıtlı; {tenant.Code} için kullanılamaz.");
                Set(d, DecisionType.Deny, "CLIENT_TENANT_MISMATCH",
                    $"'{client.Name}' uygulaması '{model.TenantCode(client.TenantId)}' tenant'ına kayıtlı; '{tenant.Code}' tenant'ında kullanılamaz.");
                return;
            }
            if (client.Type == ClientType.Intermediary)
            {
                // Gateway / BFF isteği başlatmaz: client olarak kendisi gelirse orijinal kanalın kısıtları (ör. mobil sadece okuma) kaybolur.
                Step(d, "Client", "Fail", $"'{client.ClientId}' bir aracıdır (gateway/BFF); orijinal client (azp) client alanında, aracı 'via' alanında gelmeli.");
                Set(d, DecisionType.Deny, "CLIENT_IS_INTERMEDIARY",
                    $"'{client.Name}' bir aracıdır ve isteği başlatan uygulama olamaz. Orijinal client (token'daki azp) iletilmeli; aracı 'via' zincirinde yer alır.");
                return;
            }
        }
        else if (engineOptions.Value.RequireClient)
        {
            Step(d, "Client", "Fail", "Client belirtilmedi.");
            Set(d, DecisionType.Deny, "CLIENT_REQUIRED", "İstek bir client (uygulama) kimliği içermelidir.");
            return;
        }

        // Aracı zinciri: her biri kayıtlı, aktif, Intermediary tipinde ve bu tenant'ta kullanılabilir olmalı
        var intermediaries = new List<ClientRow>();
        foreach (var code in request.Via.Where(v => !string.IsNullOrWhiteSpace(v)).Select(Codes.Lower))
        {
            if (!model.ClientsById.TryGetValue(code, out var hop) || !hop.IsActive || hop.Type != ClientType.Intermediary)
            {
                Step(d, "Client", "Fail", $"Aracı '{code}' kayıtlı/aktif bir aracı (Intermediary) değil.");
                Set(d, DecisionType.Deny, "INTERMEDIARY_UNKNOWN", $"'{code}' kayıtlı bir aracı değil; bilinmeyen aracıdan gelen istek kabul edilmez.");
                return;
            }
            if (!model.IsAvailableIn(hop.TenantId, tenant.Id))
            {
                Step(d, "Client", "Fail", $"Aracı '{hop.ClientId}' {tenant.Code} için kullanılamaz.");
                Set(d, DecisionType.Deny, "INTERMEDIARY_TENANT_MISMATCH", $"Aracı '{hop.ClientId}' '{tenant.Code}' tenant'ında kullanılamaz.");
                return;
            }
            intermediaries.Add(hop);
        }
        d.Via = intermediaries.Select(v => v.ClientId).ToList();
        var viaText = intermediaries.Count > 0 ? $" · aracı: {string.Join(" → ", d.Via)}" : "";

        if (client is not null)
        {
            Step(d, "Client", "Pass", $"'{client.ClientId}' ({client.Type}) kayıtlı ve aktif · tenant {model.TenantCode(client.TenantId)}"
                + (client.TenantId != tenant.Id ? " (üst tenant'tan miras)" : "") + viaText + ".");
        }
        else
        {
            Step(d, "Client", "Skip", "Client belirtilmedi (motor ayarı: zorunlu değil)" + viaText + ".");
        }

        // ---------------- 3) Resource + Action → permission ----------------
        PermInfo? perm;
        string via;
        if (request.Endpoint is { } ep)
        {
            var api = model.FindApi(ep.Api);
            var endpoint = api is null ? null : model.MatchEndpoint(api, ep.Method, ep.Path);
            if (api is null || endpoint is null)
            {
                Step(d, "Resource", "Fail", api is null ? $"API bulunamadı: {ep.Api}" : $"{ep.Method.ToUpperInvariant()} {ep.Path} katalogda yok.");
                Set(d, DecisionType.Deny, "ENDPOINT_UNKNOWN", $"Endpoint katalogda tanımlı değil: {d.Endpoint}. Tanımsız endpoint'e izin verilmez.");
                return;
            }
            if (endpoint.PermissionId is null || !model.Permissions.TryGetValue(endpoint.PermissionId.Value, out perm))
            {
                Step(d, "Resource", "Fail", $"{endpoint.Method} {endpoint.Path} hiçbir permission'a eşlenmemiş.");
                Set(d, DecisionType.Deny, "ENDPOINT_NOT_MAPPED", $"{endpoint.Method} {api.Code}{endpoint.Path} bir permission'a eşlenmemiş (fail-closed).");
                return;
            }
            via = $"endpoint {endpoint.Method} {api.Code}{endpoint.Path}";
        }
        else if (!string.IsNullOrWhiteSpace(request.Permission))
        {
            var code = Codes.Lower(request.Permission);
            if (!model.PermissionIdByCode.TryGetValue(code, out var pid) || !model.Permissions.TryGetValue(pid, out perm))
            {
                Step(d, "Resource", "Fail", $"'{code}' katalogda yok.");
                d.Permission = code;
                Set(d, DecisionType.Deny, "PERMISSION_UNKNOWN", $"'{code}' katalogda tanımlı bir permission değil.");
                return;
            }
            via = "permission kodu";
        }
        else if (!string.IsNullOrWhiteSpace(request.Resource?.Type) && !string.IsNullOrWhiteSpace(request.Action))
        {
            perm = model.FindPermission(request.Resource.Type, request.Action);
            if (perm is null)
            {
                Step(d, "Resource", "Fail", $"'{request.Resource.Type}' kaynağında '{request.Action}' action'ı tanımlı değil.");
                d.Permission = $"{request.Resource.Type}:{request.Action}";
                Set(d, DecisionType.Deny, "PERMISSION_UNKNOWN", $"Katalogda '{request.Resource.Type}' kaynağı için '{request.Action}' action'ı yok.");
                return;
            }
            via = $"resource {request.Resource.Type} + action {request.Action}";
        }
        else
        {
            Step(d, "Resource", "Fail", "İstekte resource + action, permission veya endpoint yok.");
            Set(d, DecisionType.Deny, "RESOURCE_REQUIRED", "İstek hangi kaynak üzerinde hangi işlemin yapılacağını belirtmelidir (resource + action).");
            return;
        }

        d.Permission = perm.Code;
        d.PermissionName = perm.Row.Name;
        d.Application = perm.App?.Code;
        d.CatalogPath = perm.Path;
        d.Action = perm.Row.Action;
        if (!perm.Row.IsActive || perm.App?.IsActive == false)
        {
            Step(d, "Resource", "Fail", perm.App?.IsActive == false ? $"{perm.App.Code} uygulaması pasif." : $"{perm.Code} pasif.");
            Set(d, DecisionType.Deny, "PERMISSION_INACTIVE", perm.App?.IsActive == false ? $"'{perm.App.Code}' uygulaması pasif." : $"'{perm.Code}' pasif.");
            return;
        }
        if (!model.IsAvailableIn(perm.TenantId, tenant.Id))
        {
            Step(d, "Resource", "Fail", $"{perm.Path} kaynağı {model.TenantCode(perm.TenantId)} tenant'ına ait; {tenant.Code} için tanımlı değil.");
            Set(d, DecisionType.Deny, "RESOURCE_NOT_IN_TENANT",
                $"'{perm.Path}' kaynağı '{model.TenantCode(perm.TenantId)}' tenant'ına ait; '{tenant.Code}' tenant'ında kullanılamaz.");
            return;
        }
        Step(d, "Resource", "Pass", $"Resource {perm.Path} · Action {perm.Row.Action} → {perm.Code} · risk={perm.Row.RiskLevel}");
        if (client is not null)
        {
            if (!model.ClientAllows(client, perm, out var grant))
            {
                Step(d, "Resource", "Fail", $"{perm.Path} : {perm.Row.Action} → '{client.ClientId}' bu kaynağa/action'a erişemez.");
                Set(d, DecisionType.Deny, "CLIENT_PERMISSION_NOT_ALLOWED",
                    $"'{client.Name}' uygulaması '{perm.Code}' işlemine izinli değil. Kullanıcının yetkisi olsa bile bu uygulama üzerinden yapılamaz.");
                return;
            }
            d.ClientAllowedPermission = grant;
            Step(d, "Client Permission", "Pass", $"'{client.ClientId}' için allowed permission: {grant}");
        }
        else Step(d, "Client Permission", "Skip", "Client belirtilmediği için kayıtlı Client Permission kontrolü uygulanmadı.");
        if (engineOptions.Value.RequireGrantedScopes || d.GrantedScopes.Count > 0)
        {
            if (d.GrantedScopes.Count == 0)
            {
                Step(d, "OAuth Scope", "Fail", "Access token üzerinde granted scope bulunamadı.");
                Set(d, DecisionType.Deny, "TOKEN_SCOPE_REQUIRED", $"Access token '{perm.Code}' scope'unu içermelidir.");
                return;
            }
            d.MatchedScope = d.GrantedScopes.FirstOrDefault(s => string.Equals(s, perm.Code, StringComparison.Ordinal));
            if (d.MatchedScope is null)
            {
                Step(d, "OAuth Scope", "Fail", $"Granted scopes, '{perm.Code}' permission'ını kapsamıyor.");
                Set(d, DecisionType.Deny, "INSUFFICIENT_SCOPE", $"Access token '{perm.Code}' scope'una sahip değil.");
                return;
            }
            Step(d, "OAuth Scope", "Pass", $"Token scope: {d.MatchedScope}");
        }
        else Step(d, "OAuth Scope", "Skip", "Token scope enforcement yapılandırmada zorunlu değil.");
        foreach (var hop in intermediaries)
        {
            if (!model.ClientAllows(hop, perm, out _))
            {
                Step(d, "Resource", "Fail", $"Aracı '{hop.ClientId}' {perm.Path} : {perm.Row.Action} işlemini iletmeye yetkili değil.");
                Set(d, DecisionType.Deny, "INTERMEDIARY_NOT_ALLOWED", $"Aracı '{hop.Name}' '{perm.Code}' işlemini kullanıcı adına iletmeye yetkili değil.");
                return;
            }
        }
        // ---------------- 4) RBAC: User → Role / Group → Permission ----------------
        var set = model.GetEffective(user.Id, now);
        var held = set.Find(perm.Id);
        if (held is null)
        {
            Step(d, "RBAC", "Fail", "Hiçbir rol / grup / doğrudan atama bu yetkiyi vermiyor. Policy değerlendirilmedi.");
            Set(d, DecisionType.Deny, "PERMISSION_NOT_GRANTED", $"'{user.UserName}' kullanıcısının '{perm.Code}' yetkisi yok.");
            return;
        }
        d.PermissionSources = held.Sources;
        Step(d, "RBAC", "Pass", string.Join(" | ", held.Sources.Select(s => s.Path)));

        // ---------------- 5) Policy → Rule ----------------
        var applicability = model.GetApplicablePolicies(perm.Id, tenant.Id, client);
        d.ExcludedPolicies = applicability.Excluded.Select(x => new ExcludedPolicyInfo(x.Policy.Row.Code, x.MatchedBy, x.ExcludedBy)).ToList();
        if (applicability.Applied.Count == 0)
        {
            Step(d, "Policy", "Skip", "Bu permission'a bağlı policy yok" + (d.ExcludedPolicies.Count > 0 ? $" ({d.ExcludedPolicies.Count} policy hariç tutuldu)." : "."));
            Set(d, DecisionType.Permit, "PERMIT_NO_POLICY", $"Yetki var ({held.Sources[0].Path}); koşul bağlayan policy yok.");
            return;
        }

        var resolver = new AttributeResolver(_providers, new AttributeResolutionScope
        {
            Subject = new SubjectRef(user.Id, user.UserName),
            Context = context,
            Action = perm.Code,
            Resource = request.Resource is null ? null : new ResourceRef(request.Resource.Type, request.Resource.Id),
            Model = model,
            Now = now
        });

        var evaluations = new List<PolicyEvaluation>();
        foreach (var ap in applicability.Applied)
        {
            var e = await policyEvaluator.EvaluateAsync(ap.Policy.Definition, resolver, perm.Code, ct);
            evaluations.Add(e with { MatchedBy = ap.MatchedBy, Mode = ap.Policy.Row.Mode, Tenant = ap.Policy.TenantCode });
        }

        var enforced = evaluations.Select((e, i) => (e, i)).Where(x => x.e.Mode == PolicyMode.Enforce).ToList();
        var reportOnly = evaluations.Where(e => e.Mode == PolicyMode.ReportOnly).ToList();
        d.ReportOnlyDenials = reportOnly.Where(e => e.Result is DecisionType.Deny or DecisionType.Indeterminate).Select(e => $"{e.Code} → {e.Result} ({e.DecidingRule})").ToList();

        // Nihai karar: RBAC Permit ∧ tüm (Enforce) policy'ler Permit. Biri Deny → Deny; biri belirsiz → Indeterminate (fail-closed).
        var combined = AllRulesMustPassAlgorithm.Evaluate(enforced.Select(x => x.e.Result).ToList());
        if (combined.DecidingIndex is { } di && combined.Decision is DecisionType.Deny or DecisionType.Indeterminate)
            evaluations[enforced[di].i] = evaluations[enforced[di].i] with { IsDeciding = true };

        d.Policies = evaluations;
        d.Evidence = resolver.Used.DistinctBy(u => u.Attribute).ToList();
        var enforcedRules = evaluations.Where(e => e.Mode == PolicyMode.Enforce).SelectMany(e => e.Rules).ToList();
        d.FailedRules = enforcedRules.Where(r => r.Result is DecisionType.Deny or DecisionType.Indeterminate).Select(r => r.Code).Distinct().ToList();
        d.MissingAttributes = enforcedRules.SelectMany(r => r.MissingAttributes).Distinct().ToList();

        var deciding = evaluations.FirstOrDefault(e => e.IsDeciding);
        var decidingRule = deciding?.Rules.FirstOrDefault(r => r.IsDeciding);
        d.DecidingPolicy = deciding?.Code;
        d.DecidingRule = decidingRule?.Code;

        foreach (var e in evaluations)
            Step(d, $"Policy {e.Code}", e.Mode == PolicyMode.ReportOnly ? "Info" : e.Result == DecisionType.Deny || e.Result == DecisionType.Indeterminate ? "Fail" : "Pass",
                $"{(e.Mode == PolicyMode.ReportOnly ? "[ReportOnly] " : "")}{e.MatchedBy} ({e.Tenant}) → {e.Result} · " +
                string.Join(", ", e.Rules.Where(r => r.IsActive).Select(r => $"{r.Code}: {RuleOutcome(r.Result)}")));

        // Yükümlülükler: Enforce policy'lerden; Permit'te karara katılan (Deny/belirsiz olmayan) policy'lerin FulfillOn=Permit olanları,
        // Deny'da FulfillOn=Deny olanları. ReportOnly policy yükümlülük üretmez.
        var final = combined.Decision is DecisionType.Deny or DecisionType.Indeterminate ? combined.Decision : DecisionType.Permit;
        var byCode = applicability.Applied.ToDictionary(a => a.Policy.Row.Code, a => a.Policy);
        d.Obligations = evaluations
            .Where(e => e.Mode == PolicyMode.Enforce && (final == DecisionType.Permit ? e.Result is not (DecisionType.Deny or DecisionType.Indeterminate) : final == DecisionType.Deny))
            .SelectMany(e => byCode[e.Code].Obligations
                .Where(o => o.FulfillOn == (final == DecisionType.Permit ? ObligationFulfillOn.Permit : ObligationFulfillOn.Deny))
                .Select(o => new DecisionObligation(o.Code, e.Code, o.Params)))
            .ToList();
        if (d.Obligations.Count > 0)
            Step(d, "Obligation", "Info", string.Join(" · ", d.Obligations.Select(o => $"{o.Code}({string.Join(", ", o.Parameters.Select(p => $"{p.Key}={p.Value}"))}) ← {o.Policy}")));

        switch (combined.Decision)
        {
            case DecisionType.Deny:
                Set(d, DecisionType.Deny, decidingRule?.ReasonCode ?? decidingRule?.Code ?? "DENIED_BY_POLICY",
                    $"{deciding!.Code} / {decidingRule?.Code} sağlanmadı: {decidingRule?.Name}. {decidingRule?.Condition?.Message}");
                break;
            case DecisionType.Indeterminate:
                Set(d, DecisionType.Indeterminate, d.MissingAttributes.Count > 0 ? "MISSING_ATTRIBUTE" : "EVALUATION_ERROR",
                    d.MissingAttributes.Count > 0
                        ? $"Karar için gerekli değer eksik: {string.Join(", ", d.MissingAttributes)} ({deciding?.Code}/{decidingRule?.Code}). Güvenli tarafta kalınarak izin verilmedi."
                        : $"{deciding?.Code}/{decidingRule?.Code} değerlendirilemedi: {decidingRule?.Condition?.Message}. Güvenli tarafta kalınarak izin verilmedi.");
                break;
            default:
                Set(d, DecisionType.Permit, "PERMIT",
                    $"Yetki var ({held.Sources[0].Path}); {enforced.Count} policy'nin koşulları sağlandı." +
                    (d.ReportOnlyDenials.Count > 0 ? $" ReportOnly uyarısı: {string.Join("; ", d.ReportOnlyDenials)}." : ""));
                break;
        }
    }

    private static string RuleOutcome(DecisionType r) => r switch
    {
        DecisionType.Permit => "sağlandı",
        DecisionType.Deny => "sağlanmadı",
        DecisionType.Indeterminate => "belirsiz",
        _ => "pasif"
    };
    private static AuthorizationContext BuildContext(AuthorizationRequest request, string? client, DateTime now)
    {
        var values = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
        if (request.Resource?.Properties is { } props)
            foreach (var (k, v) in props) values[k] = v;
        foreach (var (k, v) in request.Context) values[k] = v;
        var context = new AuthorizationContext(values);

        // Zaman ve client otoritesi motordur: çağıranın gönderdiği zaman sadece audit için saklanır.
        if (context.GetString(AuthContextKeys.CurrentTime) is { } callerTime) context.Set(AuthContextKeys.CallerTime, callerTime);
        context.Set(AuthContextKeys.CurrentTime, now.ToString("o", CultureInfo.InvariantCulture));
        context.Set(AuthContextKeys.ClientId, client);
        return context;
    }

    private static void Step(AuthorizationDecision d, string step, string outcome, string detail) => d.Steps.Add(new DecisionStep(step, outcome, detail));

    private static void Set(AuthorizationDecision d, DecisionType type, string reasonCode, string message)
    {
        d.Decision = type;
        d.ReasonCode = reasonCode;
        d.HumanReadableReason = message.Trim();
    }

    private void WriteAudit(AuthorizationDecision d, AuthorizationRequest request, EvaluationOptions options)
    {
        string? R(string attribute, string? value) => redactor.Redact(attribute, value);
        audit.Add(new AuditLog
        {
            Id = d.DecisionId,
            Timestamp = d.EvaluatedAt,
            Category = d.IsSimulation ? AuditCategory.Simulation : AuditCategory.AuthorizationDecision,
            Actor = options.Actor ?? d.Client ?? "unknown-client",
            Action = d.IsSimulation ? "SimulatedEvaluate" : "Evaluate",
            SubjectUserName = d.UserName ?? request.Subject?.Id,
            ClientId = d.Client,
            PermissionCode = d.Permission,
            Resource = d.Resource,
            Decision = d.Decision.ToString(),
            ReasonCode = d.ReasonCode,
            Summary = d.HumanReadableReason,
            CorrelationId = request.CorrelationId,
            DetailsJson = JsonDefaults.Serialize(new
            {
                d.Endpoint,
                Context = d.Context.ToDictionary(kv => kv.Key, kv => R(AttributeId.ForRequestKey(kv.Key).ToString(), kv.Value)),
                Evidence = d.Evidence.Select(e => e with { Value = R(e.Attribute, e.Value) }),
                d.Steps,
                d.PermissionSources,
                d.ClientAllowedPermission,
                d.GrantedScopes,
                d.MatchedScope,
                d.Via,
                d.Obligations,
                d.DecidingPolicy,
                d.DecidingRule,
                Policies = d.Policies.Select(p => new
                {
                    p.Code, p.Version, p.Mode, p.MatchedBy, p.Tenant, p.Algorithm, p.Result, p.DecidingRule,
                    Rules = p.Rules.Select(r => new { r.Code, r.ConditionValue, r.Result, r.ReasonCode, r.Expression })
                }),
                d.ExcludedPolicies,
                d.ReportOnlyDenials,
                d.FailedRules,
                d.MissingAttributes,
                d.ModelVersion,
                d.DurationMs
            })
        });
    }
}
