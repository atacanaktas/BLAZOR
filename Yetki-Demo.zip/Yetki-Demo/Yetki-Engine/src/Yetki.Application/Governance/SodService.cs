using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Model;
using Yetki.Domain.Common;
using Yetki.Domain.Governance;

namespace Yetki.Application.Governance;

public sealed record SodMemberSnapshot(SodMemberType Type, int Id, string Code, string Name);

public sealed record SodRuleSnapshot(int Id, string Code, string Name, Severity Severity, SodEnforcement Enforcement, IReadOnlyList<SodMemberSnapshot> Members);

public sealed record SodMatchedMember(SodMemberType Type, int Id, string Code, string Name, IReadOnlyList<string> Paths);

public sealed record SodConflict(int SodRuleId, string Code, string Name, Severity Severity, SodEnforcement Enforcement, IReadOnlyList<SodMatchedMember> MatchedMembers)
{
    public string Describe() => $"{Code}: " + string.Join(" + ", MatchedMembers.Select(m => $"{m.Code} [{string.Join(" | ", m.Paths)}]"));
}

public sealed record SodUserConflicts(int UserId, string UserName, string FullName, IReadOnlyList<SodConflict> Conflicts);

public sealed record SodScanResult(int ScannedUsers, int ViolatingUsers, int NewViolations, int StillOpen, int AutoResolved, double DurationMs,
    IReadOnlyList<SodUserConflicts> Details);

/// <summary>Saf SoD değerlendirici: etkin yetki seti + kurallar → çakışmalar (üyelerden 2+ tanesine sahip olmak ihlaldir).</summary>
public static class SodEvaluator
{
    public static IReadOnlyList<SodConflict> Evaluate(EffectivePermissionSet set, IEnumerable<SodRuleSnapshot> rules)
    {
        var result = new List<SodConflict>();
        foreach (var rule in rules)
        {
            var matched = new List<SodMatchedMember>();
            foreach (var m in rule.Members)
            {
                if (m.Type == SodMemberType.Permission)
                {
                    var p = set.Find(m.Id);
                    if (p is not null) matched.Add(new SodMatchedMember(m.Type, m.Id, m.Code, m.Name, p.Sources.Select(s => s.Path).ToList()));
                }
                else
                {
                    var r = set.Roles.FirstOrDefault(x => x.RoleId == m.Id);
                    if (r is not null) matched.Add(new SodMatchedMember(m.Type, m.Id, m.Code, m.Name, r.Sources.Select(s => s.Text).ToList()));
                }
            }
            if (matched.Count >= 2) result.Add(new SodConflict(rule.Id, rule.Code, rule.Name, rule.Severity, rule.Enforcement, matched));
        }
        return result;
    }
}

/// <summary>SoD: atama anında kontrol + geriye dönük tarama. Sistem yetkiyi otomatik silmez; ihlali görünür kılar.</summary>
public sealed class SodService(IYetkiDbContext db, AuthorizationModelProvider models, AuditWriter audit, IClock clock, ICurrentActor actor)
{
    public async Task<IReadOnlyList<SodRuleSnapshot>> LoadActiveRulesAsync(CancellationToken ct = default)
    {
        var rules = await db.SodRules.AsNoTracking().Where(r => r.IsActive)
            .Select(r => new { r.Id, r.Code, r.Name, r.Severity, r.Enforcement, Members = r.Members.Select(m => new { m.MemberType, m.MemberId }).ToList() })
            .ToListAsync(ct);
        var model = await models.GetCurrentAsync(ct);
        return rules.Select(r => Snapshot(model, r.Id, r.Code, r.Name, r.Severity, r.Enforcement, r.Members.Select(m => (m.MemberType, m.MemberId)))).ToList();
    }

    public static SodRuleSnapshot Snapshot(AuthorizationModel model, int id, string code, string name, Severity severity, SodEnforcement enforcement,
        IEnumerable<(SodMemberType Type, int Id)> members) =>
        new(id, code, name, severity, enforcement, members.Select(m => m.Type == SodMemberType.Permission
            ? new SodMemberSnapshot(m.Type, m.Id, model.Permissions.TryGetValue(m.Id, out var p) ? p.Code : $"#{m.Id}", p?.Row.Name ?? "?")
            : new SodMemberSnapshot(m.Type, m.Id, model.Roles.TryGetValue(m.Id, out var r) ? r.Code : $"#{m.Id}", r?.Name ?? "?")).ToList());

    /// <summary>İhlal kaydı açar veya açık kaydın LastSeenAt'ini günceller. SaveChanges çağırana aittir.</summary>
    public async Task<int> UpsertViolationsAsync(int userId, IEnumerable<SodConflict> conflicts, ViolationDetectionSource source, CancellationToken ct)
    {
        var now = clock.UtcNow;
        var created = 0;
        foreach (var c in conflicts)
        {
            var existing = await db.SodViolations.FirstOrDefaultAsync(v => v.UserId == userId && v.SodRuleId == c.SodRuleId && v.Status != ViolationStatus.Resolved, ct);
            if (existing is not null)
            {
                existing.LastSeenAt = now;
                existing.Details = c.Describe();
                continue;
            }
            db.SodViolations.Add(new SodViolation
            {
                SodRuleId = c.SodRuleId, UserId = userId, DetectedBy = source, DetectedAt = now, LastSeenAt = now, Details = c.Describe()
            });
            created++;
        }
        return created;
    }

    /// <summary>Geriye dönük tarama: tüm aktif kullanıcılar; artık geçerli olmayan açık ihlaller otomatik kapatılır.</summary>
    public async Task<SodScanResult> ScanAsync(CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        var rules = await LoadActiveRulesAsync(ct);
        var model = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        var details = new List<SodUserConflicts>();
        var created = 0;
        var seen = new HashSet<(int UserId, int RuleId)>();
        var users = model.Users.Values.Where(u => u.IsActive).ToList();

        foreach (var u in users)
        {
            var set = model.GetEffective(u.Id, now);
            var conflicts = SodEvaluator.Evaluate(set, rules);
            if (conflicts.Count == 0) continue;
            details.Add(new SodUserConflicts(u.Id, u.UserName, u.FullName, conflicts));
            created += await UpsertViolationsAsync(u.Id, conflicts, ViolationDetectionSource.RetrospectiveScan, ct);
            foreach (var c in conflicts) seen.Add((u.Id, c.SodRuleId));
        }

        var open = await db.SodViolations.Where(v => v.Status != ViolationStatus.Resolved).ToListAsync(ct);
        var autoResolved = 0;
        foreach (var v in open.Where(v => !seen.Contains((v.UserId, v.SodRuleId))))
        {
            v.Status = ViolationStatus.Resolved;
            v.ClosedAt = now;
            v.ClosedBy = "sod-scan";
            v.Note = "Tarama sırasında çakışma artık mevcut değil; otomatik kapatıldı.";
            autoResolved++;
        }

        sw.Stop();
        var result = new SodScanResult(users.Count, details.Count, created, seen.Count - created, autoResolved, Math.Round(sw.Elapsed.TotalMilliseconds, 1), details);
        audit.Add(new AuditLog
        {
            Category = AuditCategory.SodScan, Actor = actor.Name, Action = "SodScan",
            Summary = $"{result.ScannedUsers} kullanıcı tarandı, {result.ViolatingUsers} kullanıcıda ihlal, {created} yeni kayıt, {autoResolved} otomatik kapandı.",
            DetailsJson = JsonDefaults.Serialize(new { result.ScannedUsers, result.ViolatingUsers, result.NewViolations, result.StillOpen, result.AutoResolved, result.DurationMs })
        });
        await db.SaveChangesAsync(ct);
        return result;
    }

    /// <summary>What-If: verilen (kaydedilmemiş olabilir) kural şu an kaç kullanıcıda ihlal üretir?</summary>
    public async Task<IReadOnlyList<SodUserConflicts>> SimulateRuleAsync(SodRuleSnapshot draft, CancellationToken ct = default)
    {
        var model = await models.GetCurrentAsync(ct);
        var now = clock.UtcNow;
        return model.Users.Values.Where(u => u.IsActive)
            .Select(u => (u, c: SodEvaluator.Evaluate(model.GetEffective(u.Id, now), [draft])))
            .Where(x => x.c.Count > 0)
            .Select(x => new SodUserConflicts(x.u.Id, x.u.UserName, x.u.FullName, x.c))
            .ToList();
    }
}
