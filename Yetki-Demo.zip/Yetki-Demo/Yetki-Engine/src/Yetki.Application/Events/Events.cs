using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Yetki.Application.Abstractions;
using Yetki.Application.Common;
using Yetki.Domain.Common;
using Yetki.Domain.Governance;

namespace Yetki.Application.Events;

public static class EventTypes
{
    public const string UserChanged = "UserChanged";
    public const string RoleAssigned = "RoleAssigned";
    public const string RoleRevoked = "RoleRevoked";
    public const string PermissionAssigned = "PermissionAssigned";
    public const string PermissionRevoked = "PermissionRevoked";
    public const string OrgUnitAssignmentChanged = "OrgUnitAssignmentChanged";
    public const string GroupChanged = "GroupChanged";
    public const string GroupMembershipChanged = "GroupMembershipChanged";
    public const string GroupGrantChanged = "GroupGrantChanged";
    public const string GroupFiltersChanged = "GroupFiltersChanged";
    public const string RoleChanged = "RoleChanged";
    public const string PolicyChanged = "PolicyChanged";
    public const string CatalogChanged = "CatalogChanged";
    public const string ClientChanged = "ClientChanged";
    public const string SoDRuleChanged = "SoDRuleChanged";
    public const string ExternalMappingChanged = "ExternalMappingChanged";
    /// <summary>Dış bağımlılık (API/endpoint/permission → RACF/LDAP) veya zinciri değişti → etkilenen kullanıcılar için mutabakat.</summary>
    public const string ExternalRequirementsChanged = "ExternalRequirementsChanged";

    /// <summary>Türetilmiş event: bir değişiklik sonucu kullanıcının etkin yetki seti değişti. Provisioning bunu dinler.</summary>
    public const string EffectivePermissionsChanged = "EffectivePermissionsChanged";
}

public sealed record PermissionRef(int PermissionId, string Code);

public sealed record EffectivePermissionsChangedPayload(
    int UserId, string UserName, string CauseEventType, IReadOnlyList<PermissionRef> Added, IReadOnlyList<PermissionRef> Removed);

/// <summary>Outbox'a event yazar. SaveChanges çağırana aittir (değişiklikle aynı iş birimi).</summary>
public sealed class OutboxWriter(IYetkiDbContext db, IClock clock, ICurrentActor actor)
{
    public OutboxEvent Add(string eventType, string? aggregateType, object? aggregateId, object payload)
    {
        var e = new OutboxEvent
        {
            EventType = eventType, AggregateType = aggregateType, AggregateId = aggregateId?.ToString(),
            PayloadJson = JsonDefaults.Serialize(payload), OccurredAt = clock.UtcNow, Actor = actor.Name
        };
        db.OutboxEvents.Add(e);
        return e;
    }
}

/// <summary>Outbox tüketicisi. Yeni entegrasyon = yeni handler (yetki çekirdeği değişmez).</summary>
public interface IOutboxEventHandler
{
    bool CanHandle(string eventType);
    Task HandleAsync(OutboxEvent evt, CancellationToken ct);
}

/// <summary>Adaptöre giden istek: kime, hangi dış yetki (sınıfıyla), hangi seviye (öncekiyle), neden.</summary>
public sealed record ProvisioningRequest(
    int UserId, string UserName, string Reason, string ExternalSystemCode, string ExternalPermissionCode, ProvisioningActionType ActionType,
    string? ResourceClass = null, ExternalAccessLevel? AccessLevel = null, ExternalAccessLevel? PreviousAccessLevel = null);

public sealed record ProvisioningOutcome(bool Success, string Message);

/// <summary>Dış sistem adaptörü (RACF, LDAP, CICS...). SystemCode "*" = özel adaptörü olmayan sistemler için fallback.</summary>
public interface IProvisioningAdapter
{
    string SystemCode { get; }
    string Name { get; }
    Task<ProvisioningOutcome> ExecuteAsync(ProvisioningRequest request, CancellationToken ct);
}

/// <summary>Dış bağımlılık kataloğu değişti (ör. endpoint'e RACF transaction'ı eklendi). UserIds boş = tüm kullanıcılar.</summary>
public sealed record ExternalRequirementsChangedPayload(IReadOnlyList<int> UserIds, string Summary);

/// <summary>
/// EffectivePermissionsChanged / ExternalRequirementsChanged → kullanıcı(lar) için dış sistem MUTABAKATI
/// (olması gereken − dış sistemde açık olan → Grant / Modify / Revoke → adaptör). Yetki kararı bu akıştan bağımsızdır.
/// </summary>
public sealed class ProvisioningEventHandler(External.ExternalProvisioningService provisioning) : IOutboxEventHandler
{
    public bool CanHandle(string eventType) => eventType is EventTypes.EffectivePermissionsChanged or EventTypes.ExternalRequirementsChanged;

    public async Task HandleAsync(OutboxEvent evt, CancellationToken ct)
    {
        if (evt.EventType == EventTypes.EffectivePermissionsChanged)
        {
            var payload = JsonSerializer.Deserialize<EffectivePermissionsChangedPayload>(evt.PayloadJson, JsonDefaults.Options)
                          ?? throw new InvalidOperationException("Geçersiz payload");
            await provisioning.ReconcileUserAsync(payload.UserId, evt.Id, ct);
            return;
        }
        var ext = JsonSerializer.Deserialize<ExternalRequirementsChangedPayload>(evt.PayloadJson, JsonDefaults.Options)
                  ?? throw new InvalidOperationException("Geçersiz payload");
        if (ext.UserIds.Count == 0) await provisioning.ReconcileAllAsync(evt.Id, ct);
        else foreach (var id in ext.UserIds) await provisioning.ReconcileUserAsync(id, evt.Id, ct);
    }
}
