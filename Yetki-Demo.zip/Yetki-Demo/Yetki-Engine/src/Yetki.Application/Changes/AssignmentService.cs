using Yetki.Application.Identity;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Common;
using Yetki.Application.Events;
using Yetki.Application.Model;
using Yetki.Domain.Common;
using Yetki.Domain.Groups;
using Yetki.Domain.Identity;
using Yetki.Domain.Rbac;

namespace Yetki.Application.Changes;

public sealed class UserUpsert
{
    public int TenantId { get; set; }
    public string UserName { get; set; } = default!;
    public string FullName { get; set; } = default!;
    public string? Email { get; set; }
    public string? Title { get; set; }
    public string? EmployeeNo { get; set; }
    public UserKind Kind { get; set; } = UserKind.Person;
    public bool IsActive { get; set; } = true;
    public bool IsOnLeave { get; set; }
    public decimal CashWithdrawalLimit { get; set; }
    public string? CustomerNo { get; set; }
    public int? PrimaryOrgUnitId { get; set; }
}

public sealed class RoleUpsert
{
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsInheritable { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class GroupUpsert
{
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>
/// Yetkiyi etkileyen TÜM yönetim işlemleri. Her işlem bir AuthorizationChangeSet'e çevrilir ve
/// AuthorizationChangeService üzerinden (etki analizi + SoD + event + audit) uygulanır. What-If aynı change set'leri kullanır.
/// </summary>
public sealed class AssignmentService(
    IYetkiDbContext db,
    IIdentityProvider identities,
    AuthorizationChangeService changes,
    AuthorizationModelProvider models)
{
    // ================================ Kullanıcı ================================

    public async Task<IdentityUser> CreateUserAsync(UserUpsert dto, CancellationToken ct)
    {
        IdentityWrites.Require(identities.Capabilities.Users, "User creation");
        var name = Codes.Lower(dto.UserName);
        if (await identities.UserNameExistsAsync(name, ct)) throw new ConflictException($"Kullanıcı adı zaten var: {name}");
        if (!await db.Tenants.AnyAsync(o => o.Id == dto.TenantId, ct)) throw new NotFoundException("Kurum", dto.TenantId);
        if (dto.PrimaryOrgUnitId is { } unitId)
        {
            var unit = await db.OrgUnits.FindAsync([unitId], ct) ?? throw new NotFoundException("Birim", unitId);
            if (unit.TenantId != dto.TenantId) throw new ValidationException("Birim kullanıcının kurumunda olmalı.");

        }
        return await identities.CreateUserAsync(new IdentityUser(0, dto.TenantId, name, dto.FullName, dto.Email, dto.Title,
            dto.EmployeeNo, dto.Kind, dto.IsActive, dto.IsOnLeave, dto.CashWithdrawalLimit, dto.CustomerNo), dto.PrimaryOrgUnitId, ct);
    }

    /// <summary>Kullanıcı özelliklerini günceller. Unvan/izin/limit/aktiflik grup üyeliğini ve policy'leri etkileyebildiği için etki analizinden geçer.</summary>
    public async Task<ChangeImpactResult> UpdateUserAsync(int userId, UserUpsert dto, CancellationToken ct)
    {
        IdentityWrites.Require(identities.Capabilities.Users, "User updates");
        var user = await UserAsync(userId, ct);
        var cs = new AuthorizationChangeSet();
        cs.UserUpdates.Add(new UserUpdate(userId, dto.Title ?? "", dto.IsActive, dto.IsOnLeave, dto.CashWithdrawalLimit));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () => identities.StageUserUpdateAsync(user with
            {
                FullName = dto.FullName, Email = dto.Email, Title = dto.Title, EmployeeNo = dto.EmployeeNo,
                IsActive = dto.IsActive, IsOnLeave = dto.IsOnLeave, CashWithdrawalLimit = dto.CashWithdrawalLimit, CustomerNo = dto.CustomerNo
            }, ct),
            EventType = EventTypes.UserChanged, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, dto.Title, dto.IsActive, dto.IsOnLeave, dto.CashWithdrawalLimit },
            AuditSummary = $"'{user.UserName}' kullanıcı bilgileri güncellendi"
        }, ct);
    }

    public async Task<ChangeImpactResult> AssignRoleAsync(int userId, int roleId, DateTime? validUntil, string? reason, CancellationToken ct)
    {
        IdentityWrites.Require(identities.Capabilities.UserRoles, "User-Role assignments");
        var user = await UserAsync(userId, ct);
        var role = await identities.GetRoleAsync(roleId, ct) ?? throw new NotFoundException("Rol", roleId);
        if (await identities.GetUserRoleAsync(userId, roleId, ct) is not null)
            throw new ConflictException($"'{user.UserName}' zaten '{role.Code}' rolüne sahip.");
        await EnsureRoleUsableAsync(role, user.TenantId, ct);

        var cs = new AuthorizationChangeSet();
        cs.UserRoles.Add(new UserRoleChange(userId, roleId, true, validUntil));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () => identities.StageAssignRoleAsync(new IdentityUserRole(userId, roleId, null, validUntil, reason, default, "system"), ct),
            EventType = EventTypes.RoleAssigned, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, roleId, role.Code, validUntil, reason },
            AuditSummary = $"'{user.UserName}' kullanıcısına '{role.Code}' rolü atandı" + (validUntil is null ? "" : $" ({validUntil:yyyy-MM-dd}'e kadar)")
        }, ct);
    }

    public async Task<ChangeImpactResult> RevokeRoleAsync(int userId, int roleId, CancellationToken ct)
    {
        IdentityWrites.Require(identities.Capabilities.UserRoles, "User-Role revocation");
        var user = await UserAsync(userId, ct);
        var link = await identities.GetUserRoleAsync(userId, roleId, ct) ?? throw new NotFoundException("UserRole", $"{userId}/{roleId}");
        var role = await identities.GetRoleAsync(roleId, ct) ?? throw new NotFoundException("Role", roleId);
        var cs = new AuthorizationChangeSet();
        cs.UserRoles.Add(new UserRoleChange(userId, roleId, false));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () => identities.StageRevokeRoleAsync(userId, roleId, ct),
            EventType = EventTypes.RoleRevoked, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, roleId, role.Code },
            AuditSummary = $"'{user.UserName}' kullanıcısından '{role.Code}' rolü alındı"
        }, ct);
    }

    public async Task<ChangeImpactResult> GrantPermissionAsync(int userId, int permissionId, string? reason, DateTime? validUntil, CancellationToken ct)
    {
        var user = await UserAsync(userId, ct);
        var perm = await db.Permissions.FindAsync([permissionId], ct) ?? throw new NotFoundException("Permission", permissionId);
        if (string.IsNullOrWhiteSpace(reason)) throw new ValidationException("Doğrudan permission ataması istisnadır; gerekçe zorunlu.");
        await EnsurePermissionInTenantAsync(perm, user.TenantId, ct);
        if (await db.UserPermissions.AnyAsync(x => x.UserId == userId && x.PermissionId == permissionId, ct))
            throw new ConflictException($"'{user.UserName}' için bu doğrudan atama zaten var.");
        var cs = new AuthorizationChangeSet();
        cs.UserPermissions.Add(new UserPermissionChange(userId, permissionId, true, validUntil));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () =>
            {
                db.UserPermissions.Add(new UserPermission { UserId = userId, PermissionId = permissionId, Reason = reason, ValidUntil = validUntil });
                return Task.CompletedTask;
            },
            EventType = EventTypes.PermissionAssigned, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, permissionId, perm.Code, reason, validUntil },
            AuditSummary = $"'{user.UserName}' kullanıcısına doğrudan '{perm.Code}' verildi (gerekçe: {reason})"
        }, ct);
    }

    public async Task<ChangeImpactResult> RevokePermissionAsync(int userId, int permissionId, CancellationToken ct)
    {
        var user = await UserAsync(userId, ct);
        var link = await db.UserPermissions.Include(x => x.Permission).FirstOrDefaultAsync(x => x.UserId == userId && x.PermissionId == permissionId, ct)
                   ?? throw new NotFoundException("Doğrudan permission", $"{userId}/{permissionId}");
        var cs = new AuthorizationChangeSet();
        cs.UserPermissions.Add(new UserPermissionChange(userId, permissionId, false));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () => { db.UserPermissions.Remove(link); return Task.CompletedTask; },
            EventType = EventTypes.PermissionRevoked, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, permissionId, link.Permission.Code },
            AuditSummary = $"'{user.UserName}' kullanıcısından doğrudan '{link.Permission.Code}' alındı"
        }, ct);
    }

    public async Task<ChangeImpactResult> SetUserUnitAsync(int userId, int unitId, bool add, CancellationToken ct)
    {
        var user = await UserAsync(userId, ct);
        var unit = await db.OrgUnits.FindAsync([unitId], ct) ?? throw new NotFoundException("Birim", unitId);
        if (unit.TenantId != user.TenantId) throw new ValidationException("Birim kullanıcının kurumunda olmalı.");
        var link = await db.UserOrgUnits.FirstOrDefaultAsync(x => x.UserId == userId && x.OrgUnitId == unitId, ct);
        if (add && link is not null) throw new ConflictException("Kullanıcı zaten bu birimde.");
        if (!add && link is null) throw new NotFoundException("Kullanıcı birimi", $"{userId}/{unitId}");
        var hasAny = await db.UserOrgUnits.AnyAsync(x => x.UserId == userId, ct);

        var cs = new AuthorizationChangeSet();
        cs.UserUnits.Add(new UserUnitChange(userId, unitId, add));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () =>
            {
                if (add) db.UserOrgUnits.Add(new UserOrgUnit { UserId = userId, OrgUnitId = unitId, IsPrimary = !hasAny });
                else db.UserOrgUnits.Remove(link!);
                return Task.CompletedTask;
            },
            EventType = EventTypes.OrgUnitAssignmentChanged, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, unitId, unit.Code, add },
            AuditSummary = $"'{user.UserName}' {(add ? "birime eklendi" : "biriminden çıkarıldı")}: {unit.Code}"
        }, ct);
    }

    // ================================ Rol ================================

    public async Task<IdentityRole> CreateRoleAsync(RoleUpsert dto, CancellationToken ct)
    {
        IdentityWrites.Require(identities.Capabilities.Roles, "Role creation");
        var code = Codes.Normalize(dto.Code);
        if (await identities.RoleCodeExistsAsync(code, ct)) throw new ConflictException($"Rol kodu zaten var: {code}");
        if (!await db.Tenants.AnyAsync(o => o.Id == dto.TenantId, ct)) throw new NotFoundException("Kurum", dto.TenantId);
        return await identities.CreateRoleAsync(new IdentityRole(0, dto.TenantId, code, dto.Name, dto.Description, dto.IsInheritable, dto.IsActive), ct);
    }

    public async Task<ChangeImpactResult> UpdateRoleAsync(int roleId, RoleUpsert dto, CancellationToken ct)
    {
        IdentityWrites.Require(identities.Capabilities.Roles, "Role updates");
        var role = await identities.GetRoleAsync(roleId, ct) ?? throw new NotFoundException("Rol", roleId);
        var cs = new AuthorizationChangeSet();
        cs.RoleUpdates.Add(new RoleUpdate(roleId, dto.IsActive, dto.IsInheritable));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () => identities.StageRoleUpdateAsync(role with { Name = dto.Name, Description = dto.Description, IsInheritable = dto.IsInheritable, IsActive = dto.IsActive }, ct),
            EventType = EventTypes.RoleChanged, AggregateType = "Role", AggregateId = role.Code,
            EventPayload = new { role.Code, dto.IsActive, dto.IsInheritable },
            AuditSummary = $"'{role.Code}' rolü güncellendi (aktif={dto.IsActive}, miras={dto.IsInheritable})"
        }, ct);
    }

    /// <summary>Permission'ın uygulaması bu tenant'ta (kendi veya üst tenant'ın uygulaması) kullanılabilir olmalı.</summary>
    private async Task EnsurePermissionInTenantAsync(Domain.Catalog.Permission perm, int tenantId, CancellationToken ct)
    {
        if (!await TenantHierarchy.IsAvailableAsync(db, perm.TenantId, tenantId, ct))
            throw new ValidationException($"'{perm.Code}' permission'ı başka tenant'a ait; bu tenant'ta kullanılamaz.");
    }

    public async Task<ChangeImpactResult> SetRolePermissionAsync(int roleId, int permissionId, bool add, CancellationToken ct)
    {
        var role = await identities.GetRoleAsync(roleId, ct) ?? throw new NotFoundException("Rol", roleId);
        var perm = await db.Permissions.FindAsync([permissionId], ct) ?? throw new NotFoundException("Permission", permissionId);
        var link = await db.RolePermissions.FirstOrDefaultAsync(x => x.RoleId == roleId && x.PermissionId == permissionId, ct);
        if (add && link is not null) throw new ConflictException($"'{role.Code}' zaten '{perm.Code}' içeriyor.");
        if (add) await EnsurePermissionInTenantAsync(perm, role.TenantId, ct);
        if (!add && link is null) throw new NotFoundException("Rol permission", $"{roleId}/{permissionId}");

        var cs = new AuthorizationChangeSet();
        cs.RolePermissions.Add(new RolePermissionChange(roleId, permissionId, add));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () =>
            {
                if (add) db.RolePermissions.Add(new RolePermission { RoleId = roleId, PermissionId = permissionId });
                else db.RolePermissions.Remove(link!);
                return Task.CompletedTask;
            },
            EventType = add ? EventTypes.PermissionAssigned : EventTypes.PermissionRevoked, AggregateType = "Role", AggregateId = role.Code,
            EventPayload = new { roleId, role.Code, permissionId, permission = perm.Code, add },
            AuditSummary = $"'{role.Code}' rolüne '{perm.Code}' {(add ? "eklendi" : "çıkarıldı")}"
        }, ct);
    }

    // ================================ Grup ================================

    public async Task<Group> CreateGroupAsync(GroupUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Groups.AnyAsync(g => g.Code == code, ct)) throw new ConflictException($"Grup kodu zaten var: {code}");
        if (!await db.Tenants.AnyAsync(o => o.Id == dto.TenantId, ct)) throw new NotFoundException("Kurum", dto.TenantId);
        var g = new Group { TenantId = dto.TenantId, Code = code, Name = dto.Name, Description = dto.Description, IsActive = dto.IsActive };
        db.Groups.Add(g);
        await db.SaveChangesAsync(ct);
        return g;
    }

    public async Task<ChangeImpactResult> UpdateGroupAsync(int groupId, GroupUpsert dto, CancellationToken ct)
    {
        var g = await GroupAsync(groupId, ct);
        var cs = new AuthorizationChangeSet();
        cs.GroupActivations.Add(new ActivationChange(groupId, dto.IsActive));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () => { g.Name = dto.Name; g.Description = dto.Description; g.IsActive = dto.IsActive; return Task.CompletedTask; },
            EventType = EventTypes.GroupChanged, AggregateType = "Group", AggregateId = g.Code,
            EventPayload = new { g.Code, dto.IsActive },
            AuditSummary = $"'{g.Code}' grubu güncellendi (aktif={dto.IsActive})"
        }, ct);
    }

    /// <summary>Kitle kurallarını tamamen değiştirir. Kriterler koddaki handler'lara ve güncel modele göre doğrulanır.</summary>
    public async Task<ChangeImpactResult> ReplaceGroupFiltersAsync(int groupId, List<GroupFilterDraft> filters, CancellationToken ct)
    {
        var g = await GroupAsync(groupId, ct);
        await ValidateFiltersAsync(filters, ct);
        var cs = new AuthorizationChangeSet();
        cs.GroupFilters.Add(new GroupFiltersReplacement(groupId, filters));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = async () =>
            {
                var old = await db.GroupFilters.Include(f => f.Criteria).ThenInclude(c => c.Values).Where(f => f.GroupId == groupId).ToListAsync(ct);
                foreach (var f in old)
                {
                    foreach (var c in f.Criteria) { db.GroupFilterValues.RemoveRange(c.Values); db.GroupFilterCriteria.Remove(c); }
                    db.GroupFilters.Remove(f);
                }
                for (var i = 0; i < filters.Count; i++)
                    db.GroupFilters.Add(new GroupFilter
                    {
                        GroupId = groupId, Mode = filters[i].Mode, Order = i, Description = filters[i].Description,
                        Criteria = filters[i].Criteria.Select((c, j) => new GroupFilterCriterion
                        {
                            Attribute = c.Attribute.Trim().ToUpperInvariant(), Order = j,
                            Values = c.Values.Select(v => v.Trim()).Where(v => v.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).Select(v => new GroupFilterValue { Value = v }).ToList()
                        }).ToList()
                    });
            },
            EventType = EventTypes.GroupFiltersChanged, AggregateType = "Group", AggregateId = g.Code,
            EventPayload = new { g.Code, filters },
            AuditSummary = $"'{g.Code}' grubunun kitle kuralları değişti: {Describe(filters)}"
        }, ct);
    }

    public async Task ValidateFiltersAsync(List<GroupFilterDraft> filters, CancellationToken ct)
    {
        var model = await models.GetCurrentAsync(ct);
        var errors = new List<string>();
        for (var i = 0; i < filters.Count; i++)
        {
            if (filters[i].Criteria.Count == 0) errors.Add($"Kural #{i + 1}: en az bir kriter gerekli.");
            foreach (var c in filters[i].Criteria)
            {
                var h = model.Criteria.Find(c.Attribute ?? "");
                if (h is null) { errors.Add($"Kural #{i + 1}: bilinmeyen kriter '{c.Attribute}'."); continue; }
                errors.AddRange(h.Validate(model, c.Values.Where(v => !string.IsNullOrWhiteSpace(v)).ToList()).Select(e => $"Kural #{i + 1}: {e}"));
            }
        }
        if (errors.Count > 0) throw ValidationException.Of("filters", errors);
    }

    public static string Describe(IEnumerable<GroupFilterDraft> filters) =>
        string.Join(" ∪ ", filters.Select(f => (f.Mode == InclusionMode.Exclude ? "HARİÇ " : "") +
            "(" + string.Join(" ∧ ", f.Criteria.Select(c => $"{c.Attribute}∈{{{string.Join(",", c.Values)}}}")) + ")"));

    public async Task<ChangeImpactResult> SetGroupMemberAsync(int groupId, int userId, bool add, DateTime? validUntil, CancellationToken ct)
    {
        var g = await GroupAsync(groupId, ct);
        var user = await UserAsync(userId, ct);
        var link = await db.GroupMembers.FirstOrDefaultAsync(x => x.GroupId == groupId && x.UserId == userId, ct);
        if (add && link is not null) throw new ConflictException("Kullanıcı zaten açık üye.");
        if (!add && link is null) throw new NotFoundException("Grup üyesi", $"{groupId}/{userId}");
        var model = await models.GetCurrentAsync(ct);
        if (add && !model.TenantAncestors[user.TenantId].Contains(g.TenantId))
            throw new ValidationException($"'{user.UserName}' grubun kurumunda ({model.TenantCode(g.TenantId)}) veya alt kurumunda değil.");

        var cs = new AuthorizationChangeSet();
        cs.GroupMembers.Add(new GroupMemberChange(groupId, userId, add, validUntil));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () =>
            {
                if (add) db.GroupMembers.Add(new GroupMember { GroupId = groupId, UserId = userId, ValidUntil = validUntil });
                else db.GroupMembers.Remove(link!);
                return Task.CompletedTask;
            },
            EventType = EventTypes.GroupMembershipChanged, AggregateType = "Group", AggregateId = g.Code,
            EventPayload = new { g.Code, userId, user.UserName, add, validUntil },
            AuditSummary = $"'{g.Code}' grubuna açık üye {(add ? "eklendi" : "çıkarıldı")}: {user.UserName}"
        }, ct);
    }

    public async Task<ChangeImpactResult> SetGroupGrantAsync(int groupId, GroupGrantKind kind, int targetId, bool add, CancellationToken ct)
    {
        var g = await GroupAsync(groupId, ct);
        string code;
        bool exists;
        if (kind == GroupGrantKind.Role)
        {
            var role = await identities.GetRoleAsync(targetId, ct) ?? throw new NotFoundException("Rol", targetId);
            if (add) await EnsureRoleUsableAsync(role, g.TenantId, ct);
            code = role.Code;
            exists = await db.GroupRoles.AnyAsync(x => x.GroupId == groupId && x.RoleId == targetId, ct);
        }
        else
        {
            var perm = await db.Permissions.FindAsync([targetId], ct) ?? throw new NotFoundException("Permission", targetId);
            if (add) await EnsurePermissionInTenantAsync(perm, g.TenantId, ct);
            code = perm.Code;
            exists = await db.GroupPermissions.AnyAsync(x => x.GroupId == groupId && x.PermissionId == targetId, ct);
        }
        if (add && exists) throw new ConflictException($"'{g.Code}' zaten '{code}' veriyor.");
        if (!add && !exists) throw new NotFoundException("Grup yetkisi", $"{g.Code}/{code}");

        var cs = new AuthorizationChangeSet();
        cs.GroupGrants.Add(new GroupGrantChange(groupId, kind, targetId, add));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = async () =>
            {
                if (kind == GroupGrantKind.Role)
                {
                    if (add) db.GroupRoles.Add(new GroupRole { GroupId = groupId, RoleId = targetId });
                    else db.GroupRoles.Remove(await db.GroupRoles.FirstAsync(x => x.GroupId == groupId && x.RoleId == targetId, ct));
                }
                else
                {
                    if (add) db.GroupPermissions.Add(new GroupPermission { GroupId = groupId, PermissionId = targetId });
                    else db.GroupPermissions.Remove(await db.GroupPermissions.FirstAsync(x => x.GroupId == groupId && x.PermissionId == targetId, ct));
                }
            },
            EventType = EventTypes.GroupGrantChanged, AggregateType = "Group", AggregateId = g.Code,
            EventPayload = new { g.Code, kind, targetId, code, add },
            AuditSummary = $"'{g.Code}' grubu {(kind == GroupGrantKind.Role ? "rol" : "permission")} {(add ? "veriyor" : "artık vermiyor")}: {code}"
        }, ct);
    }

    // ================================ Yardımcılar ================================

    /// <summary>Rol, hedef kurumda kullanılabilir mi? (aynı kurum veya üst kurumun miras alınabilir rolü)</summary>
    private async Task EnsureRoleUsableAsync(IdentityRole role, int tenantId, CancellationToken ct)
    {
        var model = await models.GetCurrentAsync(ct);
        var ok = role.TenantId == tenantId || (role.IsInheritable && model.TenantAncestors[tenantId].Contains(role.TenantId));
        if (!ok)
            throw new ValidationException($"'{role.Code}' rolü {model.TenantCode(role.TenantId)} kurumuna ait ve miras alınamaz; " +
                                          $"{model.TenantCode(tenantId)} kurumunda kullanılamaz.");
    }

    private async Task<IdentityUser> UserAsync(int id, CancellationToken ct) => await identities.GetUserAsync(id, ct) ?? throw new NotFoundException("Kullanıcı", id);
    private async Task<Group> GroupAsync(int id, CancellationToken ct) => await db.Groups.FindAsync([id], ct) ?? throw new NotFoundException("Grup", id);
}
