using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Events;
using Yetki.Application.Governance;
using Yetki.Application.Model;
using Yetki.Domain.Common;

namespace Yetki.Application.Changes;

public sealed record PermissionDelta(int PermissionId, string Code, string Name, string Path, IReadOnlyList<string> Sources);

/// <summary>Kullanıcı yetkiyi KORUR ama kaynağı değişir (rolden çıkan yetki başka rol/gruptan hâlâ geliyor).</summary>
public sealed record PermissionSourceChange(int PermissionId, string Code, string Name, IReadOnlyList<string> Before, IReadOnlyList<string> After);


public sealed record UserImpact(
    int UserId, string UserName, string FullName, string Tenant,
    IReadOnlyList<PermissionDelta> AddedPermissions,
    IReadOnlyList<PermissionDelta> RemovedPermissions,
    IReadOnlyList<PermissionSourceChange> RetainedPermissions,
    IReadOnlyList<string> AddedRoles, IReadOnlyList<string> RemovedRoles,
    IReadOnlyList<string> AddedGroups, IReadOnlyList<string> RemovedGroups,
    IReadOnlyList<SodConflict> NewSodConflicts,
    /// <summary>Dış sistemde (RACF/LDAP) açılacak veya seviyesi değişecek yetkiler (PreviousLevel doluysa seviye değişimi).</summary>
    IReadOnlyList<External.ExternalChange> ExternalGrants,
    /// <summary>Dış sistemde kapanacak yetkiler (kalan hiçbir etkin yetki onları gerektirmiyor).</summary>
    IReadOnlyList<External.ExternalChange> ExternalRevokes)
{
    public bool PermissionsChanged => AddedPermissions.Count + RemovedPermissions.Count > 0;
    public bool HasChanges => PermissionsChanged || RetainedPermissions.Count + AddedRoles.Count + RemovedRoles.Count + AddedGroups.Count + RemovedGroups.Count > 0;
}

public sealed record SodFinding(int UserId, string UserName, SodConflict Conflict);

/// <summary>Bir değişikliğin etki analizi. What-If'te sadece döner, gerçek atamada uygulanır ve döner.</summary>
public sealed class ChangeImpactResult
{
    public bool DryRun { get; init; }
    public bool Applied { get; set; }
    public bool Blocked { get; set; }
    public string Summary { get; set; } = "";
    public int AffectedUserCount { get; init; }
    public int EvaluatedUserCount { get; init; }
    public IReadOnlyList<UserImpact> Users { get; init; } = [];
    public IReadOnlyList<SodFinding> BlockingConflicts { get; init; } = [];
    public IReadOnlyList<SodFinding> Warnings { get; init; } = [];
}

/// <summary>Gerçek uygulama komutu: change set + entity değişikliklerini yapan callback + event/audit bilgisi.</summary>
public sealed class ChangeCommand
{
    public required AuthorizationChangeSet Changes { get; init; }
    public required Func<Task> ApplyEntities { get; init; }
    public required string EventType { get; init; }
    public required string AggregateType { get; init; }
    public required object AggregateId { get; init; }
    public required object EventPayload { get; init; }
    public required string AuditSummary { get; init; }
}

/// <summary>
/// RBAC değişikliklerinin tek kapısı:
///   1. Güncel model ve change set uygulanmış What-If modeli kurulur (AYNI Build)
///   2. Her kullanıcı için önce/sonra etkin yetki karşılaştırılır (kazanır / kaybeder / başka kaynaktan korur)
///   3. Yeni SoD çakışmaları (Block → reddet, Warn → uygula + ihlal kaydı), RACF/LDAP gereksinimleri
///   4. Entity değişiklikleri + audit + outbox (tek SaveChanges = tek transaction)
/// What-If ekranı 1-3'ü aynen kullanır: simülasyon ile gerçek sonuç arasında fark olamaz.
/// </summary>
public sealed class AuthorizationChangeService(
    IYetkiDbContext db,
    AuthorizationModelProvider models,
    SodService sod,
    OutboxWriter outbox,
    AuditWriter audit,
    IClock clock)
{
    public async Task<ChangeImpactResult> AnalyzeAsync(AuthorizationChangeSet changes, bool dryRun = true, CancellationToken ct = default)
    {
        var before = await models.GetCurrentAsync(ct);
        var after = await models.BuildWhatIfAsync(changes, null, ct);
        var now = clock.UtcNow;
        var rules = await sod.LoadActiveRulesAsync(ct);

        // TODO(perf): 20K+ kullanıcıda aday kullanıcıları değişikliğe göre daralt (rolü taşıyanlar, grup kitlesi) ve asenkron job'a taşı.
        var raw = new List<(EffectivePermissionSet Before, EffectivePermissionSet After)>();
        foreach (var u in after.Users.Values)
        {
            if (!before.Users.ContainsKey(u.Id)) continue;
            var b = before.GetEffective(u.Id, now);
            var a = after.GetEffective(u.Id, now);
            if (!Same(b, a)) raw.Add((b, a));
        }

        // Dış sistem (RACF/LDAP): önce/sonra OLMASI GEREKEN durum farkı (kalan yetkilerden hâlâ gerekenler geri alınmaz)
        var externalCatalog = await External.ExternalRequirementCatalog.LoadAsync(db, ct);

        var impacts = new List<UserImpact>();
        foreach (var (b, a) in raw)
        {
            var bp = b.Permissions.ToDictionary(p => p.PermissionId);
            var ap = a.Permissions.ToDictionary(p => p.PermissionId);
            PermissionDelta Delta(EffectivePermission p) => new(p.PermissionId, p.Code, p.Name, p.Path, p.Sources.Select(s => s.Path).ToList());
            var added = ap.Values.Where(p => !bp.ContainsKey(p.PermissionId)).Select(Delta).ToList();
            var removed = bp.Values.Where(p => !ap.ContainsKey(p.PermissionId)).Select(Delta).ToList();
            var retained = ap.Values
                .Where(p => bp.TryGetValue(p.PermissionId, out var x) && !x.Sources.Select(s => s.Path).ToHashSet().SetEquals(p.Sources.Select(s => s.Path)))
                .Select(p => new PermissionSourceChange(p.PermissionId, p.Code, p.Name, bp[p.PermissionId].Sources.Select(s => s.Path).ToList(), p.Sources.Select(s => s.Path).ToList()))
                .ToList();

            var beforeRules = SodEvaluator.Evaluate(b, rules).Select(c => c.SodRuleId).ToHashSet();
            var newConflicts = SodEvaluator.Evaluate(a, rules).Where(c => !beforeRules.Contains(c.SodRuleId)).ToList();

            var extBefore = externalCatalog.ForUser(before, b);
            var extDiff = External.ExternalDiff.Compute(externalCatalog.ForUser(after, a),
                External.ExternalDiff.ToState(extBefore), externalCatalog.Target, previous: extBefore);

            impacts.Add(new UserImpact(a.UserId, a.UserName, a.FullName, a.Tenant, added, removed, retained,
                a.Roles.Select(r => r.Code).Except(b.Roles.Select(r => r.Code)).ToList(),
                b.Roles.Select(r => r.Code).Except(a.Roles.Select(r => r.Code)).ToList(),
                a.Groups.Select(g => g.Code).Except(b.Groups.Select(g => g.Code)).ToList(),
                b.Groups.Select(g => g.Code).Except(a.Groups.Select(g => g.Code)).ToList(),
                newConflicts,
                extDiff.Where(x => x.Action is "Grant" or "Modify").Select(External.ExternalDefinitionService.ToChange).ToList(),
                extDiff.Where(x => x.Action == "Revoke").Select(External.ExternalDefinitionService.ToChange).ToList()));
        }

        var changed = impacts.Where(i => i.HasChanges).OrderBy(i => i.UserName, StringComparer.Ordinal).ToList();
        var blocking = changed.SelectMany(u => u.NewSodConflicts.Where(c => c.Enforcement == SodEnforcement.Block).Select(c => new SodFinding(u.UserId, u.UserName, c))).ToList();
        var warnings = changed.SelectMany(u => u.NewSodConflicts.Where(c => c.Enforcement == SodEnforcement.Warn).Select(c => new SodFinding(u.UserId, u.UserName, c))).ToList();

        return new ChangeImpactResult
        {
            DryRun = dryRun,
            AffectedUserCount = changed.Count(u => u.PermissionsChanged),
            EvaluatedUserCount = after.Users.Count,
            Users = changed,
            BlockingConflicts = blocking,
            Warnings = warnings,
            Blocked = blocking.Count > 0,
            Summary = BuildSummary(changed, blocking, warnings)
        };
    }

    public async Task<ChangeImpactResult> ApplyAsync(ChangeCommand command, CancellationToken ct = default)
    {
        var impact = await AnalyzeAsync(command.Changes, dryRun: false, ct);
        if (impact.Blocked)
            throw new ConflictException("SoD kuralı nedeniyle değişiklik engellendi. " + impact.Summary, impact);

        await command.ApplyEntities();

        foreach (var group in impact.Warnings.GroupBy(w => w.UserId))
            await sod.UpsertViolationsAsync(group.Key, group.Select(g => g.Conflict), ViolationDetectionSource.AssignmentCheck, ct);

        outbox.Add(command.EventType, command.AggregateType, command.AggregateId, command.EventPayload);
        foreach (var u in impact.Users.Where(u => u.PermissionsChanged))
            outbox.Add(EventTypes.EffectivePermissionsChanged, "User", u.UserId, new EffectivePermissionsChangedPayload(
                u.UserId, u.UserName, command.EventType,
                u.AddedPermissions.Select(p => new PermissionRef(p.PermissionId, p.Code)).ToList(),
                u.RemovedPermissions.Select(p => new PermissionRef(p.PermissionId, p.Code)).ToList()));

        audit.Management(command.EventType, command.AggregateType, command.AggregateId, $"{command.AuditSummary} — {impact.Summary}",
            new { command.EventPayload, impact.AffectedUserCount, Warnings = impact.Warnings.Select(w => new { w.UserName, w.Conflict.Code }) });

        await db.SaveChangesAsync(ct);
        impact.Applied = true;
        return impact;
    }

    private static bool Same(EffectivePermissionSet a, EffectivePermissionSet b) =>
        a.Permissions.Count == b.Permissions.Count && a.Roles.Count == b.Roles.Count && a.Groups.Count == b.Groups.Count
        && a.Groups.Select(g => g.GroupId).SequenceEqual(b.Groups.Select(g => g.GroupId))
        && a.Roles.Select(r => r.RoleId).SequenceEqual(b.Roles.Select(r => r.RoleId))
        && a.Permissions.Zip(b.Permissions).All(x => x.First.PermissionId == x.Second.PermissionId
            && x.First.Sources.Select(s => s.Path).SequenceEqual(x.Second.Sources.Select(s => s.Path)));

    private static string BuildSummary(List<UserImpact> users, List<SodFinding> blocking, List<SodFinding> warnings)
    {
        var added = users.Sum(u => u.AddedPermissions.Count);
        var removed = users.Sum(u => u.RemovedPermissions.Count);
        var s = $"{users.Count(u => u.PermissionsChanged)} kullanıcının yetkisi değişir " +
                $"({users.Count(u => u.AddedPermissions.Count > 0)} kullanıcı +{added} yetki kazanır, {users.Count(u => u.RemovedPermissions.Count > 0)} kullanıcı -{removed} yetki kaybeder).";
        var retained = users.Sum(u => u.RetainedPermissions.Count);
        if (retained > 0) s += $" {retained} yetkinin kaynağı değişir (başka rol/gruptan korunur).";
        var groupMoves = users.Sum(u => u.AddedGroups.Count + u.RemovedGroups.Count);
        if (groupMoves > 0) s += $" {groupMoves} grup üyeliği değişir.";
        if (blocking.Count > 0) s += $" {blocking.Count} ENGELLEYİCİ SoD çakışması.";
        if (warnings.Count > 0) s += $" {warnings.Count} SoD uyarısı.";
        return s;
    }
}

internal static class SetExtensions
{
    public static HashSet<T> SymmetricExceptWithReturn<T>(this HashSet<T> set, IEnumerable<T> other)
    {
        set.SymmetricExceptWith(other);
        return set;
    }
}
