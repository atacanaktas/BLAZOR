using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Yetki.Application.Abstractions;
using Yetki.Domain.Catalog;
using Yetki.Domain.Clients;
using Yetki.Domain.Common;
using Yetki.Domain.Governance;
using Yetki.Domain.Groups;
using Yetki.Domain.Identity;
using Yetki.Domain.Tenants;
using Yetki.Domain.Policies;
using Yetki.Domain.Rbac;

namespace Yetki.Infrastructure.Persistence;

/// <summary>
/// Tek DbContext. Model konfigürasyonu SQL Server hedeflenerek yazılmıştır (anahtarlar, unique/composite index'ler, uzunluklar,
/// decimal precision, delete davranışları, check constraint'ler). InMemory provider bunların çoğunu yok sayar;
/// SQL Server'a geçişte migration doğrudan bu modelden üretilir.
/// </summary>
public class YetkiDbContext(DbContextOptions<YetkiDbContext> options, IClock clock, ICurrentActor actor, IAuthorizationVersion version)
    : DbContext(options), IYetkiDbContext
{
    public DbSet<Tenant> Tenants => Set<Tenant>();
    public DbSet<OrgUnit> OrgUnits => Set<OrgUnit>();
    public DbSet<User> Users => Set<User>();
    public DbSet<UserOrgUnit> UserOrgUnits => Set<UserOrgUnit>();
    public DbSet<CatalogApplication> Applications => Set<CatalogApplication>();
    public DbSet<OwnershipTeam> OwnershipTeams => Set<OwnershipTeam>();
    public DbSet<CatalogNode> CatalogNodes => Set<CatalogNode>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<ApiResource> ApiResources => Set<ApiResource>();
    public DbSet<ApiEndpoint> ApiEndpoints => Set<ApiEndpoint>();
    public DbSet<UiElement> UiElements => Set<UiElement>();
    public DbSet<Client> Clients => Set<Client>();
    public DbSet<ClientPermissionGrant> ClientPermissionGrants => Set<ClientPermissionGrant>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<UserPermission> UserPermissions => Set<UserPermission>();
    public DbSet<Group> Groups => Set<Group>();
    public DbSet<GroupMember> GroupMembers => Set<GroupMember>();
    public DbSet<GroupFilter> GroupFilters => Set<GroupFilter>();
    public DbSet<GroupFilterCriterion> GroupFilterCriteria => Set<GroupFilterCriterion>();
    public DbSet<GroupFilterValue> GroupFilterValues => Set<GroupFilterValue>();
    public DbSet<GroupRole> GroupRoles => Set<GroupRole>();
    public DbSet<GroupPermission> GroupPermissions => Set<GroupPermission>();
    public DbSet<Policy> Policies => Set<Policy>();
    public DbSet<PolicyTarget> PolicyTargets => Set<PolicyTarget>();
    public DbSet<PolicyClientTarget> PolicyClientTargets => Set<PolicyClientTarget>();
    public DbSet<PolicyObligation> PolicyObligations => Set<PolicyObligation>();
    public DbSet<PolicyObligationParameter> PolicyObligationParameters => Set<PolicyObligationParameter>();
    public DbSet<Rule> Rules => Set<Rule>();
    public DbSet<RuleCondition> RuleConditions => Set<RuleCondition>();
    public DbSet<ConditionParameter> ConditionParameters => Set<ConditionParameter>();
    public DbSet<SharedCondition> SharedConditions => Set<SharedCondition>();
    public DbSet<ConditionType> ConditionTypes => Set<ConditionType>();
    public DbSet<SodRule> SodRules => Set<SodRule>();
    public DbSet<SodRuleMember> SodRuleMembers => Set<SodRuleMember>();
    public DbSet<SodViolation> SodViolations => Set<SodViolation>();
    public DbSet<ExternalSystem> ExternalSystems => Set<ExternalSystem>();
    public DbSet<ExternalPermission> ExternalPermissions => Set<ExternalPermission>();
    public DbSet<ExternalPermissionRequirement> ExternalPermissionRequirements => Set<ExternalPermissionRequirement>();
    public DbSet<ExternalDependency> ExternalDependencies => Set<ExternalDependency>();
    public DbSet<UserExternalGrant> UserExternalGrants => Set<UserExternalGrant>();
    public DbSet<OutboxEvent> OutboxEvents => Set<OutboxEvent>();
    public DbSet<ProvisioningAction> ProvisioningActions => Set<ProvisioningAction>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    /// <summary>Bu tiplerdeki değişiklikler yetki modelini etkilemez; versiyon artırmaz (model önbelleği korunur).</summary>
    private static readonly HashSet<Type> NonModelTypes =
    [
        typeof(AuditLog), typeof(OutboxEvent), typeof(ProvisioningAction), typeof(SodViolation), typeof(SodRule), typeof(SodRuleMember),
        typeof(ExternalSystem), typeof(ExternalPermission), typeof(ExternalPermissionRequirement), typeof(ExternalDependency),
        typeof(UserExternalGrant), typeof(ConditionType), typeof(OwnershipTeam)
    ];

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        ApplyAuditFields();
        var bump = ChangeTracker.Entries().Any(e =>
            e.State is EntityState.Added or EntityState.Modified or EntityState.Deleted && !NonModelTypes.Contains(e.Entity.GetType()));
        var result = await base.SaveChangesAsync(cancellationToken);
        if (bump) version.Bump();
        return result;
    }

    private void ApplyAuditFields()
    {
        var now = clock.UtcNow;
        foreach (var e in ChangeTracker.Entries())
        {
            if (e.Entity is AuditableEntity a)
            {
                if (e.State == EntityState.Added)
                {
                    if (a.CreatedAt == default) a.CreatedAt = now;
                    if (string.IsNullOrEmpty(a.CreatedBy) || a.CreatedBy == "system") a.CreatedBy = actor.Name;
                }
                else if (e.State == EntityState.Modified)
                {
                    a.UpdatedAt = now;
                    a.UpdatedBy = actor.Name;
                }
            }
            if (e.Entity is IAssignment asg && e.State == EntityState.Added)
            {
                if (asg.AssignedAt == default) asg.AssignedAt = now;
                if (string.IsNullOrEmpty(asg.AssignedBy) || asg.AssignedBy == "system") asg.AssignedBy = actor.Name;
            }
        }
    }

    protected override void OnModelCreating(ModelBuilder b)
    {
        // ---------------- Kurum / kimlik ----------------
        b.Entity<Tenant>(e =>
        {
            e.ToTable("Tenants");
            Code(e.Property(x => x.Code), 32); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasOne(x => x.Parent).WithMany().HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<OrgUnit>(e =>
        {
            e.ToTable("OrgUnits");
            Code(e.Property(x => x.Code), 32);
            e.HasIndex(x => new { x.TenantId, x.Code }).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Parent).WithMany().HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<User>(e =>
        {
            e.ToTable("Users");
            e.Property(x => x.UserName).HasMaxLength(64).IsRequired(); e.HasIndex(x => x.UserName).IsUnique();
            e.Property(x => x.FullName).HasMaxLength(128).IsRequired();
            e.Property(x => x.Email).HasMaxLength(128);
            e.Property(x => x.Title).HasMaxLength(128);
            e.Property(x => x.EmployeeNo).HasMaxLength(32);
            e.Property(x => x.CustomerNo).HasMaxLength(32);
            e.Property(x => x.CashWithdrawalLimit).HasPrecision(18, 2);
            e.HasIndex(x => x.TenantId);
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<UserOrgUnit>(e =>
        {
            e.ToTable("UserOrgUnits");
            e.HasKey(x => new { x.UserId, x.OrgUnitId });
            e.HasIndex(x => x.OrgUnitId);
            e.HasOne(x => x.User).WithMany(u => u.OrgUnits).HasForeignKey(x => x.UserId);
            e.HasOne(x => x.OrgUnit).WithMany().HasForeignKey(x => x.OrgUnitId);
            Assign(e);
        });

        // ---------------- Katalog ----------------
        b.Entity<OwnershipTeam>(e =>
        {
            e.ToTable("OwnershipTeams");
            Code(e.Property(x => x.Code), 32);
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.Property(x => x.Description).HasMaxLength(512);
            e.HasIndex(x => new { x.TenantId, x.Code }).IsUnique();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Parent).WithMany().HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<CatalogApplication>(e =>
        {
            e.ToTable("Applications");
            Code(e.Property(x => x.Code), 32); e.HasIndex(x => x.Code).IsUnique();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.Property(x => x.OwnerTeam).HasMaxLength(64);
            e.HasOne(x => x.OwnershipTeam).WithMany().HasForeignKey(x => x.OwnerTeamId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<CatalogNode>(e =>
        {
            e.ToTable("CatalogNodes");
            Code(e.Property(x => x.Code), 32);
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.Property(x => x.Path).HasMaxLength(256).IsRequired();
            e.Property(x => x.OwnerTeam).HasMaxLength(64);
            e.HasOne(x => x.OwnershipTeam).WithMany().HasForeignKey(x => x.OwnerTeamId).OnDelete(DeleteBehavior.Restrict);
            e.HasIndex(x => x.Path).IsUnique(); // ön ek (prefix) sorguları: WHERE Path LIKE 'ANKA/NAKIT/%'
            e.HasIndex(x => new { x.TenantId, x.ApplicationId, x.ParentId, x.Code }).IsUnique();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Application).WithMany().HasForeignKey(x => x.ApplicationId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Parent).WithMany().HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<Permission>(e =>
        {
            e.ToTable("Permissions");
            e.Property(x => x.Code).HasMaxLength(160).IsRequired(); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(160).IsRequired();
            e.Property(x => x.Action).HasMaxLength(32).IsRequired();
            e.HasIndex(x => new { x.CatalogNodeId, x.Action }).IsUnique().HasFilter("\"SourceEndpointId\" IS NULL AND \"CatalogNodeId\" IS NOT NULL");
            e.HasIndex(x => new { x.SourceEndpointId, x.Action }).IsUnique().HasFilter("\"SourceEndpointId\" IS NOT NULL");
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Application).WithMany().HasForeignKey(x => x.ApplicationId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.CatalogNode).WithMany().HasForeignKey(x => x.CatalogNodeId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.SourceEndpoint).WithMany().HasForeignKey(x => x.SourceEndpointId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<ApiResource>(e =>
        {
            e.ToTable("ApiResources");
            e.Property(x => x.Code).HasMaxLength(96).IsRequired(); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Audience).HasMaxLength(160).IsRequired(); e.HasIndex(x => x.Audience).IsUnique();
            e.Property(x => x.Name).HasMaxLength(160).IsRequired();
            e.Property(x => x.Version).HasMaxLength(16);
            e.Property(x => x.BasePath).HasMaxLength(128);
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Application).WithMany().HasForeignKey(x => x.ApplicationId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.CatalogNode).WithMany().HasForeignKey(x => x.CatalogNodeId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<ApiEndpoint>(e =>
        {
            e.ToTable("ApiEndpoints");
            e.Property(x => x.Method).HasMaxLength(8).IsRequired();
            e.Property(x => x.Path).HasMaxLength(256).IsRequired();
            e.Property(x => x.OperationId).HasMaxLength(128);
            e.Property(x => x.Summary).HasMaxLength(256);
            e.HasIndex(x => new { x.ApiResourceId, x.Method, x.Path }).IsUnique();
            e.HasIndex(x => x.PermissionId);
            e.HasOne(x => x.ApiResource).WithMany(a => a.Endpoints).HasForeignKey(x => x.ApiResourceId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Permission).WithMany().HasForeignKey(x => x.PermissionId).OnDelete(DeleteBehavior.Restrict);
        });
        b.Entity<UiElement>(e =>
        {
            e.ToTable("UiElements");
            Code(e.Property(x => x.Code), 64);
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasIndex(x => new { x.CatalogNodeId, x.Code }).IsUnique();
            e.HasOne(x => x.CatalogNode).WithMany().HasForeignKey(x => x.CatalogNodeId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Parent).WithMany().HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Permission).WithMany().HasForeignKey(x => x.PermissionId).OnDelete(DeleteBehavior.Restrict);
        });

        // ---------------- Client ----------------
        b.Entity<Client>(e =>
        {
            e.ToTable("Clients");
            e.Property(x => x.ClientId).HasMaxLength(64).IsRequired(); e.HasIndex(x => x.ClientId).IsUnique();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasOne(x => x.Application).WithMany().HasForeignKey(x => x.ApplicationId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ServiceAccountUser).WithMany().HasForeignKey(x => x.ServiceAccountUserId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<ClientPermissionGrant>(e =>
        {
            // Physical table name is retained so existing installations migrate without copying data.
            e.ToTable("ClientGrants", t => t.HasCheckConstraint("CK_ClientGrants_Target", TargetCheck));
            e.Property(x => x.Actions).HasMaxLength(128);
            e.HasOne(x => x.Client).WithMany(c => c.AllowedPermissions).HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Application).WithMany().HasForeignKey(x => x.ApplicationId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.CatalogNode).WithMany().HasForeignKey(x => x.CatalogNodeId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Permission).WithMany().HasForeignKey(x => x.PermissionId).OnDelete(DeleteBehavior.Restrict);
        });

        // ---------------- RBAC ----------------
        b.Entity<Role>(e =>
        {
            e.ToTable("Roles");
            Code(e.Property(x => x.Code), 48); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<RolePermission>(e =>
        {
            e.ToTable("RolePermissions");
            e.HasKey(x => new { x.RoleId, x.PermissionId });
            e.HasIndex(x => x.PermissionId); // "bu permission hangi rollerde?"
            e.HasOne(x => x.Role).WithMany(r => r.Permissions).HasForeignKey(x => x.RoleId);
            e.HasOne(x => x.Permission).WithMany().HasForeignKey(x => x.PermissionId);
            Assign(e);
        });
        b.Entity<UserRole>(e =>
        {
            e.ToTable("UserRoles");
            e.HasKey(x => new { x.UserId, x.RoleId });
            e.HasIndex(x => x.RoleId);
            e.Property(x => x.Reason).HasMaxLength(256);
            e.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId);
            e.HasOne(x => x.Role).WithMany().HasForeignKey(x => x.RoleId);
            Assign(e);
        });
        b.Entity<UserPermission>(e =>
        {
            e.ToTable("UserPermissions");
            e.HasKey(x => new { x.UserId, x.PermissionId });
            e.Property(x => x.Reason).HasMaxLength(256);
            e.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId);
            e.HasOne(x => x.Permission).WithMany().HasForeignKey(x => x.PermissionId);
            Assign(e);
        });

        // ---------------- Grup ----------------
        b.Entity<Group>(e =>
        {
            e.ToTable("Groups");
            Code(e.Property(x => x.Code), 48); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<GroupMember>(e =>
        {
            e.ToTable("GroupMembers");
            e.HasKey(x => new { x.GroupId, x.UserId });
            e.HasIndex(x => x.UserId);
            e.HasOne(x => x.Group).WithMany(g => g.Members).HasForeignKey(x => x.GroupId);
            e.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId);
            Assign(e);
        });
        b.Entity<GroupFilter>(e =>
        {
            e.ToTable("GroupFilters");
            e.Property(x => x.Description).HasMaxLength(256);
            e.HasOne(x => x.Group).WithMany(g => g.Filters).HasForeignKey(x => x.GroupId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<GroupFilterCriterion>(e =>
        {
            e.ToTable("GroupFilterCriteria");
            e.Property(x => x.Attribute).HasMaxLength(32).IsRequired();
            e.HasOne(x => x.GroupFilter).WithMany(f => f.Criteria).HasForeignKey(x => x.GroupFilterId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<GroupFilterValue>(e =>
        {
            e.ToTable("GroupFilterValues");
            e.Property(x => x.Value).HasMaxLength(128).IsRequired();
            e.HasIndex(x => new { x.CriterionId, x.Value }).IsUnique();
            e.HasOne(x => x.Criterion).WithMany(c => c.Values).HasForeignKey(x => x.CriterionId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<GroupRole>(e =>
        {
            e.ToTable("GroupRoles");
            e.HasKey(x => new { x.GroupId, x.RoleId });
            e.HasIndex(x => x.RoleId);
            e.HasOne(x => x.Group).WithMany(g => g.Roles).HasForeignKey(x => x.GroupId);
            e.HasOne(x => x.Role).WithMany().HasForeignKey(x => x.RoleId);
            Assign(e);
        });
        b.Entity<GroupPermission>(e =>
        {
            e.ToTable("GroupPermissions");
            e.HasKey(x => new { x.GroupId, x.PermissionId });
            e.HasIndex(x => x.PermissionId);
            e.HasOne(x => x.Group).WithMany(g => g.Permissions).HasForeignKey(x => x.GroupId);
            e.HasOne(x => x.Permission).WithMany().HasForeignKey(x => x.PermissionId);
            Assign(e);
        });

        // ---------------- Policy ----------------
        b.Entity<Policy>(e =>
        {
            e.ToTable("Policies");
            Code(e.Property(x => x.Code), 64); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(160).IsRequired();
            e.Property(x => x.Version).IsConcurrencyToken();
            e.HasOne(x => x.Tenant).WithMany().HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
            Audit(e);
        });
        b.Entity<PolicyClientTarget>(e =>
        {
            e.ToTable("PolicyClientTargets");
            e.HasIndex(x => new { x.PolicyId, x.ClientId }).IsUnique();
            e.HasOne(x => x.Policy).WithMany(p => p.ClientTargets).HasForeignKey(x => x.PolicyId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Client).WithMany().HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<PolicyObligation>(e =>
        {
            e.ToTable("PolicyObligations");
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.HasOne(x => x.Policy).WithMany(p => p.Obligations).HasForeignKey(x => x.PolicyId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<PolicyObligationParameter>(e =>
        {
            e.ToTable("PolicyObligationParameters");
            e.Property(x => x.Key).HasMaxLength(64).IsRequired();
            e.Property(x => x.Value).HasMaxLength(512).IsRequired();
            e.HasIndex(x => new { x.ObligationId, x.Key }).IsUnique();
            e.HasOne(x => x.Obligation).WithMany(o => o.Parameters).HasForeignKey(x => x.ObligationId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<PolicyTarget>(e =>
        {
            e.ToTable("PolicyTargets", t => t.HasCheckConstraint("CK_PolicyTargets_Target", TargetCheck));
            e.Property(x => x.Actions).HasMaxLength(256);
            e.HasIndex(x => x.CatalogNodeId);
            e.HasIndex(x => x.PermissionId);
            e.HasOne(x => x.Policy).WithMany(p => p.Targets).HasForeignKey(x => x.PolicyId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Application).WithMany().HasForeignKey(x => x.ApplicationId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.CatalogNode).WithMany().HasForeignKey(x => x.CatalogNodeId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Permission).WithMany().HasForeignKey(x => x.PermissionId).OnDelete(DeleteBehavior.Restrict);
        });
        b.Entity<Rule>(e =>
        {
            e.ToTable("Rules");
            Code(e.Property(x => x.Code), 64);
            e.HasIndex(x => new { x.PolicyId, x.Code }).IsUnique();
            e.Property(x => x.Name).HasMaxLength(160).IsRequired();
            e.Property(x => x.ReasonCode).HasMaxLength(64);
            e.HasOne(x => x.Policy).WithMany(p => p.Rules).HasForeignKey(x => x.PolicyId).OnDelete(DeleteBehavior.Cascade);
            Audit(e);
        });
        b.Entity<RuleCondition>(e =>
        {
            e.ToTable("RuleConditions", t => t.HasCheckConstraint("CK_RuleConditions_Owner",
                "([RuleId] IS NOT NULL AND [SharedConditionId] IS NULL) OR ([RuleId] IS NULL AND [SharedConditionId] IS NOT NULL)"));
            e.HasIndex(x => x.RuleId);
            e.HasIndex(x => x.SharedConditionId);
            e.HasIndex(x => x.ReferencedSharedConditionId);
            e.HasOne(x => x.Rule).WithMany(r => r.Conditions).HasForeignKey(x => x.RuleId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.SharedCondition).WithMany(s => s.Nodes).HasForeignKey(x => x.SharedConditionId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ReferencedSharedCondition).WithMany().HasForeignKey(x => x.ReferencedSharedConditionId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Parent).WithMany(x => x.Children).HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ConditionType).WithMany().HasForeignKey(x => x.ConditionTypeId).OnDelete(DeleteBehavior.Restrict);
        });
        b.Entity<ConditionParameter>(e =>
        {
            e.ToTable("ConditionParameters");
            e.Property(x => x.Key).HasMaxLength(64).IsRequired();
            e.Property(x => x.Value).HasMaxLength(1024).IsRequired();
            e.HasIndex(x => new { x.ConditionId, x.Key }).IsUnique();
            e.HasOne(x => x.Condition).WithMany(c => c.Parameters).HasForeignKey(x => x.ConditionId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<SharedCondition>(e =>
        {
            e.ToTable("SharedConditions");
            Code(e.Property(x => x.Code), 64); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(160).IsRequired();
            e.Property(x => x.Domain).HasMaxLength(32);
            e.Property(x => x.Version).IsConcurrencyToken();
            Audit(e);
        });
        b.Entity<ConditionType>(e =>
        {
            e.ToTable("ConditionTypes");
            Code(e.Property(x => x.Code), 64); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
        });

        // ---------------- Yönetişim / olaylar / audit ----------------
        b.Entity<SodRule>(e =>
        {
            e.ToTable("SodRules");
            Code(e.Property(x => x.Code), 64); e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(160).IsRequired();
            Audit(e);
        });
        b.Entity<SodRuleMember>(e =>
        {
            e.ToTable("SodRuleMembers");
            e.HasIndex(x => new { x.SodRuleId, x.MemberType, x.MemberId }).IsUnique();
            e.HasOne(x => x.SodRule).WithMany(r => r.Members).HasForeignKey(x => x.SodRuleId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<SodViolation>(e =>
        {
            e.ToTable("SodViolations");
            e.HasIndex(x => new { x.UserId, x.SodRuleId, x.Status });
            e.Property(x => x.Details).HasMaxLength(2048);
            e.HasOne(x => x.SodRule).WithMany().HasForeignKey(x => x.SodRuleId);
            e.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId);
        });
        b.Entity<ExternalSystem>(e =>
        {
            e.ToTable("ExternalSystems");
            Code(e.Property(x => x.Code), 32); e.HasIndex(x => x.Code).IsUnique();
            Audit(e);
        });
        b.Entity<ExternalPermission>(e =>
        {
            e.ToTable("ExternalPermissions");
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.Property(x => x.ResourceClass).HasMaxLength(32);
            e.HasIndex(x => new { x.ExternalSystemId, x.Code }).IsUnique();
            e.HasOne(x => x.ExternalSystem).WithMany(s => s.Permissions).HasForeignKey(x => x.ExternalSystemId);
            Audit(e);
        });
        b.Entity<ExternalPermissionRequirement>(e =>
        {
            e.ToTable("ExternalPermissionRequirements", t => t.HasCheckConstraint("CK_ExternalPermissionRequirements_NotSelf",
                "\"ExternalPermissionId\" <> \"RequiredExternalPermissionId\""));
            e.HasKey(x => new { x.ExternalPermissionId, x.RequiredExternalPermissionId });
            e.HasOne(x => x.ExternalPermission).WithMany(p => p.Requires).HasForeignKey(x => x.ExternalPermissionId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.RequiredExternalPermission).WithMany().HasForeignKey(x => x.RequiredExternalPermissionId).OnDelete(DeleteBehavior.Restrict);
            Assign(e);
        });
        b.Entity<ExternalDependency>(e =>
        {
            // API, endpoint veya permission'dan TAM OLARAK BİRİ dolu
            e.ToTable("ExternalDependencies", t => t.HasCheckConstraint("CK_ExternalDependencies_Owner",
                "(CASE WHEN \"ApiResourceId\" IS NULL THEN 0 ELSE 1 END) + (CASE WHEN \"ApiEndpointId\" IS NULL THEN 0 ELSE 1 END) + (CASE WHEN \"PermissionId\" IS NULL THEN 0 ELSE 1 END) = 1"));
            e.HasOne(x => x.ApiResource).WithMany().HasForeignKey(x => x.ApiResourceId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.ApiEndpoint).WithMany().HasForeignKey(x => x.ApiEndpointId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Permission).WithMany().HasForeignKey(x => x.PermissionId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.ExternalPermission).WithMany().HasForeignKey(x => x.ExternalPermissionId).OnDelete(DeleteBehavior.Restrict);
            e.HasIndex(x => new { x.ApiResourceId, x.ApiEndpointId, x.PermissionId, x.ExternalPermissionId }).IsUnique();
            e.Property(x => x.Note).HasMaxLength(256);
            Assign(e);
        });
        b.Entity<UserExternalGrant>(e =>
        {
            e.ToTable("UserExternalGrants");
            e.HasKey(x => new { x.UserId, x.ExternalPermissionId });
            e.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.ExternalPermission).WithMany().HasForeignKey(x => x.ExternalPermissionId).OnDelete(DeleteBehavior.Restrict);
            e.Property(x => x.ProvisionedBy).HasMaxLength(64);
        });
        b.Entity<OutboxEvent>(e =>
        {
            e.ToTable("OutboxEvents");
            e.HasKey(x => x.Id);
            e.Property(x => x.EventType).HasMaxLength(64).IsRequired();
            e.HasIndex(x => new { x.Status, x.OccurredAt });
        });
        b.Entity<ProvisioningAction>(e =>
        {
            e.ToTable("ProvisioningActions");
            e.Property(x => x.PermissionCode).HasMaxLength(512);
            e.Property(x => x.ResourceClass).HasMaxLength(32);
            e.HasIndex(x => new { x.Status, x.CreatedAt });
            e.HasIndex(x => x.OutboxEventId);
        });
        b.Entity<AuditLog>(e =>
        {
            e.ToTable("AuditLogs");
            e.HasKey(x => x.Id);
            e.Property(x => x.Action).HasMaxLength(64).IsRequired();
            e.HasIndex(x => x.Timestamp);
            e.HasIndex(x => new { x.SubjectUserName, x.Timestamp });
            e.HasIndex(x => new { x.PermissionCode, x.Timestamp });
            e.HasIndex(x => x.CorrelationId);
        });
    }

    /// <summary>Hedef tipine göre tam olarak ilgili FK dolu olmalı (TargetType: 1=All, 2=Application, 3=CatalogNode, 4=Permission).</summary>
    private const string TargetCheck =
        "([TargetType] = 1 AND [ApplicationId] IS NULL AND [CatalogNodeId] IS NULL AND [PermissionId] IS NULL) OR " +
        "([TargetType] = 2 AND [ApplicationId] IS NOT NULL AND [CatalogNodeId] IS NULL AND [PermissionId] IS NULL) OR " +
        "([TargetType] = 3 AND [ApplicationId] IS NULL AND [CatalogNodeId] IS NOT NULL AND [PermissionId] IS NULL) OR " +
        "([TargetType] = 4 AND [ApplicationId] IS NULL AND [CatalogNodeId] IS NULL AND [PermissionId] IS NOT NULL)";

    private static void Code(PropertyBuilder<string> p, int length) => p.HasMaxLength(length).IsRequired();

    private static void Audit<T>(EntityTypeBuilder<T> e) where T : AuditableEntity
    {
        e.Property(x => x.CreatedBy).HasMaxLength(64);
        e.Property(x => x.UpdatedBy).HasMaxLength(64);
    }

    private static void Assign<T>(EntityTypeBuilder<T> e) where T : class, IAssignment =>
        e.Property(x => x.AssignedBy).HasMaxLength(64);
}
