﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class ChannelsAndObligations : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PolicyClientTargets",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    PolicyId = table.Column<int>(type: "INTEGER", nullable: false),
                    Mode = table.Column<int>(type: "INTEGER", nullable: false),
                    ClientId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PolicyClientTargets", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PolicyClientTargets_Clients_ClientId",
                        column: x => x.ClientId,
                        principalTable: "Clients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PolicyClientTargets_Policies_PolicyId",
                        column: x => x.PolicyId,
                        principalTable: "Policies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PolicyObligations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    PolicyId = table.Column<int>(type: "INTEGER", nullable: false),
                    Code = table.Column<string>(type: "TEXT", maxLength: 64, nullable: false),
                    FulfillOn = table.Column<int>(type: "INTEGER", nullable: false),
                    Order = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PolicyObligations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PolicyObligations_Policies_PolicyId",
                        column: x => x.PolicyId,
                        principalTable: "Policies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PolicyObligationParameters",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    ObligationId = table.Column<int>(type: "INTEGER", nullable: false),
                    Key = table.Column<string>(type: "TEXT", maxLength: 64, nullable: false),
                    Value = table.Column<string>(type: "TEXT", maxLength: 512, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PolicyObligationParameters", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PolicyObligationParameters_PolicyObligations_ObligationId",
                        column: x => x.ObligationId,
                        principalTable: "PolicyObligations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PolicyClientTargets_ClientId",
                table: "PolicyClientTargets",
                column: "ClientId");

            migrationBuilder.CreateIndex(
                name: "IX_PolicyClientTargets_PolicyId_ClientId",
                table: "PolicyClientTargets",
                columns: new[] { "PolicyId", "ClientId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_PolicyObligationParameters_ObligationId_Key",
                table: "PolicyObligationParameters",
                columns: new[] { "ObligationId", "Key" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_PolicyObligations_PolicyId",
                table: "PolicyObligations",
                column: "PolicyId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PolicyClientTargets");

            migrationBuilder.DropTable(
                name: "PolicyObligationParameters");

            migrationBuilder.DropTable(
                name: "PolicyObligations");
        }
    }
}
