﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class OwnershipTeamParent : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ParentId",
                table: "OwnershipTeams",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_OwnershipTeams_ParentId",
                table: "OwnershipTeams",
                column: "ParentId");

            migrationBuilder.AddForeignKey(
                name: "FK_OwnershipTeams_OwnershipTeams_ParentId",
                table: "OwnershipTeams",
                column: "ParentId",
                principalTable: "OwnershipTeams",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_OwnershipTeams_OwnershipTeams_ParentId",
                table: "OwnershipTeams");

            migrationBuilder.DropIndex(
                name: "IX_OwnershipTeams_ParentId",
                table: "OwnershipTeams");

            migrationBuilder.DropColumn(
                name: "ParentId",
                table: "OwnershipTeams");
        }
    }
}
