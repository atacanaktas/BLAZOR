﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class EndpointScopedPermissions : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Permissions_CatalogNodeId_Action",
                table: "Permissions");

            migrationBuilder.AddColumn<int>(
                name: "SourceEndpointId",
                table: "Permissions",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Permissions_CatalogNodeId_Action",
                table: "Permissions",
                columns: new[] { "CatalogNodeId", "Action" },
                unique: true,
                filter: "\"SourceEndpointId\" IS NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Permissions_SourceEndpointId_Action",
                table: "Permissions",
                columns: new[] { "SourceEndpointId", "Action" },
                unique: true,
                filter: "\"SourceEndpointId\" IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_Permissions_ApiEndpoints_SourceEndpointId",
                table: "Permissions",
                column: "SourceEndpointId",
                principalTable: "ApiEndpoints",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Permissions_ApiEndpoints_SourceEndpointId",
                table: "Permissions");

            migrationBuilder.DropIndex(
                name: "IX_Permissions_CatalogNodeId_Action",
                table: "Permissions");

            migrationBuilder.DropIndex(
                name: "IX_Permissions_SourceEndpointId_Action",
                table: "Permissions");

            migrationBuilder.DropColumn(
                name: "SourceEndpointId",
                table: "Permissions");

            migrationBuilder.CreateIndex(
                name: "IX_Permissions_CatalogNodeId_Action",
                table: "Permissions",
                columns: new[] { "CatalogNodeId", "Action" },
                unique: true);
        }
    }
}
