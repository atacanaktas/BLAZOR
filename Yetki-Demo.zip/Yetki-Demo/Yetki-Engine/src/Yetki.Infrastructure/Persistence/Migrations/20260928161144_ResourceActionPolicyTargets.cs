﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class ResourceActionPolicyTargets : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Permissions_CatalogNodeId",
                table: "Permissions");

            migrationBuilder.AddColumn<string>(
                name: "Actions",
                table: "PolicyTargets",
                type: "TEXT",
                maxLength: 256,
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Permissions_CatalogNodeId_Action",
                table: "Permissions",
                columns: new[] { "CatalogNodeId", "Action" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Permissions_CatalogNodeId_Action",
                table: "Permissions");

            migrationBuilder.DropColumn(
                name: "Actions",
                table: "PolicyTargets");

            migrationBuilder.CreateIndex(
                name: "IX_Permissions_CatalogNodeId",
                table: "Permissions",
                column: "CatalogNodeId");
        }
    }
}
