﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class OwnershipTeams : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "OwnerTeamId",
                table: "CatalogNodes",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "OwnerUserId",
                table: "CatalogNodes",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "OwnerTeamId",
                table: "Applications",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "OwnerUserId",
                table: "Applications",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "OwnershipTeams",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    TenantId = table.Column<int>(type: "INTEGER", nullable: false),
                    Code = table.Column<string>(type: "TEXT", maxLength: 32, nullable: false),
                    Name = table.Column<string>(type: "TEXT", maxLength: 128, nullable: false),
                    Description = table.Column<string>(type: "TEXT", maxLength: 512, nullable: true),
                    IsActive = table.Column<bool>(type: "INTEGER", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "TEXT", nullable: false),
                    CreatedBy = table.Column<string>(type: "TEXT", maxLength: 64, nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "TEXT", nullable: true),
                    UpdatedBy = table.Column<string>(type: "TEXT", maxLength: 64, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OwnershipTeams", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OwnershipTeams_Tenants_TenantId",
                        column: x => x.TenantId,
                        principalTable: "Tenants",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            // Convert existing free-text ownership into reusable team records.
            migrationBuilder.Sql("""
                INSERT INTO "OwnershipTeams" ("TenantId", "Code", "Name", "Description", "IsActive", "CreatedAt", "CreatedBy")
                SELECT "TenantId", 'TEAM_APP_' || printf('%04d', MIN("Id")), "OwnerTeam", 'Migrated from Application ownership', 1, CURRENT_TIMESTAMP, 'migration'
                FROM "Applications"
                WHERE "OwnerTeam" IS NOT NULL AND trim("OwnerTeam") <> ''
                GROUP BY "TenantId", "OwnerTeam";

                INSERT INTO "OwnershipTeams" ("TenantId", "Code", "Name", "Description", "IsActive", "CreatedAt", "CreatedBy")
                SELECT n."TenantId", 'TEAM_NODE_' || printf('%04d', MIN(n."Id")), n."OwnerTeam", 'Migrated from Catalog Level ownership', 1, CURRENT_TIMESTAMP, 'migration'
                FROM "CatalogNodes" n
                WHERE n."OwnerTeam" IS NOT NULL AND trim(n."OwnerTeam") <> ''
                  AND NOT EXISTS (
                    SELECT 1 FROM "OwnershipTeams" t
                    WHERE t."TenantId" = n."TenantId" AND t."Name" = n."OwnerTeam"
                  )
                GROUP BY n."TenantId", n."OwnerTeam";

                UPDATE "Applications"
                SET "OwnerTeamId" = (
                    SELECT t."Id" FROM "OwnershipTeams" t
                    WHERE t."TenantId" = "Applications"."TenantId" AND t."Name" = "Applications"."OwnerTeam"
                    LIMIT 1
                )
                WHERE "OwnerTeam" IS NOT NULL AND trim("OwnerTeam") <> '';

                UPDATE "CatalogNodes"
                SET "OwnerTeamId" = (
                    SELECT t."Id" FROM "OwnershipTeams" t
                    WHERE t."TenantId" = "CatalogNodes"."TenantId" AND t."Name" = "CatalogNodes"."OwnerTeam"
                    LIMIT 1
                )
                WHERE "OwnerTeam" IS NOT NULL AND trim("OwnerTeam") <> '';
                """);

            migrationBuilder.CreateIndex(
                name: "IX_CatalogNodes_OwnerTeamId",
                table: "CatalogNodes",
                column: "OwnerTeamId");

            migrationBuilder.CreateIndex(
                name: "IX_Applications_OwnerTeamId",
                table: "Applications",
                column: "OwnerTeamId");

            migrationBuilder.CreateIndex(
                name: "IX_OwnershipTeams_TenantId_Code",
                table: "OwnershipTeams",
                columns: new[] { "TenantId", "Code" },
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Applications_OwnershipTeams_OwnerTeamId",
                table: "Applications",
                column: "OwnerTeamId",
                principalTable: "OwnershipTeams",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_CatalogNodes_OwnershipTeams_OwnerTeamId",
                table: "CatalogNodes",
                column: "OwnerTeamId",
                principalTable: "OwnershipTeams",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Applications_OwnershipTeams_OwnerTeamId",
                table: "Applications");

            migrationBuilder.DropForeignKey(
                name: "FK_CatalogNodes_OwnershipTeams_OwnerTeamId",
                table: "CatalogNodes");

            migrationBuilder.DropTable(
                name: "OwnershipTeams");

            migrationBuilder.DropIndex(
                name: "IX_CatalogNodes_OwnerTeamId",
                table: "CatalogNodes");

            migrationBuilder.DropIndex(
                name: "IX_Applications_OwnerTeamId",
                table: "Applications");

            migrationBuilder.DropColumn(
                name: "OwnerTeamId",
                table: "CatalogNodes");

            migrationBuilder.DropColumn(
                name: "OwnerUserId",
                table: "CatalogNodes");

            migrationBuilder.DropColumn(
                name: "OwnerTeamId",
                table: "Applications");

            migrationBuilder.DropColumn(
                name: "OwnerUserId",
                table: "Applications");
        }
    }
}
