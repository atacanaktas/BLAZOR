﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class FlexibleCatalogHierarchy : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Permissions_CatalogNodeId_Action",
                table: "Permissions");

            migrationBuilder.DropIndex(
                name: "IX_CatalogNodes_ApplicationId_ParentId_Code",
                table: "CatalogNodes");

            migrationBuilder.AlterColumn<int>(
                name: "CatalogNodeId",
                table: "Permissions",
                type: "INTEGER",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "INTEGER");

            migrationBuilder.AddColumn<int>(
                name: "ApplicationId",
                table: "Permissions",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TenantId",
                table: "Permissions",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<int>(
                name: "ApplicationId",
                table: "CatalogNodes",
                type: "INTEGER",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "INTEGER");

            migrationBuilder.AddColumn<int>(
                name: "TenantId",
                table: "CatalogNodes",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<int>(
                name: "CatalogNodeId",
                table: "ApiResources",
                type: "INTEGER",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "INTEGER");

            migrationBuilder.AddColumn<int>(
                name: "ApplicationId",
                table: "ApiResources",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TenantId",
                table: "ApiResources",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            // Preserve ownership for the existing fixed Application -> CatalogNode model
            // before the new required Tenant foreign keys are created.
            migrationBuilder.Sql("""
                UPDATE "CatalogNodes"
                SET "TenantId" = (SELECT "TenantId" FROM "Applications" WHERE "Applications"."Id" = "CatalogNodes"."ApplicationId");

                UPDATE "ApiResources"
                SET "ApplicationId" = (SELECT "ApplicationId" FROM "CatalogNodes" WHERE "CatalogNodes"."Id" = "ApiResources"."CatalogNodeId"),
                    "TenantId" = (SELECT "TenantId" FROM "CatalogNodes" WHERE "CatalogNodes"."Id" = "ApiResources"."CatalogNodeId");

                UPDATE "Permissions"
                SET "ApplicationId" = (SELECT "ApplicationId" FROM "CatalogNodes" WHERE "CatalogNodes"."Id" = "Permissions"."CatalogNodeId"),
                    "TenantId" = (SELECT "TenantId" FROM "CatalogNodes" WHERE "CatalogNodes"."Id" = "Permissions"."CatalogNodeId");
                """);

            migrationBuilder.CreateIndex(
                name: "IX_Permissions_ApplicationId",
                table: "Permissions",
                column: "ApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_Permissions_CatalogNodeId_Action",
                table: "Permissions",
                columns: new[] { "CatalogNodeId", "Action" },
                unique: true,
                filter: "\"SourceEndpointId\" IS NULL AND \"CatalogNodeId\" IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Permissions_TenantId",
                table: "Permissions",
                column: "TenantId");

            migrationBuilder.CreateIndex(
                name: "IX_CatalogNodes_ApplicationId",
                table: "CatalogNodes",
                column: "ApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_CatalogNodes_TenantId_ApplicationId_ParentId_Code",
                table: "CatalogNodes",
                columns: new[] { "TenantId", "ApplicationId", "ParentId", "Code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ApiResources_ApplicationId",
                table: "ApiResources",
                column: "ApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_ApiResources_TenantId",
                table: "ApiResources",
                column: "TenantId");

            migrationBuilder.AddForeignKey(
                name: "FK_ApiResources_Applications_ApplicationId",
                table: "ApiResources",
                column: "ApplicationId",
                principalTable: "Applications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ApiResources_Tenants_TenantId",
                table: "ApiResources",
                column: "TenantId",
                principalTable: "Tenants",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_CatalogNodes_Tenants_TenantId",
                table: "CatalogNodes",
                column: "TenantId",
                principalTable: "Tenants",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Permissions_Applications_ApplicationId",
                table: "Permissions",
                column: "ApplicationId",
                principalTable: "Applications",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Permissions_Tenants_TenantId",
                table: "Permissions",
                column: "TenantId",
                principalTable: "Tenants",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ApiResources_Applications_ApplicationId",
                table: "ApiResources");

            migrationBuilder.DropForeignKey(
                name: "FK_ApiResources_Tenants_TenantId",
                table: "ApiResources");

            migrationBuilder.DropForeignKey(
                name: "FK_CatalogNodes_Tenants_TenantId",
                table: "CatalogNodes");

            migrationBuilder.DropForeignKey(
                name: "FK_Permissions_Applications_ApplicationId",
                table: "Permissions");

            migrationBuilder.DropForeignKey(
                name: "FK_Permissions_Tenants_TenantId",
                table: "Permissions");

            migrationBuilder.DropIndex(
                name: "IX_Permissions_ApplicationId",
                table: "Permissions");

            migrationBuilder.DropIndex(
                name: "IX_Permissions_CatalogNodeId_Action",
                table: "Permissions");

            migrationBuilder.DropIndex(
                name: "IX_Permissions_TenantId",
                table: "Permissions");

            migrationBuilder.DropIndex(
                name: "IX_CatalogNodes_ApplicationId",
                table: "CatalogNodes");

            migrationBuilder.DropIndex(
                name: "IX_CatalogNodes_TenantId_ApplicationId_ParentId_Code",
                table: "CatalogNodes");

            migrationBuilder.DropIndex(
                name: "IX_ApiResources_ApplicationId",
                table: "ApiResources");

            migrationBuilder.DropIndex(
                name: "IX_ApiResources_TenantId",
                table: "ApiResources");

            migrationBuilder.DropColumn(
                name: "ApplicationId",
                table: "Permissions");

            migrationBuilder.DropColumn(
                name: "TenantId",
                table: "Permissions");

            migrationBuilder.DropColumn(
                name: "TenantId",
                table: "CatalogNodes");

            migrationBuilder.DropColumn(
                name: "ApplicationId",
                table: "ApiResources");

            migrationBuilder.DropColumn(
                name: "TenantId",
                table: "ApiResources");

            migrationBuilder.AlterColumn<int>(
                name: "CatalogNodeId",
                table: "Permissions",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "INTEGER",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ApplicationId",
                table: "CatalogNodes",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "INTEGER",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CatalogNodeId",
                table: "ApiResources",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "INTEGER",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Permissions_CatalogNodeId_Action",
                table: "Permissions",
                columns: new[] { "CatalogNodeId", "Action" },
                unique: true,
                filter: "\"SourceEndpointId\" IS NULL");

            migrationBuilder.CreateIndex(
                name: "IX_CatalogNodes_ApplicationId_ParentId_Code",
                table: "CatalogNodes",
                columns: new[] { "ApplicationId", "ParentId", "Code" },
                unique: true);
        }
    }
}
