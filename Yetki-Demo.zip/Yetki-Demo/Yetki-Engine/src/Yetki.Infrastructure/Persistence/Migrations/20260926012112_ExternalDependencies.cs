﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Yetki.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class ExternalDependencies : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "AccessLevel",
                table: "ProvisioningActions",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "PreviousAccessLevel",
                table: "ProvisioningActions",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ResourceClass",
                table: "ProvisioningActions",
                type: "TEXT",
                maxLength: 32,
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "HasAccessLevels",
                table: "ExternalSystems",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "Description",
                table: "ExternalPermissions",
                type: "TEXT",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ResourceClass",
                table: "ExternalPermissions",
                type: "TEXT",
                maxLength: 32,
                nullable: true);

            migrationBuilder.CreateTable(
                name: "ExternalDependencies",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    ApiResourceId = table.Column<int>(type: "INTEGER", nullable: true),
                    ApiEndpointId = table.Column<int>(type: "INTEGER", nullable: true),
                    PermissionId = table.Column<int>(type: "INTEGER", nullable: true),
                    ExternalPermissionId = table.Column<int>(type: "INTEGER", nullable: false),
                    AccessLevel = table.Column<int>(type: "INTEGER", nullable: true),
                    Note = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    AssignedAt = table.Column<DateTime>(type: "TEXT", nullable: false),
                    AssignedBy = table.Column<string>(type: "TEXT", maxLength: 64, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ExternalDependencies", x => x.Id);
                    table.CheckConstraint("CK_ExternalDependencies_Owner", "(CASE WHEN \"ApiResourceId\" IS NULL THEN 0 ELSE 1 END) + (CASE WHEN \"ApiEndpointId\" IS NULL THEN 0 ELSE 1 END) + (CASE WHEN \"PermissionId\" IS NULL THEN 0 ELSE 1 END) = 1");
                    table.ForeignKey(
                        name: "FK_ExternalDependencies_ApiEndpoints_ApiEndpointId",
                        column: x => x.ApiEndpointId,
                        principalTable: "ApiEndpoints",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ExternalDependencies_ApiResources_ApiResourceId",
                        column: x => x.ApiResourceId,
                        principalTable: "ApiResources",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ExternalDependencies_ExternalPermissions_ExternalPermissionId",
                        column: x => x.ExternalPermissionId,
                        principalTable: "ExternalPermissions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ExternalDependencies_Permissions_PermissionId",
                        column: x => x.PermissionId,
                        principalTable: "Permissions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ExternalPermissionRequirements",
                columns: table => new
                {
                    ExternalPermissionId = table.Column<int>(type: "INTEGER", nullable: false),
                    RequiredExternalPermissionId = table.Column<int>(type: "INTEGER", nullable: false),
                    AccessLevel = table.Column<int>(type: "INTEGER", nullable: true),
                    AssignedAt = table.Column<DateTime>(type: "TEXT", nullable: false),
                    AssignedBy = table.Column<string>(type: "TEXT", maxLength: 64, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ExternalPermissionRequirements", x => new { x.ExternalPermissionId, x.RequiredExternalPermissionId });
                    table.CheckConstraint("CK_ExternalPermissionRequirements_NotSelf", "\"ExternalPermissionId\" <> \"RequiredExternalPermissionId\"");
                    table.ForeignKey(
                        name: "FK_ExternalPermissionRequirements_ExternalPermissions_ExternalPermissionId",
                        column: x => x.ExternalPermissionId,
                        principalTable: "ExternalPermissions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ExternalPermissionRequirements_ExternalPermissions_RequiredExternalPermissionId",
                        column: x => x.RequiredExternalPermissionId,
                        principalTable: "ExternalPermissions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserExternalGrants",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "INTEGER", nullable: false),
                    ExternalPermissionId = table.Column<int>(type: "INTEGER", nullable: false),
                    AccessLevel = table.Column<int>(type: "INTEGER", nullable: true),
                    ProvisionedAt = table.Column<DateTime>(type: "TEXT", nullable: false),
                    ProvisionedBy = table.Column<string>(type: "TEXT", maxLength: 64, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserExternalGrants", x => new { x.UserId, x.ExternalPermissionId });
                    table.ForeignKey(
                        name: "FK_UserExternalGrants_ExternalPermissions_ExternalPermissionId",
                        column: x => x.ExternalPermissionId,
                        principalTable: "ExternalPermissions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_UserExternalGrants_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            // Veri taşıma: eski permission → dış yetki eşlemeleri, permission seviyesindeki bağımlılık olur (seviye: action'dan türetilir).
            migrationBuilder.Sql(
                "INSERT INTO \"ExternalDependencies\" (\"PermissionId\", \"ExternalPermissionId\", \"Note\", \"AssignedAt\", \"AssignedBy\") " +
                "SELECT \"PermissionId\", \"ExternalPermissionId\", 'eski eşlemeden taşındı', \"AssignedAt\", \"AssignedBy\" FROM \"PermissionExternalMappings\";");
            // RACF erişim seviyeli (READ/UPDATE/CONTROL/ALTER); LDAP sadece üyelik
            migrationBuilder.Sql("UPDATE \"ExternalSystems\" SET \"HasAccessLevels\" = 1 WHERE \"Code\" = 'RACF';");
            migrationBuilder.Sql("UPDATE \"ExternalPermissions\" SET \"ResourceClass\" = 'TCICSTRN' WHERE \"ResourceClass\" IS NULL AND \"ExternalSystemId\" IN (SELECT \"Id\" FROM \"ExternalSystems\" WHERE \"Code\" = 'RACF');");
            migrationBuilder.Sql("UPDATE \"ExternalPermissions\" SET \"ResourceClass\" = 'GROUP' WHERE \"ResourceClass\" IS NULL AND \"ExternalSystemId\" IN (SELECT \"Id\" FROM \"ExternalSystems\" WHERE \"Code\" = 'LDAP');");

            migrationBuilder.DropTable(
                name: "PermissionExternalMappings");

            migrationBuilder.CreateIndex(
                name: "IX_ExternalDependencies_ApiEndpointId",
                table: "ExternalDependencies",
                column: "ApiEndpointId");

            migrationBuilder.CreateIndex(
                name: "IX_ExternalDependencies_ApiResourceId_ApiEndpointId_PermissionId_ExternalPermissionId",
                table: "ExternalDependencies",
                columns: new[] { "ApiResourceId", "ApiEndpointId", "PermissionId", "ExternalPermissionId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ExternalDependencies_ExternalPermissionId",
                table: "ExternalDependencies",
                column: "ExternalPermissionId");

            migrationBuilder.CreateIndex(
                name: "IX_ExternalDependencies_PermissionId",
                table: "ExternalDependencies",
                column: "PermissionId");

            migrationBuilder.CreateIndex(
                name: "IX_ExternalPermissionRequirements_RequiredExternalPermissionId",
                table: "ExternalPermissionRequirements",
                column: "RequiredExternalPermissionId");

            migrationBuilder.CreateIndex(
                name: "IX_UserExternalGrants_ExternalPermissionId",
                table: "UserExternalGrants",
                column: "ExternalPermissionId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ExternalDependencies");

            migrationBuilder.DropTable(
                name: "ExternalPermissionRequirements");

            migrationBuilder.DropTable(
                name: "UserExternalGrants");

            migrationBuilder.DropColumn(
                name: "AccessLevel",
                table: "ProvisioningActions");

            migrationBuilder.DropColumn(
                name: "PreviousAccessLevel",
                table: "ProvisioningActions");

            migrationBuilder.DropColumn(
                name: "ResourceClass",
                table: "ProvisioningActions");

            migrationBuilder.DropColumn(
                name: "HasAccessLevels",
                table: "ExternalSystems");

            migrationBuilder.DropColumn(
                name: "Description",
                table: "ExternalPermissions");

            migrationBuilder.DropColumn(
                name: "ResourceClass",
                table: "ExternalPermissions");

            migrationBuilder.CreateTable(
                name: "PermissionExternalMappings",
                columns: table => new
                {
                    PermissionId = table.Column<int>(type: "INTEGER", nullable: false),
                    ExternalPermissionId = table.Column<int>(type: "INTEGER", nullable: false),
                    AssignedAt = table.Column<DateTime>(type: "TEXT", nullable: false),
                    AssignedBy = table.Column<string>(type: "TEXT", maxLength: 64, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PermissionExternalMappings", x => new { x.PermissionId, x.ExternalPermissionId });
                    table.ForeignKey(
                        name: "FK_PermissionExternalMappings_ExternalPermissions_ExternalPermissionId",
                        column: x => x.ExternalPermissionId,
                        principalTable: "ExternalPermissions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PermissionExternalMappings_Permissions_PermissionId",
                        column: x => x.PermissionId,
                        principalTable: "Permissions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PermissionExternalMappings_ExternalPermissionId",
                table: "PermissionExternalMappings",
                column: "ExternalPermissionId");
        }
    }
}
