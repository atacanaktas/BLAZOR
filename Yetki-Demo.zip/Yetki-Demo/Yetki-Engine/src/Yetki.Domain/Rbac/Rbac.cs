using Yetki.Domain.Catalog;
using Yetki.Domain.Common;
using Yetki.Domain.Tenants;
using Yetki.Domain.Identity;

namespace Yetki.Domain.Rbac;

/// <summary>
/// İş tanımına göre gruplanmış yetki paketi (NIST RBAC). Bir kuruma aittir;
/// IsInheritable=true ise alt kurumların kullanıcılarına da atanabilir (ör. PERSONEL).
/// </summary>
public class Role : AuditableEntity
{
    public int TenantId { get; set; }
    public Tenant Tenant { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsInheritable { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<RolePermission> Permissions { get; set; } = new List<RolePermission>();
}

public class RolePermission : IAssignment
{
    public int RoleId { get; set; }
    public Role Role { get; set; } = default!;
    public int PermissionId { get; set; }
    public Permission Permission { get; set; } = default!;
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}

/// <summary>Kullanıcıya doğrudan rol ataması. Süreli olabilir (vekalet, geçici görev).</summary>
public class UserRole : IAssignment
{
    public int UserId { get; set; }
    public User User { get; set; } = default!;
    public int RoleId { get; set; }
    public Role Role { get; set; } = default!;
    public DateTime? ValidFrom { get; set; }
    public DateTime? ValidUntil { get; set; }
    public string? Reason { get; set; }
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}

/// <summary>
/// Kullanıcıya doğrudan permission ataması. Ana model DEĞİLDİR: eski sistemden taşınan istisnalar ve
/// geçici yetkiler içindir; gerekçe ve bitiş tarihi tutulmalıdır.
/// </summary>
public class UserPermission : IAssignment
{
    public int UserId { get; set; }
    public User User { get; set; } = default!;
    public int PermissionId { get; set; }
    public Permission Permission { get; set; } = default!;
    public string? Reason { get; set; }
    public DateTime? ValidUntil { get; set; }
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}
