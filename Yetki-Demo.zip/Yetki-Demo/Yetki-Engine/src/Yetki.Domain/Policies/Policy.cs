using Yetki.Domain.Catalog;
using Yetki.Domain.Common;
using Yetki.Domain.Tenants;

namespace Yetki.Domain.Policies;

// ============================================================================================
//  Policy modeli: "kullanıcı sahip olduğu permission'ı mevcut koşullar altında kullanabilir mi?"
//
//  Policy ──(1:N)── PolicyTarget   hangi permission'lara uygulanır? (Tümü / Uygulama / Katalog düğümü / Permission, Include/Exclude)
//     └──(1:N)── Rule              sağlanması gereken TEK koşul (Saat 09-18 · Tutar ≤ limit · IP şube ağında · izinde değil)
//                  └── RuleCondition (ifade ağacı: tek predicate veya VE/VEYA/DEĞİL) ── ConditionParameter · ConditionType (→ C# handler)
//                                      └── Reference → SharedCondition (adlandırılmış ortak koşul)
//
//  - Rule sonucu: sağlandı (Pass) / sağlanmadı (Fail → ReasonCode) / belirsiz (Indeterminate, fail-closed).
//  - Policy sonucu: karar stratejisi (Tüm rule'lar sağlanmalı | En az biri yeterli) → Permit / Deny / Indeterminate.
//  - Policy bir tenant'a aittir; o tenant ve ALT tenant'ların kullanıcılarına uygulanır.
//  - Hedef düğüm altındaki tüm alt düğüm ve permission'lar policy'yi miras alır; istisna Exclude ile yapılır.
//  - Policy yetki VERMEZ: RBAC'ın verdiği yetkiyi koşullara bağlar. Nihai karar: RBAC Permit ∧ tüm policy'ler Permit.
//  - DB'de ASLA çalıştırılabilir kod/SQL/script tutulmaz; davranış C# handler'dadır.
// ============================================================================================

public class Policy : AuditableEntity
{
    public int TenantId { get; set; }
    public Tenant Tenant { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public CombiningAlgorithm CombiningAlgorithm { get; set; } = CombiningAlgorithm.AllRulesMustPass;
    public PolicyMode Mode { get; set; } = PolicyMode.Enforce;
    public bool IsActive { get; set; } = true;
    /// <summary>Policy, hedefleri veya rule'larında her değişiklikte artar; kararlar versiyonla audit'lenir.</summary>
    public int Version { get; set; } = 1;

    public ICollection<PolicyTarget> Targets { get; set; } = new List<PolicyTarget>();
    public ICollection<Rule> Rules { get; set; } = new List<Rule>();
    /// <summary>Kanal hedefi: Include varsa policy SADECE bu client'lardan gelen isteklere uygulanır; Exclude client'lar hariç tutulur.</summary>
    public ICollection<PolicyClientTarget> ClientTargets { get; set; } = new List<PolicyClientTarget>();
    /// <summary>Karar ile PEP'e dönen yükümlülükler (ör. mobilde TCKN maskele).</summary>
    public ICollection<PolicyObligation> Obligations { get; set; } = new List<PolicyObligation>();
}

/// <summary>
/// Policy'nin kanal (client) hedefi — Conditional Access'teki "client apps" koşulu. Katalog hedefiyle birlikte (VE) değerlendirilir:
/// Include client'ları varsa istek client'ı bunlardan biri olmalı; Exclude client'ları hariç tutar. Hiç yoksa tüm kanallar.
/// </summary>
public class PolicyClientTarget : Entity
{
    public int PolicyId { get; set; }
    public Policy Policy { get; set; } = default!;
    public InclusionMode Mode { get; set; } = InclusionMode.Include;
    public int ClientId { get; set; }
    public Clients.Client Client { get; set; } = default!;
}

/// <summary>
/// Yükümlülük (XACML obligation): karar verildiğinde PEP'in (API / SDK) YERİNE GETİRMESİ gereken iş.
/// Tip kodu koddaki katalogdan (MASK_FIELDS, LIMIT_RESULTS, LOG_ACCESS); PEP tanımadığı yükümlülükte erişimi REDDEDER.
/// </summary>
public class PolicyObligation : Entity
{
    public int PolicyId { get; set; }
    public Policy Policy { get; set; } = default!;
    public string Code { get; set; } = default!;
    public ObligationFulfillOn FulfillOn { get; set; } = ObligationFulfillOn.Permit;
    public int Order { get; set; }
    public ICollection<PolicyObligationParameter> Parameters { get; set; } = new List<PolicyObligationParameter>();
}

public class PolicyObligationParameter : Entity
{
    public int ObligationId { get; set; }
    public PolicyObligation Obligation { get; set; } = default!;
    public string Key { get; set; } = default!;
    public string Value { get; set; } = default!;
}

/// <summary>
/// Policy hedefi. Include hedeflerinden biri eşleşir ve hiçbir Exclude hedefi eşleşmezse policy uygulanır.
/// Tipine göre ApplicationId / CatalogNodeId / PermissionId dolu (All için hiçbiri).
/// </summary>
public class PolicyTarget : Entity
{
    public int PolicyId { get; set; }
    public Policy Policy { get; set; } = default!;
    public InclusionMode Mode { get; set; } = InclusionMode.Include;
    public TargetType TargetType { get; set; }
    public int? ApplicationId { get; set; }
    public CatalogApplication? Application { get; set; }
    public int? CatalogNodeId { get; set; }
    public CatalogNode? CatalogNode { get; set; }
    public int? PermissionId { get; set; }
    public Permission? Permission { get; set; }
    /// <summary>
    /// Virgülle ayrılmış action filtresi (örn. close,approve). Boşsa hedefteki tüm action'lar kapsanır.
    /// Resource mirasıyla birlikte kullanılarak aynı policy/rule tanımının tekrarını önler.
    /// </summary>
    public string? Actions { get; set; }
}

/// <summary>
/// Policy içinde değerlendirilen tek koşul (gereksinim). Condition TRUE → sağlandı; FALSE → sağlanmadı (ReasonCode ile Deny);
/// belirsiz (eksik değer, hata) → Indeterminate.
/// </summary>
public class Rule : AuditableEntity
{
    public int PolicyId { get; set; }
    public Policy Policy { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public int Order { get; set; }
    /// <summary>Rule sağlanmadığında döndürülecek makine-okunur neden (ör. AMOUNT_EXCEEDS_USER_LIMIT).</summary>
    public string? ReasonCode { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<RuleCondition> Conditions { get; set; } = new List<RuleCondition>();
}

/// <summary>
/// Condition ifade ağacı düğümü (self-reference, ilişkisel; JSON blob yok).
/// Düğüm ya bir Rule'a (RuleId) ya da bir ortak koşula (SharedConditionId) aittir — tam olarak biri dolu.
/// </summary>
public class RuleCondition : Entity
{
    public int? RuleId { get; set; }
    public Rule? Rule { get; set; }
    public int? SharedConditionId { get; set; }
    public SharedCondition? SharedCondition { get; set; }
    public int? ParentId { get; set; }
    public RuleCondition? Parent { get; set; }
    public ConditionKind Kind { get; set; } = ConditionKind.Predicate;
    public int? ConditionTypeId { get; set; }
    public ConditionType? ConditionType { get; set; }
    public int? ReferencedSharedConditionId { get; set; }
    public SharedCondition? ReferencedSharedCondition { get; set; }
    public int Order { get; set; }

    public ICollection<RuleCondition> Children { get; set; } = new List<RuleCondition>();
    public ICollection<ConditionParameter> Parameters { get; set; } = new List<ConditionParameter>();
}

/// <summary>Adlandırılmış ortak tanım ("Banka ağı", "Mesai saati"). Rule'lar Reference düğümüyle bağlanır (kopya değil).</summary>
public class SharedCondition : AuditableEntity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ConditionScope Scope { get; set; } = ConditionScope.Global;
    /// <summary>Domain kapsamında sahibi olan iş alanı (katalog domain kodu, ör. KREDI).</summary>
    public string? Domain { get; set; }
    public bool IsActive { get; set; } = true;
    public int Version { get; set; } = 1;

    public ICollection<RuleCondition> Nodes { get; set; } = new List<RuleCondition>();
}

/// <summary>Predicate parametresi. Kullanıcıya özgü değer (ör. limit) BURADA TUTULMAZ; attribute olarak çözülür.</summary>
public class ConditionParameter : Entity
{
    public int ConditionId { get; set; }
    public RuleCondition Condition { get; set; } = default!;
    public string Key { get; set; } = default!;
    public string Value { get; set; } = default!;
}

/// <summary>Condition tipleri kataloğu; koddaki IConditionHandler'lardan açılışta senkronize edilir.</summary>
public class ConditionType : Entity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ConditionScope DefaultScope { get; set; }
    /// <summary>Parametre tanımları (JSON; sadece dokümantasyon/UI form üretimi).</summary>
    public string ParameterSchemaJson { get; set; } = "[]";
    public string? RequiredAttributes { get; set; }
    /// <summary>Koddaki handler'ı kalmayan tip false olur; bu tipteki condition'lar Indeterminate (fail-closed).</summary>
    public bool IsAvailable { get; set; } = true;
    /// <summary>Sadece kullanıcı attribute'larına bakar (istek bağlamı gerektirmez) → önceden hesaplanabilir.</summary>
    public bool IsSubjectOnly { get; set; }
}
