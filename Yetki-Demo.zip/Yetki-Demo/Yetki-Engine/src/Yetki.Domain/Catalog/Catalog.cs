using Yetki.Domain.Common;

namespace Yetki.Domain.Catalog;

/// <summary>Katalog tanımlarının teknik/iş sahipliğini üstlenen ekip.</summary>
public class OwnershipTeam : AuditableEntity
{
    public int TenantId { get; set; }
    public Tenants.Tenant Tenant { get; set; } = default!;
    public int? ParentId { get; set; }
    public OwnershipTeam? Parent { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
}

// ============================================================================================
//  Kaynak kataloğu ("NE / NEREDE?" ekseni)
//
//  Application (Anka, Nextral, Mobil Şube)          → sahibi bir tenant; o tenant ve alt tenant'ları kullanır
//   └ CatalogNode: Domain → Modül → Alt modül      (Path: ANKA/NAKIT/CEKIM/GISE)  = RESOURCE (korunan varlık)
//       ├ Permission     = Resource + Action (anka.nakit.cekim.gise:create)   ← RBAC bunu verir, policy bunu hedefler
//       ├ ApiResource    servis arayüzü (audience api://...)
//       │   └ ApiEndpoint  POST /v1/cash-withdrawals  → Permission (N:1)
//       └ UiElement      ekran / buton (Nextral)        → Permission (N:1)
//
//  Endpoint ≠ Permission: endpoint teknik (refactor edilir), permission iş kavramıdır (sabit kalır).
// ============================================================================================

/// <summary>Kataloğun kökü: yetkilendirilen sistem/ürün (resource server'ların sahibi).</summary>
public class CatalogApplication : AuditableEntity
{
    /// <summary>Sahip tenant. Uygulama bu tenant ve alt tenant'larında kullanılabilir.</summary>
    public int TenantId { get; set; }
    public Tenants.Tenant Tenant { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ApplicationType Type { get; set; }
    public int? OwnerTeamId { get; set; }
    public OwnershipTeam? OwnershipTeam { get; set; }
    /// <summary>Identity adapter tarafından sağlanan sorumlu user kimliği; yerel Users tablosuna FK değildir.</summary>
    public int? OwnerUserId { get; set; }
    /// <summary>Eski serbest metin alanı; migration uyumluluğu için tutulur.</summary>
    public string? OwnerTeam { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>
/// Uygulama altındaki hiyerarşi düğümü = RESOURCE (korunan varlık). Üzerinde tanımlı permission'lar resource'un action'larıdır.
/// Policy'ler ve client izinleri düğüme bağlanır, alt düğümler miras alır.
/// </summary>
public class CatalogNode : AuditableEntity
{
    public int TenantId { get; set; }
    public Tenants.Tenant Tenant { get; set; } = default!;
    public int? ApplicationId { get; set; }
    public CatalogApplication? Application { get; set; }
    public int? ParentId { get; set; }
    public CatalogNode? Parent { get; set; }
    public CatalogNodeType Type { get; set; }
    /// <summary>Kardeşler arasında tekil kod (ör. NAKIT).</summary>
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    /// <summary>Tam yol (ANKA/NAKIT/CEKIM). Ön ek (prefix) sorguları için; servis katmanı üretir.</summary>
    public string Path { get; set; } = default!;
    public int? OwnerTeamId { get; set; }
    public OwnershipTeam? OwnershipTeam { get; set; }
    /// <summary>Identity adapter tarafından sağlanan sorumlu user kimliği.</summary>
    public int? OwnerUserId { get; set; }
    public string? OwnerTeam { get; set; }
}

/// <summary>Permission = Resource (katalog düğümü) + Action. Kod hiyerarşiktir: {uygulama}.{domain}.{modül}[.{alt}]:{action}.</summary>
public class Permission : AuditableEntity
{
    public int TenantId { get; set; }
    public Tenants.Tenant Tenant { get; set; } = default!;
    public int? ApplicationId { get; set; }
    public CatalogApplication? Application { get; set; }
    public int? CatalogNodeId { get; set; }
    public CatalogNode? CatalogNode { get; set; }
    /// <summary>Boşsa katalog düğümü kapsamındadır; doluysa permission yalnızca bu endpoint operasyonuna aittir.</summary>
    public int? SourceEndpointId { get; set; }
    public ApiEndpoint? SourceEndpoint { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    /// <summary>Action: create, read, update, delete, approve, execute, cancel, export, view, print...</summary>
    public string Action { get; set; } = default!;
    public Severity RiskLevel { get; set; } = Severity.Medium;
    public bool IsActive { get; set; } = true;
}

/// <summary>Servis API'si (OpenAPI dokümanı / mikroservis). Audience: token'ın hangi API için verildiği (JWT aud).</summary>
public class ApiResource : AuditableEntity
{
    public int TenantId { get; set; }
    public Tenants.Tenant Tenant { get; set; } = default!;
    public int? ApplicationId { get; set; }
    public CatalogApplication? Application { get; set; }
    public int? CatalogNodeId { get; set; }
    public CatalogNode? CatalogNode { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string Audience { get; set; } = default!;
    public string Version { get; set; } = "v1";
    public string? BasePath { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<ApiEndpoint> Endpoints { get; set; } = new List<ApiEndpoint>();
}

/// <summary>HTTP endpoint'i. PermissionId boşsa endpoint eşlenmemiştir → karar motoru reddeder (fail-closed) ve denetimde görünür.</summary>
public class ApiEndpoint : Entity
{
    public int ApiResourceId { get; set; }
    public ApiResource ApiResource { get; set; } = default!;
    public string Method { get; set; } = default!;
    /// <summary>Path şablonu: /v1/cash-withdrawals/{id}</summary>
    public string Path { get; set; } = default!;
    public string? OperationId { get; set; }
    public string? Summary { get; set; }
    public int? PermissionId { get; set; }
    public Permission? Permission { get; set; }
}

/// <summary>İstemci ekran öğesi (ekran/menü/buton). PermissionId boşsa herkes görür; üst öğe kapalıysa alt öğeler de kapalıdır.</summary>
public class UiElement : Entity
{
    public int CatalogNodeId { get; set; }
    public CatalogNode CatalogNode { get; set; } = default!;
    public int? ParentId { get; set; }
    public UiElement? Parent { get; set; }
    public UiElementKind Kind { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public int Order { get; set; }
    public int? PermissionId { get; set; }
    public Permission? Permission { get; set; }
}
