using Yetki.Domain.Catalog;
using Yetki.Domain.Common;
using Yetki.Domain.Identity;

namespace Yetki.Domain.Governance;

// ------------------------------ Separation of Duties ------------------------------

/// <summary>Karşılıklı dışlayan üyeler: bir kullanıcı üyelerden 2+ tanesine (effective) sahipse ihlal.</summary>
public class SodRule : AuditableEntity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public Severity Severity { get; set; } = Severity.High;
    public SodEnforcement Enforcement { get; set; } = SodEnforcement.Block;
    public bool IsActive { get; set; } = true;

    public ICollection<SodRuleMember> Members { get; set; } = new List<SodRuleMember>();
}

public class SodRuleMember : Entity
{
    public int SodRuleId { get; set; }
    public SodRule SodRule { get; set; } = default!;
    public SodMemberType MemberType { get; set; }
    /// <summary>MemberType'a göre PermissionId veya RoleId.</summary>
    public int MemberId { get; set; }
}

/// <summary>Tespit edilen ihlal. Sistem yetkiyi otomatik SİLMEZ; ihlali görünür kılar.</summary>
public class SodViolation : Entity
{
    public int SodRuleId { get; set; }
    public SodRule SodRule { get; set; } = default!;
    public int UserId { get; set; }
    public User User { get; set; } = default!;
    public ViolationStatus Status { get; set; } = ViolationStatus.Open;
    public ViolationDetectionSource DetectedBy { get; set; }
    public DateTime DetectedAt { get; set; }
    public DateTime LastSeenAt { get; set; }
    public DateTime? ClosedAt { get; set; }
    public string? ClosedBy { get; set; }
    public string? Note { get; set; }
    public string Details { get; set; } = "";
}

// ------------------------------ Dış sistemler (RACF / LDAP) ------------------------------
//
//  Kimlik yayılımı (identity propagation): kullanıcı kendi mainframe token'ını CICS'e iletir → CICS'te
//  ÇAĞIRAN KULLANICININ RACF yetkisi aranır. Bu yüzden katalogdaki bir işlem yetkisi, dış sistemde de
//  kullanıcıya yetki açılmasını gerektirir.
//
//  Bağımlılık bilginin doğduğu yerde tanımlanır (ExternalDependency):
//     API        → o API'nin tüm endpoint'leri (ör. CICS bölgesi erişimi)
//     Endpoint   → sadece o endpoint (ör. GET /v1/customers/{id} → MUS1, HSP1 transaction'ları)
//     Permission → istisna / endpoint'i olmayan işlemler (ör. Nextral ekranı → LDAP grubu)
//  Zincir: ExternalPermissionRequirement (MUS1 transaction'ı BNK.MUSTERI.MASTER dataset'ini okur).
//
//  Kullanıcılar endpoint'e değil PERMISSION'a yetkilendirilir: permission'ın dış gereksinimi = eşlenen endpoint'lerin ve
//  API'lerinin bağımlılıkları ∪ doğrudan bağımlılıklar (+ zincir). Kullanıcının OLMASI GEREKEN dış durumu = etkin
//  permission'larının gereksinimlerinin birleşimi (seviye: en yüksek). Provisioning = olması gereken − RACF'e gönderilmiş durum
//  (UserExternalGrant) farkı; böylece başka bir yetkiden dolayı hâlâ gereken dış yetki geri alınmaz.

public class ExternalSystem : AuditableEntity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    /// <summary>true: erişim seviyesi var (RACF READ/UPDATE/CONTROL/ALTER). false: sadece üyelik (LDAP grubu).</summary>
    public bool HasAccessLevels { get; set; }
    public ICollection<ExternalPermission> Permissions { get; set; } = new List<ExternalPermission>();
}

/// <summary>Dış sistemdeki korunan kaynak / yetki: RACF transaction (TCICSTRN), dataset, uygulama (APPL); LDAP grubu.</summary>
public class ExternalPermission : AuditableEntity
{
    public int ExternalSystemId { get; set; }
    public ExternalSystem ExternalSystem { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string? Name { get; set; }
    /// <summary>RACF sınıfı (TCICSTRN, DATASET, APPL, FACILITY) veya LDAP için GROUP. Adaptör komutu buna göre üretir.</summary>
    public string? ResourceClass { get; set; }
    public string? Description { get; set; }

    public ICollection<ExternalPermissionRequirement> Requires { get; set; } = new List<ExternalPermissionRequirement>();
}

/// <summary>Zincir bağımlılık: bu dış yetkiyi alan kullanıcıya gerekli dış yetki de verilir (döngü reddedilir).</summary>
public class ExternalPermissionRequirement : IAssignment
{
    public int ExternalPermissionId { get; set; }
    public ExternalPermission ExternalPermission { get; set; } = default!;
    public int RequiredExternalPermissionId { get; set; }
    public ExternalPermission RequiredExternalPermission { get; set; } = default!;
    /// <summary>Boş: bağımlı olan yetkinin seviyesiyle aynı.</summary>
    public ExternalAccessLevel? AccessLevel { get; set; }
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}

/// <summary>
/// Katalog öğesi → gerektirdiği dış yetki. API, endpoint veya permission'dan TAM OLARAK BİRİ dolu.
/// AccessLevel boşsa permission'ın action'ından türetilir (read/view/export/print → READ, diğerleri → UPDATE).
/// </summary>
public class ExternalDependency : Entity, IAssignment
{
    public int? ApiResourceId { get; set; }
    public ApiResource? ApiResource { get; set; }
    public int? ApiEndpointId { get; set; }
    public ApiEndpoint? ApiEndpoint { get; set; }
    public int? PermissionId { get; set; }
    public Permission? Permission { get; set; }
    public int ExternalPermissionId { get; set; }
    public ExternalPermission ExternalPermission { get; set; } = default!;
    public ExternalAccessLevel? AccessLevel { get; set; }
    public string? Note { get; set; }
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}

/// <summary>
/// Dış sistemde kullanıcıya AÇILMIŞ (adaptörün başarıyla uyguladığı) yetki — provisioning'in "son bilinen durumu".
/// Olması gereken durumla farkı Grant / Modify / Revoke üretir; mutabakat (drift) bu tabloya göre ölçülür.
/// </summary>
public class UserExternalGrant
{
    public int UserId { get; set; }
    public User User { get; set; } = default!;
    public int ExternalPermissionId { get; set; }
    public ExternalPermission ExternalPermission { get; set; } = default!;
    public ExternalAccessLevel? AccessLevel { get; set; }
    public DateTime ProvisionedAt { get; set; }
    public string ProvisionedBy { get; set; } = "system";
}

// ------------------------------ Olaylar / provisioning / audit ------------------------------

/// <summary>Transactional outbox: yönetim değişikliğiyle aynı iş biriminde yazılır, arka planda tüketilir.</summary>
public class OutboxEvent
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string EventType { get; set; } = default!;
    public string? AggregateType { get; set; }
    public string? AggregateId { get; set; }
    public string PayloadJson { get; set; } = "{}";
    public DateTime OccurredAt { get; set; }
    public string Actor { get; set; } = "system";
    public OutboxStatus Status { get; set; } = OutboxStatus.Pending;
    public int Attempts { get; set; }
    public DateTime? ProcessedAt { get; set; }
    public string? Error { get; set; }
}

public class ProvisioningAction : Entity
{
    public Guid OutboxEventId { get; set; }
    public int UserId { get; set; }
    public string UserName { get; set; } = default!;
    /// <summary>Gerekçe: hangi permission / endpoint / API yüzünden (ör. "anka.musteri.bilgi.profil:read ← GET musteri-api/v1/customers/{id}").</summary>
    public string PermissionCode { get; set; } = default!;
    public string ExternalSystemCode { get; set; } = default!;
    public string ExternalPermissionCode { get; set; } = default!;
    public string? ResourceClass { get; set; }
    public ProvisioningActionType ActionType { get; set; }
    public ExternalAccessLevel? AccessLevel { get; set; }
    public ExternalAccessLevel? PreviousAccessLevel { get; set; }
    public ProvisioningStatus Status { get; set; } = ProvisioningStatus.Pending;
    public string? AdapterName { get; set; }
    public string? ResultMessage { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
}

/// <summary>Tek audit tablosu: kararlar + yönetim değişiklikleri + simülasyon/tarama. Karar kayıtlarında Id = DecisionId.</summary>
public class AuditLog
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTime Timestamp { get; set; }
    public AuditCategory Category { get; set; }
    public string Actor { get; set; } = "system";
    public string Action { get; set; } = default!;
    public string? EntityType { get; set; }
    public string? EntityId { get; set; }
    public string? SubjectUserName { get; set; }
    public string? ClientId { get; set; }
    public string? PermissionCode { get; set; }
    public string? Resource { get; set; }
    public string? Decision { get; set; }
    public string? ReasonCode { get; set; }
    public string? Summary { get; set; }
    public string? DetailsJson { get; set; }
    public string? CorrelationId { get; set; }
}
