namespace Yetki.Domain.Common;

/// <summary>Tüm kalıcı varlıkların tabanı. Int identity anahtar SQL Server'a birebir taşınır.</summary>
public abstract class Entity
{
    public int Id { get; set; }
}

/// <summary>Yönetim ekranlarından değiştirilen varlıklar için izlenebilirlik alanları (DbContext otomatik doldurur).</summary>
public abstract class AuditableEntity : Entity
{
    public DateTime CreatedAt { get; set; }
    public string CreatedBy { get; set; } = "system";
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

/// <summary>Atama (ilişki) tabloları için ortak alanlar.</summary>
public interface IAssignment
{
    DateTime AssignedAt { get; set; }
    string AssignedBy { get; set; }
}

// ------------------------------ Tenant ------------------------------

public enum TenantType { Bank = 1, Subsidiary = 2 }

public enum OrgUnitType { HeadOffice = 1, Department = 2, Region = 3, Branch = 4 }

public enum UserKind { Person = 1, ServiceAccount = 2 }

// ------------------------------ Katalog ------------------------------

/// <summary>Kataloğun kökü olan sistemin türü.</summary>
public enum ApplicationType { ApiPlatform = 1, Desktop = 2, Mobile = 3, Web = 4, Batch = 5 }

/// <summary>Uygulama altındaki hiyerarşi seviyesi: Domain → Modül → Alt modül.</summary>
public enum CatalogNodeType { Domain = 1, Module = 2, SubModule = 3, Level = 4 }

/// <summary>Masaüstü/web ekran öğesi (Nextral gibi istemcilerde buton aç/kapa için).</summary>
public enum UiElementKind { Screen = 1, Menu = 2, Tab = 3, Button = 4, Field = 5 }

/// <summary>
/// OAuth 2.0 client türü (RFC 6749): gizli anahtar tutabilen / tutamayan / servis (client credentials) /
/// ARACI (gateway, BFF, kullanıcı adına başka API çağıran servis — RFC 8693 "act"). Aracı isteği BAŞLATMAZ:
/// karar orijinal client'a (azp) göre verilir, aracı zinciri (via) ayrıca doğrulanır ve audit'e yazılır.
/// </summary>
public enum ClientType { Confidential = 1, Public = 2, Service = 3, Intermediary = 4 }

/// <summary>Yükümlülüğün hangi kararda PEP'e döneceği (XACML FulfillOn).</summary>
public enum ObligationFulfillOn { Permit = 1, Deny = 2 }

// ------------------------------ Hedefleme ------------------------------

/// <summary>Policy hedefi / client izni neyi kapsar? Katalog düğümü hedefi, altındaki her şeyi kapsar (miras).</summary>
public enum TargetType { All = 1, Application = 2, CatalogNode = 3, Permission = 4 }

public enum InclusionMode { Include = 1, Exclude = 2 }

// ------------------------------ Policy ------------------------------

/// <summary>Enforce: karara katılır. ReportOnly: değerlendirilir ve kaydedilir ama kararı etkilemez (güvenli devreye alma).</summary>
public enum PolicyMode { Enforce = 1, ReportOnly = 2 }

/// <summary>Condition tipinin kapsamı: ortak (mesai, IP, kanal) veya iş alanına özel.</summary>
public enum ConditionScope { Global = 1, Domain = 2 }

/// <summary>
/// Policy'nin karar stratejisi: rule sonuçları (sağlandı / sağlanmadı / belirsiz) tek policy sonucuna nasıl indirgenir?
/// Rule = sağlanması gereken tek koşul (saat 09-18, tutar ≤ limit, IP şube ağında...).
/// </summary>
public enum CombiningAlgorithm
{
    /// <summary>Tüm rule'lar sağlanmalı (AND). Biri sağlanmazsa Deny; biri belirsizse Indeterminate; hepsi sağlanırsa Permit.</summary>
    AllRulesMustPass = 1,
    /// <summary>En az bir rule sağlanmalı (OR). Biri sağlanırsa Permit; yoksa belirsizlik → Indeterminate; hiçbiri sağlanmazsa Deny.</summary>
    AnyRuleMustPass = 2
}

/// <summary>Condition ağacı düğüm tipi.</summary>
public enum ConditionKind { Predicate = 1, AllOf = 2, AnyOf = 3, Not = 4, Reference = 5 }

// ------------------------------ SoD / olaylar / audit ------------------------------

public enum SodMemberType { Permission = 1, Role = 2 }

/// <summary>Block: atama engellenir. Warn: atama yapılır, ihlal kaydı açılır ve uyarı döner.</summary>
public enum SodEnforcement { Warn = 1, Block = 2 }

public enum Severity { Low = 1, Medium = 2, High = 3, Critical = 4 }

public enum ViolationStatus { Open = 1, Acknowledged = 2, AcceptedRisk = 3, Resolved = 4 }

public enum ViolationDetectionSource { AssignmentCheck = 1, RetrospectiveScan = 2 }

public enum OutboxStatus { Pending = 1, Processed = 2, Failed = 3 }

/// <summary>Grant: dış yetki ver · Revoke: geri al · Modify: erişim seviyesini değiştir (ör. READ → UPDATE).</summary>
public enum ProvisioningActionType { Grant = 1, Revoke = 2, Modify = 3 }

/// <summary>
/// Dış sistemdeki erişim seviyesi (RACF PERMIT ACCESS). Sıralıdır: büyük seviye küçüğü kapsar.
/// Seviyesi olmayan sistemlerde (LDAP grup üyeliği) kullanılmaz (null).
/// </summary>
public enum ExternalAccessLevel { Read = 1, Update = 2, Control = 3, Alter = 4 }

public enum ProvisioningStatus { Pending = 1, Completed = 2, Failed = 3 }

public enum AuditCategory { AuthorizationDecision = 1, Management = 2, Simulation = 3, SodScan = 4 }
