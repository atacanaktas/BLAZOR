using Yetki.Domain.Catalog;
using Yetki.Domain.Common;
using Yetki.Domain.Identity;

namespace Yetki.Domain.Clients;

/// <summary>
/// OAuth 2.0 client: isteği gönderen UYGULAMA (Nextral masaüstü, mobil şube tableti, gateway, batch job).
/// Etkin yetki = kullanıcının yetkisi ∩ client'ın izinleri. Böylece "EFT sadece şube uygulamasından" gibi kurallar
/// kullanıcıların rolleriyle oynamadan uygulanır.
/// </summary>
public class Client : AuditableEntity
{
    /// <summary>Client'ı kaydeden tenant. Client bu tenant ve alt tenant'larının isteklerinde kullanılabilir.</summary>
    public int TenantId { get; set; }
    public Tenants.Tenant Tenant { get; set; } = default!;
    /// <summary>Kimlik sağlayıcıdaki client_id (ör. nextral-desktop).</summary>
    public string ClientId { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ClientType Type { get; set; }
    /// <summary>Client'ın ait olduğu uygulama (bilgi/sahiplik).</summary>
    public int? ApplicationId { get; set; }
    public CatalogApplication? Application { get; set; }
    /// <summary>Service tipi client'lar (client credentials) bu servis hesabının kimliğiyle yetkilendirilir.</summary>
    public int? ServiceAccountUserId { get; set; }
    public User? ServiceAccountUser { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<ClientPermissionGrant> AllowedPermissions { get; set; } = new List<ClientPermissionGrant>();
}

/// <summary>
/// Client kaydında önceden izin verilen Permission kapsamı (registered/pre-authorized client permissions).
/// Access token'a gerçekten verilmiş OAuth scope'lar runtime isteğinde ayrıca doğrulanır.
/// Hedef düğüm altındaki her şeyi kapsar. Actions doluysa sadece bu eylemler (ör. "read,view").
/// </summary>
public class ClientPermissionGrant : Entity
{
    public int ClientId { get; set; }
    public Client Client { get; set; } = default!;
    public TargetType TargetType { get; set; }
    public int? ApplicationId { get; set; }
    public CatalogApplication? Application { get; set; }
    public int? CatalogNodeId { get; set; }
    public CatalogNode? CatalogNode { get; set; }
    public int? PermissionId { get; set; }
    public Permission? Permission { get; set; }
    /// <summary>Virgülle ayrılmış eylem listesi; boş = tüm eylemler.</summary>
    public string? Actions { get; set; }
}
