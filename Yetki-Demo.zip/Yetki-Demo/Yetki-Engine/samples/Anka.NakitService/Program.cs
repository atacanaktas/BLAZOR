using Yetki.Sdk;

// Anka platformundaki örnek mikroservis: Gişe Nakit Çekim API'si (katalog: ANKA/NAKIT/CEKIM/GISE).
// İş kodunda hiçbir yetki if'i yoktur: endpoint'ler [RequiresPermission] ile, iş bağlamı DTO'da [AuthContext] ile işaretlenir.
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddYetkiAuthorization(o =>
{
    o.EngineBaseUrl = builder.Configuration["Yetki:EngineBaseUrl"] ?? "http://localhost:5100";
    o.Application = "ANKA";
    o.CatalogPath = "NAKIT/CEKIM/GISE";
    o.ApiCode = "nakit-cekim-gise-api";
    o.ApiName = "Gişe Nakit Çekim API";
    o.Audience = "api://anka/nakit-cekim-gise-api";
    // Tüm endpoint'ler Nakit CICS bölgesine bağlanır (kullanıcının kendi RACF kimliğiyle)
    o.ApiExternalDependencies.Add(new RequiresExternalAttribute("RACF", "CICSNKT") { ResourceClass = "APPL", Name = "Nakit CICS bölgesi", Access = ExternalAccess.Read });
    o.AllowDemoHeaders = true; // PROTOTİP: X-User / X-Client-Id. Üretimde token'dan (sub, azp).
});
builder.Services.AddCors(o => o.AddDefaultPolicy(p => p.WithOrigins("http://localhost:5180", "http://127.0.0.1:5180").AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();
app.UseCors();
app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();
app.MapYetkiManifest();
app.MapGet("/", () => Results.Redirect("/swagger")).ExcludeFromDescription();
app.Run();
