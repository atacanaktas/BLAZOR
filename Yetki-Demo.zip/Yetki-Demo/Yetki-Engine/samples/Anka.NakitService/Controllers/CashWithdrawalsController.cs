using Microsoft.AspNetCore.Mvc;
using Yetki.Sdk;

namespace Anka.NakitService.Controllers;

/// <summary>Çekim isteği. Property adları iş ekibine aittir; yetki bağlamı [AuthContext] ile semantik olarak işaretlenir.</summary>
public sealed class CashWithdrawalRequest
{
    [AuthContext(AuthContextType.AccountNo)] public string HesapNo { get; set; } = default!;
    [AuthContext(AuthContextType.CustomerId)] public string MusteriNo { get; set; } = default!;
    [AuthContext(AuthContextType.TransactionAmount)] public decimal Tutar { get; set; }
    [AuthContext(AuthContextType.Currency)] public string ParaBirimi { get; set; } = "TRY";
    [AuthContext(AuthContextType.BranchCode)] public string? SubeKodu { get; set; }
    public string? Aciklama { get; set; }
}

[ApiController]
[Route("v1/cash-withdrawals")]
public sealed class CashWithdrawalsController : ControllerBase
{
    [HttpPost]
    [RequiresPermission("anka.nakit.cekim.gise:create", ResourceType = "account", Name = "Gişeden para çekme")]
    [RequiresExternal("RACF", "NKC1", ResourceClass = "TCICSTRN", Name = "Nakit çekim transaction")]
    public IActionResult Create(CashWithdrawalRequest request) => Ok(new
    {
        id = Guid.NewGuid(),
        status = "COMPLETED",
        message = $"{request.HesapNo} hesabından {request.Tutar:N2} {request.ParaBirimi} çekildi.",
        authorization = HttpContext.GetAuthorizationDecisions().Select(d => new { d.DecisionId, d.Decision, d.ReasonCode, d.Permission, d.Client })
    });

    [HttpGet("{id}")]
    [RequiresPermission("anka.nakit.cekim.gise:read", Name = "Çekim sorgulama")]
    [RequiresExternal("RACF", "NKS1", ResourceClass = "TCICSTRN", Name = "Nakit çekim sorgu transaction")]
    // Hassas alanlar: kanal policy'si yükümlülük döndürürse (ör. Anka Web → MASK_FIELDS) SDK yanıtı maskeler
    public IActionResult Get(string id) => Ok(new
    {
        id, status = "COMPLETED", amount = 20000, hesapNo = "TR120006200001234567890123", musteriTckn = "12345678901", musteriAdi = "Deniz Yıldız"
    });

    [HttpPost("{id}/cancel")]
    [RequiresPermission("anka.nakit.cekim.gise:cancel", Name = "Çekim iptali")]
    [RequiresExternal("RACF", "NKI1", ResourceClass = "TCICSTRN", Name = "Nakit çekim iptal transaction")]
    public IActionResult Cancel(string id) => Ok(new { id, status = "CANCELLED" });

    /// <summary>Kasıtlı olarak [RequiresPermission] YOK: manifest'te "eşlenmemiş endpoint" bulgusu olarak görünür.</summary>
    [HttpGet("{id}/receipt")]
    public IActionResult Receipt(string id) => Ok(new { id, receipt = "DEKONT" });
}

[ApiController]
[Route("health")]
[AllowWithoutPermission]
public sealed class HealthController : ControllerBase
{
    [HttpGet]
    public IActionResult Get() => Ok(new { status = "ok" });
}
