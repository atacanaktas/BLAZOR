using Microsoft.AspNetCore.Mvc;
using Yetki.Sdk;

namespace Anka.NakitService.Controllers;

/// <summary>
/// Vadeli hesap işlemleri/izleme (katalog: ANKA_API/MV/VDL, API'ler: vadelihesapislemleri,
/// vadelihesapizleme). Aynı örnek mikroservis içinde ikinci bir iş alanı olarak eklendi;
/// [RequiresPermission] motoru doğrudan permission koduyla çağırır, bu servisin kendi
/// AddYetkiAuthorization Application/CatalogPath ayarından bağımsızdır.
/// </summary>
public sealed class CloseDepositAccountRequest
{
    public string? Aciklama { get; set; }
}

[ApiController]
[Route("vadeli-hesap-kapatma")]
public sealed class DepositAccountClosureController : ControllerBase
{
    [HttpPost("{hesapNo}")]
    [RequiresPermission("anka_api.mv.vdl.vadelihesapislemleri.closedepositaccound:close", ResourceType = "account", Name = "Vadeli hesap kapatma")]
    public IActionResult Close([AuthContext(AuthContextType.AccountNo)] string hesapNo, [FromBody] CloseDepositAccountRequest? request) => Ok(new
    {
        hesapNo,
        status = "CLOSED",
        message = $"{hesapNo} numaralı vadeli hesap kapatıldı.",
        authorization = HttpContext.GetAuthorizationDecisions().Select(d => new { d.DecisionId, d.Decision, d.ReasonCode, d.Permission, d.DecidingPolicy, d.DecidingRule })
    });
}

[ApiController]
[Route("vadeli-hesap-izle")]
public sealed class DepositAccountInquiryController : ControllerBase
{
    [HttpGet("{mustNo}")]
    [RequiresPermission("anka_api.mv.vdl.vadelihesapizleme.getdepositaccound:read", Name = "Vadeli hesap izleme")]
    // MESAI_SAATLERI policy'si bu permission'ı hedefliyor: mesai saatleri (hafta içi 09:00-18:00, Europe/Istanbul) dışında DENY döner.
    public IActionResult List([AuthContext(AuthContextType.CustomerId)] string mustNo) => Ok(new
    {
        mustNo,
        accounts = new[]
        {
            new { hesapNo = "TR120006200001234567890111", principal = 500000m, currency = "TRY", termMonths = 6, maturityDate = "2027-03-29" },
            new { hesapNo = "TR120006200001234567890222", principal = 1250000m, currency = "TRY", termMonths = 12, maturityDate = "2027-09-29" }
        },
        authorization = HttpContext.GetAuthorizationDecisions().Select(d => new { d.DecisionId, d.Decision, d.ReasonCode, d.Permission, d.DecidingPolicy, d.DecidingRule })
    });
}
