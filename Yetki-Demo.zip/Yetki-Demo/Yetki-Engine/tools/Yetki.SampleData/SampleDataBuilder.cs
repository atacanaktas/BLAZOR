using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Common;
using Yetki.Domain.Catalog;
using Yetki.Domain.Clients;
using Yetki.Domain.Common;
using Yetki.Domain.Governance;
using Yetki.Domain.Groups;
using Yetki.Domain.Identity;
using Yetki.Domain.Tenants;
using Yetki.Domain.Policies;
using Yetki.Domain.Rbac;
using Yetki.Infrastructure.Persistence;

namespace Yetki.SampleData;

/// <summary>
/// ÖRNEK (sade demo) veri — uygulama kodunda DEĞİL, sadece bu araçta. yedek.db bu sınıfla üretilir; testler de kullanır.
/// Senaryolar (PROJE-NOTLARI.md §10):
///  - Tenant: A Bankası → B İştiraki (policy, uygulama, client ve miras alınabilir rol mirası; tenant izolasyonu)
///  - Katalog (resource): ANKA (API platformu), NEXTRAL (masaüstü ekran/buton), MOBIL_SUBE (mobil API) → ABANK'ın;
///    B_PORTAL (yatırımcı portalı) → BISTIRAK'ın (A Bankası kullanıcıları erişemez)
///  - Client'lar (isteği başlatan kanal): nextral-desktop, anka-web, mobil-sube-tablet, eod-batch (servis), yetki-konsol (ABANK); b-portal-web (BISTIRAK)
///    Aracı: anka-gateway (Intermediary) — kullanıcı token'ını iletir, orijinal client (azp) korunur; "via" zincirinde doğrulanır
///  - Kanal (client) hedefli policy'ler + yükümlülükler: MOBIL_KANAL (sadece mobil: cihaz + maskele + limit + KVKK log), WEB_KANAL_MASKE
///  - Filtreli gruplar: "101'deki gişe asistanları (stajyer hariç)", "tüm personel", "İstanbul bölgesi şube müdürleri", vekalet
///  - Policy → Rule (sağlanması gereken koşul): kurumsal ağ, izinde değil, nakit mesai (ATM hariç), çekim limiti, EFT, kredi onay,
///    veri kapsamı, mobil cihaz, ReportOnly rapor mesaisi, B İştiraki mesaisi
///  - Dokümandaki örnek: ahmet.kaya (Gişe Yetkilisi) → ANKA/NAKIT/CEKIM/GISE : create (para çekme), limit 100.000
/// </summary>
public sealed class SampleDataBuilder(YetkiDbContext db, IClock clock)
{
    private readonly Dictionary<string, Permission> _perms = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, CatalogNode> _nodes = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, ApiResource> _apis = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, OwnershipTeam> _ownershipTeams = new(StringComparer.OrdinalIgnoreCase);
    private Dictionary<string, ConditionType> _types = new();

    public async Task BuildAsync()
    {
        if (await db.Tenants.AnyAsync()) throw new InvalidOperationException("Veritabanı boş değil; örnek veri sadece boş veritabanına yazılır.");
        _types = await db.ConditionTypes.ToDictionaryAsync(t => t.Code, StringComparer.OrdinalIgnoreCase);
        var now = clock.UtcNow;

        // ================================ Kurum ================================
        var abank = new Tenant { Code = "ABANK", Name = "A Bankası", Type = TenantType.Bank };
        var bIstirak = new Tenant { Code = "BISTIRAK", Name = "B İştiraki (A Bankası)", Type = TenantType.Subsidiary, Parent = abank };
        db.Tenants.AddRange(abank, bIstirak);

        OrgUnit Unit(Tenant tenant, OrgUnit? parent, string code, string name, OrgUnitType type)
        {
            var u = new OrgUnit { Tenant = tenant, Parent = parent, Code = code, Name = name, Type = type };
            db.OrgUnits.Add(u);
            return u;
        }
        var gm = Unit(abank, null, "GM", "Genel Müdürlük", OrgUnitType.HeadOffice);
        var u928 = Unit(abank, gm, "928", "Operasyon Daire Başkanlığı", OrgUnitType.Department);
        var u850 = Unit(abank, gm, "850", "Krediler Daire Başkanlığı", OrgUnitType.Department);
        var ist = Unit(abank, gm, "BLG_IST", "İstanbul Bölge Müdürlüğü", OrgUnitType.Region);
        var u1114 = Unit(abank, ist, "1114", "Kadıköy Şubesi", OrgUnitType.Branch);
        var u737 = Unit(abank, ist, "737", "Beşiktaş Şubesi", OrgUnitType.Branch);
        var u101 = Unit(abank, ist, "101", "Merkez Şube", OrgUnitType.Branch);
        var bGm = Unit(bIstirak, null, "B_GM", "B İştiraki Genel Müdürlük", OrgUnitType.HeadOffice);
        var bOps = Unit(bIstirak, bGm, "B_OPS", "B Operasyon", OrgUnitType.Department);
        var b01 = Unit(bIstirak, bGm, "B_01", "B Levent Şube", OrgUnitType.Branch);

        // ================================ Katalog ================================
        // Uygulamalar ABANK'ın → ABANK ve alt tenant'ı BISTIRAK kullanabilir. B_PORTAL BISTIRAK'ın → sadece BISTIRAK.
        var anka = App(abank, "ANKA", "Anka Mikroservis Platformu", ApplicationType.ApiPlatform, "Core banking mikroservisleri (200+ API)", "Platform Ekibi");
        var nextral = App(abank, "NEXTRAL", "Nextral Şube Masaüstü", ApplicationType.Desktop, ".NET WinForms şube uygulaması; Anka API'lerini çağırır, buton/menü yetkisi yerel", "Şube Kanalı Ekibi");
        var mobil = App(abank, "MOBIL_SUBE", "Mobil Şube", ApplicationType.Mobile, "Şube personelinin tabletle sahada kullandığı mobil API'ler", "Dijital Kanal Ekibi");
        var bPortal = App(bIstirak, "B_PORTAL", "B Yatırımcı Portalı", ApplicationType.Web, "Sadece B İştiraki'nin uygulaması (tenant izolasyonu örneği)", "B İştiraki BT");

        SeedAnka(anka);
        SeedYatirim(anka);
        SeedMobile(mobil);
        SeedNextral(nextral);
        SeedBPortal(bPortal);
        await db.SaveChangesAsync();

        // ================================ Roller ================================
        Role Role(Tenant tenant, string code, string name, bool inheritable, params string[] perms)
        {
            var r = new Role { Tenant = tenant, Code = code, Name = name, IsInheritable = inheritable };
            foreach (var p in perms.Distinct()) r.Permissions.Add(new RolePermission { Permission = P(p) });
            db.Roles.Add(r);
            return r;
        }

        string[] giseAst =
        [
            "anka.nakit.cekim.gise:create", "anka.nakit.cekim.gise:read", "anka.nakit.yatirma.gise:create", "anka.nakit.yatirma.gise:read",
            "anka.musteri.bilgi.profil:read", "anka.hesap.vadesiz:read", "anka.hesap.vadeli:read",
            "nextral.gise.nakit_ekran:view", "nextral.gise.nakit_ekran:print", "nextral.gise.hesap_ekran:view"
        ];
        string[] giseYtk =
        [
            .. giseAst, "anka.nakit.cekim.gise:cancel", "anka.nakit.kasa.gun_sonu:execute", "anka.nakit.kasa.gun_sonu:read",
            "anka.odeme.eft.giden:create", "anka.odeme.eft.giden:read", "anka.odeme.eft.giden:cancel", "anka.odeme.fast.giden:create",
            "anka.odeme.fast.giden:read", "anka.odeme.havale.hesaplar_arasi:create", "anka.odeme.havale.hesaplar_arasi:read",
            "anka.hesap.vadeli:create", "anka.hesap.vadeli:close", "nextral.gise.odeme_ekran:view"
        ];
        string[] bryslAst =
        [
            "anka.musteri.bilgi.profil:read", "anka.musteri.bilgi.profil:update", "anka.musteri.kyc.belge:read", "anka.musteri.kyc.belge:update",
            "anka.hesap.vadesiz:create", "anka.hesap.vadesiz:read", "anka.hesap.vadeli:create", "anka.hesap.vadeli:read",
            "anka.kredi.basvuru.bireysel:create", "anka.kredi.basvuru.bireysel:read", "nextral.gise.hesap_ekran:view", "nextral.kredi.kredi_ekran:view",
            "mobil_sube.musteri.onboarding.kimlik:create", "mobil_sube.musteri.onboarding.kimlik:read", "mobil_sube.musteri.onboarding.hesap_acilis:create",
            "mobil_sube.musteri.randevu.sube_randevu:create", "mobil_sube.musteri.randevu.sube_randevu:read"
        ];
        string[] ticriAst =
        [
            "anka.musteri.bilgi.profil:read", "anka.kredi.basvuru.bireysel:create", "anka.kredi.basvuru.bireysel:read", "anka.odeme.eft.giden:read",
            "nextral.kredi.kredi_ekran:view"
        ];

        var personel = Role(abank, "PERSONEL", "Tüm personel (temel)", true, "nextral.genel.duyuru:view");
        var rGiseAst = Role(abank, "GISEAST", "Gişe Asistanı", false, giseAst);
        var rGiseYtk = Role(abank, "GISEYTK", "Gişe Yetkilisi", false, giseYtk);
        var rBryslAst = Role(abank, "BRYSLAST", "Bireysel Portföy Asistanı", false, bryslAst);
        var rBryslYtk = Role(abank, "BRYSLYTK", "Bireysel Portföy Yetkilisi", false,
            [.. bryslAst, "anka.kredi.onay.dosya:read", "anka.hesap.vadeli:close", "anka.odeme.havale.hesaplar_arasi:create"]);
        var rTicriAst = Role(abank, "TICRIAST", "Ticari Portföy Asistanı", false, ticriAst);
        var rTicriYtk = Role(abank, "TICRIYTK", "Ticari Portföy Yetkilisi", false,
            [.. ticriAst, "anka.kredi.onay.dosya:approve", "anka.kredi.onay.dosya:read", "anka.kredi.kullandirim.dosya:execute", "anka.odeme.eft.giden:create"]);
        var rSubeMdr = Role(abank, "SUBEMDR", "Şube Müdürü", false,
            "anka.rapor.sube.gunluk:read", "anka.rapor.sube.gunluk:export", "anka.kredi.onay.dosya:approve", "anka.kredi.onay.dosya:read",
            "anka.nakit.cekim.gise:cancel", "anka.nakit.cekim.gise:read", "anka.nakit.kasa.gun_sonu:read", "anka.odeme.eft.giden:cancel",
            "anka.odeme.eft.giden:read", "anka.musteri.bilgi.profil:read", "nextral.gise.nakit_ekran:view", "nextral.gise.odeme_ekran:view",
            "nextral.gise.hesap_ekran:view", "nextral.kredi.kredi_ekran:view", "nextral.genel.rapor_ekran:view");
        var rBolge = Role(abank, "BOLGE_MDR", "Bölge Müdürü", false,
            "anka.rapor.sube.gunluk:read", "anka.rapor.sube.gunluk:export", "anka.musteri.bilgi.profil:read", "nextral.genel.rapor_ekran:view");

        var r928Uzm = Role(abank, "GM928UZM", "GM 928 Uzman", false, ["anka.rapor.gm.operasyon:read", "anka.odeme.eft.gelen:read"]);
        var r928Ytk = Role(abank, "GM928UZYTK", "GM 928 Uzman Yetkili", false,
            ["anka.rapor.gm.operasyon:read", "anka.odeme.eft.gelen:read", "anka.odeme.eft.giden:cancel", "anka.odeme.eft.giden:read"]);
        var r928Mgr = Role(abank, "GM928UZMYR", "GM 928 Uzman Yönetici", false,
            ["anka.rapor.gm.operasyon:read", "anka.rapor.gm.operasyon:export", "anka.odeme.eft.gelen:read", "anka.nakit.kasa.gun_sonu:read"]);
        var r850Uzm = Role(abank, "GM850UZM", "GM 850 Uzman", false, "anka.kredi.basvuru.bireysel:read", "anka.kredi.onay.dosya:read");
        var r850Ytk = Role(abank, "GM850UZYTK", "GM 850 Uzman Yetkili", false, "anka.kredi.basvuru.bireysel:read", "anka.kredi.onay.dosya:read", "anka.kredi.onay.dosya:approve");
        var r850Mgr = Role(abank, "GM850UZMYR", "GM 850 Uzman Yönetici", false,
            "anka.kredi.onay.dosya:approve", "anka.kredi.onay.dosya:read", "anka.rapor.gm.operasyon:read");
        var rBatch = Role(abank, "BATCH_RAPOR", "Gün sonu / rapor batch servisi", false,
            "anka.rapor.sube.gunluk:read", "anka.rapor.sube.gunluk:export", "anka.rapor.gm.operasyon:read", "anka.rapor.gm.operasyon:export", "anka.nakit.kasa.gun_sonu:execute");
        var rBOps = Role(bIstirak, "B_OPERASYON", "B İştiraki Operasyon", false,
            "anka.yatirim.fon.alim_satim:create", "anka.yatirim.fon.alim_satim:read", "anka.yatirim.hisse.emir:read", "b_portal.yatirimci.rapor.portfoy:read");
        var rBPortfoy = Role(bIstirak, "B_PORTFOY", "B İştiraki Portföy Yöneticisi", false,
            "anka.yatirim.fon.alim_satim:read", "anka.yatirim.hisse.emir:create", "anka.yatirim.hisse.emir:read",
            "b_portal.yatirimci.rapor.portfoy:read", "b_portal.yatirimci.rapor.portfoy:export");
        await db.SaveChangesAsync();

        // ================================ Kullanıcılar ================================
        User UserOf(Tenant tenant, OrgUnit unit, string userName, string fullName, string title, Role? role, decimal limit = 0,
            string? customerNo = null, bool onLeave = false, UserKind kind = UserKind.Person)
        {
            var u = new User
            {
                Tenant = tenant, UserName = userName, FullName = fullName, Title = title, Kind = kind, IsOnLeave = onLeave,
                CashWithdrawalLimit = limit, CustomerNo = customerNo, Email = kind == UserKind.Person ? $"{userName}@abank.com.tr" : null,
                EmployeeNo = kind == UserKind.Person ? $"P{10000 + db.ChangeTracker.Entries<User>().Count()}" : null
            };
            u.OrgUnits.Add(new UserOrgUnit { OrgUnit = unit, IsPrimary = true });
            db.Users.Add(u);
            if (role is not null) db.UserRoles.Add(new UserRole { User = u, Role = role });
            return u;
        }

        UserOf(abank, u101, "ayse.yilmaz", "Ayşe Yılmaz", "Gişe Asistanı", rGiseAst, 50_000, "C-1001");
        UserOf(abank, u101, "mert.kaya", "Mert Kaya", "Stajyer Gişe Asistanı", rGiseAst, 10_000);
        UserOf(abank, u101, "zeynep.acar", "Zeynep Acar", "Gişe Yetkilisi", rGiseYtk, 250_000);
        UserOf(abank, u101, "ali.demir", "Ali Demir", "Şube Müdürü", rSubeMdr, 500_000);
        UserOf(abank, u101, "elif.sahin", "Elif Şahin", "Bireysel Portföy Asistanı", rBryslAst);
        UserOf(abank, u101, "can.ozturk", "Can Öztürk", "Bireysel Portföy Yetkilisi", rBryslYtk, 0, "C-2002");
        UserOf(abank, u101, "selin.aydin", "Selin Aydın", "Gişe Yetkilisi", rGiseYtk, 250_000, onLeave: true);
        UserOf(abank, u101, "hakan.tekin", "Hakan Tekin", "Ticari Portföy Yetkilisi", rTicriYtk);
        UserOf(abank, u101, "ahmet.kaya", "Ahmet Kaya", "Gişe Yetkilisi", rGiseYtk, 100_000, "C-3003");
        UserOf(abank, u737, "deniz.koc", "Deniz Koç", "Gişe Asistanı", rGiseAst, 50_000);
        var burak = UserOf(abank, u737, "burak.arslan", "Burak Arslan", "Bireysel Portföy Yetkilisi", rBryslYtk);
        UserOf(abank, u737, "emre.yildiz", "Emre Yıldız", "Şube Müdürü", rSubeMdr, 500_000);
        UserOf(abank, u1114, "fatma.celik", "Fatma Çelik", "Gişe Asistanı", rGiseAst, 50_000);
        UserOf(abank, u1114, "kemal.sari", "Kemal Sarı", "Şube Müdürü", rSubeMdr, 500_000);
        UserOf(abank, u1114, "okan.polat", "Okan Polat", "Ticari Portföy Asistanı", rTicriAst);
        UserOf(abank, ist, "murat.aksoy", "Murat Aksoy", "Bölge Müdürü", rBolge);
        UserOf(abank, u928, "gul.yuce", "Gül Yüce", "Uzman Yetkili", r928Ytk);
        UserOf(abank, u928, "tolga.kurt", "Tolga Kurt", "Uzman", r928Uzm);
        UserOf(abank, u928, "nazan.er", "Nazan Er", "Uzman Yönetici", r928Mgr);
        UserOf(abank, u850, "sibel.ates", "Sibel Ateş", "Uzman Yetkili", r850Ytk);
        UserOf(abank, u850, "levent.oz", "Levent Öz", "Uzman", r850Uzm);
        UserOf(abank, u850, "derya.gok", "Derya Gök", "Uzman Yönetici", r850Mgr);
        var svc = UserOf(abank, gm, "svc.eod-batch", "Gün Sonu Batch Servisi", "Servis Hesabı", rBatch, kind: UserKind.ServiceAccount);
        UserOf(bIstirak, b01, "berk.yaman", "Berk Yaman", "Operasyon Uzmanı", rBOps);
        UserOf(bIstirak, bOps, "nil.sezer", "Nil Sezer", "Portföy Yöneticisi", rBPortfoy);

        await db.SaveChangesAsync();

        // ================================ Gruplar (kitle kuralı + yetki) ================================
        Group GroupOf(Tenant tenant, string code, string name, string description)
        {
            var g = new Group { Tenant = tenant, Code = code, Name = name, Description = description };
            db.Groups.Add(g);
            return g;
        }
        GroupFilter Filter(Group g, InclusionMode mode, string description, params (string Attr, string[] Values)[] criteria)
        {
            var f = new GroupFilter
            {
                Group = g, Mode = mode, Order = g.Filters.Count, Description = description,
                Criteria = criteria.Select((c, i) => new GroupFilterCriterion
                {
                    Attribute = c.Attr, Order = i, Values = c.Values.Select(v => new GroupFilterValue { Value = v }).ToList()
                }).ToList()
            };
            g.Filters.Add(f);
            return f;
        }

        var g101 = GroupOf(abank, "GISE_101_AST", "101 Şube Gişe Asistanları", "Sadece 101 Merkez Şube'deki gişe asistanları; stajyerler hariç. Kampanyalı vadeli açabilir.");
        Filter(g101, InclusionMode.Include, "101'deki gişe asistanları", ("ROLE", ["GISEAST"]), ("ORG_UNIT", ["101"]));
        Filter(g101, InclusionMode.Exclude, "Stajyerler hariç", ("TITLE", ["Stajyer Gişe Asistanı"]));
        g101.Permissions.Add(new GroupPermission { Permission = P("anka.hesap.vadeli.kampanya:create") });

        var gAll = GroupOf(abank, "TUM_PERSONEL", "Tüm Personel", "A Bankası ve alt kurumlarındaki tüm kişiler (servis hesapları hariç) → PERSONEL rolü.");
        Filter(gAll, InclusionMode.Include, "Kişi ve A Bankası (alt tenant dahil)", ("USER_KIND", ["Person"]), ("TENANT", ["ABANK"]));
        gAll.Roles.Add(new GroupRole { Role = personel });

        var gIst = GroupOf(abank, "IST_SUBE_MUDURLERI", "İstanbul Bölgesi Şube Müdürleri", "Bölge altındaki şube müdürleri GM operasyon raporunu görebilir.");
        Filter(gIst, InclusionMode.Include, "Şube müdürü ve İstanbul bölgesi altında", ("ROLE", ["SUBEMDR"]), ("ORG_UNIT_TREE", ["BLG_IST"]));
        gIst.Permissions.Add(new GroupPermission { Permission = P("anka.rapor.gm.operasyon:read") });

        var gVekalet = GroupOf(abank, "SUBEMDR_VEKALET_737", "737 Şube Müdürü Vekaleti", "Süreli açık üyelik: vekil şube müdürü rolünü alır.");
        gVekalet.Members.Add(new GroupMember { User = burak, ValidUntil = now.AddYears(1) });
        gVekalet.Roles.Add(new GroupRole { Role = rSubeMdr });

        var gKredi = GroupOf(abank, "KREDI_KOMITESI", "Kredi Komitesi", "GM 850 yönetici/yetkilileri VEYA Merkez Şube müdürü (filtreler arası VEYA örneği).");
        Filter(gKredi, InclusionMode.Include, "GM 850 yetkili/yönetici", ("ROLE", ["GM850UZYTK", "GM850UZMYR"]));
        Filter(gKredi, InclusionMode.Include, "101 şube müdürü", ("ROLE", ["SUBEMDR"]), ("ORG_UNIT", ["101"]));
        gKredi.Permissions.Add(new GroupPermission { Permission = P("anka.kredi.kullandirim.dosya:execute") });

        var gB = GroupOf(bIstirak, "B_TUM_PERSONEL", "B İştiraki Tüm Personel", "B İştiraki kullanıcıları fon bilgisini görebilir.");
        Filter(gB, InclusionMode.Include, "B İştiraki", ("TENANT", ["BISTIRAK"]));
        gB.Permissions.Add(new GroupPermission { Permission = P("anka.yatirim.fon.bilgi:read") });
        await db.SaveChangesAsync();

        // ================================ Client'lar ================================
        Client ClientOf(string id, string name, ClientType type, CatalogApplication? app, string description, User? serviceUser = null, Tenant? tenant = null)
        {
            var c = new Client
            {
                Tenant = tenant ?? abank, ClientId = id, Name = name, Type = type, Application = app, Description = description, ServiceAccountUser = serviceUser
            };
            db.Clients.Add(c);
            return c;
        }
        void Grant(Client c, TargetType type, object? target, string? actions = null) =>
            c.AllowedPermissions.Add(new ClientPermissionGrant
            {
                TargetType = type, Actions = actions,
                Application = target as CatalogApplication, CatalogNode = target as CatalogNode, Permission = target as Permission
            });

        var cNextral = ClientOf("nextral-desktop", "Nextral Şube Masaüstü", ClientType.Confidential, nextral, "Şube masaüstü uygulaması (WinForms).");
        Grant(cNextral, TargetType.Application, nextral);
        foreach (var d in new[] { "NAKIT", "ODEME", "HESAP", "KREDI", "MUSTERI", "RAPOR" }) Grant(cNextral, TargetType.CatalogNode, N($"ANKA/{d}"));

        var cMobil = ClientOf("mobil-sube-tablet", "Mobil Şube Tablet", ClientType.Public, mobil, "Sahada tablet; cihaz uyumluluğu zorunlu. Anka'da sadece okuma.");
        Grant(cMobil, TargetType.Application, mobil);
        Grant(cMobil, TargetType.CatalogNode, N("ANKA/MUSTERI"), "read");
        Grant(cMobil, TargetType.CatalogNode, N("ANKA/HESAP"), "read");

        // Aracı: isteği BAŞLATMAZ, kullanıcı adına iletir. Kapsamı = iletebileceği API'ler. Karar orijinal client'a göre verilir.
        var cGateway = ClientOf("anka-gateway", "Anka API Gateway", ClientType.Intermediary, anka,
            "Aracı: mikroservislerin önündeki gateway; kullanıcı token'ını ve orijinal client'ı (azp) iletir.");
        Grant(cGateway, TargetType.Application, anka);

        var cWeb = ClientOf("anka-web", "Anka Web (şube web uygulaması)", ClientType.Confidential, null,
            "Tarayıcıdan çalışan şube web uygulaması: müşteri ve hesap işlemleri, nakit sadece sorgu.");
        Grant(cWeb, TargetType.CatalogNode, N("ANKA/MUSTERI"));
        Grant(cWeb, TargetType.CatalogNode, N("ANKA/HESAP"));
        Grant(cWeb, TargetType.CatalogNode, N("ANKA/NAKIT"), "read");

        var cBatch = ClientOf("eod-batch", "Gün Sonu Batch", ClientType.Service, anka, "Client credentials; svc.eod-batch servis hesabıyla çalışır.", svc);
        Grant(cBatch, TargetType.CatalogNode, N("ANKA/RAPOR"));
        Grant(cBatch, TargetType.CatalogNode, N("ANKA/NAKIT/KASA"));

        var cConsole = ClientOf("yetki-konsol", "Yetki Yönetim Konsolu (test)", ClientType.Confidential, null, "Yönetim ekranındaki 'Yetki Testi' için; tüm katalog.");
        Grant(cConsole, TargetType.All, null);

        var cBPortal = ClientOf("b-portal-web", "B Yatırımcı Portalı (web)", ClientType.Public, bPortal,
            "B İştiraki'nin kendi client'ı: A Bankası tenant'ında kullanılamaz.", tenant: bIstirak);
        Grant(cBPortal, TargetType.Application, bPortal);
        Grant(cBPortal, TargetType.CatalogNode, N("ANKA/YATIRIM"), "read");
        await db.SaveChangesAsync();

        // ================================ Ortak koşullar ================================
        var businessHours = Shared("BUSINESS_HOURS", "Mesai saati (09:00-18:00, hafta içi)",
            Pred("TIME_WINDOW", ("Start", "09:00"), ("End", "18:00"), ("Days", "MON,TUE,WED,THU,FRI"), ("TimeZone", "Europe/Istanbul")));
        var eftHours = Shared("EFT_HOURS", "EFT saatleri (08:30-20:00, Pzt-Cmt)",
            Pred("TIME_WINDOW", ("Start", "08:30"), ("End", "20:00"), ("Days", "MON,TUE,WED,THU,FRI,SAT"), ("TimeZone", "Europe/Istanbul")));
        var bankNetwork = Shared("BANK_NETWORK", "Banka iç ağı",
            Pred("IP_IN_RANGE", ("Cidrs", "10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,127.0.0.1/32,::1/128")));
        var remote = Shared("REMOTE_PLATFORM", "Uzak platform (mobil/internet)", Pred("PLATFORM_IN", ("Platforms", "MOBILE,INTERNET")));
        var creditLimit = Shared("CREDIT_BRANCH_APPROVAL_LIMIT", "Şube kredi onay limiti içinde (≤ 1.000.000)",
            Not(Pred("AMOUNT_GREATER_THAN", ("Threshold", "1000000"))), ConditionScope.Domain, "KREDI");
        var bHours = Shared("B_BUSINESS_HOURS", "B İştiraki mesai (08:30-17:30)",
            Pred("TIME_WINDOW", ("Start", "08:30"), ("End", "17:30"), ("Days", "MON,TUE,WED,THU,FRI"), ("TimeZone", "Europe/Istanbul")));
        await db.SaveChangesAsync();

        // ================================ Policy'ler (hedefli) ================================
        var pNetwork = PolicyOf(abank, "KURUMSAL_AG", "Kurumsal ağ zorunluluğu", "Tüm işlemler banka ağından yapılır; mobil şube (saha) hariç.");
        Target(pNetwork, InclusionMode.Include, TargetType.All, null);
        Target(pNetwork, InclusionMode.Exclude, TargetType.Application, mobil);
        ClientTarget(pNetwork, InclusionMode.Exclude, cMobil);   // mobil tablet sahada: Anka API'lerini banka ağı dışından da çağırır
        RuleOf(pNetwork, "BANK_NETWORK", "İstek banka ağından gelmeli", 10, "OUTSIDE_BANK_NETWORK", Ref(bankNetwork));

        var pLeave = PolicyOf(abank, "IZINLI_PERSONEL", "İzinli personel işlem yapamaz", "İzindeki personelin tüm işlemleri reddedilir.");
        Target(pLeave, InclusionMode.Include, TargetType.All, null);
        RuleOf(pLeave, "NOT_ON_LEAVE", "Kullanıcı izinde olmamalı", 10, "USER_ON_LEAVE", Not(Pred("USER_ON_LEAVE")));

        var pCashHours = PolicyOf(abank, "NAKIT_MESAI", "Nakit işlemleri mesai saatinde", "NAKIT domain'inin tamamı (tek noktadan); ATM çekim hariç (7/24).");
        Target(pCashHours, InclusionMode.Include, TargetType.CatalogNode, N("ANKA/NAKIT"));
        Target(pCashHours, InclusionMode.Exclude, TargetType.CatalogNode, N("ANKA/NAKIT/CEKIM/ATM"));
        RuleOf(pCashHours, "WORKING_HOURS", "Mesai saatinde olmalı (09:00-18:00)", 10, "OUTSIDE_BUSINESS_HOURS", Ref(businessHours));

        var pLimit = PolicyOf(abank, "NAKIT_CEKIM_LIMIT", "Gişe çekim limiti ve kendi hesabı", "Tutar kullanıcı limitini aşamaz; personel kendi hesabında işlem yapamaz.");
        Target(pLimit, InclusionMode.Include, TargetType.CatalogNode, N("ANKA/NAKIT/CEKIM/GISE"), "create");
        RuleOf(pLimit, "TRANSACTION_LIMIT", "Tutar ≤ kullanıcının işlem limiti", 10, "AMOUNT_EXCEEDS_USER_LIMIT", Not(Pred("AMOUNT_EXCEEDS_SUBJECT_LIMIT")));
        RuleOf(pLimit, "NOT_SELF_TRANSACTION", "Personelin kendi hesabı olmamalı", 20, "SELF_TRANSACTION_NOT_ALLOWED", Not(Pred("CUSTOMER_IS_SELF")));

        var pEft = PolicyOf(abank, "EFT_KURALLARI", "Giden EFT kuralları", "EFT saatleri; uzak platformdan yüksek tutar yasak.");
        Target(pEft, InclusionMode.Include, TargetType.CatalogNode, N("ANKA/ODEME/EFT/GIDEN"), "create");
        RuleOf(pEft, "EFT_HOURS", "EFT saatlerinde olmalı (08:30-20:00)", 10, "OUTSIDE_EFT_HOURS", Ref(eftHours));
        RuleOf(pEft, "REMOTE_AMOUNT_LIMIT", "Uzak platformdan en fazla 50.000", 20, "HIGH_AMOUNT_FROM_REMOTE_PLATFORM",
            Not(All(Ref(remote), Pred("AMOUNT_GREATER_THAN", ("Threshold", "50000")))));

        var pCredit = PolicyOf(abank, "KREDI_ONAY", "Kredi onay yetki limiti ve kapsamı", "1M üzeri sadece GM 850 yetkili/yönetici; şube kendi kapsamındaki dosyayı onaylar.");
        Target(pCredit, InclusionMode.Include, TargetType.CatalogNode, N("ANKA/KREDI/ONAY/DOSYA"), "approve");
        RuleOf(pCredit, "APPROVAL_LIMIT", "Tutar şube onay limiti içinde veya onaylayan GM 850 yetkili/yönetici", 10, "APPROVAL_LIMIT_EXCEEDED",
            Any(Ref(creditLimit), Pred("SUBJECT_HAS_ROLE", ("Roles", "GM850UZYTK,GM850UZMYR"))));
        RuleOf(pCredit, "BRANCH_SCOPE", "Dosya şubesi kullanıcının kapsamında (veya GM 850)", 20, "OUT_OF_BRANCH_SCOPE",
            Any(Pred("BRANCH_IN_USER_SCOPE"), Pred("SUBJECT_IN_UNIT", ("Units", "850"))));

        var pScope = PolicyOf(abank, "MUSTERI_VERI_KAPSAMI", "Müşteri verisi kapsamı", "Şube personeli kendi (alt) birimlerinin müşterisini görür; GM daireleri tümünü.");
        Target(pScope, InclusionMode.Include, TargetType.CatalogNode, N("ANKA/MUSTERI"));
        RuleOf(pScope, "CUSTOMER_SCOPE", "Müşteri kullanıcının veri kapsamında (veya GM 928/850)", 10, "CUSTOMER_OUT_OF_SCOPE",
            Any(Pred("BRANCH_IN_USER_SCOPE"), Pred("SUBJECT_IN_UNIT", ("Units", "928,850"))));

        var pDevice = PolicyOf(abank, "MOBIL_CIHAZ", "Mobil cihaz uyumluluğu", "Mobil şube API'leri sadece MDM uyumlu cihazdan.");
        Target(pDevice, InclusionMode.Include, TargetType.Application, mobil);
        RuleOf(pDevice, "DEVICE_COMPLIANT", "Cihaz MDM uyumlu olmalı", 10, "DEVICE_NOT_COMPLIANT", Pred("DEVICE_COMPLIANT"));

        // Kanal (client) hedefli: aynı Anka endpoint'i Nextral / Anka Web / Mobil'den çağrılır; kural SADECE mobilden gelen isteğe uygulanır
        var pMobileChannel = PolicyOf(abank, "MOBIL_KANAL", "Mobil kanal: müşteri/hesap verisi",
            "Sadece mobil tabletten gelen müşteri ve hesap isteklerine: cihaz uyumlu olmalı; TCKN/telefon maskelenir, liste 20 kayıtla sınırlanır, KVKK erişim logu.");
        Target(pMobileChannel, InclusionMode.Include, TargetType.CatalogNode, N("ANKA/MUSTERI"));
        Target(pMobileChannel, InclusionMode.Include, TargetType.CatalogNode, N("ANKA/HESAP"));
        ClientTarget(pMobileChannel, InclusionMode.Include, cMobil);
        RuleOf(pMobileChannel, "MOBILE_DEVICE_COMPLIANT", "Mobil cihaz MDM uyumlu olmalı", 10, "DEVICE_NOT_COMPLIANT", Pred("DEVICE_COMPLIANT"));
        Obligation(pMobileChannel, "MASK_FIELDS", ("Fields", "tckn,telefon,email"), ("KeepLast", "2"));
        Obligation(pMobileChannel, "LIMIT_RESULTS", ("Max", "20"));
        Obligation(pMobileChannel, "LOG_ACCESS", ("Category", "KVKK_MUSTERI"));

        var pWebMask = PolicyOf(abank, "WEB_KANAL_MASKE", "Anka Web: çekim sorgusunda hassas alan maskesi",
            "Web kanalından çekim sorgusunda hesap no ve müşteri TCKN'si maskelenir (rule yok: koşulsuz yükümlülük).");
        Target(pWebMask, InclusionMode.Include, TargetType.CatalogNode, N("ANKA/NAKIT/CEKIM/GISE"), "read");
        ClientTarget(pWebMask, InclusionMode.Include, cWeb);
        Obligation(pWebMask, "MASK_FIELDS", ("Fields", "hesapNo,musteriTckn"), ("KeepLast", "4"));

        var pReport = PolicyOf(abank, "RAPOR_MESAI_DENEME", "Rapor erişimi mesai saatinde (deneme)", "ReportOnly: kararı etkilemez, kim etkilenirdi görmek için.", PolicyMode.ReportOnly);
        Target(pReport, InclusionMode.Include, TargetType.CatalogNode, N("ANKA/RAPOR"));
        RuleOf(pReport, "REPORT_WORKING_HOURS", "Rapor erişimi mesai saatinde", 10, "REPORT_OUTSIDE_HOURS", Ref(businessHours));

        var pB = PolicyOf(bIstirak, "B_MESAI", "B İştiraki mesai kuralı", "Sadece B İştiraki kullanıcılarına uygulanır (tenant kapsamı).");
        Target(pB, InclusionMode.Include, TargetType.All, null);
        RuleOf(pB, "B_WORKING_HOURS", "B İştiraki mesaisinde olmalı (08:30-17:30)", 10, "OUTSIDE_B_BUSINESS_HOURS", Ref(bHours));
        await db.SaveChangesAsync();

        // ================================ SoD ================================
        db.SodRules.Add(new SodRule
        {
            Code = "SOD_KREDI_BASVURU_ONAY", Name = "Kredi başvurusu açan onaylayamaz", Severity = Severity.High, Enforcement = SodEnforcement.Warn,
            Description = "Aynı kişi hem başvuru açıp hem onaylayabilmemeli (4 göz).",
            Members =
            [
                new SodRuleMember { MemberType = SodMemberType.Permission, MemberId = P("anka.kredi.basvuru.bireysel:create").Id },
                new SodRuleMember { MemberType = SodMemberType.Permission, MemberId = P("anka.kredi.onay.dosya:approve").Id }
            ]
        });
        db.SodRules.Add(new SodRule
        {
            Code = "SOD_GISE_SUBE_MUDURU", Name = "Gişe asistanı şube müdürü olamaz", Severity = Severity.Critical, Enforcement = SodEnforcement.Block,
            Description = "Kasa işlemini yapan ile onaylayan aynı kişi olamaz.",
            Members =
            [
                new SodRuleMember { MemberType = SodMemberType.Role, MemberId = rGiseAst.Id },
                new SodRuleMember { MemberType = SodMemberType.Role, MemberId = rSubeMdr.Id }
            ]
        });

        // ================================ Dış sistemler (RACF / LDAP) ================================
        // Kimlik yayılımı: kullanıcı kendi mainframe token'ını CICS'e iletir → CICS'te ÇAĞIRAN KULLANICININ RACF yetkisi aranır.
        // Bağımlılık bilginin doğduğu yerde: API (tüm endpoint'ler) · endpoint · permission (istisna). Zincir: transaction → dataset.
        var racf = new ExternalSystem { Code = "RACF", Name = "IBM RACF (z/OS)", Description = "CICS transaction, dataset ve uygulama profilleri", HasAccessLevels = true };
        var ldap = new ExternalSystem { Code = "LDAP", Name = "Kurumsal LDAP", Description = "Nextral uygulama grupları (üyelik)", HasAccessLevels = false };
        db.ExternalSystems.AddRange(racf, ldap);
        ExternalPermission Ext(ExternalSystem sys, string code, string cls, string name)
        {
            var e = new ExternalPermission { ExternalSystem = sys, Code = code, ResourceClass = cls, Name = name };
            db.ExternalPermissions.Add(e);
            return e;
        }
        void Requires(ExternalPermission from, ExternalPermission to, ExternalAccessLevel? level = null) =>
            db.ExternalPermissionRequirements.Add(new ExternalPermissionRequirement { ExternalPermission = from, RequiredExternalPermission = to, AccessLevel = level });
        void OnApi(string api, ExternalPermission e, ExternalAccessLevel? level = null) =>
            db.ExternalDependencies.Add(new ExternalDependency { ApiResource = _apis[api], ExternalPermission = e, AccessLevel = level });
        void OnEndpoint(string api, string method, string path, ExternalPermission e, ExternalAccessLevel? level = null) =>
            db.ExternalDependencies.Add(new ExternalDependency
            {
                ApiEndpoint = _apis[api].Endpoints.Single(x => x.Method == method && x.Path == path), ExternalPermission = e, AccessLevel = level
            });
        void OnPermission(string perm, ExternalPermission e, ExternalAccessLevel? level = null, string? note = null) =>
            db.ExternalDependencies.Add(new ExternalDependency { Permission = P(perm), ExternalPermission = e, AccessLevel = level, Note = note });

        // --- Müşteri: dokümandaki örnek — ANKA/MUSTERI/BILGI/PROFIL · musteri-api · GET /v1/customers/{id} (READ) → X, Y, Z
        var cicsMus = Ext(racf, "CICSMUS", "APPL", "Müşteri CICS bölgesi");
        var mus1 = Ext(racf, "MUS1", "TCICSTRN", "Müşteri sorgu transaction'ı");
        var hsp1 = Ext(racf, "HSP1", "TCICSTRN", "Müşteri hesap özeti transaction'ı");
        var mus2 = Ext(racf, "MUS2", "TCICSTRN", "Müşteri güncelleme transaction'ı");
        var musMaster = Ext(racf, "BNK.MUSTERI.MASTER", "DATASET", "Müşteri ana kayıt dosyası");
        var hspMaster = Ext(racf, "BNK.HESAP.MASTER", "DATASET", "Hesap ana kayıt dosyası");
        OnApi("musteri-api", cicsMus, ExternalAccessLevel.Read);                       // tüm endpoint'ler bölgeye bağlanır
        OnEndpoint("musteri-api", "GET", "/v1/customers/{id}", mus1);                  // seviye action'dan: read → READ
        OnEndpoint("musteri-api", "GET", "/v1/customers/{id}", hsp1);
        OnEndpoint("musteri-api", "GET", "/v1/customers", mus1);
        OnEndpoint("musteri-api", "PUT", "/v1/customers/{id}", mus2);                 // update → UPDATE
        Requires(mus1, musMaster);                                                     // MUS1 çalışırken müşteri dosyasını okur (seviye: MUS1 ile aynı)
        Requires(hsp1, hspMaster, ExternalAccessLevel.Read);
        Requires(mus2, musMaster);                                                     // UPDATE ile gelir → dataset'e UPDATE

        // --- Nakit çekim (örnek mikroservis manifestiyle aynı)
        var cicsNkt = Ext(racf, "CICSNKT", "APPL", "Nakit CICS bölgesi");
        var nkc1 = Ext(racf, "NKC1", "TCICSTRN", "Nakit çekim transaction");
        var nks1 = Ext(racf, "NKS1", "TCICSTRN", "Nakit çekim sorgu transaction");
        var nki1 = Ext(racf, "NKI1", "TCICSTRN", "Nakit çekim iptal transaction");
        var kasaHrk = Ext(racf, "BNK.KASA.HAREKET", "DATASET", "Kasa hareket dosyası");
        OnApi("nakit-cekim-gise-api", cicsNkt, ExternalAccessLevel.Read);
        OnEndpoint("nakit-cekim-gise-api", "POST", "/v1/cash-withdrawals", nkc1);
        OnEndpoint("nakit-cekim-gise-api", "GET", "/v1/cash-withdrawals/{id}", nks1);
        OnEndpoint("nakit-cekim-gise-api", "GET", "/v1/cash-withdrawals", nks1);
        OnEndpoint("nakit-cekim-gise-api", "POST", "/v1/cash-withdrawals/{id}/cancel", nki1);
        Requires(nkc1, kasaHrk);
        Requires(nks1, kasaHrk, ExternalAccessLevel.Read);
        Requires(nki1, kasaHrk);

        // --- Diğerleri
        var kgs1 = Ext(racf, "KGS1", "TCICSTRN", "Kasa gün sonu");
        var eft1 = Ext(racf, "EFT1", "TCICSTRN", "Giden EFT");
        var krd9 = Ext(racf, "KRD9", "TCICSTRN", "Kredi onay");
        OnEndpoint("kasa-api", "POST", "/v1/vault/day-end", kgs1);
        OnEndpoint("eft-giden-api", "POST", "/v1/eft/outgoing", eft1);
        OnEndpoint("kredi-onay-api", "POST", "/v1/loan-files/{id}/approve", krd9);
        OnPermission("nextral.gise.nakit_ekran:view", Ext(ldap, "CN=NEXTRAL_NAKIT", "GROUP", "Nextral nakit ekranı"), note: "Nextral ekranı: endpoint yok, doğrudan permission");
        OnPermission("nextral.kredi.kredi_ekran:view", Ext(ldap, "CN=NEXTRAL_KREDI", "GROUP", "Nextral kredi ekranı"), note: "Nextral ekranı: endpoint yok, doğrudan permission");
        await db.SaveChangesAsync();
    }

    // ================================ Katalog yardımcıları ================================

    private CatalogApplication App(Tenant tenant, string code, string name, ApplicationType type, string description, string owner)
    {
        var key = $"{tenant.Code}/{owner}";
        if (!_ownershipTeams.TryGetValue(key, out var team))
        {
            team = new OwnershipTeam { Tenant = tenant, Code = Codes.Normalize(owner), Name = owner };
            db.OwnershipTeams.Add(team);
            _ownershipTeams[key] = team;
        }
        var a = new CatalogApplication { Tenant = tenant, Code = code, Name = name, Type = type, Description = description, OwnerTeam = owner, OwnershipTeam = team };
        db.Applications.Add(a);
        return a;
    }

    private CatalogNode Node(CatalogApplication app, CatalogNode? parent, string code, string name, string? description = null)
    {
        var n = new CatalogNode
        {
            Tenant = app.Tenant, Application = app, Parent = parent, Code = code, Name = name, Description = description,
            Type = parent is null ? CatalogNodeType.Domain : parent.Type == CatalogNodeType.Domain ? CatalogNodeType.Module : CatalogNodeType.SubModule,
            Path = $"{parent?.Path ?? app.Code}/{code}"
        };
        db.CatalogNodes.Add(n);
        _nodes[n.Path] = n;
        return n;
    }

    private Permission Perm(CatalogNode node, string action, string name, Severity risk = Severity.Medium)
    {
        var code = $"{node.Path.Replace('/', '.').ToLowerInvariant()}:{action}";
        var p = new Permission { Tenant = node.Tenant, Application = node.Application, CatalogNode = node, Code = code, Name = name, Action = action, RiskLevel = risk };
        db.Permissions.Add(p);
        _perms[code] = p;
        return p;
    }

    private ApiResource Api(CatalogNode node, string code, string name, params (string Method, string Path, Permission? Perm, string Summary)[] endpoints)
    {
        var api = new ApiResource
        {
            Tenant = node.Tenant, Application = node.Application, CatalogNode = node, Code = code, Name = name, Audience = $"api://{node.Application!.Code.ToLowerInvariant()}/{code}", BasePath = "/v1",
            Endpoints = endpoints.Select(e => new ApiEndpoint { Method = e.Method, Path = e.Path, Permission = e.Perm, Summary = e.Summary }).ToList()
        };
        db.ApiResources.Add(api);
        _apis[code] = api;
        return api;
    }

    private UiElement Ui(CatalogNode node, UiElement? parent, UiElementKind kind, string code, string name, int order, string? perm)
    {
        var e = new UiElement { CatalogNode = node, Parent = parent, Kind = kind, Code = code, Name = name, Order = order, Permission = perm is null ? null : P(perm) };
        db.UiElements.Add(e);
        return e;
    }

    private Permission P(string code) => _perms.TryGetValue(code, out var p) ? p : throw new InvalidOperationException($"Seed: permission yok: {code}");
    private CatalogNode N(string path) => _nodes.TryGetValue(path, out var n) ? n : throw new InvalidOperationException($"Seed: düğüm yok: {path}");

    private void SeedAnka(CatalogApplication anka)
    {
        // NAKIT
        var nakit = Node(anka, null, "NAKIT", "Nakit İşlemler", "Gişe nakit işlemleri");
        var cekim = Node(anka, nakit, "CEKIM", "Para Çekme");
        var cekGise = Node(anka, cekim, "GISE", "Gişeden Çekim");
        var cc = Perm(cekGise, "create", "Gişeden para çekme", Severity.High);
        var cr = Perm(cekGise, "read", "Çekim sorgulama", Severity.Low);
        var cx = Perm(cekGise, "cancel", "Çekim iptali", Severity.High);
        Api(cekGise, "nakit-cekim-gise-api", "Gişe Nakit Çekim API",
            ("POST", "/v1/cash-withdrawals", cc, "Çekim yap"), ("GET", "/v1/cash-withdrawals", cr, "Çekimleri listele"),
            ("GET", "/v1/cash-withdrawals/{id}", cr, "Çekim detayı"), ("POST", "/v1/cash-withdrawals/{id}/cancel", cx, "Çekim iptal"),
            ("GET", "/v1/cash-withdrawals/{id}/receipt", null, "Dekont (EŞLENMEMİŞ — denetim bulgusu örneği)"));
        var atm = Node(anka, cekim, "ATM", "ATM Çekim Yönetimi", "7/24 çalışır; mesai kuralından hariç tutulur");
        var ac = Perm(atm, "create", "ATM çekim işlemi (kart hamili adına)", Severity.High);
        var ar = Perm(atm, "read", "ATM çekim sorgulama", Severity.Low);
        Api(atm, "atm-cekim-api", "ATM Çekim API", ("POST", "/v1/atm-withdrawals", ac, "ATM çekim"), ("GET", "/v1/atm-withdrawals/{id}", ar, "ATM çekim detayı"));

        var yatirma = Node(anka, nakit, "YATIRMA", "Para Yatırma");
        var yatGise = Node(anka, yatirma, "GISE", "Gişeden Yatırma");
        var yc = Perm(yatGise, "create", "Gişeden para yatırma", Severity.Medium);
        var yr = Perm(yatGise, "read", "Yatırma sorgulama", Severity.Low);
        Api(yatGise, "nakit-yatirma-api", "Nakit Yatırma API", ("POST", "/v1/cash-deposits", yc, "Yatırma"), ("GET", "/v1/cash-deposits/{id}", yr, "Yatırma detayı"));

        var kasa = Node(anka, nakit, "KASA", "Kasa İşlemleri");
        var gunSonu = Node(anka, kasa, "GUN_SONU", "Gün Sonu");
        var gx = Perm(gunSonu, "execute", "Kasa gün sonu", Severity.High);
        var gr = Perm(gunSonu, "read", "Kasa bakiyesi", Severity.Low);
        Api(gunSonu, "kasa-api", "Kasa API", ("POST", "/v1/vault/day-end", gx, "Gün sonu"), ("GET", "/v1/vault/balance", gr, "Kasa bakiyesi"));

        // ODEME
        var odeme = Node(anka, null, "ODEME", "Ödeme");
        var eft = Node(anka, odeme, "EFT", "EFT");
        var eftOut = Node(anka, eft, "GIDEN", "Giden EFT");
        var ec = Perm(eftOut, "create", "Giden EFT gönder", Severity.High);
        var er = Perm(eftOut, "read", "Giden EFT sorgula", Severity.Low);
        var ex = Perm(eftOut, "cancel", "Giden EFT iptal", Severity.High);
        Api(eftOut, "eft-giden-api", "Giden EFT API", ("POST", "/v1/eft/outgoing", ec, "EFT gönder"), ("GET", "/v1/eft/outgoing/{id}", er, "EFT detayı"),
            ("POST", "/v1/eft/outgoing/{id}/cancel", ex, "EFT iptal"));
        var eftIn = Node(anka, eft, "GELEN", "Gelen EFT");
        var eir = Perm(eftIn, "read", "Gelen EFT sorgula", Severity.Low);
        Api(eftIn, "eft-gelen-api", "Gelen EFT API", ("GET", "/v1/eft/incoming", eir, "Gelen EFT listesi"), ("GET", "/v1/eft/incoming/{id}", eir, "Gelen EFT detayı"));
        var fast = Node(anka, odeme, "FAST", "FAST");
        var fastOut = Node(anka, fast, "GIDEN", "Giden FAST");
        var fc = Perm(fastOut, "create", "FAST ödeme gönder", Severity.High);
        var fr = Perm(fastOut, "read", "FAST sorgula", Severity.Low);
        Api(fastOut, "fast-api", "FAST API", ("POST", "/v1/fast/payments", fc, "FAST gönder"), ("GET", "/v1/fast/payments/{id}", fr, "FAST detayı"));
        var havale = Node(anka, odeme, "HAVALE", "Havale");
        var hesaplar = Node(anka, havale, "HESAPLAR_ARASI", "Hesaplar Arası");
        var hc = Perm(hesaplar, "create", "Hesaplar arası havale", Severity.Medium);
        var hr = Perm(hesaplar, "read", "Havale sorgula", Severity.Low);
        Api(hesaplar, "havale-api", "Havale API", ("POST", "/v1/transfers", hc, "Havale"), ("GET", "/v1/transfers/{id}", hr, "Havale detayı"));

        // KREDI
        var kredi = Node(anka, null, "KREDI", "Krediler");
        var basvuru = Node(anka, kredi, "BASVURU", "Başvuru");
        var bireysel = Node(anka, basvuru, "BIREYSEL", "Bireysel Kredi Başvurusu");
        var bc = Perm(bireysel, "create", "Kredi başvurusu aç", Severity.Medium);
        var br = Perm(bireysel, "read", "Kredi başvurusu görüntüle", Severity.Low);
        Api(bireysel, "kredi-basvuru-api", "Kredi Başvuru API", ("POST", "/v1/loan-applications", bc, "Başvuru aç"), ("GET", "/v1/loan-applications/{id}", br, "Başvuru detayı"));
        var onay = Node(anka, kredi, "ONAY", "Onay");
        var dosya = Node(anka, onay, "DOSYA", "Kredi Dosyası");
        var oa = Perm(dosya, "approve", "Kredi onayla", Severity.Critical);
        var or = Perm(dosya, "read", "Kredi dosyası görüntüle", Severity.Low);
        Api(dosya, "kredi-onay-api", "Kredi Onay API", ("POST", "/v1/loan-files/{id}/approve", oa, "Onayla"), ("GET", "/v1/loan-files/{id}", or, "Dosya detayı"));
        var kull = Node(anka, kredi, "KULLANDIRIM", "Kullandırım");
        var kDosya = Node(anka, kull, "DOSYA", "Kullandırım Dosyası");
        var kx = Perm(kDosya, "execute", "Kredi kullandır", Severity.Critical);
        Api(kDosya, "kredi-kullandirim-api", "Kredi Kullandırım API", ("POST", "/v1/disbursements", kx, "Kullandır"));

        // MUSTERI
        var musteri = Node(anka, null, "MUSTERI", "Müşteri");
        var bilgi = Node(anka, musteri, "BILGI", "Müşteri Bilgileri");
        var profil = Node(anka, bilgi, "PROFIL", "Müşteri Profili");
        var mr = Perm(profil, "read", "Müşteri görüntüle", Severity.Low);
        var mu = Perm(profil, "update", "Müşteri güncelle", Severity.Medium);
        Api(profil, "musteri-api", "Müşteri API", ("GET", "/v1/customers", mr, "Müşteri ara"), ("GET", "/v1/customers/{id}", mr, "Müşteri detayı"),
            ("PUT", "/v1/customers/{id}", mu, "Müşteri güncelle"));
        var kyc = Node(anka, musteri, "KYC", "Müşteri Tanıma (KYC)");
        var belge = Node(anka, kyc, "BELGE", "KYC Belgeleri");
        var kr = Perm(belge, "read", "KYC belgesi görüntüle", Severity.Medium);
        var ku = Perm(belge, "update", "KYC belgesi güncelle", Severity.High);
        Api(belge, "kyc-api", "KYC API", ("GET", "/v1/kyc/{customerId}/documents", kr, "Belgeler"), ("POST", "/v1/kyc/{customerId}/documents", ku, "Belge yükle"));

        // HESAP
        var hesap = Node(anka, null, "HESAP", "Hesaplar");
        var vadesiz = Node(anka, hesap, "VADESIZ", "Vadesiz");
        var vc = Perm(vadesiz, "create", "Vadesiz hesap aç");
        var vr = Perm(vadesiz, "read", "Vadesiz hesap görüntüle", Severity.Low);
        Api(vadesiz, "vadesiz-hesap-api", "Vadesiz Hesap API", ("POST", "/v1/demand-accounts", vc, "Hesap aç"), ("GET", "/v1/demand-accounts/{id}", vr, "Hesap detayı"));
        var vadeli = Node(anka, hesap, "VADELI", "Vadeli");
        var tc = Perm(vadeli, "create", "Vadeli hesap aç");
        var tr = Perm(vadeli, "read", "Vadeli hesap görüntüle", Severity.Low);
        var tx = Perm(vadeli, "close", "Vadeli hesap kapat", Severity.High);
        Api(vadeli, "vadeli-hesap-api", "Vadeli Hesap API", ("POST", "/v1/term-deposits", tc, "Vadeli aç"), ("GET", "/v1/term-deposits/{id}", tr, "Vadeli detayı"),
            ("POST", "/v1/term-deposits/{id}/close", tx, "Vadeli kapat"));
        var kampanya = Node(anka, vadeli, "KAMPANYA", "Kampanyalı Vadeli");
        var kc = Perm(kampanya, "create", "Kampanyalı vadeli aç", Severity.Medium);
        Api(kampanya, "vadeli-kampanya-api", "Kampanyalı Vadeli API", ("POST", "/v1/term-deposit-campaigns", kc, "Kampanyalı vadeli aç"));

        // RAPOR
        var rapor = Node(anka, null, "RAPOR", "Raporlama");
        var rSube = Node(anka, rapor, "SUBE", "Şube Raporları");
        var gunluk = Node(anka, rSube, "GUNLUK", "Günlük Şube Raporu");
        var rr = Perm(gunluk, "read", "Günlük şube raporu", Severity.Low);
        var re = Perm(gunluk, "export", "Günlük şube raporu dışa aktar", Severity.Medium);
        Api(gunluk, "rapor-sube-api", "Şube Rapor API", ("GET", "/v1/reports/branch/daily", rr, "Rapor"), ("GET", "/v1/reports/branch/daily/export", re, "Dışa aktar"));
        var rGm = Node(anka, rapor, "GM", "Genel Müdürlük Raporları");
        var ops = Node(anka, rGm, "OPERASYON", "Operasyon Raporu");
        var gor = Perm(ops, "read", "GM operasyon raporu", Severity.Low);
        var goe = Perm(ops, "export", "GM operasyon raporu dışa aktar", Severity.Medium);
        Api(ops, "rapor-gm-api", "GM Rapor API", ("GET", "/v1/reports/hq/operations", gor, "Rapor"), ("GET", "/v1/reports/hq/operations/export", goe, "Dışa aktar"));
    }

    /// <summary>B İştiraki'nin kullandığı yatırım işlemleri (küçük, elle tanımlı domain).</summary>
    private void SeedYatirim(CatalogApplication anka)
    {
        var yatirim = Node(anka, null, "YATIRIM", "Yatırım", "Fon ve hisse işlemleri (B İştiraki)");
        var fon = Node(anka, yatirim, "FON", "Yatırım Fonları");
        var bilgi = Node(anka, fon, "BILGI", "Fon Bilgileri");
        var fb = Perm(bilgi, "read", "Fon bilgisi görüntüle", Severity.Low);
        Api(bilgi, "fon-bilgi-api", "Fon Bilgi API", ("GET", "/v1/funds", fb, "Fon listesi"), ("GET", "/v1/funds/{code}", fb, "Fon detayı"));
        var alim = Node(anka, fon, "ALIM_SATIM", "Fon Alım/Satım");
        var fc = Perm(alim, "create", "Fon alım/satım talimatı", Severity.High);
        var fr = Perm(alim, "read", "Fon talimatı sorgula", Severity.Low);
        Api(alim, "fon-islem-api", "Fon İşlem API", ("POST", "/v1/fund-orders", fc, "Talimat ver"), ("GET", "/v1/fund-orders/{id}", fr, "Talimat detayı"));
        var hisse = Node(anka, yatirim, "HISSE", "Hisse Senetleri");
        var emir = Node(anka, hisse, "EMIR", "Hisse Emirleri");
        var hc = Perm(emir, "create", "Hisse emri gir", Severity.High);
        var hr = Perm(emir, "read", "Hisse emri sorgula", Severity.Low);
        Api(emir, "hisse-emir-api", "Hisse Emir API", ("POST", "/v1/equity-orders", hc, "Emir gir"), ("GET", "/v1/equity-orders/{id}", hr, "Emir detayı"));
    }

    /// <summary>B İştiraki'nin kendi uygulaması: sadece BISTIRAK tenant'ında kullanılabilir.</summary>
    private void SeedBPortal(CatalogApplication portal)
    {
        var yatirimci = Node(portal, null, "YATIRIMCI", "Yatırımcı İşlemleri");
        var rapor = Node(portal, yatirimci, "RAPOR", "Raporlar");
        var portfoy = Node(portal, rapor, "PORTFOY", "Portföy Raporu");
        var pr = Perm(portfoy, "read", "Portföy raporunu görüntüle", Severity.Low);
        var pe = Perm(portfoy, "export", "Portföy raporunu dışa aktar", Severity.Medium);
        Api(portfoy, "b-portfoy-rapor-api", "B Portföy Rapor API", ("GET", "/v1/portfolio-reports", pr, "Rapor"), ("GET", "/v1/portfolio-reports/export", pe, "Dışa aktar"));
    }

    private void SeedMobile(CatalogApplication mobil)
    {
        var musteri = Node(mobil, null, "MUSTERI", "Müşteri Kazanım");
        var onboarding = Node(mobil, musteri, "ONBOARDING", "Dijital Müşteri Edinimi");
        var kimlik = Node(mobil, onboarding, "KIMLIK", "Kimlik Doğrulama");
        var kc = Perm(kimlik, "create", "Sahada müşteri kimlik doğrulama", Severity.High);
        var kr = Perm(kimlik, "read", "Onboarding sorgula", Severity.Low);
        Api(kimlik, "mobil-onboarding-api", "Mobil Onboarding API", ("POST", "/v1/onboarding", kc, "Onboarding başlat"), ("GET", "/v1/onboarding/{id}", kr, "Durum"));
        var acilis = Node(mobil, onboarding, "HESAP_ACILIS", "Sahada Hesap Açılışı");
        var ac = Perm(acilis, "create", "Sahada hesap aç", Severity.High);
        Api(acilis, "mobil-hesap-api", "Mobil Hesap Açılış API", ("POST", "/v1/accounts", ac, "Hesap aç"));
        var randevu = Node(mobil, musteri, "RANDEVU", "Randevu");
        var sr = Node(mobil, randevu, "SUBE_RANDEVU", "Şube Randevusu");
        var rc = Perm(sr, "create", "Randevu oluştur", Severity.Low);
        var rr = Perm(sr, "read", "Randevu görüntüle", Severity.Low);
        Api(sr, "mobil-randevu-api", "Mobil Randevu API", ("POST", "/v1/appointments", rc, "Randevu"), ("GET", "/v1/appointments", rr, "Randevular"));
    }

    private void SeedNextral(CatalogApplication nextral)
    {
        var gise = Node(nextral, null, "GISE", "Gişe Uygulamaları");
        var nakit = Node(nextral, gise, "NAKIT_EKRAN", "Nakit Ekranları");
        Perm(nakit, "view", "Nakit ekranını aç", Severity.Low);
        Perm(nakit, "print", "Nakit fişi yazdır", Severity.Low);
        var scrNakit = Ui(nakit, null, UiElementKind.Screen, "SCR_NAKIT", "Nakit İşlemleri Ekranı", 1, "nextral.gise.nakit_ekran:view");
        Ui(nakit, scrNakit, UiElementKind.Button, "BTN_CEKIM", "Para Çek", 1, "anka.nakit.cekim.gise:create");
        Ui(nakit, scrNakit, UiElementKind.Button, "BTN_CEKIM_IPTAL", "Çekim İptal", 2, "anka.nakit.cekim.gise:cancel");
        Ui(nakit, scrNakit, UiElementKind.Button, "BTN_YATIRMA", "Para Yatır", 3, "anka.nakit.yatirma.gise:create");
        Ui(nakit, scrNakit, UiElementKind.Button, "BTN_GUN_SONU", "Kasa Gün Sonu", 4, "anka.nakit.kasa.gun_sonu:execute");
        Ui(nakit, scrNakit, UiElementKind.Button, "BTN_FIS", "Fiş Yazdır", 5, "nextral.gise.nakit_ekran:print");

        var odeme = Node(nextral, gise, "ODEME_EKRAN", "Ödeme Ekranları");
        Perm(odeme, "view", "Ödeme ekranını aç", Severity.Low);
        var scrOdeme = Ui(odeme, null, UiElementKind.Screen, "SCR_ODEME", "Ödeme İşlemleri Ekranı", 2, "nextral.gise.odeme_ekran:view");
        Ui(odeme, scrOdeme, UiElementKind.Button, "BTN_EFT", "EFT Gönder", 1, "anka.odeme.eft.giden:create");
        Ui(odeme, scrOdeme, UiElementKind.Button, "BTN_EFT_IPTAL", "EFT İptal", 2, "anka.odeme.eft.giden:cancel");
        Ui(odeme, scrOdeme, UiElementKind.Button, "BTN_FAST", "FAST Gönder", 3, "anka.odeme.fast.giden:create");
        Ui(odeme, scrOdeme, UiElementKind.Button, "BTN_HAVALE", "Havale", 4, "anka.odeme.havale.hesaplar_arasi:create");

        var hesap = Node(nextral, gise, "HESAP_EKRAN", "Hesap Ekranları");
        Perm(hesap, "view", "Hesap ekranını aç", Severity.Low);
        var scrHesap = Ui(hesap, null, UiElementKind.Screen, "SCR_HESAP", "Hesap İşlemleri Ekranı", 3, "nextral.gise.hesap_ekran:view");
        Ui(hesap, scrHesap, UiElementKind.Button, "BTN_VADESIZ_AC", "Vadesiz Hesap Aç", 1, "anka.hesap.vadesiz:create");
        Ui(hesap, scrHesap, UiElementKind.Button, "BTN_VADELI_AC", "Vadeli Hesap Aç", 2, "anka.hesap.vadeli:create");
        Ui(hesap, scrHesap, UiElementKind.Button, "BTN_KAMPANYA", "Kampanyalı Vadeli", 3, "anka.hesap.vadeli.kampanya:create");
        Ui(hesap, scrHesap, UiElementKind.Button, "BTN_VADELI_KAPAT", "Vadeli Kapat", 4, "anka.hesap.vadeli:close");

        var kredi = Node(nextral, null, "KREDI", "Kredi Uygulamaları");
        var krediEkran = Node(nextral, kredi, "KREDI_EKRAN", "Kredi Ekranları");
        Perm(krediEkran, "view", "Kredi ekranını aç", Severity.Low);
        var scrKredi = Ui(krediEkran, null, UiElementKind.Screen, "SCR_KREDI", "Kredi İşlemleri Ekranı", 4, "nextral.kredi.kredi_ekran:view");
        Ui(krediEkran, scrKredi, UiElementKind.Button, "BTN_BASVURU", "Başvuru Aç", 1, "anka.kredi.basvuru.bireysel:create");
        Ui(krediEkran, scrKredi, UiElementKind.Button, "BTN_ONAYLA", "Kredi Onayla", 2, "anka.kredi.onay.dosya:approve");
        Ui(krediEkran, scrKredi, UiElementKind.Button, "BTN_KULLANDIR", "Kullandır", 3, "anka.kredi.kullandirim.dosya:execute");

        var genel = Node(nextral, null, "GENEL", "Genel");
        var duyuru = Node(nextral, genel, "DUYURU", "Duyurular");
        Perm(duyuru, "view", "Duyuruları görüntüle", Severity.Low);
        Ui(duyuru, null, UiElementKind.Menu, "MNU_DUYURU", "Duyurular", 9, "nextral.genel.duyuru:view");
        var raporEkran = Node(nextral, genel, "RAPOR_EKRAN", "Raporlar");
        Perm(raporEkran, "view", "Rapor ekranını aç", Severity.Low);
        var mnuRapor = Ui(raporEkran, null, UiElementKind.Menu, "MNU_RAPOR", "Raporlar", 8, "nextral.genel.rapor_ekran:view");
        Ui(raporEkran, mnuRapor, UiElementKind.Button, "BTN_RAPOR_EXPORT", "Şube Raporu Dışa Aktar", 1, "anka.rapor.sube.gunluk:export");
        Ui(raporEkran, mnuRapor, UiElementKind.Button, "BTN_GM_RAPOR", "GM Operasyon Raporu", 2, "anka.rapor.gm.operasyon:read");
    }

    // ================================ Policy yardımcıları ================================

    private Policy PolicyOf(Tenant tenant, string code, string name, string description, PolicyMode mode = PolicyMode.Enforce)
    {
        var p = new Policy { Tenant = tenant, Code = code, Name = name, Description = description, Mode = mode, CombiningAlgorithm = CombiningAlgorithm.AllRulesMustPass };
        db.Policies.Add(p);
        return p;
    }

    private static void ClientTarget(Policy p, InclusionMode mode, Client client) =>
        p.ClientTargets.Add(new PolicyClientTarget { Mode = mode, Client = client });

    private static void Obligation(Policy p, string code, params (string Key, string Value)[] parameters) =>
        p.Obligations.Add(new PolicyObligation
        {
            Code = code, Order = p.Obligations.Count,
            Parameters = parameters.Select(x => new PolicyObligationParameter { Key = x.Key, Value = x.Value }).ToList()
        });

    private static void Target(Policy p, InclusionMode mode, TargetType type, object? target, params string[] actions) =>
        p.Targets.Add(new PolicyTarget
        {
            Mode = mode, TargetType = type,
            Application = target as CatalogApplication, CatalogNode = target as CatalogNode, Permission = target as Permission,
            Actions = actions.Length == 0 ? null : string.Join(',', actions.Select(Codes.Lower).Distinct(StringComparer.Ordinal))
        });

    private sealed record Spec(ConditionKind Kind, string? Type, (string Key, string Value)[] Params, Spec[] Children, SharedCondition? Ref = null);

    private static Spec Pred(string type, params (string, string)[] ps) => new(ConditionKind.Predicate, type, ps, []);
    private static Spec Not(Spec s) => new(ConditionKind.Not, null, [], [s]);
    private static Spec All(params Spec[] s) => new(ConditionKind.AllOf, null, [], s);
    private static Spec Any(params Spec[] s) => new(ConditionKind.AnyOf, null, [], s);
    private static Spec Ref(SharedCondition sc) => new(ConditionKind.Reference, null, [], [], sc);

    private void RuleOf(Policy p, string code, string name, int order, string reason, Spec condition)
    {
        var r = new Rule { Policy = p, Code = code, Name = name, Order = order, ReasonCode = reason };
        db.Rules.Add(r);
        Build(condition, r, null, null, 0);
    }

    private SharedCondition Shared(string code, string name, Spec condition, ConditionScope scope = ConditionScope.Global, string? domain = null)
    {
        var sc = new SharedCondition { Code = code, Name = name, Scope = scope, Domain = domain };
        db.SharedConditions.Add(sc);
        Build(condition, null, sc, null, 0);
        return sc;
    }

    private void Build(Spec s, Rule? rule, SharedCondition? owner, RuleCondition? parent, int order)
    {
        var node = new RuleCondition
        {
            Rule = rule, SharedCondition = owner, Parent = parent, Kind = s.Kind, Order = order,
            ConditionType = s.Type is null ? null : _types.TryGetValue(s.Type, out var t) ? t : throw new InvalidOperationException($"Seed: condition tipi yok: {s.Type}"),
            ReferencedSharedCondition = s.Ref,
            Parameters = s.Params.Select(x => new ConditionParameter { Key = x.Key, Value = x.Value }).ToList()
        };
        db.RuleConditions.Add(node);
        for (var i = 0; i < s.Children.Length; i++) Build(s.Children[i], rule, owner, node, i);
    }
}
