using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Abstractions;
using Yetki.Infrastructure;
using Yetki.Infrastructure.Persistence;
using Yetki.Infrastructure.Services;
using Yetki.SampleData;

// Kullanım (Yetki-Engine klasöründen):
//   dotnet run --project tools/Yetki.SampleData                 → src/Yetki.Api/yedek.db
//   dotnet run --project tools/Yetki.SampleData -- <yol.db>     → verilen dosya
// Dosya varsa silinir ve sıfırdan kurulur: migration'lar + condition tipi kataloğu + örnek veri.
// API'nin kullandığı yetki.db'ye DOKUNMAZ. Geri dönmek için: API kapalıyken yedek.db'yi yetki.db olarak kopyalayın.

var target = args.Length > 0 ? Path.GetFullPath(args[0]) : Path.Combine(FindEngineRoot(), "src", "Yetki.Api", "yedek.db");
if (Path.GetFileName(target).Equals("yetki.db", StringComparison.OrdinalIgnoreCase))
{
    Console.Error.WriteLine("Güvenlik: yetki.db (çalışan veritabanı) hedeflenemez. yedek.db veya başka bir ad kullanın.");
    return 1;
}

foreach (var f in new[] { target, target + "-journal", target + "-wal", target + "-shm" })
    if (File.Exists(f)) File.Delete(f);

var config = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
{
    ["Persistence:Provider"] = "Sqlite",
    ["ConnectionStrings:Yetki"] = $"Data Source={target}"
}).Build();

var services = new ServiceCollection();
services.AddLogging();
services.AddYetkiInfrastructure(config);
services.AddScoped<ICurrentActor>(_ => new SystemActor("ornek-veri"));
await using (var provider = services.BuildServiceProvider())
{
    await provider.InitializeYetkiDatabaseAsync();
    await using var scope = provider.CreateAsyncScope();
    var db = scope.ServiceProvider.GetRequiredService<YetkiDbContext>();
    await new SampleDataBuilder(db, scope.ServiceProvider.GetRequiredService<IClock>()).BuildAsync();
    // Başlangıç: RACF/LDAP'taki mevcut durum = olması gereken (baseline); sonraki değişiklikler sadece fark üretir
    await scope.ServiceProvider.GetRequiredService<Yetki.Application.External.ExternalProvisioningService>().BaselineAsync(default);

    Console.WriteLine($"Örnek veri yazıldı: {target}");
    Console.WriteLine($"  {db.Tenants.Count()} tenant, {db.OrgUnits.Count()} birim, {db.Users.Count()} kullanıcı, {db.Roles.Count()} rol, {db.Groups.Count()} grup");
    Console.WriteLine($"  {db.Applications.Count()} uygulama, {db.CatalogNodes.Count()} düğüm, {db.Permissions.Count()} permission, {db.ApiResources.Count()} API, {db.ApiEndpoints.Count()} endpoint, {db.UiElements.Count()} UI öğesi");
    Console.WriteLine($"  {db.Clients.Count()} client, {db.Policies.Count()} policy, {db.SharedConditions.Count()} ortak koşul, {db.SodRules.Count()} SoD kuralı");
    Console.WriteLine($"  {db.ExternalPermissions.Count()} dış yetki, {db.ExternalDependencies.Count()} dış bağımlılık, {db.ExternalPermissionRequirements.Count()} zincir, {db.UserExternalGrants.Count()} kullanıcı dış yetkisi (baseline)");
}
SqliteConnection.ClearAllPools(); // dosya kilidini bırak
return 0;

static string FindEngineRoot()
{
    for (var dir = new DirectoryInfo(Directory.GetCurrentDirectory()); dir is not null; dir = dir.Parent)
        if (File.Exists(Path.Combine(dir.FullName, "Yetki.sln"))) return dir.FullName;
    for (var dir = new DirectoryInfo(AppContext.BaseDirectory); dir is not null; dir = dir.Parent)
        if (File.Exists(Path.Combine(dir.FullName, "Yetki.sln"))) return dir.FullName;
    throw new InvalidOperationException("Yetki.sln bulunamadı; hedef dosya yolunu argüman olarak verin.");
}
