using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Abstractions;
using Yetki.Application.Definitions;
using Yetki.Application.Model;
using Yetki.Domain.Catalog;
using Yetki.Domain.Common;

namespace Yetki.Tests;

public class StructureExplorerTests
{
    [Fact]
    public async Task Campus_users_are_paged_and_belong_to_selected_tenant_only()
    {
        await using var host = await TestHost.CreateAsync();
        await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<IYetkiDbContext>();
            var explorer = sp.GetRequiredService<StructureExplorer>();
            foreach (var tenant in await db.Tenants.AsNoTracking().ToListAsync())
            {
                var users = await explorer.BrowseAsync("tenant", tenant.Id, relation: "users", pageSize: 3);
                Assert.Equal(await db.Users.CountAsync(u => u.TenantId == tenant.Id), users.Total);
                Assert.True(users.Items.Count <= 3);
                Assert.All(users.Items, u => { Assert.Equal("user", u.Kind); Assert.Equal(tenant.Id, u.TenantId); });
            }
        });
    }

    [Fact]
    public async Task Permission_picker_searches_across_platforms_within_tenant_scope()
    {
        await using var host = await TestHost.CreateAsync();
        await host.WithAsync(async sp =>
        {
            var model = await sp.GetRequiredService<AuthorizationModelProvider>().GetCurrentAsync();
            var explorer = sp.GetRequiredService<StructureExplorer>();
            var bank = model.Tenants.Values.Single(t => t.ParentId == null);
            var child = model.Tenants.Values.First(t => t.ParentId == bank.Id);
            var childPermission = model.Permissions.Values.First(p => p.App.TenantId == child.Id);
            var bankResults = await explorer.BrowseAsync("permissionCatalog", tenantId: bank.Id, q: childPermission.Code);
            Assert.Empty(bankResults.Items);
            var childResults = await explorer.BrowseAsync("permissionCatalog", tenantId: child.Id, q: childPermission.Code);
            Assert.Equal(childPermission.Id, Assert.Single(childResults.Items).Id);
            await Assert.ThrowsAsync<ValidationException>(() => explorer.BrowseAsync("permissionCatalog"));
        });
    }

    [Fact]
    public async Task Tenant_scope_and_direct_children_are_preserved()
    {
        await using var host = await TestHost.CreateAsync();
        await host.WithAsync(async sp =>
        {
            var explorer = sp.GetRequiredService<StructureExplorer>();
            var model = await sp.GetRequiredService<AuthorizationModelProvider>().GetCurrentAsync();
            foreach (var tenant in model.Tenants.Values)
            {
                var platforms = await explorer.BrowseAsync("tenant", tenant.Id);
                var expected = model.Apps.Values.Where(a => model.IsAvailableIn(a.TenantId, tenant.Id)).Select(a => a.Id).Order().ToArray();
                Assert.Equal(expected, platforms.Items.Select(a => a.Id).Order());
                foreach (var app in platforms.Items)
                {
                    var domains = await explorer.BrowseAsync("application", app.Id, tenant.Id);
                    Assert.All(domains.Items, n => { Assert.Equal("Catalog Level", n.Type); Assert.Null(n.ParentId); Assert.Equal(app.Id, n.ApplicationId); });
                }
            }
            var bank = model.Tenants.Values.Single(t => t.ParentId == null);
            var subsidiaryApp = model.Apps.Values.First(a => a.TenantId != bank.Id);
            await Assert.ThrowsAsync<ValidationException>(() => explorer.BrowseAsync("application", subsidiaryApp.Id, bank.Id));
        });
    }

    [Fact]
    public async Task Large_ui_collection_is_paged_and_search_is_scoped()
    {
        await using var host = await TestHost.CreateAsync();
        await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<IYetkiDbContext>();
            var resource = await db.CatalogNodes.FirstAsync();
            var screen = new UiElement { CatalogNodeId = resource.Id, Code = "PAGING_SCREEN", Name = "Paging screen", Kind = UiElementKind.Screen };
            db.UiElements.Add(screen); await db.SaveChangesAsync(default);
            db.UiElements.AddRange(Enumerable.Range(1, 1500).Select(i => new UiElement { CatalogNodeId = resource.Id, ParentId = screen.Id, Code = $"PAGED_{i:D4}", Name = $"Control {i:D4}", Kind = UiElementKind.Button }));
            await db.SaveChangesAsync(default);
            var explorer = sp.GetRequiredService<StructureExplorer>();
            var first = await explorer.BrowseAsync("ui", screen.Id);
            var second = await explorer.BrowseAsync("ui", screen.Id, page: 2);
            Assert.Equal(1500, first.Total); Assert.Equal(12, first.Items.Count);
            Assert.Empty(first.Items.Select(x => x.Id).Intersect(second.Items.Select(x => x.Id)));
            var search = await explorer.BrowseAsync("ui", screen.Id, q: "paged_1500");
            Assert.Single(search.Items); Assert.Equal("PAGED_1500", search.Items[0].Code);
            var last = await explorer.BrowseAsync("ui", screen.Id, page: 1000);
            Assert.Equal(125, last.Page); Assert.Equal(12, last.Items.Count);
            await Assert.ThrowsAsync<ValidationException>(() => explorer.BrowseAsync(pageSize: 1000));
        });
    }

    [Fact]
    public async Task Endpoint_permission_and_policy_drilldown_uses_engine_matches()
    {
        await using var host = await TestHost.CreateAsync();
        await host.WithAsync(async sp =>
        {
            var model = await sp.GetRequiredService<AuthorizationModelProvider>().GetCurrentAsync();
            var explorer = sp.GetRequiredService<StructureExplorer>();
            var endpoint = model.Data.Endpoints.First(e => e.PermissionId != null);
            var permission = model.Permissions[endpoint.PermissionId!.Value];
            var ep = await explorer.BrowseAsync("endpoint", endpoint.Id, permission.App.TenantId);
            Assert.Equal("permissions", ep.Relation); Assert.Equal(permission.Id, Assert.Single(ep.Items).Id);
            var policies = await explorer.BrowseAsync("permission", permission.Id, permission.App.TenantId, "policies", pageSize: 48);
            Assert.Equal(model.GetApplicablePolicies(permission.Id, permission.App.TenantId).Applied.Select(x => x.Policy.Row.Id).Order(), policies.Items.Select(x => x.Id).Order());
            foreach (var policy in policies.Items)
            {
                var rules = await explorer.BrowseAsync("policy", policy.Id, permission.App.TenantId, "rules");
                Assert.All(rules.Items, x => { Assert.Equal("rule", x.Kind); Assert.False(string.IsNullOrEmpty(x.Description)); });
            }
        });
    }

    [Theory]
    [InlineData("endpoint")]
    [InlineData("ui")]
    public async Task Mapping_preserves_metadata_and_rejects_unknown_permission(string kind)
    {
        await using var host = await TestHost.CreateAsync();
        await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<IYetkiDbContext>();
            var service = sp.GetRequiredService<StructureService>();
            object entity = kind == "endpoint" ? await db.ApiEndpoints.FirstAsync() : await db.UiElements.FirstAsync();
            var before = System.Text.Json.JsonSerializer.SerializeToNode(entity)!;
            var id = before["Id"]!.GetValue<int>();
            var pid = await db.Permissions.Select(x => x.Id).FirstAsync();
            await service.MapPermissionAsync(kind, id, pid, default);
            var after = System.Text.Json.JsonSerializer.SerializeToNode(entity)!;
            before["PermissionId"] = pid;
            Assert.True(System.Text.Json.Nodes.JsonNode.DeepEquals(before, after));
            await Assert.ThrowsAsync<NotFoundException>(() => service.MapPermissionAsync(kind, id, int.MaxValue, default));
            await service.MapPermissionAsync(kind, id, null, default);
            var unmapped = await sp.GetRequiredService<StructureExplorer>().BrowseAsync(kind, id, relation: "permissions");
            Assert.Empty(unmapped.Items); Assert.NotNull(unmapped.Notice);
        });
    }
}
