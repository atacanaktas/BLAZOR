using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Yetki.Application.Abstractions;
using Yetki.Application.Definitions;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine;
using Yetki.Domain.Common;

namespace Yetki.Tests;

/// <summary>Katalog hedefleme mirası, manifest içe aktarma ve client (OAuth) kapsamı.</summary>
public class CatalogAndClientTests
{
    [Fact]
    public async Task Ayni_API_icindeki_bagimsiz_endpointler_ayni_action_ile_farkli_permission_alabilir()
    {
        await using var host = await TestHost.CreateAsync();
        var node = await host.NodeIdAsync("ANKA/MUSTERI/BILGI/PROFIL");
        var api = await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().CreateApiAsync(
            new ApiUpsert { CatalogNodeId = node, Code = "profil-operation-test-api", Name = "Profil Operation Test API" }, default));
        var detail = await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().AddEndpointAsync(api.Id,
            new EndpointUpsert { Method = "GET", Path = "/v1/profiles/{id}", OperationId = "GetProfile" }, default));
        var preferences = await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().AddEndpointAsync(api.Id,
            new EndpointUpsert { Method = "GET", Path = "/v1/profiles/{id}/preferences", OperationId = "GetProfilePreferences" }, default));

        var detailPermission = await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().CreatePermissionAsync(
            new PermissionUpsert { ApiEndpointId = detail.Id, Action = "read", Name = "Profil görüntüle" }, default));
        var preferencesPermission = await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().CreatePermissionAsync(
            new PermissionUpsert { ApiEndpointId = preferences.Id, Action = "read", Name = "Profil tercihlerini görüntüle" }, default));

        Assert.NotEqual(detailPermission.Code, preferencesPermission.Code);
        Assert.EndsWith(".getprofile:read", detailPermission.Code);
        Assert.EndsWith(".getprofilepreferences:read", preferencesPermission.Code);
        var model = await host.ModelAsync();
        Assert.Equal(detailPermission.Id, model.Data.Endpoints.Single(e => e.Id == detail.Id).PermissionId);
        Assert.Equal(preferencesPermission.Id, model.Data.Endpoints.Single(e => e.Id == preferences.Id).PermissionId);
    }

    [Fact]
    public async Task Duguma_yeni_eklenen_permission_policyyi_kendiliginden_miras_alir()
    {
        await using var host = await TestHost.CreateAsync();
        var node = await host.NodeIdAsync("ANKA/NAKIT/KASA/GUN_SONU");
        var perm = await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().CreatePermissionAsync(
            new PermissionUpsert { CatalogNodeId = node, Action = "approve", Name = "Gün sonu onayı" }, default));

        Assert.Equal("anka.nakit.kasa.gun_sonu:approve", perm.Code);
        var m = await host.ModelAsync();
        var applied = m.GetApplicablePolicies(perm.Id, m.Tenants.Values.Single(o => o.Code == "ABANK").Id).Applied;
        Assert.Contains(applied, a => a.Policy.Row.Code == "NAKIT_MESAI" && a.MatchedBy == "Düğüm ANKA/NAKIT");
        Assert.Contains(applied, a => a.Policy.Row.Code == "KURUMSAL_AG" && a.MatchedBy == "Tümü");
    }

    [Fact]
    public async Task Uygulama_hedefi_ve_uygulama_istisnasi()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var tenant = m.Tenants.Values.Single(o => o.Code == "ABANK").Id;
        var mobile = m.GetApplicablePolicies(m.PermissionIdByCode["mobil_sube.musteri.onboarding.kimlik:create"], tenant);

        Assert.Contains(mobile.Applied, a => a.Policy.Row.Code == "MOBIL_CIHAZ" && a.MatchedBy == "Uygulama MOBIL_SUBE");
        Assert.Contains(mobile.Excluded, e => e.Policy.Row.Code == "KURUMSAL_AG" && e.ExcludedBy == "Uygulama MOBIL_SUBE");
    }

    [Fact]
    public async Task Policy_hedefi_eklenince_versiyon_artar_ve_karar_degisir()
    {
        await using var host = await TestHost.CreateAsync();
        host.Clock.UtcNow = new DateTime(2026, 9, 22, 19, 0, 0, DateTimeKind.Utc); // 22:00 İstanbul
        var before = await host.EvaluateAsync("zeynep.acar", "anka.odeme.fast.giden:create");
        Assert.Equal(DecisionType.Permit, before.Decision);

        var policy = await host.PolicyIdAsync("NAKIT_MESAI");
        var node = await host.NodeIdAsync("ANKA/ODEME");
        await host.WithAsync(sp => sp.GetRequiredService<PolicyManagementService>().AddTargetAsync(policy,
            new TargetUpsert { Mode = InclusionMode.Include, TargetType = TargetType.CatalogNode, TargetId = node }, default));

        var after = await host.EvaluateAsync("zeynep.acar", "anka.odeme.fast.giden:create");
        Assert.Equal("OUTSIDE_BUSINESS_HOURS", after.ReasonCode);
        Assert.Contains(after.Policies, p => p.Code == "NAKIT_MESAI" && p.MatchedBy == "Düğüm ANKA/ODEME" && p.Version == 2);
    }

    [Fact]
    public async Task Resource_policy_hedefindeki_action_filtresi_yalnizca_secilen_isleme_uygulanir()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var tenant = m.Tenants.Values.Single(o => o.Code == "ABANK").Id;
        var create = m.GetApplicablePolicies(m.PermissionIdByCode["anka.nakit.cekim.gise:create"], tenant);
        var read = m.GetApplicablePolicies(m.PermissionIdByCode["anka.nakit.cekim.gise:read"], tenant);

        Assert.Contains(create.Applied, p => p.Policy.Row.Code == "NAKIT_CEKIM_LIMIT"
            && p.MatchedBy == "Düğüm ANKA/NAKIT/CEKIM/GISE · Action: create");
        Assert.DoesNotContain(read.Applied, p => p.Policy.Row.Code == "NAKIT_CEKIM_LIMIT");
    }

    [Fact]
    public async Task Client_eylem_filtreli_kapsam_ve_bilinmeyen_client()
    {
        await using var host = await TestHost.CreateAsync();
        // mobil kanal: MOBIL_KANAL policy'si cihaz uyumluluğu ister (kanal hedefli)
        var read = await host.EvaluateAsync("elif.sahin", "anka.musteri.bilgi.profil:read", "mobil-sube-tablet", ("BranchCode", "101"), ("DeviceCompliant", "true"));
        var update = await host.EvaluateAsync("elif.sahin", "anka.musteri.bilgi.profil:update", "mobil-sube-tablet", ("BranchCode", "101"));
        var unknown = await host.EvaluateAsync("elif.sahin", "anka.musteri.bilgi.profil:read", "bilinmeyen-app");

        Assert.Equal(DecisionType.Permit, read.Decision);
        Assert.Contains("[read]", read.ClientAllowedPermission);
        Assert.Equal("CLIENT_PERMISSION_NOT_ALLOWED", update.ReasonCode);
        Assert.Equal("CLIENT_UNKNOWN", unknown.ReasonCode);
    }

    [Fact]
    public async Task Token_scope_permission_ile_birebir_eslesir_ve_case_sensitive_calısır()
    {
        await using var host = await TestHost.CreateAsync(s => s.Configure<AuthorizationEngineOptions>(o => o.RequireGrantedScopes = true));
        var permission = "anka.musteri.bilgi.profil:read";
        var allowed = await host.WithAsync(sp => sp.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(new AuthorizationRequest
        {
            Subject = new SubjectInfo { Id = "elif.sahin" }, Client = "nextral-desktop", Permission = permission,
            Scopes = [permission], Context = new() { ["BranchCode"] = "101", ["IpAddress"] = TestHost.BankIp }
        }, new EvaluationOptions { WriteAudit = false }));
        var missing = await host.WithAsync(sp => sp.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(new AuthorizationRequest
        {
            Subject = new SubjectInfo { Id = "elif.sahin" }, Client = "nextral-desktop", Permission = permission,
            Scopes = ["anka.musteri.bilgi.profil:update"], Context = new() { ["BranchCode"] = "101", ["IpAddress"] = TestHost.BankIp }
        }, new EvaluationOptions { WriteAudit = false }));
        var wrongCase = await host.WithAsync(sp => sp.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(new AuthorizationRequest
        {
            Subject = new SubjectInfo { Id = "elif.sahin" }, Client = "nextral-desktop", Permission = permission,
            Scopes = [permission.ToUpperInvariant()], Context = new() { ["BranchCode"] = "101", ["IpAddress"] = TestHost.BankIp }
        }, new EvaluationOptions { WriteAudit = false }));

        Assert.Equal(DecisionType.Permit, allowed.Decision);
        Assert.Equal(permission, allowed.MatchedScope);
        Assert.Equal("INSUFFICIENT_SCOPE", missing.ReasonCode);
        Assert.Equal("INSUFFICIENT_SCOPE", wrongCase.ReasonCode);
    }

    [Fact]
    public async Task Scope_zorunluysa_scope_olmayan_token_reddedilir()
    {
        await using var host = await TestHost.CreateAsync(s => s.Configure<AuthorizationEngineOptions>(o => o.RequireGrantedScopes = true));
        var d = await host.EvaluateAsync("ayse.yilmaz", "anka.nakit.cekim.gise:read", "nextral-desktop");
        Assert.Equal("TOKEN_SCOPE_REQUIRED", d.ReasonCode);
    }

    [Fact]
    public async Task Client_zorunlu_ayari_clientsiz_istegi_reddeder()
    {
        await using var host = await TestHost.CreateAsync(s => s.Configure<AuthorizationEngineOptions>(o => o.RequireClient = true));
        var d = await host.EvaluateAsync("ayse.yilmaz", "anka.nakit.cekim.gise:read");
        Assert.Equal("CLIENT_REQUIRED", d.ReasonCode);
    }

    [Fact]
    public async Task Manifest_ice_aktarma_idempotent_ve_eslenmemisleri_raporlar()
    {
        await using var host = await TestHost.CreateAsync();
        var manifest = new ServiceManifest
        {
            Application = "ANKA", CatalogPath = "KART/SANAL/ONLINE",
            Api = new ManifestApi { Code = "sanal-kart-api", Name = "Sanal Kart API" },
            Endpoints =
            [
                new ManifestEndpoint { Method = "POST", Path = "/v1/virtual-cards", Action = "create" },
                new ManifestEndpoint { Method = "GET", Path = "/v1/virtual-cards/{id}", Action = "read" },
                new ManifestEndpoint { Method = "DELETE", Path = "/v1/virtual-cards/{id}" }
            ]
        };
        var first = await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().ImportManifestAsync(manifest, default));
        var second = await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().ImportManifestAsync(manifest, default));

        Assert.Equal(3, first.CreatedNodes);
        Assert.Equal(2, first.CreatedPermissions);
        Assert.Equal(3, first.CreatedEndpoints);
        Assert.Equal(["DELETE /v1/virtual-cards/{id}"], first.UnmappedEndpoints);
        Assert.Equal(0, second.CreatedPermissions + second.CreatedEndpoints + second.UpdatedEndpoints + second.CreatedNodes);

        // Yeni API KURUMSAL_AG (Tümü) policy'sini kendiliğinden alır; eşlenmemiş endpoint reddedilir
        var denied = await host.WithAsync(sp => sp.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(new AuthorizationRequest
        {
            Subject = new SubjectInfo { Id = "ali.demir" },
            Endpoint = new EndpointInfo { Api = "sanal-kart-api", Method = "DELETE", Path = "/v1/virtual-cards/9" }
        }, new EvaluationOptions { WriteAudit = false }));
        Assert.Equal("ENDPOINT_NOT_MAPPED", denied.ReasonCode);
    }

    [Fact]
    public async Task API_resource_olan_modul_veya_alt_module_eklenir_domain_altina_eklenmez()
    {
        await using var host = await TestHost.CreateAsync();
        var domain = await host.NodeIdAsync("ANKA/MUSTERI");              // domain
        var module = await host.NodeIdAsync("ANKA/MUSTERI/BILGI");        // modül
        var sub = await host.NodeIdAsync("ANKA/MUSTERI/BILGI/PROFIL");    // alt modül

        var rootLevelApi = await host.WithAsync(sp =>
            sp.GetRequiredService<CatalogService>().CreateApiAsync(new ApiUpsert { CatalogNodeId = domain, Code = "musteri-domain-api", Name = "Müşteri API" }, default));
        Assert.Equal("api://anka/musteri-domain-api", rootLevelApi.Audience);

        var moduleApi = await host.WithAsync(sp =>
            sp.GetRequiredService<CatalogService>().CreateApiAsync(new ApiUpsert { CatalogNodeId = module, Code = "musteri-bilgi-api", Name = "Müşteri Bilgi API" }, default));
        Assert.Equal("api://anka/musteri-bilgi-api", moduleApi.Audience);

        var created = await host.WithAsync(sp =>
            sp.GetRequiredService<CatalogService>().CreateApiAsync(new ApiUpsert { CatalogNodeId = sub, Code = "musteri-profil-v2-api", Name = "Müşteri API" }, default));
        Assert.Equal("api://anka/musteri-profil-v2-api", created.Audience);

        var shallow = new ServiceManifest { Application = "ANKA", CatalogPath = "MUSTERI/BILGI", Api = new ManifestApi { Code = "x-api", Name = "X" } };
        var report = await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().ImportManifestAsync(shallow, default));
        Assert.Equal("x-api", report.Api);
    }

    [Fact]
    public async Task Katalog_bes_seviye_ve_tenant_application_level_altinda_APIyi_destekler()
    {
        await using var host = await TestHost.CreateAsync();
        var model = await host.ModelAsync();
        var tenantId = model.Tenants.Values.Single(t => t.Code == "ABANK").Id;
        var appId = model.Apps.Values.Single(a => a.Code == "ANKA").Id;

        await host.WithAsync(async sp =>
        {
            var catalog = sp.GetRequiredService<CatalogService>();
            int? parentId = null;
            for (var depth = 1; depth <= 5; depth++)
            {
                var level = await catalog.CreateNodeAsync(new NodeUpsert
                {
                    TenantId = tenantId, ParentId = parentId, Code = $"FLEX{depth}", Name = $"Level {depth}"
                }, default);
                parentId = level.Id;
            }

            var levelApi = await catalog.CreateApiAsync(new ApiUpsert
                { CatalogNodeId = parentId, Code = "flex-level-api", Name = "Level API" }, default);
            Assert.Equal("api://abank/flex-level-api", levelApi.Audience);

            var appApi = await catalog.CreateApiAsync(new ApiUpsert
                { ApplicationId = appId, Code = "flex-app-api", Name = "Application API" }, default);
            Assert.Equal("api://anka/flex-app-api", appApi.Audience);

            var tenantApi = await catalog.CreateApiAsync(new ApiUpsert
                { TenantId = tenantId, Code = "flex-tenant-api", Name = "Tenant API" }, default);
            var endpoint = await catalog.AddEndpointAsync(tenantApi.Id,
                new EndpointUpsert { Method = "GET", Path = "/v1/status", OperationId = "getStatus" }, default);
            var permission = await catalog.CreatePermissionAsync(new PermissionUpsert
                { ApiEndpointId = endpoint.Id, Action = "read", Name = "Status görüntüle" }, default);

            Assert.Null(permission.CatalogNodeId);
            Assert.Null(permission.ApplicationId);
            Assert.Equal("abank.flex-tenant-api.getstatus:read", permission.Code);
        });
    }

    [Fact]
    public async Task Catalog_sahipligi_team_tablosundan_ve_identity_adapter_userindan_secilir()
    {
        await using var host = await TestHost.CreateAsync();
        var model = await host.ModelAsync();
        var tenantId = model.Tenants.Values.Single(t => t.Code == "ABANK").Id;
        var userId = model.Users.Values.Single(u => u.UserName == "ali.demir").Id;

        await host.WithAsync(async sp =>
        {
            var team = await sp.GetRequiredService<OwnershipTeamService>().CreateAsync(new OwnershipTeamUpsert
            {
                TenantId = tenantId, Code = "CATALOG_OWNER", Name = "Catalog Owner Team"
            }, default);
            var node = await sp.GetRequiredService<CatalogService>().CreateNodeAsync(new NodeUpsert
            {
                TenantId = tenantId, Code = "OWNED", Name = "Owned Level",
                OwnerTeamId = team.Id, OwnerUserId = userId
            }, default);

            Assert.Equal(team.Id, node.OwnerTeamId);
            Assert.Equal(userId, node.OwnerUserId);
            Assert.Equal("Catalog Owner Team", node.OwnerTeam);
        });
    }

    [Fact]
    public async Task Ownership_team_opsiyonel_ust_ekip_secebilir_farkli_tenanttan_ve_kendinden_secemez()
    {
        await using var host = await TestHost.CreateAsync();
        var model = await host.ModelAsync();
        var abank = model.Tenants.Values.Single(t => t.Code == "ABANK").Id;
        var bistirak = model.Tenants.Values.Single(t => t.Code == "BISTIRAK").Id;

        await host.WithAsync(async sp =>
        {
            var service = sp.GetRequiredService<OwnershipTeamService>();
            var parent = await service.CreateAsync(new OwnershipTeamUpsert
            {
                TenantId = abank, Code = "PARENT_TEAM", Name = "Parent Team"
            }, default);

            var child = await service.CreateAsync(new OwnershipTeamUpsert
            {
                TenantId = abank, ParentId = parent.Id, Code = "CHILD_TEAM", Name = "Child Team"
            }, default);
            Assert.Equal(parent.Id, child.ParentId);

            await Assert.ThrowsAsync<ValidationException>(() => service.CreateAsync(new OwnershipTeamUpsert
            {
                TenantId = bistirak, ParentId = parent.Id, Code = "CROSS_TENANT_CHILD", Name = "Cross Tenant Child"
            }, default));

            await Assert.ThrowsAsync<ValidationException>(() => service.UpdateAsync(child.Id, new OwnershipTeamUpsert
            {
                TenantId = abank, ParentId = child.Id, Code = child.Code, Name = child.Name
            }, default));
        });
    }

    [Fact]
    public async Task Kullanimda_olan_ownership_team_silinemez_bosta_olan_silinebilir()
    {
        await using var host = await TestHost.CreateAsync();
        var model = await host.ModelAsync();
        var abank = model.Tenants.Values.Single(t => t.Code == "ABANK").Id;

        await host.WithAsync(async sp =>
        {
            var service = sp.GetRequiredService<OwnershipTeamService>();
            var parent = await service.CreateAsync(new OwnershipTeamUpsert
            {
                TenantId = abank, Code = "DELETE_PARENT", Name = "Delete Parent"
            }, default);
            await service.CreateAsync(new OwnershipTeamUpsert
            {
                TenantId = abank, ParentId = parent.Id, Code = "DELETE_CHILD", Name = "Delete Child"
            }, default);

            var ex = await Assert.ThrowsAsync<ConflictException>(() => service.DeleteAsync(parent.Id, default));
            Assert.Contains("kullanımda", ex.Message);

            var standalone = await service.CreateAsync(new OwnershipTeamUpsert
            {
                TenantId = abank, Code = "DELETE_STANDALONE", Name = "Delete Standalone"
            }, default);
            await service.DeleteAsync(standalone.Id, default);

            var db = sp.GetRequiredService<IYetkiDbContext>();
            Assert.False(await db.OwnershipTeams.AnyAsync(t => t.Id == standalone.Id));
        });
    }

    [Fact]
    public async Task Kullanimda_olan_katalog_dugumu_silinemez_bos_dugum_silinebilir()
    {
        await using var host = await TestHost.CreateAsync();
        var model = await host.ModelAsync();
        var tenantId = model.Tenants.Values.Single(t => t.Code == "ABANK").Id;
        var appId = model.Data.Applications.Single(a => a.Code == "ANKA").Id;

        await host.WithAsync(async sp =>
        {
            var catalog = sp.GetRequiredService<CatalogService>();
            var parent = await catalog.CreateNodeAsync(new NodeUpsert
            {
                TenantId = tenantId, ApplicationId = appId, Code = "DELETE_TEST_PARENT", Name = "Delete Test Parent"
            }, default);
            var child = await catalog.CreateNodeAsync(new NodeUpsert
            {
                TenantId = tenantId, ApplicationId = appId, ParentId = parent.Id, Code = "DELETE_TEST_CHILD", Name = "Delete Test Child"
            }, default);

            var ex = await Assert.ThrowsAsync<ConflictException>(() => catalog.DeleteNodeAsync(parent.Id, default));
            Assert.Contains("kullanımda", ex.Message);

            await catalog.DeleteNodeAsync(child.Id, default);
            await catalog.DeleteNodeAsync(parent.Id, default);

            var db = sp.GetRequiredService<IYetkiDbContext>();
            Assert.False(await db.CatalogNodes.AnyAsync(n => n.Id == parent.Id || n.Id == child.Id));
        });
    }

    [Fact]
    public async Task Kullanimda_olan_api_ve_endpoint_silinemez_bos_olan_silinebilir()
    {
        await using var host = await TestHost.CreateAsync();
        var model = await host.ModelAsync();
        var tenantId = model.Tenants.Values.Single(t => t.Code == "ABANK").Id;
        var appId = model.Data.Applications.Single(a => a.Code == "ANKA").Id;

        await host.WithAsync(async sp =>
        {
            var catalog = sp.GetRequiredService<CatalogService>();
            var apiRes = await catalog.CreateApiAsync(new ApiUpsert
            {
                TenantId = tenantId, ApplicationId = appId, Code = "delete-test-api", Name = "Delete Test API"
            }, default);
            var endpoint = await catalog.AddEndpointAsync(apiRes.Id, new EndpointUpsert
            {
                Method = "GET", Path = "/v1/delete-test"
            }, default);

            var apiEx = await Assert.ThrowsAsync<ConflictException>(() => catalog.DeleteApiAsync(apiRes.Id, default));
            Assert.Contains("kullanımda", apiEx.Message);

            await catalog.DeleteEndpointAsync(endpoint.Id, default);
            await catalog.DeleteApiAsync(apiRes.Id, default);

            var db = sp.GetRequiredService<IYetkiDbContext>();
            Assert.False(await db.ApiResources.AnyAsync(a => a.Id == apiRes.Id));
            Assert.False(await db.ApiEndpoints.AnyAsync(e => e.Id == endpoint.Id));
        });
    }
}
