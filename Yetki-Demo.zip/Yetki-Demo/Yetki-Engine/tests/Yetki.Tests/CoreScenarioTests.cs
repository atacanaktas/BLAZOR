using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine;

namespace Yetki.Tests;

/// <summary>Uçtan uca karar senaryoları: RBAC + filtreli grup + hedefli policy (miras) + client + kurum.</summary>
public class CoreScenarioTests
{
    private const string Withdraw = "anka.nakit.cekim.gise:create";

    [Fact]
    public async Task S01_Gise_asistani_mesai_icinde_limit_altinda_cekim_yapar()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await host.EvaluateAsync("ayse.yilmaz", Withdraw, "nextral-desktop", ("TransactionAmount", "20000"), ("CustomerId", "C-9999"));

        Assert.Equal(DecisionType.Permit, d.Decision);
        Assert.Contains(d.Policies, p => p.Code == "NAKIT_MESAI" && p.MatchedBy == "Düğüm ANKA/NAKIT");
        Assert.Contains(d.Policies, p => p.Code == "KURUMSAL_AG" && p.MatchedBy == "Tümü");
        Assert.Contains(d.Steps, s => s.Step == "Client" && s.Outcome == "Pass");
    }

    [Fact]
    public async Task S02_Domain_hedefli_mesai_kurali_alt_duzeylere_miras_gecer_ATM_haric()
    {
        await using var host = await TestHost.CreateAsync();
        host.Clock.UtcNow = new DateTime(2026, 9, 22, 19, 0, 0, DateTimeKind.Utc); // 22:00 İstanbul

        var deposit = await host.EvaluateAsync("ayse.yilmaz", "anka.nakit.yatirma.gise:create");
        Assert.Equal(DecisionType.Deny, deposit.Decision);
        Assert.Equal("OUTSIDE_BUSINESS_HOURS", deposit.ReasonCode);
        Assert.Equal("NAKIT_MESAI", deposit.DecidingPolicy);

        // ATM alt modülü Exclude ile hariç: mesai kuralı uygulanmaz, açıklamada görünür
        var model = await host.ModelAsync();
        var atm = model.GetApplicablePolicies(model.PermissionIdByCode["anka.nakit.cekim.atm:create"], model.Users[model.UserIdByName["ayse.yilmaz"]].TenantId);
        Assert.DoesNotContain(atm.Applied, a => a.Policy.Row.Code == "NAKIT_MESAI");
        Assert.Contains(atm.Excluded, e => e.Policy.Row.Code == "NAKIT_MESAI" && e.ExcludedBy == "Düğüm ANKA/NAKIT/CEKIM/ATM");
    }

    [Fact]
    public async Task S03_Filtreli_grup_101_gise_asistanlarina_yetki_verir_stajyer_haric()
    {
        await using var host = await TestHost.CreateAsync();
        const string campaign = "anka.hesap.vadeli.kampanya:create";

        var ayse = await host.EvaluateAsync("ayse.yilmaz", campaign);     // 101 + GISEAST
        var deniz = await host.EvaluateAsync("deniz.koc", campaign);      // 737 + GISEAST
        var mert = await host.EvaluateAsync("mert.kaya", campaign);       // 101 + GISEAST ama stajyer (Exclude)

        Assert.Equal(DecisionType.Permit, ayse.Decision);
        Assert.Contains(ayse.PermissionSources, s => s.GroupCode == "GISE_101_AST");
        Assert.Equal("PERMISSION_NOT_GRANTED", deniz.ReasonCode);
        Assert.Equal("PERMISSION_NOT_GRANTED", mert.ReasonCode);

        var model = await host.ModelAsync();
        var set = model.GetEffective(model.UserIdByName["mert.kaya"], host.Clock.UtcNow);
        Assert.Contains(set.ExcludedFromGroups, x => x.Code == "GISE_101_AST" && x.Reason.Contains("TITLE"));
    }

    [Fact]
    public async Task S04_Client_kapsami_disinda_kullanici_yetkisi_olsa_bile_reddedilir()
    {
        await using var host = await TestHost.CreateAsync();
        // Zeynep EFT yetkisine sahip; mobil tablet Anka'da sadece okuma yapabilir
        var viaMobile = await host.EvaluateAsync("zeynep.acar", "anka.odeme.eft.giden:create", "mobil-sube-tablet");
        var viaNextral = await host.EvaluateAsync("zeynep.acar", "anka.odeme.eft.giden:create", "nextral-desktop", ("TransactionAmount", "1000"), ("Platform", "BRANCH_DESKTOP"));

        Assert.Equal("CLIENT_PERMISSION_NOT_ALLOWED", viaMobile.ReasonCode);
        Assert.Equal(DecisionType.Permit, viaNextral.Decision);
    }

    [Fact]
    public async Task S05_Alt_kurum_ust_kurumun_policysini_miras_alir_kendi_policysi_sadece_kendine()
    {
        await using var host = await TestHost.CreateAsync();
        host.Clock.UtcNow = new DateTime(2026, 9, 22, 15, 0, 0, DateTimeKind.Utc); // 18:00 İstanbul: A mesaisi içi, B mesaisi (17:30) dışı
        var model = await host.ModelAsync();
        var fund = model.Permissions.Values.First(p => p.Code.StartsWith("anka.yatirim.fon.") && p.Row.Action == "read").Code;

        var berk = await host.EvaluateAsync("berk.yaman", fund);            // B İştiraki
        Assert.Equal(DecisionType.Deny, berk.Decision);
        Assert.Equal("B_MESAI", berk.DecidingPolicy);
        Assert.Contains(berk.Policies, p => p.Code == "KURUMSAL_AG" && p.Tenant == "ABANK"); // üst kurumdan miras

        var ayse = await host.EvaluateAsync("ayse.yilmaz", "anka.nakit.cekim.gise:read"); // A Bankası: B_MESAI uygulanmaz
        Assert.DoesNotContain(ayse.Policies, p => p.Code == "B_MESAI");
    }

    [Fact]
    public async Task S06_Endpoint_katalogdan_permissiona_cozulur_eslenmemis_endpoint_reddedilir()
    {
        await using var host = await TestHost.CreateAsync();
        async Task<AuthorizationDecision> Call(string method, string path) => await host.WithAsync(sp =>
            sp.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(new AuthorizationRequest
            {
                Subject = new SubjectInfo { Id = "ayse.yilmaz" }, Client = "nextral-desktop", Via = ["anka-gateway"],
                Endpoint = new EndpointInfo { Api = "api://anka/nakit-cekim-gise-api", Method = method, Path = path },
                Context = new() { ["IpAddress"] = TestHost.BankIp }
            }, new EvaluationOptions { WriteAudit = false }));

        var read = await Call("GET", "/v1/cash-withdrawals/123");
        var receipt = await Call("GET", "/v1/cash-withdrawals/123/receipt");
        var unknown = await Call("DELETE", "/v1/cash-withdrawals/123");

        Assert.Equal(DecisionType.Permit, read.Decision);
        Assert.Equal("anka.nakit.cekim.gise:read", read.Permission);
        Assert.Equal("ENDPOINT_NOT_MAPPED", receipt.ReasonCode);
        Assert.Equal("ENDPOINT_UNKNOWN", unknown.ReasonCode);
    }

    [Fact]
    public async Task S07_Servis_client_kullanici_olmadan_servis_hesabiyla_calisir()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await host.WithAsync(sp => sp.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(new AuthorizationRequest
        {
            Client = "eod-batch", Permission = "anka.nakit.kasa.gun_sonu:execute", Context = new() { ["IpAddress"] = TestHost.BankIp }
        }, new EvaluationOptions { WriteAudit = false }));

        Assert.Equal(DecisionType.Permit, d.Decision);
        Assert.Equal("svc.eod-batch", d.UserName);
    }

    [Fact]
    public async Task S08_Report_only_policy_karari_etkilemez_ama_raporlanir()
    {
        await using var host = await TestHost.CreateAsync();
        host.Clock.UtcNow = new DateTime(2026, 9, 22, 17, 0, 0, DateTimeKind.Utc); // 20:00 İstanbul
        var d = await host.EvaluateAsync("ali.demir", "anka.rapor.sube.gunluk:read");

        Assert.Equal(DecisionType.Permit, d.Decision);
        Assert.Contains(d.ReportOnlyDenials, x => x.StartsWith("RAPOR_MESAI_DENEME"));
    }

    [Fact]
    public async Task S09_Eksik_IP_fail_closed_ve_limit_asimi_red()
    {
        await using var host = await TestHost.CreateAsync();
        var noIp = await host.WithAsync(sp => sp.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(new AuthorizationRequest
        {
            Subject = new SubjectInfo { Id = "ayse.yilmaz" }, Permission = Withdraw, Context = new() { ["TransactionAmount"] = "100", ["CustomerId"] = "C-1" }
        }, new EvaluationOptions { WriteAudit = false }));
        Assert.Equal(DecisionType.Indeterminate, noIp.Decision);
        Assert.Contains("Environment.IpAddress", noIp.MissingAttributes);

        var over = await host.EvaluateAsync("ayse.yilmaz", Withdraw, null, ("TransactionAmount", "75000"), ("CustomerId", "C-9"));
        Assert.Equal("AMOUNT_EXCEEDS_USER_LIMIT", over.ReasonCode);

        var self = await host.EvaluateAsync("ayse.yilmaz", Withdraw, null, ("TransactionAmount", "100"), ("CustomerId", "C-1001"));
        Assert.Equal("SELF_TRANSACTION_NOT_ALLOWED", self.ReasonCode);
    }

    [Fact]
    public async Task S10_Veri_kapsami_bolge_muduru_bolgedeki_subeleri_gorur_sube_personeli_sadece_kendi_subesini()
    {
        await using var host = await TestHost.CreateAsync();
        const string read = "anka.musteri.bilgi.profil:read";

        var regional = await host.EvaluateAsync("murat.aksoy", read, null, ("BranchCode", "737"));
        var ownBranch = await host.EvaluateAsync("ayse.yilmaz", read, null, ("BranchCode", "101"));
        var otherBranch = await host.EvaluateAsync("ayse.yilmaz", read, null, ("BranchCode", "737"));
        var hq = await host.EvaluateAsync("gul.yuce", "anka.odeme.eft.gelen:read"); // policy yok → statik yetki

        Assert.Equal(DecisionType.Permit, regional.Decision);
        Assert.Equal(DecisionType.Permit, ownBranch.Decision);
        Assert.Equal("CUSTOMER_OUT_OF_SCOPE", otherBranch.ReasonCode);
        Assert.Equal(DecisionType.Permit, hq.Decision);
    }
}
