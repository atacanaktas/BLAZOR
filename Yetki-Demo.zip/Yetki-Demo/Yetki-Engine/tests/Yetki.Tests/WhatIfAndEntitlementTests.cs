using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Abstractions;
using Yetki.Application.Changes;
using Yetki.Application.Definitions;
using Yetki.Application.Evaluation;
using Yetki.Application.Governance;
using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Application.Simulation;
using Yetki.Domain.Common;

namespace Yetki.Tests;

/// <summary>What-If = gerçek sonuç; toplu yetki (Nextral); SoD; audit maskeleme.</summary>
public class WhatIfAndEntitlementTests
{
    [Fact]
    public async Task Rolden_permission_cikarilinca_baska_kaynaktan_alan_korunur()
    {
        await using var host = await TestHost.CreateAsync();
        var role = await host.RoleIdAsync("BRYSLYTK");
        var perm = await host.PermissionIdAsync("anka.musteri.bilgi.profil:read");
        var cs = new AuthorizationChangeSet { RolePermissions = [new RolePermissionChange(role, perm, false)] };
        var impact = await host.WithAsync(sp => sp.GetRequiredService<SimulationService>().SimulateChangesAsync(cs, default));

        var burak = impact.Users.Single(u => u.UserName == "burak.arslan"); // SUBEMDR vekaletinden de alıyor
        Assert.Contains(burak.RetainedPermissions, p => p.Code == "anka.musteri.bilgi.profil:read");
        Assert.DoesNotContain(burak.RemovedPermissions, p => p.Code == "anka.musteri.bilgi.profil:read");
        var can = impact.Users.Single(u => u.UserName == "can.ozturk");
        Assert.Contains(can.RemovedPermissions, p => p.Code == "anka.musteri.bilgi.profil:read");
    }

    [Fact]
    public async Task Simulasyon_ile_gercek_uygulama_ayni_sonucu_verir()
    {
        await using var host = await TestHost.CreateAsync();
        var group = await host.GroupIdAsync("GISE_101_AST");
        List<GroupFilterDraft> filters =
        [
            new() { Criteria = [new() { Attribute = "ROLE", Values = ["GISEAST"] }, new() { Attribute = "ORG_UNIT_TREE", Values = ["BLG_IST"] }] }
        ];
        var simulated = await host.WithAsync(sp => sp.GetRequiredService<SimulationService>().SimulateChangesAsync(
            new AuthorizationChangeSet { GroupFilters = [new GroupFiltersReplacement(group, filters)] }, default));
        var applied = await host.WithAsync(sp => sp.GetRequiredService<AssignmentService>().ReplaceGroupFiltersAsync(group, filters, default));

        Assert.True(applied.Applied);
        Assert.Equal(simulated.Users.Select(u => (u.UserName, string.Join(",", u.AddedPermissions.Select(p => p.Code)))),
            applied.Users.Select(u => (u.UserName, string.Join(",", u.AddedPermissions.Select(p => p.Code)))));
        Assert.Contains(applied.Users, u => u.UserName is "deniz.koc" or "fatma.celik" or "mert.kaya"); // stajyer istisnası kaldırıldı
        var events = await host.WithAsync(sp => sp.GetRequiredService<IYetkiDbContext>().OutboxEvents.CountAsync(e => e.EventType == "EffectivePermissionsChanged"));
        Assert.Equal(applied.AffectedUserCount, events);
    }

    [Fact]
    public async Task Policy_mod_degisikligi_ReportOnly_dan_Enforce_kimleri_etkiler()
    {
        await using var host = await TestHost.CreateAsync();
        var policy = await host.PolicyIdAsync("RAPOR_MESAI_DENEME");
        var result = await host.WithAsync(sp => sp.GetRequiredService<PolicyImpactService>().AnalyzeAsync(new PolicyImpactRequest
        {
            Changes = new PolicyChangeSet { PolicyModes = [new PolicyModeChange(policy, PolicyMode.Enforce)] },
            Scenarios = [new ImpactScenario { Name = "gece", Context = new() { ["IpAddress"] = TestHost.BankIp } }],
            AsOfUtc = new DateTime(2026, 9, 22, 19, 0, 0, DateTimeKind.Utc)
        }, default));

        Assert.True(result.NewlyDenied > 0);
        Assert.All(result.Rows, r => Assert.Equal("REPORT_OUTSIDE_HOURS", r.After.ReasonCode));
        Assert.Contains(result.Rows, r => r.UserName == "ali.demir" && r.Permission == "anka.rapor.sube.gunluk:read");
    }

    [Fact]
    public async Task Nextral_entitlement_ust_ekran_kapaliysa_butonlar_kapali_ve_policy_ipucu()
    {
        await using var host = await TestHost.CreateAsync();
        host.Clock.UtcNow = new DateTime(2026, 9, 22, 19, 0, 0, DateTimeKind.Utc); // mesai dışı
        var e = await host.WithAsync(sp => sp.GetRequiredService<EntitlementService>().GetAsync(new EntitlementRequest
        {
            User = "ayse.yilmaz", Client = "nextral-desktop", Application = "NEXTRAL", Evaluate = true, Context = new() { ["IpAddress"] = TestHost.BankIp }
        }));

        Assert.False(e.UiElements.Single(u => u.Code == "SCR_ODEME").Enabled);
        Assert.Equal("Üst ekran/menü kapalı.", e.UiElements.Single(u => u.Code == "BTN_EFT").Reason);
        var cekim = e.UiElements.Single(u => u.Code == "BTN_CEKIM");
        Assert.False(cekim.Enabled);
        Assert.Equal(DecisionType.Deny, cekim.Runtime!.Decision);
        Assert.True(e.UiElements.Single(u => u.Code == "BTN_KAMPANYA").Enabled); // 101 grubu
    }

    [Fact]
    public async Task Mobil_client_ile_entitlement_client_kapsami_disini_listeler()
    {
        await using var host = await TestHost.CreateAsync();
        var e = await host.WithAsync(sp => sp.GetRequiredService<EntitlementService>().GetAsync(new EntitlementRequest { User = "zeynep.acar", Client = "mobil-sube-tablet" }));
        Assert.Contains("anka.odeme.eft.giden:create", e.BlockedByClientPermission);
        Assert.DoesNotContain(e.Permissions, p => p.Code == "anka.odeme.eft.giden:create");
        Assert.Contains(e.Permissions, p => p.Code == "anka.musteri.bilgi.profil:read");
    }

    [Fact]
    public async Task SoD_block_atamayi_engeller_warn_ihlal_kaydi_acar_tarama_bulur()
    {
        await using var host = await TestHost.CreateAsync();
        var ayse = await host.UserIdAsync("ayse.yilmaz");
        var subeMdr = await host.RoleIdAsync("SUBEMDR");
        await Assert.ThrowsAsync<ConflictException>(() => host.WithAsync(sp => sp.GetRequiredService<AssignmentService>().AssignRoleAsync(ayse, subeMdr, null, null, default)));

        var scan = await host.WithAsync(sp => sp.GetRequiredService<SodService>().ScanAsync());
        Assert.Contains(scan.Details, d => d.UserName == "hakan.tekin" && d.Conflicts.Any(c => c.Code == "SOD_KREDI_BASVURU_ONAY"));

        var okan = await host.UserIdAsync("okan.polat"); // TICRIAST: başvuru açabilir; SUBEMDR verilince onay da → Warn (atama yapılır, uyarı döner)
        var impact = await host.WithAsync(sp => sp.GetRequiredService<AssignmentService>().AssignRoleAsync(okan, subeMdr, null, "test", default));
        Assert.True(impact.Applied);
        Assert.Contains(impact.Warnings, w => w.UserName == "okan.polat");
    }

    [Fact]
    public async Task Audit_hassas_degerleri_maskeler()
    {
        await using var host = await TestHost.CreateAsync();
        await host.WithAsync(sp => sp.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(new AuthorizationRequest
        {
            Subject = new SubjectInfo { Id = "ayse.yilmaz" }, Permission = "anka.nakit.cekim.gise:create", Client = "nextral-desktop",
            Context = new() { ["IpAddress"] = TestHost.BankIp, ["TransactionAmount"] = "100", ["CustomerId"] = "C-987654" }
        }));
        var log = await host.WithAsync(sp => sp.GetRequiredService<IYetkiDbContext>().AuditLogs.SingleAsync(a => a.Category == AuditCategory.AuthorizationDecision));
        Assert.DoesNotContain("C-987654", log.DetailsJson);
        Assert.Contains("*****54", log.DetailsJson);
        Assert.Equal("nextral-desktop", log.ClientId);
    }

    [Fact]
    public async Task Ortak_kosul_degisikligi_tum_kullanan_policyleri_etkiler()
    {
        await using var host = await TestHost.CreateAsync();
        var shared = await host.WithAsync(sp => sp.GetRequiredService<IYetkiDbContext>().SharedConditions.SingleAsync(s => s.Code == "BUSINESS_HOURS"));
        var usages = await host.WithAsync(sp => sp.GetRequiredService<SharedConditionService>().UsagesAsync(shared.Id, default));
        Assert.Contains(usages, u => u.Policy == "NAKIT_MESAI");
        Assert.Contains(usages, u => u.Policy == "RAPOR_MESAI_DENEME");

        await Assert.ThrowsAsync<ConflictException>(() => host.WithAsync(sp => sp.GetRequiredService<SharedConditionService>().UpdateAsync(shared.Id, new SharedConditionUpsert
        {
            Code = shared.Code, Name = shared.Name, IsActive = false,
            Condition = new ConditionDraft { ConditionTypeCode = "TIME_WINDOW", Parameters = new() { ["Start"] = "09:00", ["End"] = "18:00" } }
        }, default)));
    }
}
