using Microsoft.Extensions.Logging.Abstractions;
using Yetki.Application.Context;
using Yetki.Application.Model;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Domain.Common;

namespace Yetki.Tests;

/// <summary>Saf birim testleri: karar stratejileri, rule = sağlanması gereken koşul, üç değerli mantık, fail-closed.</summary>
public class PolicyEngineTests
{
    private static readonly CombiningAlgorithmRegistry Algorithms = new([new AllRulesMustPassAlgorithm(), new AnyRuleMustPassAlgorithm()]);

    private static PolicyEvaluator Evaluator() =>
        new(new ConditionHandlerRegistry([new AlwaysConditionHandler(), new AmountGreaterThanConditionHandler(), new IpInRangeConditionHandler()]), Algorithms, NullLogger<PolicyEvaluator>.Instance);

    private static AttributeResolver Resolver(Dictionary<string, string?> ctx)
    {
        var model = AuthorizationModel.Build(new ModelData(), null, new GroupCriterionRegistry([]), 1, false, DateTime.UtcNow);
        return new AttributeResolver([new RequestContextAttributeProvider()], new AttributeResolutionScope
        {
            Subject = new SubjectRef(1, "x"), Context = new AuthorizationContext(ctx), Action = "a", Model = model, Now = DateTime.UtcNow
        });
    }

    private static ConditionNode Pred(string type, params (string, string)[] ps) =>
        new(1, ConditionKind.Predicate, type, true, ps.ToDictionary(p => p.Item1, p => p.Item2), []);

    // Rule sonucu: Permit = sağlandı, Deny = sağlanmadı, Indeterminate = belirsiz, NotApplicable = pasif
    [Theory]
    [InlineData(CombiningAlgorithm.AllRulesMustPass, new[] { DecisionType.Permit, DecisionType.Permit }, DecisionType.Permit)]
    [InlineData(CombiningAlgorithm.AllRulesMustPass, new[] { DecisionType.Permit, DecisionType.Deny }, DecisionType.Deny)]
    [InlineData(CombiningAlgorithm.AllRulesMustPass, new[] { DecisionType.Permit, DecisionType.Indeterminate }, DecisionType.Indeterminate)]
    [InlineData(CombiningAlgorithm.AllRulesMustPass, new[] { DecisionType.Indeterminate, DecisionType.Deny }, DecisionType.Deny)]
    [InlineData(CombiningAlgorithm.AnyRuleMustPass, new[] { DecisionType.Deny, DecisionType.Permit }, DecisionType.Permit)]
    [InlineData(CombiningAlgorithm.AnyRuleMustPass, new[] { DecisionType.Deny, DecisionType.Indeterminate }, DecisionType.Indeterminate)]
    [InlineData(CombiningAlgorithm.AnyRuleMustPass, new[] { DecisionType.Deny, DecisionType.Deny }, DecisionType.Deny)]
    [InlineData(CombiningAlgorithm.AllRulesMustPass, new[] { DecisionType.NotApplicable }, DecisionType.NotApplicable)]
    public void Karar_stratejileri(CombiningAlgorithm algorithm, DecisionType[] inputs, DecisionType expected) =>
        Assert.Equal(expected, Algorithms.Get(algorithm).Combine(inputs).Decision);

    [Fact]
    public async Task Eksik_deger_NOT_altinda_da_belirsiz_kalir_ve_rule_Indeterminate_uretir()
    {
        var policy = new PolicyDefinition(1, "P", "P", 1, CombiningAlgorithm.AllRulesMustPass,
            [new RuleDefinition(1, "R", "R", null, 1, "X", true, new ConditionNode(2, ConditionKind.Not, null, true, new Dictionary<string, string>(), [Pred("IP_IN_RANGE", ("Cidrs", "10.0.0.0/8"))]))]);
        var result = await Evaluator().EvaluateAsync(policy, Resolver(new()), "p", default);
        Assert.Equal(DecisionType.Indeterminate, result.Result);
        Assert.Contains("Environment.IpAddress", result.Rules[0].MissingAttributes);
    }

    [Fact]
    public async Task VE_icinde_bir_FALSE_belirsizligi_bastirir()
    {
        var and = new ConditionNode(3, ConditionKind.AllOf, null, true, new Dictionary<string, string>(),
            [Pred("IP_IN_RANGE", ("Cidrs", "10.0.0.0/8")), Pred("AMOUNT_GREATER_THAN", ("Threshold", "1000"))]);
        var policy = new PolicyDefinition(1, "P", "P", 1, CombiningAlgorithm.AllRulesMustPass, [new RuleDefinition(1, "R", "R", null, 1, "LIMIT", true, and)]);
        var result = await Evaluator().EvaluateAsync(policy, Resolver(new() { ["TransactionAmount"] = "10" }), "p", default);
        Assert.Equal(DecisionType.Deny, result.Result); // FALSE ∧ ? = FALSE → rule sağlanmadı
        Assert.Equal("R", result.DecidingRule);
    }

    [Fact]
    public async Task Tum_rulelar_saglanirsa_policy_Permit_biri_saglanmazsa_Deny()
    {
        RuleDefinition Rule(string code, int order, string threshold) =>
            new(order, code, code, null, order, code + "_FAILED", true,
                new ConditionNode(order, ConditionKind.Not, null, true, new Dictionary<string, string>(), [Pred("AMOUNT_GREATER_THAN", ("Threshold", threshold))]));
        var policy = new PolicyDefinition(1, "P", "P", 1, CombiningAlgorithm.AllRulesMustPass, [Rule("LIMIT_100K", 1, "100000"), Rule("LIMIT_50K", 2, "50000")]);

        var ok = await Evaluator().EvaluateAsync(policy, Resolver(new() { ["TransactionAmount"] = "20000" }), "p", default);
        var over = await Evaluator().EvaluateAsync(policy, Resolver(new() { ["TransactionAmount"] = "75000" }), "p", default);

        Assert.Equal(DecisionType.Permit, ok.Result);
        Assert.All(ok.Rules, r => Assert.Equal(DecisionType.Permit, r.Result));
        Assert.Equal(DecisionType.Deny, over.Result);
        Assert.Equal("LIMIT_50K", over.DecidingRule);
    }

    [Fact]
    public async Task Handleri_olmayan_kosul_ve_cocuksuz_referans_fail_closed()
    {
        var unknown = new PolicyDefinition(1, "P", "P", 1, CombiningAlgorithm.AllRulesMustPass,
            [new RuleDefinition(1, "R", "R", null, 1, null, true, Pred("YOK_BOYLE"))]);
        Assert.Equal(DecisionType.Indeterminate, (await Evaluator().EvaluateAsync(unknown, Resolver(new()), "p", default)).Result);

        var dangling = new PolicyDefinition(1, "P", "P", 1, CombiningAlgorithm.AllRulesMustPass,
            [new RuleDefinition(1, "R", "R", null, 1, null, true, new ConditionNode(5, ConditionKind.Reference, null, true, new Dictionary<string, string>(), [], "X"))]);
        Assert.Equal(DecisionType.Indeterminate, (await Evaluator().EvaluateAsync(dangling, Resolver(new()), "p", default)).Result);
    }

    [Fact]
    public void Endpoint_sablonu_en_ozel_eslesmeyi_secer()
    {
        var data = new ModelData
        {
            Apis = [new ApiRow(1, 1, "a", "A", "api://a", true)],
            Endpoints = [new EndpointRow(1, 1, "GET", "/v1/x/{id}", 10), new EndpointRow(2, 1, "GET", "/v1/x/summary", 11)]
        };
        var m = AuthorizationModel.Build(data, null, new GroupCriterionRegistry([]), 1, false, DateTime.UtcNow);
        var api = m.FindApi("a")!;
        Assert.Equal(11, m.MatchEndpoint(api, "GET", "/v1/x/summary?q=1")!.PermissionId);
        Assert.Equal(10, m.MatchEndpoint(api, "get", "/v1/x/42/")!.PermissionId);
        Assert.Null(m.MatchEndpoint(api, "POST", "/v1/x/42"));
    }
}
