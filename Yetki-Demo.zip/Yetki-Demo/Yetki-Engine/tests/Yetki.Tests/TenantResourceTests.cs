using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine;

namespace Yetki.Tests;

/// <summary>
/// Hibrit model akışı: 1 Tenant → 2 Client → 3 Resource + Action → 4 RBAC → 5 Policy/Rule.
/// İstek biçimi: { tenant, client, subject, resource, action, context }.
/// </summary>
public class TenantResourceTests
{
    private const string CashWithdrawal = "ANKA/NAKIT/CEKIM/GISE";

    private static Task<AuthorizationDecision> Evaluate(TestHost host, string? tenant, string? client, string user, string resource, string action,
        Dictionary<string, string?>? resourceProperties = null, params (string Key, string? Value)[] context) =>
        host.WithAsync(sp =>
        {
            var ctx = new Dictionary<string, string?> { ["IpAddress"] = TestHost.BankIp };
            foreach (var (k, v) in context) ctx[k] = v;
            return sp.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(new AuthorizationRequest
            {
                Tenant = tenant, Client = client, Subject = new SubjectInfo { Id = user }, Action = action,
                Resource = new ResourceInfo { Type = resource, Properties = resourceProperties ?? new() },
                Context = ctx
            }, new EvaluationOptions { WriteAudit = false });
        });

    [Fact]
    public async Task Dokuman_ornegi_Ahmet_gise_yetkilisi_para_ceker_tum_rulelar_saglanir()
    {
        await using var host = await TestHost.CreateAsync();
        host.Clock.UtcNow = new DateTime(2026, 9, 22, 11, 35, 0, DateTimeKind.Utc); // 14:35 İstanbul

        var d = await Evaluate(host, "ABANK", "nextral-desktop", "ahmet.kaya", CashWithdrawal, "create", null,
            ("TransactionAmount", "75000"), ("CustomerId", "C-9999"));

        Assert.Equal(DecisionType.Permit, d.Decision);
        Assert.Equal("anka.nakit.cekim.gise:create", d.Permission);
        Assert.Equal(["Subject", "Tenant", "Client", "Resource", "Client Permission", "OAuth Scope", "RBAC"], d.Steps.Take(7).Select(s => s.Step));
        Assert.All(d.Steps.Take(5), s => Assert.Equal("Pass", s.Outcome));
        // Saat · limit · IP · izin → hepsi sağlandı
        var rules = d.Policies.SelectMany(p => p.Rules).ToDictionary(r => r.Code, r => r.Result);
        Assert.Equal(DecisionType.Permit, rules["WORKING_HOURS"]);
        Assert.Equal(DecisionType.Permit, rules["TRANSACTION_LIMIT"]);
        Assert.Equal(DecisionType.Permit, rules["BANK_NETWORK"]);
        Assert.Equal(DecisionType.Permit, rules["NOT_ON_LEAVE"]);
    }

    [Fact]
    public async Task Limit_rule_saglanmazsa_policy_Deny_ve_neden_kodu_doner()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await Evaluate(host, "ABANK", "nextral-desktop", "ahmet.kaya", CashWithdrawal, "create", null,
            ("TransactionAmount", "150000"), ("CustomerId", "C-9999"));

        Assert.Equal(DecisionType.Deny, d.Decision);
        Assert.Equal("AMOUNT_EXCEEDS_USER_LIMIT", d.ReasonCode);
        Assert.Equal("NAKIT_CEKIM_LIMIT", d.DecidingPolicy);
        Assert.Equal("TRANSACTION_LIMIT", d.DecidingRule);
    }

    [Fact]
    public async Task RBAC_yetkisi_yoksa_policy_degerlendirilmeden_Deny()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await Evaluate(host, "ABANK", null, "elif.sahin", CashWithdrawal, "create");

        Assert.Equal("PERMISSION_NOT_GRANTED", d.ReasonCode);
        Assert.Empty(d.Policies);
        Assert.Equal("RBAC", d.Steps.Last().Step);
    }

    [Fact]
    public async Task Resource_uzerinde_tanimsiz_action_reddedilir()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await Evaluate(host, "ABANK", null, "ahmet.kaya", CashWithdrawal, "approve");
        Assert.Equal("PERMISSION_UNKNOWN", d.ReasonCode);

        var dotted = await Evaluate(host, null, null, "ahmet.kaya", "anka.nakit.cekim.gise", "READ"); // kod biçimi + büyük harf
        Assert.Equal("anka.nakit.cekim.gise:read", dotted.Permission);
    }

    [Fact]
    public async Task Tenant_izolasyonu_kullanici_baska_tenant_adina_islem_yapamaz()
    {
        await using var host = await TestHost.CreateAsync();

        var other = await Evaluate(host, "BISTIRAK", null, "ayse.yilmaz", CashWithdrawal, "read");
        var unknown = await Evaluate(host, "YOK", null, "ayse.yilmaz", CashWithdrawal, "read");
        var foreignRecord = await Evaluate(host, "ABANK", null, "ayse.yilmaz", CashWithdrawal, "read", new() { ["Tenant"] = "BISTIRAK" });
        var ownRecord = await Evaluate(host, "ABANK", null, "ayse.yilmaz", CashWithdrawal, "read", new() { ["Tenant"] = "ABANK" });

        Assert.Equal("TENANT_MISMATCH", other.ReasonCode);
        Assert.Equal("TENANT_UNKNOWN", unknown.ReasonCode);
        Assert.Equal("RESOURCE_TENANT_MISMATCH", foreignRecord.ReasonCode);
        Assert.Equal(DecisionType.Permit, ownRecord.Decision);
    }

    [Fact]
    public async Task Client_kendi_tenantinda_ve_alt_tenantlarda_kullanilir()
    {
        await using var host = await TestHost.CreateAsync();

        // b-portal-web BISTIRAK'ın: A Bankası kullanıcısı kullanamaz
        var aViaB = await Evaluate(host, "ABANK", "b-portal-web", "ayse.yilmaz", CashWithdrawal, "read");
        Assert.Equal("CLIENT_TENANT_MISMATCH", aViaB.ReasonCode);

        // nextral-desktop ABANK'ın: alt tenant BISTIRAK miras alır (client adımı geçer)
        var bViaA = await Evaluate(host, "BISTIRAK", "nextral-desktop", "berk.yaman", "ANKA/YATIRIM/FON/ALIM_SATIM", "read");
        Assert.Contains(bViaA.Steps, s => s.Step == "Client" && s.Outcome == "Pass" && s.Detail.Contains("üst tenant"));
    }

    [Fact]
    public async Task Uygulama_tenanta_aittir_ust_tenant_alt_tenantin_uygulamasina_erisemez()
    {
        await using var host = await TestHost.CreateAsync();
        const string portfolio = "B_PORTAL/YATIRIMCI/RAPOR/PORTFOY";

        var berk = await Evaluate(host, "BISTIRAK", "b-portal-web", "berk.yaman", portfolio, "read");
        var ali = await Evaluate(host, "ABANK", null, "ali.demir", portfolio, "read");

        Assert.Equal(DecisionType.Permit, berk.Decision);
        Assert.Equal("RESOURCE_NOT_IN_TENANT", ali.ReasonCode);

        // Yönetim: A Bankası rolüne B'nin uygulamasından permission eklenemez
        var role = await host.RoleIdAsync("SUBEMDR");
        var perm = await host.PermissionIdAsync("b_portal.yatirimci.rapor.portfoy:read");
        var ex = await Assert.ThrowsAsync<Yetki.Application.Abstractions.ValidationException>(() =>
            host.WithAsync(sp => sp.GetRequiredService<Yetki.Application.Changes.AssignmentService>().SetRolePermissionAsync(role, perm, true, default)));
        Assert.Contains("başka tenant", ex.Message);
    }
}
