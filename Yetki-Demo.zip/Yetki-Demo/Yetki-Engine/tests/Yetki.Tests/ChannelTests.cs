using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Definitions;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine;
using Yetki.Domain.Common;
using Yetki.Sdk;

namespace Yetki.Tests;

/// <summary>
/// Aynı Anka endpoint'i farklı kanallardan (Nextral / Anka Web / Mobil) çağrılır:
///  1) Aracı (gateway) isteği başlatmaz; karar orijinal client'a göre verilir, aracı zinciri doğrulanır
///  2) Policy'nin kanal (client) hedefi: kural sadece ilgili kanaldan gelen isteğe uygulanır
///  3) Yükümlülük (obligation): karar ile PEP'e döner (maskele, sınırla, logla); PEP tanımadığında reddeder
/// </summary>
public class ChannelTests
{
    private const string CustomerRead = "anka.musteri.bilgi.profil:read";

    private static Task<AuthorizationDecision> Evaluate(TestHost host, string user, string permission, string? client, List<string>? via = null,
        params (string Key, string? Value)[] context) =>
        host.WithAsync(sp =>
        {
            var ctx = new Dictionary<string, string?> { ["IpAddress"] = TestHost.BankIp };
            foreach (var (k, v) in context) ctx[k] = v;
            return sp.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(new AuthorizationRequest
            {
                Subject = new SubjectInfo { Id = user }, Permission = permission, Client = client, Via = via ?? [], Context = ctx
            }, new EvaluationOptions { WriteAudit = false });
        });

    [Fact]
    public async Task Gateway_client_olarak_gelirse_reddedilir_orijinal_client_ve_via_ile_gelirse_orijinalin_kisitlari_gecerli()
    {
        await using var host = await TestHost.CreateAsync();

        // Gateway kendisi client olursa mobilin "sadece okuma" kısıtı kaybolurdu → reddedilir
        var asClient = await Evaluate(host, "zeynep.acar", "anka.odeme.eft.giden:create", "anka-gateway");
        Assert.Equal("CLIENT_IS_INTERMEDIARY", asClient.ReasonCode);

        // Mobil tablet → gateway → EFT: orijinal client mobil olduğu için yine CLIENT_PERMISSION_NOT_ALLOWED
        var mobileViaGateway = await Evaluate(host, "zeynep.acar", "anka.odeme.eft.giden:create", "mobil-sube-tablet", ["anka-gateway"]);
        Assert.Equal("CLIENT_PERMISSION_NOT_ALLOWED", mobileViaGateway.ReasonCode);

        // Nextral → gateway → müşteri okuma: izin; aracı zinciri kararda
        var nextral = await Evaluate(host, "ayse.yilmaz", CustomerRead, "nextral-desktop", ["anka-gateway"], ("BranchCode", "101"));
        Assert.Equal(DecisionType.Permit, nextral.Decision);
        Assert.Equal(["anka-gateway"], nextral.Via);
        Assert.Contains(nextral.Steps, s => s.Step == "Client" && s.Detail.Contains("aracı: anka-gateway"));
    }

    [Fact]
    public async Task Bilinmeyen_veya_yetkisiz_araci_reddedilir()
    {
        await using var host = await TestHost.CreateAsync();
        var unknown = await Evaluate(host, "ayse.yilmaz", CustomerRead, "nextral-desktop", ["sahte-proxy"], ("BranchCode", "101"));
        var notIntermediary = await Evaluate(host, "ayse.yilmaz", CustomerRead, "nextral-desktop", ["anka-web"], ("BranchCode", "101"));
        // gateway sadece ANKA'yı iletebilir; NEXTRAL ekran yetkisini iletemez
        var outOfScope = await Evaluate(host, "ayse.yilmaz", "nextral.gise.nakit_ekran:view", "nextral-desktop", ["anka-gateway"]);

        Assert.Equal("INTERMEDIARY_UNKNOWN", unknown.ReasonCode);
        Assert.Equal("INTERMEDIARY_UNKNOWN", notIntermediary.ReasonCode);
        Assert.Equal("INTERMEDIARY_NOT_ALLOWED", outOfScope.ReasonCode);
    }

    [Fact]
    public async Task Ayni_endpoint_kanal_hedefli_policy_sadece_ilgili_kanaldan_gelen_istege_uygulanir()
    {
        await using var host = await TestHost.CreateAsync();
        const string outside = "85.100.1.1";

        // Nextral: MOBIL_KANAL uygulanmaz; banka ağı dışında KURUMSAL_AG reddeder
        var nextral = await Evaluate(host, "elif.sahin", CustomerRead, "nextral-desktop", null, ("BranchCode", "101"));
        Assert.Equal(DecisionType.Permit, nextral.Decision);
        Assert.DoesNotContain(nextral.Policies, p => p.Code == "MOBIL_KANAL");
        Assert.Empty(nextral.Obligations);

        // Mobil (saha, banka ağı dışı): KURUMSAL_AG kanal hariç; MOBIL_KANAL cihaz ister
        var mobileOk = await Evaluate(host, "elif.sahin", CustomerRead, "mobil-sube-tablet", null, ("BranchCode", "101"), ("IpAddress", outside), ("DeviceCompliant", "true"));
        var mobileBad = await Evaluate(host, "elif.sahin", CustomerRead, "mobil-sube-tablet", null, ("BranchCode", "101"), ("IpAddress", outside), ("DeviceCompliant", "false"));
        Assert.Equal(DecisionType.Permit, mobileOk.Decision);
        Assert.Contains(mobileOk.ExcludedPolicies, x => x.Code == "KURUMSAL_AG" && x.ExcludedBy == "Client mobil-sube-tablet");
        Assert.Contains(mobileOk.Policies, p => p.Code == "MOBIL_KANAL" && p.MatchedBy!.Contains("client mobil-sube-tablet"));
        Assert.Equal("DEVICE_NOT_COMPLIANT", mobileBad.ReasonCode);
        Assert.Empty(mobileBad.Obligations);                                                  // Permit yükümlülükleri Deny'da dönmez
    }

    [Fact]
    public async Task Yukumluluk_kararla_doner_ve_SDK_yaniti_maskeler_tanimadigini_reddeder()
    {
        await using var host = await TestHost.CreateAsync();
        var mobile = await Evaluate(host, "elif.sahin", CustomerRead, "mobil-sube-tablet", null, ("BranchCode", "101"), ("DeviceCompliant", "true"));
        Assert.Contains(mobile.Obligations, o => o.Code == "MASK_FIELDS" && o.Parameters["Fields"] == "tckn,telefon,email" && o.Policy == "MOBIL_KANAL");
        Assert.Contains(mobile.Obligations, o => o.Code == "LIMIT_RESULTS" && o.Parameters["Max"] == "20");
        Assert.Contains(mobile.Obligations, o => o.Code == "LOG_ACCESS");

        // Rule'suz policy (WEB_KANAL_MASKE): koşulsuz yükümlülük, sadece Anka Web kanalında
        var web = await Evaluate(host, "ayse.yilmaz", "anka.nakit.cekim.gise:read", "anka-web");
        var nextral = await Evaluate(host, "ayse.yilmaz", "anka.nakit.cekim.gise:read", "nextral-desktop");
        Assert.Equal(DecisionType.Permit, web.Decision);
        Assert.Contains(web.Obligations, o => o.Code == "MASK_FIELDS" && o.Parameters["Fields"] == "hesapNo,musteriTckn");
        Assert.Empty(nextral.Obligations);

        // SDK (PEP): maskele + sınırla (iç içe nesnelerde de, alan adı duyarsız)
        var obligations = mobile.Obligations.Select(o => new DecisionObligationDto { Code = o.Code, Policy = o.Policy, Parameters = new(o.Parameters, StringComparer.OrdinalIgnoreCase) }).ToList();
        var response = Enumerable.Range(1, 30).Select(i => new { Id = i, Ad = "Müşteri " + i, TCKN = "1234567890" + (i % 10), Iletisim = new { Telefon = "05321112233" } }).ToList();
        var shaped = ObligationEnforcer.Apply(response, obligations, new JsonSerializerOptions(JsonSerializerDefaults.Web))!.AsArray();
        Assert.Equal(20, shaped.Count);
        Assert.Equal("*********01", shaped[0]!["tckn"]!.GetValue<string>());
        Assert.Equal("*********33", shaped[0]!["iletisim"]!["telefon"]!.GetValue<string>());
        Assert.Equal("Müşteri 1", shaped[0]!["ad"]!.GetValue<string>());

        Assert.Equal(["REQUIRE_MFA"], ObligationEnforcer.Unsupported([new DecisionObligationDto { Code = "REQUIRE_MFA", Policy = "X" }, obligations[0]]));
    }

    [Fact]
    public async Task Kanal_hedefi_ve_yukumluluk_yonetimi_dogrular()
    {
        await using var host = await TestHost.CreateAsync();
        var policyId = await host.PolicyIdAsync("NAKIT_MESAI");
        var m = await host.ModelAsync();
        var gateway = m.ClientsById["anka-gateway"].Id;

        var ex1 = await Assert.ThrowsAsync<Application.Abstractions.ValidationException>(() => host.WithAsync(sp =>
            sp.GetRequiredService<PolicyManagementService>().AddClientTargetAsync(policyId, new ClientTargetUpsert { ClientId = gateway }, default)));
        Assert.Contains("aracı", ex1.Message);

        await Assert.ThrowsAsync<Application.Abstractions.ValidationException>(() => host.WithAsync(sp =>
            sp.GetRequiredService<PolicyManagementService>().AddObligationAsync(policyId, new ObligationUpsert { Code = "SIL_HER_SEYI" }, default)));
        await Assert.ThrowsAsync<Application.Abstractions.ValidationException>(() => host.WithAsync(sp =>
            sp.GetRequiredService<PolicyManagementService>().AddObligationAsync(policyId, new ObligationUpsert { Code = "LIMIT_RESULTS", Parameters = new() { ["Max"] = "çok" } }, default)));

        await host.WithAsync(sp => sp.GetRequiredService<PolicyManagementService>().AddClientTargetAsync(policyId,
            new ClientTargetUpsert { ClientId = m.ClientsById["mobil-sube-tablet"].Id, Mode = InclusionMode.Exclude }, default));
        var after = await host.ModelAsync();
        Assert.Contains(after.Policies[policyId].ExcludeClients, c => c.ClientId == m.ClientsById["mobil-sube-tablet"].Id);
    }
}
