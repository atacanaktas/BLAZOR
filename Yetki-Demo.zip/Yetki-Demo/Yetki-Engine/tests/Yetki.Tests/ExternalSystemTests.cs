using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Changes;
using Yetki.Application.Definitions;
using Yetki.Application.External;
using Yetki.Domain.Common;
using Yetki.Infrastructure.Persistence;

namespace Yetki.Tests;

/// <summary>
/// Dış sistem (RACF/LDAP) bağımlılıkları: kimlik yayılımında CICS çağıran kullanıcının RACF yetkisini arar.
/// Katalog (API / endpoint / permission) → dış yetki (+ zincir) → kullanıcının olması gereken durumu → mutabakat.
/// </summary>
public class ExternalSystemTests
{
    private static async Task<(ExternalRequirementCatalog Catalog, Application.Model.AuthorizationModel Model)> LoadAsync(TestHost host) =>
        (await host.WithAsync(sp => ExternalRequirementCatalog.LoadAsync(sp.GetRequiredService<Application.Abstractions.IYetkiDbContext>(), default)),
         await host.ModelAsync());

    [Fact]
    public async Task Endpointe_READ_verilince_X_Y_Z_ve_zincirdeki_dataset_READ_ile_gerekir()
    {
        await using var host = await TestHost.CreateAsync();
        var (catalog, m) = await LoadAsync(host);

        // ANKA/MUSTERI/BILGI/PROFIL · musteri-api · GET /v1/customers/{id} → anka.musteri.bilgi.profil:read
        var read = catalog.ForPermission(m, m.Permissions[m.PermissionIdByCode["anka.musteri.bilgi.profil:read"]]).ToDictionary(n => n.Target.Key);
        Assert.Equal(ExternalAccessLevel.Read, read["RACF:CICSMUS"].Level);                // API seviyesi (tüm endpoint'ler)
        Assert.Equal(ExternalAccessLevel.Read, read["RACF:MUS1"].Level);                   // endpoint; seviye action'dan (read → READ)
        Assert.Equal(ExternalAccessLevel.Read, read["RACF:HSP1"].Level);
        Assert.Equal(ExternalAccessLevel.Read, read["RACF:BNK.MUSTERI.MASTER"].Level);     // zincir: MUS1 → dataset
        Assert.Contains(read["RACF:BNK.MUSTERI.MASTER"].Reasons, r => r.Contains("MUS1 gerektirir"));
        Assert.Contains(read["RACF:MUS1"].Reasons, r => r.Contains("GET musteri-api/v1/customers/{id}"));

        // update → UPDATE; API seviyesindeki bölge erişimi açıkça READ
        var update = catalog.ForPermission(m, m.Permissions[m.PermissionIdByCode["anka.musteri.bilgi.profil:update"]]).ToDictionary(n => n.Target.Key);
        Assert.Equal(ExternalAccessLevel.Update, update["RACF:MUS2"].Level);
        Assert.Equal(ExternalAccessLevel.Update, update["RACF:BNK.MUSTERI.MASTER"].Level);
        Assert.Equal(ExternalAccessLevel.Read, update["RACF:CICSMUS"].Level);
        Assert.False(update.ContainsKey("RACF:MUS1"));
    }

    [Fact]
    public async Task Kullanicida_ayni_dis_yetki_iki_permissiondan_gelirse_en_yuksek_seviye_alinir_LDAP_seviyesizdir()
    {
        await using var host = await TestHost.CreateAsync();
        var (catalog, m) = await LoadAsync(host);
        // elif.sahin (BRYSLAST): profil:read + profil:update
        var elif = catalog.ForUser(m, m.GetEffective(m.UserIdByName["elif.sahin"], host.Clock.UtcNow)).ToDictionary(n => n.Target.Key);
        Assert.Equal(ExternalAccessLevel.Update, elif["RACF:BNK.MUSTERI.MASTER"].Level);
        Assert.Contains(elif["RACF:BNK.MUSTERI.MASTER"].Reasons, r => r.StartsWith("anka.musteri.bilgi.profil:read"));
        Assert.Contains(elif["RACF:BNK.MUSTERI.MASTER"].Reasons, r => r.StartsWith("anka.musteri.bilgi.profil:update"));

        var ayse = catalog.ForUser(m, m.GetEffective(m.UserIdByName["ayse.yilmaz"], host.Clock.UtcNow)).ToDictionary(n => n.Target.Key);
        Assert.Null(ayse["LDAP:CN=NEXTRAL_NAKIT"].Level);                                 // doğrudan permission bağımlılığı, seviyesiz
        Assert.Equal(ExternalAccessLevel.Update, ayse["RACF:NKC1"].Level);                // create → UPDATE
    }

    [Fact]
    public async Task Permission_gidince_diger_permissionin_hala_gerektirdigi_dis_yetki_geri_alinmaz_seviyesi_duser()
    {
        await using var host = await TestHost.CreateAsync();
        var ayse = await host.UserIdAsync("ayse.yilmaz");                                  // GISEAST: profil:read var
        var update = await host.PermissionIdAsync("anka.musteri.bilgi.profil:update");

        async Task<List<Domain.Governance.ProvisioningAction>> Reconcile() =>
            (await host.WithAsync(sp => sp.GetRequiredService<ExternalProvisioningService>().ReconcileUserAsync(ayse, null, default))).ToList();

        Assert.Empty(await Reconcile());                                                   // baseline: senkron

        // Grant: MUS2 açılır, müşteri dosyası READ → UPDATE
        var impact = await host.WithAsync(sp => sp.GetRequiredService<AssignmentService>().GrantPermissionAsync(ayse, update, "test", null, default));
        var u = Assert.Single(impact.Users);
        Assert.Contains(u.ExternalGrants, g => g.Code == "MUS2" && g.Level == "UPDATE" && g.PreviousLevel == null);
        Assert.Contains(u.ExternalGrants, g => g.Code == "BNK.MUSTERI.MASTER" && g.Level == "UPDATE" && g.PreviousLevel == "READ");
        var grant = await Reconcile();
        Assert.Contains(grant, a => a.ExternalPermissionCode == "MUS2" && a.ActionType == ProvisioningActionType.Grant && a.AccessLevel == ExternalAccessLevel.Update);
        Assert.Contains(grant, a => a.ExternalPermissionCode == "BNK.MUSTERI.MASTER" && a.ActionType == ProvisioningActionType.Modify);
        Assert.All(grant, a => Assert.Equal(ProvisioningStatus.Completed, a.Status));
        Assert.Empty(await Reconcile());                                                   // idempotent

        // Revoke: MUS2 kapanır; dataset ve CICS bölgesi profil:read yüzünden KALIR (seviye UPDATE → READ)
        var revokeImpact = await host.WithAsync(sp => sp.GetRequiredService<AssignmentService>().RevokePermissionAsync(ayse, update, default));
        var r = Assert.Single(revokeImpact.Users);
        Assert.Contains(r.ExternalRevokes, x => x.Code == "MUS2");
        Assert.DoesNotContain(r.ExternalRevokes, x => x.Code is "BNK.MUSTERI.MASTER" or "CICSMUS");
        var revoke = await Reconcile();
        Assert.Contains(revoke, a => a.ExternalPermissionCode == "MUS2" && a.ActionType == ProvisioningActionType.Revoke);
        Assert.Contains(revoke, a => a.ExternalPermissionCode == "BNK.MUSTERI.MASTER" && a.ActionType == ProvisioningActionType.Modify
                                     && a.AccessLevel == ExternalAccessLevel.Read && a.PreviousAccessLevel == ExternalAccessLevel.Update);
        Assert.DoesNotContain(revoke, a => a.ExternalPermissionCode == "CICSMUS");
    }

    [Fact]
    public async Task Endpointe_yeni_bagimlilik_once_etkisi_gorulur_sonra_uygulanir_ve_mutabakat_tetiklenir()
    {
        await using var host = await TestHost.CreateAsync();
        var (catalog, m) = await LoadAsync(host);
        var endpoint = m.Data.Endpoints.Single(e => m.Apis[e.ApiId].Code == "musteri-api" && e.Method == "GET" && e.Path == "/v1/customers/{id}");
        var racf = catalog.Systems.Values.Single(s => s.Code == "RACF");
        var kmp = await host.WithAsync(sp => sp.GetRequiredService<ExternalDefinitionService>().CreatePermissionAsync(
            new ExternalPermissionUpsert { ExternalSystemId = racf.Id, Code = "KMP1", ResourceClass = "TCICSTRN", Name = "Kampanya sorgu" }, default));
        var dto = new ExternalDependencyUpsert { EndpointId = endpoint.Id, ExternalPermissionId = kmp.Id };
        var holders = m.HoldersOf(m.PermissionIdByCode["anka.musteri.bilgi.profil:read"], host.Clock.UtcNow).Count(h => h.User.IsActive);

        var preview = await host.WithAsync(sp => sp.GetRequiredService<ExternalDefinitionService>().AddDependencyAsync(dto, dryRun: true, default));
        Assert.True(preview.DryRun);
        Assert.Equal(holders, preview.AffectedUserCount);
        Assert.All(preview.Users, u => Assert.Contains(u.Grants, g => g.Code == "KMP1" && g.Level == "READ"));
        Assert.Equal(0, await host.WithAsync(sp => sp.GetRequiredService<YetkiDbContext>().ExternalDependencies.CountAsync(d => d.ExternalPermissionId == kmp.Id)));

        await host.WithAsync(sp => sp.GetRequiredService<ExternalDefinitionService>().AddDependencyAsync(dto, dryRun: false, default));
        var drift = await host.WithAsync(sp => sp.GetRequiredService<ExternalProvisioningService>().DriftAsync(default));
        Assert.Equal(holders, drift.DriftedUsers);
        Assert.True(await host.WithAsync(sp => sp.GetRequiredService<YetkiDbContext>().OutboxEvents.AnyAsync(e => e.EventType == "ExternalRequirementsChanged")));

        await host.WithAsync(sp => sp.GetRequiredService<ExternalProvisioningService>().ReconcileAllAsync(null, default));
        Assert.Equal(0, (await host.WithAsync(sp => sp.GetRequiredService<ExternalProvisioningService>().DriftAsync(default))).DriftedUsers);
    }

    [Fact]
    public async Task Pasif_kullanicinin_tum_dis_yetkileri_geri_alinir()
    {
        await using var host = await TestHost.CreateAsync();
        var ayse = await host.UserIdAsync("ayse.yilmaz");
        await host.WithAsync(sp => sp.GetRequiredService<AssignmentService>().UpdateUserAsync(ayse, new UserUpsert
        {
            FullName = "Ayşe Yılmaz", Title = "Gişe Asistanı", IsActive = false, CashWithdrawalLimit = 50_000
        }, default));
        var status = await host.WithAsync(sp => sp.GetRequiredService<ExternalProvisioningService>().GetUserStatusAsync(ayse, default));
        Assert.False(status.InSync);
        Assert.NotEmpty(status.Items);
        Assert.All(status.Items, i => Assert.Equal("Revoke", i.Action));
    }

    [Fact]
    public async Task Manifest_endpoint_ve_API_dis_bagimliliklarini_kataloga_aktarir()
    {
        await using var host = await TestHost.CreateAsync();
        var manifest = new ServiceManifest
        {
            Application = "ANKA", CatalogPath = "KART/SANAL/YONETIM",
            Api = new ManifestApi { Code = "sanal-kart-dis-api", Name = "Sanal Kart", External = [new ManifestExternal { System = "RACF", Code = "CICSKRT", ResourceClass = "APPL", Access = ExternalAccessLevel.Read }] },
            Endpoints =
            [
                new ManifestEndpoint { Method = "GET", Path = "/v1/cards/{id}", Permission = "anka.kart.sanal.yonetim:read", External = [new ManifestExternal { System = "RACF", Code = "KRT1", ResourceClass = "TCICSTRN" }] },
                new ManifestEndpoint { Method = "POST", Path = "/v1/cards", Permission = "anka.kart.sanal.yonetim:create", External = [new ManifestExternal { System = "YOKSISTEM", Code = "X" }] }
            ]
        };
        var report = await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().ImportManifestAsync(manifest, default));
        Assert.Equal(2, report.CreatedExternalDependencies);
        Assert.Contains(report.Warnings, w => w.Contains("YOKSISTEM"));
        var again = await host.WithAsync(sp => sp.GetRequiredService<CatalogService>().ImportManifestAsync(manifest, default));
        Assert.Equal(0, again.CreatedExternalDependencies);                               // idempotent

        var (catalog, m) = await LoadAsync(host);
        var endpointPermission = "anka.kart.sanal.yonetim.sanal-kart-dis-api.get.v1.cards.id:read";
        var needs = catalog.ForPermission(m, m.Permissions[m.PermissionIdByCode[endpointPermission]]).Select(n => n.Target.Key).ToList();
        Assert.Contains("RACF:CICSKRT", needs);
        Assert.Contains("RACF:KRT1", needs);
    }
}
