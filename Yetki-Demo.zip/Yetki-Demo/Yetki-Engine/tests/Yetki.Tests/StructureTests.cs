using System.Text.Json.Nodes;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Abstractions;
using Yetki.Application.Definitions;

namespace Yetki.Tests;

public class StructureTests
{
    [Theory]
    [InlineData("tenant")]
    [InlineData("client")]
    [InlineData("application")]
    [InlineData("resource")]
    [InlineData("permission")]
    [InlineData("externalSystem")]
    [InlineData("externalPermission")]
    public async Task Rename_preserves_other_fields(string kind)
    {
        await using var host = await TestHost.CreateAsync();
        await host.WithAsync(async sp =>
        {
            var db = sp.GetRequiredService<IYetkiDbContext>();
            object entity = kind switch
            {
                "tenant" => await db.Tenants.FirstAsync(),
                "client" => await db.Clients.FirstAsync(),
                "application" => await db.Applications.FirstAsync(),
                "resource" => await db.CatalogNodes.FirstAsync(),
                "permission" => await db.Permissions.FirstAsync(),
                "externalSystem" => await db.ExternalSystems.FirstAsync(),
                _ => await db.ExternalPermissions.FirstAsync()
            };
            var before = System.Text.Json.JsonSerializer.SerializeToNode(entity)!;
            var id = before["Id"]!.GetValue<int>();
            await sp.GetRequiredService<StructureService>().RenameAsync(kind, id, "  Updated name  ", default);
            var after = System.Text.Json.JsonSerializer.SerializeToNode(entity)!;
            Assert.Equal("Updated name", after["Name"]!.GetValue<string>());
            before["Name"] = "Updated name";
            Assert.Equal("test", after["UpdatedBy"]!.GetValue<string>());
            Assert.NotNull(after["UpdatedAt"]);
            before.AsObject().Remove("UpdatedAt"); after.AsObject().Remove("UpdatedAt");
            before.AsObject().Remove("UpdatedBy"); after.AsObject().Remove("UpdatedBy");
            Assert.True(JsonNode.DeepEquals(before, after), $"Before: {before}\nAfter: {after}");
        });
    }

    [Fact]
    public async Task Invalid_requests_are_rejected()
    {
        await using var host = await TestHost.CreateAsync();
        await host.WithAsync(async sp =>
        {
            var service = sp.GetRequiredService<StructureService>();
            await Assert.ThrowsAsync<ValidationException>(() => service.RenameAsync("tenant", 1, "   ", default));
            await Assert.ThrowsAsync<ValidationException>(() => service.RenameAsync("tenant", 1, new string('x', 201), default));
            await Assert.ThrowsAsync<ValidationException>(() => service.RenameAsync("unknown", 1, "Name", default));
            await Assert.ThrowsAsync<NotFoundException>(() => service.RenameAsync("tenant", int.MaxValue, "Name", default));
        });
    }
}
