using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Abstractions;
using Yetki.Application.Changes;
using Yetki.Application.Model;
using Yetki.Domain.Common;

namespace Yetki.Tests;

/// <summary>Grup kitle kuralları (VE / VEYA / hariç / süreli üyelik) ve kurum mirası.</summary>
public class GroupAndTenantTests
{
    [Fact]
    public async Task Filtreler_arasi_VEYA_filtre_ici_VE()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var members = m.GroupMembersOf(await host.GroupIdAsync("KREDI_KOMITESI"), host.Clock.UtcNow).Select(x => x.User.UserName).ToList();

        Assert.Contains("sibel.ates", members);   // kural #1: GM850UZYTK
        Assert.Contains("derya.gok", members);    // kural #1: GM850UZMYR
        Assert.Contains("ali.demir", members);    // kural #2: SUBEMDR ∧ 101
        Assert.DoesNotContain("emre.yildiz", members); // SUBEMDR ama 737 (VE sağlanmıyor)
    }

    [Fact]
    public async Task Birim_agaci_kriteri_bolge_altindaki_subeleri_kapsar()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var members = m.GroupMembersOf(await host.GroupIdAsync("IST_SUBE_MUDURLERI"), host.Clock.UtcNow).Select(x => x.User.UserName).ToHashSet();

        Assert.Equal(new HashSet<string> { "ali.demir", "emre.yildiz", "kemal.sari" }, members.Where(u => !u.StartsWith("burak")).ToHashSet());
    }

    [Fact]
    public async Task Kurum_kriteri_alt_kurumu_kapsar_miras_alinabilir_rol_uygulanir_servis_hesabi_haric()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var now = host.Clock.UtcNow;

        var berk = m.GetEffective(m.UserIdByName["berk.yaman"], now); // B İştiraki
        Assert.Contains(berk.Groups, g => g.Code == "TUM_PERSONEL");
        Assert.Contains(berk.Roles, r => r.Code == "PERSONEL" && r.Tenant == "ABANK");  // üstten miras alınabilir rol
        Assert.Contains(berk.Permissions, p => p.Code == "nextral.genel.duyuru:view");

        var svc = m.GetEffective(m.UserIdByName["svc.eod-batch"], now);
        Assert.DoesNotContain(svc.Groups, g => g.Code == "TUM_PERSONEL"); // USER_KIND=Person kriteri
    }

    [Fact]
    public async Task Miras_alinamaz_rol_alt_kurum_kullanicisina_atanamaz()
    {
        await using var host = await TestHost.CreateAsync();
        var berk = await host.UserIdAsync("berk.yaman");
        var giseast = await host.RoleIdAsync("GISEAST");

        var ex = await Assert.ThrowsAsync<ValidationException>(() =>
            host.WithAsync(sp => sp.GetRequiredService<AssignmentService>().AssignRoleAsync(berk, giseast, null, null, default)));
        Assert.Contains("miras alınamaz", ex.Message);
    }

    [Fact]
    public async Task Sureli_acik_uyelik_suresi_dolunca_yetki_duser()
    {
        await using var host = await TestHost.CreateAsync();
        var m = await host.ModelAsync();
        var burak = m.UserIdByName["burak.arslan"];

        Assert.Contains(m.GetEffective(burak, host.Clock.UtcNow).Roles, r => r.Code == "SUBEMDR" && r.Sources.Any(s => s.GroupCode == "SUBEMDR_VEKALET_737"));
        var later = host.Clock.UtcNow.AddYears(1).AddDays(1);
        Assert.DoesNotContain(m.GetEffective(burak, later).Roles, r => r.Code == "SUBEMDR");
    }

    [Fact]
    public async Task Hariç_kurali_acik_uyeyi_de_cikarir()
    {
        await using var host = await TestHost.CreateAsync();
        var group = await host.GroupIdAsync("GISE_101_AST");
        var mert = await host.UserIdAsync("mert.kaya");
        await host.WithAsync(sp => sp.GetRequiredService<AssignmentService>().SetGroupMemberAsync(group, mert, true, null, default));

        var m = await host.ModelAsync();
        var set = m.GetEffective(mert, host.Clock.UtcNow);
        Assert.DoesNotContain(set.Groups, g => g.Code == "GISE_101_AST");
        Assert.Contains(set.ExcludedFromGroups, x => x.Code == "GISE_101_AST");
    }

    [Fact]
    public async Task Unvan_degisince_grup_uyeligi_degisir_ve_etki_analizinden_gecer()
    {
        await using var host = await TestHost.CreateAsync();
        var mert = await host.UserIdAsync("mert.kaya");
        var impact = await host.WithAsync(sp => sp.GetRequiredService<AssignmentService>().UpdateUserAsync(mert, new UserUpsert
        {
            FullName = "Mert Kaya", Title = "Gişe Asistanı", IsActive = true, CashWithdrawalLimit = 10_000
        }, default));

        var u = Assert.Single(impact.Users);
        Assert.Contains("GISE_101_AST", u.AddedGroups);
        Assert.Contains(u.AddedPermissions, p => p.Code == "anka.hesap.vadeli.kampanya:create");
    }

    [Fact]
    public async Task Gecersiz_kriter_degeri_reddedilir()
    {
        await using var host = await TestHost.CreateAsync();
        var group = await host.GroupIdAsync("GISE_101_AST");
        var ex = await Assert.ThrowsAsync<ValidationException>(() => host.WithAsync(sp => sp.GetRequiredService<AssignmentService>().ReplaceGroupFiltersAsync(group,
            [new GroupFilterDraft { Criteria = [new GroupCriterionDraft { Attribute = "ROLE", Values = ["YOK_BOYLE_ROL"] }] }], default)));
        Assert.Contains("YOK_BOYLE_ROL", string.Join(" ", ex.Errors.SelectMany(e => e.Value)));
    }
}
