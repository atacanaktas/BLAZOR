# Yetki Platformu

> Son güncelleme: 4 Ekim 2026  
> Başka bir bilgisayarda devam etmek için ana başlangıç noktasıdır. Açık işler için [`TODO.md`](TODO.md), Web ayrıntıları için [`Yetki-Web/PROJE-NOTLARI.md`](Yetki-Web/PROJE-NOTLARI.md) okunmalıdır.

Bankacılık senaryolarına göre şekillenen, RBAC ile policy tabanlı kararları birleştiren bir authorization platformu prototipidir. Kimlik doğrulama ürünü değildir. Hedef; kurumsal IdP'nin kimlik, MFA, token ve oturumu yönetmesi, Yetki Platformu'nun bankaya özgü erişim kararını üretmesidir.

## Çalışan mimari

| Bileşen | Port | Sorumluluk |
| --- | ---: | --- |
| `Yetki-PAP` | 5100 | **Policy Administration Point.** Katalog, permission, policy, rule, group, client, SoD ve external dependency yönetimi; değişiklik önizleme/uygulama, audit ve outbox. Migration sahibidir. |
| `Yetki-PDP` | 5200 | **Policy Decision Point.** Runtime karar, entitlements, AuthZEN karşılığı, effective access, policy/SoD/What-if analizi ve hesaplanan view'lar. |
| `Yetki-PIP` | 5300 | **Policy Information Point.** User, role, assignment, organization ve müşteri/takvim/izin/limit attribute'ları için adaptasyon sınırı. Demo bugün ortak SQLite tablolarını kullanır. |
| `Yetki-PAP Worker` | — | Outbox olaylarını işler; external provisioning/mutabakat adaptörlerini tetikler. |
| `Yetki-Web` | 5180 | React yönetim konsolu. Yalnızca PAP ile konuşur; karar üretmez. |
| PEP | planlı SDK | Uygulamada kararı zorlayan katman. Hedef `.NET` NuGet paketi ve onun kullandığı `PDP.Client` paketidir. |

### Runtime karar akışı

```text
Application / Gateway
        │  PEP (hedef: .NET SDK)
        ▼
      PDP ───────────────► Permit / Deny / Indeterminate / NotApplicable
       │                         + reason + evidence + obligation
       ▼
      PIP ──► HR / Organization / Customer / Calendar / Limits
```

### Yönetim akışı

```text
Yetki-Web ─► PAP ─► PDP What-if / validation
                   │
                   ├─ Block SoD varsa reddet
                   └─ uygula ─► audit + outbox + model version
```

Önizleme ve gerçek karar aynı authorization model/evaluator altyapısını kullanır. PAP karar vermez; PDP sonucuna göre değişiklik iş akışını yönetir.

## Yetki modeli

- **Tenant:** İzolasyon sınırı. İzin verilen miras dışında tenant'lar arası paylaşım yoktur.
- **Client:** İsteği başlatan uygulama/servis veya `via` zincirindeki intermediary. Resource değildir; aynı yazılım farklı bağlamlarda hem client hem resource olabilir.
- **Resource:** Korunan endpoint, ekran, menü, buton veya iş nesnesi. Katalog sabit `domain/module/submodule` değildir; istenen derinlikte kurulabilir.
- **Scope:** Resource üzerindeki atomik iş eylemi (`read`, `close`, `approve`). HTTP `GET/POST` scope değildir; endpoint mapping taşıma bilgisidir.
- **Access key:** `resource:scope`, örneğin `anka.hesap.vadeli:close`.
- **Permission:** Resource/scope hedefini policy'lerle koruyan bağlama nesnesi. Access key ile aynı kavram değildir.
- **Policy:** Tipsiz karar kapsayıcısıdır. Rule ve condition ağacı `kim / nereden / ne zaman / hangi bağlamda` sorularını cevaplar.
- **Rule:** Tek policy'ye aittir; sırası, reason code'u ve aktifliği vardır. Global rule kataloğu yoktur; tekrar kullanım policy reference ile yapılır.
- **Group:** Dynamic filter ve explicit member ile audience tanımlar; role verebilir. Policy `KİM` kartıyla örtüşme riski şimdilik bilinçli kabul edilmiştir.

Condition'lar `AllOf`, `AnyOf`, `Not`, `Predicate` ve `Reference` ağaçlarıyla derlenir. Varsayılan davranış fail-closed'dur.

## Mevcut kabiliyetler

- Flexible resource tree; application, resource type, scope, endpoint/URI ve UI mapping yönetimi.
- Ownership team ve user sahibi seçimi.
- User, role, organization ve assignment view/yönetim akışları; PIP adaptasyon sınırı.
- Dynamic group filter'ları, explicit membership ve group-role ilişkisi.
- Permission oluşturma/düzenleme; endpoint seviyesinden scope üretme ve policy bağlama.
- Question-card ve advanced condition tree ile policy/rule yönetimi; policy reference, strategy, mode ve obligation.
- Client secret/token, tenant/resource soru kapsamı ve intermediary (`via`) kontrolü.
- Açıklanabilir karar: source path, policy/rule sonucu, reason code, evidence ve obligation.
- SoD tanımı, `Warn/Block`, değişiklik anı kontrolü ve geriye dönük ihlal taraması.
- Change Simulation (`/what-if`): User, Role, Group, Policy ve SoD değişiklikleri; gain/loss/retained, role/group etkisi ve CSV raporu.
- Decision Analysis (`/evaluate`): resource/action, permission veya endpoint üzerinden karar açıklaması.
- External system catalog, dependency chain, desired/current farkı, outbox ve demo provisioning adapter'ı.
- Audit/decision history, inventory/coverage ve yönetici sunumu (`/platform-brief`).
- Merkezi `DataTable`: kolon filtresi, sıralama, zebra görünüm ve 10/20/50/100 sayfa boyutu.

Kaldırılan atıl ekranlar: `/apis`, Reports, Access Overview, Gateway Simulator, Nextral Demo, eski What-if ve All-in-One. Resource yönetiminin tek adresi `/resources`, simülasyonun tek adresi `/what-if`'dir.

## Çalıştırma

Gereksinimler: .NET 9 SDK, Node.js 20.19+ veya 22.12+.

```powershell
powershell -ExecutionPolicy Bypass -File .\baslat.ps1
```

Sıra PAP → PIP → PDP → Worker → Web'dir. PAP migration uygular; PIP ve PDP eksik şema oluşturmaz. Web: `http://localhost:5180`.

Tek tek çalıştırmak için:

```powershell
cd Yetki-PAP; dotnet run --project src/Yetki.Pap.Api
cd Yetki-PIP; dotnet run --project src/Yetki.Pip.Api
cd Yetki-PDP; dotnet run --project src/Yetki.Pdp.Api
cd Yetki-PAP; dotnet run --project src/Yetki.Pap.Worker
cd Yetki-Web; npm install; npm run dev
```

## Veritabanı

Aktif yapılandırma bütün servislerde `DataBase/yetki.demo.db` dosyasını kullanır.

- `yetki.demo.db`: aktif çalışma verisi.
- `yetki.demo.yedek.db`: temiz örnek veri.
- `yetki.bos.db`: yalnızca şema içeren boş başlangıç.

Aktif veriyi değiştirmeden önce servisler kapatılmalıdır. Sample-data aracı doğrudan aktif veya boş DB'yi hedeflemez.

```powershell
cd Yetki-PAP
dotnet run --project tools/Yetki.Pap.SampleData
```

## Test ve doğrulama

4 Ekim 2026 doğrulaması:

```text
PDP: 95/95
PAP: 14/14
PIP: 15/15
Web: production build başarılı, lint temiz
```

```powershell
dotnet test Yetki-PDP\Yetki.Pdp.sln
dotnet test Yetki-PAP\Yetki.Pap.sln
dotnet test Yetki-PIP\Yetki.Pip.sln
cd Yetki-Web; npm run build; npm run lint
powershell -ExecutionPolicy Bypass -File e2e\run-e2e.ps1
```

Bu dokümantasyon turunda unit testler ve Web kontrolleri çalıştırıldı; E2E yeniden çalıştırılmadı.

## Bilinen üretim boşlukları

- PAP yönetim API'lerinde gerçek authentication/authorization yok; `X-Actor` demo bilgisidir.
- Maker-checker, versiyonlu/imzalı publish, rollback ve emergency access yok.
- PEP/PDP.Client NuGet paketleri ve enforcement conformance testleri yok.
- Servisler mantıksal olarak ayrı, fakat aynı SQLite veritabanını paylaşır.
- Demo secret'ları, rotasyon, mTLS/workload identity ve secret manager tamamlanmamıştır.
- HA/DR, kapasite, login storm, soak ve bağımsız güvenlik testleri yapılmamıştır.
- Geçmiş herhangi bir an için model + identity snapshot rekonstrüksiyonu yoktur.
- PIP cache/freshness/fail davranışı attribute sınıfı bazında sözleşmeye bağlanmamıştır.
- Süreli assignment alanları vardır; expiry ile audit/outbox/provisioning tetikleyen scheduler planlıdır.

Öncelikli iş listesi [`TODO.md`](TODO.md) içindedir.

## Keycloak karşılaştırması

- [`docs/architecture/keycloak-vs-yetki-bankacilik-degerlendirmesi.pdf`](docs/architecture/keycloak-vs-yetki-bankacilik-degerlendirmesi.pdf)
- [`docs/architecture/keycloak-vs-yetki-bankacilik-degerlendirmesi.html`](docs/architecture/keycloak-vs-yetki-bankacilik-degerlendirmesi.html)
- Uygulama içi yönetici özeti: `http://localhost:5180/platform-brief`

Keycloak gibi olgun IAM; kimlik, MFA, token ve session yaşam döngüsünde üstündür. Yetki Platformu; bankacılık attribute'ları, PIP, evidence, obligation, SoD ve değişiklik etkisinde daha özel bir hedef sunar. Öneri iki ürün sınıfını hibrit mimaride birlikte kullanmaktır.
