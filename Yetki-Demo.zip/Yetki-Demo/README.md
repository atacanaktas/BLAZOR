# Banking Authorization Architecture Demo

A working, fully local .NET 8 demo of how a modern banking application can structure
**authorization** as a first-class, centralized concern — separate from authentication,
separate from business logic, and separate from the UI.

It is not a "login + role check" demo. It shows RBAC, ABAC, policy-based authorization,
resource-based authorization, scope, permissions, capabilities, field-level authorization,
screen-level authorization, and maker/checker (separation of duties) all working together
behind one decision point: the **Authorization Service**.

No real database, no real identity provider, no real banking API. Everything is in-memory
mock data inside the service process.

## Architecture

```
                ┌──────────────┐
                │   WinForms   │
                └──────┬───────┘
                       │
                 HTTP / JSON
                       │
                       ▼
          ┌────────────────────────┐
          │ Authorization Service  │
          ├────────────────────────┤
          │ RBAC                   │
          │ ABAC                   │
          │ Scope                  │
          │ Policy Engine          │
          │ Resource Authorization │
          │ Field Authorization    │
          └────────────┬───────────┘
                       │
                 ALLOW / DENY / MASK
                       │
                       ▼
                  WinForms UI
```

The two projects are independent and only agree on the JSON wire format:

```
BankingAuthorizationDemo.sln
│
├── BankingAuthorizationService   ASP.NET Core Web API — the authorization decision point
├── BankingDemo.WinForms          .NET 8 WinForms client — renders whatever the API decides
└── BankingAuthorizationService.Tests   xUnit tests for the policy pipeline
```

**The golden rule enforced throughout the codebase:** WinForms never contains authorization
logic. There is no `if (user.Role == "Admin")` and no `if (user.Permissions.Contains(...))`
anywhere in the client. Every screen asks the Authorization Service "what can I show?" and
renders the answer. The server re-checks authorization on every mutating endpoint too — the
client's own check is only used to shape the UI, never trusted as the real gate.

## Project structure

```
BankingAuthorizationService/
├── Authorization/     AuthorizationEngine, AuthorizationContext, Request/Response DTOs
├── Policies/          IPolicy + one class per policy (see below)
├── Rbac/               RbacService — role → permission resolution, incl. "*" wildcard
├── Abac/               AbacEvaluator — attribute comparisons, company-scope matching
├── Resources/          ResourceService — in-memory resource lookup
├── Screens/            Screen → Capability → Permission registry + calculation
├── Services/           User/Role/Permission catalogs + Customer/Account/Payment/Transfer
│                       banking services (apply authorization + field masking)
├── MockData/           MockUsers, MockRoles, MockPermissions, MockResources (in-memory store)
├── Audit/               In-memory authorization decision log
├── Controllers/        AuthorizationController, ScreenController, Customer/Account/
│                       Payment/Transfer controllers, CatalogController (users/roles/
│                       permissions/resources)
└── Common/              Permission/Role/Resource-type/Decision string constants

BankingDemo.WinForms/
├── Authorization/       AuthorizationClient (HTTP), CapabilityService, CurrentUserContext
├── Models/               Client-side DTOs mirroring the service's JSON contracts
├── Services/             HTTP wrappers for the mock banking endpoints
└── Forms/                LoginForm, MainForm (nav shell), AuthorizationDebugForm, and one
    └── Panels/           UserControl per screen (Dashboard, Customers, Accounts, Payments,
                           Transfers, Audit, Reports, Administration)
```

## RBAC

`RbacService` resolves a user's roles to a permission set. A role holding the permission
`"*"` (only `BankAdmin`) is granted everything. Permissions are not limited to CRUD — business
actions (`approve`, `reject`, `execute`, `submit`, `cancel`) are first-class permissions in
`resource.action` form (see `Common/PermissionNames.cs`).

| Role | Representative permissions |
|---|---|
| FinanceViewer | `customer.read`, `account.read`, `account.balance.view`, `transaction.read` |
| FinanceOperator | + `payment.create`, `payment.submit`, `transfer.create`, `statement.download` |
| FinanceManager | + `payment.approve/reject/execute`, `transfer.approve/execute`, `account.balance.view.vip`, `customer.phone.view`, `customer.identity.view` (approval limit: 1,000,000 TRY) |
| Auditor | read-only + `audit_log.read`, `report.export` |
| BankAdmin | `*` (everything, unlimited approval) |

## ABAC & Scope

Every resource (customer, account, payment, transaction) is modeled uniformly:

```csharp
public class Resource
{
    public string Id { get; set; }
    public string Type { get; set; }
    public string? ParentId { get; set; }
    public Dictionary<string, object> Attributes { get; set; }
}
```

`CompanyScopePolicy` compares `resource.Attributes["companyId"]` against `user.CompanyScope`.
A scope of `"*"` (BankAdmin) always matches; a resource with no `companyId` is treated as
unscoped. This single generic check runs for every resource-bound permission, before any
permission-specific policy.

## Policy engine

```csharp
public interface IPolicy
{
    string Name { get; }
    PolicyEvaluationResult Evaluate(AuthorizationContext context);
}
```

`PolicyRegistry` maps a permission to the policy that governs its instance-level rules:

| Permission | Policy | Rule |
|---|---|---|
| `account.read` | AccountReadPolicy | scope (generic) |
| `account.balance.view` | AccountBalanceViewPolicy | delegates to VIPBalancePolicy |
| `transaction.read` | TransactionReadPolicy | scope (generic) |
| `payment.create` | PaymentCreatePolicy | target company within scope |
| `payment.approve` | PaymentApprovePolicy | status PENDING_APPROVAL + maker/checker + approval limit |
| `payment.reject` | PaymentRejectPolicy | status PENDING_APPROVAL + maker/checker |
| `payment.execute` | PaymentExecutePolicy | status APPROVED |
| `transfer.create` | TransferCreatePolicy | scope (generic) |

Permissions with no entry still go through RBAC + scope; the registry only adds extra
ABAC/SoD/limit rules where a permission needs them.

## Field-level authorization

Sensitive customer fields are gated by dedicated permissions (`customer.phone.view`,
`customer.identity.view`). The server **never sends the real value** to a caller who lacks
the permission — it returns `null` plus a boolean flag:

```json
{ "phone": null, "phoneMasked": true }
```

This is enforced in `CustomerService.MapToDto`, which runs an authorization check per field
before deciding what to put in the DTO. Masking is not a UI-side decision.

## Maker / Checker (Separation of Duties)

`MakerCheckerPolicy` denies an approve/reject when `payment.createdBy == user.id`, regardless
of whether the user otherwise has `payment.approve`. Demo users: Mehmet (maker) creates and
submits payments; Ayşe (checker) approves/rejects/executes them. Mehmet approving his own
payment is denied with reason *"Maker cannot approve own payment"*.

## VIP balance masking

`VIPBalancePolicy`: if the account's customer has `segment == "VIP"` and the caller lacks
`account.balance.view.vip`, the decision is **MASK**, not ALLOW or DENY — the caller has
`account.balance.view` (so the account itself is visible) but the balance value is withheld.
FinanceViewer/Operator see `********` for account `2002` (customer `1002`, VIP); FinanceManager
and BankAdmin see the real balance (8,500,000 TRY).

## Decision types: ALLOW / DENY / MASK

```csharp
public enum PolicyDecision { Allow, Deny, Mask }
```

`AuthorizationResponse.Allowed` is `true` only for ALLOW. MASK still comes back as
`Allowed: false` — the client is not handed the real value, only permission to render a
masked placeholder.

## Example request / response

```json
POST /api/authorization/check
{
  "userId": "user-3",
  "permission": "payment.approve",
  "resourceType": "payment",
  "resourceId": "payment:3001"
}
```

```json
{
  "allowed": true,
  "decision": "ALLOW",
  "permission": "payment.approve",
  "resource": "payment:3001",
  "reasons": [
    "Role FinanceManager has payment.approve",
    "Payment is pending approval, not self-created, and within approval limit"
  ],
  "roleUsed": "FinanceManager",
  "policyName": "PaymentApprovePolicy",
  "steps": [
    { "step": "User Exists", "result": "PASS" },
    { "step": "RBAC", "result": "PASS" },
    { "step": "Scope", "result": "PASS" },
    { "step": "Payment Status", "result": "PASS" },
    { "step": "Maker/Checker", "result": "PASS" },
    { "step": "Amount Limit", "result": "PASS" },
    { "step": "Policy", "result": "PaymentApprovePolicy" }
  ]
}
```

Every step of the pipeline is recorded, which is exactly what the WinForms **Authorization
Debug** dialog renders after every button click.

## Screen → Capability → Permission

WinForms never asks "do I have `payment.approve`?" — it asks "what can I show on the Payments
screen for this payment?":

```
GET /api/screens/payments/capabilities?userId=user-2&resourceId=payment:3001
```

```json
{
  "screen": "payments",
  "capabilities": {
    "view_payments": true,
    "create_payment": true,
    "submit_payment": true,
    "approve_payment": false,
    "reject_payment": false,
    "execute_payment": false,
    "cancel_payment": true
  }
}
```

A screen can (and typically does) depend on more than one permission; a single permission can
back capabilities on more than one screen. `create_transfer` appears both under
`account-detail` and `transfers` but always resolves to the same `transfer.create` check.

## Demo users

| User | Username | Role | Company scope | Approval limit |
|---|---|---|---|---|
| Ahmet Yılmaz | ahmet | Finance Viewer | company:10 | — |
| Mehmet Öz | mehmet | Finance Operator | company:10 | — |
| Ayşe Kara | ayse | Finance Manager | company:10 | 1,000,000 TRY |
| Admin | admin | Bank Admin | * (global) | unlimited |
| Denetçi | auditor | Auditor | company:10 | — |

## Running the demo

Requirements: .NET 8 SDK (or newer, with the net8.0 runtime installed), Windows (WinForms).

1. **Start the Authorization Service** (from the repo root):
   ```
   dotnet run --project BankingAuthorizationService
   ```
   It listens on `http://localhost:5080` and serves Swagger at `/swagger` for exploring the
   API directly.

2. **Start the WinForms client** (in a second terminal):
   ```
   dotnet run --project BankingDemo.WinForms
   ```
   The base URL is read from `BankingDemo.WinForms/appsettings.json`
   (`AuthorizationService:BaseUrl`, defaults to `http://localhost:5080/`).

3. Pick a user from the login combo box and click **Login**. The left navigation, every grid
   column, and every action button are shaped entirely by what the Authorization Service
   returns for that user.

4. Run the unit tests:
   ```
   dotnet test BankingAuthorizationService.Tests
   ```

## Example scenarios to try in the UI

- **Login as Ahmet (Finance Viewer)** → open Accounts → account `2001`: balance, transactions
  visible; "New Transfer" and "Download Statement" disabled. Select account `2002` (VIP): the
  balance shows `********`.
- **Login as Mehmet (Finance Operator)** → Payments: create a payment, submit it, then select
  it — Approve/Reject/Execute are disabled (no permission).
- **Login as Ayşe (Finance Manager)** → Payments: select `payment:3001` (created by Mehmet,
  250,000 TRY) → Approve → the Authorization Debug dialog shows every step passing → ALLOW.
- Still as Ayşe, select `payment:3002` (2,000,000 TRY) → Approve → DENY, *"Payment amount
  exceeds approval limit"*.
- Still as Ayşe, select `payment:3003` (company:20) → Approve → DENY, *"Resource is outside
  user's company scope"*.
- **Login as Ayşe** → Accounts → account `2002` (VIP) → balance now shows the real amount
  (8,500,000 TRY), because FinanceManager holds `account.balance.view.vip`.
- **Login as Admin** → every nav item and every action is visible (wildcard role).
- **Audit** screen (any user with `audit_log.read`, e.g. Auditor or Admin) shows every
  decision made this session, newest first, including the denials above.

## Answering the design questions this demo targets

- **Can a screen use more than one permission?** Yes — `account-detail` alone depends on five.
- **Screen vs. permission?** A screen exposes capabilities; each capability maps to exactly
  one permission (`Screens/ScreenCapabilityRegistry.cs`), but the mapping is many-to-one in
  both directions across screens.
- **How does an endpoint decide its permission?** Each controller action passes a fixed
  permission string to `AuthorizationEngine.Check` — never derived from the caller's role.
- **Resource authorization?** Every resource-bound check loads the concrete `Resource` and
  runs scope + policy evaluation against its attributes, not just the permission name.
- **User scope?** `CompanyScopePolicy` compares `resource.companyId` to `user.CompanyScope`.
- **VIP balance masking?** `VIPBalancePolicy`, returning `MASK` instead of `ALLOW`/`DENY`.
- **Maker/checker?** `MakerCheckerPolicy`, reused by both `PaymentApprovePolicy` and
  `PaymentRejectPolicy`.
- **Approval limit?** `RbacService.GetApprovalLimit`, consumed by `PaymentApprovePolicy`.
- **ABAC?** `AbacEvaluator` + `Resource.Attributes`, used throughout the policies.
- **Same permission, different outcome per resource?** `payment.approve` on `payment:3001`
  (ALLOW), `payment:3002` (DENY — limit) and `payment:3003` (DENY — scope) with the exact same
  user and permission.
- **UI vs. backend authorization?** The UI's checks only decide what to render; every mutating
  controller action re-runs `AuthorizationEngine.Check` before touching data.
- **How do I debug a decision?** The `steps` array in `AuthorizationResponse`, rendered by
  `AuthorizationDebugForm` after every authorization-checked button click.
