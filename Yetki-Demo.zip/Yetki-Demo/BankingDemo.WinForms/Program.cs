using BankingDemo.WinForms.Authorization;
using BankingDemo.WinForms.Forms;
using BankingDemo.WinForms.Forms.Panels;
using BankingDemo.WinForms.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace BankingDemo.WinForms;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();

        var builder = Host.CreateApplicationBuilder();
        builder.Configuration.SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false);

        var baseUrl = builder.Configuration["AuthorizationService:BaseUrl"] ?? "http://localhost:5080/";

        // Every HTTP-backed service shares the same base address: the Authorization Service
        // hosts both the authorization endpoints and the mock banking endpoints.
        builder.Services.AddHttpClient<IAuthorizationClient, AuthorizationClient>(c => c.BaseAddress = new Uri(baseUrl));
        builder.Services.AddHttpClient<ICustomerService, CustomerService>(c => c.BaseAddress = new Uri(baseUrl));
        builder.Services.AddHttpClient<IAccountService, AccountService>(c => c.BaseAddress = new Uri(baseUrl));
        builder.Services.AddHttpClient<IPaymentService, PaymentService>(c => c.BaseAddress = new Uri(baseUrl));
        builder.Services.AddHttpClient<ITransferService, TransferService>(c => c.BaseAddress = new Uri(baseUrl));
        builder.Services.AddHttpClient<IUserDirectoryService, UserDirectoryService>(c => c.BaseAddress = new Uri(baseUrl));

        builder.Services.AddSingleton<ICurrentUserContext, CurrentUserContext>();
        builder.Services.AddSingleton<ICapabilityService, CapabilityService>();

        builder.Services.AddTransient<LoginForm>();
        builder.Services.AddTransient<MainForm>();
        builder.Services.AddTransient<DashboardPanel>();
        builder.Services.AddTransient<CustomerPanel>();
        builder.Services.AddTransient<AccountPanel>();
        builder.Services.AddTransient<PaymentPanel>();
        builder.Services.AddTransient<TransferPanel>();
        builder.Services.AddTransient<AuditPanel>();
        builder.Services.AddTransient<ReportsPanel>();
        builder.Services.AddTransient<AdministrationPanel>();

        using var host = builder.Build();

        var loginForm = host.Services.GetRequiredService<LoginForm>();
        if (loginForm.ShowDialog() == DialogResult.OK)
        {
            var mainForm = host.Services.GetRequiredService<MainForm>();
            Application.Run(mainForm);
        }
    }
}
