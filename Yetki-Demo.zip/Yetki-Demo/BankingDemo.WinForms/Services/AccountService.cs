using System.Net.Http.Json;
using BankingDemo.WinForms.Common;
using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

public class AccountService : IAccountService
{
    private readonly HttpClient _httpClient;

    public AccountService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<Account>> GetAllAsync(string userId, CancellationToken cancellationToken = default)
    {
        var result = await _httpClient.GetFromJsonAsync<List<Account>>($"api/accounts?userId={userId}", JsonOptions.Default, cancellationToken);
        return result ?? new List<Account>();
    }

    public async Task<List<Transaction>> GetTransactionsAsync(string userId, string accountId, CancellationToken cancellationToken = default)
    {
        var result = await _httpClient.GetFromJsonAsync<List<Transaction>>($"api/accounts/{accountId}/transactions?userId={userId}", JsonOptions.Default, cancellationToken);
        return result ?? new List<Transaction>();
    }
}
