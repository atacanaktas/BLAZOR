using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Tests;

public class AuthorizationEngineTests
{
    [Fact]
    public void FinanceViewer_CanReadAccount()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.Ahmet,
            Permission = PermissionNames.AccountRead,
            ResourceType = ResourceTypes.Account,
            ResourceId = "account:2001"
        });

        Assert.True(response.Allowed);
        Assert.Equal(DecisionNames.Allow, response.Decision);
    }

    [Fact]
    public void FinanceViewer_CannotCreateTransfer()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.Ahmet,
            Permission = PermissionNames.TransferCreate,
            ResourceType = ResourceTypes.Account,
            ResourceId = "account:2001"
        });

        Assert.False(response.Allowed);
        Assert.Equal(DecisionNames.Deny, response.Decision);
    }

    [Fact]
    public void FinanceOperator_CanCreatePayment()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.Mehmet,
            Permission = PermissionNames.PaymentCreate,
            ResourceType = ResourceTypes.Payment,
            Context = new Dictionary<string, object> { ["companyId"] = "company:10" }
        });

        Assert.True(response.Allowed);
    }

    [Fact]
    public void FinanceOperator_CannotApprovePayment()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.Mehmet,
            Permission = PermissionNames.PaymentApprove,
            ResourceType = ResourceTypes.Payment,
            ResourceId = "payment:3001"
        });

        Assert.False(response.Allowed);
        Assert.Contains(response.Steps, s => s.Step == "RBAC" && s.Result == StepResultNames.Fail);
    }

    [Fact]
    public void FinanceManager_CanApprovePayment()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.Ayse,
            Permission = PermissionNames.PaymentApprove,
            ResourceType = ResourceTypes.Payment,
            ResourceId = "payment:3001"
        });

        Assert.True(response.Allowed);
        Assert.Equal("PaymentApprovePolicy", response.PolicyName);
    }

    [Fact]
    public void UserCannotApproveOwnPayment()
    {
        var (engine, resources, _) = TestEngineFactory.Create();

        // Ayşe (FinanceManager, has payment.approve) creates her own payment, then tries to approve it.
        resources.Add(new Resource
        {
            Id = "payment:9001",
            Type = ResourceTypes.Payment,
            Attributes = new Dictionary<string, object>
            {
                ["companyId"] = "company:10",
                ["amount"] = 10000m,
                ["currency"] = "TRY",
                ["status"] = PaymentStatus.PendingApproval,
                ["createdBy"] = UserIds.Ayse
            }
        });

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.Ayse,
            Permission = PermissionNames.PaymentApprove,
            ResourceType = ResourceTypes.Payment,
            ResourceId = "payment:9001"
        });

        Assert.False(response.Allowed);
        Assert.Equal("MakerCheckerPolicy", response.PolicyName);
        Assert.Contains(response.Reasons, r => r.Contains("Maker cannot approve own payment"));
    }

    [Fact]
    public void PaymentAboveApprovalLimit_IsDenied()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.Ayse,
            Permission = PermissionNames.PaymentApprove,
            ResourceType = ResourceTypes.Payment,
            ResourceId = "payment:3002" // 2,000,000 TRY, above FinanceManager's 1,000,000 limit
        });

        Assert.False(response.Allowed);
        Assert.Contains(response.Reasons, r => r.Contains("exceeds approval limit"));
    }

    [Fact]
    public void UserOutsideCompanyScope_IsDenied()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.Ayse,
            Permission = PermissionNames.PaymentApprove,
            ResourceType = ResourceTypes.Payment,
            ResourceId = "payment:3003" // belongs to company:20, Ayşe's scope is company:10
        });

        Assert.False(response.Allowed);
        Assert.Equal("CompanyScopePolicy", response.PolicyName);
    }

    [Fact]
    public void VipBalance_IsMaskedForNormalUser()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.Ahmet, // FinanceViewer, no account.balance.view.vip
            Permission = PermissionNames.AccountBalanceView,
            ResourceType = ResourceTypes.Account,
            ResourceId = "account:2002" // VIP customer's account
        });

        Assert.False(response.Allowed);
        Assert.Equal(DecisionNames.Mask, response.Decision);
        Assert.Equal("VIPBalancePolicy", response.PolicyName);
    }

    [Fact]
    public void VipBalance_IsVisibleForPrivilegedUser()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.Ayse, // FinanceManager, has account.balance.view.vip
            Permission = PermissionNames.AccountBalanceView,
            ResourceType = ResourceTypes.Account,
            ResourceId = "account:2002"
        });

        Assert.True(response.Allowed);
        Assert.Equal(DecisionNames.Allow, response.Decision);
    }

    [Fact]
    public void UserWithoutIdentityPermission_CannotSeeNationalId()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.Ahmet, // FinanceViewer has no customer.identity.view
            Permission = PermissionNames.CustomerIdentityView,
            ResourceType = ResourceTypes.Customer,
            ResourceId = "customer:1001"
        });

        Assert.False(response.Allowed);
    }

    [Fact]
    public void BatchAuthorization_ReturnsCorrectResults()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.CheckBatch(new BatchAuthorizationRequest
        {
            UserId = UserIds.Ahmet,
            Checks = new List<AuthorizationCheckItem>
            {
                new() { Permission = PermissionNames.AccountRead, ResourceType = ResourceTypes.Account, ResourceId = "account:2001" },
                new() { Permission = PermissionNames.AccountBalanceView, ResourceType = ResourceTypes.Account, ResourceId = "account:2001" },
                new() { Permission = PermissionNames.TransactionRead, ResourceType = ResourceTypes.Account, ResourceId = "account:2001" },
                new() { Permission = PermissionNames.TransferCreate, ResourceType = ResourceTypes.Account, ResourceId = "account:2001" }
            }
        });

        Assert.Equal(4, response.Results.Count);
        Assert.True(response.Results[0].Allowed);
        Assert.True(response.Results[1].Allowed);
        Assert.True(response.Results[2].Allowed);
        Assert.False(response.Results[3].Allowed);
    }
}
