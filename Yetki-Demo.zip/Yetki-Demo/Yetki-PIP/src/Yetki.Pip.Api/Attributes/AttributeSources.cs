using System.Globalization;
using Microsoft.EntityFrameworkCore;
using Yetki.Pip.Api.Data;
using Yetki.Pip.Api.Identity;

namespace Yetki.Pip.Api.Attributes;

// ============================================================================================
//  Kimlik dışı öznitelik kaynakları (XACML PIP): iş takvimi, izin, müşteri.
//  Her biri bir ADAPTÖR arayüzüdür; bugün kurala dayalı geçici (stub) uygulamalar çalışır, ileride gerçek kaynak
//  (takvim servisi, İK izin sistemi, müşteri / core banking) aynı arayüzle takılır. PDP ve PIP sözleşmesi değişmez.
// ============================================================================================

public sealed record BusinessDayInfo(string Date, bool IsBusinessDay, string Reason, string Source);

public sealed record LeaveInfo(int UserId, string Date, bool OnLeave, string Reason, string Source);

public sealed record CustomerInfo(string CustomerNo, bool IsVip, bool IsStaff, string Source);

/// <summary>Kullanıcının bir limit türündeki durumu (TRY): işlem başı limit, günlük toplam limit, bugün kullanılan, kalan.</summary>
public sealed record LimitInfo(int UserId, string Type, string Date, decimal PerTransactionLimit, decimal DailyLimit, decimal UsedToday,
    decimal RemainingToday, string Currency, string Source);

/// <summary>Personelin birimi (birincil; birincil işaretli yoksa ilk bağlı birim). Bankada her personelin bir birimi vardır (şube, GM dairesi, IT...).</summary>
public sealed record UserUnitInfo(int UserId, string UnitCode, string UnitName, string UnitType, bool IsPrimary, string Source);

/// <summary>Kullanıcı limitleri (limit yönetim sistemi / core banking).</summary>
public interface ILimitSource
{
    Task<LimitInfo> GetAsync(int userId, string type, DateOnly date, CancellationToken ct);
}

/// <summary>
/// GEÇİCİ: işlem başı limit kullanıcı kaydındaki nakit çekim limiti; günlük toplam limit = işlem başı × çarpan (Pip:Sources:Limits:DailyMultiplier,
/// varsayılan 3); bugün kullanılan HER ZAMAN 0 (her işlem günün ilk işlemi sayılır). Gerçek limit sistemi gelince değiştirilir.
/// </summary>
public sealed class UserRecordLimitSource(PipDbContext db, IConfiguration config) : ILimitSource
{
    public const string Cash = "CASH";

    public async Task<LimitInfo> GetAsync(int userId, string type, DateOnly date, CancellationToken ct)
    {
        var t = (type ?? Cash).Trim().ToUpperInvariant();
        if (t != Cash) throw new ValidationException($"Desteklenmeyen limit türü: {t} (şimdilik sadece {Cash}).");
        var perTransaction = await db.Users.AsNoTracking().Where(u => u.Id == userId).Select(u => (decimal?)u.CashWithdrawalLimit).FirstOrDefaultAsync(ct)
                             ?? throw new NotFoundException("Kullanıcı", userId);
        var multiplier = config.GetValue("Pip:Sources:Limits:DailyMultiplier", 3m);
        var daily = perTransaction * multiplier;
        const decimal usedToday = 0m;
        return new LimitInfo(userId, t, date.ToString("yyyy-MM-dd"), perTransaction, daily, usedToday, daily - usedToday, "TRY",
            $"stub:kullanici-kaydi(gunluk=islem*{multiplier.ToString(CultureInfo.InvariantCulture)},kullanilan=0)");
    }
}

/// <summary>İş günü takvimi.</summary>
public interface IBusinessCalendar
{
    Task<BusinessDayInfo> GetAsync(DateOnly date, CancellationToken ct);
}

/// <summary>Kullanıcının belirli bir gündeki izin durumu.</summary>
public interface ILeaveSource
{
    Task<LeaveInfo> GetAsync(int userId, DateOnly date, CancellationToken ct);
}

/// <summary>Müşteri öznitelikleri (segment, personel müşterisi...).</summary>
public interface ICustomerDirectory
{
    Task<CustomerInfo> GetAsync(string customerNo, CancellationToken ct);
}

/// <summary>GEÇİCİ: hafta içi = iş günü. Resmî tatil / arife / köprü bilmez; gerçek takvim servisi gelince değiştirilir.</summary>
public sealed class WeekdayBusinessCalendar : IBusinessCalendar
{
    public Task<BusinessDayInfo> GetAsync(DateOnly date, CancellationToken ct)
    {
        var weekday = date.DayOfWeek is not (DayOfWeek.Saturday or DayOfWeek.Sunday);
        var day = date.ToString("dddd", CultureInfo.GetCultureInfo("tr-TR"));
        return Task.FromResult(new BusinessDayInfo(date.ToString("yyyy-MM-dd"), weekday,
            weekday ? $"{day}: hafta içi" : $"{day}: hafta sonu", "stub:hafta-ici"));
    }
}

/// <summary>GEÇİCİ: kimse izinde değil. Gerçek İK izin kaynağı gelince değiştirilir.</summary>
public sealed class AlwaysAvailableLeaveSource : ILeaveSource
{
    public Task<LeaveInfo> GetAsync(int userId, DateOnly date, CancellationToken ct) =>
        Task.FromResult(new LeaveInfo(userId, date.ToString("yyyy-MM-dd"), false, "İzin kaynağı bağlı değil: izinde değil kabul edildi.", "stub:izinde-degil"));
}

/// <summary>Kullanıcı kaydındaki "izinde" işareti (elle yönetilen alan). Pip:Sources:Leave = "UserRecord" ile seçilir.</summary>
public sealed class UserRecordLeaveSource(PipDbContext db) : ILeaveSource
{
    public async Task<LeaveInfo> GetAsync(int userId, DateOnly date, CancellationToken ct)
    {
        var onLeave = await db.Users.AsNoTracking().Where(u => u.Id == userId).Select(u => (bool?)u.IsOnLeave).FirstOrDefaultAsync(ct)
                      ?? throw new NotFoundException("Kullanıcı", userId);
        return new LeaveInfo(userId, date.ToString("yyyy-MM-dd"), onLeave, onLeave ? "Kullanıcı kaydında izinde işaretli." : "Kullanıcı kaydında izinde değil.", "kullanici-kaydi");
    }
}

/// <summary>
/// GEÇİCİ: müşteri numarası önekine göre. "99" ile başlayan → VIP; "98" ile başlayan → personel müşterisi
/// (personelin kendi müşteri kaydı: maaş vb. bilgileri sadece yetkili personel görür). Gerçek müşteri servisi gelince değiştirilir.
/// </summary>
public sealed class PrefixCustomerDirectory : ICustomerDirectory
{
    public Task<CustomerInfo> GetAsync(string customerNo, CancellationToken ct)
    {
        var no = customerNo.Trim();
        if (no.Length == 0) throw new ValidationException("Müşteri numarası boş.");
        return Task.FromResult(new CustomerInfo(no, no.StartsWith("99", StringComparison.Ordinal), no.StartsWith("98", StringComparison.Ordinal), "stub:onek"));
    }
}
