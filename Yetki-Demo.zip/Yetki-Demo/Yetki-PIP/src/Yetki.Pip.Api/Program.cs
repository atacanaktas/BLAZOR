using System.Globalization;
using System.Text.Json.Serialization;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Yetki.Pip.Api.Data;
using Yetki.Pip.Api.Identity;
using Yetki.Pip.Api.Infrastructure;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.InvariantCulture;

var builder = WebApplication.CreateBuilder(args);

// PIP (kimlik bilgi noktası). Veritabanı PAP / PDP ile paylaşılır (DataBase klasörü); şema PAP'ındır, PIP migration çalıştırmaz.
builder.Services.AddPip(builder.Configuration, builder.Environment.ContentRootPath);
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentActor, HttpCurrentActor>();
builder.Services.Configure<PipOptions>(builder.Configuration.GetSection("Pip"));

builder.Services.AddControllers(o => o.Filters.Add<ApiExceptionFilter>())
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        o.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "Yetki PIP", Version = "v1", Description = "Kimlik bilgi noktası: kullanıcı, rol, rol ataması, birim (İK verisi). X-Service-Key ister." });
    c.AddSecurityDefinition("ServiceKey", new() { Type = Microsoft.OpenApi.Models.SecuritySchemeType.ApiKey, In = Microsoft.OpenApi.Models.ParameterLocation.Header, Name = PipOptions.HeaderName });
    c.AddSecurityRequirement(new()
    {
        [new Microsoft.OpenApi.Models.OpenApiSecurityScheme { Reference = new() { Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme, Id = "ServiceKey" } }] = []
    });
});

var app = builder.Build();

await app.Services.CheckPipDatabaseAsync();

app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();
app.MapGet("/", () => Results.Redirect("/swagger")).ExcludeFromDescription();

app.Run();

public partial class Program;

public static class PipSetup
{
    /// <summary>Persistence:Provider "Sqlite" (varsayılan, ortak veritabanı) veya "InMemory" (testler).</summary>
    public static IServiceCollection AddPip(this IServiceCollection services, IConfiguration config, string? basePath = null)
    {
        var provider = config["Persistence:Provider"] ?? "Sqlite";
        services.AddDbContext<PipDbContext>(o =>
        {
            if (provider == "InMemory") o.UseInMemoryDatabase(config["Persistence:InMemoryDatabaseName"] ?? "pip");
            else
            {
                var b = new SqliteConnectionStringBuilder(config.GetConnectionString("Yetki") ?? "Data Source=yetki.db");
                if (basePath is not null && !Path.IsPathRooted(b.DataSource)) b.DataSource = Path.GetFullPath(Path.Combine(basePath, b.DataSource));
                o.UseSqlite(b.ToString());
            }
        });
        services.AddSingleton<IClock, SystemClock>();
        services.AddScoped<IdentityService>();

        // Kimlik dışı öznitelik kaynakları (adaptör). Bugün geçici kurallar; gerçek kaynak gelince buradan değiştirilir.
        services.AddSingleton<Yetki.Pip.Api.Attributes.IBusinessCalendar, Yetki.Pip.Api.Attributes.WeekdayBusinessCalendar>();
        services.AddSingleton<Yetki.Pip.Api.Attributes.ICustomerDirectory, Yetki.Pip.Api.Attributes.PrefixCustomerDirectory>();
        services.AddScoped<Yetki.Pip.Api.Attributes.ILimitSource, Yetki.Pip.Api.Attributes.UserRecordLimitSource>();
        switch (config["Pip:Sources:Leave"] ?? "AlwaysAvailable")
        {
            case "AlwaysAvailable": services.AddSingleton<Yetki.Pip.Api.Attributes.ILeaveSource, Yetki.Pip.Api.Attributes.AlwaysAvailableLeaveSource>(); break;
            case "UserRecord": services.AddScoped<Yetki.Pip.Api.Attributes.ILeaveSource, Yetki.Pip.Api.Attributes.UserRecordLeaveSource>(); break;
            default: throw new InvalidOperationException("Desteklenmeyen izin kaynağı: " + config["Pip:Sources:Leave"]);
        }
        return services;
    }

    /// <summary>Şema PAP'ındır: veritabanı veya IdentityState tablosu yoksa başlatma durur. InMemory'de şema kurulur.</summary>
    public static async Task CheckPipDatabaseAsync(this IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<PipDbContext>();
        if (!db.Database.IsRelational()) { await db.Database.EnsureCreatedAsync(); return; }
        var source = db.Database.GetDbConnection().DataSource;
        if (!File.Exists(source)) throw new InvalidOperationException($"Veritabanı bulunamadı: {source}. PIP şema oluşturmaz; PAP migration'larını uygulayın.");
        try { await db.IdentityStates.AsNoTracking().AnyAsync(); }
        catch (Exception ex) { throw new InvalidOperationException($"Veritabanı şeması PIP ile uyumsuz ({source}): IdentityState okunamadı. PAP migration'larını uygulayın.", ex); }
        scope.ServiceProvider.GetRequiredService<ILoggerFactory>().CreateLogger("Yetki.Pip").LogInformation("PIP veritabanı hazır: {Source}", source);
    }
}
