using Microsoft.EntityFrameworkCore;

namespace Yetki.Pip.Api.Data;

public interface IClock
{
    DateTime UtcNow { get; }
}

public sealed class SystemClock : IClock
{
    public DateTime UtcNow => DateTime.UtcNow;
}

public interface ICurrentActor
{
    string Name { get; }
}

/// <summary>
/// Kimlik tablolarının PIP görünümü (ortak veritabanı; şema PAP'ındır, PIP migration çalıştırmaz).
/// Kimlik verisi değişirse IdentityState.Revision değişiklikle AYNI transaction'da artırılır.
/// </summary>
public class PipDbContext(DbContextOptions<PipDbContext> options, IClock clock, ICurrentActor actor) : DbContext(options)
{
    public DbSet<Tenant> Tenants => Set<Tenant>();
    public DbSet<OrgUnit> OrgUnits => Set<OrgUnit>();
    public DbSet<User> Users => Set<User>();
    public DbSet<UserOrgUnit> UserOrgUnits => Set<UserOrgUnit>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<IdentityState> IdentityStates => Set<IdentityState>();

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        var now = clock.UtcNow;
        foreach (var e in ChangeTracker.Entries())
        {
            if (e.Entity is Audited a)
            {
                if (e.State == EntityState.Added) { if (a.CreatedAt == default) a.CreatedAt = now; a.CreatedBy = actor.Name; }
                else if (e.State == EntityState.Modified) { a.UpdatedAt = now; a.UpdatedBy = actor.Name; }
            }
            if (e.Entity is IAssigned asg && e.State == EntityState.Added)
            {
                if (asg.AssignedAt == default) asg.AssignedAt = now;
                if (string.IsNullOrEmpty(asg.AssignedBy) || asg.AssignedBy == "system") asg.AssignedBy = actor.Name;
            }
        }
        var bump = ChangeTracker.Entries().Any(e => e.State is EntityState.Added or EntityState.Modified or EntityState.Deleted && e.Entity is not IdentityState);
        if (!bump) return await base.SaveChangesAsync(cancellationToken);

        int result;
        if (Database.IsRelational())
        {
            await using var tx = Database.CurrentTransaction is null ? await Database.BeginTransactionAsync(cancellationToken) : null;
            result = await base.SaveChangesAsync(cancellationToken);
            await Database.ExecuteSqlInterpolatedAsync(
                $"UPDATE \"IdentityState\" SET \"Revision\" = \"Revision\" + 1, \"ChangedAt\" = {now} WHERE \"Id\" = 1", cancellationToken);
            if (tx is not null) await tx.CommitAsync(cancellationToken);
        }
        else
        {
            var state = await IdentityStates.FindAsync([1], cancellationToken);
            if (state is null) IdentityStates.Add(new IdentityState { Id = 1, Revision = 2, ChangedAt = now });
            else { state.Revision++; state.ChangedAt = now; }
            result = await base.SaveChangesAsync(cancellationToken);
        }
        return result;
    }

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Tenant>(e => { e.ToTable("Tenants"); e.Property(x => x.Code).HasMaxLength(32).IsRequired(); });
        b.Entity<OrgUnit>(e =>
        {
            e.ToTable("OrgUnits");
            e.Property(x => x.Code).HasMaxLength(32).IsRequired();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
        });
        b.Entity<User>(e =>
        {
            e.ToTable("Users");
            e.Property(x => x.UserName).HasMaxLength(64).IsRequired();
            e.Property(x => x.FullName).HasMaxLength(128).IsRequired();
            e.Property(x => x.CashWithdrawalLimit).HasPrecision(18, 2);
        });
        b.Entity<UserOrgUnit>(e => { e.ToTable("UserOrgUnits"); e.HasKey(x => new { x.UserId, x.OrgUnitId }); });
        b.Entity<Role>(e =>
        {
            e.ToTable("Roles");
            e.Property(x => x.Code).HasMaxLength(48).IsRequired();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
        });
        b.Entity<UserRole>(e => { e.ToTable("UserRoles"); e.HasKey(x => new { x.UserId, x.RoleId }); });
        b.Entity<IdentityState>(e => { e.ToTable("IdentityState"); e.Property(x => x.Id).ValueGeneratedNever(); });
    }
}
