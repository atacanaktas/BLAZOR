namespace Yetki.Pip.Api.Data;

// PIP'in sahip olduğu kimlik verisi (İK kaynağı): kullanıcı, birim, kullanıcı-birim, rol, rol ataması.
// Tablolar ortak veritabanındadır; şema PAP migration'larıyla yönetilir, bu sınıflar o şemanın PIP görünümüdür.
// Kurumlar (Tenants) yetki yapısıdır (PAP'ın); PIP sadece doğrulama için okur.

public enum TenantType { Bank = 1, Subsidiary = 2 }
public enum OrgUnitType { HeadOffice = 1, Department = 2, Region = 3, Branch = 4 }
public enum UserKind { Person = 1, ServiceAccount = 2 }

public abstract class Audited
{
    public int Id { get; set; }
    public DateTime CreatedAt { get; set; }
    public string CreatedBy { get; set; } = "system";
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

public interface IAssigned
{
    DateTime AssignedAt { get; set; }
    string AssignedBy { get; set; }
}

/// <summary>Salt okunur (doğrulama: kurum var mı, hangi kurumun altında).</summary>
public class Tenant : Audited
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public TenantType Type { get; set; }
    public int? ParentId { get; set; }
    public bool IsActive { get; set; } = true;
}

public class OrgUnit : Audited
{
    public int TenantId { get; set; }
    public int? ParentId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public OrgUnitType Type { get; set; }
    public bool IsActive { get; set; } = true;
}

public class User : Audited
{
    public int TenantId { get; set; }
    public string UserName { get; set; } = default!;
    public string FullName { get; set; } = default!;
    public string? Email { get; set; }
    public string? Title { get; set; }
    public string? EmployeeNo { get; set; }
    public UserKind Kind { get; set; } = UserKind.Person;
    public bool IsActive { get; set; } = true;
    public bool IsOnLeave { get; set; }
    public decimal CashWithdrawalLimit { get; set; }
    public string? CustomerNo { get; set; }
}

public class UserOrgUnit : IAssigned
{
    public int UserId { get; set; }
    public int OrgUnitId { get; set; }
    public bool IsPrimary { get; set; }
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}

public class Role : Audited
{
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsInheritable { get; set; }
    public bool IsActive { get; set; } = true;
}

public class UserRole : IAssigned
{
    public int UserId { get; set; }
    public int RoleId { get; set; }
    public DateTime? ValidFrom { get; set; }
    public DateTime? ValidUntil { get; set; }
    public string? Reason { get; set; }
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}

/// <summary>Kimlik verisinin revizyonu (tek satır, Id = 1). Her kimlik değişikliğinde aynı transaction'da artar; PDP önbelleği buna bakar.</summary>
public class IdentityState
{
    public int Id { get; set; }
    public long Revision { get; set; }
    public DateTime ChangedAt { get; set; }
}
