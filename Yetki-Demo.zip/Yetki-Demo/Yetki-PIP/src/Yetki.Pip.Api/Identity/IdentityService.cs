using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using Yetki.Pip.Api.Data;

namespace Yetki.Pip.Api.Identity;

/// <summary>
/// Kimlik verisinin TEK sahibi (İK kaynağı). Okuma: PDP (karar modeli, kişi öznitelikleri) ve PAP (ekranlar).
/// Yazma: İK süreçleri veya PAP konsolu. Yetki etkisi (SoD, kim ne kazanır) PIP'in işi değildir — PAP yazmadan önce PDP'ye sorar.
/// Burada sadece kimlik bütünlüğü kuralları vardır: tekil kullanıcı adı / rol kodu, birim ve rolün kurumla uyumu.
/// </summary>
public sealed class IdentityService(PipDbContext db)
{
    private static readonly Expression<Func<User, IdentityUser>> UserView = u =>
        new(u.Id, u.TenantId, u.UserName, u.FullName, u.Email, u.Title, u.EmployeeNo, u.Kind, u.IsActive, u.IsOnLeave, u.CashWithdrawalLimit, u.CustomerNo);
    private static readonly Expression<Func<Role, IdentityRole>> RoleView = r =>
        new(r.Id, r.TenantId, r.Code, r.Name, r.Description, r.IsInheritable, r.IsActive);
    private static readonly Expression<Func<UserRole, IdentityUserRole>> UserRoleView = x =>
        new(x.UserId, x.RoleId, x.ValidFrom, x.ValidUntil, x.Reason, x.AssignedAt, x.AssignedBy);
    private static readonly Expression<Func<OrgUnit, IdentityUnit>> UnitView = u =>
        new(u.Id, u.TenantId, u.ParentId, u.Code, u.Name, u.Type, u.IsActive);

    // ================================ Okuma ================================

    public async Task<string> RevisionAsync(CancellationToken ct) =>
        "pip:" + (await db.IdentityStates.AsNoTracking().Where(s => s.Id == 1).Select(s => (long?)s.Revision).FirstOrDefaultAsync(ct) ?? 0);

    public async Task<IdentitySnapshot> SnapshotAsync(CancellationToken ct)
    {
        // Revizyon önce okunur: okuma sırasında değişiklik olursa tüketici eski revizyonla saklar ve sonraki sorguda yeniler.
        var revision = await RevisionAsync(ct);
        return new IdentitySnapshot(revision,
            await db.Users.AsNoTracking().OrderBy(u => u.Id).Select(UserView).ToListAsync(ct),
            await db.Roles.AsNoTracking().OrderBy(r => r.Id).Select(RoleView).ToListAsync(ct),
            await db.UserRoles.AsNoTracking().Select(UserRoleView).ToListAsync(ct),
            await db.OrgUnits.AsNoTracking().OrderBy(u => u.Id).Select(UnitView).ToListAsync(ct),
            await db.UserOrgUnits.AsNoTracking().Select(x => new IdentityUserUnit(x.UserId, x.OrgUnitId, x.IsPrimary)).ToListAsync(ct));
    }

    public async Task<IdentityUser> UserAsync(int id, CancellationToken ct) =>
        await db.Users.AsNoTracking().Where(u => u.Id == id).Select(UserView).FirstOrDefaultAsync(ct) ?? throw new NotFoundException("Kullanıcı", id);

    public async Task<IdentityUser> UserByNameAsync(string userName, CancellationToken ct)
    {
        var name = userName.Trim().ToLowerInvariant();
        return await db.Users.AsNoTracking().Where(u => u.UserName == name).Select(UserView).FirstOrDefaultAsync(ct) ?? throw new NotFoundException("Kullanıcı", name);
    }

    public async Task<IdentityPage<IdentityUser>> SearchUsersAsync(int? tenantId, string? search, int page, int pageSize, CancellationToken ct)
    {
        if (page < 1 || pageSize < 1 || pageSize > 500 || search?.Length > 200) throw new ValidationException("Geçersiz sorgu.");
        var q = db.Users.AsNoTracking().Where(u => tenantId == null || u.TenantId == tenantId);
        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim().ToLower();
            q = q.Where(u => u.UserName.ToLower().Contains(term) || u.FullName.ToLower().Contains(term));
        }
        var total = await q.CountAsync(ct);
        var items = await q.OrderBy(u => u.UserName).ThenBy(u => u.Id).Skip((page - 1) * pageSize).Take(pageSize).Select(UserView).ToListAsync(ct);
        return new IdentityPage<IdentityUser>(items, total, page, pageSize);
    }

    public async Task<IReadOnlyList<IdentityUserRole>> UserRolesAsync(int userId, CancellationToken ct) =>
        await db.UserRoles.AsNoTracking().Where(x => x.UserId == userId).Select(UserRoleView).ToListAsync(ct);

    public async Task<IReadOnlyList<IdentityUserUnit>> UserUnitsAsync(int userId, CancellationToken ct) =>
        await db.UserOrgUnits.AsNoTracking().Where(x => x.UserId == userId).Select(x => new IdentityUserUnit(x.UserId, x.OrgUnitId, x.IsPrimary)).ToListAsync(ct);

/// <summary>Personelin birimi: birincil birim (yoksa ilk bağlı birim). Birim türüne göre ayrım yapılmaz.</summary>
    public async Task<Attributes.UserUnitInfo> UserUnitAsync(int userId, CancellationToken ct)
    {
        if (!await db.Users.AnyAsync(u => u.Id == userId, ct)) throw new NotFoundException("Kullanıcı", userId);
        var unit = await (from x in db.UserOrgUnits.AsNoTracking()
                          join u in db.OrgUnits.AsNoTracking() on x.OrgUnitId equals u.Id
                          where x.UserId == userId
                          orderby x.IsPrimary descending, x.OrgUnitId
                          select new { u.Code, u.Name, u.Type, x.IsPrimary }).FirstOrDefaultAsync(ct)
                   ?? throw new NotFoundException("Kullanıcının birimi", userId);
        return new(userId, unit.Code, unit.Name, unit.Type.ToString(), unit.IsPrimary, "pip:birim");
    }

    public async Task<IdentityRole> RoleAsync(int id, CancellationToken ct) =>
        await db.Roles.AsNoTracking().Where(r => r.Id == id).Select(RoleView).FirstOrDefaultAsync(ct) ?? throw new NotFoundException("Rol", id);

    public async Task<IdentityRole> RoleByCodeAsync(string code, CancellationToken ct)
    {
        var c = code.Trim().ToUpperInvariant();
        return await db.Roles.AsNoTracking().Where(r => r.Code == c).Select(RoleView).FirstOrDefaultAsync(ct) ?? throw new NotFoundException("Rol", c);
    }

    public async Task<IReadOnlyList<IdentityRole>> RolesAsync(int? tenantId, CancellationToken ct) =>
        await db.Roles.AsNoTracking().Where(r => tenantId == null || r.TenantId == tenantId).OrderBy(r => r.Code).Select(RoleView).ToListAsync(ct);

    public async Task<IReadOnlyList<IdentityUnit>> UnitsAsync(int? tenantId, CancellationToken ct) =>
        await db.OrgUnits.AsNoTracking().Where(u => tenantId == null || u.TenantId == tenantId).OrderBy(u => u.TenantId).ThenBy(u => u.Id).Select(UnitView).ToListAsync(ct);

    // ================================ Kullanıcı ================================

    public async Task<IdentityUser> CreateUserAsync(UserUpsert dto, CancellationToken ct)
    {
        var name = (dto.UserName ?? "").Trim().ToLowerInvariant();
        if (name.Length == 0) throw new ValidationException("Kullanıcı adı zorunlu.");
        if (string.IsNullOrWhiteSpace(dto.FullName)) throw new ValidationException("Ad soyad zorunlu.");
        if (await db.Users.AnyAsync(u => u.UserName == name, ct)) throw new ConflictException($"Kullanıcı adı zaten var: {name}");
        await TenantAsync(dto.TenantId, ct);
        if (dto.PrimaryOrgUnitId is { } unitId) await UnitInTenantAsync(unitId, dto.TenantId, ct);
        // Kullanıcı + birincil birim tek iş birimi (id üretimi için iki SaveChanges, tek transaction)
        await using var tx = db.Database.IsRelational() ? await db.Database.BeginTransactionAsync(ct) : null;
        var user = new User { TenantId = dto.TenantId, UserName = name };
        Copy(dto, user);
        db.Users.Add(user);
        await db.SaveChangesAsync(ct);
        if (dto.PrimaryOrgUnitId is { } primary)
        {
            db.UserOrgUnits.Add(new UserOrgUnit { UserId = user.Id, OrgUnitId = primary, IsPrimary = true });
            await db.SaveChangesAsync(ct);
        }
        if (tx is not null) await tx.CommitAsync(ct);
        return await UserAsync(user.Id, ct);
    }

    /// <summary>Kurum ve kullanıcı adı değişmez.</summary>
    public async Task<IdentityUser> UpdateUserAsync(int id, UserUpsert dto, CancellationToken ct)
    {
        var user = await db.Users.FindAsync([id], ct) ?? throw new NotFoundException("Kullanıcı", id);
        if (string.IsNullOrWhiteSpace(dto.FullName)) throw new ValidationException("Ad soyad zorunlu.");
        Copy(dto, user);
        await db.SaveChangesAsync(ct);
        return await UserAsync(id, ct);
    }

    public async Task<IdentityUserRole> AssignRoleAsync(int userId, RoleAssignment dto, CancellationToken ct)
    {
        var user = await db.Users.FindAsync([userId], ct) ?? throw new NotFoundException("Kullanıcı", userId);
        var role = await db.Roles.FindAsync([dto.RoleId], ct) ?? throw new NotFoundException("Rol", dto.RoleId);
        if (await db.UserRoles.AnyAsync(x => x.UserId == userId && x.RoleId == role.Id, ct))
            throw new ConflictException($"'{user.UserName}' zaten '{role.Code}' rolüne sahip.");
        await EnsureRoleUsableAsync(role, user.TenantId, ct);
        if (dto.ValidFrom is { } f && dto.ValidUntil is { } u && u <= f) throw new ValidationException("Bitiş tarihi başlangıçtan sonra olmalı.");
        db.UserRoles.Add(new UserRole { UserId = userId, RoleId = role.Id, ValidFrom = dto.ValidFrom, ValidUntil = dto.ValidUntil, Reason = Trim(dto.Reason, 256) });
        await db.SaveChangesAsync(ct);
        return await db.UserRoles.AsNoTracking().Where(x => x.UserId == userId && x.RoleId == role.Id).Select(UserRoleView).FirstAsync(ct);
    }

    public async Task RevokeRoleAsync(int userId, int roleId, CancellationToken ct)
    {
        var row = await db.UserRoles.FirstOrDefaultAsync(x => x.UserId == userId && x.RoleId == roleId, ct)
                  ?? throw new NotFoundException("Rol ataması", $"{userId}/{roleId}");
        db.UserRoles.Remove(row);
        await db.SaveChangesAsync(ct);
    }

    public async Task<IdentityUserUnit> AddUnitAsync(int userId, int unitId, CancellationToken ct)
    {
        var user = await db.Users.FindAsync([userId], ct) ?? throw new NotFoundException("Kullanıcı", userId);
        await UnitInTenantAsync(unitId, user.TenantId, ct);
        if (await db.UserOrgUnits.AnyAsync(x => x.UserId == userId && x.OrgUnitId == unitId, ct)) throw new ConflictException("Kullanıcı zaten bu birimde.");
        var primary = !await db.UserOrgUnits.AnyAsync(x => x.UserId == userId, ct);
        db.UserOrgUnits.Add(new UserOrgUnit { UserId = userId, OrgUnitId = unitId, IsPrimary = primary });
        await db.SaveChangesAsync(ct);
        return new IdentityUserUnit(userId, unitId, primary);
    }

    public async Task RemoveUnitAsync(int userId, int unitId, CancellationToken ct)
    {
        var row = await db.UserOrgUnits.FirstOrDefaultAsync(x => x.UserId == userId && x.OrgUnitId == unitId, ct)
                  ?? throw new NotFoundException("Kullanıcı birimi", $"{userId}/{unitId}");
        db.UserOrgUnits.Remove(row);
        await db.SaveChangesAsync(ct);
    }

    // ================================ Rol ================================

    public async Task<IdentityRole> CreateRoleAsync(RoleUpsert dto, CancellationToken ct)
    {
        var code = (dto.Code ?? "").Trim().ToUpperInvariant();
        if (code.Length == 0 || code.Contains(' ') || code.Contains(':') || code.Contains('/')) throw new ValidationException("Rol kodu boş olamaz; boşluk, ':' veya '/' içeremez.");
        if (await db.Roles.AnyAsync(r => r.Code == code, ct)) throw new ConflictException($"Rol kodu zaten var: {code}");
        await TenantAsync(dto.TenantId, ct);
        var role = new Role { TenantId = dto.TenantId, Code = code, Name = dto.Name, Description = dto.Description, IsInheritable = dto.IsInheritable, IsActive = dto.IsActive };
        db.Roles.Add(role);
        await db.SaveChangesAsync(ct);
        return await RoleAsync(role.Id, ct);
    }

    /// <summary>Kurum ve kod değişmez.</summary>
    public async Task<IdentityRole> UpdateRoleAsync(int id, RoleUpsert dto, CancellationToken ct)
    {
        var role = await db.Roles.FindAsync([id], ct) ?? throw new NotFoundException("Rol", id);
        role.Name = dto.Name; role.Description = dto.Description; role.IsInheritable = dto.IsInheritable; role.IsActive = dto.IsActive;
        await db.SaveChangesAsync(ct);
        return await RoleAsync(id, ct);
    }

    // ================================ Birim ================================

    public async Task<IdentityUnit> CreateUnitAsync(UnitUpsert dto, CancellationToken ct)
    {
        var code = (dto.Code ?? "").Trim().ToUpperInvariant();
        if (code.Length == 0) throw new ValidationException("Birim kodu zorunlu.");
        await TenantAsync(dto.TenantId, ct);
        if (await db.OrgUnits.AnyAsync(u => u.TenantId == dto.TenantId && u.Code == code, ct)) throw new ConflictException($"Birim kodu zaten var: {code}");
        if (dto.ParentId is { } p) await UnitInTenantAsync(p, dto.TenantId, ct, "Üst birim aynı kurumda olmalı.");
        var unit = new OrgUnit { TenantId = dto.TenantId, ParentId = dto.ParentId, Code = code, Name = dto.Name, Type = dto.Type, IsActive = dto.IsActive };
        db.OrgUnits.Add(unit);
        await db.SaveChangesAsync(ct);
        return new IdentityUnit(unit.Id, unit.TenantId, unit.ParentId, unit.Code, unit.Name, unit.Type, unit.IsActive);
    }

    // ================================ Yardımcılar ================================

    /// <summary>Rol hedef kurumda kullanılabilir mi? (aynı kurum veya üst kurumun miras alınabilir rolü)</summary>
    private async Task EnsureRoleUsableAsync(Role role, int tenantId, CancellationToken ct)
    {
        if (role.TenantId == tenantId) return;
        var ancestors = await AncestorsAsync(tenantId, ct);
        if (role.IsInheritable && ancestors.Contains(role.TenantId)) return;
        var codes = await db.Tenants.AsNoTracking().Where(t => t.Id == role.TenantId || t.Id == tenantId).ToDictionaryAsync(t => t.Id, t => t.Code, ct);
        throw new ValidationException($"'{role.Code}' rolü {codes.GetValueOrDefault(role.TenantId)} kurumuna ait ve miras alınamaz; " +
                                      $"{codes.GetValueOrDefault(tenantId)} kurumunda kullanılamaz.");
    }

    private async Task<HashSet<int>> AncestorsAsync(int tenantId, CancellationToken ct)
    {
        var parents = await db.Tenants.AsNoTracking().ToDictionaryAsync(t => t.Id, t => t.ParentId, ct);
        var result = new HashSet<int>();
        int? cur = tenantId;
        while (cur is { } c && result.Add(c)) cur = parents.GetValueOrDefault(c);
        return result;
    }

    private async Task TenantAsync(int id, CancellationToken ct)
    {
        if (!await db.Tenants.AnyAsync(t => t.Id == id, ct)) throw new NotFoundException("Kurum", id);
    }

    private async Task UnitInTenantAsync(int unitId, int tenantId, CancellationToken ct, string message = "Birim kullanıcının kurumunda olmalı.")
    {
        var unit = await db.OrgUnits.FindAsync([unitId], ct) ?? throw new NotFoundException("Birim", unitId);
        if (unit.TenantId != tenantId) throw new ValidationException(message);
    }

    private static void Copy(UserUpsert dto, User user)
    {
        user.FullName = dto.FullName.Trim(); user.Email = Trim(dto.Email, 128); user.Title = Trim(dto.Title, 128); user.EmployeeNo = Trim(dto.EmployeeNo, 32);
        user.Kind = dto.Kind; user.IsActive = dto.IsActive; user.IsOnLeave = dto.IsOnLeave;
        user.CashWithdrawalLimit = dto.CashWithdrawalLimit; user.CustomerNo = Trim(dto.CustomerNo, 32);
    }

    private static string? Trim(string? s, int max) =>
        string.IsNullOrWhiteSpace(s) ? null : s.Trim().Length > max ? s.Trim()[..max] : s.Trim();
}
