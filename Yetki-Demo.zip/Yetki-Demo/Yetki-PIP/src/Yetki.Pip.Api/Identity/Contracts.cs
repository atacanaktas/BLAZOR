using Yetki.Pip.Api.Data;

namespace Yetki.Pip.Api.Identity;

// PIP sözleşmesi (JSON). Tüketiciler (PDP, PAP) kendi tarafında aynı alanlarla karşılık gelen tipleri tanımlar; ortak kütüphane yoktur.

public sealed record IdentityUser(int Id, int TenantId, string UserName, string FullName, string? Email,
    string? Title, string? EmployeeNo, UserKind Kind, bool IsActive, bool IsOnLeave,
    decimal CashWithdrawalLimit, string? CustomerNo);

public sealed record IdentityRole(int Id, int TenantId, string Code, string Name, string? Description, bool IsInheritable, bool IsActive);

public sealed record IdentityUserRole(int UserId, int RoleId, DateTime? ValidFrom, DateTime? ValidUntil, string? Reason, DateTime AssignedAt, string AssignedBy);

public sealed record IdentityUnit(int Id, int TenantId, int? ParentId, string Code, string Name, OrgUnitType Type, bool IsActive);

public sealed record IdentityUserUnit(int UserId, int OrgUnitId, bool IsPrimary);

/// <summary>Karar modeli için tam kimlik görüntüsü (PDP önbelleği). Revision değişmedikçe yeniden okunmaz.</summary>
public sealed record IdentitySnapshot(string Revision, IReadOnlyList<IdentityUser> Users, IReadOnlyList<IdentityRole> Roles,
    IReadOnlyList<IdentityUserRole> UserRoles, IReadOnlyList<IdentityUnit> Units, IReadOnlyList<IdentityUserUnit> UserUnits);

public sealed record IdentityPage<T>(IReadOnlyList<T> Items, int Total, int Page, int PageSize);

public sealed record RevisionView(string Revision);

public sealed class UserUpsert
{
    public int TenantId { get; set; }
    public string UserName { get; set; } = default!;
    public string FullName { get; set; } = default!;
    public string? Email { get; set; }
    public string? Title { get; set; }
    public string? EmployeeNo { get; set; }
    public UserKind Kind { get; set; } = UserKind.Person;
    public bool IsActive { get; set; } = true;
    public bool IsOnLeave { get; set; }
    public decimal CashWithdrawalLimit { get; set; }
    public string? CustomerNo { get; set; }
    /// <summary>Sadece oluştururken: birincil birim.</summary>
    public int? PrimaryOrgUnitId { get; set; }
}

public sealed class RoleUpsert
{
    public int TenantId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsInheritable { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class RoleAssignment
{
    public int RoleId { get; set; }
    public DateTime? ValidFrom { get; set; }
    public DateTime? ValidUntil { get; set; }
    public string? Reason { get; set; }
}

public sealed class UnitUpsert
{
    public int TenantId { get; set; }
    public int? ParentId { get; set; }
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public OrgUnitType Type { get; set; } = OrgUnitType.Branch;
    public bool IsActive { get; set; } = true;
}

public class NotFoundException(string entity, object key) : Exception($"{entity} bulunamadı: {key}");
public class ValidationException(string message) : Exception(message);
public class ConflictException(string message) : Exception(message);
