using Microsoft.AspNetCore.Mvc;
using Yetki.Pip.Api.Identity;
using Yetki.Pip.Api.Infrastructure;

namespace Yetki.Pip.Api.Controllers;

/// <summary>
/// Kimlik API'si (PIP). Okuma: revizyon, tam görüntü (PDP karar modeli), kullanıcı/rol/birim sorguları.
/// Yazma: kullanıcı, rol, rol ataması, kullanıcı-birim, birim. Yetki etkisi hesabı burada yapılmaz (PAP → PDP).
/// </summary>
[ApiController]
[Route("api/identity")]
[TypeFilter(typeof(RequireServiceKeyFilter))]
public sealed class IdentityController(IdentityService identity) : ControllerBase
{
    [HttpGet("revision")]
    public async Task<RevisionView> Revision(CancellationToken ct) => new(await identity.RevisionAsync(ct));

    [HttpGet("snapshot")]
    public Task<IdentitySnapshot> Snapshot(CancellationToken ct) => identity.SnapshotAsync(ct);

    // ------------------------------ Kullanıcı ------------------------------

    [HttpGet("users")]
    public Task<IdentityPage<IdentityUser>> Users([FromQuery] int? tenantId, [FromQuery] string? search, CancellationToken ct,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 50) =>
        identity.SearchUsersAsync(tenantId, search, page, pageSize, ct);

    [HttpGet("users/{id:int}")]
    public Task<IdentityUser> User(int id, CancellationToken ct) => identity.UserAsync(id, ct);

    [HttpGet("users/by-name/{userName}")]
    public Task<IdentityUser> UserByName(string userName, CancellationToken ct) => identity.UserByNameAsync(userName, ct);

    [HttpGet("users/{id:int}/roles")]
    public Task<IReadOnlyList<IdentityUserRole>> UserRoles(int id, CancellationToken ct) => identity.UserRolesAsync(id, ct);

    [HttpGet("users/{id:int}/units")]
    public Task<IReadOnlyList<IdentityUserUnit>> UserUnits(int id, CancellationToken ct) => identity.UserUnitsAsync(id, ct);

    [HttpPost("users")]
    public Task<IdentityUser> CreateUser(UserUpsert dto, CancellationToken ct) => identity.CreateUserAsync(dto, ct);

    [HttpPut("users/{id:int}")]
    public Task<IdentityUser> UpdateUser(int id, UserUpsert dto, CancellationToken ct) => identity.UpdateUserAsync(id, dto, ct);

    [HttpPost("users/{id:int}/roles")]
    public Task<IdentityUserRole> AssignRole(int id, RoleAssignment dto, CancellationToken ct) => identity.AssignRoleAsync(id, dto, ct);

    [HttpDelete("users/{id:int}/roles/{roleId:int}")]
    public async Task<IActionResult> RevokeRole(int id, int roleId, CancellationToken ct)
    {
        await identity.RevokeRoleAsync(id, roleId, ct);
        return NoContent();
    }

    [HttpPost("users/{id:int}/units/{unitId:int}")]
    public Task<IdentityUserUnit> AddUnit(int id, int unitId, CancellationToken ct) => identity.AddUnitAsync(id, unitId, ct);

    [HttpDelete("users/{id:int}/units/{unitId:int}")]
    public async Task<IActionResult> RemoveUnit(int id, int unitId, CancellationToken ct)
    {
        await identity.RemoveUnitAsync(id, unitId, ct);
        return NoContent();
    }

    // ------------------------------ Rol ------------------------------

    [HttpGet("roles")]
    public Task<IReadOnlyList<IdentityRole>> Roles([FromQuery] int? tenantId, CancellationToken ct) => identity.RolesAsync(tenantId, ct);

    [HttpGet("roles/{id:int}")]
    public Task<IdentityRole> Role(int id, CancellationToken ct) => identity.RoleAsync(id, ct);

    [HttpGet("roles/by-code/{code}")]
    public Task<IdentityRole> RoleByCode(string code, CancellationToken ct) => identity.RoleByCodeAsync(code, ct);

    [HttpPost("roles")]
    public Task<IdentityRole> CreateRole(RoleUpsert dto, CancellationToken ct) => identity.CreateRoleAsync(dto, ct);

    [HttpPut("roles/{id:int}")]
    public Task<IdentityRole> UpdateRole(int id, RoleUpsert dto, CancellationToken ct) => identity.UpdateRoleAsync(id, dto, ct);

    // ------------------------------ Birim ------------------------------

    [HttpGet("units")]
    public Task<IReadOnlyList<IdentityUnit>> Units([FromQuery] int? tenantId, CancellationToken ct) => identity.UnitsAsync(tenantId, ct);

    [HttpPost("units")]
    public Task<IdentityUnit> CreateUnit(UnitUpsert dto, CancellationToken ct) => identity.CreateUnitAsync(dto, ct);
}
