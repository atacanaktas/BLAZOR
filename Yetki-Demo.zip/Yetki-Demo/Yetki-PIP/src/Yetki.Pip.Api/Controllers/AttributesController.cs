using System.Globalization;
using Microsoft.AspNetCore.Mvc;
using Yetki.Pip.Api.Attributes;
using Yetki.Pip.Api.Identity;
using Yetki.Pip.Api.Infrastructure;

namespace Yetki.Pip.Api.Controllers;

/// <summary>
/// Kimlik dışı öznitelikler (PDP policy koşulları için): iş günü, izin, müşteri. Kaynaklar adaptördür; bugün geçici kurallar
/// (hafta içi = iş günü, kimse izinde değil, müşteri no öneki) çalışır. Cevaptaki "source" hangi kaynağın cevap verdiğini söyler.
/// </summary>
[ApiController]
[Route("api")]
[TypeFilter(typeof(RequireServiceKeyFilter))]
public sealed class AttributesController(IBusinessCalendar calendar, ILeaveSource leave, ICustomerDirectory customers, ILimitSource limits,
    IdentityService identity) : ControllerBase
{
    /// <summary>Kullanıcının limit durumu: işlem başı, günlük toplam, bugün kullanılan, kalan. type: CASH (nakit). date boşsa bugün (UTC).</summary>
    [HttpGet("limits/users/{id:int}")]
    public Task<LimitInfo> Limit(int id, [FromQuery] string? type, [FromQuery] string? date, CancellationToken ct) =>
        limits.GetAsync(id, type ?? UserRecordLimitSource.Cash, date is null ? DateOnly.FromDateTime(DateTime.UtcNow) : ParseDate(date), ct);

    /// <summary>Personelin birim kodu (birincil birim).</summary>
    [HttpGet("identity/users/{id:int}/unit")]
    public Task<UserUnitInfo> Unit(int id, CancellationToken ct) => identity.UserUnitAsync(id, ct);

    /// <summary>Verilen gün iş günü mü? (yyyy-MM-dd)</summary>
    [HttpGet("calendar/business-days/{date}")]
    public Task<BusinessDayInfo> BusinessDay(string date, CancellationToken ct) => calendar.GetAsync(ParseDate(date), ct);

    /// <summary>Kullanıcı verilen günde izinde mi? date boşsa bugün (UTC).</summary>
    [HttpGet("identity/users/{id:int}/leave")]
    public Task<LeaveInfo> Leave(int id, [FromQuery] string? date, CancellationToken ct) =>
        leave.GetAsync(id, date is null ? DateOnly.FromDateTime(DateTime.UtcNow) : ParseDate(date), ct);

    /// <summary>Müşteri öznitelikleri: VIP mi, personel müşterisi mi.</summary>
    [HttpGet("customers/{customerNo}")]
    public Task<CustomerInfo> Customer(string customerNo, CancellationToken ct) => customers.GetAsync(customerNo, ct);

    private static DateOnly ParseDate(string s) =>
        DateOnly.TryParseExact(s, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d)
            ? d : throw new ValidationException($"Geçersiz tarih: {s} (beklenen yyyy-MM-dd)");
}
