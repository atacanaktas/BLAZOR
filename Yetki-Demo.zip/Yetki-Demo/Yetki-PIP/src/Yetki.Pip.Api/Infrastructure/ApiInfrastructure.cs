using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
using Yetki.Pip.Api.Data;
using Yetki.Pip.Api.Identity;

namespace Yetki.Pip.Api.Infrastructure;

/// <summary>
/// PIP'i yalnızca iç servisler çağırır (PDP okur, PAP okur/yazar; ileride İK entegrasyonu). Her tüketicinin kendi anahtarı vardır.
/// ÜRETİMDE anahtarlar gizli yönetiminden verilmeli (veya mTLS / ağ seviyesinde kısıt).
/// </summary>
public sealed class PipOptions
{
    public const string HeaderName = "X-Service-Key";
    /// <summary>tüketici adı → anahtar (ör. "pdp": "...", "pap": "...").</summary>
    public Dictionary<string, string> ServiceKeys { get; set; } = new();
}

public sealed class RequireServiceKeyFilter(IOptions<PipOptions> options) : IAuthorizationFilter
{
    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var keys = options.Value.ServiceKeys.Values.Where(k => !string.IsNullOrWhiteSpace(k)).ToList();
        if (keys.Count == 0)
        {
            context.Result = new ObjectResult(new ProblemDetails { Status = 503, Title = "PIP kapalı", Detail = "Pip:ServiceKeys yapılandırılmamış." }) { StatusCode = 503 };
            return;
        }
        var given = SHA256.HashData(Encoding.UTF8.GetBytes(context.HttpContext.Request.Headers[PipOptions.HeaderName].ToString()));
        if (!keys.Any(k => CryptographicOperations.FixedTimeEquals(given, SHA256.HashData(Encoding.UTF8.GetBytes(k)))))
            context.Result = new ObjectResult(new ProblemDetails { Status = 401, Title = "Servis anahtarı geçersiz", Detail = $"{PipOptions.HeaderName} başlığı eksik veya hatalı." }) { StatusCode = 401 };
    }
}

/// <summary>Değişikliği yapan kişi: çağıran servis X-Actor başlığıyla iletir (PAP konsolunda oturumdaki kişi, İK entegrasyonunda süreç adı).</summary>
public sealed class HttpCurrentActor(IHttpContextAccessor http) : ICurrentActor
{
    public string Name
    {
        get
        {
            var header = http.HttpContext?.Request.Headers["X-Actor"].ToString();
            return string.IsNullOrWhiteSpace(header) ? "pip" : header.Trim().ToLowerInvariant();
        }
    }
}

public sealed class ApiExceptionFilter(ILogger<ApiExceptionFilter> logger) : IExceptionFilter
{
    public void OnException(ExceptionContext context)
    {
        ProblemDetails? problem = context.Exception switch
        {
            NotFoundException e => new ProblemDetails { Status = 404, Title = "Bulunamadı", Detail = e.Message },
            ValidationException e => new ProblemDetails { Status = 400, Title = "Geçersiz istek", Detail = e.Message },
            ConflictException e => new ProblemDetails { Status = 409, Title = "Çakışma", Detail = e.Message },
            _ => null
        };
        if (problem is null)
        {
            logger.LogError(context.Exception, "Unhandled exception");
            problem = new ProblemDetails { Status = 500, Title = "Sunucu hatası", Detail = context.Exception.Message };
        }
        context.Result = new ObjectResult(problem) { StatusCode = problem.Status };
        context.ExceptionHandled = true;
    }
}
