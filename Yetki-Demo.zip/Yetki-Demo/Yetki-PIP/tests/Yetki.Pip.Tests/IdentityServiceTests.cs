using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Yetki.Pip.Api.Data;
using Yetki.Pip.Api.Identity;

namespace Yetki.Pip.Tests;

file sealed class FixedActor(string name) : ICurrentActor { public string Name { get; } = name; }

public class IdentityServiceTests
{
    private static (IdentityService Service, PipDbContext Db) Create()
    {
        var options = new DbContextOptionsBuilder<PipDbContext>().UseInMemoryDatabase("pip-" + Guid.NewGuid())
            .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;
        var db = new PipDbContext(options, new SystemClock(), new FixedActor("ik.test"));
        db.Tenants.AddRange(new Tenant { Id = 1, Code = "ABANK", Name = "A Bankası", Type = TenantType.Bank },
                            new Tenant { Id = 2, Code = "BISTIRAK", Name = "B İştiraki", Type = TenantType.Subsidiary, ParentId = 1 });
        db.OrgUnits.AddRange(new OrgUnit { Id = 10, TenantId = 1, Code = "101", Name = "Merkez Şube", Type = OrgUnitType.Branch },
                             new OrgUnit { Id = 20, TenantId = 2, Code = "B01", Name = "B Merkez", Type = OrgUnitType.HeadOffice });
        db.Roles.AddRange(new Role { Id = 100, TenantId = 1, Code = "PERSONEL", Name = "Personel", IsInheritable = true },
                          new Role { Id = 101, TenantId = 1, Code = "GISEYTK", Name = "Gişe Yetkilisi" });
        db.Users.AddRange(new User { Id = 1000, TenantId = 1, UserName = "ayse", FullName = "Ayşe" },
                          new User { Id = 1001, TenantId = 2, UserName = "nil", FullName = "Nil" });
        db.IdentityStates.Add(new IdentityState { Id = 1, Revision = 1 });
        db.SaveChanges();
        return (new IdentityService(db), db);
    }

    [Fact]
    public async Task Rol_atamasi_revizyonu_artirir_ve_goruntude_gorunur()
    {
        var (svc, _) = Create();
        var before = await svc.RevisionAsync(default);
        var assigned = await svc.AssignRoleAsync(1000, new RoleAssignment { RoleId = 101, Reason = "vekalet" }, default);
        Assert.Equal("ik.test", assigned.AssignedBy);
        var after = await svc.RevisionAsync(default);
        Assert.NotEqual(before, after);
        var snap = await svc.SnapshotAsync(default);
        Assert.Equal(after, snap.Revision);
        Assert.Contains(snap.UserRoles, r => r.UserId == 1000 && r.RoleId == 101);
    }

    [Fact]
    public async Task Miras_alinabilir_rol_alt_kurumda_atanir_miras_alinamaz_rol_atanamaz()
    {
        var (svc, _) = Create();
        await svc.AssignRoleAsync(1001, new RoleAssignment { RoleId = 100 }, default);
        var ex = await Assert.ThrowsAsync<ValidationException>(() => svc.AssignRoleAsync(1001, new RoleAssignment { RoleId = 101 }, default));
        Assert.Contains("miras alınamaz", ex.Message);
        await Assert.ThrowsAsync<ConflictException>(() => svc.AssignRoleAsync(1001, new RoleAssignment { RoleId = 100 }, default));
    }

    [Fact]
    public async Task Kullanici_olusturma_kurallari()
    {
        var (svc, db) = Create();
        var u = await svc.CreateUserAsync(new UserUpsert { TenantId = 1, UserName = " Mert.Kaya ", FullName = "Mert Kaya", PrimaryOrgUnitId = 10 }, default);
        Assert.Equal("mert.kaya", u.UserName);
        Assert.True(await db.UserOrgUnits.AnyAsync(x => x.UserId == u.Id && x.OrgUnitId == 10 && x.IsPrimary));
        await Assert.ThrowsAsync<ConflictException>(() => svc.CreateUserAsync(new UserUpsert { TenantId = 1, UserName = "mert.kaya", FullName = "X" }, default));
        await Assert.ThrowsAsync<ValidationException>(() => svc.CreateUserAsync(new UserUpsert { TenantId = 1, UserName = "y", FullName = "Y", PrimaryOrgUnitId = 20 }, default));
    }

    [Fact]
    public async Task Personelin_birimi_turune_bakilmadan_birincil_birimdir()
    {
        var (svc, db) = Create();
        db.OrgUnits.Add(new OrgUnit { Id = 11, TenantId = 1, Code = "IT", Name = "Bilgi Teknolojileri", Type = OrgUnitType.Department });
        db.UserOrgUnits.Add(new UserOrgUnit { UserId = 1000, OrgUnitId = 10, IsPrimary = false });
        db.UserOrgUnits.Add(new UserOrgUnit { UserId = 1000, OrgUnitId = 11, IsPrimary = true });
        db.UserOrgUnits.Add(new UserOrgUnit { UserId = 1001, OrgUnitId = 20, IsPrimary = true });
        db.SaveChanges();

        var ayse = await svc.UserUnitAsync(1000, default);
        Assert.Equal("IT", ayse.UnitCode);             // birincil birim (müşterisi olmayan bir daire de olabilir)
        Assert.True(ayse.IsPrimary);
        Assert.Equal("B01", (await svc.UserUnitAsync(1001, default)).UnitCode);   // genel müdürlük birimi de birimdir
    }

    [Fact]
    public async Task Gecici_limit_kaynagi_islem_basi_kullanici_kaydindan_gunluk_carpanla_kullanilan_sifir()
    {
        var (_, db) = Create();
        (await db.Users.FindAsync(1000))!.CashWithdrawalLimit = 50_000;
        db.SaveChanges();
        var config = new Microsoft.Extensions.Configuration.ConfigurationBuilder().Build();
        var r = await new Yetki.Pip.Api.Attributes.UserRecordLimitSource(db, config).GetAsync(1000, "cash", new DateOnly(2026, 10, 1), default);
        Assert.Equal(50_000, r.PerTransactionLimit);
        Assert.Equal(150_000, r.DailyLimit);
        Assert.Equal(0, r.UsedToday);
        Assert.Equal(150_000, r.RemainingToday);
        await Assert.ThrowsAsync<ValidationException>(() => new Yetki.Pip.Api.Attributes.UserRecordLimitSource(db, config).GetAsync(1000, "EFT", new DateOnly(2026, 10, 1), default));
    }

    [Fact]
    public async Task Birim_atamasi_ilk_birimi_birincil_yapar_ve_kurum_disi_birimi_reddeder()
    {
        var (svc, _) = Create();
        Assert.True((await svc.AddUnitAsync(1000, 10, default)).IsPrimary);
        await Assert.ThrowsAsync<ValidationException>(() => svc.AddUnitAsync(1000, 20, default));
        await svc.RemoveUnitAsync(1000, 10, default);
        Assert.Empty(await svc.UserUnitsAsync(1000, default));
    }
}
