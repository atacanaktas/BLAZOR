using Yetki.Pip.Api.Attributes;

namespace Yetki.Pip.Tests;

public class AttributeSourceTests
{
    [Theory]
    [InlineData("2026-09-28", true)]    // pazartesi
    [InlineData("2026-10-02", true)]    // cuma
    [InlineData("2026-10-03", false)]   // cumartesi
    [InlineData("2026-10-04", false)]   // pazar
    public async Task Gecici_takvim_hafta_ici_is_gunu(string date, bool expected)
    {
        var r = await new WeekdayBusinessCalendar().GetAsync(DateOnly.Parse(date), default);
        Assert.Equal(expected, r.IsBusinessDay);
        Assert.StartsWith("stub", r.Source);
    }

    [Theory]
    [InlineData("99123456", true, false)]
    [InlineData("98123456", false, true)]
    [InlineData("12345678", false, false)]
    [InlineData("C-9999", false, false)]
    public async Task Gecici_musteri_kaynagi_onekle_VIP_ve_personel_musterisi(string no, bool vip, bool staff)
    {
        var r = await new PrefixCustomerDirectory().GetAsync(no, default);
        Assert.Equal(vip, r.IsVip);
        Assert.Equal(staff, r.IsStaff);
    }

    [Fact]
    public async Task Gecici_izin_kaynagi_kimseyi_izinde_saymaz()
    {
        var r = await new AlwaysAvailableLeaveSource().GetAsync(1000, new DateOnly(2026, 10, 1), default);
        Assert.False(r.OnLeave);
    }
}
