﻿# Tüm servisleri ayrı pencerelerde başlatır: PAP (5100, migration) → PIP (5300) → PDP (5200) → Worker → Web (5180).
# Veritabanı: DataBase\yetki.demo.db (appsettings). Kapatmak için pencereleri kapatın.
#   powershell -ExecutionPolicy Bypass -File baslat.ps1
$root = $PSScriptRoot

function Wait-Url($url, $name) {
    for ($i = 0; $i -lt 120; $i++) {
        try { Invoke-WebRequest $url -UseBasicParsing -TimeoutSec 2 | Out-Null; Write-Host "$name hazır"; return } catch { Start-Sleep -Milliseconds 500 }
    }
    Write-Warning "$name yanıt vermedi ($url) — penceresindeki hatayı kontrol edin."
}

function Start-Window($title, $dir, $command) {
    Start-Process powershell -WorkingDirectory $dir -ArgumentList "-NoExit", "-Command", "`$Host.UI.RawUI.WindowTitle = '$title'; $command"
}

Start-Window "Yetki PAP :5100" (Join-Path $root "Yetki-PAP") "dotnet run --project src/Yetki.Pap.Api"
Wait-Url "http://localhost:5100/swagger/index.html" "PAP"
Start-Window "Yetki PIP :5300" (Join-Path $root "Yetki-PIP") "dotnet run --project src/Yetki.Pip.Api"
Wait-Url "http://localhost:5300/swagger/index.html" "PIP"
Start-Window "Yetki PDP :5200" (Join-Path $root "Yetki-PDP") "dotnet run --project src/Yetki.Pdp.Api"
Wait-Url "http://localhost:5200/swagger/index.html" "PDP"
Start-Window "Yetki PAP Worker" (Join-Path $root "Yetki-PAP") "dotnet run --project src/Yetki.Pap.Worker"
Start-Window "Yetki Web :5180" (Join-Path $root "Yetki-Web") "npm run dev"
Write-Host "Konsol: http://localhost:5180"
