# Yetki Platformu — Güncel TODO

> Son güncelleme: 4 Ekim 2026  
> `[x]` prototip kapsamında tamamlandı, `[ ]` açık veya üretimleşme işidir.

## P0 — Üretim güvenliği ve yönetişim

- [ ] **PAP yönetim düzlemine gerçek authentication ve authorization ekle.**
  - `X-Actor` yerine token kimliği; yönetim scope'ları, sayfa/işlem yetkileri ve servis kimlikleri.
- [ ] **Maker-checker yaşam döngüsü kur.**
  - Taslak → etki analizi → onay → publish → rollback; hazırlayan/onaylayan ayrımı.
- [ ] **Secret ve servisler arası güveni üretim seviyesine taşı.**
  - Vault/HSM/KMS, rotasyon, `kid`, mTLS veya workload identity; güvensiz config için fail-fast.
- [ ] **Değişmez audit ve saklama politikasını tasarla.**
  - Correlation ID, model/policy sürümü, attribute provenance, PEP/PDP sürümü, obligation sonucu, redaction ve SIEM.

## P1 — Runtime ve servis sınırları

- [ ] **PEP ve PDP.Client NuGet paketlerini oluştur.**
  - Request/context standardı, timeout/retry/circuit-breaker, secure defaults, obligation enforcement ve conformance test kit.
- [ ] **Servis data ownership'ini fiziksel ayır.**
  - Identity PIP'e; policy/catalog PAP'a; PDP'ye versiyonlu salt okunur bundle/read model.
- [ ] **PAP → PDP yayınını versiyonlu ve atomik yap.**
  - İmzalı policy bundle, atomik activate, rollback ve stale model alarmı.
- [ ] **PIP kaynak sözleşmelerini üretimleştir.**
  - Source authority, provenance, freshness, timeout, cache TTL, fail davranışı ve SLO.
- [ ] **Süreli atamalar için expiry orchestration ekle.**
  - `ValidUntil` değerlendirmede kullanılıyor; süre dolumunda audit/outbox/provisioning üreten scheduler eksik.
  - HR değişikliklerini event veya reconciliation ile yakala.

## P2 — Ölçek, dayanıklılık ve doğruluk kanıtı

- [ ] **20K user / 4K role / 200+ API ölçeğinde performans testi yap.**
  - Login storm, PDP p95/p99, PIP cache miss, geniş impact ve group filter taraması.
- [ ] **HA/DR ve operasyon modelini tanımla.**
  - Çoklu instance, readiness, RTO/RPO, backup/restore, chaos ve failover.
- [ ] **Referans karar seti ve property-based testler ekle.**
  - Negative logic, reference, tenant inheritance, missing attribute ve obligation kombinasyonları.
- [ ] **Tarihsel karar rekonstrüksiyonu tasarla.**
  - “T anında neden izin aldı?” için immutable model version ve identity/attribute snapshot.

## P3 — Ürün ve kullanıcı deneyimi

- [ ] **Yetki gözden geçirme / recertification ekranları ekle.**
- [ ] **Policy version history, diff ve lint geliştir.**
  - Derin reference, çift negatif, çelişen obligation, geniş `KİM` audience ve duplicate policy uyarıları.
- [ ] **Rule görünürlüğü için ayrı read-only inceleme/raporlama alanı tasarla.**
  - Rule bağımsız katalog değildir; policy, condition type, attribute ve etki ekseninde gösterilmelidir.
- [ ] **Resource ağacında lazy loading ve büyük katalog optimizasyonu yap.**
- [ ] **Yüksek hacimli listelerde server-side arama/sayfalama kapsamını tamamla.**
- [ ] **Catalog move/rename sihirbazı ekle; işlem öncesi etkisini göster.**
- [ ] **Group ile Policy `KİM` kartı arasındaki yönetişimi kararlaştır.**
  - İkisi de güçlü tutuluyor; duplicate audience riskine karşı öneri/lint ve “group'a dönüştür” akışı gerekir.

## Prototip kapsamında tamamlanan kritik işler

- [x] PAP, PDP ve PIP mantıksal servis ayrımı; Web yalnızca PAP ile konuşuyor.
- [x] Resource/scope/access-key ile Permission entity ayrımı.
- [x] Flexible resource hierarchy; endpoint seviyesinde scope/permission üretimi.
- [x] Tenant-policy uyumluluk kontrolleri ve izolasyon regresyonları.
- [x] Policy impact'te yeni erişim kazanacak kullanıcıların hesaba katılması.
- [x] Rule mutation'larının server-side ChangeGate/impact kontrolünden geçirilmesi.
- [x] Stale/truncated impact apply politikasının zorlanması.
- [x] Obligation değişikliklerinin etki akışına alınması.
- [x] SoD Warn/Block, geriye dönük tarama ve change-time enforcement.
- [x] External dependency, desired/current diff, outbox ve demo provisioning worker.
- [x] Change Simulation'ın tek `/what-if` sayfasında User/Role/Group/Policy/SoD akışlarıyla birleştirilmesi.
- [x] Group/role değişikliklerinin impact sayaçları ve CSV raporuna yansıtılması.
- [x] Atıl ekranların kaldırılması: Reports, Access Overview, `/apis`, Nextral Demo, Gateway Simulator, eski What-if ve All-in-One.
- [x] Merkezi DataTable, kolon filtresi, sıralama ve 10/20/50/100 sayfa boyutu.
- [x] Route-level lazy loading, production build ve lint.
- [x] Yönetici sunum sayfası: `/platform-brief` ve PDF yazdırma görünümü.

## Bilinçli kabul edilen prototip riskleri

- Policy `KİM` kartı ile Group kurgusunun örtüşmesi ekip kararı verilene kadar korunuyor.
- Shared SQLite ve demo service key'leri geliştirme kolaylığı için devam ediyor.
- Yönetim ekranından identity yazılabiliyor; hedefte HR/Identity sistemi otorite olacak.
- Performanstan önce semantik doğruluk ve servis sorumlulukları önceliklendirildi.

## Son doğrulama — 4 Ekim 2026

- PDP: **95/95**
- PAP: **14/14**
- PIP: **15/15**
- Yetki-Web: **production build başarılı, lint temiz**
- E2E: bu son dokümantasyon turunda yeniden çalıştırılmadı.
