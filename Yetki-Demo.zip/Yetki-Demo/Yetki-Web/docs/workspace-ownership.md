# Workspace Ownership Map

> Son güncelleme: 4 Ekim 2026

Bu sınıflandırma navigasyon ve işletim sorumluluğunu anlatır. Henüz canlı HR bağlantısı, team-specific page authorization veya approval workflow değildir.

| Alan | Bilginin sahibi | Yetki ekibinin rolü | Uygulamadaki sayfalar |
| --- | --- | --- | --- |
| Identity & Organization | HR / Identity | Kararda kullanır; prototipte yönetim ekranından da yazabilir | Tenants, Users, Roles |
| Catalogs & Controls | Application, integration, architecture ve risk ekipleri | Tanımları kullanır; prototipte insert/update yapar | Resources, Resource Types, Clients, Ownership Teams, Condition Types, Inventory, SoD, External Dependencies |
| Access Management | Authorization team | Permission-policy-group ilişkilerini ve kuralları yönetir | Permissions, Policies, Groups, Change Simulation |
| Monitoring & Reports | Ortak görünürlük | Karar, ihlal, değişiklik ve drift'i inceler | Decision Analysis, Audit, Inventory, SoD Violations, External Drift |

## Temel ayrımlar

- User'ın görevi, şubesi, unvanı veya iş rolü HR/Identity gerçeğidir. Yetki ekibi bu bilgiyi üretmemeli; PIP üzerinden kullanmalıdır.
- Hangi API, endpoint, ekran, client veya external dependency'nin var olduğu katalog bilgisidir. Yetki ekibi katalog gerçeğine karar vermez.
- Hangi resource/scope'un hangi permission ve policy ile korunacağı authorization yönetimidir.
- SoD kuralının iş/risk kararı kontrol sahibine aittir; sistem tanımı uygular, ihlali engeller/uyarır ve raporlar.
- Bütün alanlarda değişiklik ve karar izi raporlanabilir olmalıdır; mevcut audit kapsamı tarihsel snapshot garantisi vermez.

## Tek kaynak olan ekranlar

- Resource ve endpoint yönetimi: `/resources`; ayrı `/catalog` veya `/apis` sayfası yoktur.
- Değişiklik simülasyonu: `/what-if`; eski V1/V2 ayrımı yoktur.
- Runtime karar inceleme: `/evaluate`; ayrı Nextral/Gateway simulator yoktur.
- External definition, drift, event ve provisioning: `/external`.
- Yönetici özeti: `/platform-brief`.

## Raporlama sınırı

Mevcut sistem current effective access, source path, role/group membership, protection definition, SoD violation, external drift, decision evidence ve management audit'i gösterir. Herhangi bir geçmiş tarih için identity + policy modelini yeniden kuran immutable snapshot altyapısı henüz yoktur. Bu konu ana [`../../TODO.md`](../../TODO.md) içinde üretim işi olarak izlenir.
