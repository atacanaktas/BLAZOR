import {
  AuditOutlined, FileProtectOutlined, SafetyCertificateOutlined, TeamOutlined, UserOutlined,
} from '@ant-design/icons'
import { useSearchParams } from 'react-router-dom'
import { ReportDownloadProvider } from '../components/ReportDownloadContext'
import { GroupTab, PolicyTab, RoleTab, SodTab, UserTab } from './ChangeSimulationTabs'
import './ChangeSimulationPage.css'

const modes = [
  {
    key: 'user', title: 'User change', label: 'Kullanıcı etkisi',
    description: 'Rol, birim, unvan veya izin durumu değişirse erişimler nasıl değişir?',
    icon: <UserOutlined />, param: 'userId',
  },
  {
    key: 'role', title: 'Role change', label: 'Rol etkisi',
    description: 'Rol pasifleştirme ve tenant mirasının kapsadığı kullanıcıları incele.',
    icon: <SafetyCertificateOutlined />, param: 'roleId',
  },
  {
    key: 'group', title: 'Audience change', label: 'Grup etkisi',
    description: 'Kitle kriterleri, üyeler ve verilen roller değiştiğinde sonucu gör.',
    icon: <TeamOutlined />, param: 'groupId',
  },
  {
    key: 'policy', title: 'Policy change', label: 'Policy etkisi',
    description: 'Rule, condition, mod ve stratejiyi farklı senaryolarda karşılaştır.',
    icon: <FileProtectOutlined />, param: 'policyId',
  },
  {
    key: 'sod', title: 'Control proposal', label: 'SoD kuralı',
    description: 'Taslak yetki ayrılığı kuralının mevcut ihlallerini uygulamadan bul.',
    icon: <AuditOutlined />,
  },
] as const

type ModeKey = typeof modes[number]['key']

export function ChangeSimulationPage() {
  const [params, setParams] = useSearchParams()
  const requested = params.get('tab') as ModeKey | null
  const active = modes.some((mode) => mode.key === requested) ? requested! : 'user'
  const mode = modes.find((item) => item.key === active)!
  const initial = 'param' in mode && params.get(mode.param) ? Number(params.get(mode.param)) : undefined

  const content = active === 'user' ? <UserTab initial={initial} />
    : active === 'role' ? <RoleTab initial={initial} />
      : active === 'group' ? <GroupTab initial={initial} />
        : active === 'policy' ? <PolicyTab initial={initial} />
          : <SodTab />

  return (
    <ReportDownloadProvider>
      {() => (
        <div className="change-simulation">
          <div className="change-simulation-layout">
            <nav className="change-simulation-tabs" aria-label="Simülasyon türü">
              {modes.map((item, index) => (
                <button key={item.key} type="button" className={active === item.key ? 'is-active' : ''}
                  onClick={() => setParams({ tab: item.key })}>
                  <span className="change-simulation-mode-icon">{item.icon}</span>
                  <span className="change-simulation-mode-copy"><small>0{index + 1} · {item.title}</small><strong>{item.label}</strong><span>{item.description}</span></span>
                </button>
              ))}
            </nav>

            <main className="change-simulation-stage">
              <section className="change-simulation-workbench" key={active}>
                {content}
              </section>
            </main>
          </div>
        </div>
      )}
    </ReportDownloadProvider>
  )
}
