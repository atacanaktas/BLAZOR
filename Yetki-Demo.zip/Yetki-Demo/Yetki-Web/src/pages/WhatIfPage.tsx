import { Alert, App, Button, Card, Checkbox, Col, Divider, Empty, Flex, Input, Radio, Row, Select, Spin, Switch, Table, Tabs, Tag, Typography } from 'antd'
import { ExperimentOutlined } from '@ant-design/icons'
import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import type { Dayjs } from 'dayjs'
import { api } from '../api/client'
import type {
  AuthorizationChangeSet, ChangeImpactResult, CombiningAlgorithm, ConditionDraft, ConditionTypeInfo, ConditionView, GroupFilterDraft,
  ImpactScenario, InclusionMode, ParamDef, PolicyChangeSet, PolicyMode, RuleView, SharedConditionInfo, TargetView,
} from '../api/types'
import { toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { Code, PageHeader, TargetTag, algorithmLabel } from '../components/common'
import { ImpactView } from '../components/ImpactView'
import { DEFAULT_SCENARIOS, PolicyImpactView, ScenarioSettings, nextBusinessMorning, usePolicyImpact } from '../components/PolicyImpact'
import { GroupFilterEditor } from '../components/GroupFilterEditor'
import { ConditionBuilder, emptyPredicate, renderDraft } from '../components/ConditionBuilder'
import { TargetPicker, type TargetValue } from '../components/Catalog'

function useRbacImpact() {
  const { message } = App.useApp()
  const [result, setResult] = useState<ChangeImpactResult>()
  const [loading, setLoading] = useState(false)
  const run = async (cs: AuthorizationChangeSet) => {
    setLoading(true)
    try {
      setResult(await api.post<ChangeImpactResult>('/api/simulation/changes', cs))
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setLoading(false)
    }
  }
  return { result, loading, run, setResult }
}

const Result = ({ r, loading }: { r?: ChangeImpactResult; loading: boolean }) =>
  loading ? <Spin /> : r ? <ImpactView impact={r} /> : <Empty description="Değişiklikleri seçip 'Etkiyi hesapla'ya basın" />

// ================================ Kullanıcı ================================

interface UserDetailLite { user: { id: number; userName: string; title?: string; isOnLeave: boolean; isActive: boolean; cashWithdrawalLimit: number; tenant: string }; roles: { roleId: number; code: string }[]; units: { orgUnitId: number; code: string }[] }

/** Seçim değişince gövde key ile yeniden kurulur: taslak değişiklikler sıfırlanır (effect gerekmez). */
function UserTab({ initial }: { initial?: number }) {
  const [userId, setUserId] = useState<number | undefined>(initial)
  return <UserTabBody key={userId ?? 0} userId={userId} onSelect={setUserId} />
}

function UserTabBody({ userId, onSelect }: { userId?: number; onSelect: (id: number) => void }) {
  const users = useOptions('users')
  const roles = useOptions('roles')
  const units = useOptions('units')
  const detail = useApi<UserDetailLite>(userId ? `/api/users/${userId}` : null)
  const [addRoles, setAddRoles] = useState<number[]>([])
  const [removeRoles, setRemoveRoles] = useState<number[]>([])
  const [addUnits, setAddUnits] = useState<number[]>([])
  const [removeUnits, setRemoveUnits] = useState<number[]>([])
  const [title, setTitle] = useState<string>()
  const [onLeave, setOnLeave] = useState<boolean>()
  const { result, loading, run } = useRbacImpact()
  const d = detail.data
  const cs = (): AuthorizationChangeSet => ({
    userRoles: [...addRoles.map((roleId) => ({ userId: userId!, roleId, add: true })), ...removeRoles.map((roleId) => ({ userId: userId!, roleId, add: false }))],
    userUnits: [...addUnits.map((orgUnitId) => ({ userId: userId!, orgUnitId, add: true })), ...removeUnits.map((orgUnitId) => ({ userId: userId!, orgUnitId, add: false }))],
    userUpdates: title !== undefined || onLeave !== undefined ? [{ userId: userId!, title, isOnLeave: onLeave }] : [],
  })
  return (
    <Row gutter={16}>
      <Col xs={24} xl={8}>
        <Card size="small">
          <Typography.Text strong>Kullanıcı</Typography.Text>
          <Select showSearch optionFilterProp="label" style={{ width: '100%', marginBottom: 12 }} value={userId} onChange={onSelect} options={toSelectOptions(users)} />
          {d && (
            <Flex vertical gap={8}>
              <div>Mevcut roller: {d.roles.map((r) => <Tag key={r.roleId} color="blue">{r.code}</Tag>)}</div>
              <div>Birimler: {d.units.map((u) => <Tag key={u.orgUnitId}>{u.code}</Tag>)}</div>
              <Divider style={{ margin: '4px 0' }} />
              <span>Rol ver:</span><Select mode="multiple" value={addRoles} onChange={setAddRoles} optionFilterProp="label" options={toSelectOptions(roles, d.roles.map((r) => r.roleId))} />
              <span>Rol al:</span><Select mode="multiple" value={removeRoles} onChange={setRemoveRoles} options={d.roles.map((r) => ({ value: r.roleId, label: r.code }))} />
              <span>Birime ekle:</span><Select mode="multiple" value={addUnits} onChange={setAddUnits} optionFilterProp="label" options={units.filter((u) => u.group === d.user.tenant && !d.units.some((x) => x.orgUnitId === u.value)).map((u) => ({ value: u.value, label: u.label }))} />
              <span>Birimden çıkar:</span><Select mode="multiple" value={removeUnits} onChange={setRemoveUnits} options={d.units.map((u) => ({ value: u.orgUnitId, label: u.code }))} />
              <span>Unvan (grup TITLE kriteri):</span><Input placeholder={d.user.title} value={title} onChange={(e) => setTitle(e.target.value || undefined)} />
              <Checkbox checked={onLeave ?? d.user.isOnLeave} onChange={(e) => setOnLeave(e.target.checked)}>İzinde (policy'ler; RBAC değişmez)</Checkbox>
              <Button type="primary" icon={<ExperimentOutlined />} onClick={() => run(cs())}>Etkiyi hesapla</Button>
            </Flex>
          )}
        </Card>
      </Col>
      <Col xs={24} xl={16}><Result r={result} loading={loading} /></Col>
    </Row>
  )
}

// ================================ Rol ================================

function RoleTab({ initial }: { initial?: number }) {
  const [roleId, setRoleId] = useState<number | undefined>(initial)
  return <RoleTabBody key={roleId ?? 0} roleId={roleId} onSelect={setRoleId} />
}

function RoleTabBody({ roleId, onSelect }: { roleId?: number; onSelect: (id: number) => void }) {
  const roles = useOptions('roles')
  const perms = useOptions('permissions')
  const detail = useApi<{ permissions: { id: number; code: string }[] }>(roleId ? `/api/roles/${roleId}` : null)
  const [add, setAdd] = useState<number[]>([])
  const [remove, setRemove] = useState<number[]>([])
  const [deactivate, setDeactivate] = useState(false)
  const { result, loading, run } = useRbacImpact()
  return (
    <Row gutter={16}>
      <Col xs={24} xl={8}>
        <Card size="small">
          <Typography.Text strong>Rol</Typography.Text>
          <Select showSearch optionFilterProp="label" style={{ width: '100%', marginBottom: 12 }} value={roleId} onChange={onSelect} options={toSelectOptions(roles)} />
          {detail.data && (
            <Flex vertical gap={8}>
              <span>Role permission ekle:</span><Select mode="multiple" value={add} onChange={setAdd} optionFilterProp="label" options={toSelectOptions(perms, detail.data.permissions.map((p) => p.id))} />
              <span>Rolden permission çıkar:</span><Select mode="multiple" value={remove} onChange={setRemove} optionFilterProp="label" options={detail.data.permissions.map((p) => ({ value: p.id, label: p.code }))} />
              <Checkbox checked={deactivate} onChange={(e) => setDeactivate(e.target.checked)}>Rolü pasifleştir</Checkbox>
              <Button type="primary" icon={<ExperimentOutlined />} onClick={() => run({
                rolePermissions: [...add.map((permissionId) => ({ roleId: roleId!, permissionId, add: true })), ...remove.map((permissionId) => ({ roleId: roleId!, permissionId, add: false }))],
                roleUpdates: deactivate ? [{ roleId: roleId!, isActive: false }] : [],
              })}>Etkiyi hesapla</Button>
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>Rolü doğrudan veya grup üzerinden taşıyan herkes hesaba katılır; başka kaynaktan aynı yetkiyi alanlar "korunur".</Typography.Text>
            </Flex>
          )}
        </Card>
      </Col>
      <Col xs={24} xl={16}><Result r={result} loading={loading} /></Col>
    </Row>
  )
}

// ================================ Grup ================================

interface GroupLite {
  group: { id: number; tenantId: number }
  filters: { mode: InclusionMode; description?: string; criteria: { attribute: string; values: string[] }[] }[]
  roles: { id: number; code: string }[]
  permissions: { id: number; code: string }[]
}

function GroupTab({ initial }: { initial?: number }) {
  const [groupId, setGroupId] = useState<number | undefined>(initial)
  return <GroupTabBody key={groupId ?? 0} groupId={groupId} onSelect={setGroupId} />
}

const toFilterDrafts = (d: GroupLite): GroupFilterDraft[] =>
  d.filters.map((f) => ({ mode: f.mode, description: f.description, criteria: f.criteria.map((c) => ({ ...c, values: [...c.values] })) }))

function GroupTabBody({ groupId, onSelect }: { groupId?: number; onSelect: (id: number) => void }) {
  const groups = useOptions('groups')
  const roles = useOptions('roles')
  const perms = useOptions('permissions')
  const users = useOptions('users')
  const detail = useApi<GroupLite>(groupId ? `/api/groups/${groupId}` : null)
  // null = henüz düzenlenmedi → sunucudaki kurallar gösterilir
  const [edited, setEdited] = useState<GroupFilterDraft[] | null>(null)
  const [addRoles, setAddRoles] = useState<number[]>([])
  const [addPerms, setAddPerms] = useState<number[]>([])
  const [removeGrants, setRemoveGrants] = useState<string[]>([])
  const [addMembers, setAddMembers] = useState<number[]>([])
  const { result, loading, run } = useRbacImpact()
  const d = detail.data
  const filters = edited ?? (d ? toFilterDrafts(d) : [])
  const filtersChanged = edited !== null
  return (
    <Row gutter={16}>
      <Col xs={24} xl={11}>
        <Card size="small">
          <Typography.Text strong>Grup</Typography.Text>
          <Select showSearch optionFilterProp="label" style={{ width: '100%', marginBottom: 12 }} value={groupId} onChange={onSelect} options={toSelectOptions(groups)} />
          {d && (
            <Flex vertical gap={8}>
              <Typography.Text strong>Kitle kuralları {filtersChanged && <Tag color="gold">değişti</Tag>}</Typography.Text>
              <GroupFilterEditor value={filters} onChange={setEdited} />
              <Divider style={{ margin: '4px 0' }} />
              <span>Grup şu rolleri de versin:</span><Select mode="multiple" value={addRoles} onChange={setAddRoles} optionFilterProp="label" options={toSelectOptions(roles, d.roles.map((r) => r.id))} />
              <span>Grup şu permission'ları da versin:</span><Select mode="multiple" value={addPerms} onChange={setAddPerms} optionFilterProp="label" options={toSelectOptions(perms, d.permissions.map((p) => p.id))} />
              <span>Artık vermesin:</span><Select mode="multiple" value={removeGrants} onChange={setRemoveGrants}
                options={[...d.roles.map((r) => ({ value: `Role:${r.id}`, label: `rol ${r.code}` })), ...d.permissions.map((p) => ({ value: `Permission:${p.id}`, label: p.code }))]} />
              <span>Açık üye ekle:</span><Select mode="multiple" value={addMembers} onChange={setAddMembers} optionFilterProp="label" options={toSelectOptions(users)} />
              <Button type="primary" icon={<ExperimentOutlined />} onClick={() => run({
                groupFilters: filtersChanged ? [{ groupId: groupId!, filters }] : [],
                groupGrants: [
                  ...addRoles.map((targetId) => ({ groupId: groupId!, kind: 'Role' as const, targetId, add: true })),
                  ...addPerms.map((targetId) => ({ groupId: groupId!, kind: 'Permission' as const, targetId, add: true })),
                  ...removeGrants.map((k) => ({ groupId: groupId!, kind: k.split(':')[0] as 'Role' | 'Permission', targetId: Number(k.split(':')[1]), add: false })),
                ],
                groupMembers: addMembers.map((userId) => ({ groupId: groupId!, userId, add: true })),
              })}>Etkiyi hesapla</Button>
            </Flex>
          )}
        </Card>
      </Col>
      <Col xs={24} xl={13}><Result r={result} loading={loading} /></Col>
    </Row>
  )
}

// ================================ Policy ================================

interface PolicyLite {
  policy: { id: number; code: string; mode: PolicyMode; isActive: boolean; algorithm: CombiningAlgorithm }
  targets: TargetView[]
  rules: RuleView[]
}

interface Pred { conditionId: number; rule: string; type: string; parameters: Record<string, string> }

function collectPredicates(rules: RuleView[]): Pred[] {
  const out: Pred[] = []
  const walk = (rule: string, n?: ConditionView) => {
    if (!n) return
    if (n.kind === 'Predicate' && n.id > 0 && n.conditionType) out.push({ conditionId: n.id, rule, type: n.conditionType, parameters: n.parameters })
    n.children.forEach((c) => walk(n.kind === 'Reference' ? `${rule} → @${n.sharedCondition} (ORTAK)` : rule, c))
  }
  rules.forEach((r) => walk(r.code, r.condition))
  return out
}

function PolicyTab({ initial }: { initial?: number }) {
  const [policyId, setPolicyId] = useState<number | undefined>(initial)
  return <PolicyTabBody key={policyId ?? 0} policyId={policyId} onSelect={setPolicyId} />
}

function PolicyTabBody({ policyId, onSelect }: { policyId?: number; onSelect: (id: number) => void }) {
  const policies = useOptions('policies')
  const types = useApi<ConditionTypeInfo[]>('/api/condition-types').data ?? []
  const shared = useApi<SharedConditionInfo[]>('/api/shared-conditions').data ?? []
  const detail = useApi<PolicyLite>(policyId ? `/api/policies/${policyId}` : null)
  const [active, setActive] = useState<boolean>()
  const [mode, setMode] = useState<PolicyMode>()
  const [algorithm, setAlgorithm] = useState<CombiningAlgorithm>()
  const [removedTargets, setRemovedTargets] = useState<number[]>([])
  const [newTarget, setNewTarget] = useState<TargetValue>()
  const [newTargetMode, setNewTargetMode] = useState<InclusionMode>('Include')
  const [addedTargets, setAddedTargets] = useState<{ mode: InclusionMode; t: TargetValue }[]>([])
  const [ruleOverrides, setRuleOverrides] = useState<Record<number, { isActive?: boolean }>>({})
  const [paramTarget, setParamTarget] = useState<number>()
  const [paramValues, setParamValues] = useState<Record<string, string>>({})
  const [draftOn, setDraftOn] = useState(false)
  const [draft, setDraft] = useState<ConditionDraft>(emptyPredicate())
  const [scenarios, setScenarios] = useState<ImpactScenario[]>(DEFAULT_SCENARIOS)
  const [asOf, setAsOf] = useState<Dayjs | undefined>(nextBusinessMorning())
  const { result, loading, run } = usePolicyImpact()

  const d = detail.data
  const preds = useMemo(() => collectPredicates(d?.rules ?? []), [d])
  const selectedPred = preds.find((p) => p.conditionId === paramTarget)
  const paramDefs: ParamDef[] = selectedPred ? JSON.parse(types.find((t) => t.code === selectedPred.type)?.parameterSchemaJson ?? '[]') : []

  const changes = (): PolicyChangeSet => ({
    policyActivations: active !== undefined && active !== d!.policy.isActive ? [{ policyId: policyId!, isActive: active }] : [],
    policyModes: mode && mode !== d!.policy.mode ? [{ policyId: policyId!, mode }] : [],
    policyAlgorithms: algorithm && algorithm !== d!.policy.algorithm ? [{ policyId: policyId!, algorithm }] : [],
    removedTargetIds: removedTargets,
    addedTargets: addedTargets.map((x) => ({ policyId: policyId!, mode: x.mode, targetType: x.t.targetType, targetId: x.t.targetId })),
    ruleOverrides: Object.entries(ruleOverrides).map(([ruleId, o]) => ({ ruleId: Number(ruleId), ...o })),
    conditionOverrides: selectedPred ? [{ conditionId: selectedPred.conditionId, parameters: { ...selectedPred.parameters, ...paramValues } }] : [],
    addedRules: draftOn ? [{ policyId: policyId!, code: 'WHATIF_DRAFT', name: 'What-If taslak rule', order: 99, reasonCode: 'WHATIF_DRAFT', condition: draft }] : [],
  })

  return (
    <Row gutter={16}>
      <Col xs={24} xl={10}>
        <Card size="small">
          <Typography.Text strong>Policy</Typography.Text>
          <Select showSearch optionFilterProp="label" style={{ width: '100%', marginBottom: 12 }} value={policyId} onChange={onSelect} options={toSelectOptions(policies)} />
          {d && (
            <Flex vertical gap={10}>
              <Flex gap={12} wrap align="center">
                <span>Aktif <Switch checked={active ?? d.policy.isActive} onChange={setActive} /></span>
                <Radio.Group size="small" value={mode ?? d.policy.mode} onChange={(e) => setMode(e.target.value)} options={[{ value: 'Enforce', label: 'Enforce' }, { value: 'ReportOnly', label: 'ReportOnly' }]} optionType="button" />
                <Select size="small" style={{ width: 230 }} value={algorithm ?? d.policy.algorithm} onChange={setAlgorithm}
                  options={(Object.keys(algorithmLabel) as CombiningAlgorithm[]).map((a) => ({ value: a, label: algorithmLabel[a] }))} />
              </Flex>
              <Card size="small" title="A) Hedefler (mirası değiştir)">
                <Flex wrap gap={4}>
                  {d.targets.map((t) => (
                    <span key={t.id} style={{ opacity: removedTargets.includes(t.id) ? 0.4 : 1 }}>
                      <TargetTag type={t.targetType} description={t.description} mode={t.mode} closable={!removedTargets.includes(t.id)} onClose={() => setRemovedTargets([...removedTargets, t.id])} />
                    </span>
                  ))}
                  {addedTargets.map((x, i) => <Tag key={i} color="green">+ {x.mode === 'Exclude' ? 'HARİÇ ' : ''}{x.t.targetType} #{x.t.targetId ?? 'tümü'}</Tag>)}
                </Flex>
                <Divider style={{ margin: '8px 0' }} />
                <Radio.Group size="small" value={newTargetMode} onChange={(e) => setNewTargetMode(e.target.value)} options={[{ value: 'Include', label: 'Dahil' }, { value: 'Exclude', label: 'Hariç' }]} optionType="button" style={{ marginBottom: 6 }} />
                <TargetPicker value={newTarget} onChange={setNewTarget} />
                <Button size="small" style={{ marginTop: 6 }} disabled={!newTarget} onClick={() => { setAddedTargets([...addedTargets, { mode: newTargetMode, t: newTarget! }]); setNewTarget(undefined) }}>Hedefi ekle</Button>
              </Card>
              <Card size="small" title="B) Rule'lar (aktif / pasif)">
                {d.rules.map((r) => (
                  <Flex key={r.id} justify="space-between" align="center" style={{ marginBottom: 4 }}>
                    <span style={{ fontSize: 12 }}><Code>{r.code}</Code> <Typography.Text type="secondary">{r.expression}</Typography.Text></span>
                    <Flex gap={6}>
                      <Switch size="small" checked={ruleOverrides[r.id]?.isActive ?? r.isActive} onChange={(isActive) => setRuleOverrides({ ...ruleOverrides, [r.id]: { ...ruleOverrides[r.id], isActive } })} />
                    </Flex>
                  </Flex>
                ))}
              </Card>
              <Card size="small" title="C) Koşul parametresi (ör. mesai bitişi, eşik)">
                <Select allowClear style={{ width: '100%' }} value={paramTarget} onChange={(v) => { setParamTarget(v); setParamValues({}) }} placeholder="Predicate seç"
                  options={preds.map((p) => ({ value: p.conditionId, label: `${p.rule} · ${p.type}(${Object.entries(p.parameters).map(([k, v]) => `${k}=${v}`).join(', ')})` }))} />
                {selectedPred && paramDefs.map((pd) => (
                  <Input key={pd.key} size="small" style={{ marginTop: 4 }} addonBefore={pd.key} placeholder={selectedPred.parameters[pd.key] ?? pd.defaultValue}
                    value={paramValues[pd.key] ?? selectedPred.parameters[pd.key] ?? ''} onChange={(e) => setParamValues({ ...paramValues, [pd.key]: e.target.value })} />
                ))}
              </Card>
              <Card size="small" title={<><Checkbox checked={draftOn} onChange={(e) => setDraftOn(e.target.checked)} /> D) Taslak Deny rule ekle</>}>
                {draftOn && (<><Typography.Text type="secondary" style={{ fontSize: 12 }}>{renderDraft(draft)}</Typography.Text><ConditionBuilder value={draft} onChange={setDraft} types={types} shared={shared} /></>)}
              </Card>
              <ScenarioSettings scenarios={scenarios} setScenarios={setScenarios} asOf={asOf} setAsOf={setAsOf} />
              <Button type="primary" icon={<ExperimentOutlined />} loading={loading} onClick={() => run(changes(), scenarios, asOf)}>Etkiyi hesapla</Button>
            </Flex>
          )}
        </Card>
      </Col>
      <Col xs={24} xl={14}>{loading ? <Spin /> : result ? <PolicyImpactView result={result} /> : <Empty description="Policy değişikliği tanımlayıp hesaplayın" />}</Col>
    </Row>
  )
}

// ================================ SoD ================================

function SodTab() {
  const perms = useOptions('permissions')
  const roles = useOptions('roles')
  const { message } = App.useApp()
  const [permissionIds, setPerms] = useState<number[]>([])
  const [roleIds, setRoles] = useState<number[]>([])
  const [rows, setRows] = useState<{ userName: string; fullName: string; conflicts: { code: string; matchedMembers: { code: string; paths: string[] }[] }[] }[]>()
  return (
    <Row gutter={16}>
      <Col xs={24} xl={8}>
        <Card size="small" title="Taslak SoD kuralı (üyelerden 2+ tanesine sahip olmak ihlal)">
          <Flex vertical gap={8}>
            <span>Permission üyeleri</span><Select mode="multiple" optionFilterProp="label" value={permissionIds} onChange={setPerms} options={toSelectOptions(perms)} />
            <span>Rol üyeleri</span><Select mode="multiple" optionFilterProp="label" value={roleIds} onChange={setRoles} options={toSelectOptions(roles)} />
            <Button type="primary" onClick={async () => { try { setRows(await api.post('/api/simulation/sod-rule', { code: 'DRAFT', permissionIds, roleIds })) } catch (e) { message.error((e as Error).message) } }}>Mevcut ihlalleri bul</Button>
          </Flex>
        </Card>
      </Col>
      <Col xs={24} xl={16}>
        {rows && (
          <>
            <Alert type={rows.length ? 'warning' : 'success'} message={`${rows.length} kullanıcı bu kuralı şu an ihlal ediyor`} style={{ marginBottom: 8 }} />
            <Table size="small" rowKey="userName" dataSource={rows} pagination={{ pageSize: 15 }}
              columns={[
                { title: 'Kullanıcı', render: (_, r) => <>{r.userName}<br /><Typography.Text type="secondary">{r.fullName}</Typography.Text></> },
                { title: 'Çakışan üyeler (kaynak yolları)', render: (_, r) => r.conflicts[0]?.matchedMembers.map((m) => <div key={m.code} style={{ fontSize: 12 }}><Code>{m.code}</Code> {m.paths.join(' | ')}</div>) },
              ]} />
          </>
        )}
      </Col>
    </Row>
  )
}

export function WhatIfPage() {
  const [params, setParams] = useSearchParams()
  const tab = params.get('tab') ?? 'user'
  const num = (k: string) => (params.get(k) ? Number(params.get(k)) : undefined)
  return (
    <>
      <PageHeader title="Etki simülasyonu" subtitle="Değişiklikleri uygulamadan önce yetkilere ve kullanıcılara etkisini görün." />
      <Tabs activeKey={tab} onChange={(k) => setParams({ tab: k })} destroyOnHidden
        items={[
          { key: 'user', label: 'Kullanıcı', children: <UserTab initial={num('userId')} /> },
          { key: 'role', label: 'Rol', children: <RoleTab initial={num('roleId')} /> },
          { key: 'group', label: 'Grup (kitle kuralı)', children: <GroupTab initial={num('groupId')} /> },
          { key: 'policy', label: 'Policy (hedef / rule / mod)', children: <PolicyTab initial={num('policyId')} /> },
          { key: 'sod', label: 'SoD kuralı', children: <SodTab /> },
        ]} />
    </>
  )
}

