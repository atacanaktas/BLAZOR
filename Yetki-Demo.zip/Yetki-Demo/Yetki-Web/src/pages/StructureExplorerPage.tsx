import { Alert, App, Breadcrumb, Button, Drawer, Dropdown, Empty, Input, Pagination, Segmented, Skeleton, Tag, Tooltip } from 'antd'
import { ApiOutlined, ApartmentOutlined, AppstoreOutlined, ArrowLeftOutlined, ArrowRightOutlined, CloudServerOutlined, CodeOutlined, DesktopOutlined, EditOutlined, GlobalOutlined, KeyOutlined, LinkOutlined, MobileOutlined, PlusOutlined, ReloadOutlined, SafetyCertificateOutlined, SearchOutlined, UnorderedListOutlined, UserOutlined } from '@ant-design/icons'
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import { invalidateOptions } from '../hooks/useApi'
import { invalidateCatalogTree } from '../components/Catalog'
import { ExternalDependencyModal } from '../components/External'
import { ExplorerCreateModal, ExplorerRenameModal, PermissionMappingModal } from '../features/structure/ExplorerForms'
import { createKinds, explorerLabels, itemLabel, managementLink, readTrail, type ExplorerItem, type ExplorerKind, type ExplorerPage, type TrailEntry } from '../features/structure/explorer'
import { StructureWorld } from '../features/structure/StructureWorld'
import '../features/structure/explorer.css'

const icons: Record<ExplorerKind, ReactNode> = { user: <UserOutlined />, tenant: <GlobalOutlined />, application: <AppstoreOutlined />, resource: <ApartmentOutlined />, api: <ApiOutlined />, endpoint: <CodeOutlined />, ui: <DesktopOutlined />, permission: <KeyOutlined />, policy: <SafetyCertificateOutlined />, rule: <CodeOutlined />, role: <SafetyCertificateOutlined />, client: <MobileOutlined />, externalPermission: <CloudServerOutlined /> }
const stages = ['Tenant', 'Platform', 'Resource', 'API / Screen', 'Endpoint / UI', 'Permission', 'Policy / Rule']
const stageOf = (n?: TrailEntry) => !n ? 0 : ({ tenant: 1, application: 2, resource: 2, api: 3, ui: n.type === 'Screen' ? 3 : 4, endpoint: 4, permission: 5, policy: 6, rule: 6, role: 6, client: 1, externalPermission: 6, user: 1 }[n.kind])

export function StructureExplorerPage() {
  const [params, setParams] = useSearchParams()
  const trail = useMemo(() => readTrail(params.get('path')), [params])
  const selected = trail.at(-1)
  const tenantId = trail.find((x) => x.kind === 'tenant')?.id
  const relation = params.get('relation') ?? ''
  const search = params.get('q') ?? ''
  const page = Math.max(1, Number(params.get('page')) || 1)
  const [searchInput, setSearchInput] = useState(search)
  const [view, setView] = useState<string | number>('world')
  const [contextOpen, setContextOpen] = useState(false)
  const [revision, setRevision] = useState(0)
  const [response, setResponse] = useState<{ key: string; value: ExplorerPage }>()
  const [error, setError] = useState<{ key: string; message: string }>()
  const [creating, setCreating] = useState<ExplorerKind>()
  const [renaming, setRenaming] = useState(false)
  const [mapping, setMapping] = useState(false)
  const [external, setExternal] = useState(false)
  const [inspecting, setInspecting] = useState<ExplorerItem>()
  const listHeading = useRef<HTMLHeadingElement>(null)
  const { message } = App.useApp()
  const request = new URLSearchParams({ kind: selected?.kind ?? 'root', id: String(selected?.id ?? 0), page: String(page), pageSize: view === 'world' ? '6' : '12', q: search })
  if (tenantId) request.set('tenantId', String(tenantId))
  if (relation) request.set('relation', relation)
  const requestKey = `${request.toString()}&revision=${revision}`
  const data = response?.key === requestKey ? response.value : undefined
  const failure = error?.key === requestKey ? error.message : undefined
  const loading = !data && !failure
  const current = data?.current
  const children = data ? createKinds(current) : []
  const activeRelation = data?.relations.find((x) => x.key === data.relation)

  useEffect(() => {
    let active = true
    api.get<ExplorerPage>(`/api/structure/explore?${requestKey}`).then((value) => {
      if (active) { setResponse({ key: requestKey, value }); listHeading.current?.focus({ preventScroll: true }) }
    }).catch((e) => { if (active) setError({ key: requestKey, message: e.message }) })
    return () => { active = false }
  }, [requestKey])
  useEffect(() => { const timer = setTimeout(() => setSearchInput(search), 0); return () => clearTimeout(timer) }, [search, selected?.kind, selected?.id])
  const navigate = (next: TrailEntry[], values: { relation?: string; q?: string; page?: number } = next.at(-1)?.view ?? {}, replace = false) => {
    const query = new URLSearchParams()
    if (next.length) query.set('path', JSON.stringify(next.map(({ kind, id, code, name, type, view }) => ({ kind, id, code, name, type, view }))))
    if (values.relation) query.set('relation', values.relation)
    if (values.q) query.set('q', values.q)
    if (values.page && values.page > 1) query.set('page', String(values.page))
    setContextOpen(false)
    setSearchInput(values.q ?? '')
    setParams(query, { replace })
  }
  const open = (item: ExplorerItem) => {
    if (item.kind === 'rule' || item.kind === 'role' || item.kind === 'user') { setInspecting(item); return }
    const existing = trail.findIndex((x) => x.kind === item.kind && x.id === item.id)
    const savedTrail = trail.map((entry, i) => i === trail.length - 1 ? { ...entry, view: { relation: data?.relation ?? relation, q: search, page: data?.page ?? page } } : entry)
    navigate(existing >= 0 ? savedTrail.slice(0, existing + 1) : [...savedTrail, item])
  }
  const refresh = () => {
    invalidateCatalogTree()
    invalidateOptions('tenants', 'applications', 'nodes', 'permissions', 'clients', 'resources', 'external-permissions')
    setRevision((n) => n + 1)
  }
  const created = async (kind: ExplorerKind, id: number) => {
    setCreating(undefined); refresh()
    try {
      const next = await api.get<ExplorerPage>(`/api/structure/explore?kind=${kind}&id=${id}${tenantId && kind !== 'tenant' ? `&tenantId=${tenantId}` : ''}`)
      if (next.current) {
        if (kind === 'tenant') navigate([next.current])
        else open(next.current)
      }
    } catch (e) { message.error(`Created successfully, but could not open the record: ${(e as Error).message}`) }
  }
  const back = () => navigate(trail.slice(0, -1))
  const canRename = current && ['tenant', 'application', 'resource', 'permission', 'client', 'api', 'ui', 'externalPermission'].includes(current.kind)
  const canMap = current && ['endpoint', 'ui'].includes(current.kind)
  const addMenu = children.map((kind) => ({ key: kind, icon: icons[kind], label: kind === 'resource' ? `Add ${current?.kind === 'application' ? 'Domain' : current?.type === 'Domain' ? 'Module' : 'Submodule'}` : `Add ${explorerLabels[kind]}`, onClick: () => setCreating(kind) }))

  const contextPanel = <>
        <span className="context-caption">CURRENT CONTEXT</span><div className="context-icon">{selected ? icons[selected.kind] : <ApartmentOutlined />}</div>
        <span className="context-type">{current ? itemLabel(current) : selected ? itemLabel(selected) : 'Workspace'}</span>
        <h2>{current?.name ?? selected?.name ?? 'Start with a Tenant'}</h2><code>{current?.code ?? selected?.code ?? 'Your architecture, in focus.'}</code>
        {current?.active !== undefined && <Tag color={current.active ? 'blue' : undefined}>{current.active ? 'Active' : 'Inactive'}</Tag>}
        {current && ['policy', 'permission'].includes(current.kind) && <Tag>{current.type}</Tag>}
        {current?.description && <p className="context-description">{current.description}</p>}
        {current?.tenantId && tenantId && current.tenantId !== tenantId && <Tag>Inherited definition</Tag>}
        {canMap && <div className={`context-mapping ${current.permissionId ? 'is-mapped' : ''}`}><KeyOutlined /><div><strong>{current.permissionId ? 'Permission mapped' : 'No direct mapping'}</strong><span>{current.permissionId ? `Permission #${current.permissionId}` : current.kind === 'endpoint' ? 'Endpoint is fail-closed' : 'Check parent visibility'}</span></div></div>}
        <div className="context-actions">{canRename && <Button icon={<EditOutlined />} onClick={() => setRenaming(true)}>Rename</Button>}{canMap && <Button icon={<LinkOutlined />} onClick={() => setMapping(true)}>Map Permission</Button>}{current && ['permission', 'api', 'endpoint'].includes(current.kind) && <Button icon={<CloudServerOutlined />} onClick={() => setExternal(true)}>Link External Permission</Button>}{current && <Link to={managementLink(current)}>Open management <ArrowRightOutlined /></Link>}</div>
        <div className="context-help"><span>FOCUS MODE</span><p>Yalnızca seçili seviyenin kayıtları görünür. Arama bu seviyede çalışır; üst yoldan istediğiniz adıma dönebilirsiniz.</p></div>
</>

  return <div className={`explorer-page ${view === 'world' ? 'is-world' : ''}`}>
    <header className="explorer-heading"><div><span className="explorer-eyebrow"><ApartmentOutlined /> ACCESS CITY</span><h1>All-in-One <span>Architecture comes alive.</span></h1><p>Plazalar, sunucular, kitaplar ve karakterler. Yapınızın içinde gezinin, bağlantıları izleyin ve yönetin.</p></div><div className="explorer-heading-actions"><Tooltip title="Refresh"><Button aria-label="Refresh explorer" icon={<ReloadOutlined />} loading={loading} onClick={refresh} /></Tooltip>{children.length > 0 && <Dropdown menu={{ items: addMenu }} trigger={['click']}><Button type="primary" icon={<PlusOutlined />}>Add</Button></Dropdown>}</div></header>
    <div className="explorer-stages" aria-label="Exploration stages">{stages.map((label, i) => <div key={label} className={`${i === stageOf(selected) ? 'is-current' : i < stageOf(selected) ? 'is-complete' : ''}`}><span>{String(i + 1).padStart(2, '0')}</span><strong>{label}</strong>{i < stages.length - 1 && <ArrowRightOutlined />}</div>)}</div>
    <div className="explorer-breadcrumb"><Button type="text" aria-label="Go back one level" icon={<ArrowLeftOutlined />} disabled={!trail.length} onClick={back} /><Breadcrumb items={[{ title: <button onClick={() => navigate([])}>Workspace</button> }, ...trail.map((entry, i) => ({ title: <button title={entry.name} onClick={() => navigate(trail.slice(0, i + 1))}>{i === trail.length - 1 && current ? current.code : entry.code}</button> }))]} /><Tooltip title="Copy a link to this view"><Button type="text" aria-label="Copy view link" icon={<LinkOutlined />} onClick={async () => { try { await navigator.clipboard.writeText(window.location.href); message.success('View link copied') } catch { message.info('Copy the URL from your browser.') } }} /></Tooltip></div>
    <div className="explorer-workspace">
      {view === 'world' ? <Drawer open={contextOpen} onClose={() => setContextOpen(false)} title="Manage landmark" width={340}><div className="world-context-panel">{contextPanel}</div></Drawer> : <aside className="explorer-context">{contextPanel}</aside>}
      <section className="explorer-content" aria-busy={loading}>
        {failure ? <Alert type="error" showIcon title="Could not load this level" description={failure} action={<Button onClick={refresh}>Retry</Button>} /> : <>
          <div className="explorer-content-title"><div><span className="explorer-eyebrow">{selected ? `${itemLabel(selected).toUpperCase()} / EXPLORE` : 'CHOOSE YOUR STARTING POINT'}</span><h2 ref={listHeading} tabIndex={-1}>{activeRelation?.label ?? (loading ? 'Loading…' : 'Tenants')} {data && <span>{activeRelation?.count ?? 0}</span>}</h2></div><Segmented aria-label="Result layout" value={view} onChange={setView} options={[{ value: 'world', icon: <GlobalOutlined />, label: 'World' }, { value: 'cards', icon: <AppstoreOutlined />, label: 'Cards' }, { value: 'list', icon: <UnorderedListOutlined />, label: 'List' }]} /></div>
          {data && data.relations.length > 1 && <div className="explorer-relations" role="tablist" aria-label="Relations">{data.relations.map((r) => <button key={r.key} role="tab" aria-selected={data.relation === r.key} onClick={() => navigate(trail, { relation: r.key })}>{r.label}<span>{r.count}</span></button>)}</div>}
          <div className="explorer-search"><Input.Search prefix={<SearchOutlined />} allowClear placeholder={`Search ${activeRelation?.label.toLowerCase() ?? 'this level'} by name or code…`} aria-label="Search this level" value={searchInput} onChange={(e) => { setSearchInput(e.target.value); if (!e.target.value && search) navigate(trail, { relation: data?.relation }) }} onSearch={(q) => navigate(trail, { relation: data?.relation ?? relation, q: q.trim() })} enterButton="Search" /><span>{view === 'world' ? '6 per page' : '12 per page'}</span></div>
          {view === 'world' && response && <StructureWorld data={data ?? response.value} loading={loading} trail={trail} refreshKey={requestKey} onOpen={open} onInspect={() => setContextOpen(true)} onBack={back} onRelation={(key) => navigate(trail, { relation: key })} onTrail={(index) => navigate(trail.slice(0, index + 1))} />}
          {view === 'world' && loading && !response && <div className="explorer-loading"><Skeleton active paragraph={{ rows: 10 }} /></div>}
          {view === 'world' && data && data.total > 0 && <div className="explorer-pagination"><span>{(data.page - 1) * data.pageSize + 1}–{Math.min(data.page * data.pageSize, data.total)} of {data.total} {activeRelation?.label}</span><Pagination current={data.page} total={data.total} pageSize={data.pageSize} showSizeChanger={false} onChange={(next) => navigate(trail, { relation: data.relation, q: search, page: next })} /></div>}
          {view !== 'world' && (loading ? <div className="explorer-loading"><Skeleton active paragraph={{ rows: 7 }} /></div> : <div key={`${selected?.kind}:${selected?.id}:${data?.relation}:${data?.page}:${search}`} className="explorer-results-enter">
            {data?.items.length ? <div className={`explorer-results ${view === 'list' ? 'is-list' : ''}`}>{data.items.map((item, index) => <button type="button" key={`${item.kind}:${item.id}`} className="explorer-card" style={{ animationDelay: `${Math.min(index, 8) * 25}ms` }} onClick={() => open(item)} aria-label={`Open ${itemLabel(item)}: ${item.name}`}>
              <div className="explorer-card-top"><span className="explorer-card-icon">{icons[item.kind]}</span><span className="explorer-card-type">{itemLabel(item)}</span>{item.kind === 'policy' && <span className="card-inactive">{item.type}</span>}{item.active === false && <span className="card-inactive">Inactive</span>}<ArrowRightOutlined className="explorer-card-arrow" /></div>
              <div className="explorer-card-body"><h3>{item.name}</h3><code>{item.code}</code>{item.description && <p>{item.description}</p>}</div>
              <div className="explorer-card-footer"><span title={item.annotation}>{item.annotation ?? (['endpoint', 'ui'].includes(item.kind) ? item.permissionId ? 'Permission mapped' : 'No direct mapping' : item.kind === 'application' && item.tenantId !== tenantId ? 'Inherited Platform' : item.kind === 'application' ? item.type : 'Explore connections')}</span><span>{item.kind === 'rule' || item.kind === 'role' ? 'Inspect' : 'Explore'} <ArrowRightOutlined /></span></div>
            </button>)}</div> : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={search ? `No results for “${search}” in this level.` : 'No records in this relation yet.'}><Button onClick={() => search ? navigate(trail, { relation: data?.relation }) : back()}>{search ? 'Clear search' : 'Back to parent'}</Button></Empty>}
            {!!data?.total && <div className="explorer-pagination"><span>{(data.page - 1) * data.pageSize + 1}–{Math.min(data.page * data.pageSize, data.total)} of {data.total}</span><Pagination current={data.page} total={data.total} pageSize={data.pageSize} showSizeChanger={false} onChange={(next) => navigate(trail, { relation: data.relation, q: search, page: next })} /></div>}
          </div>)}
          {data?.notice && <div className="explorer-notice"><span>CONTEXT NOTE</span><p>{data.notice}</p></div>}
        </>}
      </section>
    </div>
    <div className="explorer-bottom"><span>Tenant → Platform → Domain → Module → Submodule → API / Screen</span><Link to="/evaluate">Authorization Test <ArrowRightOutlined /></Link></div>
    <Drawer open={!!inspecting} onClose={() => setInspecting(undefined)} title={inspecting ? `${explorerLabels[inspecting.kind]} details` : ''} width={480}>{inspecting && <><Tag>{inspecting.type}</Tag><h2>{inspecting.name}</h2><code>{inspecting.code}</code>{inspecting.annotation && <p>{inspecting.annotation}</p>}<pre className="explorer-expression">{inspecting.description ?? 'Open management to inspect assignments and configuration.'}</pre><Link to={managementLink(inspecting)}>Open management <ArrowRightOutlined /></Link></>}</Drawer>
    {creating && <ExplorerCreateModal kind={creating} parent={current} onClose={() => setCreating(undefined)} onCreated={(kind, id) => void created(kind, id)} />}
    {renaming && current && <ExplorerRenameModal item={current} onClose={() => setRenaming(false)} onDone={refresh} />}
    {mapping && current && <PermissionMappingModal item={current} tenantId={tenantId} onClose={() => setMapping(false)} onDone={refresh} />}
    {external && current && <ExternalDependencyModal owner={{ label: current.name, permissionId: current.kind === 'permission' ? current.id : undefined, apiId: current.kind === 'api' ? current.id : undefined, endpointId: current.kind === 'endpoint' ? current.id : undefined }} onClose={() => setExternal(false)} onDone={refresh} />}
  </div>
}
