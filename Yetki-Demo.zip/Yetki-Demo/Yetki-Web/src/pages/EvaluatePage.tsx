import { App, Button, Card, Col, Collapse, DatePicker, Flex, Form, Input, InputNumber, Row, Segmented, Select, Switch, Tabs, Typography } from 'antd'
import { ThunderboltOutlined } from '@ant-design/icons'
import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import type { Dayjs } from 'dayjs'
import { api } from '../api/client'
import type { AuthorizationDecision, AuthorizationRequest } from '../api/types'
import { useOptions } from '../hooks/useApi'
import { DecisionView } from '../components/DecisionView'
import { PageHeader } from '../components/common'
import { nextBusinessMorning } from '../components/PolicyImpact'

interface EvalForm {
  tenant?: string
  user?: string
  client?: string
  via?: string[]
  scopes?: string[]
  target: 'resource' | 'permission' | 'endpoint'
  resource?: string
  action?: string
  resourceId?: string
  permission?: string
  api?: string
  method?: string
  path?: string
  // kaydın (resource instance) özellikleri
  RecordTenant?: string
  BranchCode?: string
  CustomerId?: string
  // bağlam (context)
  IpAddress?: string
  TransactionAmount?: number
  Platform?: string
  DeviceCompliant?: boolean
  simulate?: boolean
  asOf?: Dayjs
}

/** Permission kodu → resource (katalog yolu) + action: anka.nakit.cekim.gise:create → ANKA/NAKIT/CEKIM/GISE + create */
function ra(code: string): Pick<EvalForm, 'target' | 'resource' | 'action'> {
  const [res, action] = code.split(':')
  return { target: 'resource', resource: res.split('.').join('/').toUpperCase(), action }
}

const BANK_IP = '10.1.2.3'

const presets: { group: string; items: Record<string, Partial<EvalForm>> }[] = [
  {
    group: 'Doküman örneği',
    items: {
      'Ahmet · para çekme 75.000 (PERMIT)': { tenant: 'ABANK', user: 'ahmet.kaya', client: 'nextral-desktop', ...ra('anka.nakit.cekim.gise:create'), TransactionAmount: 75000, CustomerId: 'C-555', IpAddress: BANK_IP, simulate: true },
      'Ahmet · 150.000 (limit rule)': { tenant: 'ABANK', user: 'ahmet.kaya', client: 'nextral-desktop', ...ra('anka.nakit.cekim.gise:create'), TransactionAmount: 150000, CustomerId: 'C-555', IpAddress: BANK_IP, simulate: true },
      'Ahmet · 20:00 (saat rule)': { tenant: 'ABANK', user: 'ahmet.kaya', client: 'nextral-desktop', ...ra('anka.nakit.cekim.gise:create'), TransactionAmount: 5000, CustomerId: 'C-555', IpAddress: BANK_IP, simulate: true },
      'Ahmet · şube ağı dışı (IP rule)': { tenant: 'ABANK', user: 'ahmet.kaya', client: 'nextral-desktop', ...ra('anka.nakit.cekim.gise:create'), TransactionAmount: 5000, CustomerId: 'C-555', IpAddress: '85.100.1.1', simulate: true },
      'İzindeki gişe yetkilisi (izin rule)': { tenant: 'ABANK', user: 'selin.aydin', client: 'nextral-desktop', ...ra('anka.nakit.cekim.gise:create'), TransactionAmount: 100, CustomerId: 'C-555', IpAddress: BANK_IP, simulate: true },
      'RBAC yok (policy\'ye geçilmez)': { tenant: 'ABANK', user: 'elif.sahin', client: 'nextral-desktop', ...ra('anka.nakit.cekim.gise:create'), TransactionAmount: 100, IpAddress: BANK_IP },
    },
  },
  {
    group: 'Tenant · client · resource',
    items: {
      'Başka tenant adına işlem': { tenant: 'BISTIRAK', user: 'ayse.yilmaz', client: 'nextral-desktop', ...ra('anka.nakit.cekim.gise:read'), IpAddress: BANK_IP },
      'Başka tenant\'ın kaydı': { tenant: 'ABANK', user: 'ayse.yilmaz', client: 'nextral-desktop', ...ra('anka.nakit.cekim.gise:read'), RecordTenant: 'BISTIRAK', IpAddress: BANK_IP },
      'B\'nin client\'ı · A kullanıcısı': { tenant: 'ABANK', user: 'ayse.yilmaz', client: 'b-portal-web', ...ra('anka.nakit.cekim.gise:read'), IpAddress: BANK_IP },
      'B portalı · A kullanıcısı': { tenant: 'ABANK', user: 'ali.demir', client: 'yetki-konsol', ...ra('b_portal.yatirimci.rapor.portfoy:read'), IpAddress: BANK_IP },
      'B portalı · B kullanıcısı': { tenant: 'BISTIRAK', user: 'berk.yaman', client: 'b-portal-web', ...ra('b_portal.yatirimci.rapor.portfoy:read'), IpAddress: BANK_IP, simulate: true },
      'B · üst tenant client\'ı (Nextral)': { tenant: 'BISTIRAK', user: 'berk.yaman', client: 'nextral-desktop', ...ra('anka.yatirim.fon.alim_satim:read'), IpAddress: BANK_IP, simulate: true },
      'Mobil tabletten EFT (client allowed permission)': { tenant: 'ABANK', user: 'zeynep.acar', client: 'mobil-sube-tablet', ...ra('anka.odeme.eft.giden:create'), TransactionAmount: 1000, IpAddress: '85.100.1.1', Platform: 'MOBILE' },
    },
  },
  {
    group: 'Kanal (client) · aracı · yükümlülük',
    items: {
      'Müşteri · Nextral (kanal kuralı yok)': { tenant: 'ABANK', user: 'elif.sahin', client: 'nextral-desktop', ...ra('anka.musteri.bilgi.profil:read'), BranchCode: '101', IpAddress: BANK_IP },
      'Müşteri · Mobil (saha, maske + limit)': { tenant: 'ABANK', user: 'elif.sahin', client: 'mobil-sube-tablet', ...ra('anka.musteri.bilgi.profil:read'), BranchCode: '101', IpAddress: '85.100.1.1', DeviceCompliant: true },
      'Müşteri · Mobil (cihaz uyumsuz)': { tenant: 'ABANK', user: 'elif.sahin', client: 'mobil-sube-tablet', ...ra('anka.musteri.bilgi.profil:read'), BranchCode: '101', IpAddress: '85.100.1.1', DeviceCompliant: false },
      'Çekim sorgu · Anka Web (maske)': { tenant: 'ABANK', user: 'ayse.yilmaz', client: 'anka-web', ...ra('anka.nakit.cekim.gise:read'), IpAddress: BANK_IP },
      'Nextral → gateway → Anka': { tenant: 'ABANK', user: 'ayse.yilmaz', client: 'nextral-desktop', via: ['anka-gateway'], ...ra('anka.musteri.bilgi.profil:read'), BranchCode: '101', IpAddress: BANK_IP },
      'Mobil → gateway → EFT (orijinal kanal kısıtı)': { tenant: 'ABANK', user: 'zeynep.acar', client: 'mobil-sube-tablet', via: ['anka-gateway'], ...ra('anka.odeme.eft.giden:create'), TransactionAmount: 1000, IpAddress: '85.100.1.1' },
      'Gateway client olarak (reddedilir)': { tenant: 'ABANK', user: 'zeynep.acar', client: 'anka-gateway', ...ra('anka.odeme.eft.giden:create'), TransactionAmount: 1000, IpAddress: BANK_IP },
    },
  },
  {
    group: 'RBAC · grup · veri kapsamı',
    items: {
      'Kampanya · 101 (grup)': { user: 'ayse.yilmaz', client: 'nextral-desktop', ...ra('anka.hesap.vadeli.kampanya:create'), IpAddress: BANK_IP },
      'Kampanya · 737 (grup dışı)': { user: 'deniz.koc', client: 'nextral-desktop', ...ra('anka.hesap.vadeli.kampanya:create'), IpAddress: BANK_IP },
      'Kampanya · stajyer (hariç)': { user: 'mert.kaya', client: 'nextral-desktop', ...ra('anka.hesap.vadeli.kampanya:create'), IpAddress: BANK_IP },
      'Kendi hesabı': { user: 'ayse.yilmaz', client: 'nextral-desktop', ...ra('anka.nakit.cekim.gise:create'), TransactionAmount: 100, CustomerId: 'C-1001', IpAddress: BANK_IP, simulate: true },
      'Kredi onayı 2M (şube)': { user: 'ali.demir', client: 'nextral-desktop', ...ra('anka.kredi.onay.dosya:approve'), TransactionAmount: 2000000, BranchCode: '101', IpAddress: BANK_IP },
      'Kredi onayı 2M (GM 850)': { user: 'sibel.ates', client: 'nextral-desktop', ...ra('anka.kredi.onay.dosya:approve'), TransactionAmount: 2000000, BranchCode: '737', IpAddress: BANK_IP },
      'Bölge müdürü · 737 müşterisi': { user: 'murat.aksoy', client: 'nextral-desktop', ...ra('anka.musteri.bilgi.profil:read'), BranchCode: '737', IpAddress: BANK_IP },
      'Gişe · başka şube müşterisi': { user: 'ayse.yilmaz', client: 'nextral-desktop', ...ra('anka.musteri.bilgi.profil:read'), BranchCode: '737', IpAddress: BANK_IP },
      'Mobil onboarding · uyumsuz cihaz': { user: 'elif.sahin', client: 'mobil-sube-tablet', ...ra('mobil_sube.musteri.onboarding.kimlik:create'), DeviceCompliant: false, IpAddress: '85.100.1.1' },
    },
  },
  {
    group: 'Diğer istek biçimleri',
    items: {
      'Permission kodu ile': { user: 'ayse.yilmaz', client: 'nextral-desktop', target: 'permission', permission: 'anka.nakit.cekim.gise:read', IpAddress: BANK_IP },
      'Endpoint · eşlenmemiş dekont': { user: 'ayse.yilmaz', client: 'anka-gateway', target: 'endpoint', api: 'nakit-cekim-gise-api', method: 'GET', path: '/v1/cash-withdrawals/77/receipt', IpAddress: BANK_IP },
      'Servis · gün sonu batch': { user: undefined, client: 'eod-batch', ...ra('anka.nakit.kasa.gun_sonu:execute'), IpAddress: '10.9.9.9' },
    },
  },
]

function buildRequest(v: EvalForm): AuthorizationRequest {
  const context: Record<string, string> = {}
  for (const k of ['IpAddress', 'TransactionAmount', 'Platform'] as const) {
    const val = v[k]
    if (val !== undefined && val !== null && val !== '') context[k] = String(val)
  }
  if (v.DeviceCompliant !== undefined) context.DeviceCompliant = String(v.DeviceCompliant)
  const properties: Record<string, string> = {}
  if (v.RecordTenant) properties.Tenant = v.RecordTenant
  if (v.BranchCode) properties.BranchCode = v.BranchCode
  if (v.CustomerId) properties.CustomerId = v.CustomerId
  const inferredScope = v.target === 'permission' ? v.permission
    : v.target === 'resource' && v.resource && v.action ? `${v.resource.toLowerCase().replaceAll('/', '.')}:${v.action}` : undefined
  return {
    tenant: v.tenant || undefined,
    client: v.client,
    scopes: v.scopes?.length ? v.scopes : inferredScope ? [inferredScope] : [],
    via: v.via?.length ? v.via : undefined,
    subject: { id: v.user },
    resource: v.target === 'resource' ? { type: v.resource, id: v.resourceId || undefined, properties } : Object.keys(properties).length ? { properties } : undefined,
    action: v.target === 'resource' ? v.action : undefined,
    permission: v.target === 'permission' ? v.permission : undefined,
    endpoint: v.target === 'endpoint' ? { api: v.api!, method: v.method ?? 'GET', path: v.path ?? '/' } : undefined,
    context,
  }
}

function toAuthZen(req: AuthorizationRequest) {
  let r = req
  const subject = r.subject.id ? { type: 'user', id: r.subject.id, properties: r.tenant ? { tenant: r.tenant } : undefined } : { type: 'client', id: r.client }
  r = { ...r, context: { ...r.context, ...(r.via?.length ? { via: r.via.join(',') } : {}), ...(r.scopes?.length ? { scope: r.scopes.join(' ') } : {}) } }
  if (r.endpoint)
    return { subject, action: { name: r.endpoint.method }, resource: { type: 'api_endpoint', id: r.endpoint.api, properties: { path: r.endpoint.path } }, context: { client_id: r.client, ...r.context } }
  if (r.permission) return { subject, action: { name: r.permission }, context: { client_id: r.client, ...r.context } }
  return { subject, action: { name: r.action }, resource: r.resource, context: { client_id: r.client, ...r.context } }
}

export function EvaluatePage() {
  const [params] = useSearchParams()
  const [form] = Form.useForm<EvalForm>()
  const { message } = App.useApp()
  const users = useOptions('users')
  const tenants = useOptions('tenants')
  const resources = useOptions('resources')
  const permissions = useOptions('permissions')
  const clients = useOptions('clients')
  const [result, setResult] = useState<AuthorizationDecision>()
  const [loading, setLoading] = useState(false)
  const target = Form.useWatch('target', form)
  const resource = Form.useWatch('resource', form)
  const simulate = Form.useWatch('simulate', form)
  const [request, setRequest] = useState<AuthorizationRequest>()

  // Seçili resource'un action'ları = o düğümdeki permission'lar
  const actions = useMemo(() => {
    if (!resource) return []
    const prefix = resource.toLowerCase().split('/').join('.') + ':'
    return permissions.filter((p) => p.code.startsWith(prefix)).map((p) => ({ value: p.code.slice(prefix.length), label: `${p.code.slice(prefix.length)} — ${p.label.split(' — ')[1] ?? ''}` }))
  }, [resource, permissions])

  const initial = params.get('permission')
    ? { ...ra(params.get('permission')!), user: params.get('user') ?? undefined }
    : { ...ra('anka.nakit.cekim.gise:create'), user: params.get('user') ?? 'ahmet.kaya', tenant: 'ABANK' }

  const submit = async () => {
    const v = await form.validateFields()
    const r = buildRequest(v)
    setRequest(r)
    setLoading(true)
    try {
      setResult(v.simulate
        ? await api.post<AuthorizationDecision>('/api/simulation/evaluate', { request: r, asOfUtc: v.asOf?.toISOString() })
        : await api.post<AuthorizationDecision>('/api/v1/authorize', r))
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setLoading(false)
    }
  }

  const applyPreset = (label: string, p: Partial<EvalForm>) => {
    form.resetFields()
    const hour = label.includes('20:00') ? 20 : label.startsWith('Ahmet') ? 14 : 11
    form.setFieldsValue({ tenant: undefined, via: undefined, RecordTenant: undefined, BranchCode: undefined, CustomerId: undefined, TransactionAmount: undefined, ...p,
      asOf: p.simulate ? nextBusinessMorning().hour(hour).minute(hour === 14 ? 35 : 0) : undefined })
  }

  return (
    <>
      <PageHeader title="Yetki testi"
        subtitle="Bir kullanıcının seçtiğiniz işlemi yapıp yapamayacağını kontrol edin." />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={9}>
          <Card size="small" title="Değerlendirme bilgileri">
            <Collapse size="small" style={{ marginBottom: 20 }} items={presets.map((g, i) => ({
              key: String(i), label: g.group,
              children: <Flex wrap gap={4}>{Object.entries(g.items).map(([label, p]) => <Button key={label} size="small" onClick={() => applyPreset(label, p)}>{label}</Button>)}</Flex>,
            }))} />
            <Form form={form} layout="vertical" initialValues={{ client: 'nextral-desktop', TransactionAmount: 20000, CustomerId: 'C-555', IpAddress: BANK_IP, ...initial }}>
              <Row gutter={8}>
                <Col span={8}><Form.Item name="tenant" label="Tenant" tooltip="Boşsa kullanıcının tenant'ı. Kullanıcı başka tenant adına işlem yapamaz."><Select allowClear options={tenants.map((t) => ({ value: t.code, label: t.code }))} /></Form.Item></Col>
                <Col span={16}><Form.Item name="client" label="Client (isteği yapan uygulama)"><Select allowClear showSearch optionFilterProp="label" options={clients.map((c) => ({ value: c.code, label: c.label }))} /></Form.Item></Col>
                <Col span={24}><Form.Item name="via" label="Aracı zinciri (via)" tooltip="Gateway / BFF: isteği kullanıcı adına iletir. Karar orijinal client'a göre verilir; aracı ayrıca doğrulanır (kayıtlı, aktif, bu API'yi iletmeye yetkili).">
                  <Select mode="multiple" allowClear placeholder="Doğrudan (aracı yok)" options={clients.map((c) => ({ value: c.code, label: c.label }))} />
                </Form.Item></Col>
                <Col span={24}><Form.Item name="scopes" label="Granted OAuth scopes" tooltip="Boşsa Resource + Action veya Permission seçiminden otomatik üretilir. Endpoint testinde açıkça girilmelidir.">
                  <Select mode="tags" tokenSeparators={[' ']} placeholder="anka.nakit.cekim.gise:read" options={permissions.map((p) => ({ value: p.code, label: p.code }))} />
                </Form.Item></Col>
                <Col span={24}><Form.Item name="user" label="Subject (kullanıcı)"><Select allowClear showSearch optionFilterProp="label" options={users.map((u) => ({ value: u.code, label: `${u.label} (${u.group})` }))} /></Form.Item></Col>
              </Row>
              <Form.Item name="target"><Segmented block options={[{ value: 'resource', label: 'Resource + Action' }, { value: 'permission', label: 'Permission' }, { value: 'endpoint', label: 'Endpoint' }]} /></Form.Item>
              {target === 'resource' && (
                <Row gutter={8}>
                  <Col span={16}><Form.Item name="resource" label="Resource (katalog)" rules={[{ required: true }]}>
                    <Select showSearch optionFilterProp="label" onChange={() => form.setFieldValue('action', undefined)}
                      options={resources.map((r) => ({ value: r.code, label: `${r.label} · ${r.group}` }))} />
                  </Form.Item></Col>
                  <Col span={8}><Form.Item name="action" label="Action" rules={[{ required: true }]}><Select options={actions} /></Form.Item></Col>
                </Row>
              )}
              {target === 'permission' && (
                <Form.Item name="permission" label="Permission" rules={[{ required: true }]}><Select showSearch optionFilterProp="label" options={permissions.map((p) => ({ value: p.code, label: p.label }))} /></Form.Item>
              )}
              {target === 'endpoint' && (
                <Row gutter={8}>
                  <Col span={24}><Form.Item name="api" label="API (kod veya audience)" rules={[{ required: true }]}><Input placeholder="nakit-cekim-gise-api" /></Form.Item></Col>
                  <Col span={6}><Form.Item name="method" label="Metod"><Select options={['GET', 'POST', 'PUT', 'DELETE'].map((m) => ({ value: m, label: m }))} /></Form.Item></Col>
                  <Col span={18}><Form.Item name="path" label="Path"><Input placeholder="/v1/cash-withdrawals/123" /></Form.Item></Col>
                </Row>
              )}
              <Typography.Text strong>Kayıt (resource.properties)</Typography.Text>
              <Row gutter={8}>
                <Col span={8}><Form.Item name="RecordTenant" label="Tenant" tooltip="Kaydın ait olduğu tenant; istek tenant'ıyla aynı olmalı"><Select allowClear options={tenants.map((t) => ({ value: t.code, label: t.code }))} /></Form.Item></Col>
                <Col span={8}><Form.Item name="BranchCode" label="BranchCode"><Input /></Form.Item></Col>
                <Col span={8}><Form.Item name="CustomerId" label="CustomerId"><Input /></Form.Item></Col>
              </Row>
              <Typography.Text strong>Bağlam (context)</Typography.Text>
              <Row gutter={8}>
                <Col span={12}><Form.Item name="IpAddress" label="IpAddress"><Input /></Form.Item></Col>
                <Col span={12}><Form.Item name="TransactionAmount" label="TransactionAmount"><InputNumber style={{ width: '100%' }} min={0} step={1000} /></Form.Item></Col>
                <Col span={12}><Form.Item name="Platform" label="Platform"><Select allowClear options={['BRANCH_DESKTOP', 'MOBILE', 'INTERNET'].map((c) => ({ value: c, label: c }))} /></Form.Item></Col>
                <Col span={12}><Form.Item name="DeviceCompliant" label="Cihaz uyumlu (MDM)" valuePropName="checked"><Switch /></Form.Item></Col>
              </Row>
              <Flex gap={8} align="center">
                <Form.Item name="simulate" valuePropName="checked" style={{ marginBottom: 8 }}><Switch checkedChildren="Simülasyon" unCheckedChildren="Gerçek" /></Form.Item>
                {simulate && <Form.Item name="asOf" style={{ marginBottom: 8, flex: 1 }}><DatePicker showTime placeholder="Karar anı (Time)" style={{ width: '100%' }} /></Form.Item>}
              </Flex>
              <Button type="primary" icon={<ThunderboltOutlined />} block loading={loading} onClick={submit}>Değerlendir</Button>
            </Form>
          </Card>
          {request && (
            <Card size="small" style={{ marginTop: 16 }}>
              <Tabs size="small" items={[
                { key: 'std', label: 'İstek', children: <pre style={{ fontSize: 11, margin: 0, whiteSpace: 'pre-wrap' }}>{`POST /api/v1/authorize\n${JSON.stringify(request, null, 2)}`}</pre> },
                { key: 'az', label: 'AuthZEN biçimi', children: <pre style={{ fontSize: 11, margin: 0, whiteSpace: 'pre-wrap' }}>{`POST /access/v1/evaluation\n${JSON.stringify(toAuthZen(request), null, 2)}`}</pre> },
              ]} />
            </Card>
          )}
        </Col>
        <Col xs={24} xl={15}>
          {result ? <DecisionView decision={result} /> : (
            <Card className="evaluation-empty">
              <span className="evaluation-empty-icon"><ThunderboltOutlined /></span>
              <Typography.Title level={4}>Karar sonucunu burada görün</Typography.Title>
              <Typography.Paragraph type="secondary">Bir kullanıcı ve işlem seçin ya da hazır senaryolardan başlayın. Değerlendirme sonrasında karar, gerekçesi ve uygulanan kurallar burada gösterilir.</Typography.Paragraph>
              <div className="evaluation-steps"><span>01 · Kullanıcı</span><span>02 · İşlem</span><span>03 · Değerlendirme</span></div>
            </Card>
          )}
        </Col>
      </Row>
    </>
  )
}
