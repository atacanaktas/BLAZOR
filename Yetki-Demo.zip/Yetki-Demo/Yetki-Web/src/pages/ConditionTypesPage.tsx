import { Alert, Tabs, Tag, Tooltip, Typography } from 'antd'
import { DataTable as Table } from '../components/DataTable'
import type { ConditionTypeInfo, GroupCriterionInfo, ParamDef } from '../api/types'
import { useApi } from '../hooks/useApi'
import { Code, ListError, PageHeader } from '../components/common'
import { cardMeta } from '../components/QuestionCards'

/** Koşul tipleri (policy) ve grup kriterleri: davranış C# handler'dadır, DB sadece parametre tutar. */
export function ConditionTypesPage() {
  const types = useApi<ConditionTypeInfo[]>('/api/condition-types')
  const criteria = useApi<GroupCriterionInfo[]>('/api/group-criteria')
  return (
    <>
      <PageHeader title="Koşul tipleri" subtitle="Politika ve grup kurallarında kullanılabilen koşulları inceleyin." />
      <Alert type="info" showIcon style={{ marginBottom: 12 }}
        message="İki ayrı mekanizma"
        description={<>
          <b>Grup kriteri</b> (ROLE, ORG_UNIT, TITLE...): <i>statik</i> kullanıcı özelliği → "kim üye?" (yetki verir, önceden hesaplanır).<br />
          <b>Policy koşulu</b> (TIME_WINDOW, IP_IN_RANGE, AMOUNT...): <i>istek bağlamı</i> → "şu an yapılabilir mi?" (daraltır). "Sadece kullanıcı" işaretli koşullar bağlam gerektirmez.
        </>} />
      <ListError error={types.error ?? criteria.error} onRetry={() => { types.reload(); criteria.reload() }} />
      <Tabs items={[
        {
          key: 'types', label: `Policy koşul tipleri (${types.data?.length ?? 0})`,
          children: (
            <Table size="small" rowKey="code" loading={types.loading} dataSource={types.data ?? []} pagination={false}
              columns={[
                { title: 'Kod', dataIndex: 'code', render: (_, t) => <><Code>{t.code}</Code>{!t.isAvailable && <Tag color="red">handler yok</Tag>}<br /><Typography.Text type="secondary">{t.name}</Typography.Text></> },
                { title: 'TRUE ise', dataIndex: 'description' },
                { title: 'Parametreler', render: (_, t) => (JSON.parse(t.parameterSchemaJson) as ParamDef[]).map((p) => <Tag key={p.key} title={p.description}>{p.key}{p.required ? '*' : ''}: {p.type}</Tag>) },
                { title: 'Okuduğu attribute', render: (_, t) => (t.requiredAttributes ?? '').split(',').filter(Boolean).map((a) => <Tag key={a} color={a.startsWith('Subject.') ? 'blue' : a.startsWith('Environment.') ? 'cyan' : 'orange'}>{a}</Tag>) },
                { title: 'Kart', width: 130, render: (_, t) => t.question ? <Tag color={cardMeta[t.question].color}>{cardMeta[t.question].label}</Tag> : <Typography.Text type="secondary" style={{ fontSize: 12 }}>gelişmiş</Typography.Text> },
                { title: '', render: (_, t) => <>{t.isIdentity && <Tooltip title="İstek beklemeden kesin çözülür: kimde var, SoD, RACF/LDAP"><Tag color="blue">kimlik</Tag></Tooltip>}{t.isSubjectOnly && <Tag color="purple">sadece kullanıcı</Tag>}</> },
              ]} />
          ),
        },
        {
          key: 'criteria', label: `Grup kriterleri (${criteria.data?.length ?? 0})`,
          children: (
            <Table size="small" rowKey="code" loading={criteria.loading} dataSource={criteria.data ?? []} locale={{ emptyText: 'Grup kriteri bulunamadı' }} pagination={false}
              columns={[
                { title: 'Kod', dataIndex: 'code', render: (_, c) => <><Code>{c.code}</Code><br /><Typography.Text type="secondary">{c.name}</Typography.Text></> },
                { title: 'Anlamı', dataIndex: 'description' },
                { title: 'Değer kaynağı', dataIndex: 'valueSource', render: (v) => <Tag>{v}</Tag> },
              ]} />
          ),
        },
      ]} />
    </>
  )
}
