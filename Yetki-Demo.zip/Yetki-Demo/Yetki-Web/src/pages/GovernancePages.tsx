import { Alert, App, Button, Card, Drawer, Flex, Form, Input, Modal, Select, Statistic, Switch, Table, Tabs, Tag, Typography } from 'antd'
import { PlusOutlined, ReloadOutlined, ScanOutlined, ThunderboltOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import { toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { ActiveTag, Code, DecisionTag, EnforcementTag, PageHeader, SeverityTag, fmt } from '../components/common'
import { ExternalImpactView, ExternalTag } from '../components/External'
import type { ExternalImpactResult, ExternalSystemView } from '../api/types'

// ================================ SoD ================================

interface SodRuleRow {
  id: number
  code: string
  name: string
  description?: string
  severity: string
  enforcement: string
  isActive: boolean
  openViolations: number
  members: { type: 'Permission' | 'Role'; id: number; code: string; name: string }[]
}

interface Violation {
  id: number
  userId: number
  userName: string
  fullName: string
  rule: string
  severity: string
  status: string
  detectedBy: string
  detectedAt: string
  note?: string
  details: string
}

export function SodPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const activeTab = searchParams.get('tab') === 'v' ? 'v' : 'r'
  const rules = useApi<SodRuleRow[]>('/api/sod/rules')
  const [includeResolved, setIncludeResolved] = useState(false)
  const violations = useApi<Violation[]>(`/api/sod/violations?includeResolved=${includeResolved}`)
  const { message, modal } = App.useApp()
  const navigate = useNavigate()
  const [scan, setScan] = useState<{ scannedUsers: number; violatingUsers: number; newViolations: number; stillOpen: number; autoResolved: number; durationMs: number }>()
  const [scanning, setScanning] = useState(false)
  const [editing, setEditing] = useState<SodRuleRow | 'new' | null>(null)

  const runScan = async () => {
    setScanning(true)
    try {
      setScan(await api.post('/api/sod/scan'))
      violations.reload()
      rules.reload()
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setScanning(false)
    }
  }

  const setStatus = (v: Violation, s: string) =>
    modal.confirm({
      title: `${v.userName} / ${v.rule} → ${s}`,
      content: <Input.TextArea id="violation-note" placeholder="Not (opsiyonel)" />,
      onOk: async () => {
        await api.put(`/api/sod/violations/${v.id}`, { status: s, note: (document.getElementById('violation-note') as HTMLTextAreaElement | null)?.value })
        violations.reload()
      },
    })

  return (
    <>
      <PageHeader title="SoD Controls" subtitle="Kontrol sahibi ekiplerin belirlediği Role / Permission çakışmalarını tanımlayın; ihlalleri takip edin."
        extra={<Flex gap={8}><Button icon={<ScanOutlined />} loading={scanning} onClick={runScan}>Retrospektif tarama</Button><Button type="primary" icon={<PlusOutlined />} onClick={() => setEditing('new')}>Yeni kural</Button></Flex>} />
      {scan && (
        <Card size="small" style={{ marginBottom: 16 }} title="Son tarama">
          <Flex gap={32} wrap>
            <Statistic title="Taranan" value={scan.scannedUsers} />
            <Statistic title="İhlalli kullanıcı" value={scan.violatingUsers} valueStyle={{ color: scan.violatingUsers ? '#cf1322' : undefined }} />
            <Statistic title="Yeni kayıt" value={scan.newViolations} />
            <Statistic title="Hâlâ açık" value={scan.stillOpen} />
            <Statistic title="Otomatik kapanan" value={scan.autoResolved} />
            <Statistic title="Süre (ms)" value={scan.durationMs} />
          </Flex>
        </Card>
      )}
      <Tabs activeKey={activeTab} onChange={(tab) => setSearchParams((previous) => { const next = new URLSearchParams(previous); next.set("tab", tab); return next })} items={[
        {
          key: 'v', label: 'Violations',
          children: (
            <>
              <Flex gap={8} style={{ marginBottom: 8 }}><Switch checked={includeResolved} onChange={setIncludeResolved} /> Çözülenleri de göster</Flex>
              <Table<Violation> rowKey="id" size="small" loading={violations.loading} dataSource={violations.data ?? []} pagination={{ pageSize: 15 }}
                columns={[
                  { title: 'Kullanıcı', render: (_, v) => <a onClick={() => navigate(`/users/${v.userId}`)}>{v.userName}</a> },
                  { title: 'Kural', render: (_, v) => <><Code>{v.rule}</Code> <SeverityTag severity={v.severity} /></> },
                  { title: 'Çakışma (kaynak yollarıyla)', dataIndex: 'details', render: (v) => <Typography.Text style={{ fontSize: 12 }}>{v}</Typography.Text> },
                  { title: 'Tespit', render: (_, v) => <>{v.detectedBy}<br /><Typography.Text type="secondary">{fmt(v.detectedAt)}</Typography.Text></> },
                  { title: 'Durum', render: (_, v) => <><Tag>{v.status}</Tag>{v.note && <div><Typography.Text type="secondary">{v.note}</Typography.Text></div>}</> },
                  {
                    render: (_, v) => v.status !== 'Resolved' && (
                      <Flex gap={4} wrap>
                        <Button size="small" onClick={() => setStatus(v, 'Acknowledged')}>Gördüm</Button>
                        <Button size="small" onClick={() => setStatus(v, 'AcceptedRisk')}>Risk kabul</Button>
                        <Button size="small" onClick={() => setStatus(v, 'Resolved')}>Çözüldü</Button>
                      </Flex>
                    ),
                  },
                ]} />
            </>
          ),
        },
        {
          key: 'r', label: 'Control Definitions',
          children: (
            <Table<SodRuleRow> rowKey="id" loading={rules.loading} dataSource={rules.data ?? []} pagination={false} rowClassName="clickable-row" onRow={(r) => ({ onClick: () => setEditing(r) })}
              columns={[
                { title: 'Kod', render: (_, r) => <><Code>{r.code}</Code><br /><Typography.Text type="secondary">{r.name}</Typography.Text></> },
                { title: 'Karşılıklı dışlayan üyeler', render: (_, r) => <Flex wrap gap={4}>{r.members.map((m) => <Tag key={m.type + m.id} color={m.type === 'Role' ? 'blue' : 'default'}>{m.type === 'Role' ? 'rol: ' : ''}{m.code}</Tag>)}</Flex> },
                { title: 'Önem', dataIndex: 'severity', render: (v) => <SeverityTag severity={v} /> },
                { title: 'Atama anında', dataIndex: 'enforcement', render: (v) => <EnforcementTag enforcement={v} /> },
                { title: 'Açık ihlal', dataIndex: 'openViolations', render: (v) => (v ? <Tag color="red">{v}</Tag> : 0) },
                { dataIndex: 'isActive', render: (v) => <ActiveTag active={v} /> },
              ]} />
          ),
        },
      ]} />
      {editing && <SodRuleModal rule={editing === 'new' ? undefined : editing} onClose={() => setEditing(null)} onSaved={() => { rules.reload(); violations.reload() }} />}
    </>
  )
}

function SodRuleModal({ rule, onClose, onSaved }: { rule?: SodRuleRow; onClose: () => void; onSaved: () => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const permissions = useOptions('permissions')
  const roles = useOptions('roles')
  const [preview, setPreview] = useState<{ userName: string; conflicts: { matchedMembers: { code: string }[] }[] }[]>()
  const values = () => { const v = form.getFieldsValue(); return { ...v, permissionIds: v.permissionIds ?? [], roleIds: v.roleIds ?? [] } }
  const submit = async () => {
    await form.validateFields()
    try {
      if (rule) await api.put(`/api/sod/rules/${rule.id}`, values())
      else {
        const r = await api.post<{ currentViolatingUsers: number }>('/api/sod/rules', values())
        message.success(`Oluşturuldu. Mevcut atamalarda ${r.currentViolatingUsers} kullanıcı ihlalde — retrospektif tarama ile kayda alın.`)
      }
      onSaved()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title={rule ? `SoD: ${rule.code}` : 'Yeni SoD kuralı'} onCancel={onClose} onOk={submit} width={720} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={{
        code: rule?.code, name: rule?.name, description: rule?.description, severity: rule?.severity ?? 'High', enforcement: rule?.enforcement ?? 'Block', isActive: rule?.isActive ?? true,
        permissionIds: rule?.members.filter((m) => m.type === 'Permission').map((m) => m.id) ?? [], roleIds: rule?.members.filter((m) => m.type === 'Role').map((m) => m.id) ?? [],
      }}>
        <Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input disabled={!!rule} /></Form.Item>
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Form.Item name="permissionIds" label="Permission üyeleri"><Select mode="multiple" optionFilterProp="label" options={toSelectOptions(permissions)} /></Form.Item>
        <Form.Item name="roleIds" label="Rol üyeleri"><Select mode="multiple" optionFilterProp="label" options={toSelectOptions(roles)} /></Form.Item>
        <Flex gap={16}>
          <Form.Item name="severity" label="Önem" style={{ flex: 1 }}><Select options={['Low', 'Medium', 'High', 'Critical'].map((s) => ({ value: s, label: s }))} /></Form.Item>
          <Form.Item name="enforcement" label="Atama anında" style={{ flex: 1 }}><Select options={[{ value: 'Block', label: 'Engelle' }, { value: 'Warn', label: 'Uyar, izin ver' }]} /></Form.Item>
          <Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item>
        </Flex>
        <Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item>
      </Form>
      <Button onClick={async () => { try { setPreview(await api.post('/api/simulation/sod-rule', { code: 'DRAFT', ...values() })) } catch (e) { message.error((e as Error).message) } }}>What-If: mevcutta kaç ihlal?</Button>
      {preview && <Alert style={{ marginTop: 12 }} type={preview.length ? 'warning' : 'success'} message={`${preview.length} kullanıcı ihlalde`} description={preview.map((u) => <div key={u.userName}>{u.userName}: {u.conflicts[0]?.matchedMembers.map((m) => m.code).join(' + ')}</div>)} />}
    </Modal>
  )
}

// ================================ Dış sistemler ================================

export function ExternalPage() {
  const systems = useApi<ExternalSystemView[]>('/api/external/systems')
  const drift = useApi<{ checkedUsers: number; driftedUsers: number; users: { userId: number; userName: string; grants: number; modifies: number; revokes: number }[] }>('/api/external/drift')
  const { message, modal } = App.useApp()
  const navigate = useNavigate()
  const [newPerm, setNewPerm] = useState<ExternalSystemView>()
  const [newSystem, setNewSystem] = useState(false)
  const [chainFor, setChainFor] = useState<{ system: ExternalSystemView; perm: ExternalSystemView['permissions'][number] }>()
  const [busy, setBusy] = useState(false)
  const reload = () => { systems.reload(); drift.reload() }
  const allPerms = (systems.data ?? []).flatMap((s) => s.permissions.map((p) => ({ value: p.id, label: `${s.code}:${p.code}${p.resourceClass ? ` (${p.resourceClass})` : ''} — ${p.name ?? ''}` })))

  const removeChain = async (fromId: number, toId: number, label: string) => {
    try {
      const preview = await api.del<ExternalImpactResult>(`/api/external/permissions/${fromId}/requires/${toId}?dryRun=true`)
      modal.confirm({
        width: 820, title: `${label} zincirini kaldır`, content: <ExternalImpactView impact={preview} />, okText: 'Kaldır', okButtonProps: { danger: true },
        onOk: async () => { await api.del(`/api/external/permissions/${fromId}/requires/${toId}`); message.success('Zincir kaldırıldı'); reload() },
      })
    } catch (e) { message.error((e as Error).message) }
  }

  return (
    <>
      <PageHeader title="Dış sistemler"
        subtitle="RACF ve LDAP yetkilerini, bağımlılıklarını ve eşitleme durumlarını yönetin."
        extra={<Flex gap={8}>
          <Button icon={<PlusOutlined />} onClick={() => setNewSystem(true)}>Dış sistem</Button>
        </Flex>} />
      <Alert type="info" showIcon style={{ marginBottom: 16 }}
        message="Bağımlılık nerede tanımlanır? Bilginin doğduğu yerde — katalogda (API paneli / permission detayı)."
        description={<>
          <div><b>API</b> → tüm endpoint'leri (ör. CICS bölgesi APPL profili) · <b>Endpoint</b> → sadece o endpoint (ör. GET /v1/customers/{'{id}'} → MUS1, HSP1) · <b>Permission</b> → endpoint'i olmayan işlemler (ör. Nextral ekranı → LDAP grubu).</div>
          <div><b>Zincir</b>: bir dış yetki başka bir dış yetkiyi gerektirebilir (MUS1 transaction'ı BNK.MUSTERI.MASTER dataset'ini okur). <b>Seviye</b>: verilmezse action'dan (read → READ, create/update → UPDATE); aynı dış yetki birden fazla yerden gelirse en yüksek seviye.</div>
          <div><b>Provisioning = mutabakat</b>: olması gereken − dış sistemde açık olan → GRANT / MODIFY / REVOKE. Başka bir yetki yüzünden hâlâ gereken dış yetki geri alınmaz.</div>
        </>} />

      <Card size="small" style={{ marginBottom: 16 }} title="Mutabakat (drift)"
        extra={<Flex gap={8}>
          <Button size="small" icon={<ReloadOutlined />} onClick={reload}>Yenile</Button>
          <Button size="small" type="primary" disabled={!drift.data?.driftedUsers} loading={busy} onClick={async () => {
            setBusy(true)
            try { const r = await api.post<{ actions: number }>('/api/external/reconcile'); message.success(`${r.actions} provisioning aksiyonu çalıştı`); reload() }
            catch (e) { message.error((e as Error).message) } finally { setBusy(false) }
          }}>Tümünü mutabakat yap</Button>
          <Button size="small" danger onClick={() => modal.confirm({
            title: 'Baseline al', okText: 'Baseline al', okButtonProps: { danger: true },
            content: 'Dış sistemdeki mevcut durumun olması gerekenle AYNI olduğu kabul edilir; RACF/LDAP\'a komut gönderilmez. İlk kurulumda veya RACF\'ten durum içe aktarıldıktan sonra kullanın.',
            onOk: async () => { await api.post('/api/external/baseline'); message.success('Baseline alındı'); reload() },
          })}>Baseline al</Button>
        </Flex>}>
        {drift.data && (drift.data.driftedUsers === 0
          ? <Alert type="success" showIcon message={`${drift.data.checkedUsers} kullanıcının hepsi senkron: olması gereken = dış sistemde açık olan.`} />
          : <Table size="small" rowKey="userId" dataSource={drift.data.users} pagination={{ pageSize: 10 }}
              title={() => <Typography.Text type="warning">{drift.data!.driftedUsers} / {drift.data!.checkedUsers} kullanıcıda fark var</Typography.Text>}
              rowClassName="clickable-row" onRow={(u) => ({ onClick: () => navigate(`/users/${u.userId}`) })}
              columns={[
                { title: 'Kullanıcı', dataIndex: 'userName' },
                { title: 'Açılacak', dataIndex: 'grants', render: (v) => v ? <Tag color="green">{v}</Tag> : '—' },
                { title: 'Seviye değişecek', dataIndex: 'modifies', render: (v) => v ? <Tag color="gold">{v}</Tag> : '—' },
                { title: 'Kapanacak', dataIndex: 'revokes', render: (v) => v ? <Tag color="volcano">{v}</Tag> : '—' },
              ]} />)}
      </Card>

      <Flex vertical gap={16}>
        {(systems.data ?? []).map((s) => (
          <Card key={s.id} size="small" loading={systems.loading}
            title={<><Tag color={s.code === 'RACF' ? 'geekblue' : 'purple'}>{s.code}</Tag>{s.name} {s.hasAccessLevels ? <Tag>seviye: READ / UPDATE / CONTROL / ALTER</Tag> : <Tag>sadece üyelik</Tag>}</>}
            extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setNewPerm(s)}>Dış yetki</Button>}>
            <Table size="small" rowKey="id" pagination={false} dataSource={s.permissions}
              columns={[
                { title: 'Dış yetki', render: (_, p) => <><ExternalTag system={s.code} code={p.code} resourceClass={p.resourceClass} /><br /><Typography.Text type="secondary" style={{ fontSize: 12 }}>{p.name}</Typography.Text></>, width: 280 },
                {
                  title: 'Zincir: gerektirdikleri',
                  render: (_, p) => (
                    <Flex wrap gap={2} align="center">
                      {p.requires.map((r) => <Tag key={r.id} closable onClose={(e) => { e.preventDefault(); removeChain(p.id, r.id, `${s.code}:${p.code} → ${r.key}`) }}>→ {r.key}{r.level ? ` (${r.level.toUpperCase()})` : ''}</Tag>)}
                      <Button size="small" type="dashed" icon={<PlusOutlined />} onClick={() => setChainFor({ system: s, perm: p })} />
                    </Flex>
                  ),
                },
                { title: 'Gerektiren', dataIndex: 'requiredBy', render: (v: string[]) => v.map((x) => <Tag key={x}>{x} →</Tag>) },
                { title: 'Katalog bağımlılığı', dataIndex: 'dependencyCount', width: 110 },
                { title: 'Açık olduğu kullanıcı', dataIndex: 'userCount', width: 110 },
              ]} />
          </Card>
        ))}
      </Flex>

      {newSystem && <SimpleFormModal title="Yeni dış sistem" url="/api/external/systems" onClose={() => setNewSystem(false)} onDone={reload}
        fields={[
          { name: 'code', label: 'Kod', required: true, placeholder: 'RACF2' },
          { name: 'name', label: 'Ad', required: true },
          { name: 'description', label: 'Açıklama' },
          { name: 'hasAccessLevels', label: 'Erişim seviyesi var (RACF gibi)', type: 'switch' },
        ]} />}
      {newPerm && <SimpleFormModal title={`${newPerm.code} → yeni dış yetki`} url="/api/external/permissions" extra={{ externalSystemId: newPerm.id }} onClose={() => setNewPerm(undefined)} onDone={reload}
        fields={[
          { name: 'code', label: 'Kod (profil / transaction / dataset / grup)', required: true, placeholder: newPerm.code === 'RACF' ? 'MUS3 veya BNK.MUSTERI.ADRES' : 'CN=NEXTRAL_RAPOR' },
          { name: 'resourceClass', label: 'Sınıf', type: 'select', options: newPerm.code === 'RACF' ? ['TCICSTRN', 'DATASET', 'APPL', 'FACILITY'] : ['GROUP'] },
          { name: 'name', label: 'Ad' },
          { name: 'description', label: 'Açıklama' },
        ]} />}
      {chainFor && <ChainModal from={chainFor} options={allPerms.filter((o) => o.value !== chainFor.perm.id)} onClose={() => setChainFor(undefined)} onDone={reload} />}
    </>
  )
}

/** Zincir ekle: önce etki (dryRun), sonra uygula. */
function ChainModal({ from, options, onClose, onDone }: {
  from: { system: ExternalSystemView; perm: ExternalSystemView['permissions'][number] }
  options: { value: number; label: string }[]
  onClose: () => void
  onDone: () => void
}) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const [impact, setImpact] = useState<ExternalImpactResult>()
  const run = async (dryRun: boolean) => {
    try {
      const r = await api.post<ExternalImpactResult>(`/api/external/permissions/${from.perm.id}/requires?dryRun=${dryRun}`, await form.validateFields())
      if (dryRun) setImpact(r)
      else { message.success(r.summary); onDone(); onClose() }
    } catch (e) { message.error((e as Error).message) }
  }
  return (
    <Modal open width={820} title={`${from.system.code}:${from.perm.code} → gerektirdiği dış yetki`} onCancel={onClose} destroyOnHidden
      footer={<Flex gap={8} justify="end"><Button onClick={onClose}>Vazgeç</Button><Button onClick={() => run(true)}>Etkiyi gör</Button><Button type="primary" disabled={!impact} onClick={() => run(false)}>Uygula</Button></Flex>}>
      <Form form={form} layout="vertical" onValuesChange={() => setImpact(undefined)}>
        <Form.Item name="requiredExternalPermissionId" label="Gerektirdiği dış yetki" rules={[{ required: true }]}><Select showSearch optionFilterProp="label" options={options} /></Form.Item>
        <Form.Item name="accessLevel" label="Seviye" extra="Boş: bağımlı olan yetkinin seviyesiyle aynı (ör. MUS2 UPDATE ise dataset'e UPDATE)">
          <Select allowClear placeholder="Üst ile aynı" options={['Read', 'Update', 'Control', 'Alter'].map((l) => ({ value: l, label: l.toUpperCase() }))} />
        </Form.Item>
      </Form>
      {impact && <ExternalImpactView impact={impact} />}
    </Modal>
  )
}

type SimpleField = { name: string; label: string; required?: boolean; placeholder?: string; type?: 'switch' | 'select'; options?: string[] }

function SimpleFormModal({ title, url, fields, extra, onClose, onDone }: {
  title: string; url: string; fields: SimpleField[]; extra?: object; onClose: () => void; onDone: () => void
}) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  return (
    <Modal open title={title} okText="Oluştur" onCancel={onClose} destroyOnHidden
      onOk={async () => { try { await api.post(url, { ...(await form.validateFields()), ...extra }); message.success('Oluşturuldu'); onDone(); onClose() } catch (e) { message.error((e as Error).message) } }}>
      <Form form={form} layout="vertical">
        {fields.map((f) => (
          <Form.Item key={f.name} name={f.name} label={f.label} rules={f.required ? [{ required: true }] : undefined} valuePropName={f.type === 'switch' ? 'checked' : undefined}>
            {f.type === 'switch' ? <Switch /> : f.type === 'select' ? <Select allowClear options={f.options!.map((o) => ({ value: o, label: o }))} /> : <Input placeholder={f.placeholder} />}
          </Form.Item>
        ))}
      </Form>
    </Modal>
  )
}

// ================================ Event & provisioning ================================

export function EventsPage() {
  const { message } = App.useApp()
  const events = useApi<{ id: string; eventType: string; aggregateType?: string; aggregateId?: string; payloadJson: string; occurredAt: string; actor: string; status: string; processedAt?: string; error?: string }[]>('/api/events?take=300')
  const prov = useApi<{ id: number; userName: string; permissionCode: string; externalSystemCode: string; externalPermissionCode: string; resourceClass?: string; actionType: string; accessLevel?: string; previousAccessLevel?: string; status: string; resultMessage?: string; createdAt: string }[]>('/api/provisioning')
  const reload = () => { events.reload(); prov.reload() }
  return (
    <>
      <PageHeader title="Olaylar ve aktarım" subtitle="Yetki değişikliklerinden doğan olayları ve dış sistem aktarımlarını takip edin."
        extra={<Flex gap={8}><Button icon={<ReloadOutlined />} onClick={reload}>Yenile</Button>
          <Button icon={<ThunderboltOutlined />} onClick={async () => { const r = await api.post<{ processed: number }>('/api/events/process'); message.info(`${r.processed} event işlendi`); reload() }}>Outbox'ı şimdi işlet</Button></Flex>} />
      <Tabs items={[
        {
          key: 'p', label: 'Provisioning aksiyonları',
          children: (
            <Table rowKey="id" size="small" loading={prov.loading} dataSource={prov.data ?? []} pagination={{ pageSize: 20 }}
              columns={[
                { title: 'Zaman', dataIndex: 'createdAt', render: fmt, width: 150 },
                { title: 'Kullanıcı', dataIndex: 'userName' },
                { title: 'Aksiyon', dataIndex: 'actionType', render: (v) => <Tag color={v === 'Grant' ? 'green' : v === 'Modify' ? 'gold' : 'volcano'}>{v}</Tag>, width: 90 },
                { title: 'Dış yetki', render: (_, a) => <ExternalTag system={a.externalSystemCode} code={a.externalPermissionCode} resourceClass={a.resourceClass} level={a.actionType === 'Revoke' ? undefined : a.accessLevel} previousLevel={a.actionType === 'Modify' ? a.previousAccessLevel : undefined} /> },
                { title: 'Neden', dataIndex: 'permissionCode', render: (v: string) => v.split(' | ').map((r, i) => <div key={i} style={{ fontSize: 12 }}>{r}</div>) },
                { title: 'Durum', dataIndex: 'status', render: (v) => <Tag color={v === 'Completed' ? 'green' : v === 'Failed' ? 'red' : 'default'}>{v}</Tag> },
                { title: 'Adaptör sonucu', dataIndex: 'resultMessage', render: (v) => <Typography.Text style={{ fontSize: 12 }}>{v}</Typography.Text> },
              ]} />
          ),
        },
        {
          key: 'e', label: 'Outbox event\'leri',
          children: (
            <Table rowKey="id" size="small" loading={events.loading} dataSource={events.data ?? []} pagination={{ pageSize: 20 }}
              expandable={{ expandedRowRender: (e) => <pre style={{ margin: 0, fontSize: 12, whiteSpace: 'pre-wrap' }}>{JSON.stringify(JSON.parse(e.payloadJson), null, 2)}</pre> }}
              columns={[
                { title: 'Zaman', dataIndex: 'occurredAt', render: fmt, width: 150 },
                { title: 'Event', dataIndex: 'eventType', render: (v) => <Tag color={v === 'EffectivePermissionsChanged' ? 'purple' : 'blue'}>{v}</Tag> },
                { title: 'Aggregate', render: (_, e) => `${e.aggregateType ?? ''}:${e.aggregateId ?? ''}` },
                { title: 'Kim', dataIndex: 'actor' },
                { title: 'Durum', dataIndex: 'status', render: (v, e) => <><Tag color={v === 'Processed' ? 'green' : v === 'Failed' ? 'red' : 'gold'}>{v}</Tag>{e.error}</> },
              ]} />
          ),
        },
      ]} />
    </>
  )
}

// ================================ Audit ================================

interface AuditRow { id: string; timestamp: string; category: string; actor: string; action: string; subjectUserName?: string; clientId?: string; permissionCode?: string; decision?: string; reasonCode?: string; summary?: string }

const categoryColor: Record<string, string> = { AuthorizationDecision: 'blue', Management: 'green', Simulation: 'purple', SodScan: 'red' }

export function AuditPage() {
  const [category, setCategory] = useState<string>()
  const [user, setUser] = useState('')
  const [permission, setPermission] = useState('')
  const [q, setQ] = useState('')
  const params = new URLSearchParams({ take: '300' })
  if (category) params.set('category', category)
  if (user) params.set('user', user)
  if (permission) params.set('permission', permission)
  if (q) params.set('q', q)
  const { data, loading } = useApi<AuditRow[]>(`/api/audit?${params.toString()}`)
  const [detail, setDetail] = useState<{ id: string; summary?: string; detailsJson?: string }>()
  return (
    <>
      <PageHeader title="Denetim kayıtları" subtitle="Yetki kararlarını ve yönetim işlemlerini zaman sırasıyla inceleyin." />
      <Flex gap={8} wrap style={{ marginBottom: 12 }}>
        <Select allowClear placeholder="Kategori" value={category} onChange={setCategory} style={{ width: 200 }} options={Object.keys(categoryColor).map((c) => ({ value: c, label: c }))} />
        <Input.Search placeholder="Kullanıcı / aktör" allowClear onSearch={setUser} style={{ width: 200 }} />
        <Input.Search placeholder="Permission kodu" allowClear onSearch={setPermission} style={{ width: 280 }} />
        <Input.Search placeholder="Metin ara" allowClear onSearch={setQ} style={{ width: 220 }} />
      </Flex>
      <Table<AuditRow> rowKey="id" size="small" loading={loading} dataSource={data ?? []} pagination={{ pageSize: 25 }} rowClassName="clickable-row"
        onRow={(r) => ({ onClick: () => api.get<{ id: string; summary?: string; detailsJson?: string }>(`/api/audit/${r.id}`).then(setDetail) })}
        columns={[
          { title: 'Zaman', dataIndex: 'timestamp', render: fmt, width: 150 },
          { title: 'Kategori', dataIndex: 'category', render: (v) => <Tag color={categoryColor[v]}>{v}</Tag> },
          { title: 'Aktör', dataIndex: 'actor' },
          { title: 'Kullanıcı / client', render: (_, r) => <>{r.subjectUserName}{r.clientId && <><br /><Typography.Text type="secondary">{r.clientId}</Typography.Text></>}</> },
          { title: 'Permission', dataIndex: 'permissionCode', render: (v) => v && <Code>{v}</Code> },
          { title: 'Karar', dataIndex: 'decision', render: (v, r) => v && <><DecisionTag decision={v} /><br /><Typography.Text style={{ fontSize: 11 }}>{r.reasonCode}</Typography.Text></> },
          { title: 'Özet', dataIndex: 'summary', render: (v) => <Typography.Text style={{ fontSize: 12 }}>{v}</Typography.Text> },
        ]} />
      <Drawer open={!!detail} onClose={() => setDetail(undefined)} title="Audit detayı" size="large">
        {detail && (
          <>
            <Typography.Paragraph copyable={{ text: detail.id }}>ID: {detail.id}</Typography.Paragraph>
            <Typography.Paragraph>{detail.summary}</Typography.Paragraph>
            <pre style={{ fontSize: 12, whiteSpace: 'pre-wrap' }}>{detail.detailsJson ? JSON.stringify(JSON.parse(detail.detailsJson), null, 2) : '—'}</pre>
          </>
        )}
      </Drawer>
    </>
  )
}
