import { useEffect, useMemo, useRef, useState } from 'react'
import { Alert, Button, Dropdown, Input, Modal, Pagination, Tag } from 'antd'
import { AimOutlined, ExpandOutlined, MinusOutlined, PlusOutlined, SearchOutlined } from '@ant-design/icons'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import { WorldObject } from '../features/structure/WorldObjects'
import { createKinds, managementLink, type ExplorerItem, type ExplorerKind, type ExplorerPage } from '../features/structure/explorer'
import { ExplorerCreateModal, ExplorerRenameModal, PermissionMappingModal } from '../features/structure/ExplorerForms'
import '../features/structure/city-v3.css'

type Item = Omit<ExplorerItem, 'kind'> & { kind: ExplorerKind | 'group' | 'workspace' }
type Collection = { relation: string; count: number; owner: Item }
type Node = { key: string; parent?: string; item: Item; tenantId?: number; collection?: Collection; children: string[]; open: boolean; loaded: boolean; loading?: boolean; error?: string; page?: number; total?: number; reference?: boolean; edge: string }
type FlowPage = { total: number; page: number; roleCount?: number; groupCount?: number; items: (Item & { permission?: Item })[] }
const kinds: Record<string, Item['kind']> = { tenants:'tenant', platforms:'application', resources:'resource', users:'user', clients:'client', permissions:'permission', roles:'role', groups:'group', policies:'policy', excluded:'policy', rules:'rule', endpoints:'endpoint', apis:'api', ui:'ui', external:'externalPermission' }
const home: Item = { kind:'workspace', id:0, code:'WORKSPACE', name:'Access City', type:'Workspace' }
const root: Node = { key:'root', item:home, children:[], open:true, loaded:false, edge:'' }
const short = (s:string,n=24) => s.length > n ? s.slice(0,n-1)+'…' : s
const manage = (item:Item) => item.kind === 'group' ? `/groups/${item.id}` : item.kind === 'workspace' ? '/tenants' : managementLink(item as ExplorerItem)
const pathUrl = (item:Item,tenantId?:number) => `/api/structure/explore?kind=${item.kind === 'workspace' ? 'root' : item.kind}&id=${item.id}${tenantId ? `&tenantId=${tenantId}`:''}`
async function records(node:Node,page=1,q='') {
  const owner = node.collection?.owner ?? node.item
  const relation = node.collection?.relation ?? 'tenants'
  if (['user','role','group'].includes(owner.kind)) {
    const data = await api.get<FlowPage>(`/api/structure/flow/${owner.kind}/${owner.id}?relation=${relation}&page=${page}&q=${encodeURIComponent(q)}`)
    return { ...data, items:data.items.map(x => ({ ...(x.permission ?? x), type:(x.permission ?? x).type ?? (x.permission ? 'Permission' : x.kind) })) }
  }
  return api.get<ExplorerPage>(`${pathUrl(owner,node.tenantId)}&relation=${relation}&pageSize=3&page=${page}&q=${encodeURIComponent(q)}`)
}
function layout(nodes:Record<string,Node>) {
  const positions:Record<string,{x:number;y:number}> = {}; let row=0
  const visit=(key:string,depth:number) => { const node=nodes[key]; if(!node)return; const children=node.open?node.children.filter(k=>nodes[k]):[]; const start=row; for(const child of children)visit(child,depth+1); if(!children.length)row++; positions[key]={x:140+depth*275,y:145+((start+row-1)/2)*205} }
  visit('root',0); return positions
}
export function StructureCityV3Page() {
  const [nodes,setNodes]=useState<Record<string,Node>>({root})
  const [autoFit,setAutoFit]=useState(true)
  const [pan,setPan]=useState({x:10,y:40}); const [zoom,setZoom]=useState(.85)
  const [motion,setMotion]=useState(()=>!matchMedia('(prefers-reduced-motion: reduce)').matches)
  const [detail,setDetail]=useState<Node>(); const [creating,setCreating]=useState<ExplorerKind>(); const [renaming,setRenaming]=useState(false); const [mapping,setMapping]=useState(false)
  const [searchNode,setSearchNode]=useState<Node>(); const [globalKind,setGlobalKind]=useState('user'); const [globalSearch,setGlobalSearch]=useState(false)
  const [q,setQ]=useState('');const [page,setPage]=useState(1);const [results,setResults]=useState<{items:Item[];total:number;page:number}>();const [searchError,setSearchError]=useState('')
  const shell=useRef<HTMLDivElement>(null);const drag=useRef<{x:number;y:number;px:number;py:number} | undefined>(undefined);
  const positions=useMemo(()=>layout(nodes),[nodes])
  useEffect(()=>{if(!autoFit)return;const frame=requestAnimationFrame(()=>{const values=Object.values(positions);const z=Math.min(1,1060/(Math.max(...values.map(p=>p.x))+140),610/(Math.max(...values.map(p=>p.y))+110));setZoom(z);setPan({x:20,y:20})});return()=>cancelAnimationFrame(frame)},[positions,autoFit])
  const attach=(parentKey:string,items:Item[],edge:string,extra:Partial<Node>={})=>{
    setNodes(previous=>{const parent=previous[parentKey];if(!parent)return previous; const next={...previous};const keys=[...parent.children]
      for(const item of items){const key=`${parentKey}/${item.kind}:${item.id}`;if(!keys.includes(key))keys.push(key);if(!next[key]){let ancestor:Node|undefined=parent;let reference=false;while(ancestor){if(!ancestor.collection&&ancestor.item.kind===item.kind&&ancestor.item.id===item.id)reference=true;ancestor=ancestor.parent?previous[ancestor.parent]:undefined}next[key]={key,parent:parentKey,item,tenantId:item.kind==='tenant'?item.id:parent.tenantId??item.tenantId,children:[],open:false,loaded:false,edge,reference}}}
      next[parentKey]={...parent,...extra,children:keys,open:true,loaded:true,loading:false,error:undefined};return next})
  }
  const expand=async(node:Node,nextPage=1)=>{
    if(node.loading)return
    if(node.reference||(!node.collection&&node.item.kind==='rule')){setDetail(node);return}
    if(node.loaded&&nextPage===1){setNodes(p=>({...p,[node.key]:{...p[node.key],open:true}}));return}
    setNodes(p=>({...p,[node.key]:{...p[node.key],loading:true,error:undefined}}))
    try{
      if(node.collection||node.item.kind==='workspace'){
        const data=await records(node,nextPage);attach(node.key,data.items,node.collection?.relation==='permissions'?'grants / resolves':'contains',{page:data.page,total:data.total});return
      }
      let relations:ExplorerPage['relations'];let current:Item=node.item
      if(['user','role','group'].includes(node.item.kind)){
        const data=await api.get<FlowPage>(`/api/structure/flow/${node.item.kind}/${node.item.id}`)
        relations=[...(node.item.kind==='user'?[{key:'roles',label:'Effective Roles',count:data.roleCount??0},{key:'groups',label:'Effective Groups',count:data.groupCount??0}]:[]),{key:'permissions',label:node.item.kind==='user'?'Effective Permissions':'Assigned Permissions',count:data.total}]
      }else{const data=await api.get<ExplorerPage>(`${pathUrl(node.item,node.tenantId)}&pageSize=1`);relations=data.relations;current=data.current??current}
      setNodes(previous=>{const next={...previous};const keys:string[]=[];for(const r of relations){const key=`${node.key}/relation:${r.key}`;keys.push(key);next[key]=previous[key]??{key,parent:node.key,item:{kind:kinds[r.key]??'resource',id:0,name:r.label,code:`${r.count.toLocaleString()} records`,type:'Collection'},tenantId:node.tenantId,collection:{relation:r.key,count:r.count,owner:current},children:[],loaded:false,open:false,edge:r.key==='policies'?'constrained by':r.key==='rules'?'evaluates':r.key==='permissions'?'grants / requires':'contains / relates'}}for(const r of relations){const k=`${node.key}/relation:${r.key}`;next[k]={...next[k],item:{...next[k].item,name:r.label,code:`${r.count.toLocaleString()} records`},collection:{relation:r.key,count:r.count,owner:current}}}next[node.key]={...previous[node.key],item:current,children:keys,open:true,loaded:true,loading:false};return next})
    }catch(e){setNodes(p=>({...p,[node.key]:{...p[node.key],loading:false,error:(e as Error).message}}))}
  }
  useEffect(()=>{const timer=setTimeout(()=>void expand(root),0);return()=>clearTimeout(timer)},[]) // Start with bounded Tenant landmarks only.
  useEffect(()=>{
    if(!searchNode&&!globalSearch)return;let active=true;void Promise.resolve().then(()=>{if(active){setResults(undefined);setSearchError('')}})
    const promise=searchNode?records(searchNode,page,q):api.get<{items:Item[];total:number;page:number}>(`/api/structure/flow/search?kind=${globalKind}&page=${page}&q=${encodeURIComponent(q)}`)
    promise.then(data=>{if(active)setResults(data)}).catch(e=>{if(active)setSearchError(e.message)});return()=>{active=false}
  },[searchNode,globalSearch,globalKind,page,q])
  const search=(node?:Node)=>{if(document.fullscreenElement)void document.exitFullscreen();setSearchNode(node);setGlobalSearch(!node);setQ('');setPage(1)}
  const fit=()=>{setAutoFit(true);const values=Object.values(positions);const maxX=Math.max(...values.map(p=>p.x))+140;const maxY=Math.max(...values.map(p=>p.y))+110;const z=Math.min(1,1060/maxX,610/maxY);setZoom(z);setPan({x:20,y:20})}
  const reload=()=>{if(detail){const node=nodes[detail.key];if(node)void expand({...node,loaded:false})}}
  const inspect=(node:Node)=>{if(document.fullscreenElement)void document.exitFullscreen();setDetail(node)}
  const menus=(node:Node)=>[
    {key:'expand',label:node.reference?'Reference details':'Expand connections',onClick:()=>void expand(node)},
    ...(node.open?[{key:'collapse',label:'Collapse branch',onClick:()=>setNodes(p=>({...p,[node.key]:{...p[node.key],open:false}}))}]:[]),
    ...(node.collection?[{key:'search',label:`Search ${node.item.name}`,onClick:()=>search(node)}]:[{key:'details',label:'Details & actions',onClick:()=>inspect(node)}]),
    ...(!node.collection&&!['user','role','group','rule'].includes(node.item.kind)?createKinds(node.item.kind==='workspace'?undefined:node.item as ExplorerItem).map(kind=>({key:kind,label:`Add ${kind}`,onClick:()=>{inspect(node);setCreating(kind)}})):[]),
    ...(!node.collection?[{key:'manage',label:<Link to={manage(node.item)}>Open management</Link>}]:[]),
  ]
  return <div className="city-v3"><header className="v3-header"><div><small>ACCESS CITY / V3</small><h1>Keep the whole picture.</h1><p>Open a landmark. Grow its branch. Keep every connection in sight.</p></div><Button icon={<SearchOutlined />} onClick={()=>search()}>Find User / Role / Permission</Button></header>
    <div className="v3-checks"><b>Request checks →</b>{['Subject','Tenant','Client & Scope','Resource + Action','RBAC: Role / Group / Direct','Policy → Rules','Decision'].map((step,i)=><span key={step}>{i+1}. {step}{i<6?' →':''}</span>)}</div>
    <p className="v3-caption">Solid blue arrows: Permission / Policy relations. Grey arrows: catalog structure. Roles, Groups and direct grants are alternative RBAC sources. This map does not evaluate a live request.</p>
    <div className={`v3-shell ${motion?'v3-motion':''}`} ref={shell}>
      <div className="v3-controls"><strong>CONNECTED CAMPUS</strong><Button aria-label="Zoom out" icon={<MinusOutlined />} onClick={()=>{setAutoFit(false);setZoom(z=>Math.max(.08,z-.1))}}/><span>{Math.round(zoom*100)}%</span><Button aria-label="Zoom in" icon={<PlusOutlined />} onClick={()=>{setAutoFit(false);setZoom(z=>Math.min(2,z+.1))}}/><Button icon={<AimOutlined />} onClick={fit}>Fit all</Button><Button aria-label="Fullscreen" icon={<ExpandOutlined />} onClick={()=>{if(document.fullscreenElement)void document.exitFullscreen();else void shell.current?.requestFullscreen().catch(()=>{})}}/><label><input type="checkbox" checked={motion} onChange={e=>setMotion(e.target.checked)}/> Motion</label></div>
      <svg className="v3-map" viewBox="0 0 1100 680" aria-label="Expandable architecture city" onPointerDown={e=>{if(e.button!==0||!e.currentTarget.contains(e.target as Element)||(e.target as Element).closest('[data-city-node]'))return;setAutoFit(false);drag.current={x:e.clientX,y:e.clientY,px:pan.x,py:pan.y};e.currentTarget.setPointerCapture(e.pointerId)}} onPointerMove={e=>{if(!drag.current)return;const r=e.currentTarget.getBoundingClientRect();const ratio=Math.min(r.width/1100,r.height/680);setPan({x:drag.current.px+(e.clientX-drag.current.x)/ratio,y:drag.current.py+(e.clientY-drag.current.y)/ratio})}} onPointerUp={()=>{drag.current=undefined}} onPointerCancel={()=>{drag.current=undefined}}>
        <defs><pattern id="v3-grid" width="90" height="45" patternUnits="userSpaceOnUse"><path d="M0 22L45 0L90 22L45 45Z" stroke="#d6e1e9" strokeWidth=".6" fill="none"/></pattern><marker id="v3-arrow" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0 0L7 3L0 6" fill="none" stroke="#005092" strokeWidth="1.2"/></marker></defs>
        <rect width="1100" height="680" fill="url(#v3-grid)"/>
        <g transform={`translate(${pan.x} ${pan.y}) scale(${zoom})`}>
          {Object.entries(positions).map(([key,to])=>{const n=nodes[key];const from=n.parent?positions[n.parent]:undefined;if(!from)return null;const strong=['permission','policy','rule'].includes(n.item.kind);return <g key={`edge:${key}`}><path className={strong?'v3-edge v3-access':'v3-edge'} d={`M${from.x+94} ${from.y+30}C${from.x+165} ${from.y+30},${to.x-165} ${to.y+30},${to.x-108} ${to.y+30}`} markerEnd="url(#v3-arrow)"/><text x={(from.x+to.x)/2} y={(from.y+to.y)/2+17} className="v3-edge-label" textAnchor="middle">{n.edge}</text></g>})}
          {Object.entries(positions).map(([key,p])=>{const node=nodes[key];return <g key={key} transform={`translate(${p.x} ${p.y})`} data-city-node={key}>
            <Dropdown trigger={['contextMenu']} menu={{items:menus(node)}}><g role="button" tabIndex={0} aria-label={`Expand ${node.item.code}`} aria-expanded={node.open} className="v3-landmark" onClick={()=>void expand(node)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();void expand(node)}}}>
              <title>{node.item.name} · {node.item.code}</title><ellipse rx="76" ry="29" fill={node.collection?'#dce8ef':'#e6edf2'}/><WorldObject kind={node.item.kind==='group'?'user':node.item.kind} type={node.item.type} scale={node.collection ? .48 : .65}/><rect x="-104" y="32" width="208" height="57" rx="10" fill={node.collection?'#eaf2f7':'white'} stroke="#bdcedc"/><text textAnchor="middle" y="51">{short(node.item.name)}</text><text textAnchor="middle" y="68" className="v3-code">{short(node.item.code,32)}</text><text textAnchor="middle" y="81" className="v3-hint">{node.loading?'Loading…':node.error?'Failed · click to retry':node.reference?'Reference · open details':node.open?(node.loaded&&!node.children.length?'No records in this collection':'Connections open'):'Click to expand ↓'}</text>
            </g></Dropdown>
            <Dropdown trigger={['click']} menu={{items:menus(node)}}><g role="button" tabIndex={0} aria-label={`Actions ${node.item.code}`} className="v3-node-menu" onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.currentTarget.dispatchEvent(new MouseEvent('click',{bubbles:true}))}}}><rect x="86" y="-10" width="24" height="27" rx="6"/><text x="98" y="9" textAnchor="middle">⋮</text></g></Dropdown>
            {node.open&&node.children.length>0&&<g role="button" tabIndex={0} aria-label={`Collapse ${node.item.code}`} className="v3-node-menu" onClick={()=>setNodes(prev=>({...prev,[key]:{...prev[key],open:false}}))} onKeyDown={e=>{if(e.key==='Enter'){setNodes(prev=>({...prev,[key]:{...prev[key],open:false}}))}}}><rect x="-110" y="-10" width="24" height="27" rx="6"/><text x="-98" y="9" textAnchor="middle">−</text></g>}
            {node.open&&node.total!==undefined&&node.children.length<node.total&&<g role="button" tabIndex={0} aria-label={`Load more ${node.item.name}`} className="v3-more" onClick={()=>void expand(node,(node.page??1)+1)} onKeyDown={e=>{if(e.key==='Enter')void expand(node,(node.page??1)+1)}}><rect x="-65" y="96" width="130" height="24" rx="6"/><text y="112" textAnchor="middle">Load more ({node.children.length}/{node.total})</text></g>}
          </g>})}
        </g>
      </svg><footer>Drag to pan · Click to expand · Right-click / ⋮ to manage · Collapse preserves descendants · Fit all restores the overview</footer>
    </div>
    <Modal open={!!searchNode||globalSearch} onCancel={()=>{setSearchNode(undefined);setGlobalSearch(false)}} footer={null} title={searchNode?`Search ${searchNode.item.name}`:'Find and add to the canvas'} width={620}>
      {globalSearch&&<div className="v3-search-types">{['user','role','permission','policy'].map(kind=><Button key={kind} type={globalKind===kind?'primary':'default'} onClick={()=>{setGlobalKind(kind);setPage(1)}}>{kind}</Button>)}</div>}<Input.Search allowClear aria-label="Search city" placeholder="Name or code" onSearch={value=>{setQ(value);setPage(1)}}/>
      {searchError&&<Alert type="error" title={searchError}/>}<div className="v3-results">{results?.items.map(item=><button key={`${item.kind}:${item.id}`} onClick={()=>{attach(searchNode?.key??'root',[item],searchNode?'contains':'selected focus');setSearchNode(undefined);setGlobalSearch(false)}}><strong>{item.name}</strong><code>{item.code}</code></button>)}</div>{results&&<Pagination current={results.page} total={results.total} pageSize={searchNode&& !['user','role','group'].includes(searchNode.collection?.owner.kind??'')?3:searchNode?.collection?.relation==='permissions'?4:12} showSizeChanger={false} onChange={setPage}/>}
    </Modal>
    <Modal open={!!detail&&!creating&&!renaming&&!mapping} onCancel={()=>setDetail(undefined)} footer={null} title="Landmark details" width={560}>{detail&&<><Tag>{detail.item.kind}</Tag><h2>{detail.item.name}</h2><code>{detail.item.code}</code>{detail.error&&<Alert type="error" title={detail.error}/>}<pre className="v3-expression">{detail.item.description??detail.item.annotation}</pre><div className="v3-detail-actions">{['tenant','application','resource','permission','client','api','ui','externalPermission'].includes(detail.item.kind)&&<Button onClick={()=>setRenaming(true)}>Rename</Button>}{['endpoint','ui'].includes(detail.item.kind)&&<Button onClick={()=>setMapping(true)}>Map Permission</Button>}<Link to={manage(detail.item)}>Edit assignments / Rules / delete in management</Link></div></>}</Modal>
    {creating&&<ExplorerCreateModal kind={creating} parent={detail?.item.kind==='workspace'?undefined:detail?.item as ExplorerItem} onClose={()=>setCreating(undefined)} onCreated={()=>{setCreating(undefined);reload()}}/>}
    {renaming&&detail&&<ExplorerRenameModal item={detail.item as ExplorerItem} onClose={()=>setRenaming(false)} onDone={reload}/>}
    {mapping&&detail&&<PermissionMappingModal item={detail.item as ExplorerItem} tenantId={detail.tenantId} onClose={()=>setMapping(false)} onDone={reload}/>}
  </div>
}
