import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Alert, Button, Drawer, Dropdown, Empty, Input, Modal, Pagination, Skeleton, Tag } from 'antd'
import { MoreOutlined, PlusOutlined, ReloadOutlined } from '@ant-design/icons'
import { api } from '../api/client'
import { ConnectionTree, type TreeSearch } from '../features/structure/ConnectionTree'
import { createKinds, explorerLabels, managementLink, type ExplorerItem, type ExplorerKind, type ExplorerPage } from '../features/structure/explorer'
import { ExplorerCreateModal, ExplorerRenameModal, PermissionMappingModal } from '../features/structure/ExplorerForms'
import { invalidateOptions } from '../hooks/useApi'
import { invalidateCatalogTree } from '../components/Catalog'
import '../features/structure/city-v2.css'

const kinds: Record<string, ExplorerKind> = { tenants: 'tenant', platforms: 'application', clients: 'client', users: 'user', resources: 'resource', apis: 'api', ui: 'ui', permissions: 'permission', policies: 'policy', excluded: 'policy', rules: 'rule', roles: 'role', endpoints: 'endpoint', external: 'externalPermission' }
const terminal = ['user', 'role', 'rule']
function useDistrict(url: string | undefined) {
  const [result, setResult] = useState<{ url: string; data?: ExplorerPage; error?: string }>()
  useEffect(() => {
    if (!url) return
    let active = true
    api.get<ExplorerPage>(url).then(data => { if (active) setResult({ url, data }) }).catch(e => { if (active) setResult({ url, error: e.message }) })
    return () => { active = false }
  }, [url])
  return result?.url === url ? result : undefined
}

export function StructureCityV2Page() {
  const [revision, setRevision] = useState(0)
  const [panel, setPanel] = useState<TreeSearch>()
  const [q, setQ] = useState('')
  const [draft, setDraft] = useState('')
  const [page, setPage] = useState(1)
  const [detail, setDetail] = useState<ExplorerItem>()
  const [detailTenant, setDetailTenant] = useState<number>()
  const inspect = (item: ExplorerItem, scope?: number) => { setDetail(item); setDetailTenant(scope) }
  const [creating, setCreating] = useState<ExplorerKind>()
  const [createParent, setCreateParent] = useState<ExplorerItem>()
  const [editing, setEditing] = useState<ExplorerItem>()
  const [mapping, setMapping] = useState<ExplorerItem>()
  const [motion, setMotion] = useState(() => !matchMedia('(prefers-reduced-motion: reduce)').matches)
  const tenantId = detailTenant ?? panel?.tenantId ?? detail?.tenantId
  const panelBase = `/api/structure/explore?kind=${panel?.owner?.kind ?? 'root'}&id=${panel?.owner?.id ?? 0}${panel?.tenantId ? `&tenantId=${panel.tenantId}` : ''}&revision=${revision}`
  const records = useDistrict(panel ? `${panelBase}&relation=${panel.district.key}&pageSize=12&page=${page}&q=${encodeURIComponent(q)}` : undefined)
  const current = panel?.owner
  const allowed = createKinds(current)
  const refresh = () => { invalidateCatalogTree(); invalidateOptions('tenants', 'applications', 'nodes', 'permissions', 'clients', 'resources'); setRevision(x => x + 1) }
  const show = (next: TreeSearch) => { setDraft(''); setQ(''); setPage(1); setPanel(next) }
  const beginCreate = (kind: ExplorerKind, owner?: ExplorerItem) => { setCreateParent(owner); setCreating(kind) }
  const enter = (item: ExplorerItem) => {
    if (terminal.includes(item.kind)) { inspect(item, panel?.tenantId); return }
    panel?.reveal(item)
    setPanel(undefined); setDetail(undefined)
  }
  const add = createKinds(undefined).map(kind => ({ key: kind, label: `Add ${explorerLabels[kind]}`, onClick: () => beginCreate(kind) }))
  const browse = <div className="v2-browser">
    <div className="v2-browser-context"><Tag>{current?.code ?? 'Workspace'}</Tag><span>{panel?.district.count.toLocaleString()} records in this district</span></div>
    <Input.Search autoFocus allowClear placeholder="Search by name or code" aria-label="Search district" value={draft} onChange={e => { setDraft(e.target.value); if (!e.target.value) { setQ(''); setPage(1) } }} onSearch={value => { setQ(value.trim()); setPage(1) }} enterButton="Search" />
    <div className="v2-browser-toolbar"><span>Search results load 12 at a time</span>{panel && allowed.includes(kinds[panel.district.key]) && <Button icon={<PlusOutlined />} onClick={() => beginCreate(kinds[panel.district.key], panel.owner)}>Add {explorerLabels[kinds[panel.district.key]]}</Button>}</div>
    {records?.error ? <Alert type="error" title={records.error} action={<Button onClick={refresh}>Retry</Button>} /> : !records?.data ? <Skeleton active /> : <>
      {!records.data.items.length && <Empty description="No matching records" />}
      <div className="v2-records">{records.data.items.map(item => <div className="v2-record" key={`${item.kind}:${item.id}`}>
        <button className="v2-record-main" onClick={() => enter(item)}><strong>{item.name}</strong><code>{item.code}</code>{item.annotation && <small>{item.annotation}</small>}</button>
        <Button onClick={() => enter(item)}>{terminal.includes(item.kind) ? 'Details' : 'Explore'}</Button>
        <Dropdown trigger={['click']} menu={{ items: [{ key: 'detail', label: 'Details & actions', onClick: () => inspect(item, panel?.tenantId) }, { key: 'manage', label: <Link to={managementLink(item)}>Open management</Link> }] }}><Button aria-label={`Actions for ${item.code}`} icon={<MoreOutlined />} /></Dropdown>
      </div>)}</div>
      <Pagination size="small" current={records.data.page} total={records.data.total} pageSize={12} showSizeChanger={false} showTotal={total => `${total.toLocaleString()} results`} onChange={setPage} />
    </>}
  </div>
  return <div className="city-v2">
    <header className="v2-heading"><div><span className="v2-eyebrow">ACCESS CITY / V2</span><h1>The big picture.</h1><p>Gruplarla yapıyı görün. Arayın, odağa alın ve doğru yere ekleyin.</p></div><div><Link to="/all-in-one">View V1</Link><Button aria-label="Refresh city" icon={<ReloadOutlined />} onClick={refresh} /><Dropdown trigger={['click']} menu={{ items: add }} disabled={!add.length}><Button type="primary" icon={<PlusOutlined />}>Add</Button></Dropdown></div></header>
    <>
      <div className={`v2-scene ${motion ? 'v2-motion' : ''}`}>
        <div className="v2-scene-caption"><span>ARCHITECTURE TREE</span><h2>Explore connections, keep the context.</h2><p>Click a node to grow its branch. Other branches stay in place.</p></div>
        <ConnectionTree revision={revision} onSearch={show} onDetail={inspect} onAdd={beginCreate} />
      </div>
      <footer className="v2-legend"><span><b>Click</b> Expand connections</span><span><b>Double-click group</b> Search workspace</span><span><b>Right-click / ⋯</b> Actions</span><label><input type="checkbox" checked={motion} onChange={e => setMotion(e.target.checked)} /> Motion</label></footer>
      <div className="v2-note">{'Open only the branches you need. Use the collapse button to fold a branch; right-click or the actions menu to search and manage.'} Connections are schematic, not live traffic.</div>
    </>
    <Drawer title={`${panel?.district.label ?? ''} / Search`} open={!!panel && !panel.expanded} onClose={() => setPanel(undefined)} width={620} extra={<Button onClick={() => panel && setPanel({ ...panel, expanded: true })}>Expand</Button>}>{panel && !panel.expanded && browse}</Drawer>
    <Modal title={`${panel?.district.label ?? ''} / District workspace`} open={!!panel?.expanded} onCancel={() => setPanel(undefined)} footer={null} width={1000}>{panel?.expanded && browse}</Modal>
    <Drawer title="Record details" open={!!detail} onClose={() => setDetail(undefined)} width={480}>{detail && <div className="v2-details"><Tag>{explorerLabels[detail.kind]}</Tag><h2>{detail.name}</h2><code>{detail.code}</code><p>{detail.annotation}</p><pre>{detail.description}</pre><div>
      {panel && !terminal.includes(detail.kind) && <Button type="primary" onClick={() => enter(detail)}>Explore connections</Button>}
      {['tenant', 'application', 'resource', 'permission', 'client', 'api', 'ui', 'externalPermission'].includes(detail.kind) && <Button onClick={() => setEditing(detail)}>Rename</Button>}
      {['endpoint', 'ui'].includes(detail.kind) && <Button onClick={() => setMapping(detail)}>Map Permission</Button>}
      <Link to={managementLink(detail)}>Open management</Link>
    </div></div>}</Drawer>
    {creating && <ExplorerCreateModal kind={creating} parent={createParent} onClose={() => setCreating(undefined)} onCreated={() => { setCreating(undefined); refresh() }} />}
    {editing && <ExplorerRenameModal item={editing} onClose={() => setEditing(undefined)} onDone={() => { setDetail(undefined); refresh() }} />}
    {mapping && <PermissionMappingModal item={mapping} tenantId={tenantId} onClose={() => setMapping(undefined)} onDone={() => { setDetail(undefined); refresh() }} />}
  </div>
}
