import { Alert, Button, Card, Col, Divider, Flex, Form, Input, Popconfirm, Radio, Row, Select, Switch, Tag, Typography } from 'antd'
import { DataTable as Table, textColumnFilter } from '../components/DataTable'
import { DeleteOutlined, PlusOutlined, SaveOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import type { DecisionStrategy, DefinitionChangeResult, PagedResult, PermissionListItem, PermissionTarget, PolicyLogic, PolicyMode } from '../api/types'
import { invalidateOptions, toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { AccessKey, ActiveTag, AsyncState, Code, LogicTag, ModeTag, PageGuide, PageHeader, ResourceTypeTag, StrategyTag, TagSummary, strategyHelp, strategyLabel } from '../components/common'
import { DefinitionChangeModal } from '../components/DefinitionChange'
import { ResourceModal } from '../components/ResourceForms'

const strategies: DecisionStrategy[] = ['Unanimous', 'Affirmative', 'Consensus']

// ================================ Liste ================================

export function PermissionsPage() {
  const [appId, setAppId] = useState<number>()
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const apps = useOptions('applications')
  const [query, setQuery] = useState('')
  const { data, loading, error } = useApi<PagedResult<PermissionListItem>>(`/api/permissions?page=${page}&pageSize=${pageSize}&q=${encodeURIComponent(query)}${appId ? `&applicationId=${appId}` : ''}`)
  const navigate = useNavigate()
  return (
    <>
      <PageHeader title="Permissions" subtitle="HANGİ resource / scope, HANGİ policy'lerle korunur? Permission olmayan yetkiye kimse erişemez."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => navigate('/permissions/new')}>Yeni permission</Button>} />
      <PageGuide>
        <p>Permission = <b>resource'lar × scope'lar ← policy'ler</b>. Kapsam açıkça seçilir: <b>seçili resource'lar</b>, <b>bir tipin tüm resource'ları</b> veya <b>tüm uygulama</b>; scope'lar için <b>seçili scope'lar</b> veya <b>tüm scope'lar</b>.</p>
        <p>Boş liste "tümü" demek değildir: resource veya scope listesi boş kalan permission (ör. resource'u silinmiş) <b>atıl</b> olur ve hiçbir yetkiyi etkilemez; yetki asla kendiliğinden genişlemez.</p>
        <p>Policy'ler permission'ın stratejisiyle birleşir (Unanimous: hepsi izin vermeli). Bir yetkiye birden fazla permission uygulanırsa uygulamanın stratejisi geçerlidir (Keycloak varsayılanı Unanimous → hepsi izin vermeli). "Rol X VEYA grup Y" için Affirmative birleşik policy kullanın.</p>
        <p>Sadece koşul/kanal policy'si içeren permission tek başınaysa herkese açar; başka permission'la birlikte ise ek kısıt olur.</p>
      </PageGuide>
      <Flex className="list-toolbar" gap={8} wrap>
        <Input.Search allowClear placeholder="Permission, resource veya policy ara" onSearch={(value) => { setQuery(value); setPage(1) }} style={{ width: 320 }} />
        <Select allowClear placeholder="Uygulama" value={appId} onChange={(value) => { setAppId(value); setPage(1) }} options={toSelectOptions(apps)} style={{ width: 240 }} />
      </Flex>
      {error && <Alert type="error" showIcon style={{ marginBottom: 12 }} message="Permission listesi yüklenemedi" description={error} />}
      <Table<PermissionListItem> rowKey="id" loading={loading} dataSource={data?.items ?? []} locale={{ emptyText: query || appId ? 'Filtrelerle eşleşen permission yok' : 'Henüz permission tanımlanmamış' }}
        pagination={{ current: page, pageSize, total: data?.total ?? 0, showSizeChanger: true, showTotal: (total) => `${total} permission`, onChange: (nextPage, nextSize) => { setPage(nextSize === pageSize ? nextPage : 1); setPageSize(nextSize) } }}
        rowClassName="clickable-row" onRow={(p) => ({ onClick: () => navigate(`/permissions/${p.id}`) })}
        columns={[
          { title: 'Permission', dataIndex: 'code', ...textColumnFilter<PermissionListItem>((p) => `${p.code} ${p.name}`, 'Permission içinde ara'), render: (_, p) => <><Code>{p.code}</Code>{!p.isActive && <Tag>pasif</Tag>}{!p.hasIdentityPolicy && <Tag color="orange">KİM şartı yok</Tag>}<br /><Typography.Text type="secondary">{p.name}</Typography.Text></> },
          { title: 'Uygulama', dataIndex: 'application', width: 110, render: (v) => <Tag>{v}</Tag> },
          { title: 'Resource', dataIndex: 'resources', render: (_, p) => p.target === 'Application' ? <Tag color="red">tüm uygulama</Tag>
              : p.target === 'ResourceType' ? <Tag color="purple">tüm {p.resourceType} resource'ları</Tag>
              : p.resources.length ? <TagSummary values={p.resources} limit={2} /> : <Tag>yok → atıl</Tag> },
          { title: 'Scope', dataIndex: 'scopes', render: (_, p) => p.allScopes ? <Tag color="purple">tüm scope'lar</Tag> : p.scopes.length ? p.scopes.map((s) => <Tag key={s}>{s}</Tag>) : <Tag>yok → atıl</Tag> },
          { title: 'Policy\'ler', dataIndex: 'policies', render: (_, p) => <Flex wrap gap={2}>{p.policies.map((x) => <Tag key={x.id}>{x.code}</Tag>)}</Flex> },
          { title: 'Strateji', dataIndex: 'strategy', width: 170, render: (v) => p2(v) },
          { title: 'Yetki', dataIndex: 'coverage', width: 90, render: (v: number) => v ? v : <Tag color="orange">0 · atıl</Tag> },
        ]} />
    </>
  )
}

const p2 = (v: DecisionStrategy) => <StrategyTag strategy={v} />

// ================================ Detay / düzenleyici ================================

interface PermissionDetail {
  permission: {
    id: number; code: string; name: string; description?: string; isActive: boolean; decisionStrategy: DecisionStrategy; version: number
    applicationId: number; application: string; applicationStrategy: DecisionStrategy; target: PermissionTarget; allScopes: boolean; resourceTypeId?: number; resourceType?: string; hasIdentityPolicy: boolean
  }
  resourceIds: number[]
  scopeIds: number[]
  policyIds: number[]
  policies: { id: number; code: string; name: string; logic: PolicyLogic; mode: PolicyMode; isActive: boolean; decisionStrategy: DecisionStrategy; rules: { code: string; name: string; expression: string }[] }[]
  coverage: { id: number; key: string; name: string; resourceType: string; otherPermissions: string[] }[]
}

interface PermissionForm {
  applicationId: number; code: string; name: string; description?: string; resourceTypeId?: number; resourceIds: number[]; scopeIds: number[]
  policyIds: number[]; decisionStrategy: DecisionStrategy; isActive: boolean; target: PermissionTarget; allScopes: boolean
}

export function PermissionDetailPage() {
  const { id } = useParams()
  const isNew = id === 'new'
  const { data, loading, error, reload } = useApi<PermissionDetail>(isNew ? null : `/api/permissions/${id}`)
  if (!isNew && !data) return <AsyncState loading={loading} error={error} onRetry={reload} empty="Permission bulunamadı" />
  return <PermissionEditor key={id} detail={isNew ? undefined : data} onSaved={reload} />
}

function PermissionEditor({ detail, onSaved }: { detail?: PermissionDetail; onSaved: () => void }) {
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const [form] = Form.useForm<PermissionForm>()
  const apps = useOptions('applications')
  const types = useOptions('resource-types')
  const [resourceRefresh, setResourceRefresh] = useState(0)
  const resources = useOptions('resources', resourceRefresh)
  const scopes = useOptions('scopes')
  const policies = useOptions('policies')
  const [pending, setPending] = useState<{ title: string; body?: object; method: 'post' | 'put' | 'del' }>()
  const [newResource, setNewResource] = useState(false)
  const p = detail?.permission
  const appId = Form.useWatch('applicationId', form) as number | undefined
  const target = (Form.useWatch('target', form) ?? 'Resources') as PermissionTarget
  const allScopes = (Form.useWatch('allScopes', form) ?? false) as boolean
  const selectedPolicyIds = (Form.useWatch('policyIds', form) ?? []) as number[]
  const permissionStrategy = (Form.useWatch('decisionStrategy', form) ?? 'Unanimous') as DecisionStrategy
  const appCode = apps.find((a) => a.value === appId)?.code
  const presetResource = params.get('resource')
  const selectedPolicyCodes = selectedPolicyIds.map((policyId) => policies.find((x) => x.value === policyId)?.code ?? `#${policyId}`)
  const policyJoiner = permissionStrategy === 'Unanimous' ? ' VE ' : permissionStrategy === 'Affirmative' ? ' VEYA ' : ' ÇOĞUNLUK '

  const initial: Partial<PermissionForm> = p
    ? { ...p, resourceIds: detail!.resourceIds, scopeIds: detail!.scopeIds, policyIds: detail!.policyIds }
    : { applicationId: params.get('app') ? Number(params.get('app')) : undefined, resourceIds: presetResource ? [Number(presetResource)] : [], scopeIds: [], policyIds: [],
        decisionStrategy: 'Unanimous', isActive: true, target: 'Resources', allScopes: false }

  const submit = async () => {
    const v = await form.validateFields()
    const body = {
      applicationId: v.applicationId, code: v.code ?? p?.code, name: v.name, description: v.description, decisionStrategy: v.decisionStrategy, isActive: v.isActive,
      target: v.target, resourceTypeId: v.target === 'ResourceType' ? v.resourceTypeId : undefined, resourceIds: v.target === 'Resources' ? v.resourceIds ?? [] : [],
      allScopes: v.allScopes, scopeIds: v.allScopes ? [] : v.scopeIds ?? [], policyIds: v.policyIds,
    }
    setPending({ title: p ? `${p.code} güncelle — erişim etkisi` : `${v.code} oluştur — erişim etkisi`, body, method: p ? 'put' : 'post' })
  }

  const run = (dryRun: boolean, expectedModelVersion?: number) => pending!.method === 'post'
    ? api.post<DefinitionChangeResult>(`/api/permissions?dryRun=${dryRun}${expectedModelVersion === undefined ? '' : `&expectedModelVersion=${expectedModelVersion}`}`, pending!.body)
    : pending!.method === 'put'
      ? api.put<DefinitionChangeResult>(`/api/permissions/${p!.id}?dryRun=${dryRun}${expectedModelVersion === undefined ? '' : `&expectedModelVersion=${expectedModelVersion}`}`, pending!.body)
      : api.del<DefinitionChangeResult>(`/api/permissions/${p!.id}?dryRun=${dryRun}${expectedModelVersion === undefined ? '' : `&expectedModelVersion=${expectedModelVersion}`}`)

  return (
    <>
      <PageHeader title={p ? <><Code>{p.code}</Code> {p.name}</> : 'Yeni permission'}
        subtitle={p ? <Flex gap={4} wrap align="center"><Tag>{p.application}</Tag><StrategyTag strategy={p.decisionStrategy} /><ActiveTag active={p.isActive} /> v{p.version}
          {!p.hasIdentityPolicy && <Tag color="orange">KİM şartı yok</Tag>}</Flex> : 'Hangi resource / scope, hangi policy\'lerle korunacak?'}
        extra={<Flex gap={8}>
          <Button type="primary" icon={<SaveOutlined />} onClick={submit}>Etkiyi gör ve kaydet</Button>
          {p && <Popconfirm title={`${p.code} silinsin mi?`} description="Önce etkisi gösterilir." onConfirm={() => setPending({ title: `${p.code} sil — erişim etkisi`, method: 'del' })}>
            <Button danger icon={<DeleteOutlined />} />
          </Popconfirm>}
        </Flex>} />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={14}>
          <Card size="small">
            <Form form={form} layout="vertical" initialValues={initial}
              onValuesChange={(c) => { if ('applicationId' in c) form.setFieldsValue({ resourceIds: [], scopeIds: [] }) }}>
              <Row gutter={12}>
                <Col span={24}><Divider titlePlacement="start" plain>1 · Korunacak hedef</Divider></Col>
                <Col span={12}><Form.Item name="applicationId" label="Uygulama (resource server)" rules={[{ required: true }]}><Select disabled={!!p} options={toSelectOptions(apps)} /></Form.Item></Col>
                <Col span={12}><Form.Item name="code" label="Kod" rules={[{ required: !p }]}><Input disabled={!!p} placeholder="VADELI_KAPAT" /></Form.Item></Col>
                <Col span={24}><Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input placeholder="Vadeli hesap kapatma" /></Form.Item></Col>
                <Col span={24}><Form.Item name="target" label="Neye uygulanır?">
                  <Radio.Group optionType="button" options={[
                    { value: 'Resources', label: 'Seçili resource\'lar' },
                    { value: 'ResourceType', label: 'Bir tipin tüm resource\'ları' },
                    { value: 'Application', label: 'Tüm uygulama' },
                  ]} />
                </Form.Item></Col>
                {target === 'Resources' && <Col span={24}><Form.Item name="resourceIds" label={<Flex gap={8} align="center">Resource'lar
                    <Button size="small" type="link" icon={<PlusOutlined />} disabled={!appId} onClick={() => setNewResource(true)}>yeni resource</Button></Flex>} rules={[{ required: true, type: 'array', min: 1, message: 'En az bir resource seçin' }]}
                  extra="Listede kalmayan resource (ör. silinen) kapsamdan düşer; liste boşalırsa permission atıl olur, asla genişlemez.">
                  <Select mode="multiple" showSearch optionFilterProp="label" options={toSelectOptions(resources.filter((r) => r.group === appCode))} />
                </Form.Item></Col>}
                {target === 'ResourceType' && <Col span={24}><Form.Item name="resourceTypeId" label="Resource tipi" rules={[{ required: true }]} extra="Bu tipte sonradan eklenen resource'lar da otomatik kapsanır.">
                  <Select options={toSelectOptions(types)} />
                </Form.Item></Col>}
                {target === 'Application' && <Col span={24}><Alert type="error" showIcon style={{ marginBottom: 16 }} message="Uygulamadaki TÜM resource'lar"
                  description="Sonradan eklenen her resource da kendiliğinden bu permission'ın policy'leriyle erişilebilir olur. Sadece uygulama geneli kısıtlar için kullanın." /></Col>}
                <Col span={24}><Form.Item name="allScopes" label="Scope'lar">
                  <Radio.Group optionType="button" options={[{ value: false, label: 'Seçili scope\'lar' }, { value: true, label: 'Tüm scope\'lar' }]} />
                </Form.Item></Col>
                {allScopes && <Col span={24}><Alert type="warning" showIcon style={{ marginBottom: 16 }} message="Uygulamadaki TÜM scope'lar"
                  description="Sonradan eklenen scope'lar da otomatik kapsama girer. Yalnızca bilinçli olarak gelecekteki eylemleri de korumak istiyorsanız kullanın." /></Col>}
                {!allScopes && <Col span={24}><Form.Item name="scopeIds" rules={[{ required: true, type: 'array', min: 1, message: 'En az bir scope seçin' }]}>
                  <Select mode="multiple" optionFilterProp="label" placeholder="Scope seç" options={toSelectOptions(scopes.filter((s) => s.group === appCode))} />
                </Form.Item></Col>}
                <Col span={24}><Divider titlePlacement="start" plain>2 · Karar koşulları</Divider></Col>
                <Col span={24}><Form.Item name="policyIds" label="Policy'ler" rules={[{ required: true, type: 'array', min: 1 }]}>
                  <Select mode="multiple" showSearch optionFilterProp="label"
                    options={toSelectOptions(policies)} placeholder="Policy seç (kimlik şartı yoksa kaydetmeden önce uyarı gösterilir)" />
                </Form.Item></Col>
                <Col span={16}><Form.Item name="decisionStrategy" label="Policy birleştirme">
                  <Select options={strategies.map((s) => ({ value: s, label: `${strategyLabel[s]} — ${strategyHelp[s]}` }))} />
                </Form.Item></Col>
                <Col span={8}><Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item></Col>
                <Col span={24}><Alert type="info" showIcon message="Permission mantığı"
                  description={<><Code>{selectedPolicyCodes.length ? selectedPolicyCodes.map((x) => `(${x})`).join(policyJoiner) : 'Policy seçilmedi'}</Code><br />Bu seviye seçilen policy sonuçlarını birleştirir. Her policy kendi içinde rule/kart stratejisini ayrıca uygular.</>} /></Col>
                <Col span={24}><Divider titlePlacement="start" plain>3 · Kayıt bilgileri</Divider></Col>
                <Col span={24}><Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item></Col>
              </Row>
            </Form>
          </Card>
        </Col>
        <Col xs={24} xl={10}>
          {detail && (
            <>
              <Card size="small" title="Policy'ler">
                {detail.policies.map((x) => (
                  <div key={x.id} style={{ marginBottom: 6 }}>
                    <Link to={`/policies/${x.id}`}><Code>{x.code}</Code></Link> <LogicTag logic={x.logic} /><StrategyTag strategy={x.decisionStrategy} />{x.mode !== 'Enforce' && <ModeTag mode={x.mode} />}{!x.isActive && <Tag>pasif</Tag>}
                    <div style={{ fontSize: 12 }}><Typography.Text type="secondary">{x.name}{x.rules.length > 0 && ': '}{x.rules.map((r) => r.expression).join(' · ')}</Typography.Text></div>
                  </div>
                ))}
              </Card>
              <Card size="small" style={{ marginTop: 16 }} title={`Kapsadığı yetkiler (${detail.coverage.length})`}>
                <Table size="small" rowKey="id" dataSource={detail.coverage} pagination={detail.coverage.length > 10 ? {} : false}
                  columns={[
                    { title: 'Yetki', render: (_, x) => <><ResourceTypeTag type={x.resourceType} /><AccessKey value={x.key} /></> },
                    { title: 'Aynı yetkideki diğer permission', dataIndex: 'otherPermissions', render: (v: string[]) => v.length ? v.map((c) => <Tag key={c}>{c}</Tag>) : '—' },
                  ]} />
                {detail.coverage.some((c) => c.otherPermissions.length) && (
                  <Alert type={detail.permission.applicationStrategy === 'Unanimous' ? 'warning' : 'info'} showIcon style={{ marginTop: 8 }}
                    message={<>Aynı access key'deki permission'lar: <StrategyTag strategy={detail.permission.applicationStrategy} /></>}
                    description={detail.permission.applicationStrategy === 'Unanimous'
                      ? 'Uygulama seviyesinde tüm eşleşen permission’lar izin vermelidir; bunlar alternatif grant değildir.'
                      : strategyHelp[detail.permission.applicationStrategy]} />
                )}
              </Card>
            </>
          )}
          {!detail && <Alert type="info" showIcon message="Kaydetmeden önce kim kazanır / kaybeder, SoD ve RACF etkisi gösterilir." />}
        </Col>
      </Row>
      {newResource && appId && <ResourceModal applicationId={appId} onClose={() => setNewResource(false)}
        onDone={(id) => { setResourceRefresh((x) => x + 1); if (id) form.setFieldValue('resourceIds', [...(form.getFieldValue('resourceIds') ?? []), id]) }} />}
      {pending && (
        <DefinitionChangeModal title={pending.title} danger={pending.method === 'del'} run={run} onClose={() => setPending(undefined)}
          onDone={(r) => {
            invalidateOptions('permissions')
            if (pending.method === 'del') navigate('/permissions')
            else if (pending.method === 'post' && r && r.id) navigate(`/permissions/${r.id}`)
            else onSaved()
          }} />
      )}
    </>
  )
}
