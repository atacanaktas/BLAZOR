import { Alert, App, Button, Card, Col, DatePicker, Flex, Form, Input, Modal, Row, Select, Spin, Switch, Tabs, Tag, Typography } from 'antd'
import { DataTable as Table, textColumnFilter } from '../components/DataTable'
import { DeleteOutlined, EyeOutlined, PlusOutlined, SaveOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import type { Dayjs } from 'dayjs'
import { api } from '../api/client'
import type { AuthorizationChangeSet, ChangeImpactResult, GroupFilterDraft } from '../api/types'
import { invalidateOptions, toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { ActiveTag, AsyncState, Code, ListError, TenantTag, PageGuide, PageHeader, TagSummary, fmtDate } from '../components/common'
import { ChangeModal } from '../components/ChangeModal'
import { ConfirmChangeModal } from '../components/ConfirmChangeModal'
import { GroupFilterEditor } from '../components/GroupFilterEditor'

interface GroupRow {
  id: number
  code: string
  name: string
  isActive: boolean
  tenant: string
  rule: string
  explicitMembers: number
  memberCount: number
  roles: string[]
  policies: string[]
}

export function GroupsPage() {
  const { data, loading, error, reload } = useApi<GroupRow[]>('/api/groups')
  const [query, setQuery] = useState('')
  const filtered = (data ?? []).filter((g) => `${g.code} ${g.name} ${g.tenant}`.toLocaleLowerCase('tr-TR').includes(query.toLocaleLowerCase('tr-TR')))
  const navigate = useNavigate()
  const [creating, setCreating] = useState(false)
  return (
    <>
      <PageHeader title="Gruplar"
        subtitle="Ortak özelliklere sahip kullanıcıları gruplandırın ve erişimlerini yönetin."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setCreating(true)}>Yeni grup</Button>}
      />
      <PageGuide title="Grup kuralları hakkında"><Alert type="info" showIcon style={{ marginBottom: 16 }}
        message="Örnek: 'sadece 101 şubedeki gişe asistanları' → kural: ROLE∈{GISEAST} ∧ ORG_UNIT∈{101}, hariç: TITLE∈{Stajyer...}"
        description="Kural içindeki kriterler VE, kurallar arası VEYA ile birleşir. Kişi adı yerine özellik (rol, birim, unvan, kurum) kullanın; kişi değişince üyelik kendiliğinden güncellenir. Saat/IP/tutar gibi bağlam kontrolleri policy'nin işidir." /></PageGuide>
      <Flex className="list-toolbar" justify="space-between" align="center" gap={12} wrap>
        <Input.Search allowClear placeholder="Grup adı, kodu veya kurum ara" aria-label="Gruplarda ara" onChange={(e) => setQuery(e.target.value)} style={{ width: 340 }} />
        <Typography.Text type="secondary">{filtered.length} grup</Typography.Text>
      </Flex>
      <ListError error={error} onRetry={reload} />
      <Table<GroupRow>
        rowKey="id"
        size="small"
        loading={loading}
        dataSource={filtered}
        locale={{ emptyText: query ? 'Aramayla eşleşen grup yok' : 'Henüz grup tanımlanmamış' }}
        pagination={{ hideOnSinglePage: true }}
        rowClassName="clickable-row"
        onRow={(g) => ({ onClick: () => navigate(`/groups/${g.id}`) })}
        columns={[
          { title: 'Grup', dataIndex: 'code', ...textColumnFilter<GroupRow>((g) => `${g.code} ${g.name}`, 'Grup içinde ara'), render: (_, g) => <><Code>{g.code}</Code><br /><Typography.Text type="secondary">{g.name}</Typography.Text></> },
          { title: 'Tenant', dataIndex: 'tenant', render: (v) => <TenantTag tenant={v} />, width: 110 },
          { title: 'Üyelik kuralı', dataIndex: 'rule', width: '30%', render: (v) => <Typography.Paragraph ellipsis={{ rows: 2, tooltip: v }} style={{ margin: 0, fontSize: 12, color: '#718096' }}>{v}</Typography.Paragraph> },
          { title: 'Üye', dataIndex: 'memberCount', render: (_, g) => <>{g.memberCount}{g.explicitMembers > 0 && <Typography.Text type="secondary"> ({g.explicitMembers} açık)</Typography.Text>}</>, width: 100 },
          { title: 'Rolleri / policy\'leri', render: (_, g) => <TagSummary values={[...g.roles.map((r) => `Rol: ${r}`), ...g.policies.map((p) => `KİM kartı: ${p}`)]} limit={3} /> },
          { title: '', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} />, width: 80 },
        ]}
      />
      {creating && <GroupFormModal onClose={() => setCreating(false)} onDone={(id) => { reload(); if (id) navigate(`/groups/${id}`) }} />}
    </>
  )
}

interface GroupDetail {
  group: { id: number; code: string; name: string; isActive: boolean; tenantId: number; tenant: string; description?: string }
  filters: { order: number; mode: 'Include' | 'Exclude'; description?: string; criteria: { attribute: string; values: string[] }[] }[]
  rule: string
  explicitMembers: { userId: number; userName: string; fullName: string; validUntil?: string }[]
  members: { userId: number; userName: string; fullName: string; title?: string; tenant: string; units: string[]; reasons: { kind: string; filterOrder?: number; text: string }[] }[]
  excluded: { userId: number; userName: string; fullName: string; reason: string }[]
  roles: { id: number; code: string; name: string }[]
  /** Bu grubu KİM kartında kullanan kurallar */
  cards?: { policyId: number; policy: string; ruleId: number; rule: string; ruleName: string; permissions: string[] }[]
}

interface Preview {
  rule: string
  members: { userId: number; userName: string; fullName: string; title?: string; units: string[]; reasons: string[] }[]
  excluded: { userId: number; userName: string; fullName: string; units: string[]; excludedBy: string }[]
}

export function GroupDetailPage() {
  const { id } = useParams()
  const groupId = Number(id)
  const { data, loading, error, reload } = useApi<GroupDetail>(`/api/groups/${groupId}`)
  const { message } = App.useApp()
  const roles = useOptions('roles')
  const users = useOptions('users')
  // null = düzenlenmedi → sunucudaki kurallar gösterilir
  const [edited, setEdited] = useState<GroupFilterDraft[] | null>(null)
  const [preview, setPreview] = useState<Preview>()
  const [previewing, setPreviewing] = useState(false)
  const [saveConfirm, setSaveConfirm] = useState(false)
  const [modal, setModal] = useState<'role' | 'member' | 'edit' | null>(null)
  const [validUntil, setValidUntil] = useState<Dayjs | null>(null)
  const [removal, setRemoval] = useState<{ title: string; changeSet: AuthorizationChangeSet; apply: () => Promise<ChangeImpactResult> }>()

  if (!data) return <AsyncState loading={loading} error={error} onRetry={reload} empty="Grup bulunamadı" />
  const filters = edited ?? data.filters.map((f) => ({ mode: f.mode, description: f.description, criteria: f.criteria.map((c) => ({ attribute: c.attribute, values: [...c.values] })) }))
  const dirty = edited !== null
  const reloadAll = () => { setEdited(null); setPreview(undefined); reload() }

  const runPreview = async () => {
    setPreviewing(true)
    try {
      setPreview(await api.post<Preview>('/api/groups/preview', {
        tenantId: data.group.tenantId, filters, explicitMemberIds: data.explicitMembers.map((m) => m.userId),
      }))
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setPreviewing(false)
    }
  }

  return (
    <>
      <PageHeader
        title={<><Code>{data.group.code}</Code> {data.group.name}</>}
        subtitle={<><TenantTag tenant={data.group.tenant} /><ActiveTag active={data.group.isActive} /> {data.group.description}</>}
        extra={<Button onClick={() => setModal('edit')}>Düzenle</Button>}
      />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={14}>
          <Card size="small" title="Kitle kuralları (kimler üye?)"
            extra={<Flex gap={8}>
              <Button icon={<EyeOutlined />} loading={previewing} onClick={runPreview}>Canlı önizleme</Button>
              <Button type="primary" icon={<SaveOutlined />} disabled={!dirty} onClick={() => setSaveConfirm(true)}>Etkiyi gör ve kaydet</Button>
            </Flex>}>
            <GroupFilterEditor value={filters} onChange={(f) => { setEdited(f); setPreview(undefined) }} />
          </Card>
          {preview && (
            <Card size="small" style={{ marginTop: 16 }} title={<>Önizleme: <Tag color="green">{preview.members.length} üye</Tag><Tag color="volcano">{preview.excluded.length} hariç</Tag></>}>
              <Tabs items={[
                {
                  key: 'm', label: 'Üyeler', children: (
                    <Table size="small" rowKey="userId" dataSource={preview.members} pagination={{}}
                      columns={[
                        { title: 'Kullanıcı', render: (_, u) => <>{u.userName}<br /><Typography.Text type="secondary">{u.title}</Typography.Text></> },
                        { title: 'Birim', dataIndex: 'units', render: (v: string[]) => v.map((x) => <Tag key={x}>{x}</Tag>) },
                        { title: 'Neden', dataIndex: 'reasons', render: (v: string[]) => <Typography.Text style={{ fontSize: 12 }}>{v.join(' | ')}</Typography.Text> },
                      ]} />
                  ),
                },
                {
                  key: 'x', label: 'Hariç tutulanlar', children: (
                    <Table size="small" rowKey="userId" dataSource={preview.excluded} pagination={false}
                      columns={[{ title: 'Kullanıcı', dataIndex: 'userName' }, { title: 'Neden', dataIndex: 'excludedBy' }]} />
                  ),
                },
              ]} />
            </Card>
          )}
          <Card size="small" style={{ marginTop: 16 }} title={`Mevcut üyeler (${data.members.length})`}>
            <Table size="small" rowKey="userId" dataSource={data.members} pagination={{}}
              columns={[
                { title: 'Kullanıcı', render: (_, u) => <><Link to={`/users/${u.userId}`}>{u.userName}</Link><br /><Typography.Text type="secondary">{u.title}</Typography.Text></> },
                { title: 'Tenant / birim', render: (_, u) => <><TenantTag tenant={u.tenant} />{u.units.map((x) => <Tag key={x}>{x}</Tag>)}</> },
                { title: 'Neden üye', dataIndex: 'reasons', render: (v: GroupDetail['members'][0]['reasons']) => v.map((r, i) => <div key={i} style={{ fontSize: 12 }}>{r.kind === 'Member' ? 'açık üye' : `kural #${r.filterOrder}: ${r.text}`}</div>) },
              ]} />
            {data.excluded.length > 0 && (
              <Alert type="warning" style={{ marginTop: 8 }} message="Hariç kuralıyla çıkarılanlar"
                description={data.excluded.map((x) => <div key={x.userId}><b>{x.userName}</b> — {x.reason}</div>)} />
            )}
          </Card>
        </Col>
        <Col xs={24} xl={10}>
          <Card size="small" title="Grubun rolleri (tüm üyeler alır)" extra={<Button size="small" onClick={() => setModal('role')}>+ Rol</Button>}>
            {data.roles.map((r) => (
              <Flex key={r.id} justify="space-between"><span><Tag color="blue">rol</Tag><Link to={`/roles/${r.id}`}>{r.code}</Link> {r.name}</span>
                <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={() => setRemoval({
                  title: `${data.group.code} artık ${r.code} rolünü vermesin`, changeSet: { groupRoles: [{ groupId, roleId: r.id, add: false }] },
                  apply: () => api.del(`/api/groups/${groupId}/roles/${r.id}`),
                })} /></Flex>
            ))}
            {data.roles.length === 0 && <Typography.Text type="secondary">Rol vermiyor.</Typography.Text>}
          </Card>
          <Card size="small" title="Bu grubu KİM kartında kullanan policy'ler" style={{ marginTop: 16 }}>
            {(data.cards ?? []).map((c) => (
              <div key={c.ruleId}><Link to={`/policies/${c.policyId}`}><Tag color="blue">{c.policy} / {c.ruleName}</Tag></Link>
                <Typography.Text type="secondary" style={{ fontSize: 12 }}>→ {c.permissions.length ? c.permissions.join(', ') : 'hiçbir permission kullanmıyor'}</Typography.Text></div>
            ))}
            {!data.cards?.length && <Typography.Text type="secondary">Yok.</Typography.Text>}
            {(data.cards?.length ?? 0) === 1 && data.explicitMembers.length === 0 && data.roles.length === 0 && (
              <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 6, marginBottom: 0 }}>
                Tek bir KİM kartında kullanılıyor, açık üyesi ve rolü yok: istenirse o kartta "Grubu karta aç" ile satırlara dönüştürülebilir.
              </Typography.Paragraph>
            )}
          </Card>
          <Card size="small" title="Açık üyeler (elle eklenen, süreli olabilir)" style={{ marginTop: 16 }} extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setModal('member')}>Ekle</Button>}>
            {data.explicitMembers.length === 0 && <Typography.Text type="secondary">— (tercih edilen: kural)</Typography.Text>}
            {data.explicitMembers.map((m) => (
              <Flex key={m.userId} justify="space-between"><span>{m.userName} {m.validUntil && <Tag color="gold">{fmtDate(m.validUntil)}'e kadar</Tag>}</span>
                <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={() => setRemoval({
                  title: `${m.userName} açık üyeliğini kaldır`, changeSet: { groupMembers: [{ groupId, userId: m.userId, add: false }] },
                  apply: () => api.del(`/api/groups/${groupId}/members/${m.userId}`),
                })} /></Flex>
            ))}
          </Card>
        </Col>
      </Row>

      {saveConfirm && (
        <ConfirmChangeModal open title={`${data.group.code} kitle kurallarını kaydet`} changeSet={{ groupFilters: [{ groupId, filters }] }}
          apply={() => api.put(`/api/groups/${groupId}/filters`, filters)} onClose={() => setSaveConfirm(false)} onDone={reloadAll} applyText="Kaydet" />
      )}
      <ChangeModal open={modal === 'role'} title={`${data.group.code} → rol ver`} label="Rol (grubun tüm üyeleri alır)" options={toSelectOptions(roles, data.roles.map((r) => r.id))}
        buildChangeSet={(t) => ({ groupRoles: [{ groupId, roleId: t, add: true }] })} apply={(t) => api.post(`/api/groups/${groupId}/roles/${t}`)}
        onClose={() => setModal(null)} onDone={reload} />
      <ChangeModal open={modal === 'member'} title={`${data.group.code} → açık üye ekle`} label="Kullanıcı" options={toSelectOptions(users, data.explicitMembers.map((m) => m.userId))}
        buildChangeSet={(t) => ({ groupMembers: [{ groupId, userId: t, add: true, validUntil: validUntil?.toISOString() }] })}
        apply={(t) => api.post(`/api/groups/${groupId}/members/${t}`, { validUntil: validUntil?.toISOString() })}
        onClose={() => { setModal(null); setValidUntil(null) }} onDone={reload}
        extra={<DatePicker placeholder="Bitiş (opsiyonel)" value={validUntil} onChange={setValidUntil} />} />
      {removal && <ConfirmChangeModal open title={removal.title} changeSet={removal.changeSet} apply={removal.apply} onClose={() => setRemoval(undefined)} onDone={reload} />}
      {modal === 'edit' && <GroupFormModal group={data.group} onClose={() => setModal(null)} onDone={reload} />}
      {previewing && <Spin fullscreen />}
    </>
  )
}

function GroupFormModal({ group, onClose, onDone }: { group?: GroupDetail['group']; onClose: () => void; onDone: (id?: number) => void }) {
  const [form] = Form.useForm()
  const tenants = useOptions('tenants')
  const { message } = App.useApp()
  const save = async () => {
    const v = await form.validateFields()
    try {
      if (group) {
        const r = await api.put<ChangeImpactResult>(`/api/groups/${group.id}`, { ...group, ...v })
        message.success('Kaydedildi. ' + r.summary)
        onDone()
      } else {
        const r = await api.post<{ id: number }>('/api/groups', v)
        invalidateOptions('groups')
        onDone(r.id)
      }
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title={group ? `${group.code} düzenle` : 'Yeni grup'} onCancel={onClose} onOk={save} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={group ?? { isActive: true, tenantId: 1 }}>
        {!group && <Form.Item name="tenantId" label="Tenant" rules={[{ required: true }]}><Select options={toSelectOptions(tenants)} /></Form.Item>}
        {!group && <Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input placeholder="GISE_737_AST" /></Form.Item>}
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item>
        <Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item>
      </Form>
      {!group && <Typography.Text type="secondary">Oluşturduktan sonra kitle kurallarını ve rollerini tanımlayın; yetki için bir Grup policy'si oluşturabilirsiniz.</Typography.Text>}
    </Modal>
  )
}
