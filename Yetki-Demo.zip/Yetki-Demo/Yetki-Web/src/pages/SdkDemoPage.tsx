import { Alert, Button, Card, Col, Flex, Input, Row, Select, Table, Tag, Typography } from 'antd'
import { SendOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { SAMPLE_APP_URL, api } from '../api/client'
import { useApi, useOptions } from '../hooks/useApi'
import { Code, PageGuide, PageHeader } from '../components/common'

interface Scenario {
  key: string
  title: string
  method: 'GET' | 'POST'
  path: string
  body: unknown
  /// Bu senaryonun koruduğu permission kodu. Motor RequireGrantedScopes=true iken access token'ın
  /// scope/scp claim'i istenen permission kodunu içermelidir; demo modda bu simüle scope kutusuyla yapılır.
  permission?: string
}

const scenarios: Scenario[] = [
  { key: 'create', title: 'Çekim yap (policy: mesai, limit, kendi hesabı, ağ)', method: 'POST', path: '/v1/cash-withdrawals', body: { hesapNo: 'TR120001', musteriNo: 'C-555', tutar: 20000, paraBirimi: 'TRY', subeKodu: '101' }, permission: 'anka.nakit.cekim.gise:create' },
  { key: 'limit', title: 'Limit üstü çekim (75.000)', method: 'POST', path: '/v1/cash-withdrawals', body: { hesapNo: 'TR120001', musteriNo: 'C-555', tutar: 75000 }, permission: 'anka.nakit.cekim.gise:create' },
  { key: 'read', title: 'Çekim sorgula (Anka Web kanalından: hesapNo/TCKN maskeli döner)', method: 'GET', path: '/v1/cash-withdrawals/42', body: null, permission: 'anka.nakit.cekim.gise:read' },
  { key: 'cancel', title: 'Çekim iptal (GISEYTK)', method: 'POST', path: '/v1/cash-withdrawals/42/cancel', body: {}, permission: 'anka.nakit.cekim.gise:cancel' },
  { key: 'receipt', title: 'Dekont (SDK attribute YOK → korumasız, manifest bulgusu)', method: 'GET', path: '/v1/cash-withdrawals/42/receipt', body: null },
  { key: 'vadeli-kapat', title: 'Vadeli hesap kapat (SUBEMDR)', method: 'POST', path: '/vadeli-hesap-kapatma/TR120006200001234567890111', body: { aciklama: 'Müşteri talebiyle kapatıldı' }, permission: 'anka_api.mv.vdl.vadelihesapislemleri.closedepositaccound:close' },
  { key: 'vadeli-izle', title: 'Vadeli hesap izle (SUBEAST, mesai saati kısıtlı: MESAI_SAATLERI)', method: 'GET', path: '/vadeli-hesap-izle/C-555', body: null, permission: 'anka_api.mv.vdl.vadelihesapizleme.getdepositaccound:read' },
]

const code = `// Anka mikroservisi (Anka.NakitService) — iş kodunda yetki if'i YOK
builder.Services.AddYetkiAuthorization(o =>
{
    o.EngineBaseUrl = "http://yetki-motoru";
    o.Application = "ANKA";  o.CatalogPath = "NAKIT/CEKIM/GISE";
    o.ApiCode = "nakit-cekim-gise-api";
});
app.MapYetkiManifest();   // GET /.well-known/yetki-manifest

public sealed class CashWithdrawalRequest
{
    [AuthContext(AuthContextType.AccountNo)]         public string HesapNo { get; set; }
    [AuthContext(AuthContextType.CustomerId)]        public string MusteriNo { get; set; }
    [AuthContext(AuthContextType.TransactionAmount)] public decimal Tutar { get; set; }
}

[HttpPost]
[RequiresPermission("anka.nakit.cekim.gise:create", ResourceType = "account")]
public IActionResult Create(CashWithdrawalRequest request) => Ok(...);`

export function SdkDemoPage() {
  const users = useOptions('users')
  const clients = useOptions('clients')
  const [user, setUser] = useState('ab41oyt')
  const [client, setClient] = useState('anka_api')
  const [via, setVia] = useState<string[]>([])
  const [selected, setSelected] = useState(scenarios[0])
  const [body, setBody] = useState(JSON.stringify(scenarios[0].body, null, 2))
  const [scope, setScope] = useState(scenarios[0].permission ?? '')
  const [response, setResponse] = useState<{ status: number; data: unknown }>()
  const [loading, setLoading] = useState(false)
  const manifest = useApi<{ endpoints: { method: string; path: string; permission?: string }[] }>(null)
  const [manifestData, setManifestData] = useState<{ endpoints: { method: string; path: string; permission?: string }[] }>()

  const send = async () => {
    setLoading(true)
    try {
      setResponse(await api.sample(selected.method, selected.path, selected.method === 'GET' ? null : JSON.parse(body || '{}'),
        { 'X-User': user, 'X-Client-Id': client, ...(via.length ? { 'X-Via': via.join(',') } : {}), ...(scope.trim() ? { 'X-OAuth-Scopes': scope.trim() } : {}) }))
    } catch (e) {
      setResponse({ status: 0, data: `Örnek servise ulaşılamadı (${SAMPLE_APP_URL}). samples/Anka.NakitService çalışıyor mu? ${(e as Error).message}` })
    } finally {
      setLoading(false)
    }
  }

  const loadManifest = async () => {
    try {
      setManifestData(await (await fetch(`${SAMPLE_APP_URL}/.well-known/yetki-manifest`)).json())
    } catch {
      setManifestData(undefined)
    }
  }

  return (
    <>
      <PageHeader title="Servis demosu" subtitle="Örnek bir servis üzerinde yetki kontrolünü ve veri maskelemeyi deneyin." />
      <PageGuide title="Demo ve entegrasyon bilgileri">
        <p>Örnek servis: <Code>{SAMPLE_APP_URL}</Code>. İşlemler <Code>[RequiresPermission]</Code> ile korunur.</p>
        <Alert type="info" showIcon message="Prototipte kimlik X-User / X-Client-Id / X-Via başlıklarından okunur. Üretimde doğrulanmış token kullanılır."
          description="Kanal politikası MASK_FIELDS döndürürse SDK yanıtı maskeler. Tanınmayan yükümlülüklerde erişim reddedilir." />
      </PageGuide>
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={11}>
          <Card size="small" title="İstek">
            <Flex vertical gap={8}>
              <Flex gap={8}>
                <Select showSearch optionFilterProp="label" style={{ flex: 1 }} value={user} onChange={setUser} options={users.map((u) => ({ value: u.code, label: u.label }))} />
                <Select style={{ width: 220 }} value={client} onChange={setClient} options={clients.map((c) => ({ value: c.code, label: c.code }))} />
              </Flex>
              <Select mode="multiple" allowClear placeholder="Aracı (X-Via): doğrudan" value={via} onChange={setVia} options={clients.map((c) => ({ value: c.code, label: `aracı: ${c.code}` }))} />
              <Select value={selected.key} onChange={(k) => { const s = scenarios.find((x) => x.key === k)!; setSelected(s); setBody(s.body ? JSON.stringify(s.body, null, 2) : ''); setScope(s.permission ?? '') }}
                options={scenarios.map((s) => ({ value: s.key, label: `${s.method} ${s.path} — ${s.title}` }))} />
              {selected.method !== 'GET' && <Input.TextArea rows={7} value={body} onChange={(e) => setBody(e.target.value)} style={{ fontFamily: 'monospace', fontSize: 12 }} />}
              <Input placeholder="X-OAuth-Scopes (motor RequireGrantedScopes istiyorsa boşlukla ayrılmış scope listesi)"
                value={scope} onChange={(e) => setScope(e.target.value)} style={{ fontFamily: 'monospace', fontSize: 12 }} />
              <Button type="primary" icon={<SendOutlined />} loading={loading} onClick={send}>Gönder</Button>
            </Flex>
          </Card>
          <Card size="small" title="Servis kodu" style={{ marginTop: 16 }}>
            <pre style={{ fontSize: 11, margin: 0, whiteSpace: 'pre-wrap' }}>{code}</pre>
          </Card>
        </Col>
        <Col xs={24} xl={13}>
          <Card size="small" title={<>Cevap {response && <Tag color={response.status >= 200 && response.status < 300 ? 'green' : 'red'}>HTTP {response.status}</Tag>}</>}>
            {response ? <pre style={{ fontSize: 12, margin: 0, whiteSpace: 'pre-wrap' }}>{typeof response.data === 'string' ? response.data : JSON.stringify(response.data, null, 2)}</pre>
              : <Typography.Text type="secondary">İstek gönderin. 403 cevabında reasonCode, decidingPolicy/rule ve eksik attribute'lar döner; decisionId ile audit'te bulunur.</Typography.Text>}
          </Card>
          <Card size="small" title="Servis manifesti (/.well-known/yetki-manifest)" style={{ marginTop: 16 }} extra={<Button size="small" onClick={loadManifest}>Yükle</Button>}>
            {(manifestData ?? manifest.data) && (
              <Table size="small" rowKey={(e) => e.method + e.path} pagination={false} dataSource={(manifestData ?? manifest.data)!.endpoints}
                columns={[
                  { title: 'Endpoint', render: (_, e) => <><Tag color={e.method === 'GET' ? 'green' : 'orange'}>{e.method}</Tag>{e.path}</> },
                  { title: 'Permission', dataIndex: 'permission', render: (v) => (v ? <Code>{v}</Code> : <Tag color="red">EŞLENMEMİŞ</Tag>) },
                ]} />
            )}
            <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8, marginBottom: 0 }}>Katalog → "Servis manifesti içe aktar" ile motora kaydedilir (CI/CD adımı).</Typography.Paragraph>
          </Card>
        </Col>
      </Row>
    </>
  )
}
