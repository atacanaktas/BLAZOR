import { Alert, App, AutoComplete, Breadcrumb, Button, Card, Col, Descriptions, Dropdown, Empty, Flex, Form, Input, Modal, Popconfirm, Row, Select, Table, Tabs, Tag, Tree, Typography } from 'antd'
import { ApiOutlined, AppstoreOutlined, DeleteOutlined, GlobalOutlined, ImportOutlined, KeyOutlined, PlusOutlined } from '@ant-design/icons'
import { useMemo, useState } from 'react'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import type { CatalogTreeApi, CatalogTreeApp, CatalogTreeNode, ExternalDependencyView, TargetType } from '../api/types'
import { AddDependencyButton, ExternalDependencyList, ExternalDependencyModal, ExternalTag, type DependencyOwner } from '../components/External'
import { invalidateOptions, toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { TargetPicker, invalidateCatalogTree, useCatalogTree } from '../components/Catalog'
import { ActiveTag, Code, ModeTag, TenantTag, PageHeader, SeverityTag, TargetTag } from '../components/common'

const levelLabel = 'Catalog Level'
const levelColor = 'blue'
const actionOptions = ['create', 'read', 'update', 'delete', 'approve', 'execute', 'cancel', 'close', 'export', 'view', 'print'].map((value) => ({ value }))
const methodColor: Record<string, string> = { GET: 'green', POST: 'orange', PUT: 'blue', PATCH: 'blue', DELETE: 'red' }

interface NodeDetail {
  node: { id: number; tenantId: number; code: string; name: string; type: CatalogTreeNode['type']; path: string; parentId?: number; applicationId?: number; application?: string; tenant: string; description?: string; ownerTeamId?: number; ownerTeam?: string; ownerUserId?: number }
  breadcrumb: { id: number; code: string; name: string }[]
  children: { id: number; code: string; name: string; type: CatalogTreeNode['type'] }[]
  permissions: { id: number; code: string; name: string; action: string; riskLevel: string; isActive: boolean }[]
  apis: { id: number; code: string; name: string; audience: string; endpoints: { id: number; method: string; path: string; permissionId?: number; permission?: string }[] }[]
  uiElements: { id: number; code: string; name: string; kind: string; parentId?: number; permission?: string }[]
  policies: { id: number; code: string; name: string; mode: 'Enforce' | 'ReportOnly'; isActive: boolean; tenant: string; matchedBy?: string; inherited: boolean; excludedBy?: string; onDescendants: string[] }[]
  clients: { id: number; clientId: string; name: string; allowedPermissions: string[] }[]
}

type NodeContext = NodeDetail['node']
type ApplicationInfo = { id: number; tenantId: number; tenant: string; code: string; name: string; type: string; description?: string; ownerTeamId?: number; ownerTeam?: string; ownerUserId?: number; isActive: boolean }
type CatalogOwner = { tenantId: number; applicationId?: number; catalogNodeId?: number; label: string; application?: string }
type ApiContext = { id: number; code: string; name: string }
type EndpointContext = { id: number; method: string; path: string; operationId?: string; summary?: string; permissionId?: number; permission?: string }
type CatalogDialog =
  | { kind: 'app'; tenantId?: number }
  | { kind: 'node'; tenantId?: number; parentId?: number; applicationId?: number }
  | { kind: 'permission'; node: NodeContext }
  | { kind: 'api'; owner: CatalogOwner }
  | { kind: 'endpoint'; api: ApiContext }
  | { kind: 'endpointPermission'; api: ApiContext; endpoint: EndpointContext }
  | { kind: 'import' }

export function CatalogPage() {
  const [refresh, setRefresh] = useState(0)
  const tree = useCatalogTree(refresh)
  const [params, setParams] = useSearchParams()
  const tenants = useApi<{ id: number; code: string; name: string; parentId?: number }[]>('/api/tenants')
  const selectedTenant = params.get('tenant')
  const tenant = tenants.data?.find((t) => String(t.id) === selectedTenant)
  const selectedApp = params.get('app')
  const application = tree.find((a) => !a.isTenantRoot && String(a.id) === selectedApp)
  const selected = params.get('node')
  const selectedApi = params.get('api')
  const selectedEndpoint = params.get('endpoint')
  const [search, setSearch] = useState('')
  const [dialog, setDialog] = useState<CatalogDialog>()
  const refreshTree = () => { invalidateCatalogTree(); setRefresh((r) => r + 1) }

  // Her ağaç anahtarının üst anahtarı (seçimin yolunu açmak için)
  const parentOf = useMemo(() => {
    const map = new Map<string, string>()
    const walk = (n: CatalogTreeNode, parent: string) => {
      map.set(`node:${n.id}`, parent)
      n.children.forEach((c) => walk(c, `node:${n.id}`))
      n.apiList.forEach((a) => {
        map.set(`api:${a.id}`, `node:${n.id}`)
        a.endpoints.forEach((e) => map.set(`ep:${a.id}:${e.id}`, `api:${a.id}`))
      })
    }
    tree.forEach((a) => {
      const rootKey = a.isTenantRoot ? `tenant:${a.tenantId}` : `app:${a.id}`
      if (!a.isTenantRoot) map.set(rootKey, `tenant:${a.tenantId}`)
      a.children.forEach((n) => walk(n, rootKey))
      a.apiList.forEach((api) => {
        map.set(`api:${api.id}`, rootKey)
        api.endpoints.forEach((e) => map.set(`ep:${api.id}:${e.id}`, `api:${api.id}`))
      })
    })
    return map
  }, [tree])
  const selectedKey = selectedEndpoint && selectedApi ? `ep:${selectedApi}:${selectedEndpoint}` : selectedApi ? `api:${selectedApi}` : selected ? `node:${selected}` : selectedApp ? `app:${selectedApp}` : selectedTenant ? `tenant:${selectedTenant}` : undefined
  const [expanded, setExpanded] = useState<string[]>([])
  const [expandedFor, setExpandedFor] = useState<string>()
  // Seçim (URL) veya ağaç değişince seçimin yolunu aç (render sırasında türetilmiş state; effect yok)
  const expandToken = `${selectedKey}|${tree.length}`
  if (tree.length > 0 && expandToken !== expandedFor) {
    const path: string[] = [...new Set(tree.map((a) => `tenant:${a.tenantId}`))]
    if (selectedApi) path.push(`api:${selectedApi}`) // seçili API'nin endpoint'leri de görünsün
    for (let k = selectedKey ? parentOf.get(selectedKey) : undefined; k; k = parentOf.get(k)) path.push(k)
    setExpandedFor(expandToken)
    setExpanded((prev) => [...new Set([...prev, ...path])])
  }

  const treeData = useMemo(() => {
    const q = search.toLowerCase()
    const stop = (run: () => void) => ({ domEvent }: { domEvent: React.MouseEvent | React.KeyboardEvent }) => { domEvent.stopPropagation(); run() }
    const menuTitle = (content: React.ReactNode, items: { key: string; label: string; icon?: React.ReactNode; onClick: (info: { domEvent: React.MouseEvent | React.KeyboardEvent }) => void }[]) => (
      <Dropdown trigger={['contextMenu']} menu={{ items }}><span style={{ display: 'inline-block', width: '100%' }}>{content}</span></Dropdown>
    )
    const apiMatch = (a: CatalogTreeApi) => a.code.toLowerCase().includes(q) || a.name.toLowerCase().includes(q) || a.endpoints.some((e) => e.path.toLowerCase().includes(q))
    const match = (n: CatalogTreeNode): boolean =>
      !search || n.path.toLowerCase().includes(q) || n.name.toLowerCase().includes(q) || n.children.some(match) || n.apiList.some(apiMatch)
    const apiNode = (a: CatalogTreeApi): object => ({
      key: `api:${a.id}`,
      title: menuTitle(<span><Tag color="geekblue" icon={<ApiOutlined />} style={{ marginRight: 4 }}>API</Tag>{a.code} <Typography.Text type="secondary" style={{ fontSize: 12 }}>{a.name} · {a.endpoints.length} endpoint{a.endpoints.some((e) => !e.permission) ? ' · eşlenmemiş var' : ''}{a.external.length > 0 ? ` · ${a.external.join(', ')}` : ''}</Typography.Text></span>, [
        { key: 'open', label: 'Open API', onClick: stop(() => setParams({ api: String(a.id) })) },
        { key: 'endpoint', label: 'Add Endpoint', icon: <PlusOutlined />, onClick: stop(() => { setParams({ api: String(a.id) }); setDialog({ kind: 'endpoint', api: a }) }) },
      ]),
      children: a.endpoints.map((e) => ({
        key: `ep:${a.id}:${e.id}`,
        isLeaf: true,
        title: menuTitle(<span style={{ fontSize: 12 }}><Tag color={methodColor[e.method] ?? 'default'} style={{ marginRight: 4, fontSize: 11 }}>{e.method}</Tag>{e.path} → {e.permission ? <Code>{e.permission}</Code> : <Tag color="red">EŞLENMEMİŞ</Tag>}{e.external.length > 0 && <Typography.Text type="secondary" style={{ fontSize: 11 }}> · {e.external.join(', ')}</Typography.Text>}</span>, [
          { key: 'open', label: 'Open Endpoint', onClick: stop(() => setParams({ api: String(a.id), endpoint: String(e.id) })) },
          ...(!e.permissionId ? [{ key: 'permission', label: 'Create Permission', icon: <KeyOutlined />, onClick: stop(() => { setParams({ api: String(a.id), endpoint: String(e.id) }); setDialog({ kind: 'endpointPermission', api: a, endpoint: e }) }) }] : []),
        ]),
      })),
    })
    const conv = (n: CatalogTreeNode, app: CatalogTreeApp, showAll = false): object => {
      const node: NodeContext = { id: n.id, tenantId: n.tenantId, code: n.code, name: n.name, type: n.type, path: n.path, applicationId: n.applicationId, application: n.applicationId ? app.code : undefined, tenant: app.tenant }
      const items = [
        { key: 'open', label: `Open ${levelLabel}`, onClick: stop(() => setParams({ node: String(n.id) })) },
        { key: 'child', label: 'Add Child Level', icon: <PlusOutlined />, onClick: stop(() => { setParams({ node: String(n.id) }); setDialog({ kind: 'node', tenantId: n.tenantId, parentId: n.id, applicationId: n.applicationId }) }) },
        { key: 'permission', label: 'Add Resource Permission', icon: <KeyOutlined />, onClick: stop(() => { setParams({ node: String(n.id) }); setDialog({ kind: 'permission', node }) }) },
        { key: 'api', label: 'Add API', icon: <ApiOutlined />, onClick: stop(() => { setParams({ node: String(n.id) }); setDialog({ kind: 'api', owner: { tenantId: n.tenantId, applicationId: n.applicationId, catalogNodeId: n.id, label: n.path, application: node.application } }) }) },
      ]
      return {
        key: `node:${n.id}`,
        title: menuTitle(<span><Tag color={levelColor} style={{ marginRight: 4 }}>{levelLabel}</Tag>{n.code} <Typography.Text type="secondary" style={{ fontSize: 12 }}>{n.name}{n.permissions ? ` · ${n.permissions} action` : ''}{n.apis ? ` · ${n.apis} API` : ''}</Typography.Text></span>, items),
        children: [...n.children.filter((c) => showAll || match(c)).map((c) => conv(c, app, showAll)), ...n.apiList.filter((a) => showAll || !search || n.path.toLowerCase().includes(q) || apiMatch(a)).map(apiNode)],
      }
    }
    const owners = new Map((tenants.data ?? []).map((t) => [t.id, t]))
    tree.forEach((a) => { if (!owners.has(a.tenantId)) owners.set(a.tenantId, { id: a.tenantId, code: a.tenant, name: a.tenant }) })
    return [...owners.values()].sort((a, b) => a.code.localeCompare(b.code)).map((t) => {
      const owned = tree.filter((a) => a.tenantId === t.id && !a.isTenantRoot)
      const direct = tree.find((a) => a.tenantId === t.id && a.isTenantRoot)
      const tenantMatch = !!q && (t.code.toLowerCase().includes(q) || t.name.toLowerCase().includes(q))
      const apps = owned.filter((a) => !q || tenantMatch || a.code.toLowerCase().includes(q) || a.name.toLowerCase().includes(q) || a.children.some(match) || a.apiList.some(apiMatch))
      return {
        key: `tenant:${t.id}`,
        title: menuTitle(<span><GlobalOutlined /> <b>{t.code}</b> — {t.name} <Typography.Text type="secondary" style={{ fontSize: 12 }}>({owned.length} application)</Typography.Text></span>, [
          { key: 'open', label: 'Open Tenant', onClick: stop(() => setParams({ tenant: String(t.id) })) },
          { key: 'app', label: 'Add Application', icon: <PlusOutlined />, onClick: stop(() => { setParams({ tenant: String(t.id) }); setDialog({ kind: 'app', tenantId: t.id }) }) },
          { key: 'level', label: 'Add Catalog Level', icon: <PlusOutlined />, onClick: stop(() => { setParams({ tenant: String(t.id) }); setDialog({ kind: 'node', tenantId: t.id }) }) },
          { key: 'api', label: 'Add API', icon: <ApiOutlined />, onClick: stop(() => { setParams({ tenant: String(t.id) }); setDialog({ kind: 'api', owner: { tenantId: t.id, label: t.code } }) }) },
        ]),
        children: [
          ...apps.map((a) => ({
          key: `app:${a.id}`,
          title: menuTitle(<b><AppstoreOutlined /> {a.code} — {a.name} <Typography.Text type="secondary" style={{ fontSize: 12 }}>({a.permissionCount} permission, {a.apiCount} API, {a.endpointCount} endpoint)</Typography.Text></b>, [
            { key: 'open', label: 'Open Application', onClick: stop(() => setParams({ app: String(a.id) })) },
            { key: 'level', label: 'Add Catalog Level', icon: <PlusOutlined />, onClick: stop(() => { setParams({ app: String(a.id) }); setDialog({ kind: 'node', tenantId: a.tenantId, applicationId: a.id }) }) },
            { key: 'api', label: 'Add API', icon: <ApiOutlined />, onClick: stop(() => { setParams({ app: String(a.id) }); setDialog({ kind: 'api', owner: { tenantId: a.tenantId, applicationId: a.id, label: a.code, application: a.code } }) }) },
          ]),
          children: [
            ...a.children.filter((n) => tenantMatch || a.code.toLowerCase().includes(q) || a.name.toLowerCase().includes(q) || match(n)).map((n) => conv(n, a, tenantMatch || a.code.toLowerCase().includes(q) || a.name.toLowerCase().includes(q))),
            ...a.apiList.filter((api) => tenantMatch || apiMatch(api)).map(apiNode),
          ],
        })),
          ...(direct?.children ?? []).filter((n) => tenantMatch || match(n)).map((n) => conv(n, direct!, tenantMatch)),
          ...(direct?.apiList ?? []).filter((api) => tenantMatch || apiMatch(api)).map(apiNode),
        ],
      }
    }).filter((t) => !q || t.children.length > 0 || (owners.get(Number(t.key.split(':')[1]))?.code.toLowerCase().includes(q)) || (owners.get(Number(t.key.split(':')[1]))?.name.toLowerCase().includes(q)))

  }, [tree, search, tenants.data, setParams])

  return (
    <>
      <PageHeader title="Resource Catalog"
        subtitle="Uygulamalarınızı, kaynaklarınızı ve bunlara bağlı erişim tanımlarını keşfedin."
        extra={<Flex gap={8}>
          <Button icon={<ImportOutlined />} onClick={() => setDialog({ kind: 'import' })}>Servis manifesti içe aktar</Button>
          <Button icon={<PlusOutlined />} onClick={() => setDialog({ kind: 'node' })}>Catalog Level</Button>
          <Button icon={<PlusOutlined />} onClick={() => setDialog({ kind: 'app' })}>Uygulama</Button>
        </Flex>}
      />
      <Row gutter={16}>
        <Col xs={24} xl={9}>
          <Card size="small" styles={{ body: { maxHeight: 'calc(100vh - 220px)', overflow: 'auto' } }}>
            <Input.Search placeholder="Tenant, Application, Resource, API veya Endpoint ara" allowClear onChange={(e) => setSearch(e.target.value)} style={{ marginBottom: 8 }} />
            <Tree
              showLine
              blockNode
              expandedKeys={expanded}
              onExpand={(keys) => setExpanded(keys.map(String))}
              selectedKeys={selectedKey ? [selectedKey] : []}
              treeData={treeData as never}
              onSelect={(keys) => {
                const k = String(keys[0] ?? '')
                if (k.startsWith('tenant:')) setParams({ tenant: k.slice(7) })
                else if (k.startsWith('app:')) setParams({ app: k.slice(4) })
                else if (k.startsWith('node:')) setParams({ node: k.slice(5) })
                else if (k.startsWith('api:')) setParams({ api: k.slice(4) })
                else if (k.startsWith('ep:')) { const [, apiId, endpointId] = k.split(':'); setParams({ api: apiId, endpoint: endpointId }) }
              }}
            />
          </Card>
        </Col>
        <Col xs={24} xl={15}>
          {selectedApi ? <ApiPanel key={`${selectedApi}:${selectedEndpoint ?? ''}`} apiId={Number(selectedApi)} endpointId={selectedEndpoint ? Number(selectedEndpoint) : undefined}
              onNavigateApi={() => setParams({ api: selectedApi })} onNavigateNode={(id) => setParams({ node: String(id) })} onChanged={refreshTree}
              onDeleted={() => { refreshTree(); setParams({}) }} />
            : selected ? <NodePanel key={selected} nodeId={Number(selected)} onNavigate={(id) => setParams({ node: String(id) })} onApiCreated={(id) => { refreshTree(); setParams({ api: String(id) }) }}
                onDeleted={(parentId) => { refreshTree(); setParams(parentId ? { node: String(parentId) } : {}) }} />
            : application ? <ApplicationPanel application={application} onNavigateNode={(id) => setParams({ node: String(id) })}
                onAddLevel={() => setDialog({ kind: 'node', tenantId: application.tenantId, applicationId: application.id })}
                onAddApi={() => setDialog({ kind: 'api', owner: { tenantId: application.tenantId, applicationId: application.id, label: application.code, application: application.code } })} />
            : tenant ? <Card title={<><GlobalOutlined /> {tenant.code} — {tenant.name}</>} extra={<Flex gap={6}>
                <Button size="small" icon={<PlusOutlined />} onClick={() => setDialog({ kind: 'node', tenantId: tenant.id })}>Add Catalog Level</Button>
                <Button size="small" icon={<ApiOutlined />} onClick={() => setDialog({ kind: 'api', owner: { tenantId: tenant.id, label: tenant.code } })}>Add API</Button>
                <Button type="primary" size="small" icon={<PlusOutlined />} onClick={() => setDialog({ kind: 'app', tenantId: tenant.id })}>Add Application</Button>
              </Flex>}>
              <Typography.Paragraph type="secondary">Bu Tenant’ın sahip olduğu Application’lar listelenir. Üst Tenant’tan kullanılabilen tanımlar kendi sahibinin altında gösterilir; bu liste etkin erişim listesi değildir.</Typography.Paragraph>
              {tenant.parentId && <Typography.Paragraph>Parent Tenant: <Link to={`/catalog?tenant=${tenant.parentId}`}>{tenants.data?.find((t) => t.id === tenant.parentId)?.code ?? tenant.parentId}</Link></Typography.Paragraph>}
              {tree.filter((a) => a.tenantId === tenant.id && !a.isTenantRoot).length ? tree.filter((a) => a.tenantId === tenant.id && !a.isTenantRoot).map((a) => <Card key={a.id} size="small" style={{ marginBottom: 8 }} title={a.code}>{a.name} · {a.apiCount} API · {a.endpointCount} Endpoint</Card>) : <Empty description="Bu Tenant’a ait Application yok" />}
            </Card>
            : <Card className="evaluation-empty">
              <span className="evaluation-empty-icon"><AppstoreOutlined /></span>
              <Typography.Title level={4}>Kaynaklarınızı keşfedin</Typography.Title>
              <Typography.Paragraph type="secondary">Katalogdan bir kaynak, API veya endpoint seçin. Bağlı yetkiler, politikalar ve erişim bilgileri burada gösterilir.</Typography.Paragraph>
              <div className="evaluation-steps"><span>Uygulama</span><span>Kaynak</span><span>Yetkiler</span></div>
            </Card>}
        </Col>
      </Row>
      {dialog?.kind === 'app' && <AppModal tenantId={dialog.tenantId} onClose={() => setDialog(undefined)} onDone={refreshTree} />}
      {dialog?.kind === 'node' && <NodeModal tenantId={dialog.tenantId} parentId={dialog.parentId} applicationId={dialog.applicationId} onClose={() => setDialog(undefined)} onDone={refreshTree} />}
      {dialog?.kind === 'permission' && <PermissionModal node={dialog.node} onClose={() => setDialog(undefined)} onDone={() => { refreshTree(); invalidateOptions('permissions') }} />}
      {dialog?.kind === 'api' && <ApiCreateModal owner={dialog.owner} onClose={() => setDialog(undefined)} onDone={(id) => { refreshTree(); setDialog(undefined); setParams({ api: String(id) }) }} />}
      {dialog?.kind === 'endpoint' && <EndpointCreateModal apiInfo={dialog.api} onClose={() => setDialog(undefined)} onDone={refreshTree} />}
      {dialog?.kind === 'endpointPermission' && <EndpointPermissionModal apiInfo={dialog.api} endpoint={dialog.endpoint} onClose={() => setDialog(undefined)} onDone={() => { invalidateOptions('permissions', 'endpoints'); refreshTree() }} />}
      {dialog?.kind === 'import' && <ImportModal onClose={() => setDialog(undefined)} onDone={() => { invalidateCatalogTree(); invalidateOptions('permissions', 'nodes'); setRefresh((r) => r + 1) }} />}
    </>
  )
}

function ApplicationPanel({ application, onNavigateNode, onAddLevel, onAddApi }: { application: CatalogTreeApp; onNavigateNode: (id: number) => void; onAddLevel: () => void; onAddApi: () => void }) {
  const applications = useApi<ApplicationInfo[]>('/api/catalog/applications')
  const users = useOptions('users')
  const [editing, setEditing] = useState(false)
  const detail = applications.data?.find((a) => a.id === application.id)
  return (
    <Card
      size="small"
      title={<Flex vertical gap={4}><span><AppstoreOutlined /> <b>{application.code}</b> — {application.name}</span><Typography.Text type="secondary">Application catalog root</Typography.Text></Flex>}
      extra={<Flex gap={6}><Button size="small" onClick={() => setEditing(true)}>Edit</Button><Button size="small" icon={<ApiOutlined />} onClick={onAddApi}>Add API</Button><Button type="primary" size="small" icon={<PlusOutlined />} onClick={onAddLevel}>Add Catalog Level</Button></Flex>}
    >
      <Descriptions size="small" column={{ xs: 1, md: 2 }} style={{ marginBottom: 16 }}>
        <Descriptions.Item label="Tenant"><TenantTag tenant={application.tenant} /></Descriptions.Item>
        <Descriptions.Item label="Type"><Tag>{application.type}</Tag></Descriptions.Item>
        <Descriptions.Item label="Permissions">{application.permissionCount}</Descriptions.Item>
        <Descriptions.Item label="APIs / Endpoints">{application.apiCount} / {application.endpointCount}</Descriptions.Item>
        <Descriptions.Item label="Ownership Team">{detail?.ownerTeam ?? '—'}</Descriptions.Item>
        <Descriptions.Item label="Responsible User">{users.find((u) => u.value === detail?.ownerUserId)?.label ?? '—'}</Descriptions.Item>
      </Descriptions>
      <Typography.Title level={5}>Catalog Levels</Typography.Title>
      {application.children.length === 0 ? <Empty description={<>Henüz seviye yok. <a onClick={onAddLevel}>İlk catalog level'ı ekle</a></>} /> : (
        <Row gutter={[8, 8]}>
          {application.children.map((n) => <Col xs={24} md={12} key={n.id}>
            <Card size="small" hoverable onClick={() => onNavigateNode(n.id)}>
              <Tag color={levelColor}>{levelLabel}</Tag><b>{n.code}</b><br />
              <Typography.Text type="secondary">{n.name} · {n.permissions} permission · {n.apis} API</Typography.Text>
            </Card>
          </Col>)}
        </Row>
      )}
      {editing && detail && <AppModal application={detail} tenantId={detail.tenantId} onClose={() => setEditing(false)} onDone={() => { applications.reload(); setEditing(false) }} />}
    </Card>
  )
}

function NodePanel({ nodeId, onNavigate, onApiCreated, onDeleted }: { nodeId: number; onNavigate: (id: number) => void; onApiCreated: (apiId: number) => void; onDeleted: (parentId?: number) => void }) {
  const { data, reload } = useApi<NodeDetail>(`/api/catalog/nodes/${nodeId}`)
  const [permModal, setPermModal] = useState(false)
  const [apiModal, setApiModal] = useState(false)
  const [editing, setEditing] = useState(false)
  const users = useOptions('users')
  const { message } = App.useApp()
  if (!data) return <Card loading />
  const n = data.node
  const inUse = data.children.length + data.permissions.length + data.apis.length + data.uiElements.length > 0
  const remove = async () => {
    try {
      await api.del(`/api/catalog/nodes/${n.id}`)
      message.success('Silindi')
      onDeleted(n.parentId)
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Card
      size="small"
      title={<Flex vertical gap={4}>
        <Breadcrumb items={[{ title: n.application ?? n.tenant }, ...data.breadcrumb.map((b) => ({ title: <a onClick={() => onNavigate(b.id)}>{b.code}</a> }))]} />
        <span><Tag color={levelColor}>{levelLabel}</Tag>{data.permissions.length > 0 && <Tag color="gold">RESOURCE</Tag>}{n.name} <Typography.Text type="secondary" style={{ fontSize: 12 }}>{n.path}</Typography.Text> <TenantTag tenant={n.tenant} /></span>
      </Flex>}
      extra={<Flex gap={6}>
        <Button size="small" icon={<KeyOutlined />} onClick={() => setPermModal(true)}>Action ekle</Button>
        <Button size="small" icon={<ApiOutlined />} onClick={() => setApiModal(true)}>API ekle</Button>
        <Button size="small" onClick={() => setEditing(true)}>Edit</Button>
        <Popconfirm title={`${n.code} silinsin mi?`} disabled={inUse} onConfirm={remove}>
          <Button size="small" danger icon={<DeleteOutlined />} disabled={inUse}
            title={inUse ? 'Alt düğüm, action, API veya UI öğesi olan düğüm silinemez' : undefined} />
        </Popconfirm>
      </Flex>}
    >
      {data.permissions.length > 0 && (
        <Alert type="info" showIcon style={{ marginBottom: 8 }}
          message={<>Resource <Code>{n.path}</Code> · action'lar: {data.permissions.map((p) => <Tag key={p.id} color="geekblue">{p.action}</Tag>)}</>}
          description={<>İstek: <Code>{`{ "tenant": "${n.tenant}", "resource": { "type": "${n.path}" }, "action": "${data.permissions[0].action}" }`}</Code> → permission <Code>{data.permissions[0].code}</Code></>} />
      )}
      {n.description && <Typography.Paragraph type="secondary">{n.description}</Typography.Paragraph>}
      {(n.ownerTeam || n.ownerUserId) && <Descriptions size="small" column={2} style={{ marginBottom: 12 }}>
        <Descriptions.Item label="Ownership Team">{n.ownerTeam ?? '—'}</Descriptions.Item>
        <Descriptions.Item label="Responsible User">{users.find((u) => u.value === n.ownerUserId)?.label ?? '—'}</Descriptions.Item>
      </Descriptions>}
      <Tabs
        items={[
          {
            key: 'pol',
            label: `Policy'ler (${data.policies.length})`,
            children: data.policies.length === 0 ? <Empty description="Bu düğüme (veya üstlerine) bağlı policy yok" /> : (
              <Table size="small" rowKey="id" pagination={false} dataSource={data.policies}
                columns={[
                  { title: 'Policy', render: (_, p) => <><Link to={`/policies/${p.id}`}><Code>{p.code}</Code></Link> <ModeTag mode={p.mode} />{!p.isActive && <Tag>pasif</Tag>}<br /><Typography.Text type="secondary">{p.name}</Typography.Text></> },
                  { title: 'Tenant', dataIndex: 'tenant', render: (v) => <TenantTag tenant={v} /> },
                  {
                    title: 'Bu düğüme uygulanma',
                    render: (_, p) => p.matchedBy ? (
                      <Flex vertical gap={2}>
                        <span>{p.inherited ? <Tag color="cyan">miras</Tag> : <Tag color="blue">doğrudan</Tag>} ← {p.matchedBy}</span>
                        {p.excludedBy && <span><Tag color="volcano">HARİÇ</Tag> {p.excludedBy}</span>}
                      </Flex>
                    ) : <Typography.Text type="secondary">bu düğüme değil</Typography.Text>,
                  },
                  { title: 'Alt düğümlere', dataIndex: 'onDescendants', render: (v: string[]) => v.map((x) => <Tag key={x}>{x}</Tag>) },
                ]} />
            ),
          },
          {
            key: 'perm',
            label: `Actions (${data.permissions.length})`,
            children: (
              <Table size="small" rowKey="id" pagination={false} dataSource={data.permissions}
                columns={[
                  { title: 'Action', render: (_, p) => <Link to={`/permissions/${p.id}`}><Tag color="geekblue">{p.action}</Tag></Link> },
                  { title: 'Description', dataIndex: 'name' },
                  { title: 'Risk', dataIndex: 'riskLevel', render: (v) => <SeverityTag severity={v} /> },
                  { title: '', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} /> },
                ]} />
            ),
          },
          {
            key: 'api',
            label: `API (${data.apis.length})`,
            children: data.apis.length === 0 ? <Empty description={<>Bu Catalog Level üzerinde API yok. <a onClick={() => setApiModal(true)}>API ekle</a></>} />
              : data.apis.map((a) => (
              <Card key={a.id} size="small" style={{ marginBottom: 8 }} title={<><ApiOutlined /> <Link to={`/catalog?api=${a.id}`}>{a.code}</Link> <Typography.Text type="secondary" style={{ fontSize: 12 }}>aud: {a.audience}</Typography.Text></>}>
                {a.endpoints.map((e) => (
                  <div key={e.id} style={{ fontSize: 12 }}>
                    <Tag color={e.method === 'GET' ? 'green' : 'orange'}>{e.method}</Tag>{e.path} → {e.permission ? <Code>{e.permission}</Code> : <Tag color="red">EŞLENMEMİŞ</Tag>}
                  </div>
                ))}
              </Card>
            )),
          },
          {
            key: 'ui',
            label: `Ekran/buton (${data.uiElements.length})`,
            children: (
              <Table size="small" rowKey="id" pagination={false} dataSource={data.uiElements}
                columns={[
                  { title: 'Öğe', render: (_, u) => <>{u.parentId && '└ '}<Tag>{u.kind}</Tag>{u.code} — {u.name}</> },
                  { title: 'Gerektirdiği permission', dataIndex: 'permission', render: (v) => (v ? <Code>{v}</Code> : 'yok') },
                ]} />
            ),
          },
          {
            key: 'cli',
            label: `Client'lar (${data.clients.length})`,
            children: data.clients.map((c) => <div key={c.id} style={{ marginBottom: 4 }}><Tag color="geekblue">{c.clientId}</Tag>{c.name} — {c.allowedPermissions.join(', ')}</div>),
          },
          {
            key: 'sub',
            label: `Alt düğümler (${data.children.length})`,
            children: data.children.map((c) => <div key={c.id}><a onClick={() => onNavigate(c.id)}><Tag color={levelColor}>{levelLabel}</Tag>{c.code} — {c.name}</a></div>),
          },
        ]}
      />
      {apiModal && <ApiCreateModal owner={{ tenantId: n.tenantId, applicationId: n.applicationId, catalogNodeId: n.id, label: n.path, application: n.application }} onClose={() => setApiModal(false)} onDone={(id) => { reload(); onApiCreated(id) }} />}
      {permModal && <PermissionModal node={n} onClose={() => setPermModal(false)} onDone={() => { reload(); invalidateOptions('permissions') }} />}
      {editing && <NodeModal node={n} tenantId={n.tenantId} parentId={n.parentId} applicationId={n.applicationId} onClose={() => setEditing(false)} onDone={reload} />}
    </Card>
  )
}

function AppModal({ application, tenantId, onClose, onDone }: { application?: ApplicationInfo; tenantId?: number; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const tenants = useOptions('tenants')
  const teams = useOptions('teams')
  const users = useOptions('users')
  const selectedTenantId = Form.useWatch('tenantId', form) ?? tenantId
  const tenantCode = tenants.find((t) => t.value === selectedTenantId)?.code
  const save = async () => {
    try {
      const values = await form.validateFields()
      if (application) await api.put(`/api/catalog/applications/${application.id}`, values)
      else await api.post('/api/catalog/applications', values)
      invalidateOptions('applications')
      onDone()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title={application ? `Edit ${application.code}` : 'Yeni uygulama'} onCancel={onClose} onOk={save} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={application ?? { tenantId, type: 'ApiPlatform' }}>
        <Form.Item name="tenantId" label="Sahip tenant" rules={[{ required: true }]} extra="Uygulama bu tenant ve alt tenant'larında kullanılabilir; başka tenant'lar erişemez.">
          <Select disabled={tenantId !== undefined} options={toSelectOptions(tenants)} onChange={() => form.setFieldsValue({ ownerTeamId: undefined, ownerUserId: undefined })} />
        </Form.Item>
        <Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input disabled={!!application} placeholder="INTERNET_SUBE" /></Form.Item>
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Form.Item name="type" label="Tip"><Select options={['ApiPlatform', 'Desktop', 'Mobile', 'Web', 'Batch'].map((t) => ({ value: t, label: t }))} /></Form.Item>
        <Form.Item name="isActive" label="Status"><Select options={[{ value: true, label: 'Active' }, { value: false, label: 'Passive' }]} /></Form.Item>
        <Form.Item name="ownerTeamId" label="Ownership Team" rules={[{ required: true, message: 'Ownership Team seçin' }]}>
          <Select showSearch optionFilterProp="label" options={toSelectOptions(teams.filter((t) => !tenantCode || t.group === tenantCode))} />
        </Form.Item>
        <Form.Item name="ownerUserId" label="Responsible User" rules={[{ required: true, message: 'Responsible User seçin' }]}>
          <Select showSearch optionFilterProp="label" options={toSelectOptions(users.filter((u) => !tenantCode || u.group === tenantCode))} />
        </Form.Item>
        <Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item>
      </Form>
    </Modal>
  )
}

function NodeModal({ node, tenantId, parentId, applicationId, onClose, onDone }: { node?: NodeContext; tenantId?: number; parentId?: number; applicationId?: number; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const apps = useOptions('applications')
  const tenants = useOptions('tenants')
  const nodes = useOptions('nodes')
  const teams = useOptions('teams')
  const users = useOptions('users')
  const selectedTenantId = Form.useWatch('tenantId', form) ?? tenantId
  const selectedParentId = Form.useWatch('parentId', form) ?? parentId
  const selectedApplicationId = Form.useWatch('applicationId', form) ?? applicationId
  const tenantCode = tenants.find((t) => t.value === selectedTenantId)?.code
    ?? nodes.find((n) => n.value === selectedParentId)?.group
    ?? apps.find((a) => a.value === selectedApplicationId)?.group
  const save = async () => {
    const v = await form.validateFields()
    try {
      if (node) await api.put(`/api/catalog/nodes/${node.id}`, v)
      else await api.post('/api/catalog/nodes', v)
      invalidateOptions('nodes')
      onDone()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title={node ? `Edit ${node.code}` : 'Yeni Catalog Level'} onCancel={onClose} onOk={save} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={node ?? { tenantId, parentId, applicationId }}>
        <Form.Item name="parentId" label="Parent Catalog Level">
          <Select disabled={parentId !== undefined || applicationId !== undefined || tenantId !== undefined} allowClear showSearch optionFilterProp="label" options={nodes.map((n) => ({ value: n.value, label: n.label }))} />
        </Form.Item>
        <Form.Item noStyle shouldUpdate>{({ getFieldValue }) => !getFieldValue('parentId') && (
          <>
            <Form.Item name="tenantId" label="Tenant" rules={[{ required: !getFieldValue('applicationId') }]}><Select disabled={tenantId !== undefined || applicationId !== undefined} options={toSelectOptions(tenants)} onChange={() => form.setFieldsValue({ ownerTeamId: undefined, ownerUserId: undefined })} /></Form.Item>
            <Form.Item name="applicationId" label="Application (optional)"><Select disabled={applicationId !== undefined} allowClear options={toSelectOptions(apps)} /></Form.Item>
          </>
        )}</Form.Item>
        <Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input disabled={!!node} placeholder="KART" /></Form.Item>
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Form.Item name="ownerTeamId" label="Ownership Team" rules={[{ required: true, message: 'Ownership Team seçin' }]}>
          <Select showSearch optionFilterProp="label" options={toSelectOptions(teams.filter((t) => !tenantCode || t.group === tenantCode))} />
        </Form.Item>
        <Form.Item name="ownerUserId" label="Responsible User" rules={[{ required: true, message: 'Responsible User seçin' }]}>
          <Select showSearch optionFilterProp="label" options={toSelectOptions(users.filter((u) => !tenantCode || u.group === tenantCode))} />
        </Form.Item>
      </Form>
    </Modal>
  )
}

function PermissionModal({ node, onClose, onDone }: { node: NodeDetail['node']; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const action = Form.useWatch('action', form)
  const code = `${node.path.replaceAll('/', '.').toLowerCase()}:${action ?? '...'}`
  const save = async () => {
    try {
      await api.post('/api/permissions', { ...(await form.validateFields()), catalogNodeId: node.id })
      onDone()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title={`Resource ${node.path} → yeni action`} onCancel={onClose} onOk={save} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={{ action: 'read', riskLevel: 'Medium' }}>
        <Form.Item name="action" label="Action" rules={[{ required: true }]}>
          <AutoComplete options={actionOptions} placeholder="read, create, close, approve..." />
        </Form.Item>
        <Typography.Paragraph>Resource: <Code>{node.path}</Code> · Action: <Tag color="geekblue">{action ?? '...'}</Tag></Typography.Paragraph>
        <Typography.Paragraph type="secondary" style={{ fontSize: 12 }}>Teknik anahtar sistem tarafından üretilir: <Code>{code}</Code></Typography.Paragraph>
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Form.Item name="riskLevel" label="Risk"><Select options={['Low', 'Medium', 'High', 'Critical'].map((a) => ({ value: a, label: a }))} /></Form.Item>
      </Form>
    </Modal>
  )
}

const sampleManifest = `{
  "application": "ANKA",
  "catalogPath": "KART/SANAL/ONLINE",
  "nodeNames": { "SANAL": "Sanal Kart", "ONLINE": "Online Kart İşlemleri" },
  "api": { "code": "sanal-kart-api", "name": "Sanal Kart API" },
  "endpoints": [
    { "method": "POST", "path": "/v1/virtual-cards", "action": "create", "permissionName": "Sanal kart oluştur" },
    { "method": "GET", "path": "/v1/virtual-cards/{id}", "action": "read", "permissionName": "Sanal kart görüntüle" },
    { "method": "DELETE", "path": "/v1/virtual-cards/{id}" }
  ]
}`

function ImportModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const { message } = App.useApp()
  const [text, setText] = useState(sampleManifest)
  const [report, setReport] = useState<{ api: string; createdNodes: number; createdPermissions: number; createdEndpoints: number; updatedEndpoints: number; unmappedEndpoints: string[]; warnings: string[] }>()
  const [fromUrl, setFromUrl] = useState('http://localhost:5200/.well-known/yetki-manifest')
  const run = async (body: string) => {
    try {
      setReport(await api.post('/api/catalog/import', JSON.parse(body)))
      onDone()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title="Servis manifesti içe aktar" onCancel={onClose} footer={<Button onClick={onClose}>Kapat</Button>} width={820} destroyOnHidden>
      <Typography.Paragraph type="secondary">
        SDK'lı her mikroservis <Code>/.well-known/yetki-manifest</Code> ile endpoint → permission eşlemesini yayınlar. CI/CD veya bu ekran içe aktarır;
        eksik düğüm/permission oluşturulur, eşlenmemiş endpoint'ler denetim bulgusu olarak raporlanır (motor bu endpoint'lere izin vermez).
      </Typography.Paragraph>
      <Flex gap={8} style={{ marginBottom: 8 }}>
        <Input value={fromUrl} onChange={(e) => setFromUrl(e.target.value)} />
        <Button onClick={async () => { try { const r = await fetch(fromUrl); const t = await r.text(); setText(JSON.stringify(JSON.parse(t), null, 2)) } catch (e) { message.error('Servise ulaşılamadı: ' + (e as Error).message) } }}>Servisten çek</Button>
      </Flex>
      <Input.TextArea rows={14} value={text} onChange={(e) => setText(e.target.value)} style={{ fontFamily: 'monospace', fontSize: 12 }} />
      <Button type="primary" style={{ marginTop: 8 }} onClick={() => run(text)}>İçe aktar</Button>
      {report && (
        <Alert style={{ marginTop: 12 }} type={report.unmappedEndpoints.length ? 'warning' : 'success'} showIcon
          message={`${report.api}: ${report.createdNodes} düğüm, ${report.createdPermissions} permission, ${report.createdEndpoints} yeni / ${report.updatedEndpoints} güncellenen endpoint`}
          description={<>{report.unmappedEndpoints.map((u) => <div key={u}><Tag color="red">EŞLENMEMİŞ</Tag>{u}</div>)}{report.warnings.map((w) => <div key={w}>⚠ {w}</div>)}</>} />
      )}
    </Modal>
  )
}

// ================================ Permission'lar ================================

interface PermRow {
  id: number
  code: string
  name: string
  application?: string
  tenant: string
  path: string
  sourceEndpointId?: number
  endpoint?: string
  action: string
  riskLevel: string
  isActive: boolean
  roles: string[]
  groups: string[]
}

export function PermissionsPage() {
  const [q, setQ] = useState('')
  const [app, setApp] = useState<string>()
  const [creating, setCreating] = useState(false)
  const { data, loading, reload } = useApi<PermRow[]>(`/api/permissions?q=${encodeURIComponent(q)}${app ? `&application=${app}` : ''}`)
  const apps = useOptions('applications')
  const navigate = useNavigate()
  return (
    <>
      <PageHeader title="Permissions" subtitle="Resource ve Action ilişkilerini, bunları veren Role ve Group bağlantılarıyla inceleyin."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setCreating(true)}>New Permission</Button>} />
      <Flex gap={8} style={{ marginBottom: 12 }}>
        <Input.Search placeholder="Resource, action veya açıklama" allowClear onSearch={setQ} style={{ width: 360 }} />
        <Select allowClear placeholder="Application" style={{ width: 220 }} value={app} onChange={setApp} options={apps.map((a) => ({ value: a.code, label: a.label }))} />
      </Flex>
      <Table<PermRow>
        rowKey="id"
        size="small"
        loading={loading}
        dataSource={data ?? []}
        pagination={{ pageSize: 20, showTotal: (t) => `${t} permission` }}
        rowClassName="clickable-row"
        onRow={(p) => ({ onClick: () => navigate(`/permissions/${p.id}`) })}
        columns={[
          { title: 'Resource / Endpoint', render: (_, p) => <><Code>{p.path}</Code>{p.endpoint && <><br /><Tag color="cyan">ENDPOINT</Tag><Typography.Text type="secondary">{p.endpoint}</Typography.Text></>}<br /><Typography.Text type="secondary">{p.name}</Typography.Text></>, sorter: (a, b) => a.path.localeCompare(b.path) },
          { title: 'Application', dataIndex: 'application', render: (v) => <Tag>{v}</Tag>, width: 110 },
          { title: 'Action', dataIndex: 'action', render: (v) => <Tag color="geekblue">{v}</Tag>, width: 100 },
          { title: 'Risk', dataIndex: 'riskLevel', render: (v) => <SeverityTag severity={v} />, width: 90 },
          { title: 'Roller', dataIndex: 'roles', render: (v: string[]) => v.map((r) => <Tag key={r} color="blue">{r}</Tag>) },
          { title: 'Gruplar', dataIndex: 'groups', render: (v: string[]) => v.map((g) => <Tag key={g} color="purple">{g}</Tag>) },
        ]}
      />
      {creating && <StandalonePermissionModal onClose={() => setCreating(false)} onDone={() => { reload(); invalidateOptions('permissions') }} />}
    </>
  )
}

function StandalonePermissionModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const nodes = useOptions('nodes')
  const endpoints = useOptions('endpoints')
  const sourceType = Form.useWatch('sourceType', form)
  const nodeId = Form.useWatch('catalogNodeId', form)
  const action = Form.useWatch('action', form)
  const node = nodes.find((n) => n.value === nodeId)
  const save = async () => {
    try {
      const values = await form.validateFields()
      const payload = sourceType === 'Endpoint'
        ? { apiEndpointId: values.apiEndpointId, action: String(values.action).trim().toLowerCase(), name: values.name, riskLevel: values.riskLevel }
        : { catalogNodeId: values.catalogNodeId, action: String(values.action).trim().toLowerCase(), name: values.name, riskLevel: values.riskLevel }
      const created = await api.post<{ id: number; code: string }>('/api/permissions', payload)
      message.success(`Permission oluşturuldu: ${created.code}`)
      onDone()
      onClose()
    } catch (e) {
      if (e instanceof Error) message.error(e.message)
    }
  }
  return (
    <Modal open title="New Permission" onCancel={onClose} onOk={save} okText="Create" width={680} destroyOnHidden>
      <Alert type="info" showIcon style={{ marginBottom: 16 }} message="Endpoint permission = Endpoint operation + Action"
        description="Bağımsız API operasyonları için Endpoint seçin. Aynı API içindeki birden fazla read işlemi ayrı canonical key alır." />
      <Form form={form} layout="vertical" initialValues={{ sourceType: 'Endpoint', action: 'read', riskLevel: 'Medium' }}>
        <Form.Item name="sourceType" label="Scope">
          <Select options={[{ value: 'Endpoint', label: 'Endpoint operation (recommended)' }, { value: 'Resource', label: 'Whole resource' }]} />
        </Form.Item>
        {sourceType === 'Resource' ? <Form.Item preserve={false} name="catalogNodeId" label="Resource" rules={[{ required: true, message: 'Resource seçin' }]}>
          <Select showSearch optionFilterProp="label" placeholder="Resource ara" options={nodes.map((n) => ({ value: n.value, label: n.label }))} />
        </Form.Item> : <Form.Item preserve={false} name="apiEndpointId" label="Endpoint" rules={[{ required: true, message: 'Endpoint seçin' }]}>
          <Select showSearch optionFilterProp="label" placeholder="API, method veya path ara" options={endpoints.map((e) => ({ value: e.value, label: e.label }))} />
        </Form.Item>}
        <Form.Item name="action" label="Action" rules={[{ required: true, whitespace: true, message: 'Action girin' }]}>
          <AutoComplete options={actionOptions} placeholder="read, create, close, approve..."
            filterOption={(input, option) => String(option?.value ?? '').includes(input.toLowerCase())} />
        </Form.Item>
        {sourceType === 'Resource' && node && action && <Typography.Paragraph type="secondary">
          Technical key: <Code>{`${node.code.replaceAll('/', '.').toLowerCase()}:${String(action).trim().toLowerCase()}`}</Code>
        </Typography.Paragraph>}
        <Form.Item name="name" label="Description" rules={[{ required: true, whitespace: true }]}><Input placeholder="Vadeli hesap kapat" /></Form.Item>
        <Form.Item name="riskLevel" label="Risk"><Select options={['Low', 'Medium', 'High', 'Critical'].map((value) => ({ value, label: value }))} /></Form.Item>
      </Form>
    </Modal>
  )
}

interface PermDetail {
  permission: { id: number; code: string; name: string; description?: string; action: string; resourceType?: string; riskLevel: string; isActive: boolean; application?: string; tenant: string; path: string; nodeId?: number }
  breadcrumb: { id: number; code: string; name: string }[]
  endpoints: { id: number; method: string; path: string; api: string }[]
  uiElements: { id: number; code: string; name: string; kind: string; path: string }[]
  roles: { id: number; code: string; name: string }[]
  groups: { id: number; code: string }[]
  policiesByTenant: { tenant: string; applied: { id: number; code: string; name: string; mode: 'Enforce' | 'ReportOnly'; matchedBy: string; owner: string }[]; excluded: { id: number; code: string; matchedBy: string; excludedBy: string }[] }[]
  clients: { clientId: string; name: string; allowed: boolean; via: string }[]
  holderCount: number
}

export function PermissionDetailPage() {
  const { id } = useParams()
  const { data, reload } = useApi<PermDetail>(`/api/permissions/${id}`)
  const holders = useApi<{ userId: number; userName: string; fullName: string; tenant: string; units: string[]; sources: { type: string; path: string }[] }[]>(`/api/permissions/${id}/holders`)
  const external = useApi<{
    defaultLevel: string
    requirements: { externalPermissionId: number; system: string; code: string; name?: string; resourceClass?: string; level?: string; reasons: string[] }[]
    dependencies: ExternalDependencyView[]
  }>(`/api/permissions/${id}/external`)
  const [depOwner, setDepOwner] = useState<DependencyOwner>()
  if (!data) return <Card loading />
  const p = data.permission
  return (
    <>
      <PageHeader
        title={<><Code>{p.path}</Code> <Tag color="geekblue">{p.action}</Tag></>}
        subtitle={<>{p.name} · <Tag>{p.application ?? p.tenant}</Tag> · <SeverityTag severity={p.riskLevel} /><ActiveTag active={p.isActive} /> · teknik anahtar <Code>{p.code}</Code></>}
        extra={<Link to={`/evaluate?permission=${p.code}`}><Button>Yetki testi</Button></Link>}
      />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={12}>
          <Card size="small" title="Uygulanan policy'ler (kurum bazında, hedef mirası dahil)">
            {data.policiesByTenant.map((o) => (
              <div key={o.tenant} style={{ marginBottom: 10 }}>
                <TenantTag tenant={o.tenant} />
                {o.applied.length === 0 && <Typography.Text type="secondary">kısıt yok (statik yetki)</Typography.Text>}
                {o.applied.map((x) => (
                  <div key={x.id} style={{ marginLeft: 12 }}>
                    <Link to={`/policies/${x.id}`}><Code>{x.code}</Code></Link> <ModeTag mode={x.mode} /> <Tag color="geekblue">← {x.matchedBy}</Tag>{x.owner !== o.tenant && <Tag color="cyan">{x.owner}'dan miras</Tag>}
                  </div>
                ))}
                {o.excluded.map((x) => <div key={x.id} style={{ marginLeft: 12 }}><Code>{x.code}</Code> <Tag color="volcano">HARİÇ: {x.excludedBy}</Tag></div>)}
              </div>
            ))}
          </Card>
          <Card size="small" title="Bu yetkiyi veren" style={{ marginTop: 16 }}>
            <div>Roller: {data.roles.map((r) => <Link key={r.id} to={`/roles/${r.id}`}><Tag color="blue">{r.code}</Tag></Link>)}{data.roles.length === 0 && '—'}</div>
            <div style={{ marginTop: 6 }}>Gruplar: {data.groups.map((g) => <Link key={g.id} to={`/groups/${g.id}`}><Tag color="purple">{g.code}</Tag></Link>)}{data.groups.length === 0 && '—'}</div>
          </Card>
          <Card size="small" title="Hangi uygulamalardan (client) kullanılabilir?" style={{ marginTop: 16 }}>
            {data.clients.map((c) => <div key={c.clientId}>{c.allowed ? <Tag color="green">izinli</Tag> : <Tag>kapsam dışı</Tag>}<b>{c.clientId}</b> {c.via && <Typography.Text type="secondary">({c.via})</Typography.Text>}</div>)}
          </Card>
        </Col>
        <Col xs={24} xl={12}>
          <Card size="small" title="Teknik bağlantılar">
            <Descriptions size="small" column={1}>
              <Descriptions.Item label="Endpoint'ler">{data.endpoints.length === 0 ? '—' : data.endpoints.map((e) => <div key={e.id}><Tag color={e.method === 'GET' ? 'green' : 'orange'}>{e.method}</Tag>{e.api}{e.path}</div>)}</Descriptions.Item>
              <Descriptions.Item label="Ekran/buton">{data.uiElements.length === 0 ? '—' : data.uiElements.map((u) => <div key={u.id}><Tag>{u.kind}</Tag>{u.code} — {u.name} <Typography.Text type="secondary">({u.path})</Typography.Text></div>)}</Descriptions.Item>
            </Descriptions>
          </Card>
          <Card size="small" style={{ marginTop: 16 }}
            title="Dış sistem gereksinimi (RACF / LDAP)"
            extra={<AddDependencyButton label="doğrudan bağımlılık" onClick={() => setDepOwner({ permissionId: p.id, label: p.code })} />}>
            <Typography.Paragraph type="secondary" style={{ fontSize: 12 }}>
              Bu yetkiyi alan kullanıcıya dış sistemde açılanlar: eşlenen endpoint'lerin ve API'lerinin bağımlılıkları + doğrudan bağımlılıklar + zincir.
              Seviye verilmemişse action'dan türetilir (<b>{p.action}</b> → <b>{external.data?.defaultLevel?.toUpperCase()}</b>).
            </Typography.Paragraph>
            {(external.data?.requirements.length ?? 0) === 0 ? <Typography.Text type="secondary">Dış sistem gereksinimi yok.</Typography.Text> : (
              <Table size="small" rowKey="externalPermissionId" pagination={false} dataSource={external.data!.requirements}
                columns={[
                  { title: 'Dış yetki', render: (_, x) => <><ExternalTag system={x.system} code={x.code} resourceClass={x.resourceClass} level={x.level} /><br /><Typography.Text type="secondary" style={{ fontSize: 12 }}>{x.name}</Typography.Text></>, width: 260 },
                  { title: 'Neden', dataIndex: 'reasons', render: (v: string[]) => v.map((r, i) => <div key={i} style={{ fontSize: 12 }}>{r}</div>) },
                ]} />
            )}
            <div style={{ marginTop: 8 }}>
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>Tanımlı bağımlılıklar (kaldırmadan önce etki gösterilir): </Typography.Text>
              <ExternalDependencyList deps={external.data?.dependencies ?? []} showOwner onChanged={() => { external.reload(); reload() }} />
            </div>
          </Card>
          {depOwner && <ExternalDependencyModal owner={depOwner} onClose={() => setDepOwner(undefined)} onDone={() => { external.reload(); reload() }} />}
          <Card size="small" title={`Kimde var, neden? (${data.holderCount})`} style={{ marginTop: 16 }}>
            <Table size="small" rowKey="userId" dataSource={holders.data ?? []} pagination={{ pageSize: 10 }}
              columns={[
                { title: 'Kullanıcı', render: (_, h) => <><Link to={`/users/${h.userId}`}>{h.userName}</Link> <TenantTag tenant={h.tenant} />{h.units.map((u) => <Tag key={u}>{u}</Tag>)}</> },
                { title: 'Kaynak', dataIndex: 'sources', render: (v: { path: string }[]) => v.map((s, i) => <div key={i} style={{ fontSize: 12 }}>{s.path}</div>) },
              ]} />
          </Card>
        </Col>
      </Row>
    </>
  )
}

// ================================ API & endpoint ================================

interface ApiDetail {
  api: {
    id: number; code: string; name: string; audience: string; isActive: boolean; path: string; nodeId?: number; application?: string; tenant: string
    breadcrumb: { id: number; code: string; name: string }[]
  }
  endpoints: { id: number; method: string; path: string; operationId?: string; summary?: string; permissionId?: number; permission?: string }[]
}

/** API paneli: endpoint'ler ve endpoint → permission eşlemesi. Katalog ağacında API seçilince sağda açılır. */
function ApiPanel({ apiId, endpointId, onNavigateApi, onNavigateNode, onChanged, onDeleted }: { apiId: number; endpointId?: number; onNavigateApi: () => void; onNavigateNode: (nodeId: number) => void; onChanged?: () => void; onDeleted: () => void }) {
  const { data, reload } = useApi<ApiDetail>(`/api/apis/${apiId}`)
  const deps = useApi<ExternalDependencyView[]>(`/api/external/dependencies?forApi=${apiId}`)
  const perms = useOptions('permissions')
  const { message } = App.useApp()
  const [adding, setAdding] = useState(false)
  const [creatingPermissionFor, setCreatingPermissionFor] = useState<ApiDetail['endpoints'][number]>()
  const [depOwner, setDepOwner] = useState<DependencyOwner>()
  const [form] = Form.useForm()
  if (!data) return <Card loading />
  const a = data.api
  const changed = () => { invalidateOptions('permissions', 'endpoints'); reload(); deps.reload(); onChanged?.() }
  const apiDeps = (deps.data ?? []).filter((d) => d.apiId === a.id)
  const endpointDeps = (endpointId: number) => (deps.data ?? []).filter((d) => d.endpointId === endpointId)
  const setPermission = async (endpointId: number, permissionId?: number) => {
    try {
      await api.put(`/api/endpoints/${endpointId}`, { permissionId })
      changed()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  // Önce bu alt modülün kendi action'ları, sonra diğer permission'lar
  const own = a.path.toLowerCase().split('/').join('.') + ':'
  const permOptions = [...perms].sort((x, y) => Number(!x.code.startsWith(own)) - Number(!y.code.startsWith(own)) || x.code.localeCompare(y.code))
  const unmapped = data.endpoints.filter((e) => !e.permissionId).length
  const currentEndpoint = endpointId ? data.endpoints.find((e) => e.id === endpointId) : undefined
  const visibleEndpoints = currentEndpoint ? [currentEndpoint] : data.endpoints
  const apiInUse = data.endpoints.length + apiDeps.length > 0
  const deleteApi = async () => {
    try {
      await api.del(`/api/apis/${a.id}`)
      message.success('Silindi')
      onDeleted()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  const deleteEndpoint = async (e: ApiDetail['endpoints'][number]) => {
    try {
      await api.del(`/api/endpoints/${e.id}`)
      message.success('Silindi')
      changed()
    } catch (err) {
      message.error((err as Error).message)
    }
  }
  return (
    <Card
      size="small"
      title={<Flex vertical gap={4}>
        <Breadcrumb items={[{ title: a.application ?? a.tenant }, ...a.breadcrumb.map((b) => ({ title: <a onClick={() => onNavigateNode(b.id)}>{b.code}</a> })), { title: <a onClick={onNavigateApi}>{a.code}</a> }, ...(currentEndpoint ? [{ title: `${currentEndpoint.method} ${currentEndpoint.path}` }] : [])]} />
        <span>{currentEndpoint ? <Tag color={methodColor[currentEndpoint.method] ?? 'default'}>ENDPOINT</Tag> : <Tag color="geekblue" icon={<ApiOutlined />}>API</Tag>}{currentEndpoint ? <Code>{`${currentEndpoint.method} ${currentEndpoint.path}`}</Code> : a.name} <TenantTag tenant={a.tenant} />{!a.isActive && <Tag>pasif</Tag>}</span>
      </Flex>}
      extra={<Flex gap={6}>
        {currentEndpoint && <Button size="small" onClick={onNavigateApi}>All endpoints</Button>}
        {currentEndpoint && !currentEndpoint.permissionId && <Button size="small" type="primary" icon={<KeyOutlined />} onClick={() => setCreatingPermissionFor(currentEndpoint)}>Create Permission</Button>}
        {!currentEndpoint && <Button size="small" icon={<PlusOutlined />} onClick={() => setAdding(true)}>Endpoint ekle</Button>}
        {!currentEndpoint && (
          <Popconfirm title={`${a.code} silinsin mi?`} disabled={apiInUse} onConfirm={deleteApi}>
            <Button size="small" danger icon={<DeleteOutlined />} disabled={apiInUse}
              title={apiInUse ? 'Endpoint veya dış sistem bağımlılığı olan API silinemez' : undefined} />
          </Popconfirm>
        )}
      </Flex>}
    >
      <Descriptions size="small" column={1} style={{ marginBottom: 12 }}>
        <Descriptions.Item label="Audience (JWT aud)"><Code>{a.audience}</Code></Descriptions.Item>
        <Descriptions.Item label="Catalog owner">{a.path}</Descriptions.Item>
        <Descriptions.Item label="Dış sistem (tüm endpoint'ler)">
          <Flex wrap gap={4} align="center">
            <ExternalDependencyList deps={apiDeps} onChanged={changed} />
            <AddDependencyButton onClick={() => setDepOwner({ apiId: a.id, label: `API ${a.code}` })} />
          </Flex>
        </Descriptions.Item>
      </Descriptions>
      {unmapped > 0 && <Alert type="warning" showIcon style={{ marginBottom: 8 }} message={`${unmapped} endpoint hiçbir permission'a eşlenmemiş — motor bu endpoint'lere izin vermez (fail-closed)`} />}
      {currentEndpoint && <Alert type={currentEndpoint.permissionId ? 'success' : 'warning'} showIcon style={{ marginBottom: 8 }}
        message={currentEndpoint.permissionId ? 'Endpoint doğrudan bir Permission ile korunuyor' : 'Endpoint unmapped; authorization engine fail-closed davranır'}
        description={currentEndpoint.operationId ? <>Operation ID: <Code>{currentEndpoint.operationId}</Code></> : 'Canonical permission key HTTP method ve path üzerinden üretilecektir.'} />}
      <Table size="small" rowKey="id" dataSource={visibleEndpoints} pagination={false} scroll={{ x: 'max-content' }}
        locale={{ emptyText: 'Endpoint yok — "Endpoint ekle" ile ekleyin veya servis manifestini içe aktarın' }}
        columns={[
          { title: 'Metod', dataIndex: 'method', render: (v) => <Tag color={methodColor[v] ?? 'default'}>{v}</Tag>, width: 80 },
          { title: 'Path', dataIndex: 'path', render: (v) => <Code>{v}</Code> },
          {
            title: 'Permission (endpoint → Resource + Action)',
            render: (_, e) => (
              <Select allowClear showSearch optionFilterProp="label" style={{ width: 340 }} value={e.permissionId} placeholder="EŞLENMEMİŞ (motor reddeder)"
                status={e.permissionId ? undefined : 'error'} options={toSelectOptions(permOptions)} onChange={(v) => setPermission(e.id, v)} />
            ),
          },
          {
            title: '', width: 145,
            render: (_, e) => !e.permissionId && <Button size="small" type="primary" icon={<KeyOutlined />} onClick={() => setCreatingPermissionFor(e)}>Create Permission</Button>,
          },
          {
            title: 'Dış sistem (RACF/LDAP)',
            render: (_, e) => (
              <Flex wrap gap={2} align="center" style={{ minWidth: 220 }}>
                <ExternalDependencyList deps={endpointDeps(e.id)} onChanged={changed} />
                <Button size="small" type="dashed" icon={<PlusOutlined />} onClick={() => setDepOwner({ endpointId: e.id, label: `${e.method} ${a.code}${e.path}` })} />
              </Flex>
            ),
          },
          {
            width: 50, render: (_, e) => {
              const endpointInUse = !!e.permissionId || endpointDeps(e.id).length > 0
              return (
                <Popconfirm title={`${e.method} ${e.path} silinsin mi?`} disabled={endpointInUse} onConfirm={() => deleteEndpoint(e)}>
                  <Button size="small" type="text" danger disabled={endpointInUse}
                    title={endpointInUse ? 'Permission veya dış sistem bağımlılığı olan endpoint silinemez' : undefined}>sil</Button>
                </Popconfirm>
              )
            },
          },
        ]} />
      {apiDeps.length > 0 && <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8 }}>
        API seviyesindeki bağımlılıklar tüm endpoint'lere miras geçer. Kullanıcı endpoint'e değil permission'a yetkilendirilir: permission'ı alan kişiye, eşlendiği endpoint'lerin ve API'nin dış bağımlılıkları (ve zincirleri) dış sistemde açılır.
      </Typography.Paragraph>}
      {depOwner && <ExternalDependencyModal owner={depOwner} onClose={() => setDepOwner(undefined)} onDone={changed} />}
      {creatingPermissionFor && <EndpointPermissionModal apiInfo={a} endpoint={creatingPermissionFor} onClose={() => setCreatingPermissionFor(undefined)} onDone={changed} />}
      <Modal open={adding} title={`${a.code} → endpoint ekle`} onCancel={() => setAdding(false)} destroyOnHidden
        onOk={async () => { try { await api.post(`/api/apis/${a.id}/endpoints`, await form.validateFields()); setAdding(false); changed() } catch (e) { message.error((e as Error).message) } }}>
        <Form form={form} layout="vertical" initialValues={{ method: 'GET' }}>
          <Form.Item name="method" label="Metod"><Select options={['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].map((m) => ({ value: m, label: m }))} /></Form.Item>
          <Form.Item name="path" label="Path şablonu" rules={[{ required: true }]}><Input placeholder="/v1/customers/{id}" /></Form.Item>
          <Form.Item name="operationId" label="Operation ID" extra="Permission canonical key için kararlı iş operasyonu adı. Boşsa method + path kullanılır."><Input placeholder="getCustomerDetail" /></Form.Item>
          <Form.Item name="summary" label="Açıklama"><Input /></Form.Item>
          <Form.Item name="permissionId" label="Permission (Resource + Action)" extra="Boş bırakılırsa endpoint eşlenmemiş kalır ve motor reddeder.">
            <Select allowClear showSearch optionFilterProp="label" options={toSelectOptions(permOptions)} />
          </Form.Item>
        </Form>
      </Modal>
    </Card>
  )
}

function EndpointCreateModal({ apiInfo, onClose, onDone }: { apiInfo: ApiContext; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const save = async () => {
    try {
      await api.post(`/api/apis/${apiInfo.id}/endpoints`, await form.validateFields())
      message.success('Endpoint oluşturuldu')
      invalidateOptions('endpoints')
      onDone()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title={`${apiInfo.code} → Add Endpoint`} okText="Create" onOk={save} onCancel={onClose} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={{ method: 'GET' }}>
        <Form.Item name="method" label="HTTP Method"><Select options={['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].map((m) => ({ value: m, label: m }))} /></Form.Item>
        <Form.Item name="path" label="Path template" rules={[{ required: true }]}><Input placeholder="/v1/customers/{id}" /></Form.Item>
        <Form.Item name="operationId" label="Operation ID" extra="Permission canonical key için kararlı iş operasyonu adı."><Input placeholder="getCustomerDetail" /></Form.Item>
        <Form.Item name="summary" label="Description"><Input /></Form.Item>
      </Form>
    </Modal>
  )
}

function EndpointPermissionModal({ apiInfo, endpoint, onClose, onDone }: {
  apiInfo: { code: string }; endpoint: EndpointContext; onClose: () => void; onDone: () => void
}) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const action = Form.useWatch('action', form)
  const save = async () => {
    try {
      const values = await form.validateFields()
      const created = await api.post<{ id: number; code: string }>('/api/permissions', {
        apiEndpointId: endpoint.id,
        action: String(values.action).trim().toLowerCase(),
        name: values.name,
        riskLevel: values.riskLevel,
      })
      message.success(`Permission oluşturuldu ve endpoint'e bağlandı: ${created.code}`)
      onDone()
      onClose()
    } catch (e) {
      if (e instanceof Error) message.error(e.message)
    }
  }
  return (
    <Modal open title="Create Endpoint Permission" okText="Create & Map" onOk={save} onCancel={onClose} destroyOnHidden width={680}>
      <Alert type="info" showIcon style={{ marginBottom: 16 }}
        message={<><Code>{apiInfo.code}</Code> · <Tag color={methodColor[endpoint.method] ?? 'default'}>{endpoint.method}</Tag><Code>{endpoint.path}</Code></>}
        description={endpoint.operationId ? <>Canonical key, operation ID <Code>{endpoint.operationId}</Code> üzerinden üretilecek.</> : 'Operation ID bulunmadığı için canonical key method + path üzerinden üretilecek.'} />
      <Form form={form} layout="vertical" initialValues={{ action: endpoint.method === 'GET' ? 'read' : 'execute', name: endpoint.summary ?? endpoint.operationId ?? `${endpoint.method} ${endpoint.path}`, riskLevel: 'Medium' }}>
        <Form.Item name="action" label="Action" rules={[{ required: true, whitespace: true }]}>
          <AutoComplete options={actionOptions} placeholder="read, create, close, approve..." />
        </Form.Item>
        {action && <Typography.Paragraph type="secondary">Result: endpoint operation + <Code>{String(action).trim().toLowerCase()}</Code>; exact canonical key backend tarafından üretilecektir.</Typography.Paragraph>}
        <Form.Item name="name" label="Permission name" rules={[{ required: true, whitespace: true }]}><Input /></Form.Item>
        <Form.Item name="riskLevel" label="Risk"><Select options={['Low', 'Medium', 'High', 'Critical'].map((value) => ({ value, label: value }))} /></Form.Item>
      </Form>
    </Modal>
  )
}

/** Tenant, Application veya herhangi bir Catalog Level altına API ekler. */
function ApiCreateModal({ owner, onClose, onDone }: { owner: CatalogOwner; onClose: () => void; onDone: (apiId: number) => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const code = Form.useWatch('code', form) as string | undefined
  const save = async () => {
    const v = await form.validateFields()
    try {
      const r = await api.post<{ id: number }>('/api/apis', { ...v, tenantId: owner.tenantId, applicationId: owner.applicationId, catalogNodeId: owner.catalogNodeId })
      message.success('API eklendi')
      onClose()
      onDone(r.id)
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title={`${owner.label} → yeni API`} okText="Oluştur" onOk={save} onCancel={onClose} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={{ version: 'v1', basePath: '/v1' }}>
        <Form.Item name="code" label="API kodu" rules={[{ required: true }]} extra="Küçük harf, tekil (ör. musteri-api)"><Input placeholder="musteri-api" /></Form.Item>
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input placeholder="Müşteri API" /></Form.Item>
        <Form.Item name="audience" label="Audience" extra={`Boşsa: api://${(owner.application ?? owner.label).toLowerCase()}/${code || '{kod}'}`}><Input /></Form.Item>
        <Row gutter={8}>
          <Col span={12}><Form.Item name="version" label="Versiyon"><Input /></Form.Item></Col>
          <Col span={12}><Form.Item name="basePath" label="Base path"><Input /></Form.Item></Col>
        </Row>
      </Form>
    </Modal>
  )
}

// ================================ Client'lar ================================

interface ClientRow {
  id: number
  tenantId: number
  tenant: string
  clientId: string
  name: string
  type: 'Confidential' | 'Public' | 'Service' | 'Intermediary'
  isActive: boolean
  description?: string
  application?: string
  applicationId?: number
  serviceAccount?: string
  serviceAccountUserId?: number
  allowedPermissions: { id: number; targetType: TargetType; targetId?: number; description: string; actions?: string }[]
  reachablePermissions: number
}

export function ClientsPage() {
  const { data, loading, reload } = useApi<ClientRow[]>('/api/clients')
  const [permissionFor, setPermissionFor] = useState<ClientRow>()
  const [editing, setEditing] = useState<ClientRow | 'new' | null>(null)
  const { message } = App.useApp()
  return (
    <>
      <PageHeader title="OAuth Clients" subtitle="Client kayıtlarını ve önceden izin verilen Permission kapsamlarını yönetin. Token'a verilen runtime scope'lar ayrıca doğrulanır."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setEditing('new')}>Yeni client</Button>} />
      <Alert type="info" showIcon style={{ marginBottom: 12 }}
        message="Örnek: Zeynep EFT yetkisine sahip; ama mobil-sube-tablet ANKA/ODEME kapsamında değil → mobil tabletten EFT gönderemez, Nextral'dan gönderebilir. Kullanıcının rolüyle oynamaya gerek yok."
        description="Aracı (gateway / BFF) isteği BAŞLATMAZ: kullanıcı token'ını ve orijinal client'ı (azp) iletir; kararda 'via' olarak doğrulanır. Aracının kapsamı = iletebileceği API'ler. Aracı client olarak gelirse istek reddedilir (yoksa mobilin 'sadece okuma' kısıtı gateway üzerinden delinirdi)." />
      <Table<ClientRow>
        rowKey="id"
        loading={loading}
        dataSource={data ?? []}
        pagination={false}
        columns={[
          { title: 'client_id', render: (_, c) => <><b>{c.clientId}</b><br /><Typography.Text type="secondary">{c.name}</Typography.Text></> },
          { title: 'Tenant', dataIndex: 'tenant', render: (v) => <TenantTag tenant={v} />, width: 100 },
          { title: 'Tip', render: (_, c) => <><Tag color={c.type === 'Service' ? 'purple' : c.type === 'Public' ? 'orange' : c.type === 'Intermediary' ? 'magenta' : 'blue'}>{c.type === 'Intermediary' ? 'Aracı (gateway/BFF)' : c.type}</Tag>{c.serviceAccount && <div style={{ fontSize: 12 }}>servis hesabı: {c.serviceAccount}</div>}</> },
          { title: 'Uygulama', dataIndex: 'application', render: (v) => v && <Tag>{v}</Tag> },
          {
            title: 'Allowed Permissions',
            render: (_, c) => (
              <Flex wrap gap={4}>
                {c.allowedPermissions.map((g) => <TargetTag key={g.id} type={g.targetType} description={g.description} actions={g.actions} closable
                  onClose={async () => { try { await api.del(`/api/client-permission-grants/${g.id}`); reload() } catch (e) { message.error((e as Error).message) } }} />)}
                <Button size="small" type="dashed" icon={<PlusOutlined />} onClick={() => setPermissionFor(c)}>izin ekle</Button>
              </Flex>
            ),
          },
          { title: 'Erişilebilir yetki', dataIndex: 'reachablePermissions', width: 120 },
          { title: '', render: (_, c) => <><ActiveTag active={c.isActive} /><Button size="small" type="link" onClick={() => setEditing(c)}>düzenle</Button></>, width: 150 },
        ]}
      />
      {permissionFor && <AllowedPermissionModal client={permissionFor} onClose={() => setPermissionFor(undefined)} onDone={reload} />}
      {editing && <ClientModal client={editing === 'new' ? undefined : editing} onClose={() => setEditing(null)} onDone={() => { reload(); invalidateOptions('clients') }} />}
    </>
  )
}

function AllowedPermissionModal({ client, onClose, onDone }: { client: ClientRow; onClose: () => void; onDone: () => void }) {
  const [target, setTarget] = useState<{ targetType: TargetType; targetId?: number }>()
  const [actions, setActions] = useState<string[]>([])
  const { message } = App.useApp()
  return (
    <Modal open title={`${client.clientId} → allowed permission ekle`} onCancel={onClose} okButtonProps={{ disabled: !target }} destroyOnHidden width={720}
      onOk={async () => { try { await api.post(`/api/clients/${client.id}/allowed-permissions`, { ...target, actions: actions.join(',') || undefined }); onDone(); onClose() } catch (e) { message.error((e as Error).message) } }}>
      <TargetPicker value={target} onChange={setTarget} />
      <Typography.Text style={{ display: 'block', marginTop: 12 }}>Sadece şu eylemler (boş = tümü):</Typography.Text>
      <Select mode="tags" style={{ width: '100%' }} value={actions} onChange={setActions} options={['read', 'view', 'create', 'update', 'approve', 'execute', 'export'].map((a) => ({ value: a, label: a }))} />
    </Modal>
  )
}

function ClientModal({ client, onClose, onDone }: { client?: ClientRow; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const tenants = useOptions('tenants')
  const apps = useOptions('applications')
  const users = useOptions('users')
  const { message } = App.useApp()
  const type = Form.useWatch('type', form)
  const save = async () => {
    const v = await form.validateFields()
    try {
      if (client) await api.put(`/api/clients/${client.id}`, v)
      else await api.post('/api/clients', v)
      onDone()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title={client ? client.clientId : 'Yeni client'} onCancel={onClose} onOk={save} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={client ?? { type: 'Confidential', isActive: true }}>
        <Form.Item name="tenantId" label="Kayıtlı olduğu tenant" rules={[{ required: true }]} extra="Sonradan değiştirilemez. Client bu tenant ve alt tenant'larının isteklerinde kullanılabilir.">
          <Select disabled={!!client} options={toSelectOptions(tenants)} />
        </Form.Item>
        <Form.Item name="clientId" label="client_id" rules={[{ required: true }]}><Input disabled={!!client} placeholder="internet-sube-web" /></Form.Item>
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Form.Item name="type" label="Tip" extra="Aracı: gateway / BFF / kullanıcı adına başka API çağıran servis — isteği başlatmaz, 'via' zincirinde yer alır.">
          <Select options={[{ value: 'Confidential', label: 'Confidential' }, { value: 'Public', label: 'Public' }, { value: 'Service', label: 'Service (client credentials)' }, { value: 'Intermediary', label: 'Aracı (gateway / BFF)' }]} />
        </Form.Item>
        {type === 'Service' && <Form.Item name="serviceAccountUserId" label="Servis hesabı" rules={[{ required: true }]}><Select showSearch optionFilterProp="label" options={toSelectOptions(users.filter((u) => u.code.startsWith('svc.')))} /></Form.Item>}
        <Form.Item name="applicationId" label="Uygulama"><Select allowClear options={toSelectOptions(apps)} /></Form.Item>
        <Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item>
      </Form>
    </Modal>
  )
}

