import { Alert, Button, Collapse, Table, Tabs, Tag } from 'antd'
import { ArrowRightOutlined, ReloadOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useApi } from '../hooks/useApi'
import { DecisionTag, PageHeader, fmt } from '../components/common'
import { visualWorkspace, workspaces } from '../layout/navigation'
import './DashboardPage.css'

interface Dashboard {
  modelVersion: number
  modelBuiltAt: string
  counts: Record<string, number>
  decisionsLast24h: { decision: string; count: number }[]
  recentDecisions: { id: string; timestamp: string; subjectUserName?: string; clientId?: string; permissionCode?: string; decision: string; reasonCode: string }[]
  recentChanges: { id: string; timestamp: string; actor: string; action: string; summary: string }[]
}


export function DashboardPage() {
  const { data, loading, error, reload } = useApi<Dashboard>('/api/dashboard')
  const [active, setActive] = useState('management')
  const current = workspaces.find((s) => s.key === active)!
  const number = (key: string) => data ? (data.counts[key] ?? 0).toLocaleString('tr-TR') : '—'
  return (
    <div className="dashboard task-dashboard">
      <PageHeader title="Workspace" subtitle="Yapmak istediğiniz işle başlayın."
        extra={<Button icon={<ReloadOutlined />} onClick={reload} loading={loading}>Yenile</Button>} />
      {error && <Alert type="error" showIcon title="Veriler yüklenemedi" description={error}
        action={<Button onClick={reload}>Tekrar dene</Button>} />}
      <section className="task-workspace" aria-label="İş grupları">
        <div className="task-workspace-heading">
          <div className="workspace-heading-copy"><span>ACCESS OPERATIONS</span><h2>Bugün ne yapmak istiyorsunuz?</h2><p>Bilginin sahipliğine göre ayrılmış çalışma alanlarından devam edin.</p></div>
          <div className="workspace-network" aria-hidden="true"><i /><i /><i /><i /><i /><i /></div>
          <div className="workspace-hero-signature"><span className="signature-shield">Y</span><div><strong>yetki.</strong><small>ERİŞİM YÖNETİMİ</small></div></div>
        </div>
        <div className="task-workspace-body">
          <div className="task-group-list" role="tablist" aria-label="İş grubu">
            {workspaces.map((group, i) => <button key={group.key} id={'tab-' + group.key} type="button"
              role="tab" aria-selected={active === group.key} aria-controls="workspace-tasks"
              className={active === group.key ? 'is-active' : ''} onClick={() => setActive(group.key)}
              onKeyDown={(e) => {
                if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(e.key)) return
                e.preventDefault()
                const index = e.key === 'Home' ? 0 : e.key === 'End' ? workspaces.length - 1 : (i + (e.key === 'ArrowDown' ? 1 : -1) + workspaces.length) % workspaces.length
                setActive(workspaces[index].key)
                document.getElementById('tab-' + workspaces[index].key)?.focus()
              }}>
              <span className="task-group-icon">{group.icon}</span><span>{group.label}</span><ArrowRightOutlined />
            </button>)}
          </div>
          <div className="task-group-content" id="workspace-tasks" role="tabpanel" aria-labelledby={'tab-' + active}>
            <div className="task-group-intro"><h3>{current.label}</h3><p>{current.description}</p><span className="workspace-owner">{current.owner}</span></div>
            <div className="task-links" key={active}>
              {current.children.map((item) => <Link key={item.key} to={item.key} className="task-link">
                <span className="task-link-icon">{item.icon}</span><span><strong>{item.task}</strong><small>{item.hint}</small></span><ArrowRightOutlined />
              </Link>)}

            </div>
          </div>
        </div>
      </section>

      <section className="visual-workspace" aria-labelledby="visual-title">
        <div className="workspace-section-heading"><div><h2 id="visual-title">All-in-One <Tag>Demos & Prototypes · 3 alternatif</Tag></h2><p>Üç tasarım alternatifi birlikte; seçilecek sürüm üzerinden devam edilecek.</p></div></div>
        <div className="visual-variants">
          {visualWorkspace.children.map((item, i) => <Link to={item.key} key={item.key}>
            <span className="variant-number">0{i + 1}</span><span className="variant-copy"><strong>{item.label}</strong><small>{item.hint}</small></span>
            <span className={`variant-map map-${i + 1}`} aria-hidden="true"><i /><i /><i /><i /><i /></span><ArrowRightOutlined />
          </Link>)}
        </div>
      </section>

      <section className="workspace-monitor" aria-labelledby="monitor-title">
        <div className="workspace-section-heading"><div><h2 id="monitor-title">Operational Overview</h2><p>Takip gerektiren kayıtlar ve sistem özeti.</p></div></div>
        <div className="workspace-followups">
          {[
            { key: 'openViolations', title: 'Open SoD Violations', hint: 'Çakışan erişimleri incele', to: '/sod?tab=v' },
            { key: 'unmappedEndpoints', title: 'Unmapped Endpoints', hint: 'Permission bağlantılarını tamamla', to: '/catalog' },
            { key: 'pendingEvents', title: 'Pending Events', hint: 'Aktarım durumunu incele', to: '/events' },
          ].map((item) => <Link key={item.key} to={item.to}><div><strong>{item.title}</strong><small>{item.hint}</small></div><span className={`${data?.counts[item.key] ? 'has-items' : ''} ${loading ? 'metric-loading' : ''}`}>{number(item.key)}</span><ArrowRightOutlined /></Link>)}
        </div>
        <Collapse className="workspace-details" items={[
          { key: 'inventory', label: 'Inventory', extra: 'Users · Roles · Resources · Policies', children: <div className="inventory-grid">
            {[
              ['users', 'Users', '/users'], ['roles', 'Roles', '/roles'], ['groups', 'Groups', '/groups'],
              ['tenants', 'Tenants', '/tenants'], ['applications', 'Applications', '/catalog'],
              ['nodes', 'Resources', '/catalog'], ['permissions', 'Permissions', '/permissions'],
              ['apis', 'APIs', '/catalog'], ['endpoints', 'Endpoints', '/catalog'], ['clients', 'Clients', '/clients'],
              ['policies', 'Policies', '/policies'], ['sharedConditions', 'Shared Conditions', '/shared-conditions'],
            ].map(([key, label, to]) => <Link to={to} key={key}><strong>{number(key)}</strong>{label}<ArrowRightOutlined /></Link>)}
          </div> },
          { key: 'activity', label: 'Recent Activity', extra: 'Decisions · Changes', children: <Tabs items={[
            { key: 'decisions', label: 'Authorization Decisions', children: <Table rowKey="id" size="small" loading={loading}
              dataSource={data?.recentDecisions ?? []} pagination={{ pageSize: 5, hideOnSinglePage: true }} scroll={{ x: 650 }}
              columns={[
                { title: 'User', dataIndex: 'subjectUserName', render: (v) => v ?? 'Service Account' },
                { title: 'Permission', dataIndex: 'permissionCode' },
                { title: 'Decision', dataIndex: 'decision', render: (v) => <DecisionTag decision={v} /> },
                { title: 'Reason', dataIndex: 'reasonCode' },
                { title: 'Time', dataIndex: 'timestamp', render: fmt },
              ]} /> },
            { key: 'changes', label: 'Management Changes', children: <Table rowKey="id" size="small" loading={loading}
              dataSource={data?.recentChanges ?? []} pagination={{ pageSize: 5, hideOnSinglePage: true }} scroll={{ x: 600 }}
              columns={[{ title: 'Actor', dataIndex: 'actor' }, { title: 'Change', dataIndex: 'summary' }, { title: 'Time', dataIndex: 'timestamp', render: fmt }]} /> },
          ]} /> },
        ]} />
        <div className="workspace-model">{data ? <>Model v{data.modelVersion} · {fmt(data.modelBuiltAt)}<Link to="/audit">Audit Log <ArrowRightOutlined /></Link></> : loading ? 'Sistem özeti yükleniyor…' : 'Sistem özeti alınamadı.'}</div>
      </section>
    </div>
  )
}
