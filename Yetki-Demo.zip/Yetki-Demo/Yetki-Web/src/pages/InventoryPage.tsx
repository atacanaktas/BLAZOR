import { Alert, App, Button, Card, Empty, Flex, Form, Input, Modal, Popconfirm, Radio, Select, Space, Statistic, Tabs, Tag, Tooltip, Typography } from 'antd'
import { DataTable as Table } from '../components/DataTable'
import { DeleteOutlined, ImportOutlined, LinkOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import type { CoverageReport, CoverageStatus, EndpointCoverage, InventoryFormat, InventoryKind, InventorySnapshotInfo, ResourceDetail, ResourceTypeView, UiCoverage } from '../api/types'
import { toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { AccessKey, Code, ListError, MethodTag, PageGuide, PageHeader, fmt } from '../components/common'
import { ResourceModal, UriModal, type ResourcePrefill } from '../components/ResourceForms'

const statusMeta: Record<CoverageStatus, { color: string; label: string; help: string }> = {
  Protected: { color: 'green', label: 'Korunuyor', help: 'Tanımlı ve en az bir permission ile korunuyor.' },
  NoPermission: { color: 'orange', label: 'Permission yok → kapalı', help: 'Tanımlı ama hiçbir permission bağlı değil: kimse erişemez.' },
  Undefined: { color: 'red', label: 'Tanımsız → kapalı', help: 'Uygulamada var ama yetki tanımı yok: çağrılırsa reddedilir.' },
  Ambiguous: { color: 'magenta', label: 'Belirsiz eşleşme', help: 'Aynı özgüllükte birden fazla desen eşleşiyor: istek reddedilir.' },
}
const StatusTag = ({ s }: { s: CoverageStatus }) => <Tooltip title={statusMeta[s].help}><Tag color={statusMeta[s].color}>{statusMeta[s].label}</Tag></Tooltip>
const statusFilters = (Object.keys(statusMeta) as CoverageStatus[]).map((k) => ({ text: statusMeta[k].label, value: k }))

/**
 * Envanter & kapsama: uygulamada gerçekte ne var (Swagger / ekran listesi) ↔ yetki tanımları.
 * Envanter sadece bilgidir; yetki tanımı üretmez. Tanımlama her zaman yetki ekibinin bilinçli işlemidir ("Tanımla").
 */
export function InventoryPage() {
  const [params, setParams] = useSearchParams()
  const apps = useOptions('applications')
  const appId = params.get('app') ? Number(params.get('app')) : apps[0]?.value
  const { data, loading, error, reload } = useApi<CoverageReport>(appId ? `/api/inventory/${appId}/coverage` : null)
  const [importing, setImporting] = useState<InventoryKind>()
  const [define, setDefine] = useState<{ prefill: ResourcePrefill }>()
  const [addUri, setAddUri] = useState<{ resourceId: number; method: string; pattern: string; scopeCode: string }>()
  const types = useApi<ResourceTypeView[]>('/api/resource-types').data ?? []
  const { message } = App.useApp()
  const httpType = types.find((t) => t.matchesHttp && t.isActive)?.id

  const removeSnapshot = async (kind: InventoryKind) => {
    try { await api.del(`/api/inventory/${appId}/${kind}`); message.success('Envanter silindi'); reload() } catch (e) { message.error((e as Error).message) }
  }
  const count = (list: { status: CoverageStatus }[], s: CoverageStatus) => list.filter((x) => x.status === s).length

  return (
    <>
      <PageHeader title="Envanter & Kapsama" subtitle="Uygulamada gerçekte ne var (Swagger, ekran listesi) ve bunların kaçı yetki tanımlarıyla korunuyor? Envanter sadece bilgidir; yetkiye etkisi yoktur."
        extra={<Select style={{ width: 280 }} value={appId} onChange={(v) => setParams({ app: String(v) })} options={toSelectOptions(apps)} placeholder="Uygulama" />} />
      <PageGuide>
        <p><b>Envanter</b>: Swagger / gateway route'larından endpoint listesi veya uygulamanın ekran / bileşen listesi içeri alınır. Yeniden içe aktarım öncekinin yerini alır. <b>Hiçbir resource ya da permission otomatik oluşmaz.</b></p>
        <p><b>Kapsama</b>: envanter yetki tanımlarıyla karşılaştırılır. <Tag color="red">Tanımsız</Tag> öğeler güvenlik açığı değildir: varsayılan kapalı olduğumuz için çağrılırsa reddedilir; yani uygulama o işlemi yapamaz. <Tag>Atıl</Tag> tanımlar uygulamada artık olmayabilir.</p>
        <p>Endpoint'ler URI desenleriyle, ekranlar <b>uygulama kodu</b> (ör. GVADAG00) veya resource koduyla eşleştirilir.</p>
      </PageGuide>
      <ListError error={error} onRetry={reload} />
      {!appId ? <Empty description="Uygulama yok" /> : (
        <Tabs items={[
          {
            key: 'endpoints', label: <>Endpoint'ler {data && <Tag>{data.endpointItems.length}</Tag>}</>,
            children: <>
              <SnapshotBar info={data?.endpoints} kind="Endpoint" onImport={() => setImporting('Endpoint')} onDelete={() => removeSnapshot('Endpoint')} />
              {data?.endpoints && (
                <Flex gap={28} wrap style={{ margin: '12px 0' }}>
                  <Statistic title="Korunuyor" value={count(data.endpointItems, 'Protected')} valueStyle={{ color: '#389e0d' }} />
                  <Statistic title="Tanımsız (kapalı)" value={count(data.endpointItems, 'Undefined')} valueStyle={{ color: count(data.endpointItems, 'Undefined') ? '#cf1322' : undefined }} />
                  <Statistic title="Permission yok (kapalı)" value={count(data.endpointItems, 'NoPermission')} />
                  <Statistic title="Belirsiz" value={count(data.endpointItems, 'Ambiguous')} />
                  <Statistic title="Tanımlı ama envanterde yok" value={data.staleUris.length} />
                </Flex>
              )}
              <Table<EndpointCoverage> size="small" loading={loading} rowKey={(x) => `${x.method} ${x.path}`} dataSource={data?.endpointItems ?? []} pagination={{ hideOnSinglePage: true }}
                locale={{ emptyText: data?.endpoints ? 'Envanter boş' : 'Endpoint envanteri yok — Swagger veya endpoint listesi içe aktarın' }}
                columns={[
                  { title: 'Endpoint', render: (_, x) => <><MethodTag method={x.method} /><Code>{x.path}</Code>{x.name && <div><Typography.Text type="secondary" style={{ fontSize: 12 }}>{x.name}</Typography.Text></div>}</>,
                    sorter: (a, b) => a.path.localeCompare(b.path) },
                  { title: 'Durum', width: 190, render: (_, x) => <StatusTag s={x.status} />, filters: statusFilters, onFilter: (v, x) => x.status === v },
                  {
                    title: 'Yetki tanımı', render: (_, x) => x.key
                      ? <><Link to={`/resources?resource=${x.resourceId}`}><AccessKey value={x.key} /></Link> <Typography.Text type="secondary" style={{ fontSize: 12 }}>{x.matchedUri}</Typography.Text>
                          <div>{x.permissions.map((p) => <Tag key={p} color="green">{p}</Tag>)}</div></>
                      : x.ambiguous.length ? x.ambiguous.map((a) => <div key={a} style={{ fontSize: 12 }}>{a}</div>) : <Typography.Text type="secondary">—</Typography.Text>,
                  },
                  {
                    title: '', width: 260, render: (_, x) => x.status === 'Undefined' ? (
                      <Space wrap>
                        {x.suggestedResourceId && <Tooltip title={`Aynı URL grubundaki mevcut resource'a URI ekle (önerilen scope: ${x.suggestedScope})`}>
                          <Button size="small" type="primary" icon={<LinkOutlined />} onClick={() => setAddUri({ resourceId: x.suggestedResourceId!, method: x.method, pattern: x.path, scopeCode: x.suggestedScope })}>{x.suggestedResourceCode}'a ekle</Button>
                        </Tooltip>}
                        <Button size="small" icon={<PlusOutlined />} onClick={() => setDefine({ prefill: {
                          resourceTypeId: httpType, code: x.suggestedCode, name: x.name ?? x.path, scopeCodes: [x.suggestedScope],
                          uris: [{ method: x.method, pattern: x.path, scopeCode: x.suggestedScope }],
                        } })}>Yeni resource</Button>
                      </Space>
                    ) : x.status === 'NoPermission' && x.resourceId ? <Link to={`/permissions/new?app=${appId}&resource=${x.resourceId}`}><Button size="small">Permission bağla</Button></Link> : null,
                  },
                ]} />
              {data && data.staleUris.length > 0 && (
                <Card size="small" style={{ marginTop: 16 }} title={<>Tanımlı ama envanterde yok <Tag>{data.staleUris.length}</Tag></>}
                  extra={<Typography.Text type="secondary" style={{ fontSize: 12 }}>Uygulamadan kaldırılmış olabilir (atıl). İnceleyip URI eşlemesini veya resource'u kaldırabilirsiniz.</Typography.Text>}>
                  <Table size="small" rowKey={(x) => `${x.method} ${x.pattern}`} pagination={false} dataSource={data.staleUris}
                    columns={[
                      { title: 'URI eşlemesi', render: (_, x) => <><MethodTag method={x.method} /><Code>{x.pattern}</Code></> },
                      { title: 'Yetki', render: (_, x) => <Link to={`/resources?resource=${x.resourceId}`}><AccessKey value={x.key} /></Link> },
                    ]} />
                </Card>
              )}
            </>,
          },
          {
            key: 'ui', label: <>Ekranlar / UI {data && <Tag>{data.uiItems.length}</Tag>}</>,
            children: <>
              <SnapshotBar info={data?.uiElements} kind="UiElement" onImport={() => setImporting('UiElement')} onDelete={() => removeSnapshot('UiElement')} />
              {data?.uiElements && (
                <Flex gap={28} wrap style={{ margin: '12px 0' }}>
                  <Statistic title="Korunuyor" value={count(data.uiItems, 'Protected')} valueStyle={{ color: '#389e0d' }} />
                  <Statistic title="Tanımsız (kapalı)" value={count(data.uiItems, 'Undefined')} valueStyle={{ color: count(data.uiItems, 'Undefined') ? '#cf1322' : undefined }} />
                  <Statistic title="Permission yok (kapalı)" value={count(data.uiItems, 'NoPermission')} />
                  <Statistic title="Tanımlı ama envanterde yok" value={data.staleUiResources.length} />
                </Flex>
              )}
              <Table<UiCoverage> size="small" loading={loading} rowKey="code" dataSource={data?.uiItems ?? []} pagination={{ hideOnSinglePage: true }}
                locale={{ emptyText: data?.uiElements ? 'Envanter boş' : 'Ekran / bileşen envanteri yok — ekran listesi içe aktarın' }}
                columns={[
                  { title: 'Öğe', render: (_, x) => <><Code>{x.code}</Code> {x.name}{x.elementType && <Tag style={{ marginLeft: 6 }}>{x.elementType}</Tag>}
                      {x.parentCode && <div><Typography.Text type="secondary" style={{ fontSize: 12 }}>üst: {x.parentCode}</Typography.Text></div>}</> },
                  { title: 'Durum', width: 190, render: (_, x) => <StatusTag s={x.status} />, filters: statusFilters.filter((f) => f.value !== 'Ambiguous'), onFilter: (v, x) => x.status === v },
                  { title: 'Yetki tanımı', render: (_, x) => x.resource
                      ? <><Link to={`/resources?resource=${x.resourceId}`}><Code>{x.resource}</Code></Link><div>{x.scopes.map((s) => <Tag key={s.key} color={s.protected ? 'green' : 'orange'}>{s.key.split(':')[1]}</Tag>)}</div></>
                      : <Typography.Text type="secondary">—</Typography.Text> },
                  {
                    title: '', width: 180, render: (_, x) => x.status === 'Undefined'
                      ? <Button size="small" type="primary" icon={<PlusOutlined />} onClick={() => setDefine({ prefill: {
                          resourceTypeId: x.suggestedTypeId, code: x.suggestedCode, name: x.name ?? x.code, externalCode: x.code, parentId: x.suggestedParentId,
                          scopeCodes: ['view'],
                        } })}>Tanımla</Button>
                      : x.status === 'NoPermission' && x.resourceId ? <Link to={`/permissions/new?app=${appId}&resource=${x.resourceId}`}><Button size="small">Permission bağla</Button></Link> : null,
                  },
                ]} />
              {data && data.staleUiResources.length > 0 && (
                <Card size="small" style={{ marginTop: 16 }} title={<>Tanımlı ama envanterde yok <Tag>{data.staleUiResources.length}</Tag></>}
                  extra={<Typography.Text type="secondary" style={{ fontSize: 12 }}>Uygulamada artık olmayabilir; ya da uygulama kodu (ör. GVADAG00) girilmemiş olabilir.</Typography.Text>}>
                  <Table size="small" rowKey="resourceId" pagination={false} dataSource={data.staleUiResources}
                    columns={[
                      { title: 'Resource', render: (_, x) => <Link to={`/resources?resource=${x.resourceId}`}><Code>{x.code}</Code></Link> },
                      { title: 'Ad', dataIndex: 'name' },
                      { title: 'Tip', dataIndex: 'type', render: (v) => <Tag>{v}</Tag> },
                      { title: 'Uygulama kodu', dataIndex: 'externalCode', render: (v) => v ? <Code>{v}</Code> : <Tag color="orange">girilmemiş</Tag> },
                    ]} />
                </Card>
              )}
            </>,
          },
        ]} />
      )}
      {importing && appId && <ImportModal applicationId={appId} kind={importing} onClose={() => setImporting(undefined)} onDone={reload} />}
      {define && appId && <ResourceModal applicationId={appId} prefill={define.prefill} onClose={() => setDefine(undefined)} onDone={() => reload()} />}
      {addUri && <AddUriModal {...addUri} onClose={() => setAddUri(undefined)} onDone={reload} />}
    </>
  )
}

function SnapshotBar({ info, kind, onImport, onDelete }: { info?: InventorySnapshotInfo; kind: InventoryKind; onImport: () => void; onDelete: () => void }) {
  return (
    <Alert type={info ? 'info' : 'warning'} showIcon
      message={info ? <>Kaynak: <b>{info.source}</b> · {info.itemCount} öğe · {fmt(info.importedAt)} · {info.importedBy}</>
        : kind === 'Endpoint' ? 'Endpoint envanteri yok' : 'Ekran / bileşen envanteri yok'}
      action={<Space>
        <Button size="small" type="primary" icon={<ImportOutlined />} onClick={onImport}>{info ? 'Yeniden içe aktar' : 'İçe aktar'}</Button>
        {info && <Popconfirm title="Envanter silinsin mi?" description="Sadece bilgi silinir; yetki tanımları etkilenmez." onConfirm={onDelete}><Button size="small" danger icon={<DeleteOutlined />} /></Popconfirm>}
      </Space>} />
  )
}

const examples: Record<InventoryKind, Record<string, string>> = {
  Endpoint: {
    Lines: '# METHOD /yol [açıklama]\nGET /v1/vadeli-hesap Vadeli hesap listesi\nGET /v1/vadeli-hesap/{hesapNo}/dekont Dekont\nPOST /v1/vadeli-hesap/{hesapNo}/kapat Kapat',
    OpenApi: '{ "openapi": "3.0.1", "paths": { "/v1/vadeli-hesap": { "get": { "summary": "Liste" } } } }',
  },
  UiElement: {
    Lines: '# KOD;Ad;ÜstKod;Tip\nMGISE;Gişe menüsü;;MENU\nGVADAG00;Vadeli hesap;MGISE;SCREEN\nGVADAG00.KPT;Vadeli kapat;GVADAG00;BUTTON',
    Json: '[{ "code": "GVADAG00", "name": "Vadeli hesap", "parent": "MGISE", "type": "SCREEN" }]',
  },
}

function ImportModal({ applicationId, kind, onClose, onDone }: { applicationId: number; kind: InventoryKind; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm<{ source: string; format: InventoryFormat; pathPrefix?: string; content: string }>()
  const { message } = App.useApp()
  const format = (Form.useWatch('format', form) ?? 'Lines') as InventoryFormat
  const [busy, setBusy] = useState(false)
  const save = async () => {
    const v = await form.validateFields()
    setBusy(true)
    try {
      const r = await api.post<InventorySnapshotInfo>(`/api/inventory/${applicationId}/${kind === 'Endpoint' ? 'endpoints' : 'ui'}`, v)
      message.success(`${r.itemCount} öğe içe aktarıldı`)
      onDone(); onClose()
    } catch (e) { message.error((e as Error).message) } finally { setBusy(false) }
  }
  const formats = kind === 'Endpoint'
    ? [{ value: 'Lines', label: 'Satır listesi' }, { value: 'OpenApi', label: 'OpenAPI / Swagger JSON' }]
    : [{ value: 'Lines', label: 'Satır listesi' }, { value: 'Json', label: 'JSON' }]
  return (
    <Modal open width={760} title={kind === 'Endpoint' ? 'Endpoint envanteri içe aktar' : 'Ekran / bileşen envanteri içe aktar'} onCancel={onClose} onOk={save} okText="İçe aktar" confirmLoading={busy} destroyOnHidden>
      <Alert type="info" showIcon style={{ marginBottom: 12 }} message="Önceki envanterin yerini alır. Sadece bilgi amaçlıdır: resource veya permission oluşturmaz, kararları etkilemez." />
      <Form form={form} layout="vertical" initialValues={{ format: 'Lines' }}>
        <Form.Item name="source" label="Kaynak" rules={[{ required: true }]} extra="ör. Anka Swagger v1.9 · Nextral ekran listesi 2026-10"><Input /></Form.Item>
        <Form.Item name="format" label="Biçim"><Radio.Group optionType="button" options={formats} /></Form.Item>
        {kind === 'Endpoint' && <Form.Item name="pathPrefix" label="Yol öneki (opsiyonel)" extra="Swagger'daki yolların başına eklenir (ör. gateway'deki /anka öneki)."><Input placeholder="/anka" /></Form.Item>}
        <Form.Item name="content" label="İçerik" rules={[{ required: true }]}>
          <Input.TextArea rows={12} placeholder={examples[kind][format] ?? ''} style={{ fontFamily: 'monospace', fontSize: 12 }} />
        </Form.Item>
      </Form>
    </Modal>
  )
}

/** Envanterdeki endpoint'i mevcut resource'a URI olarak ekle (resource'un scope'ları yüklenir). */
function AddUriModal({ resourceId, method, pattern, scopeCode, onClose, onDone }: {
  resourceId: number; method: string; pattern: string; scopeCode: string; onClose: () => void; onDone: () => void
}) {
  const { data } = useApi<ResourceDetail>(`/api/resources/${resourceId}`)
  if (!data) return null
  return <UriModal resourceId={resourceId} scopes={data.scopes} prefill={{ method, pattern, scopeCode }} onClose={onClose} onDone={onDone} />
}
