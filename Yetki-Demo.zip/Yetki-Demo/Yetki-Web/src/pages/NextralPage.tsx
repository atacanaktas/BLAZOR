import { Alert, Button, Card, Col, Empty, Flex, Input, Row, Select, Switch, Table, Tag, Tooltip, Typography } from 'antd'
import { CheckCircleTwoTone, CloseCircleTwoTone, DesktopOutlined, LockOutlined } from '@ant-design/icons'
import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import type { EntitlementResult, UiEntitlement } from '../api/types'
import { useApi, useOptions } from '../hooks/useApi'
import { Code, DecisionTag, PageHeader } from '../components/common'

/**
 * Nextral (WinForms) istemcisinin login'de yaptığı çağrının simülasyonu:
 *   GET /api/v1/entitlements/{user}?client=nextral-desktop&application=NEXTRAL
 * İstemci butonları bu listeye göre açıp kapatır; ama asıl güvenlik API'dedir (buton açık olsa bile Anka API'si PDP'ye sorar).
 */
export function NextralPage() {
  const [params] = useSearchParams()
  const users = useOptions('users')
  const clients = useOptions('clients')
  const permissions = useOptions('permissions')
  const [user, setUser] = useState(params.get('user') ?? 'ayse.yilmaz')
  const [client, setClient] = useState('nextral-desktop')
  const [evaluate, setEvaluate] = useState(true)
  const [ip, setIp] = useState('10.1.2.3')
  const demoScopes = permissions.map((p) => p.code).join(' ')
  const { data, loading } = useApi<EntitlementResult>(`/api/v1/entitlements/${user}?client=${client}&application=NEXTRAL&evaluate=${evaluate}&ip=${encodeURIComponent(ip)}&scope=${encodeURIComponent(demoScopes)}`)
  const [screen, setScreen] = useState<string>()

  // Önce ekranlar, sonra menüler
  const roots = useMemo(() => (data?.uiElements ?? []).filter((u) => !u.parentCode)
    .sort((a, b) => (a.kind === b.kind ? a.code.localeCompare(b.code) : a.kind === 'Screen' ? -1 : 1)), [data])
  const current = roots.find((r) => r.code === screen) ?? roots.find((r) => r.enabled) ?? roots[0]
  const children = (data?.uiElements ?? []).filter((u) => u.parentCode === current?.code)

  return (
    <>
      <PageHeader title="Ekran simülasyonu" subtitle="Bir kullanıcının erişebildiği ekranları ve işlemleri önizleyin." />
      <Card size="small" style={{ marginBottom: 16 }}>
        <Flex gap={12} wrap align="center">
          <span>Kullanıcı: <Select showSearch optionFilterProp="label" style={{ width: 300 }} value={user} onChange={setUser} options={users.map((u) => ({ value: u.code, label: u.label }))} /></span>
          <span>Client: <Select style={{ width: 260 }} value={client} onChange={setClient} options={clients.map((c) => ({ value: c.code, label: c.label }))} /></span>
          <span>IP: <Input style={{ width: 140 }} value={ip} onChange={(e) => setIp(e.target.value)} /></span>
          <span><Switch checked={evaluate} onChange={setEvaluate} /> "Şu an" policy kararını da hesapla</span>
          {data && <Tag>ETag {data.eTag}</Tag>}
        </Flex>
      </Card>
      <Row gutter={16}>
        <Col xs={24} xl={16}>
          <div className="screen-preview">
            <Flex justify="space-between" align="center" className="screen-preview-header">
              <span><DesktopOutlined /> Nextral Şube — {data?.fullName} ({data?.userName}) · {data?.tenant}</span>
              <span className="screen-preview-badge">Önizleme</span>
            </Flex>
            {loading && !data ? <Card loading /> : (
              <Flex className="screen-preview-body">
                <div className="screen-preview-menu">
                  {roots.map((r) => (
                    <Tooltip key={r.code} title={r.reason} placement="right">
                      <Button block type={current?.code === r.code ? 'primary' : 'default'} disabled={!r.enabled} style={{ marginBottom: 6, textAlign: 'left' }}
                        icon={r.enabled ? undefined : <LockOutlined />} onClick={() => setScreen(r.code)}>
                        {r.name}
                      </Button>
                    </Tooltip>
                  ))}
                </div>
                <div className="screen-preview-content">
                  {current ? (
                    <>
                      <Typography.Title level={5} style={{ marginTop: 0 }}>{current.name}</Typography.Title>
                      {!current.enabled && <Alert type="warning" showIcon message={current.reason} style={{ marginBottom: 12 }} />}
                      <Flex wrap gap={10}>
                        {children.map((b) => (
                          <Tooltip key={b.code} title={<>{b.reason}{b.permission && <div style={{ marginTop: 4, opacity: 0.8 }}>{b.permission}</div>}</>}>
                            <Button size="large" disabled={!b.enabled} icon={b.enabled ? undefined : <LockOutlined />} style={{ minWidth: 150 }}>{b.name}</Button>
                          </Tooltip>
                        ))}
                        {children.length === 0 && <Empty description="Bu ekranda buton yok" />}
                      </Flex>
                    </>
                  ) : <Empty />}
                </div>
              </Flex>
            )}
            <div className="screen-preview-footer">
              {data && <>client: {data.client} · {data.permissions.length} permission · {data.blockedByClientPermission.length} permission Client için allowed değil · model v{data.modelVersion}</>}
            </div>
          </div>
        </Col>
        <Col xs={24} xl={8}>
          <Alert type="info" showIcon message="Güvenlik sunucudadır"
            description="Buton açık olsa bile Nextral, Anka API'sini çağırdığında SDK tekrar karar ister (işlem anındaki tutar, müşteri, saat ile). Liste yalnızca kullanıcı deneyimi içindir; model değişmediyse (ETag) istemci önbelleğini kullanır." />
          <Card size="small" title="Özet" style={{ marginTop: 16 }}>
            {data && <Flex vertical gap={4}>
              <span>Açık öğe: <b>{data.uiElements.filter((u) => u.enabled).length}</b> / {data.uiElements.length}</span>
              <span>Policy nedeniyle şu an kapalı: <b>{data.uiElements.filter((u) => u.runtime && u.runtime.decision !== 'Permit').length}</b></span>
              <span>Client için allowed olmayan Permission: <b>{data.blockedByClientPermission.length}</b></span>
            </Flex>}
          </Card>
        </Col>
        <Col span={24} style={{ marginTop: 16 }}>
          <Card size="small" title="Öğe bazında neden (buton açık/kapalı)">
            <Table<UiEntitlement> size="small" rowKey="code" pagination={false} dataSource={data?.uiElements ?? []}
              columns={[
                { title: 'Öğe', render: (_, u) => <>{u.parentCode && '└ '}{u.enabled ? <CheckCircleTwoTone twoToneColor="#52c41a" /> : <CloseCircleTwoTone twoToneColor="#ff4d4f" />} {u.name}</> },
                { title: 'Permission', dataIndex: 'permission', render: (v) => v ? <Code>{v}</Code> : '—' },
                { title: 'Şu an', render: (_, u) => u.runtime ? <DecisionTag decision={u.runtime.decision} /> : null },
                { title: 'Neden', dataIndex: 'reason', render: (v) => <Typography.Text style={{ fontSize: 12 }}>{v}</Typography.Text> },
              ]} />
          </Card>
        </Col>
      </Row>
    </>
  )
}
