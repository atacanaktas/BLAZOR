import { Alert, App, Button, Card, Col, DatePicker, Descriptions, Empty, Flex, Form, Input, InputNumber, Modal, Row, Select, Space, Switch, Table, Tabs, Tag, Tooltip, Typography } from 'antd'
import { DeleteOutlined, EditOutlined, ExperimentOutlined, PlusOutlined, ThunderboltOutlined } from '@ant-design/icons'
import { useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import type { Dayjs } from 'dayjs'
import { api } from '../api/client'
import type { ChangeImpactResult, EffectivePermission, EffectivePermissionSet, EntitlementResult, UserExternalStatus } from '../api/types'
import { ExternalTag } from '../components/External'
import { invalidateOptions, toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { ActiveTag, Code, DecisionTag, TenantTag, PageHeader, SeverityTag, SourceList, TagSummary, fmtDate } from '../components/common'
import { ChangeModal } from '../components/ChangeModal'
import { ConfirmChangeModal } from '../components/ConfirmChangeModal'
import { ImpactView } from '../components/ImpactView'

interface UserRow {
  id: number
  userName: string
  fullName: string
  title?: string
  kind: string
  isActive: boolean
  isOnLeave: boolean
  tenant: string
  units: string[]
  directRoles: string[]
  groups: string[]
  permissionCount: number
}

export function UsersPage() {
  const [q, setQ] = useState('')
  const [tenant, setTenant] = useState<number>()
  const { data, loading } = useApi<UserRow[]>(`/api/users?q=${encodeURIComponent(q)}${tenant ? `&tenantId=${tenant}` : ''}`)
  const tenants = useOptions('tenants')
  const navigate = useNavigate()
  const [creating, setCreating] = useState(false)
  return (
    <>
      <PageHeader title="Users & Assignments" subtitle="HR / Identity kaynaklı profiller, iş rolleri ve organizasyon atamaları. Mevcut veri girişleri bu ekrandan devam eder."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setCreating(true)}>Yeni kullanıcı</Button>} />
      <Flex gap={8} style={{ marginBottom: 12 }}>
        <Input.Search placeholder="Kullanıcı adı veya ad" allowClear onSearch={setQ} style={{ width: 320 }} />
        <Select allowClear placeholder="Tenant" style={{ width: 240 }} value={tenant} onChange={setTenant} options={toSelectOptions(tenants)} />
      </Flex>
      <Table<UserRow>
        rowKey="id"
        size="small"
        loading={loading}
        dataSource={data ?? []}
        pagination={{ pageSize: 20 }}
        rowClassName="clickable-row"
        onRow={(u) => ({ onClick: () => navigate(`/users/${u.id}`) })}
        columns={[
          { title: 'Kullanıcı', render: (_, u) => <><b>{u.userName}</b>{u.kind === 'ServiceAccount' && <Tag color="purple" style={{ marginLeft: 6 }}>servis</Tag>}<br /><Typography.Text type="secondary">{u.fullName} · {u.title}</Typography.Text></>, sorter: (a, b) => a.userName.localeCompare(b.userName) },
          { title: 'Tenant / birim', render: (_, u) => <><TenantTag tenant={u.tenant} />{u.units.map((x) => <Tag key={x}>{x}</Tag>)}</>, filters: [...new Set((data ?? []).flatMap((u) => u.units))].map((x) => ({ text: x, value: x })), onFilter: (v, u) => u.units.includes(v as string) },
          { title: 'Doğrudan roller', dataIndex: 'directRoles', render: (v: string[]) => <TagSummary values={v} /> },
          { title: 'Gruplar', dataIndex: 'groups', render: (v: string[]) => <TagSummary values={v} /> },
          { title: 'Yetki', dataIndex: 'permissionCount', width: 70, sorter: (a, b) => a.permissionCount - b.permissionCount },
          { title: '', render: (_, u) => <>{!u.isActive && <Tag>Pasif</Tag>}{u.isOnLeave && <Tag color="orange">İzinde</Tag>}</>, width: 90 },
        ]}
      />
      {creating && <UserCreateModal onClose={() => setCreating(false)} onDone={(id) => navigate(`/users/${id}`)} />}
    </>
  )
}

/** Yeni kullanıcı. Rol/yetki/ek birimler oluşturduktan sonra detay sayfasından (etki analiziyle) verilir. */
function UserCreateModal({ onClose, onDone }: { onClose: () => void; onDone: (id: number) => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const tenants = useOptions('tenants')
  const units = useOptions('units')
  const tenantId = Form.useWatch('tenantId', form) as number | undefined
  const orgCode = tenants.find((o) => o.value === tenantId)?.code
  const save = async () => {
    const v = await form.validateFields()
    try {
      const r = await api.post<{ id: number }>('/api/users', v)
      invalidateOptions('users')
      message.success('Kullanıcı oluşturuldu. Rol ve yetkileri detay sayfasından verebilirsiniz.')
      onClose()
      onDone(r.id)
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title="Yeni kullanıcı" okText="Oluştur" onOk={save} onCancel={onClose} destroyOnHidden width={640}>
      <Form form={form} layout="vertical" initialValues={{ kind: 'Person', isActive: true, cashWithdrawalLimit: 0 }}>
        <Row gutter={12}>
          <Col span={12}><Form.Item name="userName" label="Kullanıcı adı" rules={[{ required: true }]}><Input placeholder="ad.soyad" /></Form.Item></Col>
          <Col span={12}><Form.Item name="fullName" label="Ad soyad" rules={[{ required: true }]}><Input /></Form.Item></Col>
          <Col span={12}><Form.Item name="tenantId" label="Tenant" rules={[{ required: true }]}><Select options={toSelectOptions(tenants)} onChange={() => form.setFieldValue('primaryOrgUnitId', undefined)} /></Form.Item></Col>
          <Col span={12}><Form.Item name="primaryOrgUnitId" label="Birim (şube)"><Select allowClear showSearch optionFilterProp="label" disabled={!tenantId} options={toSelectOptions(units.filter((u) => !orgCode || u.group === orgCode))} /></Form.Item></Col>
          <Col span={12}><Form.Item name="title" label="Ünvan" extra="Grup filtrelerindeki TITLE kriteri bununla eşleşir"><Input /></Form.Item></Col>
          <Col span={12}><Form.Item name="kind" label="Tür"><Select options={[{ value: 'Person', label: 'Kişi' }, { value: 'ServiceAccount', label: 'Servis hesabı' }]} /></Form.Item></Col>
          <Col span={12}><Form.Item name="email" label="E-posta"><Input /></Form.Item></Col>
          <Col span={12}><Form.Item name="employeeNo" label="Sicil no"><Input /></Form.Item></Col>
          <Col span={12}><Form.Item name="cashWithdrawalLimit" label="Nakit çekim limiti"><InputNumber style={{ width: '100%' }} min={0} /></Form.Item></Col>
          <Col span={12}><Form.Item name="customerNo" label="Müşteri no" extra="Kendi hesabında işlem kuralı için"><Input /></Form.Item></Col>
        </Row>
      </Form>
    </Modal>
  )
}

interface UserDetail {
  user: {
    id: number; userName: string; fullName: string; email?: string; title?: string; employeeNo?: string; kind: string; isActive: boolean; isOnLeave: boolean
    cashWithdrawalLimit: number; customerNo?: string; tenantId: number; tenant: string
  }
  roles: { roleId: number; code: string; name: string; validUntil?: string; reason?: string; assignedAt: string; assignedBy: string }[]
  permissions: { permissionId: number; code: string; name: string; reason?: string; validUntil?: string; assignedAt: string; assignedBy: string }[]
  units: { orgUnitId: number; code: string; name: string; type: string; isPrimary: boolean }[]
  explicitGroups: { groupId: number; code: string; validUntil?: string }[]
  violations: { id: number; code: string; status: string; details: string; detectedAt: string }[]
  tenantChain: string[]
}

type Modal_ = 'role' | 'perm' | 'unit' | 'edit' | null

export function UserDetailPage() {
  const { id } = useParams()
  const userId = Number(id)
  const detail = useApi<UserDetail>(`/api/users/${userId}`)
  const effective = useApi<EffectivePermissionSet>(`/api/users/${userId}/effective`)
  const roles = useOptions('roles')
  const perms = useOptions('permissions')
  const units = useOptions('units')
  const [modal, setModal] = useState<Modal_>(null)
  const [validUntil, setValidUntil] = useState<Dayjs | null>(null)
  const [reason, setReason] = useState('')
  const [removal, setRemoval] = useState<{ title: string; changeSet: object; apply: () => Promise<ChangeImpactResult> }>()
  const reload = () => { detail.reload(); effective.reload() }
  const d = detail.data
  const e = effective.data

  if (!d) return <Card loading />

  return (
    <>
      <PageHeader
        title={<>{d.user.fullName} <Typography.Text type="secondary" style={{ fontSize: 16 }}>({d.user.userName})</Typography.Text></>}
        subtitle={<>{d.user.title} · <TenantTag tenant={d.user.tenant} /> {d.tenantChain.length > 1 && <Typography.Text type="secondary">zincir: {d.tenantChain.join(' → ')}</Typography.Text>}</>}
        extra={
          <Space>
            <Button icon={<EditOutlined />} onClick={() => setModal('edit')}>Bilgileri düzenle</Button>
            <Link to={`/evaluate?user=${d.user.userName}`}><Button icon={<ThunderboltOutlined />}>Yetki testi</Button></Link>
            <Link to={`/nextral?user=${d.user.userName}`}><Button>Nextral ekranı</Button></Link>
            <Link to={`/what-if?tab=user&userId=${userId}`}><Button icon={<ExperimentOutlined />}>What-If</Button></Link>
          </Space>
        }
      />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={8}>
          <Card size="small" title="Kimlik">
            <Descriptions size="small" column={1}>
              <Descriptions.Item label="Durum"><ActiveTag active={d.user.isActive} />{d.user.isOnLeave && <Tag color="orange">İzinde</Tag>}{d.user.kind === 'ServiceAccount' && <Tag color="purple">Servis hesabı</Tag>}</Descriptions.Item>
              <Descriptions.Item label="Sicil">{d.user.employeeNo ?? '—'}</Descriptions.Item>
              <Descriptions.Item label="E-posta">{d.user.email ?? '—'}</Descriptions.Item>
              <Descriptions.Item label="Çekim limiti">{d.user.cashWithdrawalLimit.toLocaleString('tr-TR')} TL</Descriptions.Item>
              <Descriptions.Item label="Müşteri no">{d.user.customerNo ?? '—'}</Descriptions.Item>
            </Descriptions>
          </Card>
          <Card size="small" title="Birimler" style={{ marginTop: 16 }} extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setModal('unit')}>Ekle</Button>}>
            {d.units.map((u) => (
              <Flex key={u.orgUnitId} justify="space-between" style={{ marginBottom: 4 }}>
                <span><Tag>{u.code}</Tag>{u.name} {u.isPrimary && <Tag color="blue">birincil</Tag>}</span>
                <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={() => setRemoval({
                  title: `${d.user.userName} → ${u.code} biriminden çıkar`, changeSet: { userUnits: [{ userId, orgUnitId: u.orgUnitId, add: false }] },
                  apply: () => api.del(`/api/users/${userId}/units/${u.orgUnitId}`),
                })} />
              </Flex>
            ))}
          </Card>
          <Card size="small" title="Doğrudan roller" style={{ marginTop: 16 }} extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setModal('role')}>Rol ata</Button>}>
            {d.roles.length === 0 && <Typography.Text type="secondary">—</Typography.Text>}
            {d.roles.map((r) => (
              <Flex key={r.roleId} justify="space-between" style={{ marginBottom: 4 }}>
                <span><Link to={`/roles/${r.roleId}`}><Tag color="blue">{r.code}</Tag></Link>{r.name}{r.validUntil && <Tag color="gold">{fmtDate(r.validUntil)}'e kadar</Tag>}</span>
                <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={() => setRemoval({
                  title: `${d.user.userName} → ${r.code} rolünü al`, changeSet: { userRoles: [{ userId, roleId: r.roleId, add: false }] },
                  apply: () => api.del(`/api/users/${userId}/roles/${r.roleId}`),
                })} />
              </Flex>
            ))}
          </Card>
          <Card size="small" title="Doğrudan permission (legacy/istisna)" style={{ marginTop: 16 }} extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setModal('perm')}>Ver</Button>}>
            {d.permissions.length === 0 && <Typography.Text type="secondary">— (ana model rol ve gruptur)</Typography.Text>}
            {d.permissions.map((p) => (
              <Flex key={p.permissionId} justify="space-between" style={{ marginBottom: 4 }}>
                <span><Code>{p.code}</Code> <Typography.Text type="secondary" style={{ fontSize: 12 }}>{p.reason}</Typography.Text></span>
                <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={() => setRemoval({
                  title: `${d.user.userName} → ${p.code} doğrudan yetkisini al`, changeSet: { userPermissions: [{ userId, permissionId: p.permissionId, add: false }] },
                  apply: () => api.del(`/api/users/${userId}/permissions/${p.permissionId}`),
                })} />
              </Flex>
            ))}
          </Card>
          {d.violations.length > 0 && (
            <Alert type="error" style={{ marginTop: 16 }} message="Açık SoD ihlalleri" description={d.violations.map((v) => <div key={v.id}><Tag color="red">{v.code}</Tag>{v.details}</div>)} />
          )}
        </Col>
        <Col xs={24} xl={16}>
          <Tabs
            items={[
              { key: 'eff', label: `Etkin yetkiler (${e?.permissions.length ?? 0})`, children: <EffectiveTab set={e} /> },
              { key: 'groups', label: `Gruplar & roller (${e?.groups.length ?? 0})`, children: <GroupsTab set={e} explicit={d.explicitGroups} /> },
              { key: 'ent', label: 'Uygulama bazlı yetki (client)', children: <EntitlementTab userId={userId} /> },
              { key: 'ext', label: 'Dış sistem (RACF/LDAP)', children: <ExternalTab key={e?.modelVersion} userId={userId} /> },
            ]}
          />
        </Col>
      </Row>

      <ChangeModal
        open={modal === 'role'}
        title={`${d.user.userName} kullanıcısına rol ata`}
        label="Rol (etki önizlemesi otomatik)"
        options={toSelectOptions(roles, d.roles.map((r) => r.roleId))}
        buildChangeSet={(roleId) => ({ userRoles: [{ userId, roleId, add: true, validUntil: validUntil?.toISOString() }] })}
        apply={(roleId) => api.post(`/api/users/${userId}/roles`, { roleId, validUntil: validUntil?.toISOString(), reason })}
        onClose={() => { setModal(null); setValidUntil(null); setReason('') }}
        onDone={reload}
        extra={<Flex gap={8}><DatePicker placeholder="Bitiş (süreli atama / vekalet)" value={validUntil} onChange={setValidUntil} /><Input placeholder="Gerekçe" value={reason} onChange={(ev) => setReason(ev.target.value)} /></Flex>}
      />
      <ChangeModal
        open={modal === 'perm'}
        title={`${d.user.userName} kullanıcısına doğrudan permission (istisna)`}
        label="Permission — gerekçe zorunlu; tercih edilen yol rol veya gruptur"
        options={toSelectOptions(perms)}
        buildChangeSet={(permissionId) => ({ userPermissions: [{ userId, permissionId, add: true }] })}
        apply={(permissionId) => api.post(`/api/users/${userId}/permissions`, { permissionId, reason: reason || 'Gerekçe girilmedi', validUntil: validUntil?.toISOString() })}
        onClose={() => { setModal(null); setReason(''); setValidUntil(null) }}
        onDone={reload}
        extra={<Flex gap={8}><Input placeholder="Gerekçe (zorunlu)" value={reason} onChange={(ev) => setReason(ev.target.value)} /><DatePicker placeholder="Bitiş" value={validUntil} onChange={setValidUntil} /></Flex>}
      />
      <ChangeModal
        open={modal === 'unit'}
        title={`${d.user.userName} → birime ekle`}
        label="Birim (grup kuralları ve veri kapsamı değişebilir)"
        options={units.filter((u) => u.group === d.user.tenant).map((u) => ({ value: u.value, label: u.label }))}
        buildChangeSet={(orgUnitId) => ({ userUnits: [{ userId, orgUnitId, add: true }] })}
        apply={(orgUnitId) => api.post(`/api/users/${userId}/units/${orgUnitId}`)}
        onClose={() => setModal(null)}
        onDone={reload}
      />
      {removal && (
        <ConfirmChangeModal open title={removal.title} changeSet={removal.changeSet} apply={removal.apply} onClose={() => setRemoval(undefined)} onDone={reload} />
      )}
      {modal === 'edit' && <UserEditModal detail={d} onClose={() => setModal(null)} onDone={reload} />}
    </>
  )
}

function EffectiveTab({ set }: { set?: EffectivePermissionSet }) {
  const [q, setQ] = useState('')
  const rows = useMemo(() => (set?.permissions ?? []).filter((p) => !q || p.code.includes(q) || p.name.toLowerCase().includes(q.toLowerCase())), [set, q])
  if (!set) return <Card loading />
  return (
    <Flex vertical gap={8}>
      {set.ignoredAssignments.length > 0 && <Alert type="warning" showIcon message="Tenant kuralı nedeniyle uygulanmayan atamalar" description={set.ignoredAssignments.map((x) => <div key={x}>{x}</div>)} />}
      <Input.Search placeholder="Permission ara" allowClear onSearch={setQ} onChange={(ev) => !ev.target.value && setQ('')} style={{ width: 320 }} />
      <Table<EffectivePermission>
        size="small"
        rowKey="permissionId"
        dataSource={rows}
        pagination={{ pageSize: 15 }}
        columns={[
          { title: 'Permission', render: (_, p) => <><Link to={`/permissions/${p.permissionId}`}><Code>{p.code}</Code></Link><br /><Typography.Text type="secondary">{p.name}</Typography.Text></>, sorter: (a, b) => a.code.localeCompare(b.code) },
          { title: 'Uygulama', dataIndex: 'application', render: (v) => <Tag>{v}</Tag>, filters: [...new Set(rows.map((r) => r.application))].map((a) => ({ text: a, value: a })), onFilter: (v, r) => r.application === v, width: 110 },
          { title: 'Risk', dataIndex: 'riskLevel', render: (v) => <SeverityTag severity={v} />, width: 90 },
          { title: 'Neden sahip? (kaynak yolu)', render: (_, p) => <SourceList sources={p.sources} /> },
        ]}
      />
    </Flex>
  )
}

function GroupsTab({ set, explicit }: { set?: EffectivePermissionSet; explicit: UserDetail['explicitGroups'] }) {
  if (!set) return <Card loading />
  return (
    <Flex vertical gap={12}>
      <Card size="small" title="Grup üyelikleri (neden üye?)">
        {set.groups.length === 0 && <Empty description="Hiçbir grubun kitlesinde değil" />}
        {set.groups.map((g) => (
          <div key={g.groupId} style={{ marginBottom: 6 }}>
            <Link to={`/groups/${g.groupId}`}><Tag color="purple">{g.code}</Tag></Link> {g.name} <Tag>{g.tenant}</Tag>
            <div style={{ marginLeft: 12 }}>{g.reasons.map((r, i) => <Typography.Text key={i} style={{ fontSize: 12, display: 'block' }}>• {r.kind === 'Member' ? 'Açık üye' : `Kural #${r.filterOrder}: ${r.text}`}</Typography.Text>)}</div>
          </div>
        ))}
        {explicit.filter((x) => x.validUntil).map((x) => <Tag key={x.groupId} color="gold">{x.code} açık üyeliği {fmtDate(x.validUntil)}'e kadar</Tag>)}
      </Card>
      {set.excludedFromGroups.length > 0 && (
        <Card size="small" title="Hariç tutulduğu gruplar (dahil kuralına uyuyor ama hariç kuralıyla çıkarıldı)">
          {set.excludedFromGroups.map((x) => <div key={x.groupId}><Tag color="volcano">{x.code}</Tag>{x.reason}</div>)}
        </Card>
      )}
      <Card size="small" title="Etkin roller (doğrudan + gruptan)">
        {set.roles.map((r) => (
          <div key={r.roleId} style={{ marginBottom: 4 }}>
            <Tag color="blue">{r.code}</Tag>{r.name} <Tag>{r.tenant}</Tag>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>{r.sources.map((s) => s.text).join(' | ')}</Typography.Text>
          </div>
        ))}
      </Card>
    </Flex>
  )
}

function EntitlementTab({ userId }: { userId: number }) {
  const clients = useOptions('clients')
  const permissions = useOptions('permissions')
  const [client, setClient] = useState<string>('nextral-desktop')
  const demoScopes = permissions.map((p) => p.code).join(' ')
  const { data, loading } = useApi<EntitlementResult>(`/api/users/${userId}/entitlements?client=${client}&scope=${encodeURIComponent(demoScopes)}`)
  return (
    <Flex vertical gap={8}>
      <Flex gap={8} align="center">
        <Typography.Text>Client:</Typography.Text>
        <Select style={{ width: 320 }} value={client} onChange={setClient} options={clients.map((c) => ({ value: c.code, label: c.label }))} />
        <Tooltip title="Rapor görünümü tüm katalog scope'larını verilmiş varsayar. Runtime kararı User entitlement ∩ Client allowed permissions ∩ token granted scopes kesişimidir."><Tag>Report scope: all</Tag></Tooltip>
        <Tag>ETag {data?.eTag}</Tag>
      </Flex>
      {data && data.blockedByClientPermission.length > 0 && (
        <Alert type="warning" showIcon message={`${data.blockedByClientPermission.length} Permission bu Client için allowed değil`}
          description={data.blockedByClientPermission.slice(0, 30).map((c) => <Tag key={c}>{c}</Tag>)} />
      )}
      <Table
        size="small"
        loading={loading}
        rowKey="permissionId"
        dataSource={data?.permissions ?? []}
        pagination={{ pageSize: 15 }}
        columns={[
          { title: 'Permission', render: (_, p) => <><Code>{p.code}</Code><br /><Typography.Text type="secondary">{p.name}</Typography.Text></> },
          { title: 'Client allowed permission', dataIndex: 'clientAllowedPermission', render: (v) => v ?? '—' },
          { title: 'Granted scope', dataIndex: 'matchedScope', render: (v) => v ? <Code>{v}</Code> : '—' },
          { title: 'İşlem anında kontrol', render: (_, p) => p.requiresRuntimeCheck ? p.policies.map((x: string) => <Tag key={x} color="geekblue">{x}</Tag>) : <Tag color="green">statik</Tag> },
          { title: 'Şu an', render: (_, p) => p.runtime ? <DecisionTag decision={p.runtime.decision} /> : '—' },
        ]}
      />
    </Flex>
  )
}

function UserEditModal({ detail, onClose, onDone }: { detail: UserDetail; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const [preview, setPreview] = useState<ChangeImpactResult>()
  const [saving, setSaving] = useState(false)
  const u = detail.user
  const values = () => ({ ...u, ...form.getFieldsValue() })

  const doPreview = async () => {
    const v = values()
    setPreview(await api.post<ChangeImpactResult>('/api/simulation/changes', {
      userUpdates: [{ userId: u.id, title: v.title ?? '', isActive: v.isActive, isOnLeave: v.isOnLeave, cashWithdrawalLimit: v.cashWithdrawalLimit }],
    }))
  }
  const save = async () => {
    setSaving(true)
    try {
      const r = await api.put<ChangeImpactResult>(`/api/users/${u.id}`, values())
      message.success('Kaydedildi. ' + r.summary)
      onDone()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setSaving(false)
    }
  }
  return (
    <Modal open title={`${u.userName} — bilgiler`} onCancel={onClose} width={900} destroyOnHidden
      footer={<Flex justify="space-between"><Button onClick={doPreview}>Etkiyi önizle</Button><Space><Button onClick={onClose}>Vazgeç</Button><Button type="primary" loading={saving} onClick={save}>Kaydet</Button></Space></Flex>}>
      <Alert type="info" showIcon style={{ marginBottom: 12 }} message="Unvan grup kurallarını (TITLE kriteri), izin durumu ve limit policy'leri etkiler. Değişiklik etki analizinden geçer." />
      <Form form={form} layout="vertical" initialValues={u} onValuesChange={() => setPreview(undefined)}>
        <Row gutter={12}>
          <Col span={12}><Form.Item name="fullName" label="Ad soyad"><Input /></Form.Item></Col>
          <Col span={12}><Form.Item name="title" label="Unvan"><Input /></Form.Item></Col>
          <Col span={8}><Form.Item name="cashWithdrawalLimit" label="Çekim limiti"><InputNumber style={{ width: '100%' }} min={0} step={10000} /></Form.Item></Col>
          <Col span={8}><Form.Item name="isOnLeave" label="İzinde" valuePropName="checked"><Switch /></Form.Item></Col>
          <Col span={8}><Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item></Col>
        </Row>
      </Form>
      {preview && <ImpactView impact={preview} />}
    </Modal>
  )
}

const extActionColor: Record<string, string> = { Grant: 'green', Modify: 'gold', Revoke: 'volcano', None: 'default' }
const extActionLabel: Record<string, string> = { Grant: 'AÇILACAK', Modify: 'SEVİYE DEĞİŞECEK', Revoke: 'KAPANACAK', None: 'SENKRON' }

/**
 * Kullanıcının dış sistem durumu: olması gereken (etkin permission'lardan) ↔ dış sistemde açık olan.
 * Kimlik yayılımı: CICS çağıran kullanıcının RACF yetkisini arar; fark varsa işlem mainframe'de reddedilir.
 */
function ExternalTab({ userId }: { userId: number }) {
  const { data, loading, reload } = useApi<UserExternalStatus>(`/api/users/${userId}/external`)
  const { message } = App.useApp()
  const [busy, setBusy] = useState(false)
  if (!data) return <Card loading={loading} />
  const pending = data.items.filter((i) => i.action !== 'None').length
  return (
    <Flex vertical gap={8}>
      <Alert type={data.inSync ? 'success' : 'warning'} showIcon
        message={data.inSync ? 'Dış sistem senkron: olması gereken = açık olan' : `${pending} fark var — mutabakat bekliyor`}
        description={<>Olması gereken durum kullanıcının etkin permission'larından hesaplanır (endpoint/API/permission bağımlılıkları + zincir, seviye: en yüksek).
          Açık olan = adaptörün başarıyla uyguladığı son durum.{!data.isActive && <b> Kullanıcı pasif: tüm dış yetkiler kapanır.</b>}</>}
        action={!data.inSync && <Button size="small" type="primary" loading={busy} onClick={async () => {
          setBusy(true)
          try {
            const r = await api.post<{ count: number }>(`/api/users/${userId}/external/reconcile`)
            message.success(`${r.count} provisioning aksiyonu çalıştı`)
            reload()
          } catch (e) { message.error((e as Error).message) } finally { setBusy(false) }
        }}>Mutabakat yap</Button>} />
      <Table size="small" rowKey={(i) => i.target.externalPermissionId} dataSource={data.items} pagination={{ pageSize: 15 }}
        columns={[
          { title: 'Dış yetki', render: (_, i) => <><ExternalTag system={i.target.system} code={i.target.code} resourceClass={i.target.resourceClass} /><br /><Typography.Text type="secondary" style={{ fontSize: 12 }}>{i.target.name}</Typography.Text></>, width: 260 },
          { title: 'Olması gereken', render: (_, i) => i.action === 'Revoke' ? <Tag>yok</Tag> : <Tag color="blue">{i.desiredLevel?.toUpperCase() ?? 'üye'}</Tag>, width: 110 },
          { title: 'Açık olan', render: (_, i) => i.action === 'Grant' ? <Tag>yok</Tag> : <Tag>{i.currentLevel?.toUpperCase() ?? 'üye'}</Tag>, width: 100 },
          { title: 'Durum', dataIndex: 'action', render: (v) => <Tag color={extActionColor[v]}>{extActionLabel[v]}</Tag>, width: 150,
            filters: Object.entries(extActionLabel).map(([value, text]) => ({ value, text })), onFilter: (v, i) => i.action === v },
          { title: 'Neden', dataIndex: 'reasons', render: (v: string[]) => v.slice(0, 4).map((r, i) => <div key={i} style={{ fontSize: 12 }}>{r}</div>).concat(v.length > 4 ? [<Typography.Text key="m" type="secondary" style={{ fontSize: 12 }}>+{v.length - 4} neden daha</Typography.Text>] : []) },
        ]} />
    </Flex>
  )
}
