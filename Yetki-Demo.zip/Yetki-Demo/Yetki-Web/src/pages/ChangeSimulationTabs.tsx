import { Alert, App, Button, Card, Checkbox, Col, Empty, Flex, Input, Radio, Row, Select, Spin, Switch, Tag, Typography } from 'antd'
import { DataTable as Table } from '../components/DataTable'
import { DeleteOutlined, DownloadOutlined, ExperimentOutlined } from '@ant-design/icons'
import { useCallback, useMemo, useState } from 'react'
import type { Dayjs } from 'dayjs'
import { api } from '../api/client'
import type {
  AuthorizationChangeSet, ChangeImpactResult, ConditionDraft, ConditionTypeInfo, ConditionView, DecisionStrategy, GroupFilterDraft,
  ImpactScenario, InclusionMode, ParamDef, PolicyChangeSet, PolicyMode, RuleView,
} from '../api/types'
import { toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { Code, strategyLabel } from '../components/common'
import { ImpactView } from '../components/ImpactView'
import { DEFAULT_SCENARIOS, PolicyImpactView, ScenarioSettings, nextBusinessMorning, usePolicyImpact } from '../components/PolicyImpact'
import { GroupFilterEditor } from '../components/GroupFilterEditor'
import { ConditionBuilder, emptyPredicate, renderDraft } from '../components/ConditionBuilder'
import { downloadCsv } from '../components/csv'
import { useManagedResultScroll, useReportDownload } from '../components/ReportDownloadContext'

function useRbacImpact() {
  const { message } = App.useApp()
  const [result, setResult] = useState<ChangeImpactResult>()
  const [loading, setLoading] = useState(false)
  const run = async (cs: AuthorizationChangeSet) => {
    setLoading(true)
    try {
      setResult(await api.post<ChangeImpactResult>('/api/simulation/changes', cs))
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setLoading(false)
    }
  }
  return { result, loading, run, setResult }
}

const Result = ({ r, loading }: { r?: ChangeImpactResult; loading: boolean }) =>
  loading ? <Spin /> : r ? <ImpactView impact={r} /> : <Empty description="Değişiklikleri seçip 'Etkiyi hesapla'ya basın" />

// ================================ Kullanıcı ================================

interface UserDetailLite { user: { id: number; userName: string; title?: string; isOnLeave: boolean; isActive: boolean; cashWithdrawalLimit: number; tenant: string }; roles: { roleId: number; code: string }[]; units: { orgUnitId: number; code: string }[] }

interface DraftChangeItem { kind: 'Role' | 'Organizational unit' | 'Permission'; value: number; label: string }

function ChangePreview({ tone, items, onRemove }: { tone: 'add' | 'remove'; items: DraftChangeItem[]; onRemove: (item: DraftChangeItem) => void }) {
  return (
    <div className={`what-if-change-preview is-${tone}`}>
      {items.length === 0
        ? <small className="what-if-change-preview-empty">Henüz seçim yapılmadı</small>
        : <div className="what-if-change-preview-list">{items.map((item) => (
          <div key={`${item.kind}-${item.value}`} className="what-if-change-preview-item">
            <strong title={item.label}>{item.label}</strong>
            <Button type="text" danger aria-label={`${item.label} seçimini kaldır`} icon={<DeleteOutlined />} onClick={() => onRemove(item)} />
          </div>
        ))}</div>}
    </div>
  )
}

/** Seçim değişince gövde key ile yeniden kurulur: taslak değişiklikler sıfırlanır (effect gerekmez). */
export function UserTab({ initial }: { initial?: number }) {
  const [userId, setUserId] = useState<number | undefined>(initial)
  return <UserTabBody key={userId ?? 0} userId={userId} onSelect={setUserId} />
}

function UserTabBody({ userId, onSelect }: { userId?: number; onSelect: (id: number) => void }) {
  const users = useOptions('users')
  const roles = useOptions('roles')
  const units = useOptions('units')
  const detail = useApi<UserDetailLite>(userId ? `/api/users/${userId}` : null)
  const [addRoles, setAddRoles] = useState<number[]>([])
  const [removeRoles, setRemoveRoles] = useState<number[]>([])
  const [addUnits, setAddUnits] = useState<number[]>([])
  const [removeUnits, setRemoveUnits] = useState<number[]>([])
  const [title, setTitle] = useState<string>()
  const [onLeave, setOnLeave] = useState<boolean>()
  const { result, loading, run } = useRbacImpact()
  const d = detail.data
  const addedChanges: DraftChangeItem[] = [
    ...addRoles.map((value) => ({ kind: 'Role' as const, value, label: roles.find((r) => r.value === value)?.code ?? String(value) })),
    ...addUnits.map((value) => ({ kind: 'Organizational unit' as const, value, label: units.find((u) => u.value === value)?.code ?? String(value) })),
  ]
  const removedChanges: DraftChangeItem[] = d ? [
    ...removeRoles.map((value) => ({ kind: 'Role' as const, value, label: d.roles.find((r) => r.roleId === value)?.code ?? String(value) })),
    ...removeUnits.map((value) => ({ kind: 'Organizational unit' as const, value, label: d.units.find((u) => u.orgUnitId === value)?.code ?? String(value) })),
  ] : []
  const cs = (): AuthorizationChangeSet => ({
    userRoles: [...addRoles.map((roleId) => ({ userId: userId!, roleId, add: true })), ...removeRoles.map((roleId) => ({ userId: userId!, roleId, add: false }))],
    userUnits: [...addUnits.map((orgUnitId) => ({ userId: userId!, orgUnitId, add: true })), ...removeUnits.map((orgUnitId) => ({ userId: userId!, orgUnitId, add: false }))],
    userUpdates: title !== undefined || onLeave !== undefined ? [{ userId: userId!, title, isOnLeave: onLeave }] : [],
  })
  return (
    <Row gutter={[20, 20]}>
      <Col xs={24} xl={10}>
        <Card size="small" className="what-if-change-editor">
          <div className="what-if-editor-heading">
            <div><small>USER CHANGE</small><p>Rol, birim, unvan veya izin durumu değişirse erişimler nasıl değişir?</p></div>
          </div>
          <div className="what-if-editor-body">
            <div className="what-if-change-pair">
              <section className="what-if-current-state">
                <label className="what-if-field-label" htmlFor="what-if-user">Hedef kullanıcı</label>
                <Select id="what-if-user" showSearch optionFilterProp="label" placeholder="Kullanıcı seçin" value={userId} onChange={onSelect} options={toSelectOptions(users)} />
                {d ? <div className="what-if-current-detail">
                  <div className="what-if-section-title"><span className="what-if-section-mark">01</span><div><strong>Mevcut durum</strong><small>Simülasyonun başlangıç noktası</small></div></div>
                  <div className="what-if-current-row"><span>Roller</span><div>{d.roles.map((r) => <Tag key={r.roleId} color="blue">{r.code}</Tag>)}{d.roles.length === 0 && <em>Rol yok</em>}</div></div>
                  <div className="what-if-current-row"><span>Birimler</span><div>{d.units.map((u) => <Tag key={u.orgUnitId}>{u.code}</Tag>)}{d.units.length === 0 && <em>Birim yok</em>}</div></div>
                </div> : <div className="what-if-current-prompt"><strong>Kullanıcı seçin</strong><small>Mevcut role ve birim bilgileri burada gösterilecek.</small></div>}
              </section>

              {d && <>
                <section className="what-if-change-box is-add">
                  <div className="what-if-change-box-head"><b>+</b><div><strong>Eklenecekler</strong><small>Yeni erişim kaynağı oluşturur</small></div></div>
                  <div className="what-if-change-category">
                    <div className="what-if-change-category-head"><div><strong>Role</strong><small>Kullanıcıya atanacak roller</small></div><span>{addRoles.length}</span></div>
                    <Select mode="multiple" maxTagCount={0} maxTagPlaceholder={() => null} placeholder="Role seçin" value={addRoles} onChange={setAddRoles} optionFilterProp="label" options={toSelectOptions(roles, d.roles.map((r) => r.roleId))} />
                    <ChangePreview tone="add" items={addedChanges.filter((item) => item.kind === 'Role')} onRemove={(item) => setAddRoles(addRoles.filter((id) => id !== item.value))} />
                  </div>
                  <div className="what-if-change-category">
                    <div className="what-if-change-category-head"><div><strong>Birim</strong><small>Kullanıcının dahil edileceği organizational unit</small></div><span>{addUnits.length}</span></div>
                    <Select mode="multiple" maxTagCount={0} maxTagPlaceholder={() => null} placeholder="Birim seçin" value={addUnits} onChange={setAddUnits} optionFilterProp="label" options={units.filter((u) => u.group === d.user.tenant && !d.units.some((x) => x.orgUnitId === u.value)).map((u) => ({ value: u.value, label: u.label }))} />
                    <ChangePreview tone="add" items={addedChanges.filter((item) => item.kind === 'Organizational unit')} onRemove={(item) => setAddUnits(addUnits.filter((id) => id !== item.value))} />
                  </div>
                </section>

                <section className="what-if-change-box is-remove">
                  <div className="what-if-change-box-head"><b>−</b><div><strong>Kaldırılacaklar</strong><small>Mevcut erişim kaynağını kaldırır</small></div></div>
                  <div className="what-if-change-category">
                    <div className="what-if-change-category-head"><div><strong>Role</strong><small>Kullanıcıdan alınacak roller</small></div><span>{removeRoles.length}</span></div>
                    <Select mode="multiple" maxTagCount={0} maxTagPlaceholder={() => null} placeholder="Role seçin" value={removeRoles} onChange={setRemoveRoles} options={d.roles.map((r) => ({ value: r.roleId, label: r.code }))} />
                    <ChangePreview tone="remove" items={removedChanges.filter((item) => item.kind === 'Role')} onRemove={(item) => setRemoveRoles(removeRoles.filter((id) => id !== item.value))} />
                  </div>
                  <div className="what-if-change-category">
                    <div className="what-if-change-category-head"><div><strong>Birim</strong><small>Kullanıcının çıkarılacağı organizational unit</small></div><span>{removeUnits.length}</span></div>
                    <Select mode="multiple" maxTagCount={0} maxTagPlaceholder={() => null} placeholder="Birim seçin" value={removeUnits} onChange={setRemoveUnits} options={d.units.map((u) => ({ value: u.orgUnitId, label: u.code }))} />
                    <ChangePreview tone="remove" items={removedChanges.filter((item) => item.kind === 'Organizational unit')} onRemove={(item) => setRemoveUnits(removeUnits.filter((id) => id !== item.value))} />
                  </div>
                </section>
              </>}
              {!d && <div className="what-if-selection-placeholder"><span>02</span><strong>Değişiklik alanı kullanıcı seçiminden sonra açılır</strong><small>Role, birim ve attribute değişikliklerini seçilen kullanıcı üzerinde tasarlayabilirsiniz.</small></div>}
            </div>

            {d && <>
              <section className="what-if-attribute-box">
                <div className="what-if-section-title"><span className="what-if-section-mark">02</span><div><strong>Attribute değişiklikleri</strong><small>Group ve policy değerlendirmelerini etkileyebilir</small></div></div>
                <label className="what-if-field-label">Unvan</label>
                <Input placeholder={d.user.title || 'Yeni unvanı girin'} value={title} onChange={(e) => setTitle(e.target.value || undefined)} />
                <Checkbox checked={onLeave ?? d.user.isOnLeave} onChange={(e) => setOnLeave(e.target.checked)}>Kullanıcı izinde</Checkbox>
              </section>

              <div className="what-if-editor-footer">
                <span>Değişiklikler kaydedilmez</span>
                <Button type="primary" icon={<ExperimentOutlined />} loading={loading} onClick={() => run(cs())}>Etkiyi hesapla</Button>
              </div>
            </>}
          </div>
        </Card>
      </Col>
      <Col xs={24} xl={14} className="what-if-result-panel"><Result r={result} loading={loading} /></Col>
    </Row>
  )
}

// ================================ Rol ================================

export function RoleTab({ initial }: { initial?: number }) {
  const [roleId, setRoleId] = useState<number | undefined>(initial)
  return <RoleTabBody key={roleId ?? 0} roleId={roleId} onSelect={setRoleId} />
}

function RoleTabBody({ roleId, onSelect }: { roleId?: number; onSelect: (id: number) => void }) {
  const roles = useOptions('roles')
  const detail = useApi<{ role: { isActive: boolean; isInheritable: boolean }; policies: { id: number; code: string }[]; permissions: { id: number; code: string; accesses: string[] }[] }>(roleId ? `/api/roles/${roleId}` : null)
  const [deactivate, setDeactivate] = useState(false)
  const [inheritable, setInheritable] = useState<boolean>()
  const { result, loading, run } = useRbacImpact()
  const d = detail.data
  return (
    <Row gutter={[20, 20]}>
      <Col xs={24} xl={8}>
        <Card size="small" className="what-if-change-editor">
          <div className="what-if-editor-heading"><div><small>ROLE CHANGE</small><p>Rol pasifleştirme ve tenant mirasının kapsadığı kullanıcıları incele.</p></div></div>
          <div className="what-if-editor-body">
            <div className="what-if-config-grid">
              <section className="what-if-current-state">
                <label className="what-if-field-label" htmlFor="what-if-role">Hedef role</label>
                <Select id="what-if-role" showSearch optionFilterProp="label" placeholder="Role seçin" value={roleId} onChange={onSelect} options={toSelectOptions(roles)} />
                {d && <div className="what-if-current-detail">
                  <div className="what-if-section-title"><span className="what-if-section-mark">01</span><div><strong>Mevcut durum</strong><small>Role kapsamı ve bağlantıları</small></div></div>
                  <div className="what-if-current-row"><span>Durum</span><div><Tag color={d.role.isActive ? 'green' : 'red'}>{d.role.isActive ? 'ACTIVE' : 'PASSIVE'}</Tag><Tag color={d.role.isInheritable ? 'blue' : 'default'}>{d.role.isInheritable ? 'INHERITABLE' : 'LOCAL'}</Tag></div></div>
                  <div className="what-if-current-row"><span>Policies</span><div>{d.policies.map((p) => <Tag key={p.id} color="blue">{p.code}</Tag>)}{d.policies.length === 0 && <em>Policy yok</em>}</div></div>
                  <div className="what-if-current-row"><span>Permissions</span><div>{d.permissions.map((p) => <Tag key={p.id}>{p.code}</Tag>)}{d.permissions.length === 0 && <em>Permission yok</em>}</div></div>
                </div>}
              </section>

              <section className="what-if-config-box is-warning">
                <div className="what-if-config-box-head"><span>02</span><div><strong>Lifecycle</strong><small>Role durumunu değiştir</small></div></div>
                <Checkbox disabled={!d} checked={deactivate} onChange={(e) => setDeactivate(e.target.checked)}>Role pasif hale gelsin</Checkbox>
                <p>Role pasifleştirilirse bu role üzerinden gelen effective access bağlantıları yeniden hesaplanır.</p>
              </section>

              <section className="what-if-config-box is-primary">
                <div className="what-if-config-box-head"><span>03</span><div><strong>Tenant inheritance</strong><small>Alt tenant kapsamını değiştir</small></div></div>
                <Checkbox disabled={!d} checked={d ? (inheritable ?? d.role.isInheritable) : false} onChange={(e) => setInheritable(e.target.checked)}>Alt tenant'lara miras verilsin</Checkbox>
                <p>Inheritance değişikliği, role doğrudan atanmamış alt tenant kullanıcılarını da etkileyebilir.</p>
              </section>
            </div>

            <div className="what-if-editor-footer">
              <span>Role–permission bağlantıları Policy ve Permission ekranlarında yönetilir.</span>
              <Button type="primary" icon={<ExperimentOutlined />} loading={loading} disabled={!d} onClick={() => run({
                roleUpdates: deactivate || inheritable !== undefined ? [{ roleId: roleId!, isActive: deactivate ? false : undefined, isInheritable: inheritable }] : [],
              })}>Etkiyi hesapla</Button>
            </div>
          </div>
        </Card>
      </Col>
      <Col xs={24} xl={16} className="what-if-result-panel"><Result r={result} loading={loading} /></Col>
    </Row>
  )
}

// ================================ Grup ================================

interface GroupLite {
  group: { id: number; tenantId: number }
  filters: { mode: InclusionMode; description?: string; criteria: { attribute: string; values: string[] }[] }[]
  roles: { id: number; code: string }[]
}

export function GroupTab({ initial }: { initial?: number }) {
  const [groupId, setGroupId] = useState<number | undefined>(initial)
  return <GroupTabBody key={groupId ?? 0} groupId={groupId} onSelect={setGroupId} />
}

const toFilterDrafts = (d: GroupLite): GroupFilterDraft[] =>
  d.filters.map((f) => ({ mode: f.mode, description: f.description, criteria: f.criteria.map((c) => ({ ...c, values: [...c.values] })) }))

function GroupTabBody({ groupId, onSelect }: { groupId?: number; onSelect: (id: number) => void }) {
  const groups = useOptions('groups')
  const roles = useOptions('roles')
  const users = useOptions('users')
  const detail = useApi<GroupLite>(groupId ? `/api/groups/${groupId}` : null)
  // null = henüz düzenlenmedi → sunucudaki kurallar gösterilir
  const [edited, setEdited] = useState<GroupFilterDraft[] | null>(null)
  const [addRoles, setAddRoles] = useState<number[]>([])
  const [removeRoles, setRemoveRoles] = useState<number[]>([])
  const [addMembers, setAddMembers] = useState<number[]>([])
  const { result, loading, run } = useRbacImpact()
  const d = detail.data
  const filters = edited ?? (d ? toFilterDrafts(d) : [])
  const filtersChanged = edited !== null
  const addedRoleChanges: DraftChangeItem[] = addRoles.map((value) => ({ kind: 'Role', value, label: roles.find((r) => r.value === value)?.code ?? String(value) }))
  const removedRoleChanges: DraftChangeItem[] = removeRoles.map((value) => ({ kind: 'Role', value, label: d?.roles.find((r) => r.id === value)?.code ?? String(value) }))
  const addedMemberChanges: DraftChangeItem[] = addMembers.map((value) => ({ kind: 'Organizational unit', value, label: users.find((u) => u.value === value)?.code ?? String(value) }))
  return (
    <Row gutter={[20, 20]}>
      <Col xs={24} xl={11}>
        <Card size="small" className="what-if-change-editor">
          <div className="what-if-editor-heading"><div><small>AUDIENCE CHANGE</small><p>Kitle kriterleri, üyeler ve verilen roller değiştiğinde sonucu gör.</p></div></div>
          <div className="what-if-editor-body">
            <div className="what-if-config-grid">
              <section className="what-if-current-state">
                <label className="what-if-field-label" htmlFor="what-if-group">Hedef group</label>
                <Select id="what-if-group" showSearch optionFilterProp="label" placeholder="Group seçin" value={groupId} onChange={onSelect} options={toSelectOptions(groups)} />
                {d && <div className="what-if-current-detail">
                  <div className="what-if-section-title"><span className="what-if-section-mark">01</span><div><strong>Mevcut durum</strong><small>Audience kaynakları</small></div></div>
                  <div className="what-if-current-row"><span>Roles</span><div>{d.roles.map((r) => <Tag key={r.id} color="blue">{r.code}</Tag>)}{d.roles.length === 0 && <em>Role yok</em>}</div></div>
                  <div className="what-if-current-row"><span>Filters</span><div><Tag>{d.filters.length} filter</Tag></div></div>
                </div>}
              </section>

              <section className="what-if-config-box is-wide">
                <div className="what-if-config-box-head"><span>02</span><div><strong>Audience rules</strong><small>Dynamic membership kriterlerini düzenle</small></div>{filtersChanged && <Tag color="gold">CHANGED</Tag>}</div>
                {d ? <GroupFilterEditor value={filters} onChange={setEdited} /> : <div className="what-if-inline-empty">Önce group seçin</div>}
              </section>

              <section className="what-if-change-category is-add">
                <div className="what-if-change-category-head"><div><strong>Role ekle</strong><small>Group yeni role versin</small></div><span>{addRoles.length}</span></div>
                <Select disabled={!d} mode="multiple" maxTagCount={0} maxTagPlaceholder={() => null} placeholder="Role seçin" value={addRoles} onChange={setAddRoles} optionFilterProp="label" options={toSelectOptions(roles, d?.roles.map((r) => r.id) ?? [])} />
                <ChangePreview tone="add" items={addedRoleChanges} onRemove={(item) => setAddRoles(addRoles.filter((id) => id !== item.value))} />
              </section>

              <section className="what-if-change-category is-remove">
                <div className="what-if-change-category-head"><div><strong>Role kaldır</strong><small>Group artık bu role vermesin</small></div><span>{removeRoles.length}</span></div>
                <Select disabled={!d} mode="multiple" maxTagCount={0} maxTagPlaceholder={() => null} placeholder="Role seçin" value={removeRoles} onChange={setRemoveRoles} options={d?.roles.map((r) => ({ value: r.id, label: r.code })) ?? []} />
                <ChangePreview tone="remove" items={removedRoleChanges} onRemove={(item) => setRemoveRoles(removeRoles.filter((id) => id !== item.value))} />
              </section>

              <section className="what-if-change-category is-add">
                <div className="what-if-change-category-head"><div><strong>Açık üye ekle</strong><small>Dynamic filter dışında explicit member</small></div><span>{addMembers.length}</span></div>
                <Select disabled={!d} mode="multiple" maxTagCount={0} maxTagPlaceholder={() => null} placeholder="User seçin" value={addMembers} onChange={setAddMembers} optionFilterProp="label" options={toSelectOptions(users)} />
                <ChangePreview tone="add" items={addedMemberChanges} onRemove={(item) => setAddMembers(addMembers.filter((id) => id !== item.value))} />
              </section>
            </div>

            <div className="what-if-editor-footer">
              <span>Değişiklikler kaydedilmeden effective access ve SoD etkisi hesaplanır.</span>
              <Button type="primary" icon={<ExperimentOutlined />} loading={loading} disabled={!d} onClick={() => run({
                groupFilters: filtersChanged ? [{ groupId: groupId!, filters }] : [],
                groupRoles: [
                  ...addRoles.map((roleId) => ({ groupId: groupId!, roleId, add: true })),
                  ...removeRoles.map((roleId) => ({ groupId: groupId!, roleId, add: false })),
                ],
                groupMembers: addMembers.map((userId) => ({ groupId: groupId!, userId, add: true })),
              })}>Etkiyi hesapla</Button>
            </div>
          </div>
        </Card>
      </Col>
      <Col xs={24} xl={13} className="what-if-result-panel"><Result r={result} loading={loading} /></Col>
    </Row>
  )
}

// ================================ Policy ================================

interface PolicyLite {
  policy: { id: number; code: string; mode: PolicyMode; isActive: boolean; decisionStrategy: DecisionStrategy }
  rules: RuleView[]
  usedBy: { permissions: { id: number; code: string; coverage: number }[] }
}

interface Pred { conditionId: number; rule: string; type: string; parameters: Record<string, string> }

function collectPredicates(rules: RuleView[]): Pred[] {
  const out: Pred[] = []
  const walk = (rule: string, n?: ConditionView) => {
    if (!n) return
    if (n.kind === 'Predicate' && n.id > 0 && n.conditionType) out.push({ conditionId: n.id, rule, type: n.conditionType, parameters: n.parameters })
    n.children.forEach((c) => walk(rule, c))   // policy referansının parametreleri o policy seçilerek değiştirilir
  }
  rules.forEach((r) => walk(r.code, r.condition))
  return out
}

export function PolicyTab({ initial }: { initial?: number }) {
  const [policyId, setPolicyId] = useState<number | undefined>(initial)
  return <PolicyTabBody key={policyId ?? 0} policyId={policyId} onSelect={setPolicyId} />
}

function PolicyTabBody({ policyId, onSelect }: { policyId?: number; onSelect: (id: number) => void }) {
  const policies = useOptions('policies')
  const types = useApi<ConditionTypeInfo[]>('/api/condition-types').data ?? []
  const detail = useApi<PolicyLite>(policyId ? `/api/policies/${policyId}` : null)
  const [active, setActive] = useState<boolean>()
  const [mode, setMode] = useState<PolicyMode>()
  const [strategy, setStrategy] = useState<DecisionStrategy>()
  const [ruleOverrides, setRuleOverrides] = useState<Record<number, { isActive?: boolean }>>({})
  const [paramTarget, setParamTarget] = useState<number>()
  const [paramValues, setParamValues] = useState<Record<string, string>>({})
  const [draftOn, setDraftOn] = useState(false)
  const [draft, setDraft] = useState<ConditionDraft>(emptyPredicate())
  const [scenarios, setScenarios] = useState<ImpactScenario[]>(DEFAULT_SCENARIOS)
  const [asOf, setAsOf] = useState<Dayjs | undefined>(nextBusinessMorning())
  const { result, loading, run } = usePolicyImpact()

  const d = detail.data
  const preds = useMemo(() => collectPredicates(d?.rules ?? []), [d])
  const selectedPred = preds.find((p) => p.conditionId === paramTarget)
  const paramDefs: ParamDef[] = selectedPred ? JSON.parse(types.find((t) => t.code === selectedPred.type)?.parameterSchemaJson ?? '[]') : []

  const changes = (): PolicyChangeSet => ({
    policyActivations: active !== undefined && active !== d!.policy.isActive ? [{ policyId: policyId!, isActive: active }] : [],
    policyModes: mode && mode !== d!.policy.mode ? [{ policyId: policyId!, mode }] : [],
    policyStrategies: strategy && strategy !== d!.policy.decisionStrategy ? [{ policyId: policyId!, strategy }] : [],
    ruleOverrides: Object.entries(ruleOverrides).map(([ruleId, o]) => ({ ruleId: Number(ruleId), ...o })),
    conditionOverrides: selectedPred ? [{ conditionId: selectedPred.conditionId, parameters: { ...selectedPred.parameters, ...paramValues } }] : [],
    addedRules: draftOn ? [{ policyId: policyId!, code: 'WHATIF_DRAFT', name: 'What-If taslak rule', order: 99, reasonCode: 'WHATIF_DRAFT', condition: draft }] : [],
  })

  return (
    <Row gutter={[20, 20]}>
      <Col xs={24} xl={10}>
        <Card size="small" className="what-if-change-editor">
          <div className="what-if-editor-heading"><div><small>POLICY CHANGE</small><p>Rule, condition, mode ve decision strategy değişikliklerini farklı senaryolarda karşılaştır.</p></div></div>
          <div className="what-if-editor-body">
            <div className="what-if-policy-overview">
              <section className="what-if-current-state">
                <label className="what-if-field-label" htmlFor="what-if-policy">Hedef policy</label>
                <Select id="what-if-policy" showSearch optionFilterProp="label" placeholder="Policy seçin" value={policyId} onChange={onSelect} options={toSelectOptions(policies)} />
                {d && <div className="what-if-current-detail">
                  <div className="what-if-current-row"><span>Mode</span><div><Tag color="blue">{d.policy.mode}</Tag></div></div>
                  <div className="what-if-current-row"><span>Strategy</span><div><Tag>{strategyLabel[d.policy.decisionStrategy]}</Tag></div></div>
                  <div className="what-if-current-row"><span>Rules</span><div><Tag>{d.rules.length}</Tag></div></div>
                </div>}
              </section>

              <section className="what-if-config-box is-primary">
                <div className="what-if-config-box-head"><span>01</span><div><strong>Policy behavior</strong><small>Lifecycle, mode ve decision strategy</small></div></div>
                <div className="what-if-policy-controls">
                  <label>Aktif <Switch disabled={!d} checked={d ? (active ?? d.policy.isActive) : false} onChange={setActive} /></label>
                  <Radio.Group disabled={!d} size="small" value={d ? (mode ?? d.policy.mode) : undefined} onChange={(e) => setMode(e.target.value)} options={[{ value: 'Enforce', label: 'Enforce' }, { value: 'ReportOnly', label: 'ReportOnly' }, { value: 'Advisory', label: 'Advisory' }]} optionType="button" />
                  <Select disabled={!d} placeholder="Decision strategy" value={d ? (strategy ?? d.policy.decisionStrategy) : undefined} onChange={setStrategy}
                    options={(Object.keys(strategyLabel) as DecisionStrategy[]).map((a) => ({ value: a, label: strategyLabel[a] }))} />
                </div>
              </section>

              <section className="what-if-config-box">
                <div className="what-if-config-box-head"><span>02</span><div><strong>Permission coverage</strong><small>Bu policy'yi kullanan permission'lar</small></div></div>
                <div className="what-if-token-cloud">{d?.usedBy.permissions.map((p) => <Tag key={p.id}>{p.code} · {p.coverage}</Tag>)}
                  {d && d.usedBy.permissions.length === 0 && <Tag color="orange">Policy kullanımda değil</Tag>}
                  {!d && <div className="what-if-inline-empty">Önce policy seçin</div>}</div>
              </section>
            </div>

            {d && <>
              <div className="what-if-policy-change-grid">
              <Card size="small" className="what-if-policy-change-card" title="A · Rule durumu">
                {d.rules.map((r) => (
                  <Flex key={r.id} justify="space-between" align="center" style={{ marginBottom: 4 }}>
                    <span style={{ fontSize: 12 }}><Code>{r.code}</Code> <Typography.Text type="secondary">{r.expression}</Typography.Text></span>
                    <Flex gap={6}>
                      <Switch size="small" checked={ruleOverrides[r.id]?.isActive ?? r.isActive} onChange={(isActive) => setRuleOverrides({ ...ruleOverrides, [r.id]: { ...ruleOverrides[r.id], isActive } })} />
                    </Flex>
                  </Flex>
                ))}
              </Card>
              <Card size="small" className="what-if-policy-change-card" title="B · Condition parametresi">
                <Select allowClear style={{ width: '100%' }} value={paramTarget} onChange={(v) => { setParamTarget(v); setParamValues({}) }} placeholder="Predicate seç"
                  options={preds.map((p) => ({ value: p.conditionId, label: `${p.rule} · ${p.type}(${Object.entries(p.parameters).map(([k, v]) => `${k}=${v}`).join(', ')})` }))} />
                {selectedPred && paramDefs.map((pd) => (
                  <Input key={pd.key} size="small" style={{ marginTop: 4 }} addonBefore={pd.key} placeholder={selectedPred.parameters[pd.key] ?? pd.defaultValue}
                    value={paramValues[pd.key] ?? selectedPred.parameters[pd.key] ?? ''} onChange={(e) => setParamValues({ ...paramValues, [pd.key]: e.target.value })} />
                ))}
              </Card>
              <Card size="small" className="what-if-policy-change-card" title={<><Checkbox checked={draftOn} onChange={(e) => setDraftOn(e.target.checked)} /> C · Rule ekle</>}>
                {draftOn && (<><Typography.Text type="secondary" style={{ fontSize: 12 }}>{renderDraft(draft)}</Typography.Text><ConditionBuilder value={draft} onChange={setDraft} types={types} /></>)}
              </Card>
              </div>
              <ScenarioSettings scenarios={scenarios} setScenarios={setScenarios} asOf={asOf} setAsOf={setAsOf} />
            </>}

            <div className="what-if-editor-footer">
              <span>Policy değişikliği kaydedilmeden yapısal fark ve karar senaryoları hesaplanır.</span>
              <Button type="primary" icon={<ExperimentOutlined />} loading={loading} disabled={!d} onClick={() => run(changes(), scenarios, asOf)}>Etkiyi hesapla</Button>
            </div>
          </div>
        </Card>
      </Col>
      <Col xs={24} xl={14} className="what-if-result-panel">{loading ? <Spin /> : result ? <PolicyImpactView result={result} /> : <Empty description="Policy değişikliği tanımlayıp hesaplayın" />}</Col>
    </Row>
  )
}

// ================================ SoD ================================

export function SodTab() {
  const accesses = useOptions('resource-scopes')
  const roles = useOptions('roles')
  const { message } = App.useApp()
  const [resourceScopeIds, setAccesses] = useState<number[]>([])
  const [roleIds, setRoles] = useState<number[]>([])
  const [rows, setRows] = useState<{ userName: string; fullName: string; conflicts: { code: string; matchedMembers: { code: string; paths: string[] }[] }[] }[]>()
  const exportCsv = useCallback(() => {
    if (!rows) return
    downloadCsv('sod-simulasyon-raporu.csv', [
      ['Kullanıcı', 'Ad Soyad', 'Çakışan üyeler', 'Kaynak yolları'],
      ...rows.map((r) => [
        r.userName,
        r.fullName,
        r.conflicts.flatMap((c) => c.matchedMembers.map((m) => m.code)).join(' | '),
        r.conflicts.flatMap((c) => c.matchedMembers.flatMap((m) => m.paths)).join(' | '),
      ]),
    ])
  }, [rows])
  const { isManaged } = useReportDownload(rows ? exportCsv : undefined)
  useManagedResultScroll(isManaged, rows)
  const permissionChanges: DraftChangeItem[] = resourceScopeIds.map((value) => ({ kind: 'Permission', value, label: accesses.find((a) => a.value === value)?.code ?? String(value) }))
  const roleChanges: DraftChangeItem[] = roleIds.map((value) => ({ kind: 'Role', value, label: roles.find((r) => r.value === value)?.code ?? String(value) }))
  return (
    <Row gutter={[20, 20]}>
      <Col xs={24} xl={8}>
        <Card size="small" className="what-if-change-editor">
          <div className="what-if-editor-heading"><div><small>CONTROL PROPOSAL</small><p>Taslak yetki ayrılığı kuralının mevcut ihlallerini uygulamadan bul.</p></div></div>
          <div className="what-if-editor-body">
            <div className="what-if-sod-grid">
              <section className="what-if-change-category is-add">
                <div className="what-if-change-category-head"><div><strong>Permission members</strong><small>Birlikte bulunması kontrol edilecek permission'lar</small></div><span>{resourceScopeIds.length}</span></div>
                <Select mode="multiple" maxTagCount={0} maxTagPlaceholder={() => null} placeholder="Permission seçin" optionFilterProp="label" value={resourceScopeIds} onChange={setAccesses} options={toSelectOptions(accesses)} />
                <ChangePreview tone="add" items={permissionChanges} onRemove={(item) => setAccesses(resourceScopeIds.filter((id) => id !== item.value))} />
              </section>
              <section className="what-if-change-category is-add">
                <div className="what-if-change-category-head"><div><strong>Role members</strong><small>Birlikte bulunması kontrol edilecek role'ler</small></div><span>{roleIds.length}</span></div>
                <Select mode="multiple" maxTagCount={0} maxTagPlaceholder={() => null} placeholder="Role seçin" optionFilterProp="label" value={roleIds} onChange={setRoles} options={toSelectOptions(roles)} />
                <ChangePreview tone="add" items={roleChanges} onRemove={(item) => setRoles(roleIds.filter((id) => id !== item.value))} />
              </section>
            </div>
            <div className="what-if-control-note"><strong>İhlal koşulu</strong><span>Seçilen üyelerden en az iki tanesine aynı kullanıcının sahip olması.</span></div>
            <div className="what-if-editor-footer">
              <span>Bu işlem yalnızca mevcut ihlalleri analiz eder; SoD kuralı kaydedilmez.</span>
              <Button type="primary" icon={<ExperimentOutlined />} disabled={resourceScopeIds.length + roleIds.length < 2} onClick={async () => { try { setRows(await api.post('/api/simulation/sod-rule', { code: 'DRAFT', resourceScopeIds, roleIds })) } catch (e) { message.error((e as Error).message) } }}>Mevcut ihlalleri bul</Button>
            </div>
          </div>
        </Card>
      </Col>
      <Col xs={24} xl={16} className="what-if-result-panel">
        {!rows && <Empty description="Permission ve role üyelerini seçip mevcut ihlalleri bulun" />}
        {rows && (
          <Card size="small" className="what-if-impact-metrics">
            <div className="what-if-impact-metrics-head"><span>CONTROL RESULT</span><Button type="primary" icon={<DownloadOutlined />} onClick={exportCsv}>Raporu indir</Button></div>
            <div className="what-if-sod-result-body">
            <Alert type={rows.length ? 'warning' : 'success'} message={`${rows.length} kullanıcı bu kuralı şu an ihlal ediyor`} />
            <Table size="small" rowKey="userName" dataSource={rows} pagination={{}}
              columns={[
                { title: 'Kullanıcı', render: (_, r) => <>{r.userName}<br /><Typography.Text type="secondary">{r.fullName}</Typography.Text></> },
                { title: 'Çakışan üyeler (kaynak yolları)', render: (_, r) => r.conflicts[0]?.matchedMembers.map((m) => <div key={m.code} style={{ fontSize: 12 }}><Code>{m.code}</Code> {m.paths.join(' | ')}</div>) },
              ]} />
            </div>
          </Card>
        )}
      </Col>
    </Row>
  )
}
