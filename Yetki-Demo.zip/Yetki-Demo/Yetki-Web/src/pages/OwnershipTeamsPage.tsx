import { App, Button, Flex, Form, Input, Modal, Popconfirm, Select, Table, Tag } from 'antd'
import { DeleteOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { api } from '../api/client'
import { ActiveTag, PageHeader, TenantTag } from '../components/common'
import { invalidateOptions, toSelectOptions, useApi, useOptions } from '../hooks/useApi'

interface OwnershipTeam {
  id: number
  tenantId: number
  tenant: string
  code: string
  name: string
  description?: string
  isActive: boolean
  parentId?: number
  parent?: string
  applicationCount: number
  catalogLevelCount: number
  childTeamCount: number
}

export function OwnershipTeamsPage() {
  const { data, loading, reload } = useApi<OwnershipTeam[]>('/api/ownership-teams')
  const [editing, setEditing] = useState<OwnershipTeam | 'new'>()
  const { message } = App.useApp()
  const remove = async (t: OwnershipTeam) => {
    try {
      await api.del(`/api/ownership-teams/${t.id}`)
      message.success('Silindi')
      reload()
      invalidateOptions('teams')
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <>
      <PageHeader title="Ownership Teams" subtitle="Application ve Catalog Level sahipliğinde seçilebilen ekip kataloğu."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setEditing('new')}>New Team</Button>} />
      <Table<OwnershipTeam> rowKey="id" loading={loading} dataSource={data ?? []} pagination={false}
        columns={[
          { title: 'Team', render: (_, t) => <><b>{t.code}</b><br /><span>{t.name}</span></> },
          { title: 'Tenant', dataIndex: 'tenant', render: (v) => <TenantTag tenant={v} /> },
          { title: 'Parent', dataIndex: 'parent', render: (v) => (v ? <Tag>{v}</Tag> : '—') },
          {
            title: 'Used by', render: (_, t) => (
              <><Tag>{t.applicationCount} application</Tag><Tag>{t.catalogLevelCount} catalog level</Tag>{t.childTeamCount > 0 && <Tag>{t.childTeamCount} child team</Tag>}</>
            ),
          },
          { title: 'Description', dataIndex: 'description' },
          {
            title: '', render: (_, t) => {
              const inUse = t.applicationCount + t.catalogLevelCount + t.childTeamCount > 0
              return (
                <Flex gap={4} align="center">
                  <ActiveTag active={t.isActive} />
                  <Button type="link" size="small" onClick={() => setEditing(t)}>Edit</Button>
                  <Popconfirm title={`${t.code} silinsin mi?`} disabled={inUse} onConfirm={() => remove(t)}>
                    <Button type="link" danger size="small" icon={<DeleteOutlined />} disabled={inUse}
                      title={inUse ? 'Kullanımda olan ekip silinemez' : undefined} />
                  </Popconfirm>
                </Flex>
              )
            },
          },
        ]} />
      {editing && <OwnershipTeamModal team={editing === 'new' ? undefined : editing} teams={data ?? []}
        onClose={() => setEditing(undefined)} onDone={() => { reload(); invalidateOptions('teams') }} />}
    </>
  )
}

function OwnershipTeamModal({ team, teams, onClose, onDone }: { team?: OwnershipTeam; teams: OwnershipTeam[]; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const tenants = useOptions('tenants')
  const tenantId = Form.useWatch('tenantId', form) ?? team?.tenantId
  const { message } = App.useApp()
  const parentOptions = teams
    .filter((t) => t.tenantId === tenantId && t.id !== team?.id)
    .map((t) => ({ value: t.id, label: `${t.code} — ${t.name}` }))
  const save = async () => {
    try {
      const values = await form.validateFields()
      if (team) await api.put(`/api/ownership-teams/${team.id}`, values)
      else await api.post('/api/ownership-teams', values)
      message.success(team ? 'Team updated' : 'Team created')
      onDone()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title={team ? `Edit ${team.code}` : 'New Ownership Team'} onCancel={onClose} onOk={save} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={team ?? { isActive: true }}>
        <Form.Item name="tenantId" label="Tenant" rules={[{ required: true }]}>
          <Select disabled={!!team} options={toSelectOptions(tenants)} onChange={() => form.setFieldValue('parentId', undefined)} />
        </Form.Item>
        <Form.Item name="code" label="Code" rules={[{ required: true }]}><Input disabled={!!team} placeholder="CORE_BANKING" /></Form.Item>
        <Form.Item name="name" label="Name" rules={[{ required: true }]}><Input placeholder="Core Banking Team" /></Form.Item>
        <Form.Item name="parentId" label="Parent Team" extra="Opsiyonel — aynı tenant içindeki bir ekip">
          <Select allowClear disabled={!tenantId} options={parentOptions} placeholder="Yok" />
        </Form.Item>
        <Form.Item name="description" label="Description"><Input.TextArea rows={3} /></Form.Item>
        <Form.Item name="isActive" label="Status"><Select options={[{ value: true, label: 'Active' }, { value: false, label: 'Passive' }]} /></Form.Item>
      </Form>
    </Modal>
  )
}
