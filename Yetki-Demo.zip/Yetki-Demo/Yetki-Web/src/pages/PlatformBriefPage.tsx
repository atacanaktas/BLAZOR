import {
  ApiOutlined, ApartmentOutlined, AuditOutlined, BankOutlined, BranchesOutlined,
  CheckCircleFilled, DatabaseOutlined, ExperimentOutlined, FilePdfOutlined,
  RocketOutlined, SafetyCertificateOutlined, ThunderboltOutlined,
} from '@ant-design/icons'
import { Button } from 'antd'
import './PlatformBriefPage.css'

const capabilities = [
  {
    icon: <ApartmentOutlined />, title: 'Esnek erişim modeli',
    text: 'Tenant izolasyonu, serbest katalog hiyerarşisi ve resource:scope tabanlı atomik erişim tanımları.',
    tags: ['Tenant', 'Resource', 'Scope'],
  },
  {
    icon: <BranchesOutlined />, title: 'Policy karar zinciri',
    text: 'Permission → Policy → Rule → Condition zinciri; yeniden kullanılabilir policy ve çok seviyeli karar stratejileri.',
    tags: ['RBAC + ABAC', 'Policy reference'],
  },
  {
    icon: <ThunderboltOutlined />, title: 'Açıklanabilir karar',
    text: 'Permit, Deny, Indeterminate ve NotApplicable sonuçları; reason code, evidence ve obligation çıktıları.',
    tags: ['Why access?', 'Fail closed'],
  },
  {
    icon: <ExperimentOutlined />, title: 'Değişiklik simülasyonu',
    text: 'User, role, group, policy ve SoD değişikliklerini kaydetmeden önce kullanıcı ve erişim etkisiyle karşılaştırır.',
    tags: ['What-if', 'CSV report'],
  },
  {
    icon: <AuditOutlined />, title: 'Yönetişim ve iz',
    text: 'SoD kontrolleri, karar geçmişi, yönetim audit’i ve dış sistem provisioning ihtiyaçlarının takibi.',
    tags: ['SoD', 'Audit', 'RACF / LDAP'],
  },
  {
    icon: <DatabaseOutlined />, title: 'Kaynağından attribute',
    text: 'PIP ile çalışan, organizasyon, müşteri, takvim ve limit bilgilerini sahibi olan sistemden çözümler.',
    tags: ['HR', 'Customer', 'Calendar'],
  },
]

const comparison = [
  { topic: 'Kimlik doğrulama, MFA, token ve oturum', keycloak: 'Yerleşik ve olgun', yetki: 'Kurumsal IdP’ye bırakır', lead: 'keycloak' },
  { topic: 'Resource, scope, permission modeli', keycloak: 'Yerleşik', yetki: 'Sektör modeliyle uyumlu', lead: 'equal' },
  { topic: 'Banka attribute’ları ve dış veri kaynakları', keycloak: 'Claim / custom provider', yetki: 'Açık PIP sözleşmesi', lead: 'yetki' },
  { topic: 'Karar gerekçesi, evidence ve obligation', keycloak: 'Temel değerlendirme çıktısı', yetki: 'Modelin doğal parçası', lead: 'yetki' },
  { topic: 'What-if, SoD ve değişiklik etkisi', keycloak: 'Özel geliştirme gerekir', yetki: 'Ürün kabiliyeti', lead: 'yetki' },
  { topic: 'UMA, ekosistem ve işletim olgunluğu', keycloak: 'Güçlü', yetki: 'Geliştirme aşamasında', lead: 'keycloak' },
  { topic: 'Bankaya göre model ve akış esnekliği', keycloak: 'Ürün / SPI sınırlarında', yetki: 'Tam kontrol', lead: 'yetki' },
]

const roadmap = [
  { no: '01', title: 'Güvenli yönetim', text: 'OIDC tabanlı admin kimliği, yönetim yetkileri, secret yönetimi ve servisler arası güven.' },
  { no: '02', title: 'Dört göz ve yayın', text: 'Maker-checker, versiyonlu policy bundle, imzalı publish, rollback ve acil durum akışı.' },
  { no: '03', title: 'Standart enforcement', text: '.NET PEP ve PDP.Client SDK, timeout/fail davranışı, obligation enforcement ve uyumluluk testleri.' },
  { no: '04', title: 'Kurumsal ölçek', text: 'PDP local read model, cache stratejisi, HA/DR, performans kanıtı ve gözlemlenebilirlik.' },
]

export function PlatformBriefPage() {
  return (
    <div className="executive-brief">
      <div className="executive-actions">
        <div><span>YÖNETİCİ SUNUMU</span><strong>Yetki Platformu · Executive Brief</strong></div>
        <Button type="primary" icon={<FilePdfOutlined />} onClick={() => window.print()}>PDF olarak kaydet</Button>
      </div>

      <article className="executive-sheet">
        <header className="executive-hero">
          <div className="executive-hero-copy">
            <span className="executive-kicker">BANKACILIK İÇİN MERKEZİ YETKİ KARAR KATMANI</span>
            <h1>Doğru kişiye, doğru kaynağa,<br />doğru koşulda erişim.</h1>
            <p>Yetki Platformu; kimlik sisteminin ürettiği kullanıcıyı, bankanın iş bağlamı ve risk kurallarıyla değerlendirerek açıklanabilir bir erişim kararı üretir.</p>
            <div className="executive-position"><SafetyCertificateOutlined /><span><strong>Hedef konum:</strong> Kurumsal IAM + bankaya özel authorization engine</span></div>
          </div>
          <div className="executive-hero-mark" aria-hidden="true"><span>Y</span><small>yetki.</small></div>
        </header>

        <section className="executive-scale" aria-label="Hedeflenen ölçek">
          <div className="executive-scale-label"><span>HEDEFLENEN BANKA ÖLÇEĞİ</span><strong>Tek model, merkezi görünürlük</strong></div>
          <div><strong>20K+</strong><span>User</span></div>
          <div><strong>4K</strong><span>Role</span></div>
          <div><strong>200+</strong><span>API</span></div>
          <div><strong>1.5K+</strong><span>Screen</span></div>
        </section>

        <section className="executive-section executive-value">
          <div className="executive-section-title"><span>01</span><div><small>YÖNETİCİ ÖZETİ</small><h2>Neden bu platform?</h2></div></div>
          <div className="executive-thesis">
            <div><BankOutlined /></div>
            <p>Klasik RBAC, “rolü var mı?” sorusunu cevaplar. Banka ise <strong>kim, hangi kanaldan, hangi müşteriye, ne zaman, hangi limit dahilinde ve neden erişti?</strong> sorusunun tamamını yönetmek zorundadır.</p>
          </div>
          <div className="executive-value-grid">
            <div><strong>Kararı merkezileştirir</strong><span>Uygulamalardaki dağınık yetki kodlarını ortak modele taşır.</span></div>
            <div><strong>Değişikliği güvenli kılar</strong><span>Canlıya almadan önce kim kazanır, kim kaybeder gösterir.</span></div>
            <div><strong>Denetlenebilirlik sağlar</strong><span>Bir kararın kuralını, kaynağını ve gerekçesini görünür kılar.</span></div>
            <div><strong>Kaynak sistemi korur</strong><span>HR ve müşteri verisini kopyalamadan PIP üzerinden kullanır.</span></div>
          </div>
        </section>

        <section className="executive-section">
          <div className="executive-section-title"><span>02</span><div><small>ÇALIŞAN PROTOTİP</small><h2>Bugün neler yapabiliyor?</h2></div></div>
          <div className="executive-capability-grid">
            {capabilities.map((item) => <div className="executive-capability" key={item.title}>
              <span className="executive-capability-icon">{item.icon}</span>
              <div><h3>{item.title}</h3><p>{item.text}</p><footer>{item.tags.map((tag) => <span key={tag}>{tag}</span>)}</footer></div>
            </div>)}
          </div>
        </section>

        <section className="executive-section executive-architecture">
          <div className="executive-section-title"><span>03</span><div><small>HEDEF MİMARİ</small><h2>Basit görünen, net ayrılmış sorumluluklar</h2></div></div>
          <div className="executive-flow">
            <div><small>UYGULAMALAR</small><strong>Web · API · Desktop</strong><span>İsteği başlatır</span></div><b>→</b>
            <div className="is-accent"><small>PEP SDK</small><strong>Kararı uygular</strong><span>Bypass’ı önler</span></div><b>→</b>
            <div className="is-core"><small>PDP</small><strong>Permit / Deny</strong><span>Evidence + obligation</span></div><b>←</b>
            <div><small>PIP</small><strong>Attribute çözer</strong><span>HR · CRM · Takvim</span></div>
          </div>
          <div className="executive-control-plane"><ApiOutlined /><span><strong>PAP / Yönetim düzlemi</strong> katalog, permission, policy, rule, SoD, simülasyon ve yayın yaşam döngüsünü yönetir.</span></div>
        </section>

        <section className="executive-section">
          <div className="executive-section-title"><span>04</span><div><small>TARAFSIZ KARŞILAŞTIRMA</small><h2>Keycloak ile nerede aynı, nerede farklı?</h2></div></div>
          <p className="executive-section-lead">Keycloak olgun bir IAM ve standart yetkilendirme ürünüdür. Yetki Platformu ise bankaya özgü karar bağlamını, açıklanabilirliği ve değişiklik yönetişimini merkeze alan özel bir authorization engine’dir.</p>
          <div className="executive-comparison">
            <div className="executive-comparison-head"><span>Yetenek</span><span>Keycloak</span><span>Yetki Platformu</span></div>
            {comparison.map((row) => <div className="executive-comparison-row" key={row.topic}>
              <strong>{row.topic}</strong>
              <span className={row.lead === 'keycloak' ? 'is-leading' : ''}>{row.keycloak}</span>
              <span className={row.lead === 'yetki' ? 'is-leading' : row.lead === 'equal' ? 'is-aligned' : ''}>{row.yetki}</span>
            </div>)}
          </div>
          <div className="executive-balance">
            <div className="is-plus"><CheckCircleFilled /><span><strong>Bizim artımız</strong> Banka bağlamı, PIP, evidence, obligation, SoD ve gerçek değişiklik etkisi.</span></div>
            <div className="is-gap"><RocketOutlined /><span><strong>Bugünkü açığımız</strong> Ürün güvenliği, standart protokoller, HA/DR ve operasyon ekosistemi.</span></div>
          </div>
        </section>

        <section className="executive-section">
          <div className="executive-section-title"><span>05</span><div><small>YATIRIM ALANI</small><h2>Sıradaki kabiliyetler</h2></div></div>
          <div className="executive-roadmap">
            {roadmap.map((item) => <div key={item.no}><span>{item.no}</span><h3>{item.title}</h3><p>{item.text}</p></div>)}
          </div>
          <div className="executive-next-wave">
            <strong>Sonraki değer dalgası</strong>
            <span>Geçici yetki ve otomatik süre sonu</span><span>Erişim sertifikasyonu</span><span>Shadow decision / kademeli geçiş</span><span>Policy lint ve risk skoru</span><span>Anomali ve kullanım analitiği</span>
          </div>
        </section>

        <footer className="executive-verdict">
          <div><small>ÖNERİLEN STRATEJİ</small><h2>Hibrit mimariyle ilerleyelim.</h2><p>Olgun IAM kimliği ve token’ı yönetsin; Yetki Platformu bankaya özgü kararı versin; PEP kararı uygulamaya zorlasın. Böylece hazır ürün olgunluğu ile kuruma özel karar gücünü aynı mimaride birleştirebiliriz.</p></div>
          <span><SafetyCertificateOutlined /><strong>Kimlik ayrı.<br />Karar merkezi.<br />Gerekçe görünür.</strong></span>
        </footer>
        <div className="executive-footnote">Yetki Platformu · Yönetici Özeti · Çalışan prototip ve hedef mimari birlikte değerlendirilmiştir.</div>
      </article>
    </div>
  )
}
