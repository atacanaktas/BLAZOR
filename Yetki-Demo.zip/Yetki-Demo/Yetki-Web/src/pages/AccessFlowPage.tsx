import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Alert, Button, Dropdown, Empty, Input, Modal, Pagination, Skeleton, Tag } from 'antd'
import { ReloadOutlined, SearchOutlined } from '@ant-design/icons'
import { api } from '../api/client'
import { PolicyChangeModal } from '../components/PolicyImpact'
import { ConfirmChangeModal } from '../components/ConfirmChangeModal'
import type { ChangeImpactResult } from '../api/types'
import { WorldObject } from '../features/structure/WorldObjects'
import { InlineFlowDetails } from '../features/structure/InlineFlowDetails'
import '../features/structure/access-flow.css'

type Entry = { kind: string; id: number; code: string; name: string; tenantId: number }
type SearchPage = { total: number; page: number; items: Entry[] }
type Flow = { subject: Entry; total: number; page: number; roleCount?: number; groupCount?: number; active: boolean; items: { permission: Entry; resource: { id: number; name: string; path: string; application: string; action: string }; sources: string[]; sourceCount: number }[] }
function useRead<T>(url?: string) {
  const [state, setState] = useState<{ url: string; value?: T; error?: string }>()
  useEffect(() => { if (!url) return; let active = true; api.get<T>(url).then(value => { if (active) setState({ url, value }) }).catch(e => { if (active) setState({ url, error: e.message }) }); return () => { active = false } }, [url])
  return state?.url === url ? state : undefined
}
const short = (s: string, n = 29) => s.length > n ? s.slice(0, n - 1) + '…' : s

export function AccessFlowPage() {
  const [intent, setIntent] = useState<{ type: 'grant' | 'attach'; owner: Entry }>()
  const [pending, setPending] = useState<{ type: 'grant' | 'attach'; owner: Entry; target: Entry }>()
  const [focus, setFocus] = useState<Entry>()
  const [revision, setRevision] = useState(0)
  const [page, setPage] = useState(1)
  const [query, setQuery] = useState('')
  const [picker, setPicker] = useState<string>()
  const [search, setSearch] = useState('')
  const [searchPage, setSearchPage] = useState(1)
  const [roles, setRoles] = useState(false)
  const [branches, setBranches] = useState<Entry[]>([])
  const [motion, setMotion] = useState(() => !matchMedia('(prefers-reduced-motion: reduce)').matches)
  const flow = useRead<Flow>(focus ? `/api/structure/flow/${focus.kind}/${focus.id}?page=${page}&q=${encodeURIComponent(query)}&revision=${revision}` : undefined)
  const candidates = useRead<SearchPage>(picker ? roles && focus ? `/api/structure/flow/user/${focus.id}?relation=roles&page=${searchPage}&q=${encodeURIComponent(search)}&revision=${revision}` : `/api/structure/flow/search?kind=${picker}&page=${searchPage}&q=${encodeURIComponent(search)}&revision=${revision}` : undefined)
  const browse = (kind: string, userRoles = false) => { setIntent(undefined); setRoles(userRoles); setPicker(kind); setSearch(''); setSearchPage(1) }
  const inspect = (item: Entry) => { setBranches(previous => previous.some(x => x.kind === item.kind && x.id === item.id && x.tenantId === item.tenantId) ? previous : [...previous, item]); requestAnimationFrame(() => document.getElementById('af-inline-details')?.scrollIntoView({ behavior: motion ? 'smooth' : 'instant', block: 'start' })) }
  const choose = (item: Entry) => { setPicker(undefined); if (intent) { setPending({ ...intent, target: item }); setIntent(undefined); return } if (item.kind === 'policy') inspect(item); else { setFocus(item); setPage(1); setQuery(''); setBranches([]) } }
  const startChange = (type: 'grant' | 'attach', owner: Entry) => { browse(type === 'grant' ? 'permission' : 'policy'); setIntent({ type, owner }) }
  const drawable = flow?.value
  const count = drawable?.items.length ?? 0
  const height = Math.max(420, count * 145 + 120)
  const nodeActions = (node: Entry) => [
    { key: 'expand', label: node.kind === 'user' ? 'Show Roles in scene' : 'Expand connections', onClick: () => node.kind === 'role' ? choose(node) : inspect(node) },
    ...(node.kind === 'permission' ? [{ key: 'attach', label: 'Attach existing Policy', onClick: () => startChange('attach', node) }] : []),
    ...(node.kind === 'role' ? [{ key: 'grant', label: 'Assign Permission', onClick: () => startChange('grant', node) }] : []),
    { key: 'manage', label: <Link to={node.kind === 'user' ? `/users/${node.id}` : node.kind === 'role' ? `/roles/${node.id}` : node.kind === 'policy' ? `/policies/${node.id}` : `/permissions/${node.id}`}>Open management</Link> },
  ]
  const object = (kind: string, x: number, y: number, title: string, caption: string, action: () => void, label: string, scale = .65, node?: Entry) => <Dropdown trigger={['contextMenu']} menu={{ items: node ? nodeActions(node) : [{ key: 'find', label: title, onClick: action }] }}><g role="button" tabIndex={0} aria-label={label} className="af-object" transform={`translate(${x} ${y})`} onClick={action} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); action() } }}><title>{title}</title><ellipse cy="10" rx="65" ry="24" fill="#dee8ef" /><WorldObject kind={kind as 'user'} scale={scale} /><rect x="-100" y="34" width="200" height="51" rx="10" fill="white" stroke="#cadbe7" /><text textAnchor="middle" y="54">{short(title)}</text><text className="af-caption" textAnchor="middle" y="72">{short(caption, 37)}</text></g></Dropdown>
  return <div className="access-flow">
    <header className="af-header"><div><small>ACCESS CITY / V2</small><h1>Access in motion.</h1><p>Kim, hangi Resource üzerinde, hangi Permission ile işlem yapıyor?</p></div><div><Link to="/all-in-one">View V1</Link><Button aria-label="Refresh flow" icon={<ReloadOutlined />} onClick={() => setRevision(x => x + 1)} /></div></header>
    <div className="af-intents"><button onClick={() => browse('user')}>User access <small>Mehmet’in Roles ve Resource’ları</small></button><button onClick={() => browse('role')}>Role permissions <small>Bir Role’e Permission ekle</small></button><button onClick={() => browse('permission')}>Permission policies <small>Bir işleme Policy bağla</small></button><button onClick={() => browse('policy')}>Policy conditions <small>Rule ve Condition düzenle</small></button></div>
    <div className="af-toolbar"><div><Tag color="blue">{focus ? 'FOCUSED ACCESS' : 'OVERVIEW'}</Tag><strong>{focus?.name ?? 'Start with the big picture'}</strong>{focus && <Button size="small" onClick={() => { setFocus(undefined); setBranches([]); setQuery(''); setPage(1) }}>Clear focus</Button>}</div><label><input type="checkbox" checked={motion} onChange={e => setMotion(e.target.checked)} /> Motion</label></div>
    {focus && <div className="af-focus-tools"><Input.Search key={`${focus.kind}:${focus.id}`} allowClear placeholder="Filter Permission or Resource" aria-label="Filter access paths" onSearch={v => { setQuery(v); setPage(1) }} style={{ maxWidth: 370 }} />{focus.kind === 'role' && <Button type="primary" onClick={() => startChange('grant', focus)}>Assign Permission</Button>}{focus.kind === 'user' && <Button onClick={() => inspect(focus)}>Roles ({drawable?.roleCount ?? '…'})</Button>}<Link to={focus.kind === 'user' ? `/users/${focus.id}` : focus.kind === 'role' ? `/roles/${focus.id}` : `/permissions/${focus.id}`}>{focus.kind === 'role' ? 'Assign / remove Permission' : 'Open management'}</Link></div>}
    <div className={`af-scene ${motion ? 'af-motion' : ''}`}>
      <div className="af-scene-heading"><span>{focus ? 'EFFECTIVE ASSIGNMENT PATHS' : 'HOW ACCESS IS CONNECTED'}</span><small>{focus ? 'Select a Permission gate to inspect its Policies.' : 'Illustrative groups — select a landmark or a task to find real records.'}</small></div>
      {flow?.error ? <Alert type="error" title={flow.error} action={<Button onClick={() => setRevision(x => x + 1)}>Retry</Button>} /> : focus && !drawable ? <Skeleton active paragraph={{ rows: 9 }} /> : <div className="af-canvas-scroll"><svg className="af-canvas" viewBox={`0 0 1100 ${focus ? height : 610}`} aria-label="Interactive access flow">
        <defs><marker id="af-arrow" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0 0L7 3L0 6" fill="none" stroke="#7c9bb2" /></marker><pattern id="af-grid" width="90" height="45" patternUnits="userSpaceOnUse"><path d="M0 22.5L45 0L90 22.5L45 45Z" stroke="#d9e4ec" strokeWidth=".6" fill="none" /></pattern></defs>
        <rect width="1100" height="100%" fill="url(#af-grid)" opacity=".6" />
        {!focus ? <>
          <path className="af-road" d="M205 295H290 M465 295H550 M725 295H850 M650 355V395 M725 475H850" markerEnd="url(#af-arrow)" />
          {object('user', 130, 265, 'Users', 'Find a User', () => browse('user'), 'Find User')}
          {object('role', 390, 265, 'Roles / Groups', 'Assignment sources', () => browse('role'), 'Find Role')}
          {object('permission', 650, 265, 'Permissions', 'The access gate', () => browse('permission'), 'Find Permission')}
          {object('resource', 940, 265, 'Resources', 'Find the protecting Permission', () => browse('permission'), 'Find Resource permissions')}
          {object('policy', 650, 475, 'Policies', 'Constraints on access', () => browse('policy'), 'Find Policy', .55)}
          {object('rule', 940, 475, 'Rules / Conditions', 'Time · Amount · IP', () => browse('policy'), 'Find Policy conditions', .55)}
          <text x="60" y="70" className="af-scene-title">One flow. Many ways to manage access.</text>
          <text x="60" y="96" className="af-caption">User → assignment source → Permission → Resource · Policy → Rules</text>
        </> : drawable && <>
          {drawable.items.map((row, i) => { const y = 115 + i * 145; return <g key={row.permission.id}>
            <path className="af-road" d={`M190 ${height / 2}C270 ${height / 2},240 ${y},290 ${y} M495 ${y}H570 M735 ${y}H860`} markerEnd="url(#af-arrow)" />
            <rect x="295" y={y - 22} width="195" height="56" rx="10" fill="#f5f8fb" stroke="#d1dfe9" /><text x="392" y={y - 1} textAnchor="middle" className="af-caption">{row.sources.length ? short(row.sources[0], 32) : 'Permission definition'}</text><text x="392" y={y + 17} textAnchor="middle" className="af-caption">{row.sourceCount > 1 ? `+${row.sourceCount - 1} other sources` : 'Assignment source'}</text>
            {object('permission', 650, y - 20, row.permission.name, row.permission.code, () => inspect(row.permission), `Inspect Permission ${row.permission.code}`, .43, row.permission)}
            {object('resource', 945, y - 20, row.resource.name, `${row.resource.application} / ${row.resource.action}`, () => inspect(row.permission), `Inspect Resource ${row.resource.path}`, .43, row.permission)}
          </g> })}
          {object(focus.kind === 'permission' ? 'permission' : focus.kind, 150, height / 2 - 15, focus.name, focus.code, () => focus.kind === 'user' ? inspect(focus) : focus.kind === 'permission' ? inspect(focus) : browse('role'), 'Inspect focused subject', .65, focus)}
        </>}
      </svg></div>}
      {drawable && !count && <Empty description="No matching Permission assignments" />}
      <div id="af-inline-details">{branches.map(branch => <InlineFlowDetails key={`${branch.kind}:${branch.id}:${branch.tenantId}`} item={branch} revision={revision} onClose={() => setBranches(previous => previous.filter(x => !(x.kind === branch.kind && x.id === branch.id && x.tenantId === branch.tenantId)))} onAttach={item => startChange('attach', item)} onGrant={item => startChange('grant', item)} onFocus={choose} sources={branch.kind === 'permission' ? drawable?.items.find(x => x.permission.id === branch.id)?.sources : undefined} />)}</div>
    </div>
    {drawable && <div className="af-pagination"><span>{drawable.total.toLocaleString()} Permission paths · 4 per page{!drawable.active ? ' · Inactive subject' : ''}</span><Pagination current={drawable.page} total={drawable.total} pageSize={4} showSizeChanger={false} onChange={setPage} /></div>}
    <p className="af-note">{focus ? 'Arrows show current RBAC assignments, not a runtime Permit. Client scope, Tenant validation and Policy conditions are evaluated for the actual request.' : 'The overview is schematic. No complete User, Role or Resource catalog is loaded into the scene.'}</p>
    <Modal footer={null} zIndex={1100} title={roles ? `${focus?.name} / Effective Roles` : `Find ${picker ?? ''}`} open={!!picker} onCancel={() => { setPicker(undefined); setIntent(undefined) }} width={580}>
      <Input.Search key={`${picker}:${roles}`} allowClear autoFocus placeholder="Search by name or code" aria-label="Search flow records" onSearch={v => { setSearch(v); setSearchPage(1) }} enterButton={<SearchOutlined />} />
      {candidates?.error ? <Alert type="error" title={candidates.error} action={<Button onClick={() => setRevision(x => x + 1)}>Retry</Button>} /> : !candidates?.value ? <Skeleton active /> : <><div className="af-search-results">{candidates.value.items.map(item => <button key={item.id} onClick={() => choose(item)}><strong>{item.name}</strong><code>{item.code}</code><span>{roles ? 'Explore Role permissions →' : 'Focus →'}</span></button>)}</div>{!candidates.value.items.length && <Empty description="No matching records" />}<Pagination size="small" current={candidates.value.page} total={candidates.value.total} pageSize={12} showSizeChanger={false} onChange={setSearchPage} /></>}
    </Modal>
    {pending?.type === 'grant' && <ConfirmChangeModal open title={`${pending.owner.code}: assign ${pending.target.code}`} changeSet={{ rolePermissions: [{ roleId: pending.owner.id, permissionId: pending.target.id, add: true }] }} apply={() => api.post<ChangeImpactResult>(`/api/roles/${pending.owner.id}/permissions/${pending.target.id}`)} onClose={() => setPending(undefined)} onDone={() => setRevision(x => x + 1)} />}
    {pending?.type === 'attach' && <PolicyChangeModal open title={`${pending.target.code}: include ${pending.owner.code}`} changes={{ addedTargets: [{ policyId: pending.target.id, mode: 'Include', targetType: 'Permission', targetId: pending.owner.id }] }} apply={() => api.post(`/api/policies/${pending.target.id}/targets`, { mode: 'Include', targetType: 'Permission', targetId: pending.owner.id })} onClose={() => setPending(undefined)} onDone={() => { setPending(undefined); setRevision(x => x + 1) }} />}
  </div>
}
