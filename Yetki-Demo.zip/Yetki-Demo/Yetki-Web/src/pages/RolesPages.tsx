import { Alert, App, Button, Card, Col, Flex, Form, Input, Modal, Row, Select, Switch, Table, Tag, Typography } from 'antd'
import { DeleteOutlined, EditOutlined, ExperimentOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { api } from '../api/client'
import type { AuthorizationChangeSet, ChangeImpactResult } from '../api/types'
import { invalidateOptions, toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { ActiveTag, Code, TenantTag, PageHeader, SeverityTag, TagSummary } from '../components/common'
import { ChangeModal } from '../components/ChangeModal'
import { ConfirmChangeModal } from '../components/ConfirmChangeModal'

interface RoleRow {
  id: number
  code: string
  name: string
  isInheritable: boolean
  isActive: boolean
  tenant: string
  permissionCount: number
  directHolders: number
  grantingGroups: string[]
}

export function RolesPage() {
  const { data, loading, reload } = useApi<RoleRow[]>('/api/roles')
  const [query, setQuery] = useState('')
  const filtered = (data ?? []).filter((r) => `${r.code} ${r.name} ${r.tenant}`.toLocaleLowerCase('tr-TR').includes(query.toLocaleLowerCase('tr-TR')))
  const navigate = useNavigate()
  const [creating, setCreating] = useState(false)
  return (
    <>
      <PageHeader title="Role Directory" subtitle="İş rolü tanımları ve üyeleri. Role detayındaki Permission bağlantıları yetki ekibi tarafından yönetilir."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setCreating(true)}>Yeni rol</Button>} />
      <Flex className="list-toolbar" justify="space-between" align="center" gap={12} wrap>
        <Input.Search allowClear placeholder="Rol adı, kodu veya kurum ara" aria-label="Rollerde ara" onChange={(e) => setQuery(e.target.value)} style={{ width: 340 }} />
        <Typography.Text type="secondary">{filtered.length} rol</Typography.Text>
      </Flex>
      <Table<RoleRow>
        rowKey="id"
        size="small"
        loading={loading}
        dataSource={filtered}
        pagination={{ pageSize: 15, hideOnSinglePage: true, showSizeChanger: false }}
        rowClassName="clickable-row"
        onRow={(r) => ({ onClick: () => navigate(`/roles/${r.id}`) })}
        columns={[
          { title: 'Rol', render: (_, r) => <><Code>{r.code}</Code><br /><Typography.Text type="secondary">{r.name}</Typography.Text></> },
          { title: 'Tenant', render: (_, r) => <><TenantTag tenant={r.tenant} />{r.isInheritable && <Tag color="cyan">miras alınabilir</Tag>}</> },
          { title: 'Permission', dataIndex: 'permissionCount', width: 100 },
          { title: 'Doğrudan sahip', dataIndex: 'directHolders', width: 120 },
          { title: 'Veren gruplar', dataIndex: 'grantingGroups', render: (v: string[]) => <TagSummary values={v} /> },
          { title: '', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} />, width: 80 },
        ]}
      />
      {creating && <RoleFormModal onClose={() => setCreating(false)} onDone={(id) => { reload(); if (id) navigate(`/roles/${id}`) }} />}
    </>
  )
}

interface RoleDetail {
  role: { id: number; code: string; name: string; isInheritable: boolean; isActive: boolean; tenantId: number; tenant: string }
  permissions: { id: number; code: string; name: string; application: string; path: string; action: string; riskLevel: string }[]
  holders: { userId: number; userName: string; fullName: string; tenant: string; sources: string[] }[]
  grantingGroups: { groupId: number; code: string; name: string }[]
}

export function RoleDetailPage() {
  const { id } = useParams()
  const roleId = Number(id)
  const { data, reload } = useApi<RoleDetail>(`/api/roles/${roleId}`)
  const perms = useOptions('permissions')
  const [adding, setAdding] = useState(false)
  const [editing, setEditing] = useState(false)
  const [removal, setRemoval] = useState<{ title: string; changeSet: AuthorizationChangeSet; apply: () => Promise<ChangeImpactResult> }>()
  if (!data) return <Card loading />
  return (
    <>
      <PageHeader
        title={<><Code>{data.role.code}</Code> {data.role.name}</>}
        subtitle={<><TenantTag tenant={data.role.tenant} />{data.role.isInheritable && <Tag color="cyan">alt kurumlara miras</Tag>}<ActiveTag active={data.role.isActive} /></>}
        extra={<Flex gap={8}>
          <Button icon={<EditOutlined />} onClick={() => setEditing(true)}>Düzenle</Button>
          <Link to={`/what-if?tab=role&roleId=${roleId}`}><Button icon={<ExperimentOutlined />}>What-If</Button></Link>
        </Flex>}
      />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={14}>
          <Card size="small" title={`Permission'lar (${data.permissions.length})`} extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setAdding(true)}>Ekle</Button>}>
            <Table size="small" rowKey="id" dataSource={data.permissions} pagination={{ pageSize: 15 }}
              columns={[
                { title: 'Permission', render: (_, p) => <><Link to={`/permissions/${p.id}`}><Code>{p.code}</Code></Link><br /><Typography.Text type="secondary">{p.name}</Typography.Text></> },
                { title: 'Katalog', dataIndex: 'path', render: (v) => <Typography.Text style={{ fontSize: 12 }}>{v}</Typography.Text> },
                { title: 'Risk', dataIndex: 'riskLevel', render: (v) => <SeverityTag severity={v} /> },
                {
                  width: 40,
                  render: (_, p) => <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={() => setRemoval({
                    title: `${data.role.code} rolünden ${p.code} çıkar`,
                    changeSet: { rolePermissions: [{ roleId, permissionId: p.id, add: false }] },
                    apply: () => api.del(`/api/roles/${roleId}/permissions/${p.id}`),
                  })} />,
                },
              ]} />
          </Card>
        </Col>
        <Col xs={24} xl={10}>
          <Card size="small" title={`Sahipler (${data.holders.length}) — doğrudan veya grup üzerinden`}>
            <Table size="small" rowKey="userId" dataSource={data.holders} pagination={{ pageSize: 12 }}
              columns={[
                { title: 'Kullanıcı', render: (_, h) => <Link to={`/users/${h.userId}`}>{h.userName}</Link> },
                { title: 'Kaynak', dataIndex: 'sources', render: (v: string[]) => <Typography.Text style={{ fontSize: 12 }}>{v.join(' | ')}</Typography.Text> },
              ]} />
          </Card>
          {data.grantingGroups.length > 0 && (
            <Card size="small" title="Bu rolü veren gruplar" style={{ marginTop: 16 }}>
              {data.grantingGroups.map((g) => <Link key={g.groupId} to={`/groups/${g.groupId}`}><Tag color="purple">{g.code}</Tag></Link>)}
            </Card>
          )}
        </Col>
      </Row>
      <ChangeModal
        open={adding}
        title={`${data.role.code} rolüne permission ekle`}
        label="Permission (kimler kazanır: rolü doğrudan veya gruptan alan herkes)"
        options={toSelectOptions(perms, data.permissions.map((p) => p.id))}
        buildChangeSet={(permissionId) => ({ rolePermissions: [{ roleId, permissionId, add: true }] })}
        apply={(permissionId) => api.post(`/api/roles/${roleId}/permissions/${permissionId}`)}
        onClose={() => setAdding(false)}
        onDone={reload}
      />
      {removal && <ConfirmChangeModal open title={removal.title} changeSet={removal.changeSet} apply={removal.apply} onClose={() => setRemoval(undefined)} onDone={reload} />}
      {editing && <RoleFormModal role={data.role} onClose={() => setEditing(false)} onDone={reload} />}
    </>
  )
}

function RoleFormModal({ role, onClose, onDone }: { role?: RoleDetail['role']; onClose: () => void; onDone: (id?: number) => void }) {
  const [form] = Form.useForm()
  const tenants = useOptions('tenants')
  const { message } = App.useApp()
  const [preview, setPreview] = useState<ChangeImpactResult>()
  const save = async () => {
    const v = await form.validateFields()
    try {
      if (role) {
        const r = await api.put<ChangeImpactResult>(`/api/roles/${role.id}`, { ...role, ...v })
        message.success('Kaydedildi. ' + r.summary)
        onDone()
      } else {
        const r = await api.post<{ id: number }>('/api/roles', v)
        invalidateOptions('roles')
        onDone(r.id)
      }
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  const doPreview = async () => {
    if (!role) return
    const v = form.getFieldsValue()
    setPreview(await api.post<ChangeImpactResult>('/api/simulation/changes', { roleUpdates: [{ roleId: role.id, isActive: v.isActive, isInheritable: v.isInheritable }] }))
  }
  return (
    <Modal open title={role ? `${role.code} düzenle` : 'Yeni rol'} onCancel={onClose} onOk={save} destroyOnHidden width={640}>
      <Form form={form} layout="vertical" initialValues={role ?? { isActive: true, isInheritable: false, tenantId: 1 }} onValuesChange={() => setPreview(undefined)}>
        {!role && <Form.Item name="tenantId" label="Tenant" rules={[{ required: true }]}>
          <Select showSearch optionFilterProp="label" loading={tenants.length === 0}
            notFoundContent="Tenant seçenekleri yükleniyor…" options={toSelectOptions(tenants)} />
        </Form.Item>}
        {!role && <Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input placeholder="GISEAST" /></Form.Item>}
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Flex gap={24}>
          <Form.Item name="isInheritable" label="Alt tenant'lara miras" valuePropName="checked"><Switch /></Form.Item>
          <Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item>
        </Flex>
      </Form>
      {role && <Button onClick={doPreview}>Aktiflik/miras değişikliğinin etkisi</Button>}
      {preview && <Alert style={{ marginTop: 8 }} type={preview.affectedUserCount ? 'warning' : 'info'} message={preview.summary} />}
    </Modal>
  )
}
