import { Alert, App, Button, Card, Col, Flex, Form, Input, Modal, Row, Select, Switch, Tag, Typography } from 'antd'
import { DataTable as Table, textColumnFilter } from '../components/DataTable'
import { EditOutlined, ExperimentOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { api } from '../api/client'
import type { ChangeImpactResult, PolicyLogic } from '../api/types'
import { invalidateOptions, toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { AccessKey, ActiveTag, AsyncState, Code, ListError, TenantTag, PageHeader, TagSummary } from '../components/common'

interface RoleRow {
  id: number
  code: string
  name: string
  isInheritable: boolean
  isActive: boolean
  tenant: string
  policies: string[]
  directHolders: number
  grantingGroups: string[]
}

export function RolesPage() {
  const { data, loading, error, reload } = useApi<RoleRow[]>('/api/roles')
  const [query, setQuery] = useState('')
  const filtered = (data ?? []).filter((r) => `${r.code} ${r.name} ${r.tenant}`.toLocaleLowerCase('tr-TR').includes(query.toLocaleLowerCase('tr-TR')))
  const navigate = useNavigate()
  const [creating, setCreating] = useState(false)
  return (
    <>
      <PageHeader title="Role Directory" subtitle="İş rolleri ve sahipleri. Rol yetkiyi doğrudan taşımaz: Rol policy'sine üye olur, policy'yi kullanan permission'lar yetkiyi verir."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setCreating(true)}>Yeni rol</Button>} />
      <Flex className="list-toolbar" justify="space-between" align="center" gap={12} wrap>
        <Input.Search allowClear placeholder="Rol adı, kodu veya kurum ara" aria-label="Rollerde ara" onChange={(e) => setQuery(e.target.value)} style={{ width: 340 }} />
        <Typography.Text type="secondary">{filtered.length} rol</Typography.Text>
      </Flex>
      <ListError error={error} onRetry={reload} />
      <Table<RoleRow>
        rowKey="id"
        size="small"
        loading={loading}
        dataSource={filtered}
        locale={{ emptyText: query ? 'Aramayla eşleşen rol yok' : 'Henüz rol tanımlanmamış' }}
        pagination={{ hideOnSinglePage: true }}
        rowClassName="clickable-row"
        onRow={(r) => ({ onClick: () => navigate(`/roles/${r.id}`) })}
        columns={[
          { title: 'Rol', dataIndex: 'code', ...textColumnFilter<RoleRow>((r) => `${r.code} ${r.name}`, 'Rol içinde ara'), render: (_, r) => <><Code>{r.code}</Code><br /><Typography.Text type="secondary">{r.name}</Typography.Text></> },
          { title: 'Tenant', dataIndex: 'tenant', render: (_, r) => <><TenantTag tenant={r.tenant} />{r.isInheritable && <Tag color="cyan">miras alınabilir</Tag>}</> },
          { title: 'KİM kartında geçtiği policy\'ler', dataIndex: 'policies', render: (v: string[]) => v.length ? <TagSummary values={v} /> : <Tag color="orange">policy yok → yetki vermez</Tag> },
          { title: 'Doğrudan sahip', dataIndex: 'directHolders', width: 120 },
          { title: 'Veren gruplar', dataIndex: 'grantingGroups', render: (v: string[]) => <TagSummary values={v} /> },
          { title: '', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} />, width: 80 },
        ]}
      />
      {creating && <RoleFormModal onClose={() => setCreating(false)} onDone={(id) => { reload(); if (id) navigate(`/roles/${id}`) }} />}
    </>
  )
}

interface RoleDetail {
  role: { id: number; code: string; name: string; isInheritable: boolean; isActive: boolean; tenantId: number; tenant: string }
  policies: { id: number; code: string; name: string; logic: PolicyLogic; isActive: boolean }[]
  permissions: { id: number; code: string; name: string; application: string; otherPolicies: string[]; accesses: string[] }[]
  holders: { userId: number; userName: string; fullName: string; tenant: string; sources: string[] }[]
  grantingGroups: { groupId: number; code: string; name: string }[]
}

export function RoleDetailPage() {
  const { id } = useParams()
  const roleId = Number(id)
  const { data, loading, error, reload } = useApi<RoleDetail>(`/api/roles/${roleId}`)
  const [editing, setEditing] = useState(false)
  if (!data) return <AsyncState loading={loading} error={error} onRetry={reload} empty="Rol bulunamadı" />
  return (
    <>
      <PageHeader
        title={<><Code>{data.role.code}</Code> {data.role.name}</>}
        subtitle={<><TenantTag tenant={data.role.tenant} />{data.role.isInheritable && <Tag color="cyan">alt kurumlara miras</Tag>}<ActiveTag active={data.role.isActive} /></>}
        extra={<Flex gap={8}>
          <Button icon={<EditOutlined />} onClick={() => setEditing(true)}>Düzenle</Button>
          <Link to={`/what-if?tab=role&roleId=${roleId}`}><Button icon={<ExperimentOutlined />}>What-If</Button></Link>
        </Flex>}
      />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={14}>
          <Card size="small" title="Bu rol neye erişim sağlar? (rol → policy → permission → yetki)"
            extra={<Link to="/policies"><Button size="small" icon={<PlusOutlined />}>Policy'ler</Button></Link>}>
            <Flex wrap gap={4} style={{ marginBottom: 8 }}>
              <Typography.Text type="secondary">Rol policy'leri:</Typography.Text>
              {data.policies.map((p) => <Link key={p.id} to={`/policies/${p.id}`}><Tag color={p.isActive ? 'blue' : 'default'}>{p.code}{p.logic === 'Negative' ? ' (negatif)' : ''}</Tag></Link>)}
              {data.policies.length === 0 && <Tag color="orange">Bu rol hiçbir policy'nin KİM kartında yok → rol hiçbir yetki vermez</Tag>}
            </Flex>
            <Table size="small" rowKey="id" dataSource={data.permissions} pagination={{ hideOnSinglePage: true }}
              columns={[
                { title: 'Permission', render: (_, p) => <><Link to={`/permissions/${p.id}`}><Code>{p.code}</Code></Link> <Tag>{p.application}</Tag><br /><Typography.Text type="secondary">{p.name}</Typography.Text></> },
                { title: 'Yetkiler', dataIndex: 'accesses', render: (v: string[]) => <Flex vertical gap={2}>{v.map((k) => <AccessKey key={k} value={k} />)}</Flex> },
                { title: 'Birlikte uygulanan policy', dataIndex: 'otherPolicies', render: (v: string[]) => v.length ? v.map((c) => <Tag key={c} color="gold">{c}</Tag>) : '—' },
              ]} />
            <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8, marginBottom: 0 }}>
              Role yetki eklemek için: bir permission'a bu rolün policy'sini ekleyin veya yeni bir Rol policy'si oluşturun. Birlikte uygulanan koşul policy'leri sağlanmazsa erişim reddedilir.
            </Typography.Paragraph>
          </Card>
        </Col>
        <Col xs={24} xl={10}>
          <Card size="small" title={`Sahipler (${data.holders.length}) — doğrudan veya grup üzerinden`}>
            <Table size="small" rowKey="userId" dataSource={data.holders} pagination={{}}
              columns={[
                { title: 'Kullanıcı', render: (_, h) => <Link to={`/users/${h.userId}`}>{h.userName}</Link> },
                { title: 'Kaynak', dataIndex: 'sources', render: (v: string[]) => <Typography.Text style={{ fontSize: 12 }}>{v.join(' | ')}</Typography.Text> },
              ]} />
          </Card>
          {data.grantingGroups.length > 0 && (
            <Card size="small" title="Bu rolü veren gruplar" style={{ marginTop: 16 }}>
              {data.grantingGroups.map((g) => <Link key={g.groupId} to={`/groups/${g.groupId}`}><Tag color="purple">{g.code}</Tag></Link>)}
            </Card>
          )}
        </Col>
      </Row>
      {editing && <RoleFormModal role={data.role} onClose={() => setEditing(false)} onDone={reload} />}
    </>
  )
}

function RoleFormModal({ role, onClose, onDone }: { role?: RoleDetail['role']; onClose: () => void; onDone: (id?: number) => void }) {
  const [form] = Form.useForm()
  const tenants = useOptions('tenants')
  const { message } = App.useApp()
  const [preview, setPreview] = useState<ChangeImpactResult>()
  const save = async () => {
    const v = await form.validateFields()
    try {
      if (role) {
        const r = await api.put<ChangeImpactResult>(`/api/roles/${role.id}`, { ...role, ...v })
        message.success('Kaydedildi. ' + r.summary)
        onDone()
      } else {
        const r = await api.post<{ id: number }>('/api/roles', v)
        invalidateOptions('roles')
        onDone(r.id)
      }
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  const doPreview = async () => {
    if (!role) return
    const v = form.getFieldsValue()
    setPreview(await api.post<ChangeImpactResult>('/api/simulation/changes', { roleUpdates: [{ roleId: role.id, isActive: v.isActive, isInheritable: v.isInheritable }] }))
  }
  return (
    <Modal open title={role ? `${role.code} düzenle` : 'Yeni rol'} onCancel={onClose} onOk={save} destroyOnHidden width={640}>
      <Form form={form} layout="vertical" initialValues={role ?? { isActive: true, isInheritable: false, tenantId: 1 }} onValuesChange={() => setPreview(undefined)}>
        {!role && <Form.Item name="tenantId" label="Tenant" rules={[{ required: true }]}>
          <Select showSearch optionFilterProp="label" loading={tenants.length === 0}
            notFoundContent="Tenant seçenekleri yükleniyor…" options={toSelectOptions(tenants)} />
        </Form.Item>}
        {!role && <Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input placeholder="GISEAST" /></Form.Item>}
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Flex gap={24}>
          <Form.Item name="isInheritable" label="Alt tenant'lara miras" valuePropName="checked"><Switch /></Form.Item>
          <Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item>
        </Flex>
      </Form>
      {role && <Button onClick={doPreview}>Aktiflik/miras değişikliğinin etkisi</Button>}
      {preview && <Alert style={{ marginTop: 8 }} type={preview.affectedUserCount ? 'warning' : 'info'} message={preview.summary} />}
    </Modal>
  )
}
