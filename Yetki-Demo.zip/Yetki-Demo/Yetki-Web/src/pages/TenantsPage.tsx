import { Alert, App, Button, Card, Col, Empty, Flex, Form, Input, Modal, Row, Select, Table, Tag, TreeSelect, Typography } from 'antd'
import { PlusOutlined } from '@ant-design/icons'
import { useMemo, useState } from 'react'
import { api } from '../api/client'
import { invalidateOptions, useApi } from '../hooks/useApi'
import { TenantTag, PageGuide, PageHeader } from '../components/common'

interface Tenant {
  id: number
  code: string
  name: string
  type: string
  parent?: string
  userCount: number
  roleCount: number
  groupCount: number
  inheritedRoles: string[]
  ownPolicies: string[]
  inheritedPolicies: string[]
  ownApplications: string[]
  inheritedApplications: string[]
  ownClients: string[]
  inheritedClients: string[]
}

function Owned({ label, own, inherited }: { label: string; own: string[]; inherited: string[] }) {
  return (
    <div style={{ marginBottom: 8 }}>
      <Typography.Text type="secondary">{label}: </Typography.Text>
      {own.map((p) => <Tag key={p} color="blue">{p}</Tag>)}
      {inherited.map((p) => <Tag key={p} color="cyan" title="üst tenant'tan miras">↑ {p}</Tag>)}
      {own.length + inherited.length === 0 && '—'}
    </div>
  )
}

interface Unit {
  id: number
  code: string
  name: string
  type: string
  parentId?: number
  tenantId: number
  tenant: string
  userCount: number
}

type UnitNode = Unit & { children?: UnitNode[] }

const unitColor: Record<string, string> = { HeadOffice: 'purple', Department: 'blue', Region: 'gold', Branch: 'green' }
const unitTypes = [
  { value: 'HeadOffice', label: 'Genel müdürlük' },
  { value: 'Department', label: 'Departman' },
  { value: 'Region', label: 'Bölge' },
  { value: 'Branch', label: 'Şube' },
]

export function TenantsPage() {
  const tenants = useApi<Tenant[]>('/api/tenants')
  const units = useApi<Unit[]>('/api/org-units')
  const [creatingOrg, setCreatingOrg] = useState(false)
  const [unitFor, setUnitFor] = useState<{ tenant: Tenant; tree: UnitNode[] }>()
  const reload = () => {
    tenants.reload()
    units.reload()
    invalidateOptions('tenants', 'units')
  }

  const trees = useMemo(() => {
    const all = units.data ?? []
    const build = (parentId: number | undefined, tenantId: number): UnitNode[] =>
      all.filter((u) => u.parentId === parentId && u.tenantId === tenantId).map((u) => {
        const children = build(u.id, tenantId)
        return children.length ? { ...u, children } : { ...u }
      })
    return (tenants.data ?? []).map((o) => ({ tenant: o, units: build(undefined, o.id) }))
  }, [tenants.data, units.data])

  return (
    <>
      <PageHeader title="Kurumlar" subtitle="Kurumları, bağlı kuruluşları ve organizasyon birimlerini yönetin."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setCreatingOrg(true)}>Yeni kurum</Button>} />
      <PageGuide title="Kurumlar arası erişim hakkında"><Alert type="info" showIcon style={{ marginBottom: 16 }}
        message="Tek kural: bir tenant KENDİ ve ÜST tenant'larının tanımlarını kullanır; kullanıcı başka tenant'ın kaynağına erişemez (tenant izolasyonu)"
        description="Policy, uygulama (resource) ve client alt tenant'lara miras geçer (↑). Rol için ayrıca IsInheritable gerekir (ör. PERSONEL). Üst tenant alt tenant'ın uygulamasını kullanamaz (ör. B_PORTAL sadece BISTIRAK'ın). Yetki isteğindeki tenant kullanıcının tenant'ı olmalı; kaydın tenant'ı (resource.properties.Tenant) da aynı olmalı." /></PageGuide>
      {tenants.data?.length === 0 && <Empty description="Henüz tenant yok. Önce ana bankayı (tip: Banka) oluşturun." />}
      <Row gutter={[16, 16]}>
        {trees.map(({ tenant, units: tree }) => (
          <Col xs={24} xl={12} key={tenant.id}>
            <Card
              title={<Flex gap={8} align="center"><TenantTag tenant={tenant.code} />{tenant.name}{tenant.parent && <Typography.Text type="secondary">← {tenant.parent} altında</Typography.Text>}</Flex>}
              extra={<Flex gap={8} align="center"><Tag>{tenant.type}</Tag><Button size="small" icon={<PlusOutlined />} onClick={() => setUnitFor({ tenant, tree })}>Birim</Button></Flex>}
            >
              <Flex gap={16} wrap style={{ marginBottom: 12 }}>
                <span><b>{tenant.userCount}</b> kullanıcı</span>
                <span><b>{tenant.roleCount}</b> rol</span>
                <span><b>{tenant.groupCount}</b> grup</span>
              </Flex>
              <Owned label="Uygulamalar (resource)" own={tenant.ownApplications} inherited={tenant.inheritedApplications} />
              <Owned label="Client'lar" own={tenant.ownClients} inherited={tenant.inheritedClients} />
              <Owned label="Policy'ler" own={tenant.ownPolicies} inherited={tenant.inheritedPolicies} />
              <div style={{ marginBottom: 12 }}>
                <Typography.Text type="secondary">Miras alabildiği roller: </Typography.Text>
                {tenant.inheritedRoles.length ? tenant.inheritedRoles.map((p) => <Tag key={p} color="cyan">{p}</Tag>) : '—'}
              </div>
              <Table<UnitNode>
                size="small"
                rowKey="id"
                pagination={false}
                dataSource={tree}
                expandable={{ defaultExpandAllRows: true }}
                columns={[
                  { title: 'Birim', render: (_, u) => <><b>{u.code}</b> — {u.name}</> },
                  { title: 'Tip', dataIndex: 'type', render: (v) => <Tag color={unitColor[v]}>{v}</Tag> },
                  { title: 'Kullanıcı', dataIndex: 'userCount', width: 90 },
                ]}
              />
            </Card>
          </Col>
        ))}
      </Row>
      {creatingOrg && <TenantFormModal tenants={tenants.data ?? []} onClose={() => setCreatingOrg(false)} onDone={reload} />}
      {unitFor && <UnitFormModal tenant={unitFor.tenant} tree={unitFor.tree} onClose={() => setUnitFor(undefined)} onDone={reload} />}
    </>
  )
}

function TenantFormModal({ tenants, onClose, onDone }: { tenants: Tenant[]; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const save = async () => {
    const v = await form.validateFields()
    try {
      await api.post('/api/tenants', v)
      message.success('Tenant oluşturuldu')
      onDone()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title="Yeni tenant" okText="Oluştur" onOk={save} onCancel={onClose} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={{ type: tenants.length ? 'Subsidiary' : 'Bank' }}>
        <Form.Item name="code" label="Kod" rules={[{ required: true }]} extra="Büyük harf, ör. ABANK"><Input /></Form.Item>
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Form.Item name="type" label="Tip"><Select options={[{ value: 'Bank', label: 'Banka' }, { value: 'Subsidiary', label: 'İştirak' }]} /></Form.Item>
        <Form.Item name="parentId" label="Üst tenant" extra="Alt kurum üstün policy'lerini ve miras alınabilir rollerini devralır">
          <Select allowClear options={tenants.map((o) => ({ value: o.id, label: `${o.code} — ${o.name}` }))} />
        </Form.Item>
      </Form>
    </Modal>
  )
}

interface UnitTreeOption { value: number; title: string; children?: UnitTreeOption[] }
const toUnitTree = (nodes: UnitNode[]): UnitTreeOption[] =>
  nodes.map((u) => ({ value: u.id, title: `${u.code} — ${u.name}`, children: u.children ? toUnitTree(u.children) : undefined }))

function UnitFormModal({ tenant, tree, onClose, onDone }: { tenant: Tenant; tree: UnitNode[]; onClose: () => void; onDone: () => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const save = async () => {
    const v = await form.validateFields()
    try {
      await api.post('/api/org-units', { ...v, tenantId: tenant.id })
      message.success('Birim oluşturuldu')
      onDone()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title={`${tenant.code} — yeni birim`} okText="Oluştur" onOk={save} onCancel={onClose} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={{ type: tree.length ? 'Branch' : 'HeadOffice' }}>
        <Form.Item name="code" label="Kod" rules={[{ required: true }]} extra="Şube kodu gibi, ör. 101"><Input /></Form.Item>
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Form.Item name="type" label="Tip"><Select options={unitTypes} /></Form.Item>
        <Form.Item name="parentId" label="Üst birim"><TreeSelect allowClear treeDefaultExpandAll treeData={toUnitTree(tree)} /></Form.Item>
      </Form>
    </Modal>
  )
}
