import { Alert, App, Button, Card, Col, Flex, Form, Input, InputNumber, Modal, Radio, Row, Select, Switch, Table, Tag, Typography } from 'antd'
import { DeleteOutlined, EditOutlined, ExperimentOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { api } from '../api/client'
import type { CombiningAlgorithm, ConditionDraft, ConditionTypeInfo, InclusionMode, ObligationTypeDef, PolicyChangeSet, PolicyMode, RuleView, SharedConditionInfo, TargetView } from '../api/types'
import { invalidateOptions, toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { ActiveTag, AlgorithmTag, Code, ModeTag, TenantTag, PageGuide, PageHeader, TagSummary, TargetTag, algorithmHelp, algorithmLabel } from '../components/common'
import { ConditionBuilder, emptyPredicate, renderDraft, toDraft } from '../components/ConditionBuilder'
import { PolicyChangeModal } from '../components/PolicyImpact'
import { TargetPicker, type TargetValue } from '../components/Catalog'

interface PolicyRow {
  id: number
  code: string
  name: string
  mode: PolicyMode
  isActive: boolean
  algorithm: CombiningAlgorithm
  version: number
  tenant: string
  includes: string[]
  excludes: string[]
  clients: string[]
  excludedClients: string[]
  obligations: string[]
  rules: { code: string; name: string; reasonCode?: string; isActive: boolean; expression: string }[]
  coverage: number
}

export function PoliciesPage() {
  const { data, loading, reload } = useApi<PolicyRow[]>('/api/policies')
  const [query, setQuery] = useState('')
  const filtered = (data ?? []).filter((p) => `${p.code} ${p.name} ${p.tenant}`.toLocaleLowerCase('tr-TR').includes(query.toLocaleLowerCase('tr-TR')))
  const navigate = useNavigate()
  const [creating, setCreating] = useState(false)
  return (
    <>
      <PageHeader title="Politikalar"
        subtitle="Yetkilerin hangi koşullarda kullanılabileceğini belirleyin."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setCreating(true)}>Yeni politika</Button>}
      />
      <PageGuide title="Politikalar nasıl değerlendirilir?"><Alert type="info" showIcon style={{ marginBottom: 16 }}
        message="Nihai karar: RBAC = PERMIT ve uygulanan tüm Enforce policy'ler = PERMIT → PERMIT. Bir policy'nin rule'u sağlanmazsa DENY (neden kodu ile); değer eksikse INDETERMINATE (izin yok). ReportOnly policy'ler sadece raporlanır."
        description="Rule = sağlanması gereken tek koşul (Saat 09-18 · Tutar ≤ limit · IP şube ağında · izinde değil). Üst tenant'ın policy'si alt tenant'a miras geçer (A Bankası → B İştiraki); istisna HARİÇ hedefiyle yapılır." /></PageGuide>
      <Flex className="list-toolbar" justify="space-between" align="center" gap={12} wrap>
        <Input.Search allowClear placeholder="Politika adı, kodu veya kurum ara" aria-label="Politikalarda ara" onChange={(e) => setQuery(e.target.value)} style={{ width: 340 }} />
        <Typography.Text type="secondary">{filtered.length} politika</Typography.Text>
      </Flex>
      <Table<PolicyRow>
        rowKey="id"
        loading={loading}
        dataSource={filtered}
        pagination={{ pageSize: 15, hideOnSinglePage: true, showSizeChanger: false }}
        rowClassName="clickable-row"
        onRow={(p) => ({ onClick: () => navigate(`/policies/${p.id}`) })}
        columns={[
          { title: 'Policy', render: (_, p) => <><Code>{p.code}</Code> <ModeTag mode={p.mode} />{!p.isActive && <Tag>pasif</Tag>}<br /><Typography.Text type="secondary">{p.name}</Typography.Text></> },
          { title: 'Tenant', dataIndex: 'tenant', render: (v) => <TenantTag tenant={v} />, width: 110 },
          {
            title: 'Hedef (miras)',
            render: (_, p) => <Flex wrap gap={4}>
              <TagSummary values={p.includes} />{p.excludes.map((t) => <Tag key={t} color="volcano">HARİÇ {t}</Tag>)}
              {p.clients.map((c) => <Tag key={c} color="magenta">kanal: {c}</Tag>)}{p.excludedClients.map((c) => <Tag key={c} color="volcano">HARİÇ kanal {c}</Tag>)}
              {p.obligations.map((o) => <Tag key={o} color="gold">⚑ {o}</Tag>)}
            </Flex>,
          },
          { title: 'Yetki sayısı', dataIndex: 'coverage', width: 100 },
          { title: 'Kurallar', width: 220, render: (_, p) => <TagSummary values={p.rules.map((r) => `${r.name}${r.isActive ? '' : ' (pasif)'}`)} /> },
        ]}
      />
      {creating && <PolicyFormModal onClose={() => setCreating(false)} onDone={(id) => { reload(); invalidateOptions('policies'); if (id) navigate(`/policies/${id}`) }} />}
    </>
  )
}

interface PolicyDetail {
  policy: {
    id: number; code: string; name: string; description?: string; mode: PolicyMode; isActive: boolean; algorithm: CombiningAlgorithm; version: number
    tenantId: number; tenant: string; appliesToTenants: string[]; updatedAt?: string; updatedBy?: string
  }
  targets: TargetView[]
  clientTargets: { id: number; mode: InclusionMode; clientId: number; client: string; name?: string }[]
  obligations: { id: number; code: string; fulfillOn: 'Permit' | 'Deny'; order: number; parameters: Record<string, string> }[]
  rules: RuleView[]
  coverage: { count: number; byApplication: { application: string; count: number }[]; sample: { id: number; code: string; name: string; path: string }[] }
}

interface Pending {
  title: string
  changes: PolicyChangeSet
  apply: () => Promise<unknown>
}

export function PolicyDetailPage() {
  const { id } = useParams()
  const policyId = Number(id)
  const { data, reload } = useApi<PolicyDetail>(`/api/policies/${policyId}`)
  const types = useApi<ConditionTypeInfo[]>('/api/condition-types').data ?? []
  const shared = useApi<SharedConditionInfo[]>('/api/shared-conditions').data ?? []
  const [pending, setPending] = useState<Pending>()
  const [ruleModal, setRuleModal] = useState<RuleView | 'new' | null>(null)
  const [targetModal, setTargetModal] = useState(false)
  const [clientModal, setClientModal] = useState(false)
  const [obligationModal, setObligationModal] = useState(false)
  const [editing, setEditing] = useState(false)
  const { message } = App.useApp()
  if (!data) return <Card loading />
  const p = data.policy

  return (
    <>
      <PageHeader
        title={<><Code>{p.code}</Code> {p.name}</>}
        subtitle={<><TenantTag tenant={p.tenant} /> <ModeTag mode={p.mode} /> <AlgorithmTag algorithm={p.algorithm} /> <ActiveTag active={p.isActive} /> v{p.version} · uygulandığı tenant'lar: {p.appliesToTenants.join(', ')}</>}
        extra={<Flex gap={8}>
          <Button icon={<EditOutlined />} onClick={() => setEditing(true)}>Mod / algoritma / aktiflik</Button>
          <Link to={`/what-if?tab=policy&policyId=${policyId}`}><Button icon={<ExperimentOutlined />}>What-If</Button></Link>
        </Flex>}
      />
      {p.description && <Typography.Paragraph type="secondary">{p.description}</Typography.Paragraph>}
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={10}>
          <Card size="small" title="Hedefler (bu policy hangi işlemlere uygulanır?)" extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setTargetModal(true)}>Hedef / istisna</Button>}>
            <Flex vertical gap={6}>
              {data.targets.map((t) => (
                <div key={t.id}>
                  <TargetTag type={t.targetType} description={t.description} actions={t.actions} mode={t.mode} closable onClose={() => setPending({
                    title: `${p.code}: ${t.mode === 'Exclude' ? 'istisnayı' : 'hedefi'} kaldır → ${t.description}`,
                    changes: { removedTargetIds: [t.id] },
                    apply: () => api.del(`/api/policy-targets/${t.id}`),
                  })} />
                </div>
              ))}
              {data.targets.length === 0 && <Alert type="warning" message="Hedef yok: bu policy hiçbir işleme uygulanmaz." />}
            </Flex>
            <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8, marginBottom: 0 }}>
              Katalog düğümü hedefi altındaki tüm modül/alt modül/permission'ları kapsar; yeni eklenen API'ler de kendiliğinden kurala girer.
            </Typography.Paragraph>
          </Card>
          <Card size="small" style={{ marginTop: 16 }} title="Kanal (client) hedefi" extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setClientModal(true)}>Kanal</Button>}>
            <Flex wrap gap={4}>
              {data.clientTargets.map((c) => (
                <Tag key={c.id} color={c.mode === 'Include' ? 'magenta' : 'volcano'} closable onClose={(e) => {
                  e.preventDefault()
                  setPending({
                    title: `${p.code}: kanal hedefini kaldır → ${c.mode === 'Include' ? 'sadece' : 'hariç'} ${c.client}`,
                    changes: { removedClientTargetIds: [c.id] },
                    apply: () => api.del(`/api/policy-clients/${c.id}`),
                  })
                }}>{c.mode === 'Include' ? 'SADECE' : 'HARİÇ'} {c.client}</Tag>
              ))}
              {data.clientTargets.length === 0 && <Typography.Text type="secondary">Tüm kanallar (client ayrımı yok)</Typography.Text>}
            </Flex>
            <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8, marginBottom: 0 }}>
              Aynı endpoint Nextral / Anka Web / Mobil'den çağrılır. "Sadece" kanalı varsa policy yalnızca o client'lardan gelen isteklere uygulanır; "hariç" kanal için uygulanmaz.
              Karar orijinal client'a (gateway üzerinden gelse bile) göre verilir.
            </Typography.Paragraph>
          </Card>
          <Card size="small" style={{ marginTop: 16 }} title="Yükümlülükler (obligation)" extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setObligationModal(true)}>Yükümlülük</Button>}>
            {data.obligations.length === 0 && <Typography.Text type="secondary">Yok</Typography.Text>}
            {data.obligations.map((o) => (
              <Flex key={o.id} justify="space-between" align="center" style={{ marginBottom: 4 }}>
                <span><Tag color="gold">⚑ {o.code}</Tag>{Object.entries(o.parameters).map(([k, v]) => <Tag key={k}>{k}={v}</Tag>)}<Typography.Text type="secondary" style={{ fontSize: 12 }}>{o.fulfillOn === 'Permit' ? 'izin verilince' : 'reddedilince'}</Typography.Text></span>
                <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={async () => {
                  try { await api.del(`/api/policy-obligations/${o.id}`); message.success('Yükümlülük kaldırıldı'); reload() } catch (e) { message.error((e as Error).message) }
                }} />
              </Flex>
            ))}
            <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8, marginBottom: 0 }}>
              Karar ile PEP'e (API / SDK) döner: MASK_FIELDS yanıttaki alanları maskeler, LIMIT_RESULTS listeyi kısaltır, LOG_ACCESS hassas erişim loguna yazar.
              PEP tanımadığı yükümlülükte erişimi reddeder. Rule'u olmayan policy koşulsuz yükümlülük verir.
            </Typography.Paragraph>
          </Card>
          <Card size="small" title={`Kapsam: ${data.coverage.count} permission`} style={{ marginTop: 16 }}>
            <Flex wrap gap={4} style={{ marginBottom: 8 }}>{data.coverage.byApplication.map((a) => <Tag key={a.application}>{a.application}: {a.count}</Tag>)}</Flex>
            <Table size="small" rowKey="id" dataSource={data.coverage.sample} pagination={{ pageSize: 8 }}
              columns={[{ title: 'Permission', render: (_, x) => <><Link to={`/permissions/${x.id}`}><Code>{x.code}</Code></Link><br /><Typography.Text type="secondary" style={{ fontSize: 12 }}>{x.name}</Typography.Text></> }]} />
          </Card>
        </Col>
        <Col xs={24} xl={14}>
          <Card size="small" title={<>Rule'lar <AlgorithmTag algorithm={p.algorithm} /></>} extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setRuleModal('new')}>Rule ekle</Button>}>
            <Table<RuleView>
              size="small"
              rowKey="id"
              dataSource={data.rules}
              pagination={false}
              columns={[
                { title: '#', dataIndex: 'order', width: 50 },
                { title: 'Rule', width: 230, render: (_, r) => <><Code>{r.code}</Code>{!r.isActive && <Tag>pasif</Tag>}<br /><Typography.Text type="secondary">{r.name}</Typography.Text></> },
                { title: 'Koşul (sağlanmalı)', dataIndex: 'expression', render: (v) => <Typography.Text style={{ fontSize: 12, wordBreak: 'break-word' }}>{v}</Typography.Text> },
                { title: 'Sağlanmazsa', dataIndex: 'reasonCode', width: 200, render: (v) => v && <Code>{v}</Code> },
                {
                  width: 90,
                  render: (_, r) => (
                    <Flex gap={2}>
                      <Button size="small" type="text" icon={<EditOutlined />} onClick={() => setRuleModal(r)} />
                      <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={() => setPending({
                        title: `${p.code} / ${r.code} rule'unu sil`, changes: { removedRuleIds: [r.id] }, apply: () => api.del(`/api/rules/${r.id}`),
                      })} />
                    </Flex>
                  ),
                },
              ]}
            />
          </Card>
        </Col>
      </Row>

      {targetModal && (
        <TargetModal onClose={() => setTargetModal(false)} onSubmit={(mode, t, actions) => {
          setTargetModal(false)
          const actionFilter = actions.length ? actions.join(',') : undefined
          setPending({
            title: `${p.code}: ${mode === 'Exclude' ? 'istisna (HARİÇ)' : 'hedef'} ekle${actionFilter ? ` · Action: ${actionFilter}` : ''}`,
            changes: { addedTargets: [{ policyId, mode, targetType: t.targetType, targetId: t.targetId, actions: actionFilter }] },
            apply: () => api.post(`/api/policies/${policyId}/targets`, { mode, targetType: t.targetType, targetId: t.targetId, actions: actionFilter }),
          })
        }} />
      )}
      {ruleModal && (
        <RuleModal
          policyId={policyId}
          rule={ruleModal === 'new' ? undefined : ruleModal}
          types={types}
          shared={shared}
          onClose={() => setRuleModal(null)}
          onSubmit={(draft, body) => {
            const existing = ruleModal === 'new' ? undefined : ruleModal
            setRuleModal(null)
            setPending(existing
              ? { title: `${p.code} / ${existing.code} güncelle`, changes: { replacedRules: [{ ruleId: existing.id, rule: draft }] }, apply: () => api.put(`/api/rules/${existing.id}`, body) }
              : { title: `${p.code}: yeni rule ${draft.code}`, changes: { addedRules: [draft] }, apply: () => api.post(`/api/policies/${policyId}/rules`, body) })
          }}
        />
      )}
      {editing && (
        <PolicyFormModal policy={p} onClose={() => setEditing(false)} onSubmit={(v) => {
          setEditing(false)
          setPending({
            title: `${p.code}: ${v.mode} / ${v.combiningAlgorithm} / ${v.isActive ? 'aktif' : 'pasif'}`,
            changes: {
              policyModes: v.mode !== p.mode ? [{ policyId, mode: v.mode }] : [],
              policyAlgorithms: v.combiningAlgorithm !== p.algorithm ? [{ policyId, algorithm: v.combiningAlgorithm }] : [],
              policyActivations: v.isActive !== p.isActive ? [{ policyId, isActive: v.isActive }] : [],
            },
            apply: () => api.put(`/api/policies/${policyId}`, { ...v, tenantId: p.tenantId, code: p.code }),
          })
        }} />
      )}
      {clientModal && <ClientTargetModal onClose={() => setClientModal(false)} onSubmit={(mode, clientId, label) => {
        setClientModal(false)
        setPending({
          title: `${p.code}: kanal hedefi → ${mode === 'Include' ? 'sadece' : 'hariç'} ${label}`,
          changes: { addedClientTargets: [{ policyId, mode, clientId }] },
          apply: () => api.post(`/api/policies/${policyId}/clients`, { clientId, mode }),
        })
      }} />}
      {obligationModal && <ObligationModal policyId={policyId} onClose={() => setObligationModal(false)} onDone={reload} />}
      {pending && (
        <PolicyChangeModal
          open
          title={pending.title}
          changes={pending.changes}
          apply={pending.apply}
          onClose={() => setPending(undefined)}
          onDone={reload}
        />
      )}
    </>
  )
}

/** Kanal hedefi seçimi: aracılar (gateway) listelenmez — kanal isteği başlatan client'tır. */
function ClientTargetModal({ onClose, onSubmit }: { onClose: () => void; onSubmit: (mode: InclusionMode, clientId: number, label: string) => void }) {
  const clients = useApi<{ id: number; clientId: string; name: string; type: string; tenant: string }[]>('/api/clients').data ?? []
  const [mode, setMode] = useState<InclusionMode>('Include')
  const [clientId, setClientId] = useState<number>()
  const label = clients.find((c) => c.id === clientId)?.clientId ?? ''
  return (
    <Modal open title="Kanal (client) hedefi" onCancel={onClose} onOk={() => clientId && onSubmit(mode, clientId, label)} okButtonProps={{ disabled: !clientId }} okText="Etkiyi gör" destroyOnHidden>
      <Radio.Group value={mode} onChange={(e) => setMode(e.target.value)} style={{ marginBottom: 12 }}
        options={[{ value: 'Include', label: 'Sadece bu kanal' }, { value: 'Exclude', label: 'Bu kanal hariç' }]} optionType="button" buttonStyle="solid" />
      <Select style={{ width: '100%' }} placeholder="Client (kanal)" value={clientId} onChange={setClientId}
        options={clients.filter((c) => c.type !== 'Intermediary').map((c) => ({ value: c.id, label: `${c.clientId} — ${c.name} (${c.tenant})` }))} />
      <Alert style={{ marginTop: 12 }} type="info" message="Örn. MUSTERI verisine mobil kanal kuralı (cihaz uyumlu + maskeleme) sadece mobil tablet için; kurumsal ağ kuralı mobil tablet hariç." />
    </Modal>
  )
}

/** Yükümlülük ekle: tip katalogdan, parametre formu tipten üretilir. */
function ObligationModal({ policyId, onClose, onDone }: { policyId: number; onClose: () => void; onDone: () => void }) {
  const types = useApi<ObligationTypeDef[]>('/api/obligation-types').data ?? []
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const code = Form.useWatch('code', form) as string | undefined
  const type = types.find((t) => t.code === code)
  const save = async () => {
    const v = await form.validateFields()
    try {
      await api.post(`/api/policies/${policyId}/obligations`, { code: v.code, fulfillOn: v.fulfillOn, parameters: v.parameters ?? {} })
      message.success('Yükümlülük eklendi')
      onDone()
      onClose()
    } catch (e) { message.error((e as Error).message) }
  }
  return (
    <Modal open title="Yükümlülük (obligation)" okText="Ekle" onOk={save} onCancel={onClose} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={{ fulfillOn: 'Permit' }}>
        <Form.Item name="code" label="Tip" rules={[{ required: true }]} extra={type?.description}>
          <Select options={types.map((t) => ({ value: t.code, label: `${t.code} — ${t.name}` }))} onChange={() => form.setFieldValue('parameters', {})} />
        </Form.Item>
        {type?.parameters.map((prm) => (
          <Form.Item key={prm.key} name={['parameters', prm.key]} label={prm.label} rules={prm.required ? [{ required: true }] : undefined} extra={prm.hint}>
            <Input />
          </Form.Item>
        ))}
        <Form.Item name="fulfillOn" label="Ne zaman">
          <Radio.Group options={[{ value: 'Permit', label: 'İzin verilince' }, { value: 'Deny', label: 'Reddedilince' }]} optionType="button" />
        </Form.Item>
      </Form>
    </Modal>
  )
}

const policyActions = ['create', 'read', 'update', 'delete', 'approve', 'execute', 'cancel', 'close', 'export', 'view', 'print']

function TargetModal({ onClose, onSubmit }: { onClose: () => void; onSubmit: (mode: InclusionMode, t: TargetValue, actions: string[]) => void }) {
  const [mode, setMode] = useState<InclusionMode>('Include')
  const [target, setTarget] = useState<TargetValue>()
  const [actions, setActions] = useState<string[]>([])
  return (
    <Modal open title="Policy hedefi" onCancel={onClose} onOk={() => target && onSubmit(mode, target, actions)} okButtonProps={{ disabled: !target }} okText="Etkiyi gör" width={720} destroyOnHidden>
      <Radio.Group value={mode} onChange={(e) => setMode(e.target.value)} style={{ marginBottom: 12 }}
        options={[{ value: 'Include', label: 'Dahil et (hedef)' }, { value: 'Exclude', label: 'Hariç tut (istisna)' }]} optionType="button" buttonStyle="solid" />
      <TargetPicker value={target} onChange={setTarget} />
      {target?.targetType !== 'Permission' && <div style={{ marginTop: 12 }}>
        <Typography.Text strong>Action filtresi</Typography.Text>
        <Select mode="tags" tokenSeparators={[',']} value={actions} onChange={setActions}
          options={policyActions.map((a) => ({ value: a, label: a }))}
          placeholder="Boş bırakılırsa hedefteki tüm action'lar" style={{ width: '100%', marginTop: 6 }} />
        <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 6, marginBottom: 0 }}>
          Örneğin Resource hedefinde <Code>close</Code> seçilirse policy yalnızca o Resource ve altındaki kapatma işlemlerine uygulanır.
        </Typography.Paragraph>
      </div>}
      {mode === 'Exclude' && <Alert style={{ marginTop: 12 }} type="info" message="Örn. NAKIT domain'ine uygulanan mesai kuralından ATM alt modülünü hariç tut." />}
    </Modal>
  )
}

function RuleModal({ policyId, rule, types, shared, onClose, onSubmit }: {
  policyId: number
  rule?: RuleView
  types: ConditionTypeInfo[]
  shared: SharedConditionInfo[]
  onClose: () => void
  onSubmit: (draft: { policyId: number; code: string; name?: string; order: number; reasonCode?: string; condition: ConditionDraft }, body: object) => void
}) {
  const [form] = Form.useForm()
  const [condition, setCondition] = useState<ConditionDraft>(rule?.condition ? toDraft(rule.condition) : emptyPredicate())
  const allRules = useApi<RuleView[]>('/api/rules').data ?? []
  const submit = async () => {
    const v = await form.validateFields()
    onSubmit({ policyId, code: v.code, name: v.name, order: v.order, reasonCode: v.reasonCode, condition }, { ...v, condition })
  }
  return (
    <Modal open title={rule ? `Rule: ${rule.code}` : 'Yeni rule'} onCancel={onClose} onOk={submit} okText="Etkiyi gör" width={980} destroyOnHidden>
      {!rule && (
        <Flex gap={8} align="center" style={{ marginBottom: 12 }}>
          <Typography.Text type="secondary">Mevcut bir rule'dan kopyala:</Typography.Text>
          <Select style={{ width: 460 }} showSearch optionFilterProp="label" placeholder="Rule seç" allowClear
            options={allRules.map((r) => ({ value: r.id, label: `${r.policy} / ${r.code} — ${r.expression}` }))}
            onChange={(id) => {
              const r = allRules.find((x) => x.id === id)
              if (!r) return
              form.setFieldsValue({ code: r.code, name: r.name, reasonCode: r.reasonCode })
              if (r.condition) setCondition(toDraft(r.condition))
            }} />
        </Flex>
      )}
      <Form form={form} layout="vertical" initialValues={rule ?? { order: 50, isActive: true }}>
        <Row gutter={12}>
          <Col span={6}><Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input disabled={!!rule} placeholder="WORKING_HOURS" /></Form.Item></Col>
          <Col span={14}><Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input placeholder="Mesai saatinde olmalı" /></Form.Item></Col>
          <Col span={4}><Form.Item name="order" label="Sıra"><InputNumber style={{ width: '100%' }} /></Form.Item></Col>
          <Col span={12}><Form.Item name="reasonCode" label="Sağlanmazsa neden kodu"><Input placeholder="OUTSIDE_BUSINESS_HOURS" /></Form.Item></Col>
          <Col span={4}><Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item></Col>
        </Row>
      </Form>
      <Typography.Text strong>Koşul: TRUE → rule sağlandı · FALSE → sağlanmadı (Deny) · değer eksik → belirsiz</Typography.Text>{' '}
      <Typography.Text type="secondary" style={{ fontSize: 12 }}>önizleme: <Code>{renderDraft(condition)}</Code></Typography.Text>
      <div style={{ marginTop: 6 }}><ConditionBuilder value={condition} onChange={setCondition} types={types} shared={shared} /></div>
      <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8 }}>
        Kullanıcıya özgü değerler (limit, birim, rol) buraya yazılmaz; koşul tipi onları attribute olarak çözer. Banka ağı / mesai gibi ortak tanımlar için "Ortak koşul (@referans)" seçin.
      </Typography.Paragraph>
    </Modal>
  )
}

interface PolicyFormValues { tenantId?: number; code?: string; name: string; description?: string; mode: PolicyMode; combiningAlgorithm: CombiningAlgorithm; isActive: boolean }

function PolicyFormModal({ policy, onClose, onDone, onSubmit }: {
  policy?: PolicyDetail['policy']
  onClose: () => void
  onDone?: (id?: number) => void
  onSubmit?: (v: PolicyFormValues) => void
}) {
  const [form] = Form.useForm<PolicyFormValues>()
  const tenants = useOptions('tenants')
  const { message } = App.useApp()
  const save = async () => {
    const v = await form.validateFields()
    if (policy && onSubmit) return onSubmit({ ...v, name: v.name ?? policy.name, description: v.description ?? policy.description })
    try {
      const r = await api.post<{ id: number }>('/api/policies', v)
      onDone?.(r.id)
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    }
  }
  return (
    <Modal open title={policy ? `${policy.code}` : 'Yeni policy'} onCancel={onClose} onOk={save} okText={policy ? 'Etkiyi gör' : 'Oluştur'} destroyOnHidden>
      <Form form={form} layout="vertical"
        initialValues={policy ? { name: policy.name, description: policy.description, mode: policy.mode, combiningAlgorithm: policy.algorithm, isActive: policy.isActive } : { tenantId: 1, mode: 'ReportOnly', combiningAlgorithm: 'AllRulesMustPass', isActive: true }}>
        {!policy && <Form.Item name="tenantId" label="Tenant (alt tenant'lara miras)" rules={[{ required: true }]}><Select options={toSelectOptions(tenants)} /></Form.Item>}
        {!policy && <Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input placeholder="ODEME_MESAI" /></Form.Item>}
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item>
        <Form.Item name="mode" label="Mod" tooltip="ReportOnly: değerlendirilir ve kaydedilir ama kararı etkilemez. Yeni policy'yi önce ReportOnly açın, etkisini izleyip Enforce'a alın.">
          <Radio.Group options={[{ value: 'Enforce', label: 'Enforce' }, { value: 'ReportOnly', label: 'ReportOnly (deneme)' }]} optionType="button" />
        </Form.Item>
        <Form.Item name="combiningAlgorithm" label="Karar stratejisi">
          <Select options={(Object.keys(algorithmLabel) as CombiningAlgorithm[]).map((a) => ({ value: a, label: `${algorithmLabel[a]} — ${algorithmHelp[a]}` }))} />
        </Form.Item>
        <Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item>
      </Form>
      {!policy && <Typography.Text type="secondary">Oluşturduktan sonra hedef (katalog düğümü) ve rule ekleyin.</Typography.Text>}
    </Modal>
  )
}

