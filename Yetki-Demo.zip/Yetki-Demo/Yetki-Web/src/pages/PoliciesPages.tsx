import { Alert, App, Button, Card, Col, Descriptions, Dropdown, Flex, Form, Input, InputNumber, Modal, Popconfirm, Radio, Row, Select, Switch, Tag, Tooltip, Typography } from 'antd'
import { DataTable as Table, textColumnFilter } from '../components/DataTable'
import { DeleteOutlined, EditOutlined, ExperimentOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { api } from '../api/client'
import type {
  ConditionDraft, ConditionTypeInfo, DecisionStrategy, DefinitionChangeResult, ObligationTypeDef, PolicyChangeSet, PolicyListItem, PolicyLogic,
  PolicyMode, RuleDraft, RuleView,
} from '../api/types'
import { invalidateOptions, toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { ActiveTag, AsyncState, Code, ListError, LogicTag, ModeTag, PageGuide, PageHeader, StrategyTag, TenantTag, fmt, strategyHelp, strategyLabel } from '../components/common'
import { ConditionBuilder, emptyPredicate, renderDraft, toDraft } from '../components/ConditionBuilder'
import { PolicyChangeModal } from '../components/PolicyImpact'
import { DefinitionChangeModal } from '../components/DefinitionChange'
import { CardRuleModal, RuleCard, cardKinds, cardMeta, parseCard, type CardKind } from '../components/QuestionCards'

const strategies: DecisionStrategy[] = ['Unanimous', 'Affirmative', 'Consensus']

/** Kartın kısa etiketi (liste için): KİM / NEREDEN / ... / GELİŞMİŞ */
function CardTags({ rules, types }: { rules: PolicyListItem['rules']; types: ConditionTypeInfo[] }) {
  return (
    <Flex wrap gap={4}>
      {rules.map((r) => {
        const card = parseCard(r.condition ? toDraft(r.condition) : undefined, types)
        const meta = card ? cardMeta[card.kind] : undefined
        return <Tooltip key={r.code} title={r.expression}><Tag color={meta?.color} style={{ opacity: r.isActive ? 1 : 0.5 }}>{meta?.label ?? 'GELİŞMİŞ'} · {r.name}</Tag></Tooltip>
      })}
      {rules.length === 0 && <Typography.Text type="secondary">kart yok</Typography.Text>}
    </Flex>
  )
}

// ================================ Liste ================================

export function PoliciesPage() {
  const { data, loading, error, reload } = useApi<PolicyListItem[]>('/api/policies')
  const types = useApi<ConditionTypeInfo[]>('/api/condition-types').data ?? []
  const [query, setQuery] = useState('')
  const navigate = useNavigate()
  const [creating, setCreating] = useState(false)
  const q = query.toLocaleLowerCase('tr-TR')
  const filtered = (data ?? []).filter((p) => `${p.code} ${p.name} ${p.rules.map((r) => `${r.name} ${r.expression}`).join(' ')}`.toLocaleLowerCase('tr-TR').includes(q))
  return (
    <>
      <PageHeader title="Policies" subtitle="KİM ve HANGİ KOŞULDA? Her policy kartlardan oluşur; permission'lar policy'leri resource/scope'lara bağlar."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setCreating(true)}>Yeni policy</Button>} />
      <PageGuide title="Policy nasıl değerlendirilir?">
        <p>Policy tek başına bir şeye erişim vermez; bir <Link to="/permissions">Permission</Link>'a eklendiğinde o permission'ın resource/scope'larını korur.</p>
        <p>Policy'nin tipi yoktur; <b>kartlardan</b> oluşur: <b>KİM</b> (rol / grup / birim / unvan / kullanıcı…), <b>NEREDEN</b> (ağ, kanal / client), <b>NEREYE / KİME</b>, <b>NE KADAR</b>,
          <b> HANGİ SAAT</b>, <b>NE ZAMAN</b> ve <b>HAZIR POLICY</b> (tekrar kullanılan başka bir policy; kopyalanmaz). Kartlar stratejiyle birleşir (varsayılan: hepsi sağlanmalı).</p>
        <p><b>Negatif</b> mantık sonucu tersine çevirir (ör. "izinli DEĞİLSE"). <b>ReportOnly</b> kararı etkilemez, sadece raporlanır; <b>Advisory</b> kararı etkilemez ama koşulu sağlanırsa yükümlülüklerini (maskeleme vb.) ekler.</p>
      </PageGuide>
      <Flex className="list-toolbar" justify="space-between" align="center" gap={12} wrap>
        <Input.Search allowClear placeholder="Policy kodu, adı veya kart içeriği (rol, grup, client...) ara" onChange={(e) => setQuery(e.target.value)} style={{ width: 420 }} />
        <Typography.Text type="secondary">{filtered.length} policy</Typography.Text>
      </Flex>
      <ListError error={error} onRetry={reload} />
      <Table<PolicyListItem> rowKey="id" loading={loading} dataSource={filtered} locale={{ emptyText: query ? 'Aramayla eşleşen policy yok' : 'Henüz policy tanımlanmamış' }} pagination={{ hideOnSinglePage: true }}
        rowClassName="clickable-row" onRow={(p) => ({ onClick: () => navigate(`/policies/${p.id}`) })}
        columns={[
          { title: 'Policy', dataIndex: 'code', ...textColumnFilter<PolicyListItem>((p) => `${p.code} ${p.name}`, 'Policy içinde ara'), width: '24%', render: (_, p) => <><Code>{p.code}</Code> <LogicTag logic={p.logic} />{p.mode !== 'Enforce' && <ModeTag mode={p.mode} />}{!p.isActive && <Tag>pasif</Tag>}<br /><Typography.Text type="secondary">{p.name}</Typography.Text></> },
          { title: 'Kartlar', dataIndex: 'rules', render: (_, p) => <>{p.rules.length > 1 && <StrategyTag strategy={p.strategy} />}<CardTags rules={p.rules} types={types} /></> },
          { title: 'Yükümlülük', dataIndex: 'obligations', width: 140, render: (v: string[]) => v.map((o) => <Tag key={o} color="gold">⚑ {o}</Tag>) },
          { title: 'Kullanan permission', dataIndex: 'permissions', render: (v: string[]) => v.length ? v.map((x) => <Tag key={x}>{x}</Tag>) : <Typography.Text type="secondary">kullanılmıyor</Typography.Text> },
          { title: 'Tenant', dataIndex: 'tenant', width: 100, render: (v) => <TenantTag tenant={v} /> },
        ]} />
      {creating && <PolicyCreateModal onClose={() => setCreating(false)}
        onDone={(id) => { reload(); invalidateOptions('policies'); if (id) navigate(`/policies/${id}`) }} />}
    </>
  )
}

interface PolicyFormValues {
  tenantId: number; code: string; name: string; description?: string; logic: PolicyLogic; decisionStrategy: DecisionStrategy
  mode: PolicyMode; isActive: boolean
}

function PolicyFields({ editing }: { editing: boolean }) {
  const tenants = useOptions('tenants')
  return (
    <Row gutter={12}>
      {!editing && <>
        <Col span={12}><Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input placeholder="NAKIT_CEKIM_KURALI" /></Form.Item></Col>
        <Col span={12}><Form.Item name="tenantId" label="Tenant" rules={[{ required: true }]}><Select options={toSelectOptions(tenants)} /></Form.Item></Col>
      </>}
      <Col span={24}><Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item></Col>
      <Col span={8}><Form.Item name="logic" label="Mantık" tooltip="Negatif: sonuç tersine çevrilir (şartı sağlamıyorsa izin).">
        <Radio.Group optionType="button" options={[{ value: 'Positive', label: 'Pozitif' }, { value: 'Negative', label: 'Negatif' }]} />
      </Form.Item></Col>
      <Col span={16}><Form.Item name="decisionStrategy" label="Kartları birleştirme">
        <Select options={strategies.map((s) => ({ value: s, label: `${strategyLabel[s]} — ${strategyHelp[s]}` }))} />
      </Form.Item></Col>
      <Col span={16}><Form.Item name="mode" label="Mod">
        <Radio.Group optionType="button" options={[{ value: 'Enforce', label: 'Enforce' }, { value: 'ReportOnly', label: 'ReportOnly (deneme)' }, { value: 'Advisory', label: 'Advisory (sadece yükümlülük)' }]} />
      </Form.Item></Col>
      <Col span={8}><Form.Item name="isActive" label="Aktif" valuePropName="checked" extra="Pasif policy → izin vermez (DENY)."><Switch /></Form.Item></Col>
      <Col span={24}><Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item></Col>
    </Row>
  )
}

function PolicyCreateModal({ onClose, onDone }: { onClose: () => void; onDone: (id?: number) => void }) {
  const [form] = Form.useForm<PolicyFormValues>()
  const { message } = App.useApp()
  const save = async () => {
    const v = await form.validateFields()
    try {
      const r = await api.post<DefinitionChangeResult>('/api/policies', v)
      if (r.warnings?.length) message.warning(r.warnings.join(' · '))
      else message.success('Oluşturuldu — kartları ekleyin; bir permission\'a eklenene kadar etkisizdir')
      onDone(r.id); onClose()
    } catch (e) { message.error((e as Error).message) }
  }
  return (
    <Modal open width={720} title="Yeni policy" onCancel={onClose} onOk={save} okText="Oluştur" destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={{ tenantId: 1, logic: 'Positive', decisionStrategy: 'Unanimous', mode: 'Enforce', isActive: true }}>
        <PolicyFields editing={false} />
      </Form>
      <Typography.Text type="secondary">Oluşturduktan sonra kartları ekleyin (KİM, NEREDEN, HANGİ SAAT...). Kartı olmayan policy belirsiz sonuç verir (izin yok).</Typography.Text>
    </Modal>
  )
}

// ================================ Detay ================================

interface PolicyDetail {
  policy: {
    id: number; code: string; name: string; description?: string; logic: PolicyLogic; mode: PolicyMode; isActive: boolean
    decisionStrategy: DecisionStrategy; version: number; tenantId: number; tenant: string; updatedAt?: string; updatedBy?: string
  }
  obligations: { id: number; code: string; fulfillOn: 'Permit' | 'Deny'; order: number; parameters: Record<string, string> }[]
  rules: RuleView[]
  usedBy: {
    permissions: { id: number; code: string; name: string; application: string; coverage: number }[]
    /** Bu policy'yi kartında (HAZIR POLICY) referansla kullanan policy'ler */
    policies: { id: number; code: string; name: string; via: string }[]
  }
}

interface Pending { title: string; changes: PolicyChangeSet; apply: (expectedModelVersion: number) => Promise<unknown> }
interface PendingDefinition { title: string; run: (dryRun: boolean, expectedModelVersion?: number) => Promise<DefinitionChangeResult> }

export function PolicyDetailPage() {
  const { id } = useParams()
  const policyId = Number(id)
  const navigate = useNavigate()
  const { data, loading, error, reload } = useApi<PolicyDetail>(`/api/policies/${policyId}`)
  const types = useApi<ConditionTypeInfo[]>('/api/condition-types').data ?? []
  const [pending, setPending] = useState<Pending>()
  const [definition, setDefinition] = useState<PolicyFormValues>()
  const [ruleModal, setRuleModal] = useState<RuleView | 'new' | null>(null)
  const [cardModal, setCardModal] = useState<{ kind?: CardKind; rule?: RuleView } | null>(null)
  const [obligationModal, setObligationModal] = useState(false)
  const [obligationChange, setObligationChange] = useState<PendingDefinition>()
  const [editing, setEditing] = useState(false)
  const { message } = App.useApp()
  if (!data) return <AsyncState loading={loading} error={error} onRetry={reload} empty="Policy bulunamadı" />
  const p = data.policy
  const usedByPolicies = data.usedBy.policies ?? []
  const inUse = data.usedBy.permissions.length + usedByPolicies.length > 0
  const submitRule = (existing: RuleView | undefined, draft: RuleDraft, body: object) =>
    setPending(existing
      ? { title: `${p.code} / ${existing.code} güncelle`, changes: { replacedRules: [{ ruleId: existing.id, rule: draft }] }, apply: (v) => api.put(`/api/rules/${existing.id}?expectedModelVersion=${v}`, body) }
      : { title: `${p.code}: yeni kural ${draft.code}`, changes: { addedRules: [draft] }, apply: (v) => api.post(`/api/policies/${policyId}/rules?expectedModelVersion=${v}`, body) })
  const editRule = (r: RuleView) => (parseCard(r.condition ? toDraft(r.condition) : undefined, types) ? setCardModal({ rule: r }) : setRuleModal(r))
  const joiner = p.decisionStrategy === 'Unanimous' ? 'VE' : p.decisionStrategy === 'Affirmative' ? 'VEYA' : 'ÇOĞUNLUK'
  const orderedRules = [...data.rules].sort((a, b) => a.order - b.order || a.code.localeCompare(b.code))
  const activeRules = orderedRules.filter((r) => r.isActive)
  const logicalExpression = activeRules.length
    ? activeRules.map((r) => `(${r.code})`).join(` ${joiner} `)
    : 'Aktif kural yok → INDETERMINATE → DENY'
  const remove = async () => { try { await api.del(`/api/policies/${policyId}`); message.success('Silindi'); invalidateOptions('policies'); navigate('/policies') } catch (e) { message.error((e as Error).message) } }

  return (
    <>
      <PageHeader
        title={<><Code>{p.code}</Code> {p.name}</>}
        subtitle={<Flex gap={4} wrap align="center"><LogicTag logic={p.logic} /><ModeTag mode={p.mode} />
          <StrategyTag strategy={p.decisionStrategy} /><ActiveTag active={p.isActive} /><TenantTag tenant={p.tenant} /> v{p.version}</Flex>}
        extra={<Flex gap={8}>
          <Button icon={<EditOutlined />} onClick={() => setEditing(true)}>Düzenle</Button>
          <Link to={`/what-if?tab=policy&policyId=${policyId}`}><Button icon={<ExperimentOutlined />}>What-If</Button></Link>
          <Popconfirm title={`${p.code} silinsin mi?`} description={inUse ? 'Permission veya başka bir policy kullanıyor; önce oradan çıkarın.' : 'Geri alınamaz.'} onConfirm={remove} disabled={inUse}>
            <Button danger icon={<DeleteOutlined />} disabled={inUse} />
          </Popconfirm>
        </Flex>} />
      {p.description && <Typography.Paragraph type="secondary">{p.description}</Typography.Paragraph>}
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={9}>
          <Card size="small" title="Kullanıldığı yerler">
            <Table size="small" rowKey="id" pagination={false} dataSource={data.usedBy.permissions}
              locale={{ emptyText: 'Hiçbir permission kullanmıyor — bu policy şu an etkisiz.' }}
              columns={[
                { title: 'Permission', render: (_, x) => <><Link to={`/permissions/${x.id}`}><Code>{x.code}</Code></Link><br /><Typography.Text type="secondary" style={{ fontSize: 12 }}>{x.name}</Typography.Text></> },
                { title: 'Uygulama', dataIndex: 'application', render: (v) => <Tag>{v}</Tag> },
                { title: 'Yetki', dataIndex: 'coverage', width: 70 },
              ]} />
            {usedByPolicies.length > 0 && (
              <div style={{ marginTop: 8 }}>
                <Typography.Text type="secondary" style={{ fontSize: 12 }}>Bu policy'yi HAZIR POLICY kartında kullanan policy'ler (değişiklik onları da etkiler):</Typography.Text>
                <Flex wrap gap={4} style={{ marginTop: 4 }}>{usedByPolicies.map((x) => (
                  <Link key={x.id} to={`/policies/${x.id}`}><Tag color="magenta">{x.code} · {x.via}</Tag></Link>
                ))}</Flex>
              </div>
            )}
          </Card>
          <Card size="small" style={{ marginTop: 16 }} title="Yükümlülükler (obligation)" extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setObligationModal(true)}>Yükümlülük</Button>}>
            {data.obligations.length === 0 && <Typography.Text type="secondary">Yok</Typography.Text>}
            {data.obligations.map((o) => (
              <Flex key={o.id} justify="space-between" align="center" style={{ marginBottom: 4 }}>
                <span><Tag color="gold">⚑ {o.code}</Tag>{Object.entries(o.parameters).map(([k, v]) => <Tag key={k}>{k}={v}</Tag>)}<Typography.Text type="secondary" style={{ fontSize: 12 }}>{o.fulfillOn === 'Permit' ? 'izin verilince' : 'reddedilince'}</Typography.Text></span>
                <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={() => setObligationChange({
                  title: `${p.code}: ${o.code} yükümlülüğünü kaldır`,
                  run: (dryRun, expected) => api.del<DefinitionChangeResult>(`/api/policy-obligations/${o.id}?dryRun=${dryRun}${expected === undefined ? '' : `&expectedModelVersion=${expected}`}`),
                })} />
              </Flex>
            ))}
            <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8, marginBottom: 0 }}>
              Policy izin verdiğinde (Advisory modda koşulu sağlandığında) karar ile PEP'e döner: MASK_FIELDS alanları maskeler, LOG_ACCESS hassas erişim loguna yazar. PEP tanımadığı yükümlülükte erişimi reddeder.
            </Typography.Paragraph>
          </Card>
          <Descriptions size="small" style={{ marginTop: 12 }} column={1}>
            <Descriptions.Item label="Son değişiklik">{fmt(p.updatedAt)} {p.updatedBy && `· ${p.updatedBy}`}</Descriptions.Item>
          </Descriptions>
        </Col>
        <Col xs={24} xl={15}>
          <Card size="small" title={<>Kartlar (kurallar) <StrategyTag strategy={p.decisionStrategy} /></>}
            extra={<Flex gap={6}>
              <Dropdown menu={{ items: cardKinds.map((k) => ({ key: k, label: <><Tag color={cardMeta[k].color}>{cardMeta[k].label}</Tag>{cardMeta[k].help}</> })), onClick: ({ key }) => setCardModal({ kind: key as CardKind }) }}>
                <Button size="small" type="primary" icon={<PlusOutlined />}>Kart ekle</Button>
              </Dropdown>
              <Button size="small" onClick={() => setRuleModal('new')}>Gelişmiş kural</Button>
            </Flex>}>
            {data.rules.length === 0 && <Alert type="warning" showIcon style={{ marginBottom: 8 }} message="Kart yok: bu policy belirsiz sonuç verir (izin yok). KİM kartıyla başlayın; saat, kanal, tutar gibi şartları ayrı kartlarla ekleyin." />}
            {p.logic === 'Negative' && <Alert type="warning" showIcon style={{ marginBottom: 8 }} message="Negatif policy: kartların birleşik sonucu tersine çevrilir." description="Yeni kart veya strateji değişikliği beklenmeyen geniş erişime yol açabilir; What-If sonucunu özellikle kazanan kullanıcılar açısından inceleyin." />}
            {p.decisionStrategy !== 'Unanimous' && <Alert type="info" showIcon style={{ marginBottom: 8 }} message={`${strategyLabel[p.decisionStrategy]} stratejisi kullanılıyor`} description={strategyHelp[p.decisionStrategy]} />}
            <Alert type="info" style={{ marginBottom: 8 }} message="Çalışan mantık" description={<Code>{p.logic === 'Negative' ? `DEĞİL (${logicalExpression})` : logicalExpression}</Code>} />
            <Flex vertical gap={4}>
              {orderedRules.map((r, i) => (
                <div key={r.id}>
                  {i > 0 && <div style={{ textAlign: 'center' }}><Tag bordered={false} color={joiner === 'VE' ? 'processing' : 'warning'}>{joiner}</Tag></div>}
                  <RuleCard rule={r} types={types} onEdit={() => editRule(r)}
                    onDelete={() => setPending({ title: `${p.code} / ${r.code} kuralını sil`, changes: { removedRuleIds: [r.id] }, apply: (v) => api.del(`/api/rules/${r.id}?expectedModelVersion=${v}`) })} />
                </div>
              ))}
            </Flex>
            <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8, marginBottom: 0 }}>
              Kart = kural; kartlar {strategyLabel[p.decisionStrategy].toLocaleLowerCase('tr-TR')} ile birleşir. Kartlar sadece ekrandır; motor kuralı değerlendirir.
              Değişiklikler senaryolarla simüle edilir. Değer eksikse karar belirsiz olur → izin yok.
            </Typography.Paragraph>
          </Card>
        </Col>
      </Row>

      {editing && <PolicyEditModal detail={data} onClose={() => setEditing(false)} onSubmit={(v) => { setEditing(false); setDefinition(v) }} />}
      {definition && (
        <DefinitionChangeModal title={`${p.code} güncelle — erişim etkisi`} onClose={() => setDefinition(undefined)} onDone={() => { reload(); invalidateOptions('policies') }}
          run={(dryRun, expected) => api.put<DefinitionChangeResult>(`/api/policies/${policyId}?dryRun=${dryRun}${expected === undefined ? '' : `&expectedModelVersion=${expected}`}`, definition)} />
      )}
      {ruleModal && (
        <RuleModal policyId={policyId} policyCode={p.code} rule={ruleModal === 'new' ? undefined : ruleModal} types={types} onClose={() => setRuleModal(null)}
          onSubmit={(draft, body) => {
            const existing = ruleModal === 'new' ? undefined : ruleModal
            setRuleModal(null)
            submitRule(existing, draft, body)
          }} />
      )}
      {cardModal && (
        <CardRuleModal policyId={policyId} policyCode={p.code} tenantId={p.tenantId} kind={cardModal.kind} rule={cardModal.rule} types={types} existingCodes={data.rules.map((r) => r.code)}
          onClose={() => setCardModal(null)} onChanged={reload}
          onAdvanced={cardModal.rule ? () => { const r = cardModal.rule!; setCardModal(null); setRuleModal(r) } : undefined}
          onSubmit={({ draft, body }) => { const existing = cardModal.rule; setCardModal(null); submitRule(existing, draft, body) }} />
      )}
      {obligationModal && <ObligationModal onClose={() => setObligationModal(false)} onSubmit={(body) => {
        setObligationModal(false)
        setObligationChange({
          title: `${p.code}: ${body.code} yükümlülüğü ekle`,
          run: (dryRun, expected) => api.post<DefinitionChangeResult>(`/api/policies/${policyId}/obligations?dryRun=${dryRun}${expected === undefined ? '' : `&expectedModelVersion=${expected}`}`, body),
        })
      }} />}
      {obligationChange && <DefinitionChangeModal title={obligationChange.title} run={obligationChange.run} onClose={() => setObligationChange(undefined)} onDone={reload} />}
      {pending && <PolicyChangeModal open title={pending.title} changes={pending.changes} apply={pending.apply} onClose={() => setPending(undefined)} onDone={reload} />}
    </>
  )
}

function PolicyEditModal({ detail, onClose, onSubmit }: { detail: PolicyDetail; onClose: () => void; onSubmit: (v: PolicyFormValues) => void }) {
  const [form] = Form.useForm<PolicyFormValues>()
  const p = detail.policy
  const submit = async () => {
    const v = await form.validateFields()
    onSubmit({ ...v, tenantId: p.tenantId, code: p.code })
  }
  return (
    <Modal open width={720} title={`${p.code} düzenle`} onCancel={onClose} onOk={submit} okText="Etkiyi gör" destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={p}>
        <PolicyFields editing />
      </Form>
    </Modal>
  )
}

/** Yükümlülük ekle: tip katalogdan, parametre formu tipten üretilir. */
interface ObligationFormValues { code: string; fulfillOn: 'Permit' | 'Deny'; parameters?: Record<string, string> }

function ObligationModal({ onClose, onSubmit }: { onClose: () => void; onSubmit: (body: ObligationFormValues) => void }) {
  const types = useApi<ObligationTypeDef[]>('/api/obligation-types').data ?? []
  const [form] = Form.useForm()
  const code = Form.useWatch('code', form) as string | undefined
  const type = types.find((t) => t.code === code)
  const save = async () => {
    const v = await form.validateFields()
    onSubmit({ code: v.code, fulfillOn: v.fulfillOn, parameters: v.parameters ?? {} })
  }
  return (
    <Modal open title="Yükümlülük (obligation)" okText="Ekle" onOk={save} onCancel={onClose} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={{ fulfillOn: 'Permit' }}>
        <Form.Item name="code" label="Tip" rules={[{ required: true }]} extra={type?.description}>
          <Select options={types.map((t) => ({ value: t.code, label: `${t.code} — ${t.name}` }))} onChange={() => form.setFieldValue('parameters', {})} />
        </Form.Item>
        {type?.parameters.map((prm) => (
          <Form.Item key={prm.key} name={['parameters', prm.key]} label={prm.label} rules={prm.required ? [{ required: true }] : undefined} extra={prm.hint}>
            <Input />
          </Form.Item>
        ))}
        <Form.Item name="fulfillOn" label="Ne zaman">
          <Radio.Group options={[{ value: 'Permit', label: 'İzin verilince' }, { value: 'Deny', label: 'Reddedilince' }]} optionType="button" />
        </Form.Item>
      </Form>
    </Modal>
  )
}

/** Gelişmiş kural düzenleyici: karta sığmayan ifadeler (iç içe VE / VEYA / DEĞİL, karışık sorular). */
function RuleModal({ policyId, policyCode, rule, types, onClose, onSubmit }: {
  policyId: number
  policyCode: string
  rule?: RuleView
  types: ConditionTypeInfo[]
  onClose: () => void
  onSubmit: (draft: RuleDraft, body: object) => void
}) {
  const [form] = Form.useForm()
  const [condition, setCondition] = useState<ConditionDraft>(rule?.condition ? toDraft(rule.condition) : emptyPredicate())
  const submit = async () => {
    const v = await form.validateFields()
    onSubmit({ policyId, code: v.code, name: v.name, order: v.order, reasonCode: v.reasonCode, isActive: v.isActive, condition }, { ...v, condition })
  }
  return (
    <Modal open title={rule ? `Kural (gelişmiş): ${rule.code}` : 'Yeni kural (gelişmiş)'} onCancel={onClose} onOk={submit} okText="Etkiyi gör" width={980} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={rule ?? { order: 50, isActive: true }}>
        <Row gutter={12}>
          <Col span={6}><Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input disabled={!!rule} placeholder="WORKING_HOURS" /></Form.Item></Col>
          <Col span={14}><Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input placeholder="Mesai saatinde olmalı" /></Form.Item></Col>
          <Col span={4}><Form.Item name="order" label="Sıra"><InputNumber style={{ width: '100%' }} /></Form.Item></Col>
          <Col span={12}><Form.Item name="reasonCode" label="Sağlanmazsa neden kodu"><Input placeholder="OUTSIDE_BUSINESS_HOURS" /></Form.Item></Col>
          <Col span={4}><Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item></Col>
        </Row>
      </Form>
      <Typography.Text strong>Koşul: TRUE → kural sağlandı · FALSE → sağlanmadı · değer eksik → belirsiz</Typography.Text>{' '}
      <Typography.Text type="secondary" style={{ fontSize: 12 }}>önizleme: <Code>{renderDraft(condition)}</Code></Typography.Text>
      <div style={{ marginTop: 6 }}><ConditionBuilder value={condition} onChange={setCondition} types={types} excludePolicy={policyCode} /></div>
      <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8 }}>
        Kullanıcıya özgü değerler (limit, işlem tutarı) buraya yazılmaz; koşul tipi onları attribute olarak çözer. Banka ağı / mesai gibi tekrar kullanılan parçalar ayrı bir
        policy'dir: "Policy kullan (@referans)" ile çağırın — kopyalanmaz, o policy değişince burası da değişir.
      </Typography.Paragraph>
    </Modal>
  )
}
