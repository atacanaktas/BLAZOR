import { AccessBindingsPage, ReportCenterPage } from './pages/WorkspaceCenters'
import { StructureCityV3Page } from './pages/StructureCityV3Page'
import { Navigate, Route, Routes } from 'react-router-dom'
import { AppLayout } from './layout/AppLayout'
import { DashboardPage } from './pages/DashboardPage'
import { AccessFlowPage } from './pages/AccessFlowPage'
import { StructureExplorerPage } from './pages/StructureExplorerPage'
import { TenantsPage } from './pages/TenantsPage'
import { UserDetailPage, UsersPage } from './pages/UsersPages'
import { RoleDetailPage, RolesPage } from './pages/RolesPages'
import { GroupDetailPage, GroupsPage } from './pages/GroupsPages'
import { CatalogPage, ClientsPage, PermissionDetailPage, PermissionsPage } from './pages/CatalogPages'
import { PoliciesPage, PolicyDetailPage } from './pages/PoliciesPages'
import { SharedConditionsPage } from './pages/SharedConditionsPage'
import { ConditionTypesPage } from './pages/ConditionTypesPage'
import { EvaluatePage } from './pages/EvaluatePage'
import { NextralPage } from './pages/NextralPage'
import { WhatIfPage } from './pages/WhatIfPage'
import { SdkDemoPage } from './pages/SdkDemoPage'
import { AuditPage, EventsPage, ExternalPage, SodPage } from './pages/GovernancePages'
import { OwnershipTeamsPage } from './pages/OwnershipTeamsPage'

export default function App() {
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route index element={<DashboardPage />} />
        <Route path="access-management" element={<AccessBindingsPage />} />
        <Route path="reports" element={<ReportCenterPage />} />
        <Route path="all-in-one" element={<StructureExplorerPage />} />
        <Route path="all-in-one-v2" element={<AccessFlowPage />} />
        <Route path="all-in-one-v3" element={<StructureCityV3Page />} />
        <Route path="tenants" element={<TenantsPage />} />
        <Route path="units" element={<Navigate to="/tenants" replace />} />
        <Route path="users" element={<UsersPage />} />
        <Route path="users/:id" element={<UserDetailPage />} />
        <Route path="roles" element={<RolesPage />} />
        <Route path="roles/:id" element={<RoleDetailPage />} />
        <Route path="groups" element={<GroupsPage />} />
        <Route path="groups/:id" element={<GroupDetailPage />} />
        <Route path="catalog" element={<CatalogPage />} />
        <Route path="ownership-teams" element={<OwnershipTeamsPage />} />
        <Route path="permissions" element={<PermissionsPage />} />
        <Route path="permissions/:id" element={<PermissionDetailPage />} />
        <Route path="clients" element={<ClientsPage />} />
        <Route path="policies" element={<PoliciesPage />} />
        <Route path="policies/:id" element={<PolicyDetailPage />} />
        <Route path="shared-conditions" element={<SharedConditionsPage />} />
        <Route path="condition-types" element={<ConditionTypesPage />} />
        <Route path="rules" element={<Navigate to="/condition-types" replace />} />
        <Route path="evaluate" element={<EvaluatePage />} />
        <Route path="nextral" element={<NextralPage />} />
        <Route path="what-if" element={<WhatIfPage />} />
        <Route path="sdk-demo" element={<SdkDemoPage />} />
        <Route path="sod" element={<SodPage />} />
        <Route path="external" element={<ExternalPage />} />
        <Route path="events" element={<EventsPage />} />
        <Route path="audit" element={<AuditPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  )
}
