import { lazy, Suspense, type ComponentType } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import { Spin } from 'antd'
import { AppLayout } from './layout/AppLayout'

const page = <T extends Record<string, unknown>>(load: () => Promise<T>, name: keyof T) =>
  lazy(async () => ({ default: (await load())[name] as ComponentType }))

const DashboardPage = page(() => import('./pages/DashboardPage'), 'DashboardPage')
const TenantsPage = page(() => import('./pages/TenantsPage'), 'TenantsPage')
const UsersPage = page(() => import('./pages/UsersPages'), 'UsersPage')
const UserDetailPage = page(() => import('./pages/UsersPages'), 'UserDetailPage')
const RolesPage = page(() => import('./pages/RolesPages'), 'RolesPage')
const RoleDetailPage = page(() => import('./pages/RolesPages'), 'RoleDetailPage')
const GroupsPage = page(() => import('./pages/GroupsPages'), 'GroupsPage')
const GroupDetailPage = page(() => import('./pages/GroupsPages'), 'GroupDetailPage')
const ResourcesPage = page(() => import('./pages/CatalogPages'), 'ResourcesPage')
const ClientsPage = page(() => import('./pages/CatalogPages'), 'ClientsPage')
const ResourceTypesPage = page(() => import('./pages/CatalogPages'), 'ResourceTypesPage')
const InventoryPage = page(() => import('./pages/InventoryPage'), 'InventoryPage')
const OwnershipTeamsPage = page(() => import('./pages/OwnershipTeamsPage'), 'OwnershipTeamsPage')
const PermissionsPage = page(() => import('./pages/PermissionsPages'), 'PermissionsPage')
const PermissionDetailPage = page(() => import('./pages/PermissionsPages'), 'PermissionDetailPage')
const PoliciesPage = page(() => import('./pages/PoliciesPages'), 'PoliciesPage')
const PolicyDetailPage = page(() => import('./pages/PoliciesPages'), 'PolicyDetailPage')
const ConditionTypesPage = page(() => import('./pages/ConditionTypesPage'), 'ConditionTypesPage')
const EvaluatePage = page(() => import('./pages/EvaluatePage'), 'EvaluatePage')
const ChangeSimulationPage = page(() => import('./pages/ChangeSimulationPage'), 'ChangeSimulationPage')
const PlatformBriefPage = page(() => import('./pages/PlatformBriefPage'), 'PlatformBriefPage')
const SodPage = page(() => import('./pages/GovernancePages'), 'SodPage')
const ExternalPage = page(() => import('./pages/GovernancePages'), 'ExternalPage')
const AuditPage = page(() => import('./pages/GovernancePages'), 'AuditPage')

const loading = <div style={{ display: 'grid', placeItems: 'center', minHeight: 280 }}><Spin size="large" tip="Sayfa yükleniyor" /></div>

export default function App() {
  return (
    <Suspense fallback={loading}>
      <Routes>
        <Route element={<AppLayout />}>
          <Route index element={<DashboardPage />} />
          <Route path="tenants" element={<TenantsPage />} />
          <Route path="units" element={<Navigate to="/tenants" replace />} />
          <Route path="users" element={<UsersPage />} />
          <Route path="users/:id" element={<UserDetailPage />} />
          <Route path="roles" element={<RolesPage />} />
          <Route path="roles/:id" element={<RoleDetailPage />} />
          <Route path="groups" element={<GroupsPage />} />
          <Route path="groups/:id" element={<GroupDetailPage />} />
          <Route path="resources" element={<ResourcesPage />} />
          <Route path="resource-types" element={<ResourceTypesPage />} />
          <Route path="accesses" element={<Navigate to="/resources?view=list" replace />} />
          <Route path="inventory" element={<InventoryPage />} />
          <Route path="ownership-teams" element={<OwnershipTeamsPage />} />
          <Route path="permissions" element={<PermissionsPage />} />
          <Route path="permissions/:id" element={<PermissionDetailPage />} />
          <Route path="clients" element={<ClientsPage />} />
          <Route path="policies" element={<PoliciesPage />} />
          <Route path="policies/:id" element={<PolicyDetailPage />} />
          <Route path="condition-types" element={<ConditionTypesPage />} />
          <Route path="rules" element={<Navigate to="/condition-types" replace />} />
          <Route path="evaluate" element={<EvaluatePage />} />
          <Route path="what-if" element={<ChangeSimulationPage />} />
          <Route path="platform-brief" element={<PlatformBriefPage />} />
          <Route path="sod" element={<SodPage />} />
          <Route path="external" element={<ExternalPage />} />
          <Route path="events" element={<Navigate to="/external?tab=provisioning" replace />} />
          <Route path="audit" element={<AuditPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </Suspense>
  )
}
