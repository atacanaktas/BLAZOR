import {
  AuditOutlined, BranchesOutlined, CloudServerOutlined, ClusterOutlined,
  DesktopOutlined, ExperimentOutlined, FileProtectOutlined, GlobalOutlined, KeyOutlined,
  MobileOutlined, NodeIndexOutlined, PlayCircleOutlined, SafetyCertificateOutlined,
  ShareAltOutlined, TeamOutlined, ThunderboltOutlined, UserOutlined,
} from '@ant-design/icons'

export const visualWorkspace = {
  key: 'visual', label: 'Visual Workspace', icon: <ClusterOutlined />,
  children: [
    { key: '/all-in-one', label: 'All-in-One V1', icon: <ClusterOutlined />, hint: 'Animasyonlu yapı keşfi' },
    { key: '/all-in-one-v2', label: 'All-in-One V2', icon: <ShareAltOutlined />, hint: 'User ve erişim bağlantıları' },
    { key: '/all-in-one-v3', label: 'All-in-One V3', icon: <BranchesOutlined />, hint: 'Genişleyen ağaç ve kontrol akışı' },
  ],
}

export const workspaces = [
  { key: 'identity', label: 'HR & Identity', icon: <UserOutlined />,
    description: 'HR kaynaklı User, iş rolü ve organizasyon bilgileri. Authorization bu verileri karar girdisi olarak kullanır.',
    owner: 'Veri sahibi: HR / Identity ekipleri',
    children: [
      { key: '/users', label: 'Users & Assignments', icon: <UserOutlined />, task: 'Users & Assignments', hint: 'User profili, iş rolü, şube ve organizasyon atamaları.' },
      { key: '/roles', label: 'Role Directory', icon: <SafetyCertificateOutlined />, task: 'Role Directory', hint: 'İş rolü tanımları ve üyeleri. Permission bağlantıları Access Management kapsamındadır.' },
      { key: '/tenants', label: 'Tenants & Organization', icon: <GlobalOutlined />, task: 'Tenants & Organization', hint: 'Tenant, organizasyon birimleri ve hiyerarşi bilgileri.' },
    ] },
  { key: 'catalogs', label: 'Catalogs & Controls', icon: <ClusterOutlined />,
    description: 'Uygulama ve kontrol sahiplerinin belirlediği envanter, bağımlılık ve kısıt tanımları. Yetki ekibi bunları uygular.',
    owner: 'Tanım sahibi: Uygulama / Entegrasyon / Risk ekipleri',
    children: [
      { key: '/catalog', label: 'Resource Catalog', icon: <ClusterOutlined />, task: 'Resource Catalog', hint: 'Tenant / Application altında sınırsız Catalog Level, API, Endpoint ve UI tanımları.' },
      { key: '/ownership-teams', label: 'Ownership Teams', icon: <TeamOutlined />, task: 'Ownership Teams', hint: 'Application ve Catalog Level sahiplik ekipleri.' },
      { key: '/clients', label: 'Client Catalog', icon: <MobileOutlined />, task: 'Client Catalog', hint: 'Çağıran uygulamalar ve Service Account bağlantıları.' },
      { key: '/permissions', label: 'Permission Catalog', icon: <KeyOutlined />, task: 'Permission Catalog', hint: 'Resource üzerinde tanımlı Action ve Permission envanteri.' },
      { key: '/external', label: 'External Dependencies', icon: <CloudServerOutlined />, task: 'External Dependencies', hint: 'API / Endpoint / Permission → dış sistem erişimi; zincir bağımlılıklar ve erişim seviyeleri.' },
      { key: '/sod', label: 'SoD Control Catalog', icon: <SafetyCertificateOutlined />, task: 'SoD Control Catalog', hint: 'Birlikte bulunamayan Role / Permission tanımları, severity ve enforcement.' },
      { key: '/condition-types', label: 'Condition Types', icon: <BranchesOutlined />, task: 'Condition Types', hint: 'Rule oluştururken kullanılabilen Condition tipleri ve parametre sözleşmeleri.' },
    ] },
  { key: 'management', label: 'Access Management', icon: <KeyOutlined />,
    description: 'Mevcut Role ve Resource tanımlarını kullanarak erişim bağlantılarını ve Policy davranışını düzenle.',
    owner: 'İşlem sahibi: Yetki yönetimi ekibi',
    children: [
      { key: '/access-management', label: 'Access Bindings', icon: <KeyOutlined />, task: 'Access Bindings', hint: 'Endpoint / UI → Permission → Role bağlantıları ve Client Scope.' },
      { key: '/groups', label: 'Access Groups', icon: <TeamOutlined />, task: 'Access Groups', hint: 'Erişim amaçlı Group, üyelik kriterleri ve Role / Permission bağlantıları.' },
      { key: '/policies', label: 'Policies & Rules', icon: <FileProtectOutlined />, task: 'Policies & Rules', hint: 'Policy hedefleri, Rule sırası, Condition ve karar davranışı.' },
      { key: '/shared-conditions', label: 'Shared Conditions', icon: <ShareAltOutlined />, task: 'Shared Conditions', hint: 'Policy’lerde tekrar kullanılan Condition ifadeleri.' },
      { key: '/what-if', label: 'Change Simulation', icon: <ExperimentOutlined />, task: 'Change Simulation', hint: 'Değişikliği uygulamadan önce erişim ve SoD etkisini incele.' },
    ] },
  { key: 'reporting', label: 'Monitoring & Reports', icon: <AuditOutlined />,
    description: 'Sahibinden bağımsız olarak tüm alanları incele: mevcut erişim, karar gerekçesi, kontrol ihlalleri ve değişiklik kayıtları.',
    owner: 'Görünürlük: HR + Catalogs + Access Management',
    children: [
      { key: '/reports', label: 'Report Center', icon: <AuditOutlined />, task: 'Report Center', hint: 'Kim neye erişebilir? Endpoint nasıl korunuyor? Role kimlerde? SoD durumu nedir?' },
      { key: '/audit', label: 'Audit & Decision History', icon: <AuditOutlined />, task: 'Audit & Decision History', hint: 'Geçmiş kararın kaydedilmiş gerekçesi ve yönetim değişiklikleri.' },
      { key: '/evaluate', label: 'Decision Analysis', icon: <ThunderboltOutlined />, task: 'Decision Analysis', hint: 'Güncel verilerle bir isteğin neden PERMIT / DENY aldığını incele.' },
      { key: '/events', label: 'Events & Delivery', icon: <NodeIndexOutlined />, task: 'Events & Delivery', hint: 'Outbox, provisioning aksiyonları ve dış sistem aktarım durumu.' },
    ] },
  { key: 'demos', label: 'Demos & Prototypes', icon: <PlayCircleOutlined />,
    description: 'Örnek uygulamalar ve değerlendirme aşamasındaki görsel çalışma alanları.',
    owner: 'Demo ve tasarım alternatifleri',
    children: [
      { key: '/nextral', label: 'Nextral Demo', icon: <DesktopOutlined />, task: 'Nextral Demo', hint: 'User erişimini örnek Nextral ekranında dene.' },
      { key: '/sdk-demo', label: 'Service / SDK Demo', icon: <PlayCircleOutlined />, task: 'Service / SDK Demo', hint: 'Örnek servis üzerinden authorization entegrasyonunu dene.' },
      ...visualWorkspace.children.map((item) => ({ ...item, task: item.label })),
    ] },
]
export const sections = workspaces

export const bindingTasks = [
  { to: '/catalog', title: 'Endpoint → Permission', text: 'API seç, Endpoint’in Permission eşleştirmesini düzenle.' },
  { to: '/catalog', title: 'Screen / UI → Permission', text: 'Resource Catalog içinden Screen ve UI bağlantılarını düzenle.' },
  { to: '/roles', title: 'Role → Permission', text: 'Role seç, erişebileceği Permission’ları ekle veya kaldır. HR Role atamalarından ayrı bir işlemdir.' },
  { to: '/clients', title: 'Client → Allowed Permissions', text: 'Client için önceden izin verilen Resource, Permission ve Action kapsamını düzenle.' },
  { to: '/policies', title: 'Resource / Client → Policy', text: 'Policy hedeflerini, Rule ve Condition’ları düzenle.' },
  { to: '/groups', title: 'Group → Role / Permission', text: 'Erişim amaçlı Group üyelik kriterlerini ve erişim bağlantılarını düzenle.' },
  { to: '/users', title: 'Direct Permission Exceptions', text: 'User detayında gerekçeli doğrudan Permission istisnalarını yönet.' },
]
export const reportGroups = [
  { title: 'Current Access', description: 'Güncel modeldeki erişim yolları; Policy sonucu istek bağlamına göre değişebilir.', items: [
    { to: '/users', title: 'X User bugün nerelere erişebilir, neden?', text: 'User seç → etkin Permission’lar, Group / Role kaynakları ve Client bazlı erişim.' },
    { to: '/roles', title: 'Y Role kimlerde var?', text: 'Role seç → doğrudan ve Group üzerinden sahipler.' },
    { to: '/groups', title: 'Group üyeliği nereden geliyor?', text: 'Üyeleri, dinamik kriterleri ve erişim bağlantılarını incele.' },
  ] },
  { title: 'Resource Protection & Catalogs', description: 'Uygulama, entegrasyon ve kontrol sahiplerinin tanımları da raporlama kapsamındadır.', items: [
    { to: '/catalog', title: 'X Endpoint nasıl korunuyor?', text: 'API seç → Endpoint → Permission bağlantısını incele.' },
    { to: '/permissions', title: 'Permission hangi erişim yollarına sahip?', text: 'Permission seç → sahipler, Role / Group kaynakları ve ilgili Policy’ler.' },
    { to: '/external', title: 'Hangi dış sistem erişimleri gerekli?', text: 'Bağımlılık zincirlerini, access level ve drift durumunu incele.' },
    { to: '/sod?tab=v', title: 'SoD ihlalleri kimlerde var?', text: 'Açık ihlalleri ve kontrol sonuçlarını incele; gerektiğinde tarama çalıştır.' },
    { to: '/sod?tab=r', title: 'Hangi Role / Permission birlikte bulunamaz?', text: 'Kontrol kataloğunu, severity ve enforcement tanımlarını incele.' },
    { to: '/tenants', title: 'Organizasyon yapısı nasıl?', text: 'Tenant ve organizasyon hiyerarşisini incele.' },
    { to: '/catalog', title: 'Hangi Platform / Domain / Screen var?', text: 'Resource envanterini ve alt kırılımlarını incele.' },
    { to: '/clients', title: 'Client için hangi Permission’lar allowed?', text: 'Client, Service Account ve kayıtlı Allowed Permissions bilgilerini incele.' },
    { to: '/condition-types', title: 'Hangi Condition tipleri destekleniyor?', text: 'Condition tiplerini ve parametrelerini incele.' },
    { to: '/policies', title: 'Hangi Policy ve Rule uygulanıyor?', text: 'Hedefler, istisnalar, Rule’lar ve Condition ifadelerini incele.' },
    { to: '/shared-conditions', title: 'Hangi ortak Condition kullanılıyor?', text: 'Tekrar kullanılan Condition tanımlarını incele.' },
  ] },
  { title: 'History & Operations', description: 'Geçmiş kayıtlar ve güncel simülasyon farklı kanıtlardır.', items: [
    { to: '/audit', title: 'T anındaki işlem neden PERMIT aldı?', text: 'Audit kaydını aç → o kararla birlikte kaydedilmiş gerekçe ve erişim kaynaklarını incele.' },
    { to: '/audit', title: 'Kim, hangi tanımı veya atamayı değiştirdi?', text: 'Mevcut audit kayıtlarını actor, kategori ve metin ile ara.' },
    { to: '/events', title: 'Değişiklik dış sisteme ulaştı mı?', text: 'Provisioning aksiyonlarını ve event teslim durumlarını incele.' },
    { to: '/evaluate', title: 'Aynı istek bugün hangi kararı alır?', text: 'Güncel model ile Decision Analysis çalıştır; geçmiş kararın yerine kullanma.' },
    { to: '/what-if', title: 'Değişiklik kimleri etkiler?', text: 'Uygulamadan önce erişim değişimini ve SoD etkisini simüle et.' },
  ] },
]
