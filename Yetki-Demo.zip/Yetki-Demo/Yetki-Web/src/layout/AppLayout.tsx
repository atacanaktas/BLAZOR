import { Avatar, Badge, Button, Drawer, Grid, Layout, Menu, Popover, Select, Tooltip } from 'antd'
import { BellOutlined, DashboardOutlined, MenuFoldOutlined, MenuOutlined, MenuUnfoldOutlined,
  CloseOutlined, ExclamationCircleFilled, InfoCircleFilled, LoadingOutlined,
  SafetyCertificateOutlined, SearchOutlined, UserOutlined, WarningFilled } from '@ant-design/icons'
import { navigationSections, workspaces } from './navigation'
import { useEffect, useRef, useState } from 'react'
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { api, getActor, setActor } from '../api/client'

const { Sider, Header, Content } = Layout
const overview = { key: '/', label: 'Workspace', icon: <DashboardOutlined /> }
const pages = [overview, ...navigationSections.flatMap((s) => s.children)]
const actors = ['yetki.admin', 'guvenlik.ekibi', 'ali.demir']

type ToastKind = 'loading' | 'info' | 'warning' | 'error'

export function AppLayout() {
  const navigate = useNavigate()
  const location = useLocation()
  const screens = Grid.useBreakpoint()
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [actor, setActorState] = useState(getActor())
  const [info, setInfo] = useState<{ modelVersion: number; pendingEvents: number }>()
  const [connection, setConnection] = useState<'loading' | 'online' | 'offline'>('loading')
  const connectionRef = useRef<'loading' | 'online' | 'offline'>('loading')
  const [toast, setToast] = useState<{ kind: ToastKind; title: string; detail: string } | null>({
    kind: 'loading', title: 'Sistem hazırlanıyor', detail: 'Yetki modeli ve çalışma alanı yükleniyor.',
  })

  useEffect(() => {
    let active = true
    const load = () => api.get<{ modelVersion: number; pendingEvents: number }>('/api/version')
      .then((v) => { if (active) {
        setInfo(v); setConnection('online')
        if (connectionRef.current !== 'online') setToast({ kind: 'info', title: 'Workspace hazır', detail: 'Güncel yetki modeli başarıyla yüklendi.' })
        connectionRef.current = 'online'
      } })
      .catch(() => { if (active) {
        setInfo(undefined); setConnection('offline')
        if (connectionRef.current !== 'offline') setToast({ kind: 'error', title: 'Bağlantı kurulamadı', detail: 'Yetki yönetim servisine erişilemiyor.' })
        connectionRef.current = 'offline'
      } })
    load()
    const timer = setInterval(load, 15000)
    return () => { active = false; clearInterval(timer) }
  }, [])

  useEffect(() => {
    if (!toast || toast.kind === 'loading') return
    const timer = window.setTimeout(() => setToast(null), 4200)
    return () => window.clearTimeout(timer)
  }, [toast])

  const selected = '/' + (location.pathname.split('/')[1] ?? '')
  const ownershipSection = workspaces.find((s) => s.children.some((p) => p.key === selected))
  const go = (path: string) => { navigate(path); setMobileOpen(false) }
  const notificationItems: { kind: ToastKind; title: string; detail: string; time: string }[] = [
    ...(connection === 'offline' ? [{ kind: 'error' as const, title: 'API bağlantısı yok', detail: 'Yetki yönetim servisine erişilemiyor.', time: 'Şimdi' }] : []),
    ...((info?.pendingEvents ?? 0) > 0 ? [{ kind: 'warning' as const, title: 'Bekleyen aktarım olayları', detail: `${info!.pendingEvents} olay dış sistemlere aktarılmayı bekliyor.`, time: 'Güncel' }] : []),
  ]
  const notificationContent = <div className="notification-popover">
    <div className="notification-popover-head"><strong>Bildirimler</strong><Link to="/external?tab=outbox">Tümünü gör</Link></div>
    {notificationItems.map((item) => <div className={`notification-history-item is-${item.kind}`} key={item.title}>
      <span className="notification-history-icon">{item.kind === 'loading' ? <LoadingOutlined spin /> : item.kind === 'warning' ? <WarningFilled /> : <ExclamationCircleFilled />}</span>
      <span><strong>{item.title}</strong><small>{item.detail}</small></span><time>{item.time}</time>
    </div>)}
    {notificationItems.length === 0 && <div className="notification-history-empty"><InfoCircleFilled /><span>Bekleyen olay veya bağlantı uyarısı yok.</span></div>}
  </div>
  const navigation = (compact: boolean) => (
    <>
      <Link to="/" className="brand" aria-label="Yetki, genel bakış" onClick={() => setMobileOpen(false)}>
        <span className="brand-mark"><SafetyCertificateOutlined /></span>
        {!compact && <span className="brand-copy"><strong>yetki<span>.</span></strong><small>ERİŞİM YÖNETİMİ</small></span>}
      </Link>
      {screens.lg && <Tooltip title={collapsed ? 'Menüyü genişlet' : 'Menüyü daralt'} placement="right">
        <Button type="text" className="sidebar-collapse" aria-label={collapsed ? 'Menüyü genişlet' : 'Menüyü daralt'}
          icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />} onClick={() => setCollapsed(!collapsed)} />
      </Tooltip>}
      <div className="navigation-body">
        {!compact && <div className="nav-caption">ÇALIŞMA ALANI</div>}
        <Menu key={String(compact)} mode="inline" inlineCollapsed={compact} selectedKeys={[selected]}
          items={[
            overview,
            { type: 'divider' },
            ...navigationSections.map((s) => ({
              type: 'group' as const,
              key: `group-${s.key}`,
              label: s.label,
              children: s.children.map((p) => ({ key: p.key, label: p.label, icon: p.icon, title: p.hint })),
            })),
          ]} onClick={(e) => go(e.key)} />
      </div>
      <div className={`sidebar-footer ${compact ? 'is-compact' : ''}`}>
        <Tooltip title={connection === 'online' ? `Bağlı · Model v${info?.modelVersion}` : connection === 'offline' ? 'API bağlantısı yok' : 'Bağlanıyor'}>
          <span className={`connection-dot ${connection}`} />
        </Tooltip>
        {!compact && <div><strong>{connection === 'online' ? 'Sistem bağlantısı aktif' : connection === 'offline' ? 'Bağlantı kurulamadı' : 'Bağlantı kuruluyor'}</strong>
          <span>{info ? `Model v${info.modelVersion} · Yönetim paneli` : 'Yetki yönetim servisi'}</span></div>}
      </div>
    </>
  )

  return (
    <Layout className="app-shell">
      <a href="#main-content" className="skip-link">İçeriğe geç</a>
      {screens.lg && <Sider width={272} collapsedWidth={76} collapsed={collapsed} theme="light" className="app-sidebar">{navigation(collapsed)}</Sider>}
      <Drawer title="Gezinme" placement="left" width={280} open={!screens.lg && mobileOpen} onClose={() => setMobileOpen(false)} className="mobile-navigation">
        {navigation(false)}
      </Drawer>
      <Layout className="workspace">
        <div key={`${location.pathname}${location.search}`} className="route-progress is-active" aria-hidden="true" />
        {toast && <div className={`status-toast is-${toast.kind}`} role="status" aria-live="polite">
          <span className="status-toast-icon">{toast.kind === 'loading' ? <LoadingOutlined spin /> : toast.kind === 'error' ? <ExclamationCircleFilled /> : toast.kind === 'warning' ? <WarningFilled /> : <InfoCircleFilled />}</span>
          <span className="status-toast-copy"><strong>{toast.title}</strong><small>{toast.detail}</small></span>
          <Button type="text" size="small" aria-label="Bildirimi kapat" icon={<CloseOutlined />} onClick={() => setToast(null)} />
          <span className="status-toast-timer" />
        </div>}
        <Header className="workspace-header">
          {!screens.lg && <Button type="text" className="mobile-nav-toggle" aria-label="Menüyü aç"
            icon={<MenuOutlined />} onClick={() => setMobileOpen(true)} />}
          <div className="header-actions">
            <Select className="page-search" showSearch value={null} placeholder="Ara" suffixIcon={<SearchOutlined />}
              aria-label="Sayfalarda ara" onChange={go}
              filterOption={(input, option) => {
                const page = pages.find((p) => p.key === option?.value)
                const hint = page && 'hint' in page ? page.hint : ''
                return `${page?.label ?? ''} ${hint}`.toLocaleLowerCase('tr-TR').includes(input.toLocaleLowerCase('tr-TR'))
              }}
              options={pages.map((p) => ({ value: p.key, label: p.label }))} notFoundContent="Sayfa bulunamadı" />
            <Popover content={notificationContent} trigger="click" placement="bottomRight" overlayClassName="notification-overlay">
              <Tooltip title={info ? `${info.pendingEvents} bekleyen olay` : 'Olaylar ve aktarım'}>
                <Badge count={info?.pendingEvents} size="small" offset={[-4, 4]}>
                  <Button type="text" aria-label="Bildirimleri görüntüle" icon={<BellOutlined />} />
                </Badge>
              </Tooltip>
            </Popover>
            <div className="actor-control">
              <Avatar size={32} icon={<UserOutlined />} />
              <div className="actor-copy"><span>Yönetici</span><Select aria-label="İşlemi yapan kullanıcı" value={actor} variant="borderless"
                options={actors.map((a) => ({ value: a, label: a }))} onChange={(v) => {
                  setActor(v); setActorState(v)
                  setToast({ kind: 'info', title: 'İşlem sahibi değiştirildi', detail: `Yeni audit kullanıcısı: ${v}` })
                }} /></div>
            </div>
          </div>
        </Header>
        <Content id="main-content" className="workspace-content" tabIndex={-1}>
          <div className="page-content">
            {ownershipSection && <div className="ownership-context"><span><strong>{ownershipSection.label}</strong> · {ownershipSection.owner}</span></div>}
            <Outlet />
          </div>
          <footer className="workspace-footer"><span>Yetki · Erişim yönetimi</span><span>Kontrol sizde.</span></footer>
        </Content>
      </Layout>
    </Layout>
  )
}
