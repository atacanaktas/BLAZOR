// Yetki Motoru API sözleşme tipleri (backend DTO'larıyla birebir).

export type DecisionType = 'Permit' | 'Deny' | 'NotApplicable' | 'Indeterminate'
export type TriState = 'True' | 'False' | 'Indeterminate'
/** Policy karar stratejisi: rule'lar (sağlanması gereken koşullar) tek policy sonucuna nasıl indirgenir. */
export type CombiningAlgorithm = 'AllRulesMustPass' | 'AnyRuleMustPass'
export type ConditionKind = 'Predicate' | 'AllOf' | 'AnyOf' | 'Not' | 'Reference'
export type PolicyMode = 'Enforce' | 'ReportOnly'
export type TargetType = 'All' | 'Application' | 'CatalogNode' | 'Permission'
export type InclusionMode = 'Include' | 'Exclude'
/** Intermediary = aracı (gateway / BFF / kullanıcı adına çağıran servis): isteği başlatmaz, 'via' zincirinde yer alır. */
export type ClientType = 'Confidential' | 'Public' | 'Service' | 'Intermediary'
export type Severity = 'Low' | 'Medium' | 'High' | 'Critical'
export type PermissionSourceType = 'DirectRole' | 'GroupRole' | 'GroupPermission' | 'DirectPermission'

export interface Option {
  value: number
  label: string
  group?: string
  code: string
}

// ------------------------------------------------------------------ Etkin yetki

export interface PermissionSource {
  type: PermissionSourceType
  roleId?: number
  roleCode?: string
  groupId?: number
  groupCode?: string
  path: string
}

export interface MembershipReason {
  kind: 'Member' | 'Filter'
  filterOrder?: number
  text: string
}

export interface GroupMembership {
  groupId: number
  code: string
  name: string
  tenant: string
  reasons: MembershipReason[]
}

export interface EffectivePermission {
  permissionId: number
  code: string
  name: string
  application: string
  path: string
  action: string
  riskLevel: Severity
  sources: PermissionSource[]
}

export interface EffectivePermissionSet {
  userId: number
  userName: string
  fullName: string
  tenant: string
  isActive: boolean
  modelVersion: number
  computedAt: string
  roles: { roleId: number; code: string; name: string; tenant: string; sources: { kind: string; groupCode?: string; text: string; validUntil?: string }[] }[]
  groups: GroupMembership[]
  excludedFromGroups: { groupId: number; code: string; reason: string }[]
  permissions: EffectivePermission[]
  ignoredAssignments: string[]
}

// ------------------------------------------------------------------ Karar

export interface UsedAttribute {
  attribute: string
  value?: string | null
  source: string
  resolved: boolean
}

export interface ConditionTrace {
  kind: ConditionKind
  conditionType?: string
  expression: string
  value: TriState
  message?: string
  missingAttributes?: string[]
  evidence?: UsedAttribute[]
  children?: ConditionTrace[]
}

/** Rule sonucu: result Permit = sağlandı · Deny = sağlanmadı · Indeterminate = belirsiz · NotApplicable = pasif. */
export interface RuleEvaluation {
  ruleId: number
  code: string
  name: string
  order: number
  isActive: boolean
  conditionValue: TriState
  result: DecisionType
  reasonCode?: string
  message: string
  expression: string
  condition?: ConditionTrace
  missingAttributes: string[]
  evidence: UsedAttribute[]
  isDeciding: boolean
}

export interface PolicyEvaluation {
  policyId: number
  code: string
  name: string
  version: number
  algorithm: CombiningAlgorithm
  result: DecisionType
  decidingRule?: string
  rules: RuleEvaluation[]
  isDeciding: boolean
  matchedBy?: string
  mode: PolicyMode
  tenant?: string
}

export interface DecisionStep {
  step: string
  outcome: 'Pass' | 'Fail' | 'Info' | 'Skip'
  detail: string
}

export interface AuthorizationDecision {
  decisionId: string
  decision: DecisionType
  isAllowed: boolean
  reasonCode: string
  humanReadableReason: string
  userName?: string
  tenant?: string
  client?: string
  /** Doğrulanmış aracı zinciri (gateway → servis) */
  via: string[]
  /** PEP'in yerine getirmesi gereken yükümlülükler */
  obligations: DecisionObligation[]
  permission?: string
  action?: string
  permissionName?: string
  application?: string
  catalogPath?: string
  endpoint?: string
  resource?: string
  decidingPolicy?: string
  decidingRule?: string
  evaluatedAt: string
  isSimulation: boolean
  modelVersion: number
  durationMs: number
  steps: DecisionStep[]
  permissionSources: PermissionSource[]
  clientAllowedPermission?: string
  grantedScopes: string[]
  matchedScope?: string
  policies: PolicyEvaluation[]
  excludedPolicies: { code: string; matchedBy: string; excludedBy: string }[]
  reportOnlyDenials: string[]
  failedRules: string[]
  missingAttributes: string[]
  evidence: UsedAttribute[]
  context: Record<string, string | null>
}

/** Standart istek: { tenant, client, subject, resource, action, context }. Alternatif: permission kodu veya endpoint. */
/** Karar ile PEP'e dönen yükümlülük (ör. MASK_FIELDS). PEP tanımıyorsa erişimi reddetmeli. */
export interface DecisionObligation {
  code: string
  policy: string
  parameters: Record<string, string>
}

export interface ObligationTypeDef {
  code: string
  name: string
  description: string
  parameters: { key: string; label: string; required: boolean; hint?: string }[]
}

export interface AuthorizationRequest {
  tenant?: string
  /** Aracı zinciri (gateway, BFF): orijinal client 'client' alanında kalır */
  via?: string[]
  subject: { id?: string; userId?: number }
  action?: string
  permission?: string
  endpoint?: { api: string; method: string; path: string }
  resource?: { type?: string; id?: string; properties?: Record<string, string> }
  context: Record<string, string>
  client?: string
  /** Access token'a verilmiş OAuth scope değerleri (case-sensitive). */
  scopes?: string[]
  correlationId?: string
}

// ------------------------------------------------------------------ Entitlement

export interface RuntimeCheck {
  decision: DecisionType
  reasonCode: string
  reason: string
}

export interface EntitledPermission {
  permissionId: number
  code: string
  name: string
  application: string
  path: string
  action: string
  riskLevel: Severity
  sources: string[]
  clientAllowedPermission?: string
  matchedScope?: string
  policies: string[]
  requiresRuntimeCheck: boolean
  runtime?: RuntimeCheck
}

export interface UiEntitlement {
  id: number
  code: string
  name: string
  kind: 'Screen' | 'Menu' | 'Tab' | 'Button' | 'Field'
  parentCode?: string
  path: string
  permission?: string
  enabled: boolean
  reason: string
  runtime?: RuntimeCheck
}

export interface EntitlementResult {
  userName: string
  fullName: string
  tenant: string
  client?: string
  modelVersion: number
  computedAt: string
  eTag: string
  permissions: EntitledPermission[]
  blockedByClientPermission: string[]
  blockedByTokenScope: string[]
  uiElements: UiEntitlement[]
}

// ------------------------------------------------------------------ Katalog / policy görünümleri

export interface CatalogTreeEndpoint {
  id: number
  method: string
  path: string
  operationId?: string
  summary?: string
  permissionId?: number
  permission?: string
  /** Dış bağımlılıklar (ör. RACF:MUS1) */
  external: string[]
}

/** Tenant, Application veya herhangi bir Catalog Level altındaki API. */
export interface CatalogTreeApi {
  id: number
  code: string
  name: string
  audience: string
  isActive: boolean
  /** API seviyesindeki dış bağımlılıklar (tüm endpoint'lere miras) */
  external: string[]
  endpoints: CatalogTreeEndpoint[]
}

export interface CatalogTreeNode {
  id: number
  tenantId: number
  applicationId?: number
  code: string
  name: string
  type: 'Domain' | 'Module' | 'SubModule' | 'Level'
  path: string
  permissions: number
  apis: number
  uiElements: number
  children: CatalogTreeNode[]
  apiList: CatalogTreeApi[]
}

export interface CatalogTreeApp {
  id: number
  code: string
  name: string
  type: string
  isActive: boolean
  /** Sahip tenant: uygulama bu tenant ve alt tenant'larında kullanılabilir. */
  tenantId: number
  tenant: string
  /** Tenant altındaki doğrudan içerikleri ağaçta taşımak için backend tarafından üretilen görünüm kökü. */
  isTenantRoot: boolean
  permissionCount: number
  apiCount: number
  endpointCount: number
  children: CatalogTreeNode[]
  apiList: CatalogTreeApi[]
}

export interface TargetView {
  id: number
  mode: InclusionMode
  targetType: TargetType
  targetId?: number
  description: string
  actions?: string
}

export interface ConditionView {
  id: number
  kind: ConditionKind
  conditionType?: string
  parameters: Record<string, string>
  children: ConditionView[]
  sharedCondition?: string
  sharedConditionVersion?: number
}

export interface ConditionDraft {
  kind: ConditionKind
  conditionTypeCode?: string
  sharedConditionCode?: string
  parameters: Record<string, string>
  children: ConditionDraft[]
}

export interface ParamDef {
  key: string
  label: string
  type: string
  required: boolean
  defaultValue?: string
  description?: string
}

export interface ConditionTypeInfo {
  id: number
  code: string
  name: string
  description?: string
  defaultScope: string
  parameterSchemaJson: string
  requiredAttributes?: string
  isAvailable: boolean
  isSubjectOnly: boolean
}

export interface SharedConditionInfo {
  id: number
  code: string
  name: string
  description?: string
  scope: 'Global' | 'Domain'
  domain?: string
  isActive: boolean
  version: number
  expression: string
  usageCount: number
  policies: string[]
}

export interface RuleView {
  id: number
  code: string
  name: string
  description?: string
  order: number
  reasonCode?: string
  isActive: boolean
  expression: string
  condition?: ConditionView
  policyId?: number
  policy?: string
}

export interface RuleDraft {
  policyId: number
  code: string
  name?: string
  order: number
  reasonCode?: string
  condition: ConditionDraft
}

// ------------------------------------------------------------------ Grup

export interface GroupCriterionDraft {
  attribute: string
  values: string[]
}

export interface GroupFilterDraft {
  mode: InclusionMode
  description?: string
  criteria: GroupCriterionDraft[]
}

export interface GroupCriterionInfo {
  code: string
  name: string
  description: string
  valueSource: 'role' | 'orgUnit' | 'orgUnitType' | 'tenant' | 'user' | 'userKind' | 'text'
}

// ------------------------------------------------------------------ Değişiklik setleri (What-If)

export interface AuthorizationChangeSet {
  userRoles?: { userId: number; roleId: number; add: boolean; validUntil?: string }[]
  userPermissions?: { userId: number; permissionId: number; add: boolean; validUntil?: string }[]
  userUnits?: { userId: number; orgUnitId: number; add: boolean }[]
  rolePermissions?: { roleId: number; permissionId: number; add: boolean }[]
  groupMembers?: { groupId: number; userId: number; add: boolean; validUntil?: string }[]
  groupGrants?: { groupId: number; kind: 'Role' | 'Permission'; targetId: number; add: boolean }[]
  groupFilters?: { groupId: number; filters: GroupFilterDraft[] }[]
  groupActivations?: { id: number; isActive: boolean }[]
  roleUpdates?: { roleId: number; isActive?: boolean; isInheritable?: boolean }[]
  userUpdates?: { userId: number; title?: string; isActive?: boolean; isOnLeave?: boolean; cashWithdrawalLimit?: number }[]
}

export interface PolicyChangeSet {
  policyActivations?: { policyId: number; isActive: boolean }[]
  policyModes?: { policyId: number; mode: PolicyMode }[]
  policyAlgorithms?: { policyId: number; algorithm: CombiningAlgorithm }[]
  addedTargets?: { policyId: number; mode: InclusionMode; targetType: TargetType; targetId?: number; actions?: string }[]
  removedTargetIds?: number[]
  addedClientTargets?: { policyId: number; mode: InclusionMode; clientId: number }[]
  removedClientTargetIds?: number[]
  ruleOverrides?: { ruleId: number; isActive?: boolean; order?: number }[]
  conditionOverrides?: { conditionId: number; parameters: Record<string, string> }[]
  addedRules?: RuleDraft[]
  removedRuleIds?: number[]
  replacedRules?: { ruleId: number; rule: RuleDraft }[]
  sharedConditionReplacements?: { sharedConditionId: number; condition: ConditionDraft }[]
}

// ------------------------------------------------------------------ Etki analizi

export interface PermissionDelta {
  permissionId: number
  code: string
  name: string
  path: string
  sources: string[]
}

export interface SodConflict {
  sodRuleId: number
  code: string
  name: string
  severity: Severity
  enforcement: 'Warn' | 'Block'
  matchedMembers: { type: string; id: number; code: string; name: string; paths: string[] }[]
}

// ------------------------------------------------------------------ Dış sistem (RACF / LDAP)

export type ExternalAccessLevel = 'Read' | 'Update' | 'Control' | 'Alter'

/** Dış sistemde açılacak / değişecek / kapanacak yetki (seviye büyük harf: READ, UPDATE...). */
export interface ExternalChange {
  system: string
  code: string
  resourceClass?: string
  level?: string
  previousLevel?: string
  reasons: string[]
}

export interface ExternalUserImpact {
  userId: number
  userName: string
  grants: ExternalChange[]
  modifies: ExternalChange[]
  revokes: ExternalChange[]
}

export interface ExternalImpactResult {
  dryRun: boolean
  summary: string
  affectedUserCount: number
  users: ExternalUserImpact[]
}

export interface ExternalTargetView {
  externalPermissionId: number
  system: string
  code: string
  name?: string
  resourceClass?: string
  hasAccessLevels: boolean
}

export interface ExternalDiffItem {
  target: ExternalTargetView
  desiredLevel?: ExternalAccessLevel
  currentLevel?: ExternalAccessLevel
  action: 'Grant' | 'Modify' | 'Revoke' | 'None'
  reasons: string[]
}

export interface UserExternalStatus {
  userId: number
  userName: string
  isActive: boolean
  inSync: boolean
  items: ExternalDiffItem[]
}

export interface ExternalDependencyView {
  id: number
  ownerType: 'Api' | 'Endpoint' | 'Permission'
  owner: string
  apiId?: number
  endpointId?: number
  permissionId?: number
  externalPermissionId: number
  system: string
  code: string
  name?: string
  resourceClass?: string
  hasAccessLevels: boolean
  level?: ExternalAccessLevel
  note?: string
}

export interface ExternalSystemView {
  id: number
  code: string
  name: string
  hasAccessLevels: boolean
  permissions: {
    id: number; code: string; name?: string; resourceClass?: string; description?: string; dependencyCount: number; userCount: number
    requires: { id: number; key: string; level?: ExternalAccessLevel }[]
    requiredBy: string[]
  }[]
}

export interface UserImpact {
  userId: number
  userName: string
  fullName: string
  tenant: string
  addedPermissions: PermissionDelta[]
  removedPermissions: PermissionDelta[]
  retainedPermissions: { permissionId: number; code: string; name: string; before: string[]; after: string[] }[]
  addedRoles: string[]
  removedRoles: string[]
  addedGroups: string[]
  removedGroups: string[]
  newSodConflicts: SodConflict[]
  /** Dış sistemde açılacak veya seviyesi değişecek (previousLevel dolu) yetkiler */
  externalGrants: ExternalChange[]
  /** Dış sistemde kapanacak yetkiler (kalan hiçbir etkin yetki gerektirmiyor) */
  externalRevokes: ExternalChange[]
}

export interface ChangeImpactResult {
  dryRun: boolean
  applied: boolean
  blocked: boolean
  summary: string
  affectedUserCount: number
  evaluatedUserCount: number
  users: UserImpact[]
  blockingConflicts: { userId: number; userName: string; conflict: SodConflict }[]
  warnings: { userId: number; userName: string; conflict: SodConflict }[]
}

export interface ImpactScenario {
  name: string
  context: Record<string, string | undefined>
  client?: string
}

export type DecisionChange = 'NEWLY_DENIED' | 'NEWLY_INDETERMINATE' | 'NEWLY_ALLOWED' | 'REASON_CHANGED' | 'UNCHANGED'

export interface PermissionPolicyDiff {
  permissionId: number
  code: string
  name: string
  path: string
  tenant: string
  holderCount: number
  policiesBefore: string[]
  policiesAfter: string[]
  rulesBefore: { policy: string; code: string; name: string; expression: string }[]
  rulesAfter: { policy: string; code: string; name: string; expression: string }[]
  addedRules: string[]
  removedRules: string[]
  changedRules: { policy: string; ruleCode: string; expressionBefore: string; expressionAfter: string }[]
  requiredAttributesAfter: string[]
  newRequiredAttributes: string[]
  becomesUnrestricted: boolean
  becomesRestricted: boolean
}

export interface DecisionBrief {
  decision: DecisionType
  reasonCode: string
  reason: string
  decidingPolicy?: string
  decidingRule?: string
}

export interface PolicyImpactResult {
  summary: string
  permissions: PermissionPolicyDiff[]
  affectedUsers: { userId: number; userName: string; fullName: string; tenant: string; permissions: string[] }[]
  scenarios: ImpactScenario[]
  rows: { userId: number; userName: string; fullName: string; permission: string; scenario: string; before: DecisionBrief; after: DecisionBrief; change: DecisionChange }[]
  evaluations: number
  truncated: boolean
  newlyDenied: number
  newlyAllowed: number
  otherChanged: number
  unchanged: number
  durationMs: number
}
