// Yönetim konsolu istemcisi. Konsol SADECE PAP (yönetim API'si) ile konuşur; PDP (karar) ve PIP (kimlik) PAP'ın arkasındadır.
// Frontend hiçbir yetki kararı üretmez; kararlar ve hesaplanan görünümler PAP üzerinden PDP'den gelir.

export const API_URL: string = import.meta.env.VITE_API_URL ?? 'http://localhost:5100'

const ACTOR_KEY = 'yetki.actor'

/** Yönetim işlemini yapan kişi (audit "kim yaptı?"). PROTOTİP: X-Actor header'ı ile gönderilir. */
export function getActor(): string {
  try {
    return localStorage.getItem(ACTOR_KEY) || 'yetki.admin'
  } catch {
    return 'yetki.admin'
  }
}

export function setActor(actor: string) {
  try {
    localStorage.setItem(ACTOR_KEY, actor)
  } catch {
    /* depolama yoksa oturum boyunca varsayılan kullanılır */
  }
}

export interface ProblemDetails {
  title?: string
  status?: number
  detail?: string
  errors?: Record<string, string[]>
  details?: unknown
  [key: string]: unknown
}

export class ApiError extends Error {
  status: number
  problem: ProblemDetails
  constructor(status: number, problem: ProblemDetails) {
    const extra = problem.errors ? ' ' + Object.values(problem.errors).flat().join(' ') : ''
    super((problem.detail || problem.title || `HTTP ${status}`) + extra)
    this.status = status
    this.problem = problem
  }
}

async function request<T>(method: string, path: string, body?: unknown, baseUrl = API_URL, headers?: Record<string, string>): Promise<T> {
  const res = await fetch(`${baseUrl}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      'X-Actor': getActor(),
      ...headers,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  if (res.status === 204) return undefined as T
  const text = await res.text()
  const data = text ? JSON.parse(text) : undefined
  if (!res.ok) throw new ApiError(res.status, (data ?? {}) as ProblemDetails)
  return data as T
}

export const api = {
  get: <T>(path: string) => request<T>('GET', path),
  post: <T>(path: string, body?: unknown) => request<T>('POST', path, body ?? {}),
  put: <T>(path: string, body?: unknown) => request<T>('PUT', path, body ?? {}),
  del: <T>(path: string) => request<T>('DELETE', path),
}
