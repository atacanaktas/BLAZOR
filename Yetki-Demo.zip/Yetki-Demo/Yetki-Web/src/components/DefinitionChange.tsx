import { Alert, App, Button, Flex, Modal, Spin } from 'antd'
import { useEffect, useState } from 'react'
import type { DefinitionChangeResult } from '../api/types'
import { ImpactView } from './ImpactView'

/**
 * Tanım değişikliği (policy / permission): önce dryRun ile erişim etkisi + uyarılar gösterilir, onaylanırsa uygulanır.
 * run(true) = önizleme, run(false) = uygula.
 */
export function DefinitionChangeModal({ title, run, onClose, onDone, danger }: {
  title: string
  run: (dryRun: boolean, expectedModelVersion?: number) => Promise<DefinitionChangeResult | void>
  onClose: () => void
  onDone: (result?: DefinitionChangeResult | void) => void
  danger?: boolean
}) {
  const { message } = App.useApp()
  const [preview, setPreview] = useState<DefinitionChangeResult>()
  const [error, setError] = useState<string>()
  const [applying, setApplying] = useState(false)

  useEffect(() => {
    run(true).then((r) => setPreview(r ?? undefined)).catch((e: Error) => setError(e.message))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const apply = async () => {
    setApplying(true)
    try {
      const r = await run(false, preview?.impact.modelVersion)
      message.success(r?.impact?.summary ?? 'Uygulandı')
      onDone(r)
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setApplying(false)
    }
  }

  return (
    <Modal open width={1100} title={title} onCancel={onClose} destroyOnHidden
      footer={<Flex gap={8} justify="end">
        <Button onClick={onClose}>Vazgeç</Button>
        <Button type="primary" danger={danger || !!preview?.impact.users.some((u) => u.removedAccesses.length)} disabled={!preview || preview.impact.blocked} loading={applying} onClick={apply}>Onayla ve uygula</Button>
      </Flex>}>
      {error && <Alert type="error" showIcon message={error} />}
      {!preview && !error && <Spin />}
      {preview && (
        <Flex vertical gap={12}>
          {preview.warnings.length > 0 && <Alert type="warning" showIcon message="Uyarılar" description={preview.warnings.map((w, i) => <div key={i}>{w}</div>)} />}
          <ImpactView impact={preview.impact} />
        </Flex>
      )}
    </Modal>
  )
}
