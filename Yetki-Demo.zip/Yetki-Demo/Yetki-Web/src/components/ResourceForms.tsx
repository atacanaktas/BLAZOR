import { App, Button, Card, Col, Divider, Flex, Form, Input, InputNumber, Modal, Row, Select, Switch, Typography } from 'antd'
import { DeleteOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { api } from '../api/client'
import type { ChangeImpactResult, ResourceDetail, ResourceTypeView, Severity } from '../api/types'
import { invalidateOptions, toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { invalidateCatalogTree } from './Catalog'

export const severities: Severity[] = ['Low', 'Medium', 'High', 'Critical']
export const httpMethods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', '*']

/** Yeni resource formunun ön değerleri (ör. envanterden "Tanımla" veya permission ekranından). */
export interface ResourcePrefill {
  resourceTypeId?: number
  code?: string
  name?: string
  externalCode?: string
  parentId?: number
  scopeCodes?: string[]
  uris?: { method: string; pattern: string; scopeCode?: string }[]
}

/**
 * Resource oluştur / düzenle. Üç yerden açılır: yetki tanımları (Resources), permission formu ("yeni resource"),
 * kapsama raporu ("Tanımla"). Kaydedilen resource permission bağlanana kadar kapalıdır.
 */
export function ResourceModal({ applicationId, parentId, detail, prefill, onClose, onDone }: {
  applicationId: number; parentId?: number; detail?: ResourceDetail; prefill?: ResourcePrefill; onClose: () => void; onDone: (id?: number) => void
}) {
  const [form] = Form.useForm()
  const types = useApi<ResourceTypeView[]>('/api/resource-types').data ?? []
  const resources = useOptions('resources')
  const scopes = useOptions('scopes')
  const teams = useOptions('teams')
  const apps = useOptions('applications')
  const { message } = App.useApp()
  const appCode = apps.find((a) => a.value === applicationId)?.code
  const appScopes = scopes.filter((s) => s.group === appCode)
  const scopeId = (code?: string) => appScopes.find((s) => s.code === code)?.value
  const typeId = Form.useWatch('resourceTypeId', form) as number | undefined
  const type = types.find((t) => t.id === typeId)
  const [uris, setUris] = useState<{ method: string; pattern: string; scope?: number; scopeCode?: string }[]>(
    () => (prefill?.uris ?? []).map((u) => ({ method: u.method, pattern: u.pattern, scopeCode: u.scopeCode })))
  const selectedScopes = (Form.useWatch('scopeIds', form) as number[] | undefined) ?? []
  const r = detail?.resource
  // Ön değerlerdeki scope kodları seçenekler yüklenince id'ye çevrilir
  const [resolved, setResolved] = useState(false)
  if (!resolved && !r && prefill && appScopes.length > 0) {
    setResolved(true)
    const ids = (prefill.scopeCodes ?? []).map(scopeId).filter((x): x is number => !!x)
    if (ids.length) form.setFieldValue('scopeIds', ids)
    setUris((list) => list.map((u) => ({ ...u, scope: u.scope ?? scopeId(u.scopeCode) })))
  }
  const missingScopes = (prefill?.scopeCodes ?? []).filter((c) => !scopeId(c))

  const save = async () => {
    const v = await form.validateFields()
    const scopeList = (v.scopeIds as number[]).map((sid) => ({ scopeId: sid, riskLevel: detail?.scopes.find((s) => s.scopeId === sid)?.riskLevel ?? v.defaultRisk }))
    const body = { ...v, applicationId, scopes: scopeList, uris: uris.filter((u) => u.pattern && u.scope).map((u) => ({ method: u.method, pattern: u.pattern, scopeId: u.scope })) }
    try {
      if (r) {
        const res = await api.put<ChangeImpactResult>(`/api/resources/${r.id}`, body)
        message.success(res?.affectedUserCount ? `Güncellendi · ${res.summary}` : 'Güncellendi')
        onDone(r.id)
      } else {
        const res = await api.post<{ id: number; impact: ChangeImpactResult }>('/api/resources', body)
        message.success(res.impact?.affectedUserCount ? `Oluşturuldu · ${res.impact.summary}` : 'Oluşturuldu (permission bağlanana kadar erişim kapalı)')
        onDone(res.id)
      }
      invalidateOptions('resources', 'resource-scopes'); invalidateCatalogTree()
      onClose()
    } catch (e) { message.error((e as Error).message) }
  }
  return (
    <Modal open width={760} title={r ? `${r.code} düzenle` : `Yeni resource (${appCode ?? ''})`} onCancel={onClose} onOk={save} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={r
        ? { ...r, scopeIds: detail!.scopes.map((s) => s.scopeId), defaultRisk: 'Medium' }
        : { parentId: prefill?.parentId ?? parentId, resourceTypeId: prefill?.resourceTypeId, code: prefill?.code, name: prefill?.name, externalCode: prefill?.externalCode,
            isActive: true, order: 0, defaultRisk: 'Medium', scopeIds: [] }}>
        <Row gutter={12}>
          <Col span={24}><Divider titlePlacement="start" plain>1 · Resource kimliği</Divider></Col>
          <Col span={12}><Form.Item name="resourceTypeId" label="Resource tipi" rules={[{ required: true }]} extra={type?.description}>
            <Select options={types.filter((t) => t.isActive || t.id === r?.resourceTypeId).map((t) => ({ value: t.id, label: `${t.code} — ${t.name}${t.matchesHttp ? ' (HTTP)' : ''}` }))} />
          </Form.Item></Col>
          <Col span={12}><Form.Item name="code" label="Kod (kalıcı kimlik)" rules={[{ required: true }]} extra="ör. anka.vadelihesap — URI değişse de değişmez"><Input disabled={!!r} /></Form.Item></Col>
          <Col span={12}><Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item></Col>
          <Col span={12}><Form.Item name="externalCode" label="Uygulama kodu" extra="Uygulamanın kendi kodu (ör. ekran kodu GVADAG00). Envanter eşleştirmesi için; yetki kimliği değildir.">
            <Input placeholder="GVADAG00" />
          </Form.Item></Col>
          {type?.supportsHierarchy && <Col span={12}><Form.Item name="parentId" label="Üst resource" extra="Üst kapalıysa alt da kapalı görünür"><Select allowClear showSearch optionFilterProp="label" options={toSelectOptions(resources.filter((x) => x.group === appCode && x.value !== r?.id))} /></Form.Item></Col>}
          <Col span={24}><Divider titlePlacement="start" plain>2 · Sahiplik ve kapsam</Divider></Col>
          <Col span={12}><Form.Item name="ownerTeamId" label="Sahip ekip"><Select allowClear showSearch optionFilterProp="label" options={toSelectOptions(teams)} /></Form.Item></Col>
          <Col span={16}><Form.Item name="scopeIds" label="Scope'lar (bu resource üzerinde yapılabilen işlemler)" rules={[{ required: true, type: 'array', min: 1 }]}
            extra={missingScopes.length ? `Önerilen scope uygulamada yok: ${missingScopes.join(', ')} — uygulama panelinden ekleyebilir veya başka scope seçebilirsiniz.` : undefined}>
            <Select mode="multiple" optionFilterProp="label" options={toSelectOptions(appScopes)} />
          </Form.Item></Col>
          <Col span={8}><Form.Item name="defaultRisk" label="Yeni scope risk seviyesi"><Select options={severities.map((s) => ({ value: s, label: s }))} /></Form.Item></Col>
          <Col span={24}><Divider titlePlacement="start" plain>3 · Görünüm ve yaşam döngüsü</Divider></Col>
          <Col span={6}><Form.Item name="order" label="Sıra"><InputNumber style={{ width: '100%' }} /></Form.Item></Col>
          <Col span={6}><Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item></Col>
          <Col span={24}><Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item></Col>
        </Row>
      </Form>
      {!r && type?.matchesHttp && (
        <Card size="small" type="inner" title="URI eşlemeleri (sonradan da eklenebilir)" extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setUris([...uris, { method: 'GET', pattern: '' }])}>URI</Button>}>
          {uris.map((u, i) => (
            <Flex key={i} gap={6} style={{ marginBottom: 6 }}>
              <Select value={u.method} onChange={(v) => setUris(uris.map((x, j) => (j === i ? { ...x, method: v } : x)))} options={httpMethods.map((m) => ({ value: m, label: m }))} style={{ width: 100 }} />
              <Input value={u.pattern} placeholder="/v1/vadeli-hesap/{hesapNo}" onChange={(e) => setUris(uris.map((x, j) => (j === i ? { ...x, pattern: e.target.value } : x)))} />
              <Select value={u.scope} placeholder="scope" onChange={(v) => setUris(uris.map((x, j) => (j === i ? { ...x, scope: v } : x)))} style={{ width: 150 }}
                options={toSelectOptions(appScopes.filter((s) => selectedScopes.includes(s.value)))} />
              <Button icon={<DeleteOutlined />} onClick={() => setUris(uris.filter((_, j) => j !== i))} />
            </Flex>
          ))}
          {uris.length === 0 && <Typography.Text type="secondary">URI olmadan gateway istekleri bu resource'a eşlenmez.</Typography.Text>}
        </Card>
      )}
    </Modal>
  )
}

/** URI eşlemesi ekle / düzenle. prefill: envanterden gelen METHOD + path ve önerilen scope. */
export function UriModal({ resourceId, scopes, uri, prefill, onClose, onDone }: {
  resourceId: number; scopes: ResourceDetail['scopes']; uri?: ResourceDetail['uris'][number]
  prefill?: { method: string; pattern: string; scopeCode?: string }; onClose: () => void; onDone: () => void
}) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const save = async () => {
    const v = await form.validateFields()
    try {
      if (uri) await api.put(`/api/resource-uris/${uri.id}`, v)
      else await api.post(`/api/resources/${resourceId}/uris`, v)
      invalidateCatalogTree()
      onDone(); onClose()
    } catch (e) { message.error((e as Error).message) }
  }
  const initial = uri ?? (prefill
    ? { method: prefill.method, pattern: prefill.pattern, scopeId: scopes.find((s) => s.code === prefill.scopeCode)?.scopeId }
    : { method: 'GET' })
  return (
    <Modal open title={uri ? 'URI eşlemesi düzenle' : 'Yeni URI eşlemesi'} onCancel={onClose} onOk={save} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={initial}>
        <Form.Item name="method" label="HTTP metodu" rules={[{ required: true }]}><Select options={httpMethods.map((m) => ({ value: m, label: m === '*' ? '* (tümü)' : m }))} /></Form.Item>
        <Form.Item name="pattern" label="URI deseni" rules={[{ required: true }]} extra="{ad} veya * tek segment; sonda ** kalan tüm segmentler. Sorgu dizesi yok sayılır.">
          <Input placeholder="/v1/vadeli-hesap/{hesapNo}/kapat" />
        </Form.Item>
        <Form.Item name="scopeId" label="Eşlendiği scope" rules={[{ required: true }]}
          extra={prefill?.scopeCode && !scopes.some((s) => s.code === prefill.scopeCode) ? `Önerilen '${prefill.scopeCode}' bu resource'ta yok; resource'u düzenleyip scope ekleyebilir veya mevcut bir scope seçebilirsiniz.` : undefined}>
          <Select options={scopes.map((s) => ({ value: s.scopeId, label: `${s.code} (${s.key})` }))} />
        </Form.Item>
      </Form>
    </Modal>
  )
}

/** Uygulamanın scope sözlüğüne scope ekle / düzenle. */
export function ScopeModal({ applicationId, scope, onClose, onDone }: {
  applicationId: number; scope?: { id: number; code: string; name: string }; onClose: () => void; onDone: () => void
}) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const save = async () => {
    const v = await form.validateFields()
    try {
      if (scope) await api.put(`/api/scopes/${scope.id}`, { ...v, applicationId })
      else await api.post('/api/scopes', { ...v, applicationId })
      invalidateOptions('scopes'); onDone(); onClose()
    } catch (e) { message.error((e as Error).message) }
  }
  return (
    <Modal open title={scope ? `Scope: ${scope.code}` : 'Yeni scope'} onCancel={onClose} onOk={save} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={scope}>
        <Form.Item name="code" label="Kod" rules={[{ required: true }]} extra="Küçük harf: view, create, close, approve..."><Input disabled={!!scope} /></Form.Item>
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input placeholder="Kapat" /></Form.Item>
        <Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item>
      </Form>
    </Modal>
  )
}
