import { Flex, Radio, Select, TreeSelect, Typography } from 'antd'
import { useEffect, useMemo, useState } from 'react'
import { api } from '../api/client'
import type { CatalogTreeApp, CatalogTreeNode, TargetType } from '../api/types'
import { useOptions } from '../hooks/useApi'

let treePromise: Promise<CatalogTreeApp[]> | undefined

/** Esnek katalog ağacı. Catalog Level sayısı sınırsızdır; Application kullanımı isteğe bağlıdır. */
export function useCatalogTree(refresh = 0) {
  const [tree, setTree] = useState<CatalogTreeApp[]>([])
  useEffect(() => {
    if (refresh > 0 || !treePromise) treePromise = api.get<CatalogTreeApp[]>('/api/catalog/tree').catch(() => [])
    let cancelled = false
    treePromise.then((t) => !cancelled && setTree(t))
    return () => {
      cancelled = true
    }
  }, [refresh])
  return tree
}

export function invalidateCatalogTree() {
  treePromise = undefined
}

interface TreeOption { value: string; title: string; children: TreeOption[]; disabled?: boolean }

function toTreeData(node: CatalogTreeNode): TreeOption {
  return {
    value: `node:${node.id}`,
    title: `${node.code} — ${node.name} (Catalog Level${node.permissions ? `, ${node.permissions} permissions` : ''})`,
    children: node.children.map(toTreeData),
  }
}

export interface TargetValue {
  targetType: TargetType
  targetId?: number
}

/**
 * Policy hedefi / Client Allowed Permission seçici. Katalog düğümü seçilirse altındaki HER ŞEY kapsanır.
 * Tümü · Uygulama · Katalog düğümü · Permission.
 */
export function TargetPicker({ value, onChange, allowAll = true }: { value?: TargetValue; onChange: (v: TargetValue) => void; allowAll?: boolean }) {
  const tree = useCatalogTree()
  const permissions = useOptions('permissions')
  const [kind, setKind] = useState<'catalog' | 'permission' | 'all'>(value?.targetType === 'Permission' ? 'permission' : value?.targetType === 'All' ? 'all' : 'catalog')

  const treeData = useMemo(() => tree.map((a) => a.isTenantRoot ? ({
    value: `tenant:${a.tenantId}`,
    title: `${a.tenant} (Tenant)`,
    disabled: true,
    children: a.children.map(toTreeData),
  }) : ({
    value: `app:${a.id}`,
    title: `${a.code} — ${a.name} (Application, ${a.permissionCount} permissions)`,
    children: a.children.map(toTreeData),
  })), [tree])

  const treeValue = value?.targetType === 'Application' ? `app:${value.targetId}` : value?.targetType === 'CatalogNode' ? `node:${value.targetId}` : undefined

  return (
    <Flex vertical gap={8}>
      <Radio.Group
        value={kind}
        onChange={(e) => {
          setKind(e.target.value)
          if (e.target.value === 'all') onChange({ targetType: 'All' })
        }}
        options={[
          { value: 'catalog', label: 'Resource Catalog (Application / Catalog Level — inherited)' },
          { value: 'permission', label: 'Permission' },
          ...(allowAll ? [{ value: 'all', label: 'Tümü' }] : []),
        ]}
      />
      {kind === 'catalog' && (
        <TreeSelect
          showSearch
          treeNodeFilterProp="title"
          style={{ width: '100%' }}
          value={treeValue}
          placeholder="Application veya Resource seçin"
          treeData={treeData}
          listHeight={420}
          onChange={(v: string) => {
            const [t, id] = v.split(':')
            onChange({ targetType: t === 'app' ? 'Application' : 'CatalogNode', targetId: Number(id) })
          }}
        />
      )}
      {kind === 'permission' && (
        <Select
          showSearch
          optionFilterProp="label"
          value={value?.targetType === 'Permission' ? value.targetId : undefined}
          placeholder="Permission ara (kod veya ad)"
          options={permissions.map((p) => ({ value: p.value, label: p.label }))}
          onChange={(id) => onChange({ targetType: 'Permission', targetId: id })}
        />
      )}
      {kind === 'all' && <Typography.Text type="secondary">Tüm Resource Catalog (mevcut ve gelecekte eklenecek Application kayıtları dahil).</Typography.Text>}
    </Flex>
  )
}
