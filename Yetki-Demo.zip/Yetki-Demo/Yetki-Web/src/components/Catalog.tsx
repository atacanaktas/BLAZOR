import { useCallback, useEffect, useState } from 'react'
import { api } from '../api/client'
import type { CatalogTreeTenant } from '../api/types'

let treePromise: Promise<CatalogTreeTenant[]> | undefined
const appPromises = new Map<number, Promise<CatalogTreeTenant[]>>()

/** Yetki tanımları ağacı: Tenant → Uygulama (resource server) → resource listesi (gruplama istemcide: URL / üst-alt). */
export function useCatalogTree(refresh = 0) {
  const [tree, setTree] = useState<CatalogTreeTenant[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string>()
  useEffect(() => {
    if (refresh > 0 || !treePromise) treePromise = api.get<CatalogTreeTenant[]>('/api/resources/tree?includeResources=false')
    let cancelled = false
    // oxlint-disable-next-line react/set-state-in-effect -- yeni istek çevrimini kullanıcıya hemen gösterir
    setLoading(true)
    setError(undefined)
    treePromise.then((t) => !cancelled && setTree(t)).catch((e: Error) => !cancelled && setError(e.message)).finally(() => !cancelled && setLoading(false))
    return () => {
      cancelled = true
    }
  }, [refresh])

  const mergeApplication = useCallback((loaded: CatalogTreeTenant[]) => {
    const app = loaded.flatMap((tenant) => tenant.applications).at(0)
    if (!app) return
    setTree((current) => current.map((tenant) => ({
      ...tenant,
      applications: tenant.applications.map((item) => item.id === app.id ? { ...app, resourcesLoaded: true } : item),
    })))
  }, [])

  const loadApplication = useCallback(async (applicationId: number) => {
    let request = appPromises.get(applicationId)
    if (!request) {
      request = api.get<CatalogTreeTenant[]>(`/api/resources/tree?applicationId=${applicationId}`)
      appPromises.set(applicationId, request)
    }
    try { mergeApplication(await request) }
    catch (e) { appPromises.delete(applicationId); setError((e as Error).message); throw e }
  }, [mergeApplication])

  const loadAll = useCallback(async () => {
    setLoading(true)
    setError(undefined)
    try {
      const full = await api.get<CatalogTreeTenant[]>('/api/resources/tree')
      setTree(full.map((tenant) => ({ ...tenant, applications: tenant.applications.map((app) => ({ ...app, resourcesLoaded: true })) })))
    } catch (e) { setError((e as Error).message) }
    finally { setLoading(false) }
  }, [])

  return { tree, loading, error, loadApplication, loadAll }
}

export function invalidateCatalogTree() {
  treePromise = undefined
  appPromises.clear()
}
