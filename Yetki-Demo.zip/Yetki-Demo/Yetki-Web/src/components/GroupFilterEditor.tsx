import { Alert, Button, Card, Flex, Input, Segmented, Select, Tag, Typography } from 'antd'
import { DeleteOutlined, PlusOutlined } from '@ant-design/icons'
import type { GroupCriterionInfo, GroupFilterDraft } from '../api/types'
import { useApi, useOptions } from '../hooks/useApi'

/** Kuralın okunur hali: (ROLE∈{GISEAST} ∧ ORG_UNIT∈{101}) ∪ ... − (TITLE∈{Stajyer}) */
export function describeFilters(filters: GroupFilterDraft[]) {
  const part = (f: GroupFilterDraft) => '(' + f.criteria.map((c) => `${c.attribute}∈{${c.values.join(',')}}`).join(' ∧ ') + ')'
  const inc = filters.filter((f) => f.mode === 'Include').map(part).join(' ∪ ')
  const exc = filters.filter((f) => f.mode === 'Exclude').map((f) => ' − ' + part(f)).join('')
  return (inc || '(kural yok)') + exc
}

const unitTypes = ['HeadOffice', 'Department', 'Region', 'Branch']
const userKinds = ['Person', 'ServiceAccount']

/** KİM kartına özel kriter: adlı bir gruba üye olmak (grup içinde grup olmadığı için grup kuralında yoktur). */
export const groupCriterion: GroupCriterionInfo = { code: 'GROUP', name: 'Grup', description: 'Adlı bir grubun üyesi', valueSource: 'group' }

function ValueInput({ source, values, onChange }: { source?: GroupCriterionInfo['valueSource']; values: string[]; onChange: (v: string[]) => void }) {
  const roles = useOptions('roles')
  const units = useOptions('units')
  const tenants = useOptions('tenants')
  const users = useOptions('users')
  const groups = useOptions('groups')
  const opts =
    source === 'role' ? roles.map((o) => ({ value: o.code, label: o.label }))
      : source === 'orgUnit' ? units.map((o) => ({ value: o.code, label: `${o.label} (${o.group})` }))
        : source === 'tenant' ? tenants.map((o) => ({ value: o.code, label: o.label }))
          : source === 'user' ? users.map((o) => ({ value: o.code, label: o.label }))
            : source === 'group' ? groups.map((o) => ({ value: o.code, label: o.label }))
              : source === 'orgUnitType' ? unitTypes.map((v) => ({ value: v, label: v }))
                : source === 'userKind' ? userKinds.map((v) => ({ value: v, label: v }))
                  : undefined
  if (!opts)
    return <Select mode="tags" value={values} onChange={onChange} placeholder="Değer yazıp Enter" style={{ minWidth: 280, flex: 1 }} tokenSeparators={[',']} />
  return <Select mode="multiple" showSearch optionFilterProp="label" value={values} onChange={onChange} options={opts} placeholder="Değer seçin" style={{ minWidth: 280, flex: 1 }} />
}

/**
 * Kitle kuralı: satır içindeki kriterler VE, satırlar arası VEYA; Hariç satırı eşleşenleri çıkarır.
 * Grup kitle kuralı ile KİM kartı AYNI biçimdir (forCard: satır etiketi, Grup kriteri, rol = etkin rol notu).
 * Kriter davranışı backend'deki C# handler'lardadır (ROLE, ORG_UNIT, ORG_UNIT_TREE, TITLE, TENANT...).
 */
export function GroupFilterEditor({ value, onChange, forCard = false }: { value: GroupFilterDraft[]; onChange: (v: GroupFilterDraft[]) => void; forCard?: boolean }) {
  const loaded = useApi<GroupCriterionInfo[]>('/api/group-criteria').data ?? []
  const criteria = forCard
    ? [...loaded.map((c) => (c.code === 'ROLE' ? { ...c, description: 'Kullanıcının etkin rolü (doğrudan veya gruptan gelen)' } : c)), groupCriterion]
    : loaded
  const set = (i: number, f: GroupFilterDraft) => onChange(value.map((x, j) => (j === i ? f : x)))
  const rowName = forCard ? 'Satır' : 'Kural'

  return (
    <Flex vertical gap={8}>
      <Alert
        type={forCard ? 'info' : 'warning'}
        showIcon
        message={forCard ? 'KİM kartındaki ROLE etkin rolleri değerlendirir' : 'Grup kuralındaki ROLE doğrudan rol atamasını değerlendirir'}
        description={forCard
          ? 'Doğrudan kullanıcıya atanmış roller ve üye olduğu gruplardan kazandığı roller birlikte dikkate alınır.'
          : 'Bir kullanıcının başka bir gruptan kazandığı rol bu grubu tetiklemez. Böylece gruplar arasında örtük ve döngüsel üyelik oluşmaz.'}
      />
      {value.map((f, i) => (
        <Card
          key={i}
          size="small"
          style={{ borderColor: f.mode === 'Exclude' ? '#ffbb96' : '#adc6ff', background: f.mode === 'Exclude' ? '#fff7f0' : '#f7f9ff' }}
          title={
            <Flex gap={8} align="center">
              {i > 0 && f.mode === 'Include' && <Tag color="orange">VEYA</Tag>}
              <Tag color={f.mode === 'Exclude' ? 'volcano' : 'geekblue'}>{rowName} #{i + 1}</Tag>
              <Segmented size="small" value={f.mode} onChange={(m) => set(i, { ...f, mode: m as GroupFilterDraft['mode'] })}
                options={[{ value: 'Include', label: 'Dahil et' }, { value: 'Exclude', label: 'Hariç tut' }]} />
              {!forCard && <Input size="small" placeholder="Açıklama" value={f.description ?? ''} onChange={(e) => set(i, { ...f, description: e.target.value })} style={{ maxWidth: 320 }} />}
            </Flex>
          }
          extra={<Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={() => onChange(value.filter((_, j) => j !== i))} />}
        >
          <Flex vertical gap={6}>
            {f.criteria.map((c, k) => (
              <Flex key={k} gap={8} align="center">
                {k > 0 && <Tag color="blue">VE</Tag>}
                <Select
                  value={c.attribute}
                  style={{ width: 240 }}
                  options={criteria.map((x) => ({ value: x.code, label: `${x.name} (${x.code})`, title: x.description }))}
                  onChange={(a) => set(i, { ...f, criteria: f.criteria.map((y, z) => (z === k ? { attribute: a, values: [] } : y)) })}
                />
                <Typography.Text>∈</Typography.Text>
                <ValueInput
                  source={criteria.find((x) => x.code === c.attribute)?.valueSource}
                  values={c.values}
                  onChange={(vals) => set(i, { ...f, criteria: f.criteria.map((y, z) => (z === k ? { ...y, values: vals } : y)) })}
                />
                <Button size="small" type="text" icon={<DeleteOutlined />} onClick={() => set(i, { ...f, criteria: f.criteria.filter((_, z) => z !== k) })} />
              </Flex>
            ))}
            <Button size="small" icon={<PlusOutlined />} style={{ alignSelf: 'flex-start' }}
              onClick={() => set(i, { ...f, criteria: [...f.criteria, { attribute: 'ORG_UNIT', values: [] }] })}>Kriter ekle (VE)</Button>
          </Flex>
        </Card>
      ))}
      <Flex gap={8}>
        <Button icon={<PlusOutlined />} onClick={() => onChange([...value, { mode: 'Include', criteria: [{ attribute: 'ROLE', values: [] }] }])}>
          {forCard ? 'Satır ekle (VEYA)' : 'Dahil etme kuralı (VEYA)'}
        </Button>
        <Button icon={<PlusOutlined />} danger onClick={() => onChange([...value, { mode: 'Exclude', criteria: [{ attribute: 'TITLE', values: [] }] }])}>
          {forCard ? 'Hariç tutma satırı' : 'Hariç tutma kuralı'}
        </Button>
      </Flex>
      <Typography.Text type="secondary" style={{ fontSize: 12 }}>
        Formül: <Typography.Text code>{describeFilters(value)}</Typography.Text>
        {forCard ? ' · satır içi VE, satırlar arası VEYA, hariç satırı çıkarır' : ' · Üyeler = açık üyeler ∪ dahil kuralları − hariç kuralları'}
      </Typography.Text>
    </Flex>
  )
}
