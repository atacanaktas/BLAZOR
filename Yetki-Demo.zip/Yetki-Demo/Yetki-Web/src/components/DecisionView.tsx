import { Alert, Card, Descriptions, Flex, Steps, Table, Tag, Tooltip, Typography } from 'antd'
import type { AuthorizationDecision, ConditionTrace, PolicyEvaluation, RuleEvaluation, UsedAttribute } from '../api/types'
import { AlgorithmTag, Code, DecisionTag, ModeTag, RuleResultTag, SourceList, TriTag, fmt } from './common'

function Evidence({ items }: { items?: UsedAttribute[] }) {
  if (!items?.length) return <Typography.Text type="secondary">—</Typography.Text>
  return (
    <Flex vertical gap={2}>
      {items.map((e, i) => (
        <Typography.Text key={i} style={{ fontSize: 12 }} type={e.resolved ? undefined : 'danger'}>
          <Code>{e.attribute}</Code> = {e.resolved ? (e.value ?? '∅') : 'ÇÖZÜLEMEDİ'} <Typography.Text type="secondary">({e.source})</Typography.Text>
        </Typography.Text>
      ))}
    </Flex>
  )
}

function TraceTree({ t, depth = 0 }: { t: ConditionTrace; depth?: number }) {
  const label = t.kind === 'Predicate' ? t.conditionType : t.kind === 'Reference' ? t.expression : t.kind === 'AllOf' ? 'AND' : t.kind === 'AnyOf' ? 'OR' : 'NOT'
  return (
    <div style={{ marginLeft: depth * 16 }}>
      <TriTag value={t.value} /> <Code>{label}</Code>{' '}
      {(t.kind === 'Predicate' || (t.kind === 'Reference' && !t.children?.length)) && <Typography.Text style={{ fontSize: 12 }}>{t.message}</Typography.Text>}
      {t.kind === 'Reference' && !!t.children?.length && <Typography.Text type="secondary" style={{ fontSize: 12 }}>ortak koşul</Typography.Text>}
      {t.children?.map((c, i) => <TraceTree key={i} t={c} depth={depth + 1} />)}
    </div>
  )
}

const stepStatus = { Pass: 'finish', Fail: 'error', Info: 'process', Skip: 'wait' } as const

/** Motorun adım adları → hibrit modelin numaralı akışı (Tenant → Client → Resource → RBAC → Policy). */
export function stepTitle(step: string): string {
  if (step === 'Subject') return 'Kimlik (subject)'
  if (step === 'Tenant') return '1 · Tenant doğrulama'
  if (step === 'Client') return '2 · Client doğrulama'
  if (step === 'Resource') return '3 · Resource + Action'
  if (step === 'RBAC') return '4 · RBAC: User → Role / Group → Permission'
  if (step.startsWith('Policy')) return `5 · ${step}`
  if (step === 'Obligation') return 'Yükümlülük (PEP yerine getirir)'
  return step
}

function PolicyCard({ p }: { p: PolicyEvaluation }) {
  return (
    <Card
      size="small"
      style={p.mode === 'ReportOnly' ? { borderStyle: 'dashed' } : p.isDeciding ? { borderColor: '#cf1322' } : undefined}
      title={
        <Flex gap={6} align="center" wrap>
          <Code>{p.code}</Code> {p.name} <Typography.Text type="secondary">v{p.version}</Typography.Text>
          <ModeTag mode={p.mode} />
          {p.matchedBy && <Tooltip title="Policy bu isteğe bu hedef üzerinden uygulandı (katalog mirası)"><Tag color="geekblue">← {p.matchedBy}</Tag></Tooltip>}
          {p.tenant && <Tag>{p.tenant}</Tag>}
        </Flex>
      }
      extra={<Flex gap={4} align="center"><AlgorithmTag algorithm={p.algorithm} /> → <DecisionTag decision={p.result} /></Flex>}
    >
      <Table<RuleEvaluation>
        size="small"
        rowKey={(r) => `${r.ruleId}-${r.code}`}
        pagination={false}
        dataSource={p.rules}
        rowClassName={(r) => (r.isDeciding ? 'ant-table-row-selected' : '')}
        expandable={{ rowExpandable: (r) => !!r.condition, expandedRowRender: (r) => r.condition && <TraceTree t={r.condition} /> }}
        columns={[
          { title: '#', dataIndex: 'order', width: 50 },
          { title: 'Rule', render: (_, r) => <><Code>{r.code}</Code> {r.isDeciding && <Tag color="purple">KARAR</Tag>}{!r.isActive && <Tag>pasif</Tag>}<br /><Typography.Text type="secondary">{r.name}</Typography.Text></> },
          { title: 'Koşul (sağlanmalı)', render: (_, r) => <Tooltip title={r.message}><TriTag value={r.conditionValue} /> <Typography.Text style={{ fontSize: 12 }}>{r.expression}</Typography.Text></Tooltip> },
          { title: 'Rule sonucu', render: (_, r) => <><RuleResultTag result={r.result} />{r.reasonCode && r.result === 'Deny' && <div><Code>{r.reasonCode}</Code></div>}</>, width: 170 },
          { title: 'Kullanılan değerler', render: (_, r) => <Evidence items={r.evidence} /> },
        ]}
      />
    </Card>
  )
}

/**
 * Açıklanabilir karar: karar + neden → adım adım akış (subject, permission/endpoint, client, RBAC, policy'ler)
 * → uygulanan policy'ler (hangi hedef üzerinden) ve rule izleri → hariç tutulan / report-only policy'ler → kullanılan değerler.
 */
export function DecisionView({ decision: d }: { decision: AuthorizationDecision }) {
  const type = d.decision === 'Permit' ? 'success' : d.decision === 'Deny' ? 'error' : 'warning'
  const enforced = d.policies.filter((p) => p.mode === 'Enforce')
  const reportOnly = d.policies.filter((p) => p.mode === 'ReportOnly')
  return (
    <Flex vertical gap={12}>
      <Alert
        type={type}
        showIcon
        message={
          <Flex gap={8} align="center" wrap>
            <DecisionTag decision={d.decision} />
            <Code>{d.reasonCode}</Code>
            {d.decidingRule && <Typography.Text type="secondary">karar veren: {d.decidingPolicy} / {d.decidingRule}</Typography.Text>}
            {d.isSimulation && <Tag color="purple">SİMÜLASYON</Tag>}
          </Flex>
        }
        description={d.humanReadableReason}
      />
      {d.reportOnlyDenials.length > 0 && (
        <Alert type="info" showIcon message="ReportOnly policy'ler (kararı etkilemedi)" description={d.reportOnlyDenials.map((x) => <div key={x}>{x}</div>)} />
      )}

      <Card size="small" title="Karar akışı">
        <Steps
          direction="vertical"
          size="small"
          items={d.steps.map((s) => ({ title: <b>{stepTitle(s.step)}</b>, description: <Typography.Text style={{ fontSize: 12 }}>{s.detail}</Typography.Text>, status: stepStatus[s.outcome] }))}
        />
      </Card>

      <Descriptions size="small" bordered column={{ xs: 1, md: 2 }}>
        <Descriptions.Item label="Tenant">{d.tenant ? <Tag color="blue">{d.tenant}</Tag> : '—'}</Descriptions.Item>
        <Descriptions.Item label="Client (orijinal kanal)">{d.client ?? '—'}{d.clientAllowedPermission && <Typography.Text type="secondary"> · allowed: {d.clientAllowedPermission}</Typography.Text>}
        </Descriptions.Item>
        <Descriptions.Item label="Granted OAuth scope">{d.matchedScope ?? (d.grantedScopes?.length ? d.grantedScopes.join(' ') : '—')}</Descriptions.Item>
        {d.via?.length > 0 && <Descriptions.Item label="Intermediaries">{d.via.map((v) => <Tag key={v} color="purple">{v}</Tag>)}</Descriptions.Item>}
        <Descriptions.Item label="Kullanıcı">{d.userName ?? '—'}</Descriptions.Item>
        <Descriptions.Item label="Resource : Action">{d.catalogPath ? <><Code>{d.catalogPath}</Code> : <Tag color="geekblue">{d.action}</Tag></> : '—'}</Descriptions.Item>
        <Descriptions.Item label="Permission" span={2}><Code>{d.permission}</Code> {d.permissionName}</Descriptions.Item>
        {d.endpoint && <Descriptions.Item label="Endpoint">{d.endpoint}</Descriptions.Item>}
        {d.resource && <Descriptions.Item label="Kaynak">{d.resource}</Descriptions.Item>}
        <Descriptions.Item label="Decision ID"><Typography.Text copyable style={{ fontSize: 12 }}>{d.decisionId}</Typography.Text></Descriptions.Item>
        <Descriptions.Item label="Zaman / süre">{fmt(d.evaluatedAt)} · {d.durationMs} ms · model v{d.modelVersion}</Descriptions.Item>
        {d.missingAttributes.length > 0 && (
          <Descriptions.Item label="Eksik attribute" span={2}>{d.missingAttributes.map((k) => <Tag color="orange" key={k}>{k}</Tag>)}</Descriptions.Item>
        )}
      </Descriptions>

      {d.obligations?.length > 0 && (
        <Card size="small" title="Yükümlülükler — PEP (API/SDK) yerine getirmek zorunda; tanımıyorsa erişimi reddeder">
          {d.obligations.map((o, i) => (
            <div key={i}><Tag color="gold">⚑ {o.code}</Tag>{Object.entries(o.parameters).map(([k, v]) => <Tag key={k}>{k}={v}</Tag>)}
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>← {o.policy}</Typography.Text></div>
          ))}
        </Card>
      )}

      {d.permissionSources.length > 0 && (
        <Card size="small" title="RBAC: yetki nereden geliyor?"><SourceList sources={d.permissionSources} /></Card>
      )}

      {enforced.map((p) => <PolicyCard key={p.policyId} p={p} />)}
      {reportOnly.map((p) => <PolicyCard key={p.policyId} p={p} />)}

      {d.excludedPolicies.length > 0 && (
        <Card size="small" title="Hedefi eşleşip HARİÇ tutulan policy'ler">
          {d.excludedPolicies.map((x) => (
            <div key={x.code}><Code>{x.code}</Code> <Tag color="geekblue">← {x.matchedBy}</Tag> ama <Tag color="volcano">HARİÇ {x.excludedBy}</Tag></div>
          ))}
        </Card>
      )}

      {d.evidence.length > 0 && (
        <Card size="small" title="Değerlendirmede kullanılan tüm attribute'lar (audit'te hassas olanlar maskelenir)"><Evidence items={d.evidence} /></Card>
      )}

      <Card size="small" title="İstek bağlamı">
        <Flex wrap gap={4}>{Object.entries(d.context).map(([k, v]) => <Tag key={k}>{k}={v}</Tag>)}</Flex>
      </Card>
    </Flex>
  )
}
