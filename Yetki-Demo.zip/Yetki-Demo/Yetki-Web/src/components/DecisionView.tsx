import { Alert, Card, Descriptions, Flex, Steps, Tag, Tooltip, Typography } from 'antd'
import { DataTable as Table } from './DataTable'
import type { AuthorizationDecision, ConditionTrace, PermissionEvaluation, PolicyEvaluation, RuleEvaluation, UsedAttribute } from '../api/types'
import { AccessKey, Code, DecisionTag, LogicTag, ModeTag, RuleResultTag, StrategyTag, TriTag, fmt } from './common'

function Evidence({ items }: { items?: UsedAttribute[] }) {
  if (!items?.length) return <Typography.Text type="secondary">—</Typography.Text>
  return (
    <Flex vertical gap={2}>
      {items.map((e, i) => (
        <Typography.Text key={i} style={{ fontSize: 12 }} type={e.resolved ? undefined : 'danger'}>
          <Code>{e.attribute}</Code> = {e.resolved ? (e.value ?? '∅') : 'ÇÖZÜLEMEDİ'} <Typography.Text type="secondary">({e.source})</Typography.Text>
        </Typography.Text>
      ))}
    </Flex>
  )
}

function TraceTree({ t, depth = 0 }: { t: ConditionTrace; depth?: number }) {
  const label = t.kind === 'Predicate' ? t.conditionType : t.kind === 'Reference' ? t.expression : t.kind === 'AllOf' ? 'AND' : t.kind === 'AnyOf' ? 'OR' : 'NOT'
  return (
    <div style={{ marginLeft: depth * 16 }}>
      <TriTag value={t.value} /> <Code>{label}</Code>{' '}
      {(t.kind === 'Predicate' || t.kind === 'Reference') && <Typography.Text style={{ fontSize: 12 }}>{t.message}</Typography.Text>}
      {t.children?.map((c, i) => <TraceTree key={i} t={c} depth={depth + 1} />)}
    </div>
  )
}

const stepStatus = { Pass: 'finish', Fail: 'error', Info: 'process', Skip: 'wait' } as const

/** Motorun adım adları → Keycloak akışı (Subject → Tenant → Client → Resource → Permission → Policy). */
export function stepTitle(step: string): string {
  if (step === 'Caller') return '0 · Soran (motoru çağıran client)'
  if (step === 'Subject') return 'Kimlik (subject)'
  if (step === 'Tenant') return '1 · Tenant doğrulama'
  if (step === 'Client') return '2 · Client doğrulama'
  if (step === 'Resource') return '3 · İstek → resource : scope'
  if (step === 'Permission') return '4 · Uygulanan permission'
  if (step.startsWith('Permission ')) return `4 · ${step}`
  if (step === 'Obligation') return 'Yükümlülük (PEP yerine getirir)'
  return step
}

function RuleTable({ rules }: { rules: RuleEvaluation[] }) {
  return (
    <Table<RuleEvaluation>
      size="small"
      rowKey={(r) => `${r.ruleId}-${r.code}`}
      pagination={false}
      dataSource={rules}
      rowClassName={(r) => (r.isDeciding ? 'ant-table-row-selected' : '')}
      expandable={{ rowExpandable: (r) => !!r.condition, expandedRowRender: (r) => r.condition && <TraceTree t={r.condition} /> }}
      columns={[
        { title: 'Kural', render: (_, r) => <><Code>{r.code}</Code> {r.isDeciding && <Tag color="purple">KARAR</Tag>}{!r.isActive && <Tag>pasif</Tag>}<br /><Typography.Text type="secondary">{r.name}</Typography.Text></> },
        { title: 'Koşul', render: (_, r) => <Tooltip title={r.message}><TriTag value={r.conditionValue} /> <Typography.Text style={{ fontSize: 12 }}>{r.expression}</Typography.Text></Tooltip> },
        { title: 'Sonuç', render: (_, r) => <><RuleResultTag result={r.result} />{r.reasonCode && r.result === 'Deny' && <div><Code>{r.reasonCode}</Code></div>}</>, width: 150 },
        { title: 'Kullanılan değerler', render: (_, r) => <Evidence items={r.evidence} /> },
      ]}
    />
  )
}

/** Policy sonucu: kuralları (kartlar) ve HAZIR POLICY kartlarında kullanılan policy'lerin sonuçları. */
function PolicyNode({ p, depth = 0 }: { p: PolicyEvaluation; depth?: number }) {
  const muted = p.mode !== 'Enforce'
  return (
    <div style={{ marginLeft: depth * 18, padding: '6px 8px', borderLeft: `3px solid ${p.isDeciding ? '#cf1322' : muted ? '#d9d9d9' : '#91caff'}`, marginBottom: 6, background: muted ? '#fafafa' : undefined }}>
      <Flex gap={6} align="center" wrap>
        <Code>{p.code}</Code>
        <Typography.Text>{p.name}</Typography.Text>
        <LogicTag logic={p.logic} />
        {p.mode !== 'Enforce' && <ModeTag mode={p.mode} />}
        {p.rules.length > 1 && <StrategyTag strategy={p.strategy} />}
        <span>→</span><DecisionTag decision={p.result} />
        {p.isDeciding && <Tag color="purple">KARAR</Tag>}
      </Flex>
      <Typography.Text type="secondary" style={{ fontSize: 12 }}>{p.detail}</Typography.Text>
      {p.rules.length > 0 && <div style={{ marginTop: 6 }}><RuleTable rules={p.rules} /></div>}
      {p.children.map((c) => <PolicyNode key={c.policyId} p={c} depth={1} />)}
    </div>
  )
}

function PermissionCard({ e }: { e: PermissionEvaluation }) {
  return (
    <Card size="small" style={e.isDeciding && e.result !== 'Permit' ? { borderColor: '#cf1322' } : undefined}
      title={<Flex gap={6} align="center" wrap><Tag color="green">Permission</Tag><Code>{e.code}</Code> {e.name}</Flex>}
      extra={<Flex gap={4} align="center"><StrategyTag strategy={e.strategy} /> → <DecisionTag decision={e.result} /></Flex>}>
      {e.policies.length === 0 ? <Typography.Text type="danger">Policy yok → izin vermez</Typography.Text> : e.policies.map((p) => <PolicyNode key={p.policyId} p={p} />)}
    </Card>
  )
}

/**
 * Açıklanabilir karar: karar + neden → adım adım akış → isteğin eşlendiği resource:scope (HTTP ise URI deseni)
 * → uygulanan permission'lar ve policy ağaçları (aggregate / negatif / advisory dahil) → kullanılan değerler.
 */
export function DecisionView({ decision: d }: { decision: AuthorizationDecision }) {
  const type = d.decision === 'Permit' ? 'success' : d.decision === 'Deny' ? 'error' : 'warning'
  return (
    <Flex vertical gap={12}>
      <Alert
        type={type}
        showIcon
        message={
          <Flex gap={8} align="center" wrap>
            <DecisionTag decision={d.decision} />
            <Code>{d.reasonCode}</Code>
            {d.decidingPolicy && <Typography.Text type="secondary">karar veren: {d.decidingPermission} / {d.decidingPolicy}{d.decidingRule ? ` / ${d.decidingRule}` : ''}</Typography.Text>}
            {d.isSimulation && <Tag color="purple">SİMÜLASYON</Tag>}
          </Flex>
        }
        description={d.humanReadableReason}
      />
      {d.reportOnlyDenials.length > 0 && (
        <Alert type="info" showIcon message="ReportOnly policy'ler (kararı etkilemedi)" description={d.reportOnlyDenials.map((x) => <div key={x}>{x}</div>)} />
      )}

      <Card size="small" title="Karar akışı">
        <Steps
          direction="vertical"
          size="small"
          items={d.steps.map((s) => ({ title: <b>{stepTitle(s.step)}</b>, description: <Typography.Text style={{ fontSize: 12 }}>{s.detail}</Typography.Text>, status: stepStatus[s.outcome] }))}
        />
      </Card>

      <Descriptions size="small" bordered column={{ xs: 1, md: 2 }}>
        <Descriptions.Item label="Kullanıcı">{d.userName ?? '—'}</Descriptions.Item>
        <Descriptions.Item label="Tenant">{d.tenant ? <Tag color="blue">{d.tenant}</Tag> : '—'}</Descriptions.Item>
        <Descriptions.Item label="Soran (çağıran)">{d.caller ?? <Typography.Text type="secondary">yönetim konsolu (iç çağrı)</Typography.Text>}</Descriptions.Item>
        <Descriptions.Item label="Client (orijinal kanal)">{d.client ?? '—'}</Descriptions.Item>
        {d.via?.length > 0 && <Descriptions.Item label="Aracılar">{d.via.map((v) => <Tag key={v} color="purple">{v}</Tag>)}</Descriptions.Item>}
        {d.http && <Descriptions.Item label="HTTP isteği"><Code>{d.http}</Code></Descriptions.Item>}
        {d.matchedUri && <Descriptions.Item label="Eşlenen URI deseni"><Code>{d.matchedUri}</Code></Descriptions.Item>}
        <Descriptions.Item label="Access key (resource:scope)" span={2}>{(d.accessKey ?? d.permission) ? <><AccessKey value={(d.accessKey ?? d.permission)!} /> {d.permissionName}</> : '—'}</Descriptions.Item>
        <Descriptions.Item label="Resource tipi / uygulama">{d.resourceType ? <><Tag>{d.resourceType}</Tag>{d.application} · {d.catalogPath}</> : '—'}</Descriptions.Item>
        {d.resource && <Descriptions.Item label="Kayıt">{d.resource}</Descriptions.Item>}
        <Descriptions.Item label="Decision ID"><Typography.Text copyable style={{ fontSize: 12 }}>{d.decisionId}</Typography.Text></Descriptions.Item>
        <Descriptions.Item label="Zaman / süre">{fmt(d.evaluatedAt)} · {d.durationMs} ms · model v{d.modelVersion}</Descriptions.Item>
        {d.missingAttributes.length > 0 && (
          <Descriptions.Item label="Eksik değer (policy istiyor, istekte yok)" span={2}>{d.missingAttributes.map((k) => <Tag color="orange" key={k}>{k}</Tag>)}</Descriptions.Item>
        )}
      </Descriptions>

      {d.obligations?.length > 0 && (
        <Card size="small" title="Yükümlülükler — PEP (gateway / servis) yerine getirmek zorunda; tanımıyorsa erişimi reddeder">
          {d.obligations.map((o, i) => (
            <div key={i}><Tag color="gold">⚑ {o.code}</Tag>{Object.entries(o.parameters).map(([k, v]) => <Tag key={k}>{k}={v}</Tag>)}
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>← {o.policy}</Typography.Text></div>
          ))}
        </Card>
      )}

      {d.permissions.map((e) => <PermissionCard key={e.permissionId} e={e} />)}

      {d.evidence.length > 0 && (
        <Card size="small" title="Değerlendirmede kullanılan tüm attribute'lar (audit'te hassas olanlar maskelenir)"><Evidence items={d.evidence} /></Card>
      )}

      <Card size="small" title="İstek bağlamı">
        <Flex wrap gap={4}>{Object.entries(d.context).map(([k, v]) => <Tag key={k}>{k}={v}</Tag>)}</Flex>
      </Card>
    </Flex>
  )
}
