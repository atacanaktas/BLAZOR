import { Button, Empty, Input, Space, Table as AntTable } from 'antd'
import { FilterFilled, SearchOutlined } from '@ant-design/icons'
import { useMemo, type Key, type ReactNode } from 'react'
import type { TableProps } from 'antd'
import type { ColumnGroupType, ColumnType, ColumnsType, FilterDropdownProps } from 'antd/es/table/interface'

export interface DataTableProps<RecordType extends object> extends TableProps<RecordType> {
  emptyDescription?: ReactNode
  /** Yüklenmiş kayıtları dataIndex bulunan kolonlarda yerel olarak filtreler. */
  localColumnFiltering?: boolean
}

function readColumnValue(record: object, dataIndex: ColumnType<object>['dataIndex']) {
  const path = Array.isArray(dataIndex) ? dataIndex : [dataIndex]
  return path.reduce<unknown>((value, key) => (
    value != null && typeof value === 'object' ? (value as Record<PropertyKey, unknown>)[key as PropertyKey] : undefined
  ), record)
}

function searchableValue(value: unknown): string {
  if (Array.isArray(value)) return value.map(searchableValue).join(' ')
  if (value == null) return ''
  if (typeof value === 'object') return Object.values(value).map(searchableValue).join(' ')
  return String(value)
}

/**
 * Yetki yönetimi ekranlarının ortak tablo yüzeyi.
 * Sayfa yalnızca veri ve kolonları tanımlar; yoğunluk, pagination, empty state ve görsel dil burada yönetilir.
 */
export function DataTable<RecordType extends object>({
  className,
  locale,
  pagination,
  emptyDescription = 'Gösterilecek kayıt bulunamadı',
  localColumnFiltering = true,
  ...props
}: DataTableProps<RecordType>) {
  const mergedPagination = pagination === false ? false : {
    defaultPageSize: 10,
    hideOnSinglePage: true,
    showTotal: (total: number) => `${total.toLocaleString('tr-TR')} kayıt`,
    ...pagination,
    showSizeChanger: { showSearch: false },
    pageSizeOptions: ['10', '20', '50', '100'],
  }

  const columns = useMemo(() => {
    if (!localColumnFiltering || !props.columns) return props.columns

    const addLocalFilter = (column: ColumnType<RecordType> | ColumnGroupType<RecordType>): ColumnType<RecordType> | ColumnGroupType<RecordType> => {
      if ('children' in column && column.children) {
        return { ...column, children: column.children.map(addLocalFilter) as ColumnsType<RecordType> }
      }
      const leaf = column as ColumnType<RecordType>
      const alreadyFilterable = leaf.filters || leaf.filterDropdown || leaf.onFilter || leaf.filteredValue || leaf.defaultFilteredValue
      if (alreadyFilterable || leaf.dataIndex == null) return leaf

      return {
        ...leaf,
        ...textColumnFilter<RecordType>(
          (record) => searchableValue(readColumnValue(record, leaf.dataIndex as ColumnType<object>['dataIndex'])),
          `${typeof leaf.title === 'string' ? leaf.title : 'Kolon'} içinde ara`,
        ),
      }
    }

    return props.columns.map(addLocalFilter) as ColumnsType<RecordType>
  }, [localColumnFiltering, props.columns])

  return <AntTable<RecordType>
    {...props}
    columns={columns}
    className={['data-table', className].filter(Boolean).join(' ')}
    locale={{ emptyText: <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={emptyDescription} />, ...locale }}
    pagination={mergedPagination}
    showSorterTooltip={{ target: 'sorter-icon' }}
  />
}

/** Kolon başlığında standart metin arama filtresi. */
export function textColumnFilter<RecordType extends object>(
  value: (record: RecordType) => unknown,
  placeholder = 'Kolonda ara',
): Pick<ColumnType<RecordType>, 'filterDropdown' | 'filterIcon' | 'onFilter'> {
  return {
    filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }: FilterDropdownProps) => (
      <div className="data-table-filter" onKeyDown={(event) => event.stopPropagation()}>
        <Input autoFocus allowClear prefix={<SearchOutlined />} placeholder={placeholder} value={selectedKeys[0] as string}
          onChange={(event) => setSelectedKeys(event.target.value ? [event.target.value] : [])}
          onPressEnter={() => confirm()} />
        <Space>
          <Button type="primary" size="small" onClick={() => confirm()}>Uygula</Button>
          <Button size="small" onClick={() => { clearFilters?.(); confirm() }}>Temizle</Button>
        </Space>
      </div>
    ),
    filterIcon: (filtered: boolean) => <FilterFilled className={filtered ? 'is-filtered' : undefined} />,
    onFilter: (filterValue: boolean | Key, record: RecordType) => String(value(record) ?? '')
      .toLocaleLowerCase('tr-TR').includes(String(filterValue).toLocaleLowerCase('tr-TR')),
  }
}

/** Kolon başlığında standart seçenek filtresi. */
export function optionColumnFilter<RecordType extends object>(
  values: readonly string[],
  value: (record: RecordType) => unknown,
): Pick<ColumnType<RecordType>, 'filters' | 'filterSearch' | 'onFilter'> {
  return {
    filters: values.map((item) => ({ text: item, value: item })),
    filterSearch: values.length > 8,
    onFilter: (filterValue, record) => String(value(record) ?? '') === String(filterValue),
  }
}
