import { Alert, Button, Card, Empty, Flex, Segmented, Statistic, Tag, Tooltip, Typography } from 'antd'
import { DataTable as Table } from './DataTable'
import { DownloadOutlined } from '@ant-design/icons'
import { useCallback, useMemo, useState } from 'react'
import type { ChangeImpactResult, UserImpact } from '../api/types'
import { Code, EnforcementTag, SeverityTag } from './common'
import { downloadCsv } from './csv'
import { ExternalTag } from './External'
import { useManagedResultScroll, useReportDownload } from './ReportDownloadContext'

type ChangeKind = 'KAYBEDER' | 'KAZANIR' | 'KORUNUR'

interface FlatRow {
  key: string
  userId: number
  userName: string
  fullName: string
  permission: string
  permissionName: string
  change: ChangeKind
  before: string[]
  after: string[]
  external: string[]
}

const changeColor: Record<ChangeKind, string> = { KAYBEDER: 'red', KAZANIR: 'green', KORUNUR: 'blue' }
const changeLabel: Record<ChangeKind, string> = { KAYBEDER: 'Kaybeder', KAZANIR: 'Kazanır', KORUNUR: 'Korunur (başka kaynaktan)' }

function flatten(users: UserImpact[]): FlatRow[] {
  const rows: FlatRow[] = []
  for (const u of users) {
    // Neden metinleri "resource:scope ← kaynak" (revoke'ta "önceden: ...") biçiminde: yetkiye göre eşle
    const ext = (code: string, list: UserImpact['externalGrants']) =>
      list.filter((e) => e.reasons.some((r) => r.replace(/^önceden: /, '').startsWith(`${code} ←`)))
        .map((e) => `${e.system}:${e.code}${e.level ? ` ${e.previousLevel ? `${e.previousLevel}→` : ''}${e.level}` : ''}`)
    for (const p of u.removedAccesses)
      rows.push({ key: `${u.userId}-r-${p.key}`, userId: u.userId, userName: u.userName, fullName: u.fullName, permission: p.key, permissionName: p.name, change: 'KAYBEDER', before: p.sources, after: [], external: ext(p.key, u.externalRevokes) })
    for (const p of u.addedAccesses)
      rows.push({ key: `${u.userId}-a-${p.key}`, userId: u.userId, userName: u.userName, fullName: u.fullName, permission: p.key, permissionName: p.name, change: 'KAZANIR', before: [], after: p.sources, external: ext(p.key, u.externalGrants) })
    for (const p of u.retainedAccesses ?? [])
      rows.push({ key: `${u.userId}-k-${p.key}`, userId: u.userId, userName: u.userName, fullName: u.fullName, permission: p.key, permissionName: p.name, change: 'KORUNUR', before: p.before, after: p.after, external: [] })
  }
  return rows
}

const Paths = ({ paths }: { paths: string[] }) =>
  paths.length ? (
    <Flex vertical gap={2}>
      {paths.map((p) => <Typography.Text key={p} style={{ fontSize: 12 }}>{p}</Typography.Text>)}
    </Flex>
  ) : <Typography.Text type="secondary">—</Typography.Text>

/**
 * Bir değişikliğin (rol ataması, grup, policy, permission) erişime etkisi:
 *  - kim hangi yetkiyi KAYBEDER / KAZANIR / başka kaynaktan KORUR
 *  - kullanıcı bazlı, yetki bazlı ve detaylı liste görünümleri + CSV
 *  - SoD çakışmaları ve dış sistem (RACF/LDAP) gereksinimleri
 */
export function ImpactView({ impact }: { impact: ChangeImpactResult }) {
  const [view, setView] = useState<'user' | 'permission' | 'flat'>('flat')
  const rows = useMemo(() => flatten(impact.users), [impact])
  const activeView = rows.length === 0 && impact.users.length > 0 ? 'user' : view

  const byPermission = useMemo(() => {
    const map = new Map<string, { code: string; name: string; losers: string[]; gainers: string[]; retained: string[] }>()
    for (const r of rows) {
      const e = map.get(r.permission) ?? { code: r.permission, name: r.permissionName, losers: [], gainers: [], retained: [] }
      ;(r.change === 'KAYBEDER' ? e.losers : r.change === 'KAZANIR' ? e.gainers : e.retained).push(r.userName)
      map.set(r.permission, e)
    }
    return [...map.values()].sort((a, b) => a.code.localeCompare(b.code))
  }, [rows])

  const losers = new Set(rows.filter((r) => r.change === 'KAYBEDER').map((r) => r.userId)).size
  const gainers = new Set(rows.filter((r) => r.change === 'KAZANIR').map((r) => r.userId)).size
  const retained = rows.filter((r) => r.change === 'KORUNUR').length
  const roleChangedUsers = impact.users.filter((u) => u.addedRoles.length + u.removedRoles.length > 0).length
  const groupChangedUsers = impact.users.filter((u) => u.addedGroups.length + u.removedGroups.length > 0).length
  const externalActions = impact.users.reduce((n, u) => n + u.externalGrants.length + u.externalRevokes.length, 0)

  const exportCsv = useCallback(() => {
    const reportRows = impact.users.flatMap((u) => {
      const accessRows = rows.filter((r) => r.userId === u.userId)
      const roles = [...u.addedRoles.map((r) => `+${r}`), ...u.removedRoles.map((r) => `-${r}`)].join(' | ')
      const groups = [...u.addedGroups.map((g) => `+${g}`), ...u.removedGroups.map((g) => `-${g}`)].join(' | ')
      const base = [u.userName, u.fullName, roles, groups]

      if (accessRows.length === 0) return [[...base, '', '', '', '', '']]
      return accessRows.map((r) => [...base, r.permission, changeLabel[r.change], r.before.join(' | '), r.after.join(' | '), r.external.join(' | ')])
    })

    downloadCsv('yetki-etki-analizi.csv', [
      ['Kullanıcı', 'Ad Soyad', 'Role değişimi', 'Group değişimi', 'Yetki (resource:scope)', 'Yetki değişimi', 'Önceki kaynak', 'Sonraki kaynak', 'Dış sistem'],
      ...reportRows,
    ])
  }, [impact.users, rows])
  const { isManaged } = useReportDownload(exportCsv)
  useManagedResultScroll(isManaged, impact)

  return (
    <Flex vertical gap={12}>
      {!isManaged && <Alert
        type={impact.blocked ? 'error' : impact.warnings.length ? 'warning' : impact.applied ? 'success' : 'info'}
        showIcon
        message={impact.blocked ? 'SoD kuralı bu değişikliği ENGELLİYOR' : impact.applied ? 'Değişiklik uygulandı' : impact.dryRun ? 'Önizleme (henüz uygulanmadı)' : 'Sonuç'}
        description={impact.summary}
      />}
      {!isManaged && <Flex justify="flex-end">
        <Button icon={<DownloadOutlined />} onClick={exportCsv}>Raporu indir (CSV)</Button>
      </Flex>}

      <Card size="small" className="what-if-impact-metrics">
        <div className="what-if-impact-metrics-head">
          <span>IMPACT SNAPSHOT</span>
          {isManaged ? <Button type="primary" icon={<DownloadOutlined />} onClick={exportCsv}>Raporu indir</Button> : <strong>Etki özeti</strong>}
        </div>
        <div className="what-if-impact-metrics-grid">
          <Statistic className="is-scope" title="Değişiklik yaşayan kullanıcı" value={impact.users.length} />
          <Statistic className="is-scope" title="Effective access değişen" value={impact.affectedUserCount} />
          <Statistic className="is-loss" title="Yetki kaybeden kullanıcı" value={losers} />
          <Statistic className="is-gain" title="Yetki kazanan kullanıcı" value={gainers} />
          <Statistic className="is-group" title="Group üyeliği değişen" value={groupChangedUsers} />
          <Statistic className="is-role" title="Role ataması değişen" value={roleChangedUsers} />
          <Statistic className="is-retained" title="Başka kaynaktan korunan" value={retained} />
          <Statistic className="is-sod" title="Yeni SoD çakışması" value={impact.blockingConflicts.length + impact.warnings.length} />
          <Statistic className="is-external" title="Dış sistem aksiyonu" value={externalActions} />
        </div>
      </Card>

      {impact.blockingConflicts.length > 0 && (
        <Alert type="error" message="Engelleyici SoD çakışmaları"
          description={impact.blockingConflicts.map((c, i) => <div key={i}><b>{c.userName}</b>: {c.conflict.code} — {c.conflict.matchedMembers.map((m) => m.code).join(' + ')}</div>)} />
      )}
      {impact.warnings.length > 0 && (
        <Alert type="warning" message="SoD uyarıları (değişiklik uygulanabilir, ihlal kaydı açılır)"
          description={impact.warnings.map((c, i) => <div key={i}><b>{c.userName}</b>: {c.conflict.code} — {c.conflict.matchedMembers.map((m) => m.code).join(' + ')}</div>)} />
      )}

      {impact.users.length === 0 ? (
        <Empty description={`Kapsamdaki ${impact.evaluatedUserCount ?? 0} kullanıcının effective yetkilerinde değişiklik yok`} />
      ) : (
        <>
          <Flex justify="flex-start" wrap gap={8}>
            <Segmented value={activeView} onChange={(v) => setView(v as typeof view)}
              options={[
                { value: 'flat', label: 'Kim, hangi yetki', disabled: rows.length === 0 },
                { value: 'user', label: 'Kullanıcı bazlı' },
                { value: 'permission', label: 'Yetki bazlı', disabled: rows.length === 0 },
              ]} />
          </Flex>

          {activeView === 'flat' && (
            <Table<FlatRow>
              size="small"
              rowKey="key"
              dataSource={rows}
              pagination={rows.length > 10 ? {} : false}
              columns={[
                { title: 'Kullanıcı', render: (_, r) => <><b>{r.userName}</b><br /><Typography.Text type="secondary">{r.fullName}</Typography.Text></>, sorter: (a, b) => a.userName.localeCompare(b.userName) },
                { title: 'Yetki', render: (_, r) => <><Code>{r.permission}</Code><br /><Typography.Text type="secondary">{r.permissionName}</Typography.Text></>, sorter: (a, b) => a.permission.localeCompare(b.permission) },
                {
                  title: 'Değişim',
                  render: (_, r) => <Tag color={changeColor[r.change]}>{changeLabel[r.change]}</Tag>,
                  filters: (Object.keys(changeLabel) as ChangeKind[]).map((k) => ({ text: changeLabel[k], value: k })),
                  onFilter: (v, r) => r.change === v,
                },
                { title: 'Şu anki kaynak', render: (_, r) => <Paths paths={r.before} /> },
                { title: 'Değişiklik sonrası kaynak', render: (_, r) => <Paths paths={r.after} /> },
                { title: 'Dış sistem', render: (_, r) => r.external.map((e) => <Tag key={e} color={r.change === 'KAYBEDER' ? 'volcano' : 'cyan'}>{r.change === 'KAYBEDER' ? 'REVOKE' : 'GRANT'} {e}</Tag>) },
              ]}
            />
          )}

          {activeView === 'user' && (
            <Table<UserImpact>
              size="small"
              rowKey="userId"
              dataSource={impact.users}
              pagination={impact.users.length > 10 ? {} : false}
              columns={[
                { title: 'Kullanıcı', render: (_, u) => <><b>{u.userName}</b> <Tag>{u.tenant}</Tag><br /><Typography.Text type="secondary">{u.fullName}</Typography.Text></> },
                {
                  title: 'Yetki değişimi',
                  render: (_, u) => (
                    <Flex wrap gap={4}>
                      {u.removedAccesses.map((p) => <Tag key={'r' + p.key} color="red" title={p.sources.join('\n')}>− {p.key}</Tag>)}
                      {u.addedAccesses.map((p) => <Tag key={'a' + p.key} color="green" title={p.sources.join('\n')}>+ {p.key}</Tag>)}
                      {(u.retainedAccesses ?? []).map((p) => <Tag key={'k' + p.key} color="blue" title={'Sonraki kaynak:\n' + p.after.join('\n')}>= {p.key}</Tag>)}
                    </Flex>
                  ),
                },
                {
                  title: 'Rol / grup',
                  render: (_, u) => (
                    <Flex wrap gap={4}>
                      {[...u.addedRoles.map((r) => `+rol ${r}`), ...u.removedRoles.map((r) => `−rol ${r}`), ...u.addedGroups.map((g) => `+grup ${g}`), ...u.removedGroups.map((g) => `−grup ${g}`)].map((t) => <Tag key={t}>{t}</Tag>)}
                    </Flex>
                  ),
                },
                {
                  title: 'Dış sistem',
                  render: (_, u) => (
                    <Flex vertical gap={2}>
                      {u.externalGrants.map((e, i) => <Tooltip key={'g' + i} title={e.reasons.map((r, j) => <div key={j}>{r}</div>)}><span><Tag color={e.previousLevel ? 'gold' : 'cyan'}>{e.previousLevel ? 'MODIFY' : 'GRANT'}</Tag><ExternalTag system={e.system} code={e.code} resourceClass={e.resourceClass} level={e.level} previousLevel={e.previousLevel} /></span></Tooltip>)}
                      {u.externalRevokes.map((e, i) => <Tooltip key={'v' + i} title={e.reasons.map((r, j) => <div key={j}>{r}</div>)}><span><Tag color="volcano">REVOKE</Tag><ExternalTag system={e.system} code={e.code} resourceClass={e.resourceClass} /></span></Tooltip>)}
                    </Flex>
                  ),
                },
                {
                  title: 'Yeni SoD',
                  render: (_, u) => u.newSodConflicts.map((c) => <div key={c.code}><EnforcementTag enforcement={c.enforcement} /> <SeverityTag severity={c.severity} /> {c.code}</div>),
                },
              ]}
            />
          )}

          {activeView === 'permission' && (
            <Table
              size="small"
              rowKey="code"
              dataSource={byPermission}
              pagination={false}
              columns={[
                { title: 'Yetki', render: (_, p) => <><Code>{p.code}</Code><br /><Typography.Text type="secondary">{p.name}</Typography.Text></> },
                { title: 'Kaybeden kullanıcılar', render: (_, p) => <><Tag color="red">{p.losers.length}</Tag>{p.losers.join(', ')}</> },
                { title: 'Kazanan kullanıcılar', render: (_, p) => <><Tag color="green">{p.gainers.length}</Tag>{p.gainers.join(', ')}</> },
                { title: 'Korunan (başka kaynak)', render: (_, p) => <><Tag color="blue">{p.retained.length}</Tag>{p.retained.join(', ')}</> },
              ]}
            />
          )}
        </>
      )}
    </Flex>
  )
}
