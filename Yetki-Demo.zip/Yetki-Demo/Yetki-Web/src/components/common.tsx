import { Flex, Tag, Tooltip, Typography } from 'antd'
import {
  ApartmentOutlined,
  AppstoreOutlined,
  ClusterOutlined,
  GlobalOutlined,
  KeyOutlined,
  SafetyCertificateOutlined,
  TeamOutlined,
  UserOutlined,
} from '@ant-design/icons'
import type { ReactNode } from 'react'
import dayjs from 'dayjs'
import type { CombiningAlgorithm, DecisionType, InclusionMode, PermissionSource, PolicyMode, TargetType, TriState } from '../api/types'

export function PageHeader({ title, subtitle, extra }: { title: ReactNode; subtitle?: ReactNode; extra?: ReactNode }) {
  return (
    <Flex className="page-header" justify="space-between" align="center" gap={16} wrap>
      <div className="page-heading">
        <Typography.Title level={1}>{title}</Typography.Title>
        {subtitle && <div className="page-subtitle">{subtitle}</div>}
      </div>
      {extra && <div className="page-header-actions">{extra}</div>}
    </Flex>
  )
}

/** İkincil açıklamalar, asıl çalışma alanını kaplamadan erişilebilir kalır. */
export function PageGuide({ title = 'Bu sayfa nasıl çalışır?', children }: { title?: string; children: ReactNode }) {
  return <details className="page-guide"><summary>{title}</summary><div className="page-guide-content">{children}</div></details>
}

export function TagSummary({ values, limit = 2 }: { values: string[]; limit?: number }) {
  return <span className="tag-summary">{values.slice(0, limit).map((v) => <Tag key={v} title={v}>{v}</Tag>)}
    {values.length > limit && <Tooltip title={values.slice(limit).join(' · ')}><Tag tabIndex={0}>+{values.length - limit}</Tag></Tooltip>}
    {values.length === 0 && <span className="muted-dash">—</span>}
  </span>
}

export const Code = ({ children }: { children: ReactNode }) => (
  <Typography.Text code style={{ whiteSpace: 'nowrap' }}>{children}</Typography.Text>
)

export const fmt = (d?: string | null) => (d ? dayjs(d).format('DD.MM.YYYY HH:mm:ss') : '—')
export const fmtDate = (d?: string | null) => (d ? dayjs(d).format('DD.MM.YYYY') : '—')

export function ActiveTag({ active }: { active: boolean }) {
  return active ? <Tag color="green">Aktif</Tag> : <Tag>Pasif</Tag>
}

const decisionColor: Record<DecisionType, string> = { Permit: 'green', Deny: 'red', NotApplicable: 'default', Indeterminate: 'orange' }
const decisionLabel: Record<DecisionType, string> = { Permit: 'PERMIT', Deny: 'DENY', NotApplicable: 'NOT APPLICABLE', Indeterminate: 'INDETERMINATE' }

export function DecisionTag({ decision }: { decision?: string | null }) {
  if (!decision) return <Tag>—</Tag>
  const d = decision as DecisionType
  return <Tag color={decisionColor[d] ?? 'default'}>{decisionLabel[d] ?? decision}</Tag>
}

const triColor: Record<TriState, string> = { True: 'blue', False: 'default', Indeterminate: 'orange' }

export function TriTag({ value }: { value: TriState }) {
  return <Tag color={triColor[value]}>{value === 'True' ? 'TRUE' : value === 'False' ? 'FALSE' : 'BELİRSİZ'}</Tag>
}

/** Rule sonucu: Permit = sağlandı, Deny = sağlanmadı, Indeterminate = belirsiz, NotApplicable = pasif. */
export function RuleResultTag({ result }: { result: DecisionType | string }) {
  if (result === 'Permit') return <Tag color="green">SAĞLANDI</Tag>
  if (result === 'Deny') return <Tag color="red">SAĞLANMADI</Tag>
  if (result === 'Indeterminate') return <Tag color="orange">BELİRSİZ</Tag>
  return <Tag>PASİF</Tag>
}

export const algorithmLabel: Record<CombiningAlgorithm, string> = {
  AllRulesMustPass: 'Tüm rule\'lar sağlanmalı (AND)',
  AnyRuleMustPass: 'En az bir rule yeterli (OR)',
}

export const algorithmHelp: Record<CombiningAlgorithm, string> = {
  AllRulesMustPass: 'Bir rule sağlanmazsa Deny; biri belirsizse Indeterminate; hepsi sağlanırsa Permit.',
  AnyRuleMustPass: 'Bir rule sağlanırsa Permit; yoksa belirsizlik → Indeterminate; hiçbiri sağlanmazsa Deny.',
}

export function AlgorithmTag({ algorithm }: { algorithm: CombiningAlgorithm }) {
  return <Tag color="geekblue" title={algorithmHelp[algorithm]}>{algorithmLabel[algorithm] ?? algorithm}</Tag>
}

export function ModeTag({ mode }: { mode: PolicyMode }) {
  return mode === 'ReportOnly'
    ? <Tooltip title="Değerlendirilir ve kaydedilir ama kararı etkilemez (güvenli devreye alma)."><Tag color="purple">REPORT-ONLY</Tag></Tooltip>
    : <Tag color="blue">ENFORCE</Tag>
}

export function SeverityTag({ severity }: { severity: string }) {
  const color = { Critical: 'magenta', High: 'red', Medium: 'orange', Low: 'blue' }[severity] ?? 'default'
  return <Tag color={color}>{severity}</Tag>
}

export function EnforcementTag({ enforcement }: { enforcement: string }) {
  return enforcement === 'Block' ? <Tag color="red">ENGELLE</Tag> : <Tag color="gold">UYAR</Tag>
}

export function TenantTag({ tenant }: { tenant?: string }) {
  if (!tenant) return null
  return <Tag color={tenant === 'ABANK' ? 'blue' : 'cyan'} icon={<GlobalOutlined />}>{tenant}</Tag>
}

const targetIcon: Record<TargetType, ReactNode> = {
  All: <GlobalOutlined />,
  Application: <AppstoreOutlined />,
  CatalogNode: <ClusterOutlined />,
  Permission: <KeyOutlined />,
}

/** Policy hedefi / Client Allowed Permission: "Düğüm ANKA/NAKIT" (Include) veya "HARİÇ ..." (Exclude). */
export function TargetTag({ type, description, mode = 'Include', actions, closable, onClose }: {
  type: TargetType; description: string; mode?: InclusionMode; actions?: string; closable?: boolean; onClose?: () => void
}) {
  return (
    <Tag color={mode === 'Exclude' ? 'volcano' : 'geekblue'} icon={targetIcon[type]} closable={closable} onClose={(e) => { e.preventDefault(); onClose?.() }}>
      {mode === 'Exclude' ? 'HARİÇ ' : ''}{description}{actions ? ` [${actions}]` : ''}
    </Tag>
  )
}

const sourceMeta: Record<string, { icon: ReactNode; color: string; label: string }> = {
  DirectRole: { icon: <SafetyCertificateOutlined />, color: 'blue', label: 'Doğrudan rol' },
  GroupRole: { icon: <TeamOutlined />, color: 'purple', label: 'Grup → rol' },
  GroupPermission: { icon: <ApartmentOutlined />, color: 'geekblue', label: 'Grup → permission' },
  DirectPermission: { icon: <UserOutlined />, color: 'orange', label: 'Doğrudan (legacy)' },
}

/** Permission'ın kaynağı: "Bu kullanıcı bu yetkiyi neden aldı?" */
export function SourceList({ sources }: { sources: PermissionSource[] }) {
  return (
    <Flex vertical gap={4}>
      {sources.map((s, i) => {
        const m = sourceMeta[s.type] ?? { icon: <KeyOutlined />, color: 'default', label: s.type }
        return (
          <div key={i}>
            <Tooltip title={m.label}><Tag color={m.color} icon={m.icon}>{m.label}</Tag></Tooltip>
            <Typography.Text style={{ fontSize: 13 }}>{s.path}</Typography.Text>
          </div>
        )
      })}
    </Flex>
  )
}

export const riskOrder: Record<string, number> = { Low: 1, Medium: 2, High: 3, Critical: 4 }
