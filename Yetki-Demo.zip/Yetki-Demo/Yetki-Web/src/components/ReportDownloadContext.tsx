import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'

type ReportAction = () => void

interface ReportDownloadState {
  reportAction?: ReportAction
  register: (action?: ReportAction) => void
}

const ReportDownloadContext = createContext<ReportDownloadState | null>(null)

export function ReportDownloadProvider({ children }: { children: (reportAction?: ReportAction) => ReactNode }) {
  const [reportAction, setReportAction] = useState<ReportAction>()
  const register = useCallback((action?: ReportAction) => setReportAction(() => action), [])

  return <ReportDownloadContext.Provider value={{ reportAction, register }}>{children(reportAction)}</ReportDownloadContext.Provider>
}

/** Rapor aksiyonunu sayfanın ortak başlığına taşıyan ekranlarda indirme işlevini kaydeder. */
export function useReportDownload(action?: ReportAction) {
  const state = useContext(ReportDownloadContext)
  const register = state?.register

  useEffect(() => {
    if (!register) return
    register(action)
    return () => register(undefined)
  }, [action, register])

  return { isManaged: state !== null }
}

/** Simülasyon sonucunu oluşturulduğu anda görünür alana getirir. */
export function useManagedResultScroll(isManaged: boolean, trigger: unknown) {
  useEffect(() => {
    if (!isManaged || trigger === undefined || trigger === null) return
    const frame = requestAnimationFrame(() => {
      const panel = document.querySelector('.change-simulation-workbench .what-if-result-panel')
      const header = document.querySelector('.workspace-header')
      const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
      if (!panel) return
      const headerHeight = header?.getBoundingClientRect().height ?? 0
      const top = panel.getBoundingClientRect().top + window.scrollY - headerHeight - 16
      window.scrollTo({ top: Math.max(0, top), behavior: reduceMotion ? 'auto' : 'smooth' })
    })
    return () => cancelAnimationFrame(frame)
  }, [isManaged, trigger])
}
