# All-in-One Structure Explorer

Route: `/all-in-one`. The explorer replaces the full graph with progressive navigation:

`Tenant → Platform → Domain → Module → Submodule → API / Screen → Endpoint / UI Element → Permission → Policy → Rule`

The actual hierarchy is respected: existing Nextral Screens may belong directly to a Module. Empty Submodule levels are not fabricated. Platform is the display name of an existing Application; no database entity was renamed.

- Each request loads a single level through `GET /api/structure/explore`. Catalog filtering, counting and pagination run in SQL. World renders 6 primary records per page; Cards/List render 12; the API allows at most 48.
- Search applies to the current relation. Breadcrumbs, selected Tenant, relation, query and page survive reloads and browser back/forward via URL state. Cards and list layouts share the same bounded response.
- Tenant Platforms include inherited Applications. Client definitions are a separate relation. The Tenant campus additionally fetches at most 3 Clients and 3 Users. Users belong to the selected Tenant only. Complete personnel and Role lists are never sent to the browser.
- API and UI paths branch independently. Endpoint/UI cards expose their direct Permission mapping. UI parent checks still apply when no direct mapping exists; unmapped Endpoints remain fail-closed.
- Permission Policies use the existing engine's Tenant and target matching, with exclusions shown separately. Client-specific targeting and runtime conditions are explicitly distinguished from a final authorization decision. Rules show their compiled condition expressions.
- Related Roles are paged on demand; Rule/Role details open in a drawer. Advanced assignments and Policy editing link to their existing management screens.
- Contextual creation supports Tenant, Platform, Client, Domain/Module/Submodule, API, Endpoint, Screen/UI Element and Permission. Parents are fixed from the current context rather than loading a global catalog picker.
- Rename updates preserve codes and relationships. Permission mapping updates preserve Endpoint/UI metadata and write audit/outbox events. The mapping picker searches paged Tenant-accessible Permissions, including cross-platform mappings such as Nextral → ANKA.
- API, Endpoint and Permission external dependencies use the existing impact-preview workflow.

The API's Policy/Rule lookup still uses the existing cached authorization model, which contains personnel/assignment data on the server. This change bounds browser payload and catalog queries; it does not solve the engine's separate 20K-user model-partitioning work. No production-scale concurrency benchmark is claimed.

Halkbank blue (`#005092`), grey backgrounds, keyboard-operable cards and reduced-motion support are retained. Data refreshes on navigation, explicit refresh and saved changes; there is no live subscription.

## Access City / World

World is the default view. Native SVG landmarks represent real records: Tenant plazas, Client server racks, Resource books, User genies, UI monitors, Endpoint gates, Permission keys and Policy shields. Platform libraries and server/user districts surround the selected Tenant. Clicking a landmark moves the camera into its related level; the central landmark opens a management drawer with existing contextual actions. User, Role and Rule landmarks open their details.

Drag to pan, zoom, reset and fullscreen controls are available. The path strip replays the selected relationship path and supports returning to previous levels. Moving roads and path replay are schematic relationships, not live requests or an authorization decision. Motion can be disabled and respects the OS reduced-motion preference. Landmarks support keyboard activation. Cards and List remain available for dense browsing and precise text search.

The campus loads only bounded previews (6 Platforms, 3 Clients, 3 Users); district tabs expose paginated results. These are previews rather than a complete network diagram. No database hierarchy or existing management mutation semantics changed for this view.
## All-in-One V2 / Access in motion

Route `/all-in-one-v2` now uses `AccessFlowPage`. V1 remains unchanged. The previous tree implementation remains in source for comparison but is not routed.

The initial animated SVG is an illustrative User -> Role/Group -> Permission -> Resource flow, with a Policy -> Rule branch. It fetches no entity catalog. Task buttons and landmarks open server-paged search (12 records), using `/api/structure/flow/search` for User, Role, Permission and Policy.

Selecting a User loads current effective assignments from the same `GetEffective` model used by the engine. The scene shows four Permission paths per page, their Resource/action and bounded assignment-source summaries. Search filters the paths. Effective Roles have a separate paged picker. Selecting a Role shows its Permission assignments; selecting a Permission focuses its Resource path. Permission gates open paged existing explorer relations including Policies, excluded Policies, Roles, Endpoints, UI and External Dependencies. Policy inspection shows Rules and links to the established Condition editor.

Role Permission assignment and adding an Include Permission target to an existing Policy reuse ConfirmChangeModal / PolicyChangeModal, including their impact preview and explicit apply actions. Opening or exploring the scene never mutates records. The Policy editor remains the place to create Policies and edit Condition trees.

These are static assignment paths, not runtime authorization decisions. Client scope, Tenant validation, conditions and subject activity still matter at request time. Inactive subjects are labelled. Policy listings use the selected subject Tenant for inheritance; they do not imply all Client-specific Policies apply to every request.

Payloads are bounded (search 12, flow 4, related records 8, source summaries 4). The backend still uses the preexisting full cached authorization model: this is not a 20K-user backend scalability fix. Search-selected User flows were compared across every page with existing effective-permission responses. Browser checks cover focus, Roles, Permission inspection, Policy selection, change-preview modals and mobile overflow without applying mutations.


### Embedded interactions

Permission, Policy and User detail drawers have been replaced with inline branches inside the scene (`InlineFlowDetails`). Single-click expands relationships; multiple Permission branches remain open. Policy cards expand their Rules, and Rule cards reveal Condition expressions in place. Each branch owns its relation, pagination and close control. User Roles are rendered in the scene as well. Related records load four per page (effective User Roles: twelve).

Scene landmarks and inline cards expose right-click menus; inline branch headers and ellipsis buttons expose management actions. Search and selection use centered modals. Assignment/Policy mutations retain their existing impact-preview modals; advanced Condition editing links to the Policy editor. No authorization semantics or backend endpoints changed in this interaction update.

## All-in-One V3 / Persistent city map

`/all-in-one-v3` is separate from V1 and V2. The SVG camera contains a persistent expansion tree using the original WorldObject illustrations. Opening a record reveals relation collections; opening a collection appends paged landmarks beneath it. Ancestors and siblings remain in the map. Explicit collapse hides descendants without deleting their expansion state. Repeated records in the same ancestry become references. Expansion state resets on page reload.

Grey directional arrows describe catalog relationships, and blue arrows identify Permission/Policy/Rule relationships. The request-check guide shows the engine sequence but is not a simulated evaluation. User Roles, Groups and effective Permissions represent alternative/combined RBAC sources, not a sequential role-then-group fallback. Group Permission expansion combines its direct Permission definitions and Role Permission definitions; it is not a per-request Permit.

Initial Tenant and catalog pages contain at most 3 records. Load more appends without discarding existing nodes. Permission-flow pages contain 4; User Roles/Groups use existing 12-record paging. Scoped search adds selected records to the owning branch. Global search adds selected User/Role/Permission/Policy landmarks to the workspace. Auto-fit follows expansion until manual zoom/pan, and Fit all restores it. A large fully expanded map requires zooming for legible labels.

Right-click and ellipsis menus expose expansion, collapse, scoped search, contextual creation and management. Rename and mapping reuse existing forms; advanced assignments and deletion remain in existing management pages. Policy Rules open their expression in a modal. Structural links are derived data, not arbitrary editable edges. V1/V2 routes remain unchanged.

Verification covered retained ancestors/sibling Tenant, collapse/reopen state, User Group equivalence to the engine, Group Permission paging, Permission -> Policy -> Rule traversal, management menus and mobile overflow. Backend full-model caching remains the known scaling limitation; no production load benchmark was performed.
