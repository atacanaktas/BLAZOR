import { useEffect, useState } from 'react'
import { Alert, Button, Dropdown, Empty, Pagination, Skeleton, Tag } from 'antd'
import { MoreOutlined, CloseOutlined } from '@ant-design/icons'
import { Link } from 'react-router-dom'
import { api } from '../../api/client'
import { WorldObject } from './WorldObjects'
import { managementLink, type ExplorerItem, type ExplorerPage } from './explorer'

export type FlowEntry = { kind: string; id: number; code: string; name: string; tenantId: number }
interface Props { item: FlowEntry; revision: number; onClose: () => void; onAttach: (item: FlowEntry) => void; onGrant: (item: FlowEntry) => void; onFocus: (item: FlowEntry) => void; sources?: string[] }
export function InlineFlowDetails({ item, revision, onClose, onAttach, onGrant, onFocus, sources }: Props) {
  const [relation, setRelation] = useState('')
  const [page, setPage] = useState(1)
  const [retry, setRetry] = useState(0)
  const [children, setChildren] = useState<ExplorerItem[]>([])
  const [rules, setRules] = useState<number[]>([])
  const [response, setResponse] = useState<{ key: string; data?: ExplorerPage; error?: string }>()
  const key = item.kind === 'user'
    ? `/api/structure/flow/user/${item.id}?relation=roles&page=${page}&revision=${revision}&retry=${retry}`
    : `/api/structure/explore?kind=${item.kind}&id=${item.id}&tenantId=${item.tenantId}&pageSize=4&page=${page}${relation ? `&relation=${relation}` : ''}&revision=${revision}&retry=${retry}`
  useEffect(() => {
    let active = true
    api.get<ExplorerPage>(key).then(value => {
      const data = item.kind === 'user' ? { ...value, relation: 'roles', pageSize: 12, relations: [{ key: 'roles', label: 'Effective Roles', count: value.total }] } : value
      if (active) setResponse({ key, data })
    }).catch(e => { if (active) setResponse({ key, error: e.message }) })
    return () => { active = false }
  }, [key, item.kind])
  const data = response?.key === key ? response.data : undefined
  const failure = response?.key === key ? response.error : undefined
  const open = (node: ExplorerItem) => {
    if (node.kind === 'rule') { setRules(ids => ids.includes(node.id) ? ids.filter(id => id !== node.id) : [...ids, node.id]); return }
    if (node.kind === 'role') { onFocus({ ...node, tenantId: item.tenantId }); return }
    setChildren(previous => previous.some(x => x.kind === node.kind && x.id === node.id) ? previous : [...previous, node])
  }
  const actions = (node: FlowEntry) => [
    ...(node.kind === 'permission' ? [{ key: 'attach', label: 'Attach existing Policy', onClick: () => onAttach(node) }] : []),
    ...(node.kind === 'role' ? [{ key: 'grant', label: 'Assign Permission', onClick: () => onGrant(node) }] : []),
    { key: 'manage', label: <Link to={managementLink(node as ExplorerItem)}>{node.kind === 'policy' || node.kind === 'rule' ? 'Edit Rules / Conditions' : 'Open management'}</Link> },
  ]
  return <section className="af-inline-branch" data-branch={`${item.kind}:${item.id}`} aria-label={`${item.name} connections`}>
    <div className="af-inline-connector">↓</div>
    <Dropdown trigger={['contextMenu']} menu={{ items: actions(item) }}><header className="af-inline-header"><svg viewBox="-90 -190 180 240" aria-hidden="true"><WorldObject kind={item.kind as 'permission'} scale={.8} /></svg><div><Tag>{item.kind}</Tag><h3>{item.name}</h3><code>{item.code}</code></div><Dropdown trigger={['click']} menu={{ items: actions(item) }}><Button aria-label={`Actions for ${item.code}`} icon={<MoreOutlined />} /></Dropdown><Button aria-label={`Close branch ${item.code}`} icon={<CloseOutlined />} onClick={onClose} /></header></Dropdown>
    {sources?.length ? <details className="af-inline-sources"><summary>Assignment sources ({sources.length} shown)</summary>{sources.map((source, i) => <p key={i}>{source}</p>)}</details> : null}
    {failure ? <Alert type="error" title={failure} action={<Button onClick={() => setRetry(x => x + 1)}>Retry</Button>} /> : !data ? <Skeleton active paragraph={{ rows: 2 }} /> : <>
      <div className="af-inline-relations" role="tablist" aria-label={`${item.code} relations`}>{data.relations.map(r => <button key={r.key} role="tab" aria-selected={data.relation === r.key} onClick={() => { setRelation(r.key); setPage(1) }}>{r.label}<b>{r.count}</b></button>)}</div>
      {data.notice && <p className="af-note">{data.notice}</p>}
      <div className="af-inline-nodes">{data.items.map(node => <Dropdown key={`${node.kind}:${node.id}`} trigger={['contextMenu']} menu={{ items: actions({ ...node, tenantId: item.tenantId }) }}><article className="af-inline-node">
        <button className="af-inline-node-main" aria-label={`Expand ${node.kind} ${node.code}`} onClick={() => open(node)}><svg viewBox="-90 -190 180 240" aria-hidden="true"><WorldObject kind={node.kind} scale={.75} /></svg><strong>{node.name}</strong><code>{node.code}</code><small>{node.kind === 'rule' ? 'Show Condition' : node.kind === 'role' ? 'Explore Permission paths' : 'Expand connections'} ↓</small></button>
        <Dropdown trigger={['click']} menu={{ items: actions({ ...node, tenantId: item.tenantId }) }}><Button className="af-inline-node-menu" aria-label={`Actions for ${node.code}`} icon={<MoreOutlined />} /></Dropdown>
        {node.annotation && <p>{node.annotation}</p>}
        {node.kind === 'rule' && rules.includes(node.id) && <div className="af-inline-condition"><Tag>Condition</Tag><pre>{node.description ?? 'No Condition defined'}</pre><Link to={`/policies/${item.id}`}>Edit Condition</Link></div>}
      </article></Dropdown>)}</div>
      {!data.items.length && <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="No records in this relation" />}
      {data.total > data.pageSize && <Pagination size="small" current={data.page} total={data.total} pageSize={data.pageSize} showSizeChanger={false} onChange={setPage} />}
    </>}
    {children.map(child => <InlineFlowDetails key={`${child.kind}:${child.id}`} item={{ ...child, tenantId: item.tenantId }} revision={revision} onClose={() => setChildren(previous => previous.filter(x => !(x.kind === child.kind && x.id === child.id)))} onAttach={onAttach} onGrant={onGrant} onFocus={onFocus} />)}
  </section>
}
