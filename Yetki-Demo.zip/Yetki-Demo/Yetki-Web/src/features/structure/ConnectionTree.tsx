﻿import { useEffect, useState } from 'react'
import { Alert, Button, Dropdown, Empty, Pagination, Skeleton } from 'antd'
import { MoreOutlined, PlusOutlined, SearchOutlined } from '@ant-design/icons'
import { api } from '../../api/client'
import { WorldObject } from './WorldObjects'
import { createKinds, explorerLabels, type ExplorerItem, type ExplorerKind, type ExplorerPage } from './explorer'

export type TreeDistrict = ExplorerPage['relations'][number]
const districtKinds: Record<string, ExplorerKind> = { tenants: 'tenant', platforms: 'application', clients: 'client', users: 'user', resources: 'resource', apis: 'api', ui: 'ui', permissions: 'permission', policies: 'policy', excluded: 'policy', rules: 'rule', roles: 'role', endpoints: 'endpoint', external: 'externalPermission' }
export interface TreeSearch {
  owner?: ExplorerItem; tenantId?: number; district: TreeDistrict; expanded: boolean;
  reveal: (item: ExplorerItem) => void;
}
interface Actions {
  revision: number;
  onSearch: (search: TreeSearch) => void;
  onDetail: (item: ExplorerItem, tenantId?: number) => void;
  onAdd: (kind: ExplorerKind, owner?: ExplorerItem) => void;
}
function useBranch(url: string, enabled: boolean) {
  const [retry, setRetry] = useState(0)
  const [result, setResult] = useState<{ key: string; data?: ExplorerPage; error?: string }>()
  const key = `${url}&retry=${retry}`
  useEffect(() => {
    if (!enabled) return
    let active = true
    api.get<ExplorerPage>(key).then(data => { if (active) setResult({ key, data }) }).catch(e => { if (active) setResult({ key, error: e.message }) })
    return () => { active = false }
  }, [key, enabled])
  return { ...(result?.key === key ? result : { data: result?.data, error: undefined }), retry: () => setRetry(x => x + 1) }
}
const base = (owner?: ExplorerItem, tenantId?: number) => `/api/structure/explore?kind=${owner?.kind ?? 'root'}&id=${owner?.id ?? 0}${tenantId ? `&tenantId=${tenantId}` : ''}`
const identity = (item: ExplorerItem) => `${item.kind}:${item.id}`

export function ConnectionTree(props: Actions) {
  return <div className="v2-tree" aria-label="Architecture connection tree"><EntityBranch {...props} ancestors={[]} initialOpen /></div>
}
function EntityBranch({ item, tenantId, ancestors, initialOpen = false, ...actions }: Actions & { item?: ExplorerItem; tenantId?: number; ancestors: string[]; initialOpen?: boolean }) {
  const [open, setOpen] = useState(initialOpen)
  const [visited, setVisited] = useState(initialOpen)
  const scope = item?.kind === 'tenant' ? item.id : tenantId
  const leaf = !!item && ['user', 'role', 'rule'].includes(item.kind)
  const cycle = !!item && ancestors.includes(identity(item))
  const result = useBranch(`${base(item, scope)}&pageSize=1&revision=${actions.revision}`, open && !leaf && !cycle)
  const current = result.data?.current ?? item
  const expand = () => { if (leaf || cycle) { if (current) actions.onDetail(current, scope) } else { setVisited(true); setOpen(true) } }
  const menu = [
    { key: 'explore', label: cycle ? 'View reference details' : leaf ? 'Details' : 'Explore connections', onClick: expand },
    ...(current ? [{ key: 'details', label: 'Details & actions', onClick: () => actions.onDetail(current, scope) }] : []),
    ...createKinds(current).map(kind => ({ key: `add-${kind}`, label: `Add ${explorerLabels[kind]}`, onClick: () => actions.onAdd(kind, current) })),
  ]
  return <div className="v2-tree-entity" data-entity={item ? identity(item) : 'workspace'}>
    <Dropdown trigger={['contextMenu']} menu={{ items: menu }}><div className="v2-tree-node">
      <button className="v2-tree-object" aria-label={`Explore connections: ${current?.code ?? 'Workspace'}`} aria-expanded={leaf || cycle ? undefined : open} onClick={expand} onDoubleClick={() => current && actions.onDetail(current, scope)}>
        <svg viewBox="-100 -200 200 255" aria-hidden="true"><WorldObject kind={current?.kind ?? 'workspace'} type={current?.type} /></svg>
        <strong>{current?.name ?? 'Workspace'}</strong><code>{current?.code ?? 'TENANT SKYLINE'}</code><small>{cycle ? 'Already in this path · reference' : leaf ? 'Details' : open ? 'Connections expanded' : 'Explore connections'}</small>
      </button>
      <div className="v2-tree-node-actions">{!leaf && !cycle && open && <button aria-label={`Collapse ${current?.code ?? 'Workspace'}`} onClick={() => setOpen(false)}>−</button>}<Dropdown trigger={['click']} menu={{ items: menu }}><Button size="small" aria-label={`Actions for ${current?.code ?? 'Workspace'}`} icon={<MoreOutlined />} /></Dropdown></div>
    </div></Dropdown>
    {visited && !leaf && !cycle && <div className="v2-tree-children" hidden={!open}>
      {result.error ? <Alert type="error" title={result.error} action={<Button onClick={result.retry}>Retry</Button>} /> : !result.data ? <Skeleton active paragraph={{ rows: 2 }} /> : <>
        {result.data.notice && <p className="v2-tree-notice">{result.data.notice}</p>}
        {result.data.relations.map(district => <DistrictBranch key={district.key} {...actions} owner={current} tenantId={scope} district={district} ancestors={item ? [...ancestors, identity(item)] : ancestors} />)}
      </>}
    </div>}
  </div>
}
function DistrictBranch({ owner, tenantId, district, ancestors, ...actions }: Actions & { owner?: ExplorerItem; tenantId?: number; district: TreeDistrict; ancestors: string[] }) {
  const [open, setOpen] = useState(false)
  const [visited, setVisited] = useState(false)
  const expand = () => { setVisited(true); setOpen(true) }
  const [page, setPage] = useState(1)
  const [revealed, setRevealed] = useState<ExplorerItem[]>([])
  const result = useBranch(`${base(owner, tenantId)}&relation=${district.key}&pageSize=6&page=${page}&revision=${actions.revision}`, open)
  const reveal = (item: ExplorerItem) => { expand(); setRevealed(items => [...items.filter(x => identity(x) !== identity(item)), item]) }
  const search = (expanded = false) => actions.onSearch({ owner, tenantId, district, expanded, reveal })
  const kind = districtKinds[district.key]
  const menu = [
    { key: 'explore', label: 'Explore connections', onClick: expand },
    { key: 'search', label: `Search ${district.label}`, icon: <SearchOutlined />, onClick: () => search() },
    { key: 'workspace', label: 'Open district workspace', onClick: () => search(true) },
    ...(createKinds(owner).includes(kind) ? [{ key: 'add', label: `Add ${explorerLabels[kind]}`, icon: <PlusOutlined />, onClick: () => actions.onAdd(kind, owner) }] : []),
  ]
  // Search-selected records stay visible even when another page is displayed.
  const items = [...revealed, ...(result.data?.items ?? []).filter(item => !revealed.some(x => identity(x) === identity(item)))]
  return <div className="v2-tree-district" data-district={district.key}>
    <Dropdown trigger={['contextMenu']} menu={{ items: menu }}><div className="v2-tree-group">
      <button className="v2-tree-group-main" aria-label={`Explore ${district.label}, ${district.count} records`} aria-expanded={open} onClick={expand} onDoubleClick={() => search(true)}><svg viewBox="-100 -190 200 250" aria-hidden="true"><WorldObject kind={kind ?? 'resource'} scale={.8} /></svg><span><strong>{district.label}</strong><small>{district.count.toLocaleString()} records</small></span><b>{open ? '↓' : '→'}</b></button>
      {open && <button className="v2-tree-collapse" aria-label={`Collapse ${district.label}`} onClick={() => setOpen(false)}>−</button>}
      <Dropdown trigger={['click']} menu={{ items: menu }}><Button aria-label={`${district.label} actions`} icon={<MoreOutlined />} /></Dropdown>
    </div></Dropdown>
    {visited && <div className="v2-tree-children" hidden={!open}>
      <div className="v2-tree-tools"><Button size="small" icon={<SearchOutlined />} onClick={() => search()}>Search {district.label}</Button><span>6 records per page</span>{revealed.length > 0 && <Button size="small" onClick={() => setRevealed([])}>Clear search selections</Button>}</div>
      {result.error ? <Alert type="error" title={result.error} action={<Button onClick={result.retry}>Retry</Button>} /> : !result.data ? <Skeleton active paragraph={{ rows: 2 }} /> : <>
        {!items.length && <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="No records in this collection" />}
        {items.map(item => <EntityBranch key={`${identity(item)}:${revealed.some(x => identity(x) === identity(item)) ? 'selected' : 'page'}`} {...actions} item={item} tenantId={tenantId} ancestors={ancestors} initialOpen={revealed.some(x => identity(x) === identity(item))} />)}
        {result.data.total > 6 && <Pagination size="small" current={result.data.page} total={result.data.total} pageSize={6} showSizeChanger={false} onChange={setPage} />}
      </>}
    </div>}
  </div>
}


