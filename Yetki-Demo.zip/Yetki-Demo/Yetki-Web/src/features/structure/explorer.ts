export type ExplorerKind = 'tenant' | 'application' | 'resource' | 'api' | 'endpoint' | 'ui' | 'permission' | 'policy' | 'rule' | 'role' | 'client' | 'externalPermission' | 'user'
export interface ExplorerItem {
  kind: ExplorerKind; id: number; code: string; name: string; type: string;
  description?: string; active?: boolean; tenantId?: number; applicationId?: number;
  resourceId?: number; permissionId?: number; parentId?: number; annotation?: string;
}
export interface ExplorerPage {
  current?: ExplorerItem; relations: { key: string; label: string; count: number }[];
  relation: string; items: ExplorerItem[]; total: number; page: number; pageSize: number; notice?: string;
}
export type TrailEntry = Pick<ExplorerItem, 'kind' | 'id' | 'code' | 'name' | 'type'> & { view?: { relation?: string; q?: string; page?: number } }
export const explorerLabels: Record<ExplorerKind, string> = { tenant: 'Tenant', application: 'Platform', resource: 'Resource', api: 'API', endpoint: 'Endpoint', ui: 'UI Element', permission: 'Permission', policy: 'Policy', rule: 'Rule', role: 'Role', client: 'Client', externalPermission: 'External Permission', user: 'User' }
export function itemLabel(item: ExplorerItem | TrailEntry) {
  return item.kind === 'resource' ? item.type === 'SubModule' ? 'Submodule' : item.type : item.kind === 'ui' ? item.type : explorerLabels[item.kind]
}
export function readTrail(raw: string | null): TrailEntry[] {
  if (!raw || raw.length > 16000) return []
  try {
    const entries: unknown = JSON.parse(raw)
    if (!Array.isArray(entries) || entries.length > 24) return []
    if (!entries.every((x) => x && Object.hasOwn(explorerLabels, x.kind) && Number.isSafeInteger(x.id) && x.id > 0 && ['code', 'name', 'type'].every((k) => typeof x[k] === 'string' && x[k].length <= 500)
      && (!x.view || (typeof x.view === 'object' && (!x.view.q || (typeof x.view.q === 'string' && x.view.q.length <= 200)) && (!x.view.relation || (typeof x.view.relation === 'string' && x.view.relation.length < 50)) && (!x.view.page || (Number.isInteger(x.view.page) && x.view.page > 0 && x.view.page <= 100000)))))) return []
    return entries as TrailEntry[]
  } catch { return [] }
}
export function managementLink(item: ExplorerItem) {
  switch (item.kind) {
    case 'user': return `/users/${item.id}`
    case 'permission': return `/permissions/${item.id}`
    case 'policy': return `/policies/${item.id}`
    case 'rule': return `/policies/${item.parentId}`
    case 'role': return `/roles/${item.id}`
    case 'api': return `/catalog?api=${item.id}`
    case 'endpoint': return `/catalog?api=${item.parentId}`
    case 'client': return '/clients'
    case 'tenant': return '/tenants'
    case 'externalPermission': return '/external'
    default: return `/catalog${item.resourceId ? `?node=${item.resourceId}` : ''}`
  }
}
export function createKinds(current?: ExplorerItem): ExplorerKind[] {
  if (!current) return ['tenant']
  switch (current.kind) {
    case 'tenant': return ['application', 'client', 'tenant']
    case 'application': return ['resource']
    case 'resource': return [...(current.type !== 'SubModule' ? ['resource' as const] : ['api' as const]), 'ui', 'permission']
    case 'api': return ['endpoint']
    case 'ui': return ['ui']
    default: return []
  }
}
