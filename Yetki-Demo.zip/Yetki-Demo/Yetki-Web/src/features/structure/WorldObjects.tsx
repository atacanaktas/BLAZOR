import type { ExplorerKind } from './explorer'

// Native vectors keep the scene sharp, interactive and independent of external image assets.
function Block({ x = 0, y = 0, w = 48, d = 30, h = 80, color = '#005092', top = '#497a9e', side = '#003767' }: { x?: number; y?: number; w?: number; d?: number; h?: number; color?: string; top?: string; side?: string }) {
  return <g transform={`translate(${x} ${y})`}><path d={`M0 0 L${w} ${-w / 2} V${-h - w / 2} L0 ${-h}Z`} fill={color} /><path d={`M0 0 L${-d} ${-d / 2} V${-h - d / 2} L0 ${-h}Z`} fill={side} /><path d={`M0 ${-h} L${w} ${-h - w / 2} L${w - d} ${-h - (w + d) / 2} L${-d} ${-h - d / 2}Z`} fill={top} /></g>
}

function Plaza() {
  return <g><Block x={-28} y={-5} w={36} d={27} h={68} color="#8a9eac" side="#627e92" top="#c1ced7" /><Block x={7} w={55} d={38} h={152} />
    {[0, 1, 2, 3, 4, 5].map((row) => <g key={row}>{[0, 1, 2].map((col) => <path key={col} d={`M${15 + col * 15} ${-21 - row * 20 - col * 7.5} l8 -4 v-11 l-8 4Z`} fill={(row + col) % 4 === 0 ? '#e6ca86' : '#b4cbd8'} opacity={.85} />)}<path d={`M-21 ${-29 - row * 20} l10 5 v-10 l-10 -5Z`} fill="#6896b6" /></g>)}
    <path d="M20 -4 v-20 l17 -8 v20" fill="#e3edf2" /><path d="M28 -8 v-19" stroke="#53728a" strokeWidth="2" /><Block x={10} y={-159} w={29} d={20} h={9} color="#ced9e1" top="#f0f5f8" side="#91a8ba" /><path d="M15 -186 v-29" stroke="#6d8799" strokeWidth="3" /><circle className="world-beacon" cx="15" cy="-217" r="4" fill="#e3b65f" />
  </g>
}
function Server() {
  return <g><Block w={44} d={30} h={100} color="#415d74" top="#9cadba" side="#203f59" />{[0, 1, 2, 3].map((i) => <g key={i} transform={`translate(0 ${-i * 23})`}><path d="M5 -8 l34 -17 v-17 l-34 17Z" fill="#112e48" /><path d="M11 -20 l15 -7" stroke="#819baa" strokeWidth="2" /><circle className="server-led" cx="33" cy="-27" r="2" fill="#83d3b5" style={{ animationDelay: `${i * .4}s` }} /></g>)}<path d="M-23 -18 l13 6 M-23 -24 l13 6 M-23 -30 l13 6" stroke="#7794a9" strokeWidth="2" /></g>
}
function Book({ shelf = false }: { shelf?: boolean }) {
  return <g>{shelf && <><Block x={-28} y={-10} w={20} d={14} h={64} color="#71899c" top="#afc0cc" side="#536d82" /><Block x={-13} y={-3} w={22} d={15} h={72} color="#a7b5bf" top="#dce4e9" side="#7990a3" /></>}<Block w={49} d={14} h={85} color="#005092" side="#003563" top="#668faa" /><path d="M5 -84 l39 -19 l-1 6 l-38 19Z" fill="#f3f2e9" /><path d="M7 -83 l33 -16 M8 -80 l31 -15" stroke="#c4c6bf" /><path d="M7 -71 l34 -17 v49 l-34 17Z" fill="#175e97" /><path d="M16 -59 l15 -7 M16 -51 l20 -10 M16 -43 l12 -6" stroke="#cedfeb" strokeWidth="2.5" /><path d="M28 -93 v22 l5 -6 l5 1 v-22" fill="#e1bc70" /><path d="M-8 -78 v64" stroke="#3a75a2" strokeWidth="2" /></g>
}
function Genie() {
  return <g className="world-genie"><ellipse cx="0" cy="-4" rx="24" ry="9" fill="#caa767" /><path d="M-17 -9 Q-13 6 11 1 L22 -8 Q35 -18 23 -17 L13 -12Z" fill="#dfbd78" /><path d="M-2 -15 C-39 -33 22 -38 -3 -56 C-25 -71 -26 -101 0 -105 C28 -104 29 -75 17 -65 C5 -54 38 -34 9 -24Z" fill="#729fb8" opacity=".25" /><path d="M0 -17 C-14 -31 19 -41 5 -55 L-17 -65 Q-24 -91 -10 -99 L15 -99 Q32 -85 19 -65 L8 -56 C28 -32 -10 -28 0 -17Z" fill="#005092" /><path d="M-16 -89 Q-36 -86 -31 -65 M20 -89 Q38 -83 33 -65" fill="none" stroke="#005092" strokeWidth="11" strokeLinecap="round" /><circle cx="-30" cy="-63" r="6" fill="#e1b88f" /><circle cx="33" cy="-63" r="6" fill="#e1b88f" /><path d="M-16 -65 Q0 -57 19 -65" stroke="#dbb776" strokeWidth="7" /><circle cx="2" cy="-114" r="20" fill="#e6c5a0" /><path d="M-19 -119 Q-22 -145 2 -143 Q27 -145 23 -120 Q3 -136 -19 -119" fill="#e7edf2" /><path d="M-14 -132 Q2 -118 18 -133" stroke="#93aec0" strokeWidth="3" fill="none" /><ellipse cx="2" cy="-134" rx="4" ry="6" fill="#005092" /><circle cx="-5" cy="-113" r="2" fill="#243c50" /><circle cx="10" cy="-113" r="2" fill="#243c50" /><path d="M-3 -103 Q3 -98 9 -104" fill="none" stroke="#8c654c" strokeWidth="2" strokeLinecap="round" /><path d="M-11 -96 Q3 -85 15 -97 L4 -84Z" fill="#234a65" /></g>
}
function Monitor() {
  return <g><Block x={1} y={2} w={38} d={24} h={7} color="#a1b4c2" top="#d2dce4" side="#7893a7" /><path d="M9 -10 v-24 l12 -6 v23Z" fill="#748fa3" /><path d="M-27 -38 V-103 L48 -140 v67Z" fill="#23445f" stroke="#9ab0c0" strokeWidth="5" strokeLinejoin="round" /><path d="M-21 -45 v-51 l63 -31 v51Z" fill="#005092" /><path d="M-13 -83 l24 -12 M-13 -73 l39 -19 M-13 -63 l17 -8" stroke="#9cbed4" strokeWidth="3" /><path d="M28 -108 l6 3 l-6 10" fill="none" stroke="#dfbc76" strokeWidth="2" /></g>
}
function Shield({ rule = false }: { rule?: boolean }) {
  return <g><Block w={45} d={35} h={12} color="#8ca5b6" top="#d5e0e7" side="#6e8ba0" /><path d="M-23 -111 L10 -131 L47 -125 L44 -68 Q34 -34 7 -19 Q-18 -34 -22 -58Z" fill={rule ? '#627f95' : '#005092'} stroke="#a1b8c8" strokeWidth="4" /><path d="M-13 -102 L10 -116 L36 -113 L33 -73 Q27 -48 8 -35 Q-8 -45 -12 -65Z" fill="none" stroke="#7da2be" strokeWidth="2" />{rule ? <path d="M-1 -83 l18 -9 M-1 -72 l18 -9 M-1 -61 l11 -5" stroke="#e7edf2" strokeWidth="4" /> : <path d="M-1 -76 l9 6 l18 -34" fill="none" stroke="#efcf88" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />}</g>
}
function Key() {
  return <g><Block w={44} d={34} h={12} color="#92a9b8" top="#d9e3e9" side="#7290a3" /><g className="world-key"><path d="M4 -100 L5 -32 l13 -7 M5 -48 l17 -8" fill="none" stroke="#9d793f" strokeWidth="12" strokeLinejoin="round" /><path d="M0 -101 v66 l14 -7 M0 -51 l17 -8" fill="none" stroke="#dfbd77" strokeWidth="8" strokeLinejoin="round" /><ellipse cx="0" cy="-111" rx="22" ry="28" fill="none" stroke="#e5c788" strokeWidth="10" /><ellipse cx="0" cy="-111" rx="12" ry="17" fill="#f0f4f7" /></g></g>
}
function Gate() {
  return <g><Block x={-25} w={13} d={13} h={90} color="#7d98ac" top="#c9d7e0" side="#52748f" /><Block x={36} y={-30} w={13} d={13} h={90} color="#005092" top="#6c98b9" side="#003867" /><path d="M-25 -88 v-24 l61 -30 v24Z" fill="#005092" /><path d="M-13 -81 l36 -18 v66 l-36 18Z" fill="#9abed4" opacity=".35" /><path className="gate-pulse" d="M-4 -68 l15 4 l-15 19" stroke="#005092" strokeWidth="4" fill="none" /></g>
}
function Cloud() {
  return <g><Block w={40} d={30} h={10} color="#a1b3bf" top="#d6e1e7" side="#7e98ab" /><path d="M-25 -65 C-55 -69 -42 -99 -23 -99 C-24 -128 14 -143 26 -116 C53 -130 72 -95 48 -80Z" fill="#e5edf2" stroke="#8faabc" strokeWidth="3" /><path d="M-15 -76 l45 -22" stroke="#005092" strokeWidth="4" strokeDasharray="5 4" /><path d="M5 -68 v43" stroke="#8faabc" strokeWidth="3" strokeDasharray="5 5" /></g>
}

export function WorldObject({ kind, type, scale = 1 }: { kind: ExplorerKind | 'workspace'; type?: string; scale?: number }) {
  return <g transform={`scale(${scale})`} className={`world-object object-${kind}`} aria-hidden="true">
    {kind === 'tenant' ? <Plaza /> : kind === 'client' || kind === 'api' ? <Server /> : kind === 'resource' || kind === 'application' ? <Book shelf={kind === 'application' || type === 'Domain'} /> : kind === 'user' ? <Genie /> : kind === 'ui' ? <Monitor /> : kind === 'permission' ? <Key /> : kind === 'policy' || kind === 'role' || kind === 'rule' ? <Shield rule={kind === 'rule'} /> : kind === 'endpoint' ? <Gate /> : kind === 'externalPermission' ? <Cloud /> : <><Block w={45} d={45} h={20} /><circle cx="0" cy="-78" r="35" fill="#edf3f7" stroke="#005092" strokeWidth="3" /><ellipse cx="0" cy="-78" rx="13" ry="35" fill="none" stroke="#769ab5" strokeWidth="2" /><path d="M-33 -87 h66 M-33 -68 h66" stroke="#769ab5" strokeWidth="2" /><path d="M0 -42 v15" stroke="#005092" strokeWidth="4" /></>}
  </g>
}

export function WorldTree({ x, y }: { x: number; y: number }) {
  return <g transform={`translate(${x} ${y})`} aria-hidden="true"><ellipse cy="5" rx="16" ry="7" fill="#879eae" opacity=".13" /><path d="M0 0 v-24" stroke="#86969d" strokeWidth="4" /><path d="M-16 -17 L0 -58 L17 -17 L0 -9Z" fill="#9ab2aa" /><path d="M0 -58 v49 l17 -8Z" fill="#7e9c92" /></g>
}
