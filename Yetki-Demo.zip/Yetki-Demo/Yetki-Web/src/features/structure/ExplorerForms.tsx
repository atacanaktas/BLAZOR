import { Alert, App, Button, Flex, Form, Input, Modal, Select, Typography } from 'antd'
import { useEffect, useState } from 'react'
import { api } from '../../api/client'
import { explorerLabels, type ExplorerItem, type ExplorerKind, type ExplorerPage } from './explorer'

const options = (values: string[]) => values.map((value) => ({ value, label: value }))

/** Context fixes the parent. Opening an editor never downloads the complete catalog. */
export function ExplorerCreateModal({ kind, parent, onClose, onCreated }: {
  kind: ExplorerKind; parent?: ExplorerItem; onClose: () => void; onCreated: (kind: ExplorerKind, id: number) => void;
}) {
  const [form] = Form.useForm()
  const [saving, setSaving] = useState(false)
  const { message } = App.useApp()
  const resourceId = parent?.resourceId
  const label = kind === 'resource' ? parent?.kind === 'application' ? 'Domain' : parent?.type === 'Domain' ? 'Module' : 'Submodule' : explorerLabels[kind]
  const save = async () => {
    let fields: Record<string, unknown>
    try { fields = await form.validateFields() } catch { return }
    const context: Record<string, unknown> = {}
    let path = ''
    switch (kind) {
      case 'tenant': path = '/api/tenants'; context.parentId = parent?.id; break
      case 'application': path = '/api/catalog/applications'; context.tenantId = parent?.id; break
      case 'client': path = '/api/clients'; context.tenantId = parent?.id; break
      case 'resource': path = '/api/catalog/nodes'; context.applicationId = parent?.applicationId; context.parentId = parent?.kind === 'resource' ? parent.id : undefined; break
      case 'permission': path = '/api/permissions'; context.catalogNodeId = resourceId; break
      case 'api': path = '/api/apis'; context.catalogNodeId = resourceId; break
      case 'ui': path = '/api/ui-elements'; context.catalogNodeId = resourceId; context.parentId = parent?.kind === 'ui' ? parent.id : undefined; break
      case 'endpoint': path = `/api/apis/${parent?.id}/endpoints`; break
      default: return
    }
    setSaving(true)
    try {
      const result = await api.post<{ id: number }>(path, { ...fields, ...context })
      message.success(`${label} created`)
      onCreated(kind, result.id)
    } catch (e) { message.error((e as Error).message) } finally { setSaving(false) }
  }
  return <Modal open title={`Add ${label}`} footer={null} onCancel={onClose} width={540}>
    <div className="explorer-form-parent">Parent <strong>{parent?.code ?? 'Workspace'}</strong></div>
    <Form form={form} layout="vertical" initialValues={{ type: kind === 'tenant' ? 'Subsidiary' : kind === 'application' ? 'ApiPlatform' : 'Confidential', kind: parent?.kind === 'ui' ? 'Button' : 'Screen', action: 'read', riskLevel: 'Medium', method: 'GET' }}>
      {kind !== 'permission' && kind !== 'endpoint' && <Form.Item name={kind === 'client' ? 'clientId' : 'code'} label={kind === 'client' ? 'Client ID' : 'Code'} rules={[{ required: true, whitespace: true }, { max: 100 }]}><Input autoComplete="off" /></Form.Item>}
      {kind !== 'endpoint' && <Form.Item name="name" label="Name" rules={[{ required: true, whitespace: true }, { max: 200 }]}><Input autoComplete="off" /></Form.Item>}
      {kind === 'tenant' && <Form.Item name="type" label="Tenant Type"><Select options={options(['Bank', 'Subsidiary'])} /></Form.Item>}
      {kind === 'application' && <Form.Item name="type" label="Platform Type"><Select options={options(['ApiPlatform', 'Desktop', 'Mobile', 'Web', 'Batch'])} /></Form.Item>}
      {kind === 'client' && <Form.Item name="type" label="Client Type"><Select options={options(['Confidential', 'Public', 'Intermediary'])} /></Form.Item>}
      {kind === 'ui' && <Form.Item name="kind" label="UI Type"><Select options={options(['Screen', 'Menu', 'Tab', 'Button', 'Field'])} /></Form.Item>}
      {kind === 'permission' && <><Form.Item name="action" label="Action" rules={[{ required: true }]}><Select options={options(['read', 'view', 'create', 'update', 'delete', 'approve', 'execute', 'export', 'print'])} /></Form.Item><Form.Item name="riskLevel" label="Risk Level"><Select options={options(['Low', 'Medium', 'High', 'Critical'])} /></Form.Item></>}
      {kind === 'api' && <Form.Item name="audience" label="Audience" extra="Leave empty to generate an audience from the Platform and API code."><Input placeholder="api://..." /></Form.Item>}
      {kind === 'endpoint' && <><Form.Item name="method" label="HTTP Method"><Select options={options(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'])} /></Form.Item><Form.Item name="path" label="Path" rules={[{ required: true, whitespace: true }, { pattern: /^\//, message: 'Start with /' }]}><Input placeholder="/v1/accounts/{id}" /></Form.Item><Form.Item name="summary" label="Summary"><Input /></Form.Item><Alert type="info" showIcon title="Create the Endpoint, then map its Permission from the context panel." /></>}
      <Flex justify="end" gap={8}><Button onClick={onClose}>Cancel</Button><Button type="primary" onClick={save} loading={saving}>Create {label}</Button></Flex>
    </Form>
  </Modal>
}

export function ExplorerRenameModal({ item, onClose, onDone }: { item: ExplorerItem; onClose: () => void; onDone: () => void }) {
  const [name, setName] = useState(item.name)
  const [saving, setSaving] = useState(false)
  const { message } = App.useApp()
  const save = async () => {
    if (!name.trim() || saving) return
    setSaving(true)
    try { await api.put(`/api/structure/${item.kind}/${item.id}/name`, { name: name.trim() }); onDone(); onClose(); message.success('Name updated') }
    catch (e) { message.error((e as Error).message) } finally { setSaving(false) }
  }
  return <Modal open title={`Rename ${explorerLabels[item.kind]}`} onCancel={onClose} onOk={save} okText="Save" cancelText="Cancel" confirmLoading={saving} okButtonProps={{ disabled: !name.trim() || name.trim() === item.name }}>
    <Typography.Paragraph type="secondary">{item.code}</Typography.Paragraph><Input aria-label="Name" value={name} onChange={(e) => setName(e.target.value)} maxLength={200} onPressEnter={save} />
  </Modal>
}

export function PermissionMappingModal({ item, tenantId, onClose, onDone }: { item: ExplorerItem; tenantId?: number; onClose: () => void; onDone: () => void }) {
  const [query, setQuery] = useState('')
  const [page, setPage] = useState(1)
  const [result, setResult] = useState<ExplorerPage>()
  const [error, setError] = useState<string>()
  const [loading, setLoading] = useState(true)
  const [chosen, setChosen] = useState<number | null>(item.permissionId ?? null)
  const [saving, setSaving] = useState(false)
  const { message } = App.useApp()
  useEffect(() => {
    let active = true
    const timer = setTimeout(() => {
      setLoading(true); setError(undefined)
      const params = new URLSearchParams({ kind: 'permissionCatalog', tenantId: String(tenantId ?? item.tenantId), q: query, page: String(page), pageSize: '12' })
      api.get<ExplorerPage>(`/api/structure/explore?${params}`).then((data) => { if (active) setResult(data) }).catch((e) => { if (active) setError(e.message) }).finally(() => { if (active) setLoading(false) })
    }, 200)
    return () => { active = false; clearTimeout(timer) }
  }, [item.tenantId, query, page, tenantId])
  const save = async () => {
    setSaving(true)
    try { await api.put(`/api/structure/${item.kind}/${item.id}/permission`, { permissionId: chosen }); onDone(); onClose(); message.success('Permission mapping updated') }
    catch (e) { message.error((e as Error).message) } finally { setSaving(false) }
  }
  return <Modal open title="Map Permission" onCancel={onClose} onOk={save} okText="Save mapping" cancelText="Cancel" confirmLoading={saving} okButtonProps={{ disabled: chosen === (item.permissionId ?? null) }}>
    <Typography.Paragraph type="secondary">Search Permissions available to this Tenant across all Platforms. A Nextral UI Element can map to an ANKA Permission.</Typography.Paragraph>
    <Input.Search aria-label="Search permissions" placeholder="Search permissions…" value={query} onChange={(e) => { setQuery(e.target.value); setPage(1) }} />
    {error && <Alert type="error" title={error} />}
    <div className="mapping-options" aria-busy={loading}>{loading ? <Typography.Text>Loading…</Typography.Text> : result?.items.map((p) => <button type="button" key={p.id} aria-pressed={chosen === p.id} onClick={() => setChosen(p.id)}><strong>{p.name}</strong><code>{p.code}</code></button>)}</div>
    {!loading && result?.total === 0 && <Typography.Paragraph>No matching Permissions in this Tenant.</Typography.Paragraph>}
    <Flex justify="space-between" align="center"><Button disabled={page <= 1 || loading} onClick={() => setPage(page - 1)}>Previous</Button><span>{result?.total ?? 0} permissions</span><Button disabled={loading || page * 12 >= (result?.total ?? 0)} onClick={() => setPage(page + 1)}>Next</Button></Flex>
    <Button type="link" onClick={() => setChosen(null)}>Clear mapping</Button><Typography.Text type="secondary">Selected: {chosen ? `#${chosen}` : 'None'}</Typography.Text>
    {chosen === null && <Alert type="warning" title={item.kind === 'endpoint' ? 'An unmapped Endpoint is denied by the authorization engine.' : 'Removing the mapping removes this UI Element’s direct Permission check.'} />}
  </Modal>
}
