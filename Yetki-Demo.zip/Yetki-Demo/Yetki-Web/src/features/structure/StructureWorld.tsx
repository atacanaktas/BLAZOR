import { useEffect, useRef, useState, type PointerEvent } from 'react'
import { AimOutlined, ArrowLeftOutlined, CaretRightOutlined, ExpandOutlined, MinusOutlined, PauseOutlined, PlusOutlined } from '@ant-design/icons'
import { api } from '../../api/client'
import { itemLabel, type ExplorerItem, type ExplorerPage, type TrailEntry } from './explorer'
import { WorldObject, WorldTree } from './WorldObjects'
import './world.css'

interface WorldProps {
  data: ExplorerPage; loading: boolean; trail: TrailEntry[]; refreshKey: string;
  onOpen: (item: ExplorerItem) => void; onInspect: () => void; onBack: () => void;
  onRelation: (relation: string) => void; onTrail: (index: number) => void;
}
interface Positioned { item: ExplorerItem; x: number; y: number; scale: number; group: string }
const short = (value: string, length = 24) => value.length > length ? value.slice(0, length - 1) + '…' : value

export function StructureWorld({ data, loading, trail, refreshKey, onOpen, onInspect, onBack, onRelation, onTrail }: WorldProps) {
  const sceneId = `${data.current?.kind ?? 'root'}:${data.current?.id ?? 0}:${data.relation}:${data.page}:${data.items.map((x) => x.id).join(',')}`
  const shell = useRef<HTMLDivElement>(null)
  const svg = useRef<SVGSVGElement>(null)
  const [zoom, setZoom] = useState(1)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [flying, setFlying] = useState(false)
  const [hovered, setHovered] = useState<ExplorerItem>()
  const [motion, setMotion] = useState(() => !window.matchMedia('(prefers-reduced-motion: reduce)').matches)
  const [playing, setPlaying] = useState(false)
  const [trace, setTrace] = useState(-1)
  const [districts, setDistricts] = useState<{ key: string; clients: ExplorerPage; users: ExplorerPage }>()
  const [districtError, setDistrictError] = useState<string>()
  const [fullscreenError, setFullscreenError] = useState(false)
  const drag = useRef<{ x: number; y: number; px: number; py: number } | null>(null)
  const flightTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
  const campus = data.current?.kind === 'tenant' && data.relation === 'platforms'
  const districtKey = `${data.current?.id}:${refreshKey}`
  const extra = districts?.key === districtKey ? districts : undefined

  useEffect(() => {
    const frame = requestAnimationFrame(() => { setZoom(1); setPan({ x: 0, y: 0 }); setFlying(false); setHovered(undefined); setPlaying(false); setTrace(-1) })
    return () => cancelAnimationFrame(frame)
  }, [sceneId])
  useEffect(() => () => clearTimeout(flightTimer.current), [])
  useEffect(() => { if (loading) clearTimeout(flightTimer.current) }, [loading])
  useEffect(() => {
    if (!campus) return
    let active = true
    const url = `/api/structure/explore?kind=tenant&id=${data.current!.id}&pageSize=3&relation=`
    Promise.all([api.get<ExplorerPage>(url + 'clients'), api.get<ExplorerPage>(url + 'users')]).then(([clients, users]) => {
      if (active) { setDistricts({ key: districtKey, clients, users }); setDistrictError(undefined) }
    }).catch(() => { if (active) setDistrictError(districtKey) })
    return () => { active = false }
  }, [campus, data.current, districtKey])
  useEffect(() => {
    const media = window.matchMedia('(prefers-reduced-motion: reduce)')
    const changed = () => { if (media.matches) { setMotion(false); setPlaying(false) } }
    media.addEventListener('change', changed)
    return () => media.removeEventListener('change', changed)
  }, [])
  useEffect(() => {
    if (!playing) return
    const timer = setTimeout(() => {
      if (trace >= trail.length - 1) setPlaying(false)
      else setTrace(trace + 1)
    }, 1100)
    return () => clearTimeout(timer)
  }, [playing, trail.length, trace])

  const positions: Positioned[] = data.items.map((item, i) => {
    if (campus) return { item, x: i % 2 ? 295 : 125, y: 255 + Math.floor(i / 2) * 170 + (i % 2 ? 30 : 0), scale: .78, group: 'Platform' }
    if (!data.current && data.items.length <= 3) return { item, x: 550 + (i - (data.items.length - 1) / 2) * 310, y: 355 + (i % 2) * 70, scale: 1.22, group: 'Tenant' }
    const coords = [[230, 255], [550, 190], [880, 255], [225, 480], [550, 565], [880, 480]]
    const [x, y] = coords[i % coords.length]
    return { item, x, y, scale: item.kind === 'tenant' ? .8 : 1, group: itemLabel(item) }
  })
  if (campus && extra) {
    extra.clients.items.forEach((item, i) => positions.push({ item, x: 870 + (i % 2) * 100, y: 225 + i * 112, scale: .79, group: 'Client' }))
    extra.users.items.forEach((item, i) => positions.push({ item, x: 450 + i * 180, y: 610 + (i % 2) * 22, scale: .68, group: 'User' }))
  }
  const focus = (node: Positioned) => {
    if (loading || flying) return
    if (['user', 'role', 'rule'].includes(node.item.kind)) {
      if (document.fullscreenElement) void document.exitFullscreen().then(() => onOpen(node.item), () => onOpen(node.item))
      else onOpen(node.item)
      return
    }
    setFlying(true)
    setZoom(1.65)
    setPan({ x: (550 - node.x) * 1.65, y: (350 - (node.y - 75)) * 1.65 })
    flightTimer.current = setTimeout(() => { onOpen(node.item); setFlying(false) }, motion ? 440 : 0)
  }
  const pointerDown = (e: PointerEvent<SVGSVGElement>) => {
    if (e.button !== 0 || (e.target as Element).closest('[data-world-node]')) return
    drag.current = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y }
    e.currentTarget.classList.add('is-dragging')
    e.currentTarget.setPointerCapture(e.pointerId)
  }
  const pointerMove = (e: PointerEvent<SVGSVGElement>) => {
    if (!drag.current) return
    const rect = e.currentTarget.getBoundingClientRect()
    const ratio = Math.min(rect.width / 1100, rect.height / 730)
    setPan({ x: drag.current.px + (e.clientX - drag.current.x) / ratio, y: drag.current.py + (e.clientY - drag.current.y) / ratio })
  }
  const reset = () => { setZoom(1); setPan({ x: 0, y: 0 }) }
  const inspect = () => {
    if (document.fullscreenElement) void document.exitFullscreen().then(onInspect, onInspect)
    else onInspect()
  }
  const relationTitle = data.relations.find((r) => r.key === data.relation)?.label ?? 'Tenants'
  const traceStart = Math.max(0, Math.min(trace - 3, trail.length - 8))
  const visibleTrail = trail.slice(traceStart, traceStart + 8)

  return <div ref={shell} className={`structure-world-shell ${motion ? 'has-motion' : ''} ${flying ? 'is-flying' : ''} ${loading ? 'is-loading' : ''}`}>
    <div className="world-topbar"><div><span className="world-status-dot" /><strong>ACCESS CITY</strong><span className="world-mode">{campus ? 'Tenant campus' : data.current ? itemLabel(data.current) + ' district' : 'Tenant skyline'}</span></div><div className="world-controls"><button aria-label="Zoom out" onClick={() => setZoom(Math.max(.6, zoom - .15))}><MinusOutlined /></button><span>{Math.round(zoom * 100)}%</span><button aria-label="Zoom in" onClick={() => setZoom(Math.min(2, zoom + .15))}><PlusOutlined /></button><button aria-label="Reset camera" onClick={reset}><AimOutlined /></button><button aria-label="Fullscreen scene" onClick={async () => { try { if (document.fullscreenElement) await document.exitFullscreen(); else await shell.current?.requestFullscreen(); setFullscreenError(false) } catch { setFullscreenError(true) } }}><ExpandOutlined /></button></div></div>
    <div className="world-stage">
      <div className="world-scene-caption"><span>{data.current?.code ?? 'WORKSPACE'}</span><h3>{campus ? 'Your connected campus.' : data.current ? 'Follow the connections.' : 'Every Tenant has a place.'}</h3><p>{campus ? 'Platforms, Clients & Users in one scene' : `${data.total} ${relationTitle} · select a landmark to focus`}</p></div>
      {data.current && <button className="world-back" onClick={onBack} disabled={loading || flying}><ArrowLeftOutlined /> Fly back</button>}
      <svg ref={svg} className="world-svg" viewBox="0 0 1100 730" aria-label="Interactive architecture city" onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={(e) => { drag.current = null; e.currentTarget.classList.remove('is-dragging') }} onPointerCancel={(e) => { drag.current = null; e.currentTarget.classList.remove('is-dragging') }}>
        <defs><pattern id="city-grid" width="80" height="40" patternUnits="userSpaceOnUse"><path d="M0 20 L40 0 L80 20 L40 40Z" fill="none" stroke="#dbe3e9" strokeWidth=".7" /></pattern><radialGradient id="city-ground"><stop stopColor="#fff" /><stop offset="1" stopColor="#edf2f6" /></radialGradient><filter id="city-shadow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5" /></filter></defs>
        <rect width="1100" height="730" fill="url(#city-ground)" />
        <g className="world-camera" style={{ transform: `translate(${550 + pan.x}px, ${350 + pan.y}px) scale(${zoom}) translate(-550px, -350px)` }}>
          <path d="M-150 390 L550 35 L1250 390 L550 745Z" fill="url(#city-grid)" />
          <path d="M-50 510 L1060 -45 M80 715 L1260 120" stroke="#e3eaf0" strokeWidth="18" /><path d="M-50 510 L1060 -45 M80 715 L1260 120" stroke="#fff" strokeWidth="1.5" strokeDasharray="7 9" />
          <g className="world-landscaping"><WorldTree x={85} y={430} /><WorldTree x={109} y={454} /><WorldTree x={750} y={135} /><WorldTree x={779} y={154} /><WorldTree x={1010} y={530} /><WorldTree x={982} y={550} /><WorldTree x={370} y={665} /></g>
          {campus && <g className="world-districts"><ellipse cx="218" cy="418" rx="196" ry="245" fill="#dfe8ee" opacity=".34" /><ellipse cx="920" cy="335" rx="130" ry="202" fill="#e2e8ed" opacity=".5" /><ellipse cx="630" cy="610" rx="260" ry="95" fill="#e4ebe8" opacity=".6" /><text x="80" y="160">PLATFORM LIBRARY</text><text x="865" y="132">CLIENT SERVERS</text><text x="460" y="710">USER PLAZA</text></g>}
          {positions.map(({ item, x, y }) => <g key={`road:${item.kind}:${item.id}`} className={`world-road ${hovered?.kind === item.kind && hovered.id === item.id ? 'is-highlighted' : ''}`}><path d={`M550 360 Q${550} ${y} ${x} ${y}`} className="world-road-base" /><path d={`M550 360 Q${550} ${y} ${x} ${y}`} className="world-road-flow" /></g>)}
          {data.current && <g data-world-node="current" className="world-current" transform="translate(550 350)" role="button" tabIndex={0} aria-label={`Manage ${data.current.name}`} onClick={inspect} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); inspect() } }}><title>Manage {data.current.name}</title><ellipse cy="3" rx="87" ry="37" fill="#d4e0e9" /><ellipse cy="3" rx="77" ry="32" fill="#f7fafc" stroke="#a8bece" /><ellipse cy="3" rx="94" ry="42" className="world-focus-ring" /><WorldObject kind={data.current.kind} type={data.current.type} scale={campus ? 1 : 1.05} /><g className="world-current-label" transform="translate(0 53)"><rect x="-92" y="-14" width="184" height="35" rx="9" fill="#005092" /><text textAnchor="middle" y="0" fill="white">{short(data.current.code, 23)}</text><text textAnchor="middle" y="13" className="current-action">MANAGE / EDIT</text></g></g>}
          {!data.current && <g transform="translate(560 562)" className="world-compass"><WorldObject kind="workspace" scale={.65} /><text y="35" textAnchor="middle">TENANT DISTRICT</text></g>}
          <g key={sceneId} className="world-landmarks">{positions.sort((a, b) => a.y - b.y).map((node, i) => <g key={`${node.item.kind}:${node.item.id}`} data-world-node={`${node.item.kind}:${node.item.id}`} className={`world-landmark ${node.item.active === false ? 'is-inactive' : ''}`} transform={`translate(${node.x} ${node.y})`} role="button" tabIndex={loading ? -1 : 0} aria-label={`Focus ${itemLabel(node.item)}: ${node.item.name}`} aria-disabled={loading || flying} onClick={() => focus(node)} onMouseEnter={() => setHovered(node.item)} onMouseLeave={() => setHovered(undefined)} onFocus={() => setHovered(node.item)} onBlur={() => setHovered(undefined)} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); focus(node) } }}>
            <title>{`${itemLabel(node.item)} · ${node.item.name}\n${node.item.code}`}</title><ellipse rx="58" ry="24" cy="2" fill="#91a8ba" opacity=".17" filter="url(#city-shadow)" /><path className="world-pedestal" d="M0 22 L75 -15 L0 -52 L-75 -15Z" fill="#f6f9fb" stroke="#c5d3dd" /><path d="M-75 -15 v5 L0 27 L75 -10 v-5 L0 22Z" fill="#dae5ec" />
            <g className="landmark-art" style={{ animationDelay: `${i * 40}ms` }}><WorldObject kind={node.item.kind} type={node.item.type} scale={node.scale} /></g>
            <g className="landmark-label" transform="translate(0 46)"><rect x="-87" y="-12" width="174" height="40" rx="8" /><text textAnchor="middle" y="2">{short(node.item.name, campus ? 21 : 25)}</text><text textAnchor="middle" y="17" className="landmark-code">{node.item.active === false ? 'Inactive · ' : ''}{short(node.item.code, 27)}</text></g>
          </g>)}</g>
        </g>
      </svg>
      {!data.items.length && !loading && <div className="world-empty">This district is empty.<span>Use Add to place a new landmark.</span></div>}
      <div className="world-hover-caption" aria-live="polite">{hovered ? <><strong>{itemLabel(hovered)} · {hovered.name}</strong><span>{hovered.code}</span></> : <><strong>Explore the architecture</strong><span>Drag to pan · Select a landmark to fly closer</span></>}</div>
      {loading && <div className="world-loading">Opening district…</div>}
      {campus && <div className="world-district-links"><button onClick={() => onRelation('platforms')}>Platforms <b>{data.total}</b></button><button onClick={() => onRelation('clients')}>Clients <b>{data.relations.find((r) => r.key === 'clients')?.count ?? '—'}</b></button><button onClick={() => onRelation('users')}>Users <b>{data.relations.find((r) => r.key === 'users')?.count ?? '—'}</b></button>{!extra && <small>{districtError === districtKey ? 'Districts unavailable · use Refresh' : 'Loading districts…'}</small>}</div>}
    </div>
    {trail.length > 0 && <div className="world-journey"><div className="world-journey-controls"><button aria-label={playing ? 'Pause path replay' : 'Play path replay'} disabled={trail.length < 2 || !motion} onClick={() => { if (playing) setPlaying(false); else { if (trace >= trail.length - 1 || trace < 0) setTrace(0); setPlaying(true) } }}>{playing ? <PauseOutlined /> : <CaretRightOutlined />}</button><span>PATH REPLAY<small>{playing ? `Step ${trace + 1} / ${trail.length}` : 'Schematic relationships'}</small></span></div><div className="world-journey-track">{traceStart > 0 && <span>…</span>}{visibleTrail.map((entry, i) => <button key={`${entry.kind}:${entry.id}`} className={trace === traceStart + i ? 'is-tracing' : ''} onClick={() => onTrail(traceStart + i)} title={entry.name}><svg viewBox="-70 -170 155 200"><WorldObject kind={entry.kind} type={entry.type} scale={.75} /></svg><span>{short(entry.code, 17)}</span><small>{itemLabel(entry)}</small></button>)}</div></div>}
    <footer className="world-footer"><span>Plaza / Tenant <i /> Server / Client <i /> Book / Resource <i /> Genie / User</span><label><input type="checkbox" checked={motion} onChange={(e) => { setMotion(e.target.checked); if (!e.target.checked) setPlaying(false) }} /> Motion</label>{fullscreenError && <span>Fullscreen is unavailable in this browser.</span>}</footer>
  </div>
}
