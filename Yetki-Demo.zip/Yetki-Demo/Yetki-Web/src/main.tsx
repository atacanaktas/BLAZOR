import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { App as AntApp, ConfigProvider } from 'antd'
import trTR from 'antd/locale/tr_TR'
import dayjs from 'dayjs'
import 'dayjs/locale/tr'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import './index.css'

dayjs.locale('tr')

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ConfigProvider
      locale={trTR}
      theme={{
        token: {
          colorPrimary: '#005092', colorPrimaryHover: '#003f75', colorPrimaryActive: '#003461', colorInfo: '#005092', colorText: '#263449',
          colorTextSecondary: '#718096', colorBgLayout: '#f5f6f8', colorBorder: '#dde4ee',
          colorBorderSecondary: '#eaf0f6', borderRadius: 10, fontSize: 14,
          fontFamily: "'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif",
          controlHeight: 38, wireframe: false,
        },
        components: {
          Layout: { siderBg: '#ffffff', headerBg: '#ffffff', bodyBg: '#f5f6f8' },
          Menu: { itemColor: '#66758a', itemSelectedColor: '#ffffff', itemSelectedBg: '#005092', subMenuItemSelectedColor: '#005092',
            itemHoverBg: '#f5f6f8', itemBorderRadius: 8, itemHeight: 42, subMenuItemBg: '#ffffff', iconSize: 17 },
          Card: { headerFontSize: 15, headerFontSizeSM: 14, headerHeight: 60, headerHeightSM: 50, bodyPadding: 22, bodyPaddingSM: 18 },
          Table: { headerBg: '#f8fafd', headerColor: '#748198', headerSplitColor: 'transparent',
            rowHoverBg: '#f1f4f6', cellPaddingBlockSM: 13, cellPaddingInlineSM: 16, cellPaddingBlock: 16, cellPaddingInline: 18 },
          Button: { fontWeight: 500, primaryShadow: '0 2px 4px rgba(0,80,146,.16)', defaultShadow: 'none' },
          Tabs: { titleFontSize: 14, horizontalItemGutter: 26 },
          Tag: { defaultBg: '#f2f5f9', defaultColor: '#61718a' },
          Modal: { borderRadiusLG: 14 },
          Input: { activeShadow: '0 0 0 3px rgba(0,80,146,.10)' },
          Select: { optionSelectedBg: '#e8eef3' },
        },
      }}
    >
      <AntApp>
        <BrowserRouter>
          <App />
        </BrowserRouter>
      </AntApp>
    </ConfigProvider>
  </StrictMode>,
)
