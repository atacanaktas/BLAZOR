# Yetki-Web — Güncel Proje Notları

> Son güncelleme: 4 Ekim 2026  
> Genel mimari, portlar, veritabanı ve üretim riskleri için [`../README.md`](../README.md); açık işler için [`../TODO.md`](../TODO.md).

## Amaç ve sınır

React yönetim konsoludur. **Yalnızca PAP (`http://localhost:5100`) ile konuşur.** Runtime karar, effective access, impact, SoD ve hesaplanan view sonuçları PAP arkasındaki PDP'den gelir. Frontend authorization kararı üretmez.

Stack: React 19, TypeScript 6, Vite 8, Ant Design 6, react-router-dom 7, dayjs, oxlint.

```powershell
npm install
npm run dev      # http://localhost:5180, strictPort
npm run build    # tsc -b + vite build
npm run lint     # oxlint
```

## Güncel navigation ve route'lar

Navbar accordion değildir; sabit section label'ları altında tek tıkla gidilen linkler vardır.

| Section | Route | Sayfa |
| --- | --- | --- |
| Identity & Assignments | `/tenants` | Tenant ve organization hierarchy |
|  | `/roles`, `/roles/:id` | Role directory ve detay |
|  | `/groups`, `/groups/:id` | Dynamic/explicit access groups |
|  | `/users`, `/users/:id` | User ve assignment bilgileri |
| Authorization Model | `/resources` | Flexible resource tree, scopes, endpoint/UI mappings |
|  | `/permissions`, `/permissions/:id` | Permission ve policy koruması |
|  | `/policies`, `/policies/:id` | Policy, rule, condition ve obligation |
| Supporting Definitions | `/resource-types` | Resource type kataloğu |
|  | `/condition-types` | Condition sözleşmeleri |
|  | `/clients` | Caller/intermediary client'lar |
|  | `/ownership-teams` | Sahip ekipler |
| Controls & Integrations | `/sod` | SoD tanım ve ihlalleri |
|  | `/external` | External dependency, drift, provisioning ve event'ler |
| Analysis & Monitoring | `/evaluate` | Decision Analysis |
|  | `/what-if` | Change Simulation |
|  | `/inventory` | Inventory & Coverage |
|  | `/audit` | Audit & Decision History |
|  | `/platform-brief` | Yönetici özeti ve PDF yazdırma görünümü |

Redirect'ler: `/units → /tenants`, `/accesses → /resources?view=list`, `/rules → /condition-types`, `/events → /external?tab=provisioning`.

Kaldırılmış sayfalar ve route'lar: `/catalog`, `/apis`, Reports, Access Overview, Nextral Demo, Gateway Simulator, SDK Demo, eski `/what-if-v2`, eski What-if ve All-in-One örnekleri. Bunlara yeniden link eklenmemelidir.

## Dashboard ve sayfa sorumlulukları

Workspace dört iş alanıyla yönlendirir:

1. **Identity & Organization:** HR/Identity kaynaklı user, role, tenant ve organization bilgileri.
2. **Catalogs & Controls:** Application/integration/risk ekiplerinin resource, client, inventory, SoD, condition ve external definition bilgileri.
3. **Access Management:** Permission, policy, group ve değişiklik simülasyonu.
4. **Monitoring & Reports:** Karar gerekçesi, audit ve operasyonel görünürlük.

Bu ayrım CRUD yetkisi değildir; bilgi sahipliğini ve navigasyonu anlatır. Gerçek admin authorization henüz yoktur.

## Önemli sayfalar

### Resources

- Resource yönetiminin tek ekranı `/resources`'tır.
- Tenant → application → istenen sayıda custom node → resource/scope yapısını destekler; sabit domain/module/submodule zorunluluğu yoktur.
- Ağaç düğümlerinde context menu vardır. Uygulama veya custom node altına node/resource/endpoint eklenebilir.
- Endpoint, UI element, scope, external dependency ve permission bağlantıları aynı katalog bağlamında gösterilir.
- Scope ve permission API seviyesinden değil, seçilen endpoint/resource eyleminden üretilmelidir.

### Permissions / Policies

- Permission bir access key değildir; resource/scope hedefini bir veya daha fazla policy ile korur.
- Policy tipsizdir. Question cards ve advanced tree aynı Rule/Condition modeline yazar.
- Tekrar kullanım policy reference ile yapılır; global Rule listesi ve “rule'u şablon olarak kopyala” kaldırıldı.
- Condition Types ekranında yalnızca condition sözleşmeleri vardır.

### Change Simulation

- Tek route `/what-if`; V2 adı artık kullanılmıyor.
- Üst tablar: User change, Role change, Audience/Group change, Policy change, SoD proposal.
- Sonuçlar formun altında açılır ve hesaplamadan sonra otomatik kaydırılır.
- Effective access kazanma/kaybetme/korunma ile role/group membership değişimi ayrı sayaçlardır.
- Yalnız role/group değişikliği varsa User view otomatik açılır; CSV bu değişiklikleri de içerir.
- “Raporu indir” ancak hesaplanmış sonuç varken kullanılabilir.

### Decision Analysis

- Resource + action, permission veya endpoint üzerinden authorization isteği kurar.
- Tenant, subject, client, via chain, resource properties, context ve simulation time destekler.
- Karar adımları, RBAC kaynakları, policy/rule sonuçları, evidence ve obligations gösterilir.
- Ayrı Gateway/Nextral simulator yoktur; ileride gerekirse bu sayfa tablarla genişletilecektir.

### Platform Brief

- `/platform-brief` üst yönetim için tek sayfalık doküman görünümüdür.
- Mevcut capability, hedef mimari, Keycloak artı/eksi ve roadmap içerir.
- `window.print()` ile PDF'e kaydetme ve özel print CSS vardır.

## Ortak UI bileşenleri

- `components/DataTable.tsx`: bütün liste tablolarının merkezi katmanı. Kolon içi client-side filtre, sıralama, zebra satır, varsayılan 10 kayıt ve 10/20/50/100 seçimi.
- `components/ImpactView.tsx`: RBAC/group impact metrikleri, user/permission/flat view ve CSV.
- `components/PolicyImpact.tsx`: policy senaryoları ve etki raporu.
- `components/QuestionCards.tsx` / `ConditionBuilder.tsx`: aynı backend modelinin basit ve advanced editörleri.
- `components/ReportDownloadContext.tsx`: simülasyon sonucuna kaydırma ve rapor action'ı.
- `layout/navigation.tsx`: navbar ve Workspace sayfa tanımlarının tek kaynağı.

Header yalnız merkezi “Ara” sayfa yönlendirmesini ve yönetim aktörünü gösterir. Desktop sidebar collapse kontrolü navbar üzerindedir. Route loading ve geçici info/warning/error bildirimleri ortak layout'tadır.

## Tasarım ilkeleri

1. Halkbank laciverti (`#003f75`, `#005092`) ve gri/açık mavi yardımcı tonlar.
2. Kurumsal, sade ve ölçülü curve; gösterişli decoration işlevin önüne geçmez.
3. Navigation tek tıkla hedefe götürür; accordion menü kullanılmaz.
4. Büyük veri görselleştirmesinde bütün node'ları aynı anda çizme yaklaşımı kullanılmaz.
5. CRUD öncesinde backend impact/validation sonucu gösterilir; Web'deki preview güvenlik sınırı sayılmaz.
6. Page listeleri DataTable üzerinden merkezileştirilir.
7. Backend alan adları sektör terimleriyle korunur: Tenant, Client, Resource, Scope, Permission, Policy, Rule, Condition.

## Veri ve demo notları

- Aktif DB: `../DataBase/yetki.demo.db`.
- `yetki.demo.yedek.db` temiz örnek; `yetki.bos.db` boş şemadır.
- `X-Actor` demo audit kolaylığıdır; gerçek authentication değildir.
- `useOptions(kind)` `/api/options/{kind}` çağrılarını cache'ler; create/update sonrası ilgili option cache invalidate edilmelidir.
- Büyük resource tree bugün tam yüklenebilir; lazy loading açık TODO'dur.

## Doğrulama

4 Ekim 2026: `npm run build` başarılı, `npm run lint` temiz. Route-level lazy loading aktiftir.

## Açık Web işleri

- Yönetim authentication/authorization ve entitlement'a göre action görünürlüğü.
- Recertification ve maker-checker UI.
- Policy version diff/lint.
- Resource tree lazy loading.
- Rule read-only inceleme/raporlama tasarımı.
- Yüksek hacimli listelerin server-side arama/sayfalama kapsamını genişletme.

Ana backlog [`../TODO.md`](../TODO.md) içindedir.
