﻿# Uçtan uca test: demo veritabanının KOPYASI üzerinde PIP (5301), PDP (5201), PAP (5101) ve Worker'ı başlatır, e2e_test.py'yi çalıştırır,
# servisleri kapatır. Gerçek veritabanlarına (DataBase\*.db) dokunmaz.
#   powershell -ExecutionPolicy Bypass -File e2e\run-e2e.ps1
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$work = Join-Path $env:TEMP "yetki-e2e-$(Get-Date -Format yyyyMMddHHmmss)"
New-Item -ItemType Directory -Force $work | Out-Null
$db = Join-Path $work "e2e.db"
Copy-Item (Join-Path $root "DataBase\yetki.demo.db") $db
Write-Host "Kopya veritabanı: $db"

foreach ($sln in "Yetki-PIP\Yetki.Pip.sln", "Yetki-PDP\Yetki.Pdp.sln", "Yetki-PAP\Yetki.Pap.sln") {
    dotnet build (Join-Path $root $sln) -v q -nologo | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Derleme hatası: $sln" }
}

$env:ConnectionStrings__Yetki = "Data Source=$db"
$env:Pip__BaseUrl = "http://localhost:5301"
$env:Pdp__BaseUrl = "http://localhost:5201"
$procs = @()
# Derlenmiş dll proje klasöründen çalıştırılır (content root = proje klasörü → appsettings.json)
function Start-Dll($projectDir, $dll, $name, $url) {
    $env:ASPNETCORE_URLS = $url
    $log = Join-Path $work "$name.log"
    $p = Start-Process dotnet -ArgumentList "`"$(Join-Path $projectDir "bin\Debug\net9.0\$dll")`"" -WorkingDirectory $projectDir -PassThru -WindowStyle Hidden `
        -RedirectStandardOutput $log -RedirectStandardError "$log.err"
    $script:procs += $p
    if (-not $url) { return }
    for ($i = 0; $i -lt 60; $i++) {
        try { Invoke-WebRequest "$url/swagger/index.html" -UseBasicParsing -TimeoutSec 2 | Out-Null; Write-Host "$name hazır ($url)"; return } catch { Start-Sleep -Milliseconds 500 }
    }
    throw "$name başlamadı; log: $log"
}
$code = 1
try {
    Start-Dll (Join-Path $root "Yetki-PAP\src\Yetki.Pap.Api") "Yetki.Pap.Api.dll" "pap" "http://localhost:5101"   # önce PAP: migration
    Start-Dll (Join-Path $root "Yetki-PIP\src\Yetki.Pip.Api") "Yetki.Pip.Api.dll" "pip" "http://localhost:5301"
    Start-Dll (Join-Path $root "Yetki-PDP\src\Yetki.Pdp.Api") "Yetki.Pdp.Api.dll" "pdp" "http://localhost:5201"
    $env:ASPNETCORE_URLS = $null
    Start-Dll (Join-Path $root "Yetki-PAP\src\Yetki.Pap.Worker") "Yetki.Pap.Worker.dll" "worker" $null
    $env:PYTHONIOENCODING = "utf-8"
    python (Join-Path $PSScriptRoot "e2e_test.py")
    $code = $LASTEXITCODE
}
finally {
    foreach ($p in $procs) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
}
Write-Host "Loglar: $work"
exit $code
