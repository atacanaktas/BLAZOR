"""
Uçtan uca test: PIP + PDP + PAP (+ Worker) birlikte, yönetim konsolunun (Yetki-Web) kullandığı PAP uçları üzerinden.
Servisler çalışıyor olmalı (run-e2e.ps1 kopya veritabanıyla başlatır). Varsayılan portlar: PAP 5101, PDP 5201, PIP 5301.

Kullanım:  python e2e_test.py [--pap http://localhost:5101] [--pdp http://localhost:5201] [--pip http://localhost:5301]
Not: Bu test veriyi DEĞİŞTİRİR (rol atar / geri alır, permission ve resource oluşturup siler) — gerçek demo veritabanına karşı çalıştırmayın.
"""
import argparse, json, sys, time, urllib.error, urllib.request

ap = argparse.ArgumentParser()
ap.add_argument("--pap", default="http://localhost:5101")
ap.add_argument("--pdp", default="http://localhost:5201")
ap.add_argument("--pip", default="http://localhost:5301")
args = ap.parse_args()
PAP, PDP, PIP = args.pap, args.pdp, args.pip
ACTOR = {"X-Actor": "e2e.test"}
fails = 0


def call(method, url, body=None, headers=None):
    data = json.dumps(body).encode() if body is not None else None
    h = {"Content-Type": "application/json", **ACTOR, **(headers or {})}
    req = urllib.request.Request(url, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            t = r.read().decode()
            return r.status, (json.loads(t) if t else None)
    except urllib.error.HTTPError as e:
        t = e.read().decode()
        try:
            return e.code, json.loads(t)
        except Exception:
            return e.code, t


def check(name, cond, extra=""):
    global fails
    if not cond:
        fails += 1
    print(("OK   " if cond else "FAIL ") + name + (f"  [{extra}]" if extra != "" else ""))
    return cond


def get(path):
    return call("GET", PAP + path)


# ------------------------------------------------------------------ 1) Konsolun okuma ekranları (PAP → PDP görünümleri / PAP DB)
s, tree = get("/api/resources/tree")
check("katalog ağacı", s == 200 and len(tree) > 0, s)
apps = [a for t in tree for a in t["applications"]]
anka = next(a for a in apps if a["code"] == "ANKA")
res = next(r for r in anka["resources"] if r["code"] == "anka.vadelihesap")
s, users = get("/api/users")
check("kullanıcılar (etkin yetki sayılarıyla)", s == 200 and any(u["userName"] == "elif.sahin" for u in users), s)
uid = {u["userName"]: u["id"] for u in users}
s, roles = get("/api/roles")
rid = {r["code"]: r["id"] for r in roles}
s, groups = get("/api/groups")
s, policies = get("/api/policies")
s, perms = get("/api/permissions")
s, rs = get("/api/resource-scopes")
rsid = {x["key"]: x["id"] for x in rs}
s, _ = get("/api/shared-conditions")
check("ortak koşul ucu kalktı (tekrar kullanım birimi policy)", s == 404, s)
polid = {p["code"]: p["id"] for p in policies}
check("ortak koşul yok; tekrar kullanılan parça policy (MESAI)", "MESAI" in polid, sorted(polid)[:5])
s, mesai_saati = get(f"/api/policies/{polid['MESAI']}")
check("MESAI'yi kuralında kullanan policy'ler (referans)",
      s == 200 and {"RAPOR_MESAI_DENEME"} <= {x["code"] for x in mesai_saati["usedBy"]["policies"]}, mesai_saati.get("usedBy") if s == 200 else s)
s, ctypes = get("/api/condition-types")
check("koşul tipleri soru kartı + kimlik bilgisiyle",
      s == 200 and any(t["code"] == "SUBJECT_HAS_ROLE" and t["question"] == "Who" and t["isIdentity"] for t in ctypes)
      and any(t["code"] == "TIME_WINDOW" and t["question"] == "Time" and not t["isIdentity"] for t in ctypes),
      [(t["code"], t.get("question"), t.get("isIdentity")) for t in ctypes if t["code"] in ("SUBJECT_HAS_ROLE", "TIME_WINDOW")] if s == 200 else s)
check("policy'lerde tip yok, her policy kartlardan oluşur", s == 200 and all("type" not in p and "members" not in p for p in policies), policies[0].keys() if policies else s)
rol_gise = next(p for p in policies if p["code"] == "ROL_GISE")
check("eski rol policy'si KİM kartı oldu", any("SUBJECT_HAS_ROLE" in r["expression"] and "GISEAST" in r["expression"] for r in rol_gise["rules"]), rol_gise["rules"])
s, role = get(f"/api/roles/{rid['GISEAST']}")
check("rol sayfası: rolü KİM kartında kullanan policy'ler", s == 200 and any(c["policy"] == "ROL_GISE" for c in role.get("cards", [])), [c["policy"] for c in role.get("cards", [])] if s == 200 else s)
paths = [
    "/api/applications", f"/api/applications/{anka['id']}", "/api/resource-types", "/api/scopes",
    f"/api/resources/{res['id']}", "/api/uri-match?method=GET&path=/v1/vadeli-hesap/123&application=ANKA",
    f"/api/resource-scopes/{rsid['anka.vadelihesap:view']}/holders", f"/api/resource-scopes/{rsid['anka.vadelihesap:view']}/external",
    "/api/clients", f"/api/clients/{1}/secrets", "/api/ownership-teams", "/api/tenants", "/api/org-units",
    f"/api/users/{uid['ayse.yilmaz']}", f"/api/users/{uid['ayse.yilmaz']}/effective", f"/api/users/{uid['ayse.yilmaz']}/entitlements",
    f"/api/users/{uid['ayse.yilmaz']}/external", f"/api/roles/{rid['GISEYTK']}", f"/api/groups/{groups[0]['id']}", "/api/group-criteria",
    f"/api/policies/{policies[0]['id']}", "/api/rules", "/api/obligation-types", "/api/condition-types",
    f"/api/permissions/{perms[0]['id']}",
    "/api/sod/rules", "/api/sod/violations", "/api/external/systems", f"/api/external/dependencies?forResource={res['id']}",
    "/api/external/drift", f"/api/inventory/{anka['id']}/coverage", "/api/options/users", "/api/options/teams",
    "/api/dashboard", "/api/version", "/api/events", "/api/provisioning", "/api/audit",
]
bad = []
for p in paths:
    s, _ = get(p)
    if s != 200:
        bad.append(f"{p} → {s}")
check(f"{len(paths)} konsol okuma ucu 200", not bad, "; ".join(bad))

# ------------------------------------------------------------------ 2) Konsol kararı ve What-If (PAP → PDP analiz)
dec_req = {"subject": {"id": "ayse.yilmaz"}, "permission": "anka.vadelihesap:view", "client": "nextral-api", "context": {"IpAddress": "10.20.30.40"}}
s, d = call("POST", PAP + "/api/console/authorize", dec_req)
check("konsol kararı", s == 200 and d.get("decision") in ("Permit", "Deny"), f"{d.get('decision')} {d.get('reasonCode')}" if s == 200 else d)
s, d = call("POST", PAP + "/api/console/authorize", {**dec_req, "client": "b-portal-web", "caller": "b-portal-web"})
check("konsol kararı: soran client kapsamı", s == 200 and str(d.get("reasonCode", "")).startswith("CALLER"), d.get("reasonCode") if s == 200 else d)
s, e = get("/api/console/entitlements/ayse.yilmaz?client=nextral-api&application=NEXTRAL&caller=nextral-api")
check("konsol yetki listesi (Nextral)", s == 200 and "accesses" in e, s)
s, w = call("POST", PAP + "/api/simulation/evaluate", {"request": dec_req, "asOfUtc": "2026-09-22T08:00:00Z"})
check("What-If kararı (mesai içi an)", s == 200 and w.get("decision") == "Permit", f"{w.get('decision')} {w.get('reasonCode')}" if s == 200 else w)
s, w = call("POST", PAP + "/api/simulation/changes", {"userRoles": [{"userId": uid["elif.sahin"], "roleId": rid["GISEYTK"], "add": True}]})
check("What-If kimlik değişikliği (dryRun)", s == 200 and w.get("dryRun") is True and w.get("affectedUserCount", 0) >= 1, w.get("summary") if s == 200 else w)
s, w = call("POST", PAP + "/api/groups/preview", {"tenantId": 1, "filters": [{"mode": "Include", "criteria": [{"attribute": "ROLE", "values": ["GISEYTK"]}]}]})
check("grup kuralı önizleme", s == 200 and "members" in w, s)
s, w = call("POST", PAP + "/api/groups/preview", {"tenantId": 1, "filters": [{"mode": "Include", "criteria": [{"attribute": "YOK", "values": ["x"]}]}]})
check("grup kuralı önizleme: bilinmeyen kriter → 400", s == 400, s)

# ------------------------------------------------------------------ 3) SoD engeli (PDP hesaplar, PAP reddeder, PIP'e yazılmaz)
s, r = call("POST", PAP + f"/api/users/{uid['ayse.yilmaz']}/roles", {"roleId": rid["SUBEMDR"]})
check("SoD Block → 409", s == 409, r.get("detail", "")[:80] if isinstance(r, dict) else r)
s, ur = call("GET", PIP + f"/api/identity/users/{uid['ayse.yilmaz']}/roles", headers={"X-Service-Key": "pip-demo-key-pap"})
check("engellenen rol PIP'e yazılmadı", s == 200 and all(x["roleId"] != rid["SUBEMDR"] for x in ur), s)

# ------------------------------------------------------------------ 4) Rol ataması: PDP etki → PIP yazımı → PDP yeni yetkiyi görür → worker RACF mutabakatı
elif_id = uid["elif.sahin"]
s, imp = call("POST", PAP + f"/api/users/{elif_id}/roles", {"roleId": rid["GISEYTK"], "reason": "e2e vekalet"})
check("rol ataması uygulandı", s == 200 and imp.get("applied") is True, imp.get("summary") if s == 200 else imp)
u = next((x for x in imp.get("users", []) if x["userName"] == "elif.sahin"), {}) if s == 200 else {}
check("etki: yeni yetki + RACF gereksinimi", any(a["key"] == "anka.nakitcekim:create" for a in u.get("addedAccesses", []))
      and any(g["code"] == "NKC1" for g in u.get("externalGrants", [])), [a["key"] for a in u.get("addedAccesses", [])])
s, eff = get(f"/api/users/{elif_id}/effective")
check("PDP yeni kimliği hemen görüyor (konsol görünümü)", s == 200 and any(a["key"] == "anka.nakitcekim:create" for a in eff["accesses"]), s)
s, tok = call("POST", PDP + "/api/v1/token", {"clientId": "nextral-api", "clientSecret": "ysk_demo_nextral-api"})
auth = {"Authorization": "Bearer " + tok["access_token"]} if s == 200 else {}
time.sleep(1.2)  # karar trafiği kısa önbellekle çalışır (≤ 1 sn)
s, d = call("POST", PDP + "/api/v1/authorize", {"subject": {"id": "elif.sahin"}, "permission": "anka.nakitcekim:create",
                                                 "context": {"IpAddress": "10.20.30.40", "Amount": "1000"}}, auth)
check("PDP karar ucu: yetki artık değerlendirmede (NOT_GRANTED değil)", s == 200 and d.get("reasonCode") != "NO_MATCHING_PERMISSION" and d.get("reasonCode") != "NOT_GRANTED",
      f"{d.get('decision')} {d.get('reasonCode')}" if s == 200 else d)
s, ev = get("/api/events")
check("outbox: RoleAssigned + EffectivePermissionsChanged", s == 200 and any(e["eventType"] == "RoleAssigned" for e in ev)
      and any(e["eventType"] == "EffectivePermissionsChanged" and e["aggregateId"] == str(elif_id) for e in ev), s)

# Worker (ayrı süreç) olayları işlemeli; çalışmıyorsa konsolun "şimdi işle" ucu kullanılır
deadline = time.time() + 15
prov = []
while time.time() < deadline:
    s, prov = get("/api/provisioning")
    if any(p["userId"] == elif_id and p["externalPermissionCode"] == "NKC1" for p in prov):
        break
    time.sleep(1)
if not any(p["userId"] == elif_id and p["externalPermissionCode"] == "NKC1" for p in prov):
    call("POST", PAP + "/api/events/process")
    s, prov = get("/api/provisioning")
check("provisioning: RACF NKC1 Grant tamamlandı", any(p["userId"] == elif_id and p["externalPermissionCode"] == "NKC1" and p["status"] == "Completed" for p in prov),
      len(prov))
s, st = get(f"/api/users/{elif_id}/external")
check("dış sistem durumu senkron", s == 200 and st.get("inSync") is True, [i["action"] for i in st.get("items", []) if i["action"] != "None"])

s, imp = call("DELETE", PAP + f"/api/users/{elif_id}/roles/{rid['GISEYTK']}")
check("rol geri alındı", s == 200 and imp.get("applied") is True, imp.get("summary") if s == 200 else imp)
call("POST", PAP + "/api/events/process")
s, st = get(f"/api/users/{elif_id}/external")
check("geri alma sonrası RACF revoke ile senkron", s == 200 and st.get("inSync") is True, [i["action"] for i in st.get("items", []) if i["action"] != "None"])

# ------------------------------------------------------------------ 5) Tanım değişiklikleri: permission (ModelPatch dryRun + uygula), resource
view_scope = next(x for x in rs if x["key"] == "anka.vadelihesap:view")
s, sc = get(f"/api/scopes?applicationId={anka['id']}")
view_scope_id = next(x["id"] for x in sc if x["code"] == "view")
pol = next(p for p in policies if p["code"] == "ROL_SUBE_PERSONELI")
body = {"applicationId": anka["id"], "code": "E2E_TEST", "name": "e2e", "target": "Resources", "resourceIds": [res["id"]], "scopeIds": [view_scope_id], "policyIds": [pol["id"]]}
s, r = call("POST", PAP + "/api/permissions?dryRun=true", body)
check("permission dryRun (PDP ModelPatch etkisi)", s == 200 and r["impact"]["dryRun"] is True and r.get("id") is None, r["impact"]["summary"] if s == 200 else r)
s, r = call("POST", PAP + "/api/permissions?dryRun=false", body)
check("permission oluşturuldu", s == 200 and r.get("id"), r.get("id") if s == 200 else r)
pid = r.get("id")
s, pd = get(f"/api/permissions/{pid}")
check("PDP görünümü yeni permission'ı hemen gösteriyor", s == 200 and pd["permission"]["code"] == "E2E_TEST" and len(pd["coverage"]) == 1, s)
s, r = call("DELETE", PAP + f"/api/permissions/{pid}?dryRun=false")
check("permission silindi", s == 200, s)

types = get("/api/resource-types")[1]
http_type = next(t for t in types if t["matchesHttp"])
s, r = call("POST", PAP + "/api/resources", {"applicationId": anka["id"], "resourceTypeId": http_type["id"], "code": "anka.e2e", "name": "E2E",
                                            "scopes": [{"scopeId": view_scope_id}], "uris": [{"method": "GET", "pattern": "/v1/e2e/{id}", "scopeId": view_scope_id}]})
check("resource + URI oluşturuldu", s == 200 and r.get("id"), r if s != 200 else r["id"])
new_res = r.get("id")
s, m = get("/api/uri-match?method=GET&path=/v1/e2e/42&application=ANKA")
check("URI eşleşmesi yeni resource'a", s == 200 and (m.get("matched") or {}).get("key") == "anka.e2e:view", m)
s, _ = call("DELETE", PAP + f"/api/resources/{new_res}")
check("resource silindi", s in (200, 204), s)

# ------------------------------------------------------------------ 6) Doğrulama PDP'de: geçersiz condition
s, r = call("POST", PAP + f"/api/policies/{polid['MESAI']}/rules",
            {"code": "E2E_RULE", "name": "x", "order": 1, "condition": {"kind": "Predicate", "conditionTypeCode": "YOK_BOYLE_TIP"}})
check("geçersiz condition tipi → 400 (PDP doğrulaması)", s == 400, s)

# ------------------------------------------------------------------ 6b) Tekrar kullanım = policy referansı; KİM kartı koşul policy'sinin içinde
s, r = call("POST", PAP + "/api/policies", {"tenantId": 1, "code": "E2E_OGLE", "name": "e2e öğle arası"})
check("koşul policy'si oluşturuldu", s == 200 and r.get("id"), r)
ogle = r.get("id")
kim_rule = {"code": "KIM", "name": "Kim", "order": 10, "reasonCode": "NOT_ELIGIBLE",
            "condition": {"kind": "AnyOf", "children": [
                {"kind": "Predicate", "conditionTypeCode": "SUBJECT_HAS_ROLE", "parameters": {"Roles": "GISEAST"}},
                {"kind": "Predicate", "conditionTypeCode": "SUBJECT_IS_USER", "parameters": {"Users": "sibel.ates"}}]}}
s, r = call("POST", PAP + f"/api/policies/{ogle}/rules", kim_rule)
check("KİM kuralı (rol VEYA kullanıcı, tek policy içinde)", s == 200, r)
s, r = call("POST", PAP + f"/api/policies/{ogle}/rules", {"code": "SAAT", "name": "Mesai", "order": 20, "reasonCode": "OUTSIDE_BUSINESS_HOURS",
                                                         "condition": {"kind": "Reference", "policyCode": "MESAI"}})
check("mevcut policy'yi referansla kullanan kural", s == 200, r)
ref_rule = r.get("id") if s == 200 else None
s, r = call("POST", PAP + f"/api/policies/{polid['MESAI']}/rules", {"code": "DONGU", "name": "x", "order": 30,
                                                                         "condition": {"kind": "Reference", "policyCode": "E2E_OGLE"}})
check("döngüsel policy referansı → 400", s == 400, s)
s, r = call("DELETE", PAP + f"/api/policies/{polid['MESAI']}")
check("kullanımdaki (referans verilen) policy silinemez → 409", s == 409, s)
perm_body = {"applicationId": anka["id"], "code": "E2E_OGLE_PERM", "name": "e2e", "target": "Resources", "resourceIds": [res["id"]],
             "scopeIds": [view_scope_id], "policyIds": [ogle]}
s, r = call("POST", PAP + "/api/permissions?dryRun=true", perm_body)
check("permission taslağı: kimlik koşul policy'sinin içinde (koşulsuz erişim uyarısı yok)",
      s == 200 and not any("kimlik şartı" in w for w in r.get("warnings", [])), r.get("warnings") if s == 200 else r)
if ref_rule:
    call("DELETE", PAP + f"/api/rules/{ref_rule}")
s, r = call("DELETE", PAP + f"/api/policies/{ogle}")
check("e2e policy temizlendi", s in (200, 204), s)

# ------------------------------------------------------------------ 6c) KİM kartı = grup kuralı: örtüşme, gruba çevir, karta geri al
gise101 = [{"mode": "Include", "criteria": [{"attribute": "ORG_UNIT", "values": ["101"]}, {"attribute": "ROLE", "values": ["GISEAST"]}]},
           {"mode": "Exclude", "criteria": [{"attribute": "TITLE", "values": ["Stajyer Gişe Asistanı"]}]}]
s, ov = call("POST", PAP + "/api/audiences/overlap", {"filters": gise101})
check("KİM kartı: aynı tanımlı grup önerilir (GISE_101_AST)", s == 200 and any(g["code"] == "GISE_101_AST" and g["sameMembers"] for g in ov["sameDefinitionGroups"]),
      (ov.get("members"), [g["code"] for g in ov.get("sameDefinitionGroups", [])]) if s == 200 else ov)
s, kapsam = get(f"/api/policies/{polid['SUBE_KAPSAMI']}")
hq = next(r for r in kapsam["rules"] if r["code"] == "HQ_928")
s, r = call("POST", PAP + "/api/policies", {"tenantId": 1, "code": "E2E_KIM", "name": "e2e kim"})
kim_pol = r.get("id")
gm928 = [{"mode": "Include", "criteria": [{"attribute": "ORG_UNIT", "values": ["928"]}]}]
s, r = call("POST", PAP + f"/api/policies/{kim_pol}/rules", {"code": "KIM", "name": "KİM", "order": 10,
            "condition": {"kind": "Predicate", "conditionTypeCode": "SUBJECT_IN_UNIT", "parameters": {"Units": "928"}}})
kim_rule = r.get("id") if s == 200 else None
s, ov = call("POST", PAP + "/api/audiences/overlap", {"policyId": kim_pol, "ruleId": kim_rule, "filters": gm928})
check("KİM kartı: aynı tanım başka kartta → grup önerisi (SUBE_KAPSAMI/HQ_928)", s == 200 and any(x["ruleId"] == hq["id"] for x in ov["sameDefinition"]) and ov["canBecomeGroup"],
      [x["rule"] for x in ov.get("sameDefinition", [])] if s == 200 else ov)
s, eff_before = get(f"/api/users/{uid['gul.yuce']}/effective")
promote = {"tenantId": 1, "code": "E2E_GM928", "name": "GM 928 personeli", "filters": gm928, "ruleIds": [hq["id"], kim_rule]}
s, pr = call("POST", PAP + "/api/audiences/promote?dryRun=true", promote)
check("gruba çevir önizleme: kimsenin erişimi değişmez", s == 200 and not any(u["addedAccesses"] or u["removedAccesses"] for u in pr["impact"]["users"]), pr.get("impact", {}).get("summary") if s == 200 else pr)
s, pr = call("POST", PAP + "/api/audiences/promote?dryRun=false", promote)
check("gruba çevrildi", s == 200 and pr.get("groupCode") == "E2E_GM928", pr if s != 200 else pr["groupCode"])
s, kapsam = get(f"/api/policies/{polid['SUBE_KAPSAMI']}")
check("eski kart artık grubu kullanıyor", s == 200 and "SUBJECT_IN_GROUP" in next(r for r in kapsam["rules"] if r["code"] == "HQ_928")["expression"], s)
s, eff_after = get(f"/api/users/{uid['gul.yuce']}/effective")
check("gul.yuce'nin etkin yetkileri aynı", sorted(a["key"] for a in eff_before["accesses"]) == sorted(a["key"] for a in eff_after["accesses"]))
s, grp = get(f"/api/groups/{pr.get('groupId')}")
check("grup detayında KİM kartı kullanımları", s == 200 and len(grp.get("cards", [])) == 2, s)
s, dm = call("POST", PAP + "/api/audiences/demote?dryRun=false", {"groupId": pr.get("groupId"), "ruleIds": [hq["id"], kim_rule]})
check("karta geri alındı, kullanılmayan grup silindi", s == 200 and dm.get("groupDeleted") is True, dm)
s, kapsam = get(f"/api/policies/{polid['SUBE_KAPSAMI']}")
check("kart yine satır (birim 928)", "SUBJECT_IN_UNIT" in next(r for r in kapsam["rules"] if r["code"] == "HQ_928")["expression"])
if kim_rule: call("DELETE", PAP + f"/api/rules/{kim_rule}")
call("DELETE", PAP + f"/api/policies/{kim_pol}")

# ------------------------------------------------------------------ 7) PIP kimlik dışı öznitelikler (iş günü, izin, müşteri) → PDP koşulları
PIPKEY = {"X-Service-Key": "pip-demo-key-pap"}
s, bd = call("GET", PIP + "/api/calendar/business-days/2026-10-03", headers=PIPKEY)
check("PIP iş günü (cumartesi → false)", s == 200 and bd["isBusinessDay"] is False, bd)
s, lv = call("GET", PIP + f"/api/identity/users/{uid['ayse.yilmaz']}/leave?date=2026-10-01", headers=PIPKEY)
check("PIP izin (geçici: izinde değil)", s == 200 and lv["onLeave"] is False, lv.get("source") if s == 200 else lv)
s, cu = call("GET", PIP + "/api/customers/98123456", headers=PIPKEY)
check("PIP müşteri (98 → personel müşterisi)", s == 200 and cu["isStaff"] is True and cu["isVip"] is False, cu)
s, lm = call("GET", PIP + f"/api/limits/users/{uid['ayse.yilmaz']}?type=CASH&date=2026-10-01", headers=PIPKEY)
check("PIP limit (günlük = işlem başı × 3, kullanılan 0)", s == 200 and lm["usedToday"] == 0 and lm["dailyLimit"] == lm["perTransactionLimit"] * 3, lm)
s, un = call("GET", PIP + f"/api/identity/users/{uid['ayse.yilmaz']}/unit", headers=PIPKEY)
check("PIP personelin birimi", s == 200 and un.get("unitCode"), un)
s, ctypes = get("/api/condition-types")
codes = {t["code"] for t in ctypes} if s == 200 else set()
new_types = {"BUSINESS_DAY", "CUSTOMER_IS_VIP", "CUSTOMER_IS_STAFF", "AMOUNT_EXCEEDS_DAILY_LIMIT"}
check("yeni koşul tipleri katalogda, DEVICE_COMPLIANT yok", new_types <= codes and "DEVICE_COMPLIANT" not in codes, sorted(codes & (new_types | {"DEVICE_COMPLIANT"})))
mesai = next(p for p in policies if p["code"] == "MESAI")
staff_rule = {"policyId": mesai["id"], "code": "E2E_STAFF", "order": 1, "reasonCode": "STAFF_CUSTOMER",
              "condition": {"kind": "Not", "children": [{"kind": "Predicate", "conditionTypeCode": "CUSTOMER_IS_STAFF"}]}}
cash = {"subject": {"id": "ayse.yilmaz"}, "permission": "anka.nakitcekim:create", "client": "nextral-api",
        "context": {"IpAddress": "10.20.30.40", "TransactionAmount": "1000", "CustomerId": "98123456", "IsStaff": "false"}}
s, d = call("POST", PAP + "/api/simulation/evaluate", {"request": cash, "asOfUtc": "2026-09-22T08:00:00Z", "policyChanges": {"addedRules": [staff_rule]}})
check("What-If: personel müşterisinde işlem reddedilir (PDP → PIP, istekteki IsStaff yok sayılır)", s == 200 and d.get("reasonCode") == "STAFF_CUSTOMER",
      f"{d.get('decision')} {d.get('reasonCode')}" if s == 200 else d)
cash["context"]["CustomerId"] = "12345678"
s, d = call("POST", PAP + "/api/simulation/evaluate", {"request": cash, "asOfUtc": "2026-09-22T08:00:00Z", "policyChanges": {"addedRules": [staff_rule]}})
check("What-If: normal müşteride kural etkisiz", s == 200 and d.get("decision") == "Permit", f"{d.get('decision')} {d.get('reasonCode')}" if s == 200 else d)
bd_rule = {**staff_rule, "code": "E2E_BDAY", "reasonCode": "NOT_BUSINESS_DAY", "condition": {"kind": "Predicate", "conditionTypeCode": "BUSINESS_DAY"}}
s, d = call("POST", PAP + "/api/simulation/evaluate", {"request": cash, "asOfUtc": "2026-09-26T08:00:00Z", "policyChanges": {"addedRules": [bd_rule]}})
check("What-If: hafta sonu iş günü kuralı reddeder", s == 200 and d.get("decision") != "Permit"
      and any(e["attribute"] == "Environment.IsBusinessDay" and e["value"] == "False" and e["source"].startswith("PIP:stub") for e in d.get("evidence", [])),
      f"{d.get('decision')} {d.get('reasonCode')}" if s == 200 else d)

# ------------------------------------------------------------------ 8) SoD taraması (PDP hesap, PAP kayıt)
s, r = call("POST", PAP + "/api/sod/scan")
check("SoD taraması", s == 200 and r.get("scannedUsers", 0) > 0, {k: r.get(k) for k in ("scannedUsers", "violatingUsers", "newViolations", "autoResolved")} if s == 200 else r)

print()
print("SONUÇ:", "BAŞARILI" if fails == 0 else f"{fails} HATA")
sys.exit(1 if fails else 0)
