# Yetki-Web — Proje Notları (React Admin Dashboard)

> Bu dosya, projeye daha sonra dönüldüğünde (insan veya AI asistan) **genel resmi, detayları, dikkat edilmesi gerekenleri ve TODO'ları** hızlıca hatırlamak içindir.
> Kaynak gereksinim dokümanı: `../authorization-engine-prototype-context.md`
> Backend notları (domain, karar motoru, API uçları, seed senaryoları): `../Yetki-Engine/PROJE-NOTLARI.md`

---

## 1. Özet

Yetki yönetim ekibinin kullandığı sade, kurumsal admin paneli. **Hiçbir yetki kararı frontend'de üretilmez**; her şey Yetki Motoru API'sinden (`Yetki-Engine`) gelir. Doğrudan DB erişimi yoktur.

Stack: React 19, TypeScript 6, Vite 8, **Ant Design 6**, react-router-dom 7, dayjs (tr locale). Lint: oxlint.

Yerleşim: sol menü (koyu lacivert) + liste/detay ekranları + modal/drawer.

---

## 2. Çalıştırma

```bash
npm install
npm run dev        # http://localhost:5180  (strictPort)
npm run build      # tsc -b + vite build → dist/
npm run lint       # oxlint
```

Önkoşul: Engine API `http://localhost:5100` çalışıyor olmalı. SDK Demo ekranı için örnek iş uygulaması `http://localhost:5200` çalışmalı (`Yetki-Engine/samples/Yetki.Sample.CashDesk`).

Ortam değişkenleri (opsiyonel, `.env.local`):

| Değişken | Varsayılan |
|---|---|
| `VITE_API_URL` | `http://localhost:5100` |
| `VITE_SAMPLE_APP_URL` | `http://localhost:5200` |

**Port 5180:** Bu makinede 5173'te başka bir uygulama çalıştığı için 5180 seçildi. Port değişirse Engine `appsettings.json → Cors:Origins` ve Sample `Program.cs` CORS listesi güncellenmeli.

---

## 3. Klasör yapısı

```
src/
├─ main.tsx                 ConfigProvider (tema, tr_TR), antd App (message/modal), BrowserRouter
├─ App.tsx                  Route tanımları
├─ index.css
├─ api/
│  ├─ client.ts             fetch sarmalayıcı, ApiError(ProblemDetails), X-Actor header, SDK demo çağrısı
│  └─ types.ts              API sözleşme tipleri (EffectivePermissionSet, AuthorizationDecision, ChangeImpactResult...)
├─ hooks/useApi.ts          useApi(path) (GET + reload), useOptions(kind) (select listeleri), toSelectOptions
├─ layout/AppLayout.tsx     Sol menü, üst bar (yetki versiyonu, bekleyen outbox rozeti, aktör seçimi) — 5 sn polling
├─ components/
│  ├─ common.tsx            PageHeader, Code, DecisionTag, OutcomeTag, SeverityTag, EnforcementTag, SourceList, fmt
│  ├─ ChangeModal.tsx       ★ Tüm atamalar: hedef seç → What-If önizleme → Uygula
│  ├─ ConditionBuilder.tsx  Condition ağaç editörü (Predicate/NOT/AND/OR/@Ortak koşul) + renderDraft/toDraft (referanslar kopyalanmaz)
│  ├─ ConfirmChangeModal.tsx / PolicyImpact.tsx  Kaldırma ve policy değişikliği etki önizlemeleri
│  ├─ ImpactView.tsx        ChangeImpactResult gösterimi (diff, SoD, RACF gereksinimleri)
│  ├─ DecisionView.tsx      AuthorizationDecision gösterimi (neden, policy/rule tablosu, kanıt, context)
│  └─ EntityFormModal.tsx   Basit tanım CRUD formu (+ soft advisory uyarıları)
└─ pages/
   ├─ DashboardPage.tsx
   ├─ users/UsersPage.tsx, users/UserDetailPage.tsx
   ├─ RolesPages.tsx, PermissionsPages.tsx, GroupsPages.tsx, OrgUnitsPage.tsx
   ├─ PoliciesPages.tsx, RulesPage.tsx, SodPage.tsx
   ├─ EvaluatePage.tsx (EvaluateForm'u What-If de kullanır), WhatIfPage.tsx, SdkDemoPage.tsx
   └─ ExternalPage.tsx, EventsPage.tsx, AuditPage.tsx
```

---

## 4. Ekranlar → API

| Ekran | Ne gösterir / yapar | Başlıca uçlar |
|---|---|---|
| Genel Bakış | Sayılar, son kararlar, son değişiklikler, son provisioning | `GET /api/dashboard` |
| Kullanıcılar / detay | Arama; **effective yetkiler + kaynak yolu**, roller (doğrudan/effective), grup üyelik nedenleri, legacy doğrudan permission, birimler, SoD ihlalleri, provisioning | `/api/users…`, `/api/users/{id}/effective` |
| Roller / detay | Rol permission'ları (ekle → fan-out önizleme), sahipler, grup ilişkileri | `/api/roles…` |
| Permission'lar / detay | Policy bağlama, RACF/LDAP eşleme, **"kimde var, neden?"** | `/api/permissions…`, `…/holders` |
| Gruplar / detay | Kitle (kullanıcı/rol/birim) + grant (permission/rol) + çözümlenmiş üyeler | `/api/groups…` |
| Birimler (`/units`) | Şube ve GM birimleri (hiyerarşi sadece bilgi) | `/api/org-units` |
| Policy'ler / detay | Combining algoritması + sürüm; rule'lar (sıra, Effect, Condition ifadesi, reason); **rule ekle/düzenle** (`RuleModal` + `ConditionBuilder`: Predicate/NOT/AND/OR ağacı, parametre formu ConditionType şemasından) ve **sil** — hepsi önce `PolicyChangeModal` etki analizi | `/api/policies…`, `/api/policies/{id}/rules`, `/api/rules/{id}` |
| Ortak Koşullar (`/shared-conditions`) | Ortak tanımlar (banka ağı, mesai, eşikler): kapsam, tanım, kullanım yerleri (drawer, transitif), sürüm; oluştur/düzenle (ConditionBuilder), kullanımdaysa **"Etkisini gör ve kaydet…"** (tüm kullanan policy'ler için What-If); kullanımdaki silinemez/pasifleştirilemez | `/api/shared-conditions…` |
| Rule & Condition Tipleri | Tüm policy'lerdeki rule'ların genel görünümü (Effect + Condition ifadesi); ConditionType kataloğu (TRUE anlamı, parametreler, okunan attribute'lar) | `/api/rules`, `/api/condition-types` |
| SoD & İhlaller | Kural CRUD (+ "mevcutta kaç ihlal?" önizleme), ihlal listesi ve durum yönetimi, **retrospektif tarama** | `/api/sod/…`, `/api/simulation/sod-rule` |
| Yetki Testi | Gerçek karar veya simülasyon (zaman seçilebilir), hazır senaryo butonları. Sonuç: Permit/Deny/NotApplicable/Indeterminate, karar veren policy/rule, her rule'un Effect/condition sonucu/iz ağacı, kullanılan attribute değerleri | `/api/authorization/evaluate`, `/api/simulation/evaluate` |
| What-If | Sekmeler: **Rol → yetki ekle/çıkar**, **Kullanıcı → rol/yetki/grup/birim ver/al**, **Grup değişikliği**, **Policy / Rule değişikliği** (A: rule çıkar/pasifleştir/effect değiştir + algoritma + policy aktifliği, B: permission↔policy, C: taslak rule ekle (ConditionBuilder), D: condition parametresi değiştir (ORTAK işaretliler tüm kullananları etkiler), E: ortak koşul tanımını değiştir), karar simülasyonu, SoD kuralı etkisi. Seçimler mevcut duruma göre (çıkarılacak = mevcutlar, eklenecek = diğerleri). Derin link: `?tab=role&roleId=`, `?tab=user&userId=`, `?tab=group&groupId=`, `?tab=policy&policyId=&permissionId=` | `/api/simulation/changes`, `/api/simulation/policy-impact` |
| SDK Demo | Örnek iş uygulamasına X-User/X-Channel ile istek; iş kodu örneği | `http://localhost:5200/api/...` |
| Dış Sistemler | RACF/LDAP sistemleri, dış yetkiler, hangi permission'ların gerektirdiği | `/api/external/systems` |
| Event & Provisioning | Outbox event'leri (payload), provisioning aksiyonları, "şimdi işlet" | `/api/events/*` |
| Audit | Filtreli liste + detay drawer (JSON) | `/api/audit` |

---

## 5. Tasarım prensipleri (bozulmamalı)

1. **Frontend karar vermez.** Buton gizleme vb. bile UX amaçlıdır; güvenlik API'dedir.
2. **Önce önizle, sonra uygula:** Yetki değiştiren her işlem önce etkiyi gösterir:
   - Ekleme (seçim gerektiren): `ChangeModal` → `/api/simulation/changes`
   - Kaldırma (rolden permission, kullanıcıdan rol/permission/birim/grup, gruptan kayıt): `ConfirmChangeModal` → "kim kaybeder / kim başka kaynaktan korur"
   - Policy/rule değişiklikleri (policy'ye rule ekle/çıkar, permission'a policy bağla/ayır, rule parametresi kaydet): `PolicyChangeModal` → `/api/simulation/policy-impact` (varsayılan 3 senaryo, bir sonraki iş günü 11:00)
   SoD `Block` varsa "Uygula" pasiftir; kayıp/Allow→Deny varsa buton kırmızıdır. Uygulamada 409 dönerse modal, dönen etki analizini gösterir.
   - Etki görünümleri: `ImpactView` (özet sayılar + "Kim, hangi yetki" / kullanıcı bazlı / yetki bazlı + CSV), `PolicyImpactView` (karar değişimleri, yapısal fark, etkilenen kullanıcılar + CSV). Senaryo editörü: `ScenarioEditor` (`@userBranch` desteği).
3. **Açıklanabilirlik görünür olmalı:** Permission listelerinde her zaman kaynak yolu (`SourceList`), kararlarda reason code + rule tablosu + kanıt.
4. **Soft advisory engellemez:** Yeni permission/grup oluştururken API'nin döndürdüğü `advisories` sarı uyarı olarak gösterilir, işlem zaten yapılmıştır.
5. Sade kurumsal görünüm: tek tema rengi `#1f4e79`, sol menü `#0f2740`.

---

## 6. DİKKAT EDİLMESİ GEREKENLER

- **Karar modeli:** `DecisionType` = `Permit | Deny | NotApplicable | Indeterminate`; sadece `Permit` izinlidir (`isAllowed`). Eski `Allow` değeri yok.
- **Context anahtarları:** `CustomerId` (eski CustomerNo), `Platform`; nakit çekim testlerinde `IpAddress` girilmeli (banka ağı rule'u). `CurrentTime` motor tarafından üretilir.
- `/api/authorization/evaluate` isteği `{ subject: { userName }, permission, action?, resource?, context }` biçimindedir.
- **antd v6** kullanılıyor (v5 değil): `Modal destroyOnHidden` (destroyOnClose değil), `Drawer size`, dikey yerleşim için `Space direction` yerine `<Flex vertical>` tercih edildi. Yeni bileşen eklerken v6 API'sine bakın.
- **Aktör (X-Actor):** Üst bardaki seçim `localStorage['yetki.actor']`'da tutulur ve her isteğe `X-Actor` header'ı olarak eklenir. **Prototip** — gerçek kimlik doğrulama yok; audit'teki "kim yaptı" bilgisi buradan gelir.
- **SDK Demo `X-User`/`X-Channel`:** Örnek uygulama prototip modunda bu header'lara güvenir. Üretimde kullanıcı token'dan, kanal gateway'den gelir.
- **Mesai dışı DENY normaldir:** Policy'li işlemler (CASH_WITHDRAW, CREDIT_APPROVE...) mesai dışında reddedilir. Test için "Simülasyon" modunda karar anını seçin (varsayılan: bir sonraki iş günü 11:00).
- Tarih gösterimi yerel saat (dayjs tr); API UTC döner/alır (`toISOString()`).
- `useApi` basit bir hook'tur (cache yok, istek iptali sadece "cancelled" bayrağı). `useOptions` her mount'ta liste çeker; kullanıcı seçim listesi ilk 200 kullanıcıyla sınırlı (`pageSize=200`) — büyük veride uzaktan arama gerekir.
- Kullanıcı detayında provisioning sekmesi, outbox işleyicisi ~2 sn'de bir çalıştığı için atamadan 2.5 sn sonra yenilenir.
- Build uyarısı: tek chunk ~1.3 MB (antd). Kod bölme TODO.
- oxlint uyarıları (only-export-components, set-state-in-effect) bilinçli olarak bırakıldı; işlevsel sorun değil.

---

## 7. TODO

- [ ] Gerçek kimlik doğrulama (OIDC/MSAL) ve aktörün token'dan gelmesi; X-Actor seçicisini kaldır
- [ ] Yönetim ekranlarının kendisinin yetkilendirilmesi (login-time permission seti ile menü/buton görünürlüğü; `GET /api/authorization/users/{u}/permissions`)
- [ ] 4-göz onay akışı ekranları (talep → onay), yetki talep formu
- [ ] Süreli atama (`validUntil`) girişi ve süresi dolacaklar listesi
- [ ] Sunucu tarafı sayfalama/arama (roller, permission'lar, audit, kullanıcı seçiciler için uzaktan arama)
- [ ] Veri katmanı: TanStack Query (cache, invalidation, retry) + OpenAPI'den tip üretimi (`types.ts` elle yazıldı)
- [ ] Route bazlı code splitting (React.lazy), error boundary, 404 sayfası
- [ ] Testler: Vitest + React Testing Library, Playwright ile uçtan uca başarı hikâyesi (doküman §19)
- [ ] Rol benzerliği / duplicate analizi gibi advisory ekranları (backend hazır olunca)
- [ ] Periyodik access review ekranları, ihlal atama/sahiplik (kim çözecek)
- [ ] Provisioning bildirimleri için gerçek zamanlı kanal (SSE/SignalR) — şu an 5 sn polling
- [ ] Erişilebilirlik ve i18n (şu an sadece Türkçe metinler bileşenlerin içinde)
