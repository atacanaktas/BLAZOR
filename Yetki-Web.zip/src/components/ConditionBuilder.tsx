import { Button, Card, Flex, Input, Select, Tooltip, Typography } from 'antd'
import { DeleteOutlined, PlusOutlined } from '@ant-design/icons'
import type { ConditionDraft, ConditionKind, ConditionTypeInfo, ConditionView, ParamDef, SharedConditionInfo } from '../api/types'

export const emptyPredicate = (): ConditionDraft => ({ kind: 'Predicate', conditionTypeCode: undefined, parameters: {}, children: [] })

/** API gösterimini (ConditionView) düzenlenebilir taslağa çevirir. */
export function toDraft(v?: ConditionView): ConditionDraft {
  if (!v) return emptyPredicate()
  // Referansın çözülmüş çocukları KOPYALANMAZ; referans olarak kalır (tanım ortak koşulda yönetilir)
  if (v.kind === 'Reference') return { kind: 'Reference', sharedConditionCode: v.sharedCondition, parameters: {}, children: [] }
  return { kind: v.kind, conditionTypeCode: v.conditionType, parameters: { ...v.parameters }, children: v.children.map(toDraft) }
}

/** Taslağın okunur gösterimi: NOT TIME_WINDOW(Start=09:00, ...) */
export function renderDraft(d: ConditionDraft): string {
  if (d.kind === 'Reference') return `@${d.sharedConditionCode ?? '?'}`
  if (d.kind === 'Not') return `NOT ${d.children[0] ? renderDraft(d.children[0]) : '?'}`
  if (d.kind === 'AllOf' || d.kind === 'AnyOf') return '(' + d.children.map(renderDraft).join(d.kind === 'AllOf' ? ' AND ' : ' OR ') + ')'
  const ps = Object.entries(d.parameters).filter(([, v]) => v !== '').sort(([a], [b]) => a.localeCompare(b))
  return ps.length ? `${d.conditionTypeCode ?? '?'}(${ps.map(([k, v]) => `${k}=${v}`).join(', ')})` : d.conditionTypeCode ?? '?'
}

const kindOptions = [
  { value: 'Predicate', label: 'Koşul (predicate)' },
  { value: 'Not', label: 'DEĞİL (NOT)' },
  { value: 'AllOf', label: 'VE (AND)' },
  { value: 'AnyOf', label: 'VEYA (OR)' },
  { value: 'Reference', label: 'Ortak koşul (@referans)' },
]

/**
 * Condition ifade ağacı editörü: Predicate / NOT / AND / OR.
 * Predicate parametre formu, ConditionType'ın (handler descriptor) parametre şemasından üretilir.
 */
export function ConditionBuilder({ value, onChange, types, shared = [], excludeShared, depth = 0 }: {
  value: ConditionDraft
  onChange: (v: ConditionDraft) => void
  types: ConditionTypeInfo[]
  /** Referans verilebilecek ortak koşullar */
  shared?: SharedConditionInfo[]
  /** Ortak koşul düzenlerken kendisi (kendine referans engeli) */
  excludeShared?: string
  depth?: number
}) {
  const setKind = (kind: ConditionKind) => {
    if (kind === value.kind) return
    if (kind === 'Predicate') onChange(emptyPredicate())
    else if (kind === 'Reference') onChange({ kind, sharedConditionCode: undefined, parameters: {}, children: [] })
    else if (kind === 'Not') onChange({ kind, parameters: {}, children: [value.kind === 'Predicate' ? value : emptyPredicate()] })
    else onChange({ kind, parameters: {}, children: value.kind === 'Predicate' ? [value] : value.children.length ? value.children : [emptyPredicate()] })
  }
  const setChild = (i: number, c: ConditionDraft) => onChange({ ...value, children: value.children.map((x, j) => (j === i ? c : x)) })

  const type = types.find((t) => t.code === value.conditionTypeCode)
  const ref = shared.find((x) => x.code === value.sharedConditionCode)
  const params: ParamDef[] = type ? JSON.parse(type.parameterSchemaJson) : []

  return (
    <Card size="small" style={{ background: depth % 2 ? '#fafbfc' : '#fff', marginBottom: 6 }} styles={{ body: { padding: 10 } }}>
      <Flex gap={8} wrap align="center">
        <Select size="small" value={value.kind} onChange={setKind} options={kindOptions} style={{ width: 160 }} />
        {value.kind === 'Predicate' && (
          <Select
            size="small"
            showSearch
            placeholder="Condition tipi"
            value={value.conditionTypeCode}
            onChange={(code) => {
              const t = types.find((x) => x.code === code)
              const defs: ParamDef[] = t ? JSON.parse(t.parameterSchemaJson) : []
              onChange({ ...value, conditionTypeCode: code, parameters: Object.fromEntries(defs.map((p) => [p.key, p.defaultValue ?? ''])) })
            }}
            options={types.filter((t) => t.isAvailable).map((t) => ({ value: t.code, label: `${t.code} — ${t.name}` }))}
            style={{ minWidth: 300, flex: 1 }}
            optionFilterProp="label"
          />
        )}
        {value.kind === 'Reference' && (
          <Select
            size="small"
            showSearch
            placeholder="Ortak koşul seçin"
            value={value.sharedConditionCode}
            onChange={(code) => onChange({ ...value, sharedConditionCode: code })}
            options={shared.filter((x) => x.isActive && x.code !== excludeShared).map((x) => ({ value: x.code, label: `@${x.code} — ${x.name}` }))}
            style={{ minWidth: 300, flex: 1 }}
            optionFilterProp="label"
          />
        )}
      </Flex>
      {value.kind === 'Reference' && ref && (
        <Typography.Paragraph type="secondary" style={{ fontSize: 12, margin: '6px 0 0' }}>
          = {ref.expression} · v{ref.version} · {ref.scope === 'Domain' ? `domain: ${ref.domain}` : 'global'} — tanım ortak koşulda yönetilir, burada kopyalanmaz.
        </Typography.Paragraph>
      )}
      {value.kind === 'Predicate' && type && (
        <>
          <Typography.Paragraph type="secondary" style={{ fontSize: 12, margin: '6px 0' }}>
            TRUE ise: {type.description} {type.requiredAttributes && <>· okur: {type.requiredAttributes}</>}
          </Typography.Paragraph>
          <Flex gap={8} wrap>
            {params.map((p) => (
              <Tooltip key={p.key} title={p.description}>
                <Input
                  size="small"
                  addonBefore={p.key + (p.required ? '*' : '')}
                  placeholder={p.defaultValue}
                  value={value.parameters[p.key] ?? ''}
                  onChange={(e) => onChange({ ...value, parameters: { ...value.parameters, [p.key]: e.target.value } })}
                  style={{ width: p.type === 'list' ? 420 : 220 }}
                />
              </Tooltip>
            ))}
          </Flex>
        </>
      )}
      {value.kind !== 'Predicate' && value.kind !== 'Reference' && (
        <div style={{ marginTop: 8, paddingLeft: 12, borderLeft: '2px solid #d6e4ff' }}>
          {value.children.map((c, i) => (
            <Flex key={i} gap={4} align="flex-start">
              <div style={{ flex: 1 }}>
                <ConditionBuilder value={c} onChange={(x) => setChild(i, x)} types={types} shared={shared} excludeShared={excludeShared} depth={depth + 1} />
              </div>
              {value.kind !== 'Not' && value.children.length > 1 && (
                <Button size="small" type="text" icon={<DeleteOutlined />} onClick={() => onChange({ ...value, children: value.children.filter((_, j) => j !== i) })} />
              )}
            </Flex>
          ))}
          {value.kind !== 'Not' && (
            <Button size="small" icon={<PlusOutlined />} onClick={() => onChange({ ...value, children: [...value.children, emptyPredicate()] })}>
              Alt koşul ekle
            </Button>
          )}
        </div>
      )}
    </Card>
  )
}
