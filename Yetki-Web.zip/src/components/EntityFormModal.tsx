import { Alert, App, Form, Input, InputNumber, Modal, Select, Switch } from 'antd'
import { useState } from 'react'
import { api } from '../api/client'

export interface FieldDef {
  name: string
  label: string
  type?: 'text' | 'textarea' | 'switch' | 'select' | 'number' | 'multiselect'
  required?: boolean
  disabledOnEdit?: boolean
  options?: { value: string | number; label: string }[]
  placeholder?: string
  tooltip?: string
}

interface Props {
  open: boolean
  title: string
  fields: FieldDef[]
  /** POST (yeni) veya PUT (id varsa) adresi */
  createPath: string
  updatePath?: string
  initial?: Record<string, unknown>
  onClose: () => void
  onSaved: (id?: number) => void
  transform?: (values: Record<string, unknown>) => unknown
}

/** Basit tanım CRUD formu (rol, permission, grup, policy...). */
export function EntityFormModal({ open, title, fields, createPath, updatePath, initial, onClose, onSaved, transform }: Props) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const [saving, setSaving] = useState(false)
  const [advisories, setAdvisories] = useState<string[]>([])
  const editing = !!updatePath

  const submit = async () => {
    const values = await form.validateFields()
    const body = transform ? transform(values) : values
    setSaving(true)
    try {
      if (editing) {
        await api.put(updatePath!, body)
        onSaved()
        onClose()
      } else {
        const r = await api.post<{ id: number; advisories?: string[] }>(createPath, body)
        if (r?.advisories?.length) {
          // Soft advisory: işlemi engellemez, sadece bilgilendirir.
          setAdvisories(r.advisories)
          message.warning('Kaydedildi — benzer kayıt uyarıları var.')
        } else {
          onClose()
        }
        onSaved(r?.id)
      }
      message.success('Kaydedildi')
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <Modal
      open={open}
      title={title}
      onCancel={() => { setAdvisories([]); onClose() }}
      onOk={advisories.length ? () => { setAdvisories([]); onClose() } : submit}
      okText={advisories.length ? 'Kapat' : 'Kaydet'}
      confirmLoading={saving}
      destroyOnHidden
    >
      {advisories.length > 0 && (
        <Alert type="warning" showIcon style={{ marginBottom: 12 }} message="Öneri (engellemez)" description={advisories.map((a) => <div key={a}>{a}</div>)} />
      )}
      <Form form={form} layout="vertical" initialValues={initial ?? { isActive: true }} preserve={false}>
        {fields.map((f) => (
          <Form.Item
            key={f.name}
            name={f.name}
            label={f.label}
            tooltip={f.tooltip}
            rules={f.required ? [{ required: true, message: `${f.label} zorunlu` }] : undefined}
            valuePropName={f.type === 'switch' ? 'checked' : 'value'}
          >
            {f.type === 'switch' ? (
              <Switch />
            ) : f.type === 'textarea' ? (
              <Input.TextArea rows={3} placeholder={f.placeholder} />
            ) : f.type === 'number' ? (
              <InputNumber style={{ width: '100%' }} />
            ) : f.type === 'select' || f.type === 'multiselect' ? (
              <Select options={f.options} mode={f.type === 'multiselect' ? 'multiple' : undefined} showSearch optionFilterProp="label" placeholder={f.placeholder} disabled={editing && f.disabledOnEdit} />
            ) : (
              <Input placeholder={f.placeholder} disabled={editing && f.disabledOnEdit} />
            )}
          </Form.Item>
        ))}
      </Form>
    </Modal>
  )
}
