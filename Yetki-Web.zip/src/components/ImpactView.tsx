import { Alert, Button, Card, Empty, Flex, Segmented, Statistic, Table, Tag, Typography } from 'antd'
import { DownloadOutlined } from '@ant-design/icons'
import { useMemo, useState } from 'react'
import type { ChangeImpactResult, UserImpact } from '../api/types'
import { Code, EnforcementTag, SeverityTag } from './common'
import { downloadCsv } from './csv'

type ChangeKind = 'KAYBEDER' | 'KAZANIR' | 'KORUNUR'

interface FlatRow {
  key: string
  userId: number
  userName: string
  fullName: string
  permission: string
  permissionName: string
  change: ChangeKind
  before: string[]
  after: string[]
  external: string[]
}

const changeColor: Record<ChangeKind, string> = { KAYBEDER: 'red', KAZANIR: 'green', KORUNUR: 'blue' }
const changeLabel: Record<ChangeKind, string> = { KAYBEDER: 'Kaybeder', KAZANIR: 'Kazanır', KORUNUR: 'Korunur (başka kaynaktan)' }

function flatten(users: UserImpact[]): FlatRow[] {
  const rows: FlatRow[] = []
  for (const u of users) {
    const ext = (code: string, list: UserImpact['externalGrants']) =>
      list.filter((e) => e.permissionCode === code).map((e) => `${e.systemCode}:${e.externalPermissionCode}`)
    for (const p of u.removedPermissions)
      rows.push({ key: `${u.userId}-r-${p.code}`, userId: u.userId, userName: u.userName, fullName: u.fullName, permission: p.code, permissionName: p.name, change: 'KAYBEDER', before: p.paths, after: [], external: ext(p.code, u.externalRevokes) })
    for (const p of u.addedPermissions)
      rows.push({ key: `${u.userId}-a-${p.code}`, userId: u.userId, userName: u.userName, fullName: u.fullName, permission: p.code, permissionName: p.name, change: 'KAZANIR', before: [], after: p.paths, external: ext(p.code, u.externalGrants) })
    for (const p of u.retainedPermissions ?? [])
      rows.push({ key: `${u.userId}-k-${p.code}`, userId: u.userId, userName: u.userName, fullName: u.fullName, permission: p.code, permissionName: p.name, change: 'KORUNUR', before: p.beforePaths, after: p.afterPaths, external: [] })
  }
  return rows
}

const Paths = ({ paths }: { paths: string[] }) =>
  paths.length ? (
    <Flex vertical gap={2}>
      {paths.map((p) => <Typography.Text key={p} style={{ fontSize: 12 }}>{p}</Typography.Text>)}
    </Flex>
  ) : <Typography.Text type="secondary">—</Typography.Text>

/**
 * Bir yetki değişikliğinin (RBAC) etkisi:
 *  - kim hangi yetkiyi KAYBEDER / KAZANIR / başka kaynaktan KORUR
 *  - kullanıcı bazlı, yetki bazlı ve detaylı liste görünümleri + CSV
 *  - SoD çakışmaları ve dış sistem (RACF/LDAP) gereksinimleri
 */
export function ImpactView({ impact }: { impact: ChangeImpactResult }) {
  const [view, setView] = useState<'user' | 'permission' | 'flat'>('flat')
  const rows = useMemo(() => flatten(impact.users), [impact])

  const byPermission = useMemo(() => {
    const map = new Map<string, { code: string; name: string; losers: string[]; gainers: string[]; retained: string[] }>()
    for (const r of rows) {
      const e = map.get(r.permission) ?? { code: r.permission, name: r.permissionName, losers: [], gainers: [], retained: [] }
      ;(r.change === 'KAYBEDER' ? e.losers : r.change === 'KAZANIR' ? e.gainers : e.retained).push(r.userName)
      map.set(r.permission, e)
    }
    return [...map.values()].sort((a, b) => a.code.localeCompare(b.code))
  }, [rows])

  const losers = new Set(rows.filter((r) => r.change === 'KAYBEDER').map((r) => r.userId)).size
  const gainers = new Set(rows.filter((r) => r.change === 'KAZANIR').map((r) => r.userId)).size
  const retained = rows.filter((r) => r.change === 'KORUNUR').length
  const externalActions = impact.users.reduce((n, u) => n + u.externalGrants.length + u.externalRevokes.length, 0)

  const exportCsv = () =>
    downloadCsv('yetki-etki-analizi.csv', [
      ['Kullanıcı', 'Ad Soyad', 'Permission', 'Değişim', 'Önceki kaynak', 'Sonraki kaynak', 'Dış sistem'],
      ...rows.map((r) => [r.userName, r.fullName, r.permission, changeLabel[r.change], r.before.join(' | '), r.after.join(' | '), r.external.join(' | ')]),
    ])

  return (
    <Flex vertical gap={12}>
      <Alert
        type={impact.blocked ? 'error' : impact.warnings.length ? 'warning' : impact.applied ? 'success' : 'info'}
        showIcon
        message={impact.blocked ? 'SoD kuralı bu değişikliği ENGELLİYOR' : impact.applied ? 'Değişiklik uygulandı' : impact.dryRun ? 'Önizleme (henüz uygulanmadı)' : 'Sonuç'}
        description={impact.summary}
      />

      <Card size="small">
        <Flex gap={28} wrap>
          <Statistic title="Kapsamdaki kullanıcı" value={impact.evaluatedUserCount ?? impact.users.length} />
          <Statistic title="Yetki kaybeden kullanıcı" value={losers} valueStyle={{ color: losers ? '#cf1322' : undefined }} />
          <Statistic title="Yetki kazanan kullanıcı" value={gainers} valueStyle={{ color: gainers ? '#389e0d' : undefined }} />
          <Statistic title="Başka kaynaktan korunan" value={retained} valueStyle={{ color: retained ? '#1f4e79' : undefined }} />
          <Statistic title="Yeni SoD çakışması" value={impact.blockingConflicts.length + impact.warnings.length} valueStyle={{ color: impact.blockingConflicts.length ? '#cf1322' : undefined }} />
          <Statistic title="Dış sistem aksiyonu" value={externalActions} />
        </Flex>
      </Card>

      {impact.blockingConflicts.length > 0 && (
        <Alert type="error" message="Engelleyici SoD çakışmaları"
          description={impact.blockingConflicts.map((c, i) => <div key={i}><b>{c.userName}</b>: {c.conflict.code} — {c.conflict.matchedMembers.map((m) => m.code).join(' + ')}</div>)} />
      )}
      {impact.warnings.length > 0 && (
        <Alert type="warning" message="SoD uyarıları (değişiklik uygulanabilir, ihlal kaydı açılır)"
          description={impact.warnings.map((c, i) => <div key={i}><b>{c.userName}</b>: {c.conflict.code} — {c.conflict.matchedMembers.map((m) => m.code).join(' + ')}</div>)} />
      )}

      {impact.users.length === 0 ? (
        <Empty description={`Kapsamdaki ${impact.evaluatedUserCount ?? 0} kullanıcının effective yetkilerinde değişiklik yok`} />
      ) : (
        <>
          <Flex justify="space-between" wrap gap={8}>
            <Segmented value={view} onChange={(v) => setView(v as typeof view)}
              options={[{ value: 'flat', label: 'Kim, hangi yetki' }, { value: 'user', label: 'Kullanıcı bazlı' }, { value: 'permission', label: 'Yetki bazlı' }]} />
            <Button icon={<DownloadOutlined />} onClick={exportCsv}>CSV</Button>
          </Flex>

          {view === 'flat' && (
            <Table<FlatRow>
              size="small"
              rowKey="key"
              dataSource={rows}
              pagination={rows.length > 15 ? { pageSize: 15 } : false}
              columns={[
                { title: 'Kullanıcı', render: (_, r) => <><b>{r.userName}</b><br /><Typography.Text type="secondary">{r.fullName}</Typography.Text></>, sorter: (a, b) => a.userName.localeCompare(b.userName) },
                { title: 'Permission', render: (_, r) => <><Code>{r.permission}</Code><br /><Typography.Text type="secondary">{r.permissionName}</Typography.Text></>, sorter: (a, b) => a.permission.localeCompare(b.permission) },
                {
                  title: 'Değişim',
                  render: (_, r) => <Tag color={changeColor[r.change]}>{changeLabel[r.change]}</Tag>,
                  filters: (Object.keys(changeLabel) as ChangeKind[]).map((k) => ({ text: changeLabel[k], value: k })),
                  onFilter: (v, r) => r.change === v,
                },
                { title: 'Şu anki kaynak', render: (_, r) => <Paths paths={r.before} /> },
                { title: 'Değişiklik sonrası kaynak', render: (_, r) => <Paths paths={r.after} /> },
                { title: 'Dış sistem', render: (_, r) => r.external.map((e) => <Tag key={e} color={r.change === 'KAYBEDER' ? 'volcano' : 'cyan'}>{r.change === 'KAYBEDER' ? 'REVOKE' : 'GRANT'} {e}</Tag>) },
              ]}
            />
          )}

          {view === 'user' && (
            <Table<UserImpact>
              size="small"
              rowKey="userId"
              dataSource={impact.users}
              pagination={impact.users.length > 10 ? { pageSize: 10 } : false}
              columns={[
                { title: 'Kullanıcı', render: (_, u) => <><b>{u.userName}</b><br /><Typography.Text type="secondary">{u.fullName}</Typography.Text></> },
                {
                  title: 'Yetki değişimi',
                  render: (_, u) => (
                    <Flex wrap gap={4}>
                      {u.removedPermissions.map((p) => <Tag key={'r' + p.code} color="red" title={p.paths.join('\n')}>− {p.code}</Tag>)}
                      {u.addedPermissions.map((p) => <Tag key={'a' + p.code} color="green" title={p.paths.join('\n')}>+ {p.code}</Tag>)}
                      {(u.retainedPermissions ?? []).map((p) => <Tag key={'k' + p.code} color="blue" title={'Sonraki kaynak:\n' + p.afterPaths.join('\n')}>= {p.code}</Tag>)}
                    </Flex>
                  ),
                },
                {
                  title: 'Rol / grup',
                  render: (_, u) => (
                    <Flex wrap gap={4}>
                      {[...u.addedRoles.map((r) => `+rol ${r}`), ...u.removedRoles.map((r) => `−rol ${r}`), ...u.addedGroups.map((g) => `+grup ${g}`), ...u.removedGroups.map((g) => `−grup ${g}`)].map((t) => <Tag key={t}>{t}</Tag>)}
                    </Flex>
                  ),
                },
                {
                  title: 'Dış sistem',
                  render: (_, u) => (
                    <Flex vertical gap={2}>
                      {u.externalGrants.map((e, i) => <span key={'g' + i}><Tag color="cyan">GRANT</Tag>{e.systemCode}: {e.externalPermissionCode}</span>)}
                      {u.externalRevokes.map((e, i) => <span key={'v' + i}><Tag color="volcano">REVOKE</Tag>{e.systemCode}: {e.externalPermissionCode}</span>)}
                    </Flex>
                  ),
                },
                {
                  title: 'Yeni SoD',
                  render: (_, u) => u.newSodConflicts.map((c) => <div key={c.code}><EnforcementTag enforcement={c.enforcement} /> <SeverityTag severity={c.severity} /> {c.code}</div>),
                },
              ]}
            />
          )}

          {view === 'permission' && (
            <Table
              size="small"
              rowKey="code"
              dataSource={byPermission}
              pagination={false}
              columns={[
                { title: 'Permission', render: (_, p) => <><Code>{p.code}</Code><br /><Typography.Text type="secondary">{p.name}</Typography.Text></> },
                { title: 'Kaybeden kullanıcılar', render: (_, p) => <><Tag color="red">{p.losers.length}</Tag>{p.losers.join(', ')}</> },
                { title: 'Kazanan kullanıcılar', render: (_, p) => <><Tag color="green">{p.gainers.length}</Tag>{p.gainers.join(', ')}</> },
                { title: 'Korunan (başka kaynak)', render: (_, p) => <><Tag color="blue">{p.retained.length}</Tag>{p.retained.join(', ')}</> },
              ]}
            />
          )}
        </>
      )}
    </Flex>
  )
}
