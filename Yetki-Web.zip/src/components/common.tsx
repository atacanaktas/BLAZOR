import { Flex, Tag, Tooltip, Typography } from 'antd'
import {
  ApartmentOutlined,
  KeyOutlined,
  SafetyCertificateOutlined,
  TeamOutlined,
  UserOutlined,
} from '@ant-design/icons'
import type { ReactNode } from 'react'
import dayjs from 'dayjs'
import type { CombiningAlgorithm, DecisionType, PermissionSource, RuleEffect, TriState } from '../api/types'

export function PageHeader({ title, subtitle, extra }: { title: string; subtitle?: ReactNode; extra?: ReactNode }) {
  return (
    <Flex justify="space-between" align="flex-start" gap={16} wrap style={{ marginBottom: 16 }}>
      <div>
        <Typography.Title level={3} style={{ margin: 0 }}>
          {title}
        </Typography.Title>
        {subtitle && <Typography.Text type="secondary">{subtitle}</Typography.Text>}
      </div>
      {extra}
    </Flex>
  )
}

export const Code = ({ children }: { children: ReactNode }) => (
  <Typography.Text code style={{ whiteSpace: 'nowrap' }}>
    {children}
  </Typography.Text>
)

export const fmt = (d?: string | null) => (d ? dayjs(d).format('DD.MM.YYYY HH:mm:ss') : '—')

export function ActiveTag({ active }: { active: boolean }) {
  return active ? <Tag color="green">Aktif</Tag> : <Tag>Pasif</Tag>
}

const decisionColor: Record<DecisionType, string> = { Permit: 'green', Deny: 'red', NotApplicable: 'default', Indeterminate: 'orange' }
const decisionLabel: Record<DecisionType, string> = { Permit: 'PERMIT', Deny: 'DENY', NotApplicable: 'NOT APPLICABLE', Indeterminate: 'INDETERMINATE' }

/** Karar / rule sonucu: Permit · Deny · NotApplicable · Indeterminate */
export function DecisionTag({ decision }: { decision?: string | null }) {
  if (!decision) return <Tag>—</Tag>
  const d = decision as DecisionType
  return <Tag color={decisionColor[d] ?? 'default'}>{decisionLabel[d] ?? decision}</Tag>
}

const triColor: Record<TriState, string> = { True: 'blue', False: 'default', Indeterminate: 'orange' }

/** Condition sonucu (üç değerli mantık) */
export function TriTag({ value }: { value: TriState }) {
  return <Tag color={triColor[value]}>{value === 'True' ? 'TRUE' : value === 'False' ? 'FALSE' : 'BELİRSİZ'}</Tag>
}

export function EffectTag({ effect }: { effect: RuleEffect | string }) {
  return effect === 'Permit' ? <Tag color="green">PERMIT</Tag> : <Tag color="red">DENY</Tag>
}

export const algorithmLabel: Record<CombiningAlgorithm, string> = {
  DenyOverrides: 'Deny-overrides',
  PermitOverrides: 'Permit-overrides',
  FirstApplicable: 'First-applicable',
}

export const algorithmHelp: Record<CombiningAlgorithm, string> = {
  DenyOverrides: 'Herhangi bir Deny → Deny; yoksa belirsizlik → Indeterminate; yoksa Permit → Permit; yoksa NotApplicable.',
  PermitOverrides: 'Herhangi bir Permit → Permit; yoksa belirsizlik → Indeterminate; yoksa Deny → Deny; yoksa NotApplicable.',
  FirstApplicable: 'Sıraya göre NotApplicable olmayan ilk rule\'un sonucu.',
}

export function AlgorithmTag({ algorithm }: { algorithm: CombiningAlgorithm }) {
  return <Tag color="geekblue" title={algorithmHelp[algorithm]}>{algorithmLabel[algorithm] ?? algorithm}</Tag>
}

export function SeverityTag({ severity }: { severity: string }) {
  const color = { Critical: 'magenta', High: 'red', Medium: 'orange', Low: 'blue' }[severity] ?? 'default'
  return <Tag color={color}>{severity}</Tag>
}

export function EnforcementTag({ enforcement }: { enforcement: string }) {
  return enforcement === 'Block' ? <Tag color="red">ENGELLE</Tag> : <Tag color="gold">UYAR</Tag>
}

const sourceMeta: Record<string, { icon: ReactNode; color: string; label: string }> = {
  DirectRole: { icon: <SafetyCertificateOutlined />, color: 'blue', label: 'Doğrudan rol' },
  GroupGrantedRole: { icon: <TeamOutlined />, color: 'purple', label: 'Grup → rol' },
  GroupPermission: { icon: <ApartmentOutlined />, color: 'geekblue', label: 'Grup → permission' },
  DirectUser: { icon: <UserOutlined />, color: 'orange', label: 'Doğrudan (legacy)' },
}

/** Permission'ın kaynağı (authorization path). "Bu kullanıcı bu yetkiyi neden aldı?" */
export function SourceList({ sources }: { sources: PermissionSource[] }) {
  return (
    <Flex vertical gap={4}>
      {sources.map((s, i) => {
        const m = sourceMeta[s.type] ?? { icon: <KeyOutlined />, color: 'default', label: s.type }
        return (
          <div key={i}>
            <Tooltip title={m.label}>
              <Tag color={m.color} icon={m.icon}>
                {m.label}
              </Tag>
            </Tooltip>
            <Typography.Text style={{ fontSize: 13 }}>{s.path}</Typography.Text>
          </div>
        )
      })}
    </Flex>
  )
}
