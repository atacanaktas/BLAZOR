import { App, Button, Divider, Flex, Modal, Select, Spin, Typography } from 'antd'
import { useEffect, useState, type ReactNode } from 'react'
import { api, ApiError } from '../api/client'
import type { AuthorizationChangeSet, ChangeImpactResult } from '../api/types'
import { ImpactView } from './ImpactView'

interface Props {
  open: boolean
  title: string
  label: string
  options: { value: number; label: string }[]
  /** Seçilen hedef için change set (What-If önizleme). */
  buildChangeSet: (targetId: number) => AuthorizationChangeSet
  /** Gerçek uygulama (API aynı change set mantığını kullanır). */
  apply: (targetId: number) => Promise<ChangeImpactResult>
  onClose: () => void
  onDone: () => void
  extra?: ReactNode
}

/**
 * Tüm atama işlemleri için ortak akış:
 *   1) hedef seç → 2) What-If önizleme (/api/simulation/changes) → 3) Uygula.
 * Önizleme ile uygulama aynı backend hesaplayıcısını kullanır.
 */
export function ChangeModal({ open, title, label, options, buildChangeSet, apply, onClose, onDone, extra }: Props) {
  const { message } = App.useApp()
  const [target, setTarget] = useState<number>()
  const [preview, setPreview] = useState<ChangeImpactResult>()
  const [loading, setLoading] = useState(false)
  const [applying, setApplying] = useState(false)

  useEffect(() => {
    if (!open) {
      setTarget(undefined)
      setPreview(undefined)
    }
  }, [open])

  useEffect(() => {
    if (target === undefined) return
    setLoading(true)
    setPreview(undefined)
    api
      .post<ChangeImpactResult>('/api/simulation/changes', buildChangeSet(target))
      .then(setPreview)
      .catch((e: Error) => message.error(e.message))
      .finally(() => setLoading(false))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target])

  const doApply = async () => {
    if (target === undefined) return
    setApplying(true)
    try {
      const result = await apply(target)
      if (result.warnings.length) message.warning(`Uygulandı, ${result.warnings.length} SoD uyarısı ile. İhlal kaydı açıldı.`)
      else message.success('Uygulandı. ' + result.summary)
      onDone()
      onClose()
    } catch (e) {
      if (e instanceof ApiError && e.status === 409 && e.problem.details) setPreview(e.problem.details as ChangeImpactResult)
      message.error((e as Error).message)
    } finally {
      setApplying(false)
    }
  }

  return (
    <Modal
      open={open}
      title={title}
      onCancel={onClose}
      width={980}
      destroyOnHidden
      footer={
        <Flex justify="space-between">
          <Typography.Text type="secondary">Önizleme What-If motoruyla hesaplanır; uygulama aynı mantığı kullanır.</Typography.Text>
          <Flex gap={8}>
            <Button onClick={onClose}>Vazgeç</Button>
            <Button type="primary" disabled={!preview || preview.blocked} loading={applying} onClick={doApply}>
              Uygula
            </Button>
          </Flex>
        </Flex>
      }
    >
      <Flex vertical gap={8}>
        <Typography.Text strong>{label}</Typography.Text>
        <Select
          showSearch
          optionFilterProp="label"
          placeholder="Seçiniz"
          value={target}
          onChange={setTarget}
          options={options}
          style={{ width: '100%' }}
        />
        {extra}
      </Flex>
      <Divider />
      {loading && <Spin />}
      {preview && <ImpactView impact={preview} />}
    </Modal>
  )
}
