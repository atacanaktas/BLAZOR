import { Alert, Card, Descriptions, Flex, Table, Tag, Tooltip, Typography } from 'antd'
import type { AuthorizationDecision, ConditionTrace, RuleEvaluation, UsedAttribute } from '../api/types'
import { AlgorithmTag, Code, DecisionTag, EffectTag, SourceList, TriTag, fmt } from './common'

function Evidence({ items }: { items?: UsedAttribute[] }) {
  if (!items?.length) return <Typography.Text type="secondary">—</Typography.Text>
  return (
    <Flex vertical gap={2}>
      {items.map((e, i) => (
        <Typography.Text key={i} style={{ fontSize: 12 }} type={e.resolved ? undefined : 'danger'}>
          <Code>{e.attribute}</Code> = {e.resolved ? (e.value ?? '∅') : 'ÇÖZÜLEMEDİ'} <Typography.Text type="secondary">({e.source})</Typography.Text>
        </Typography.Text>
      ))}
    </Flex>
  )
}

/** Condition ağacı izi: her düğümün değeri (TRUE/FALSE/BELİRSİZ) ve mesajı. */
function TraceTree({ t, depth = 0 }: { t: ConditionTrace; depth?: number }) {
  const label = t.kind === 'Predicate' ? t.conditionType : t.kind === 'Reference' ? t.expression : t.kind === 'AllOf' ? 'AND' : t.kind === 'AnyOf' ? 'OR' : 'NOT'
  return (
    <div style={{ marginLeft: depth * 16 }}>
      <TriTag value={t.value} /> <Code>{label}</Code>{' '}
      {(t.kind === 'Predicate' || (t.kind === 'Reference' && !t.children?.length)) && <Typography.Text style={{ fontSize: 12 }}>{t.message}</Typography.Text>}
      {t.kind === 'Reference' && !!t.children?.length && <Typography.Text type="secondary" style={{ fontSize: 12 }}>ortak koşul</Typography.Text>}
      {t.children?.map((c, i) => <TraceTree key={i} t={c} depth={depth + 1} />)}
    </div>
  )
}

/**
 * Açıklanabilir karar:
 *   Karar + neden + kararı veren policy/rule
 *   → RBAC kaynağı (permission nereden geldi)
 *   → her policy: combining algoritması ve sonucu → her rule: effect, condition sonucu, rule sonucu, kullanılan değerler
 */
export function DecisionView({ decision: d }: { decision: AuthorizationDecision }) {
  const type = d.decision === 'Permit' ? 'success' : d.decision === 'Deny' ? 'error' : 'warning'
  return (
    <Flex vertical gap={12}>
      <Alert
        type={type}
        showIcon
        message={
          <Flex gap={8} align="center" wrap>
            <DecisionTag decision={d.decision} />
            <Code>{d.reasonCode}</Code>
            {d.decidingRule && <Typography.Text type="secondary">karar veren: {d.decidingPolicy} / {d.decidingRule}</Typography.Text>}
            {d.isSimulation && <Tag color="purple">SİMÜLASYON</Tag>}
            {!d.isAllowed && d.decision !== 'Deny' && <Tag>izin verilmez</Tag>}
          </Flex>
        }
        description={d.humanReadableReason}
      />
      <Descriptions size="small" bordered column={{ xs: 1, md: 2 }}>
        <Descriptions.Item label="Subject">{d.userName ?? '—'}</Descriptions.Item>
        <Descriptions.Item label="Permission / Action"><Code>{d.permission}</Code> / {d.action}</Descriptions.Item>
        {d.resource && <Descriptions.Item label="Resource">{d.resource}</Descriptions.Item>}
        <Descriptions.Item label="Decision ID"><Typography.Text copyable style={{ fontSize: 12 }}>{d.decisionId}</Typography.Text></Descriptions.Item>
        <Descriptions.Item label="Zaman / süre">{fmt(d.evaluatedAt)} · {d.durationMs} ms · v{d.authorizationVersion}</Descriptions.Item>
        {d.policies.length > 1 && <Descriptions.Item label="Policy birleştirme"><AlgorithmTag algorithm={d.policyCombiningAlgorithm} /></Descriptions.Item>}
        {d.missingAttributes.length > 0 && (
          <Descriptions.Item label="Eksik attribute" span={2}>
            {d.missingAttributes.map((k) => <Tag color="orange" key={k}>{k}</Tag>)}
          </Descriptions.Item>
        )}
      </Descriptions>

      {d.permissionSources.length > 0 && (
        <Card size="small" title="RBAC: permission kaynağı (neden sahip?)">
          <SourceList sources={d.permissionSources} />
        </Card>
      )}

      {d.policies.map((p) => (
        <Card
          key={p.policyId}
          size="small"
          title={<>Policy: <Code>{p.code}</Code> {p.name} <Typography.Text type="secondary">v{p.version}</Typography.Text></>}
          extra={<Flex gap={4} align="center"><AlgorithmTag algorithm={p.algorithm} /> → <DecisionTag decision={p.result} /></Flex>}
        >
          <Table<RuleEvaluation>
            size="small"
            rowKey={(r) => `${r.ruleId}-${r.code}`}
            pagination={false}
            dataSource={p.rules}
            rowClassName={(r) => (r.isDeciding ? 'ant-table-row-selected' : '')}
            expandable={{
              rowExpandable: (r) => !!r.condition,
              expandedRowRender: (r) => r.condition && <TraceTree t={r.condition} />,
            }}
            columns={[
              { title: '#', dataIndex: 'order', width: 55 },
              {
                title: 'Rule',
                render: (_, r) => (
                  <>
                    <Code>{r.code}</Code> {r.isDeciding && <Tag color="purple">KARAR</Tag>}{!r.isActive && <Tag>pasif</Tag>}
                    <br /><Typography.Text type="secondary">{r.name}</Typography.Text>
                  </>
                ),
              },
              { title: 'Effect', render: (_, r) => <EffectTag effect={r.effect} />, width: 90 },
              {
                title: 'Condition',
                render: (_, r) => (
                  <Tooltip title={r.message}>
                    <TriTag value={r.conditionValue} /> <Typography.Text style={{ fontSize: 12 }}>{r.expression}</Typography.Text>
                  </Tooltip>
                ),
              },
              { title: 'Sonuç', render: (_, r) => <>{<DecisionTag decision={r.result} />}{r.reasonCode && r.result !== 'NotApplicable' && <div><Code>{r.reasonCode}</Code></div>}</>, width: 150 },
              { title: 'Kullanılan değerler', render: (_, r) => <Evidence items={r.evidence} /> },
            ]}
          />
        </Card>
      ))}

      {d.evidence.length > 0 && (
        <Card size="small" title="Değerlendirmede kullanılan tüm attribute'lar (audit'te hassas olanlar maskelenir)">
          <Evidence items={d.evidence} />
        </Card>
      )}

      <Card size="small" title="Request context">
        <Flex wrap gap={4}>
          {Object.entries(d.context).map(([k, v]) => <Tag key={k}>{k}={v}</Tag>)}
        </Flex>
      </Card>
    </Flex>
  )
}
