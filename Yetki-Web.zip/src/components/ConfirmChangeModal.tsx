import { App, Button, Flex, Modal, Spin, Typography } from 'antd'
import { useEffect, useState } from 'react'
import { api, ApiError } from '../api/client'
import type { AuthorizationChangeSet, ChangeImpactResult } from '../api/types'
import { ImpactView } from './ImpactView'

interface Props {
  open: boolean
  title: string
  changeSet: AuthorizationChangeSet
  apply: () => Promise<ChangeImpactResult>
  onClose: () => void
  onDone: () => void
  applyText?: string
}

/**
 * Hedefi belli bir değişiklik (ör. "rolden X'i çıkar", "kullanıcıdan rolü al") için:
 * açılır açılmaz What-If etkisini gösterir, onaylanırsa uygular.
 */
export function ConfirmChangeModal({ open, title, changeSet, apply, onClose, onDone, applyText = 'Onayla ve uygula' }: Props) {
  const { message } = App.useApp()
  const [preview, setPreview] = useState<ChangeImpactResult>()
  const [loading, setLoading] = useState(false)
  const [applying, setApplying] = useState(false)

  useEffect(() => {
    if (!open) {
      setPreview(undefined)
      return
    }
    setLoading(true)
    api
      .post<ChangeImpactResult>('/api/simulation/changes', changeSet)
      .then(setPreview)
      .catch((e: Error) => message.error(e.message))
      .finally(() => setLoading(false))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const doApply = async () => {
    setApplying(true)
    try {
      const r = await apply()
      if (r?.warnings?.length) message.warning(`Uygulandı, ${r.warnings.length} SoD uyarısı ile.`)
      else message.success('Uygulandı. ' + (r?.summary ?? ''))
      onDone()
      onClose()
    } catch (e) {
      if (e instanceof ApiError && e.status === 409 && e.problem.details) setPreview(e.problem.details as ChangeImpactResult)
      message.error((e as Error).message)
    } finally {
      setApplying(false)
    }
  }

  return (
    <Modal
      open={open}
      title={title}
      onCancel={onClose}
      width={1100}
      destroyOnHidden
      footer={
        <Flex justify="space-between">
          <Typography.Text type="secondary">Etki What-If motoruyla hesaplandı; uygulama aynı mantığı kullanır.</Typography.Text>
          <Flex gap={8}>
            <Button onClick={onClose}>Vazgeç</Button>
            <Button type="primary" danger={!!preview?.users.some((u) => u.removedPermissions.length)} disabled={!preview || preview.blocked} loading={applying} onClick={doApply}>
              {applyText}
            </Button>
          </Flex>
        </Flex>
      }
    >
      {loading && <Spin />}
      {preview && <ImpactView impact={preview} />}
    </Modal>
  )
}
