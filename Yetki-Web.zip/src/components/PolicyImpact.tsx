import { Alert, App, Button, Card, Col, Collapse, DatePicker, Empty, Flex, Input, Modal, Row, Spin, Statistic, Table, Tabs, Tag, Tooltip, Typography } from 'antd'
import { DeleteOutlined, DownloadOutlined, PlusOutlined } from '@ant-design/icons'
import { useEffect, useState } from 'react'
import dayjs, { type Dayjs } from 'dayjs'
import { api } from '../api/client'
import type { DecisionChange, ImpactScenario, PermissionPolicyDiff, PolicyChangeSet, PolicyImpactResult } from '../api/types'
import { Code, DecisionTag } from './common'
import { downloadCsv } from './csv'

// ---------------------------------------------------------------- Senaryolar

export const SCENARIO_KEYS = ['TransactionAmount', 'Channel', 'Platform', 'CustomerId', 'BranchCode', 'IpAddress'] as const

export const DEFAULT_SCENARIOS: ImpactScenario[] = [
  { name: 'Tipik vezne işlemi', context: { TransactionAmount: '20000', Channel: 'CASH_DESK', CustomerId: '555', BranchCode: '@userBranch', IpAddress: '10.1.2.3' } },
  { name: 'Yüksek tutar', context: { TransactionAmount: '150000', Channel: 'CASH_DESK', CustomerId: '555', BranchCode: '@userBranch', IpAddress: '10.1.2.3' } },
  { name: 'İnternet / dış IP', context: { TransactionAmount: '20000', Channel: 'INTERNET', Platform: 'MOBILE', CustomerId: '555', BranchCode: '@userBranch', IpAddress: '85.100.1.1' } },
]

export function nextBusinessMorning(): Dayjs {
  let d = dayjs().hour(11).minute(0).second(0)
  if (dayjs().hour() >= 18) d = d.add(1, 'day')
  while (d.day() === 0 || d.day() === 6) d = d.add(1, 'day')
  return d
}

/** Karar karşılaştırmasında kullanılacak örnek context'ler. "@userBranch" = her kullanıcının kendi birimi. */
export function ScenarioEditor({ value, onChange }: { value: ImpactScenario[]; onChange: (v: ImpactScenario[]) => void }) {
  const set = (i: number, key: string, v: string) =>
    onChange(value.map((s, j) => (j !== i ? s : key === '__name' ? { ...s, name: v } : { ...s, context: { ...s.context, [key]: v } })))
  return (
    <Flex vertical gap={6}>
      <Table
        size="small"
        pagination={false}
        rowKey={(_, i) => String(i)}
        dataSource={value}
        scroll={{ x: 760 }}
        columns={[
          { title: 'Senaryo', width: 170, render: (_, s, i) => <Input size="small" value={s.name} onChange={(e) => set(i, '__name', e.target.value)} /> },
          ...SCENARIO_KEYS.map((k) => ({
            title: k,
            render: (_: unknown, s: ImpactScenario, i: number) => <Input size="small" value={s.context[k] ?? ''} onChange={(e) => set(i, k, e.target.value)} />,
          })),
          { width: 40, render: (_, __, i) => <Button size="small" type="text" icon={<DeleteOutlined />} onClick={() => onChange(value.filter((_, j) => j !== i))} /> },
        ]}
      />
      <Flex justify="space-between" align="center">
        <Button size="small" icon={<PlusOutlined />} onClick={() => onChange([...value, { name: `Senaryo ${value.length + 1}`, context: {} }])}>Senaryo ekle</Button>
        <Typography.Text type="secondary" style={{ fontSize: 12 }}>
          <Code>@userBranch</Code> = her kullanıcının kendi birim kodu. Boş alan context'e gönderilmez.
        </Typography.Text>
      </Flex>
    </Flex>
  )
}

export const cleanScenarios = (s: ImpactScenario[]) =>
  s.map((x) => ({ name: x.name, context: Object.fromEntries(Object.entries(x.context).filter(([, v]) => v !== undefined && v !== '')) }))

// ---------------------------------------------------------------- Sonuç görünümü

const changeMeta: Record<DecisionChange, { color: string; label: string }> = {
  NEWLY_DENIED: { color: 'red', label: 'İzin → Red' },
  NEWLY_INDETERMINATE: { color: 'orange', label: 'İzin → Indeterminate' },
  NEWLY_ALLOWED: { color: 'green', label: '→ İzin (Permit)' },
  REASON_CHANGED: { color: 'gold', label: 'Red nedeni değişir' },
  UNCHANGED: { color: 'default', label: 'Değişmez' },
}

function RuleTags({ diff }: { diff: PermissionPolicyDiff }) {
  const key = (r: { policy: string; code: string }) => `${r.policy}/${r.code}`
  const all = new Map([...diff.rulesBefore, ...diff.rulesAfter].map((r) => [key(r), r]))
  return (
    <Flex wrap gap={4}>
      {[...all.entries()].map(([k, r]) => {
        const added = diff.addedRules.includes(k)
        const removed = diff.removedRules.includes(k)
        const changed = diff.changedRules.some((x) => `${x.policy}/${x.ruleCode}` === k)
        return (
          <Tooltip key={k} title={r.expression}>
            <Tag color={added ? 'green' : removed ? 'red' : changed ? 'gold' : 'default'} style={removed ? { textDecoration: 'line-through' } : undefined}>
              {added ? '+ ' : removed ? '− ' : changed ? '~ ' : ''}{r.effect === 'Permit' ? '✓' : '✗'} {r.code}
            </Tag>
          </Tooltip>
        )
      })}
      {all.size === 0 && <Typography.Text type="secondary">policy yok (koşulsuz)</Typography.Text>}
    </Flex>
  )
}

/** Policy What-If sonucu: yapısal fark, yeni gerekli context, senaryolarda karar değişimleri, etkilenen kullanıcılar. */
export function PolicyImpactView({ result }: { result: PolicyImpactResult }) {
  const newCtx = [...new Set(result.permissions.flatMap((p) => p.newRequiredAttributes))]
  const unconditional = result.permissions.filter((p) => p.becomesUnconditional)

  const exportCsv = () =>
    downloadCsv('policy-etki-analizi.csv', [
      ['Kullanıcı', 'Ad Soyad', 'Permission', 'Senaryo', 'Mevcut karar', 'Mevcut neden', 'Yeni karar', 'Yeni neden', 'Değişim'],
      ...result.rows.map((r) => [r.userName, r.fullName, r.permission, r.scenario, r.before.decision, r.before.reasonCode, r.after.decision, r.after.reasonCode, changeMeta[r.change].label]),
    ])

  return (
    <Flex vertical gap={12}>
      <Alert type={result.newlyDenied ? 'warning' : 'info'} showIcon message="Policy etki özeti" description={result.summary} />
      {newCtx.length > 0 && (
        <Alert type="warning" showIcon message={<>Yeni gerekli attribute: {newCtx.map((k) => <Tag key={k} color="orange">{k}</Tag>)}</>}
          description="Bu permission'ları çağıran uygulamalar (SDK) bu değerleri göndermiyorsa kararlar Indeterminate olur ve işlem REDDEDİLİR. İlgili DTO'larda [AuthContext] işaretlemesi yapılmalı." />
      )}
      {unconditional.length > 0 && (
        <Alert type="error" showIcon message={`${unconditional.map((p) => p.code).join(', ')} artık KOŞULSUZ olur`}
          description="Bu permission'a sahip herkes, hiçbir context kontrolü olmadan işlemi yapabilir." />
      )}
      <Card size="small">
        <Flex gap={28} wrap>
          <Statistic title="Etkilenen permission" value={result.permissions.length} />
          <Statistic title="Kapsamdaki kullanıcı" value={result.affectedUsers.length} />
          <Statistic title="İzin → Red" value={result.newlyDenied} valueStyle={{ color: result.newlyDenied ? '#cf1322' : undefined }} />
          <Statistic title="→ İzin" value={result.newlyAllowed} valueStyle={{ color: result.newlyAllowed ? '#389e0d' : undefined }} />
          <Statistic title="Diğer değişim" value={result.otherChanged} />
          <Statistic title="Değişmeyen" value={result.unchanged} />
          <Statistic title="Değerlendirme" value={result.evaluations} suffix={result.truncated ? '(kesildi)' : undefined} />
        </Flex>
      </Card>

      <Tabs
        items={[
          {
            key: 'rows',
            label: `Karar değişimleri (${result.rows.length})`,
            children:
              result.scenarios.length === 0 ? (
                <Alert type="info" message="Senaryo verilmediği için karar karşılaştırması yapılmadı; yapısal fark ve etkilenen kullanıcılar sekmelerine bakın." />
              ) : result.rows.length === 0 ? (
                <Empty description="Senaryolarda hiçbir kararda değişiklik yok" />
              ) : (
                <>
                  <Flex justify="flex-end" style={{ marginBottom: 8 }}>
                    <Button icon={<DownloadOutlined />} onClick={exportCsv}>CSV</Button>
                  </Flex>
                  <Table
                    size="small"
                    rowKey={(r) => `${r.userId}-${r.permission}-${r.scenario}`}
                    dataSource={result.rows}
                    pagination={{ pageSize: 15 }}
                    columns={[
                      { title: 'Kullanıcı', render: (_, r) => <><b>{r.userName}</b><br /><Typography.Text type="secondary">{r.fullName}</Typography.Text></>, sorter: (a, b) => a.userName.localeCompare(b.userName) },
                      { title: 'Permission', dataIndex: 'permission', render: (v) => <Code>{v}</Code>, filters: [...new Set(result.rows.map((r) => r.permission))].map((p) => ({ text: p, value: p })), onFilter: (v, r) => r.permission === v },
                      { title: 'Senaryo', dataIndex: 'scenario', filters: result.scenarios.map((s) => ({ text: s.name, value: s.name })), onFilter: (v, r) => r.scenario === v },
                      { title: 'Şu an', render: (_, r) => <Tooltip title={r.before.reason}><DecisionTag decision={r.before.decision} /> <Typography.Text style={{ fontSize: 12 }}>{r.before.reasonCode}</Typography.Text></Tooltip> },
                      { title: 'Değişiklik sonrası', render: (_, r) => <Tooltip title={r.after.reason}><DecisionTag decision={r.after.decision} /> <Typography.Text style={{ fontSize: 12 }}>{r.after.reasonCode}</Typography.Text></Tooltip> },
                      {
                        title: 'Etki',
                        render: (_, r) => <Tag color={changeMeta[r.change].color}>{changeMeta[r.change].label}</Tag>,
                        filters: (Object.keys(changeMeta) as DecisionChange[]).map((k) => ({ text: changeMeta[k].label, value: k })),
                        onFilter: (v, r) => r.change === v,
                      },
                    ]}
                  />
                </>
              ),
          },
          {
            key: 'diff',
            label: 'Yapısal fark (permission bazlı)',
            children: (
              <Table<PermissionPolicyDiff>
                size="small"
                rowKey="permissionId"
                dataSource={result.permissions}
                pagination={false}
                expandable={{
                  rowExpandable: (d) => d.changedRules.length > 0,
                  expandedRowRender: (d) =>
                    d.changedRules.map((c) => (
                      <div key={c.policy + c.ruleCode} style={{ marginBottom: 8 }}>
                        <Code>{c.policy} / {c.ruleCode}</Code>
                        {c.effectBefore !== c.effectAfter && <Tag color="gold">Effect: {c.effectBefore} → {c.effectAfter}</Tag>}
                        <div style={{ fontSize: 12 }}><Typography.Text type="secondary">önce:</Typography.Text> {c.expressionBefore}</div>
                        <div style={{ fontSize: 12 }}><Typography.Text type="secondary">sonra:</Typography.Text> <b>{c.expressionAfter}</b></div>
                      </div>
                    )),
                }}
                columns={[
                  { title: 'Permission', render: (_, d) => <><Code>{d.code}</Code><br /><Typography.Text type="secondary">{d.name}</Typography.Text></> },
                  { title: 'Sahip', dataIndex: 'holderCount', width: 70 },
                  {
                    title: 'Policy (önce → sonra)',
                    render: (_, d) => (
                      <>
                        {d.policiesBefore.map((p) => <Tag key={'b' + p}>{p}</Tag>)} → {d.policiesAfter.map((p) => <Tag key={'a' + p} color="purple">{p}</Tag>)}
                        {d.policiesAfter.length === 0 && <Tag color="red">yok</Tag>}
                      </>
                    ),
                  },
                  { title: 'Uygulanan rule\'lar', render: (_, d) => <RuleTags diff={d} /> },
                  {
                    title: 'Çağıranın sağlaması gereken (sonra)',
                    render: (_, d) => d.requiredAttributesAfter.map((k) => <Tag key={k} color={d.newRequiredAttributes.includes(k) ? 'orange' : 'default'}>{d.newRequiredAttributes.includes(k) ? 'YENİ ' : ''}{k}</Tag>),
                  },
                ]}
              />
            ),
          },
          {
            key: 'users',
            label: `Etkilenen kullanıcılar (${result.affectedUsers.length})`,
            children: (
              <Table
                size="small"
                rowKey="userId"
                dataSource={result.affectedUsers}
                pagination={{ pageSize: 15 }}
                columns={[
                  { title: 'Kullanıcı', dataIndex: 'userName' },
                  { title: 'Ad', dataIndex: 'fullName' },
                  { title: 'İlgili permission\'lar', dataIndex: 'permissions', render: (v: string[]) => v.map((p) => <Tag key={p}>{p}</Tag>) },
                ]}
              />
            ),
          },
        ]}
      />
    </Flex>
  )
}

// ---------------------------------------------------------------- Çalıştırıcı + onay modalı

/** Policy değişiklik seti + senaryolar + an → /api/simulation/policy-impact */
export function usePolicyImpact() {
  const { message } = App.useApp()
  const [result, setResult] = useState<PolicyImpactResult>()
  const [loading, setLoading] = useState(false)
  const run = async (changes: PolicyChangeSet, scenarios: ImpactScenario[], asOf?: Dayjs) => {
    setLoading(true)
    try {
      setResult(await api.post<PolicyImpactResult>('/api/simulation/policy-impact', {
        changes, scenarios: cleanScenarios(scenarios), asOfUtc: asOf?.toISOString(),
      }))
    } catch (e) {
      message.error((e as Error).message)
      setResult(undefined)
    } finally {
      setLoading(false)
    }
  }
  return { result, loading, run, setResult }
}

export function ScenarioSettings({ scenarios, setScenarios, asOf, setAsOf }: {
  scenarios: ImpactScenario[]; setScenarios: (s: ImpactScenario[]) => void; asOf?: Dayjs; setAsOf: (d?: Dayjs) => void
}) {
  return (
    <Collapse
      size="small"
      items={[{
        key: 's',
        label: `Karar senaryoları (${scenarios.length}) ve karar anı: ${asOf ? asOf.format('DD.MM.YYYY HH:mm') : 'şimdi'}`,
        children: (
          <Row gutter={[12, 12]}>
            <Col span={24}><ScenarioEditor value={scenarios} onChange={setScenarios} /></Col>
            <Col span={24}>
              <Flex gap={8} align="center">
                <Typography.Text>Karar anı:</Typography.Text>
                <DatePicker showTime value={asOf} onChange={(d) => setAsOf(d ?? undefined)} />
                <Typography.Text type="secondary" style={{ fontSize: 12 }}>Mesai saati kuralları bu ana göre değerlendirilir.</Typography.Text>
              </Flex>
            </Col>
          </Row>
        ),
      }]}
    />
  )
}

/** Tek bir policy/rule değişikliğini uygulamadan önce etkisini gösterir, onaylanırsa uygular. */
export function PolicyChangeModal({ open, title, changes, apply, onClose, onDone }: {
  open: boolean
  title: string
  changes: PolicyChangeSet
  apply: () => Promise<unknown>
  onClose: () => void
  onDone: () => void
}) {
  const { message } = App.useApp()
  const [scenarios, setScenarios] = useState<ImpactScenario[]>(DEFAULT_SCENARIOS)
  const [asOf, setAsOf] = useState<Dayjs | undefined>(nextBusinessMorning())
  const { result, loading, run, setResult } = usePolicyImpact()
  const [applying, setApplying] = useState(false)

  useEffect(() => {
    if (open) run(changes, scenarios, asOf)
    else setResult(undefined)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const doApply = async () => {
    setApplying(true)
    try {
      await apply()
      message.success('Uygulandı')
      onDone()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setApplying(false)
    }
  }

  return (
    <Modal
      open={open}
      title={title}
      onCancel={onClose}
      width={1150}
      destroyOnHidden
      footer={
        <Flex justify="space-between">
          <Button onClick={() => run(changes, scenarios, asOf)} loading={loading}>Senaryolarla yeniden hesapla</Button>
          <Flex gap={8}>
            <Button onClick={onClose}>Vazgeç</Button>
            <Button type="primary" danger={!!result?.newlyDenied} disabled={!result} loading={applying} onClick={doApply}>Onayla ve uygula</Button>
          </Flex>
        </Flex>
      }
    >
      <Flex vertical gap={12}>
        <ScenarioSettings scenarios={scenarios} setScenarios={setScenarios} asOf={asOf} setAsOf={setAsOf} />
        {loading && <Spin />}
        {result && <PolicyImpactView result={result} />}
      </Flex>
    </Modal>
  )
}
