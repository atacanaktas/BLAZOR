import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { App as AntApp, ConfigProvider } from 'antd'
import trTR from 'antd/locale/tr_TR'
import dayjs from 'dayjs'
import 'dayjs/locale/tr'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import './index.css'

dayjs.locale('tr')

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ConfigProvider
      locale={trTR}
      theme={{
        token: { colorPrimary: '#1f4e79', borderRadius: 6, fontSize: 14 },
        components: { Layout: { siderBg: '#0f2740' }, Menu: { darkItemBg: '#0f2740', darkSubMenuItemBg: '#0f2740' } },
      }}
    >
      <AntApp>
        <BrowserRouter>
          <App />
        </BrowserRouter>
      </AntApp>
    </ConfigProvider>
  </StrictMode>,
)
