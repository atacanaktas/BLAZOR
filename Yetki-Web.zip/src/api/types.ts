// API sözleşmesi tipleri (Yetki.Application modelleriyle birebir).

export type PermissionSourceType = 'DirectRole' | 'GroupGrantedRole' | 'GroupPermission' | 'DirectUser'

export interface PermissionSource {
  type: PermissionSourceType
  roleId?: number
  roleCode?: string
  groupId?: number
  groupCode?: string
  path: string
}

export interface MembershipReason {
  type: 'User' | 'Role' | 'OrgUnit'
  refId?: number
  refCode?: string
  text: string
}

export interface EffectivePermissionSet {
  userId: number
  userName: string
  fullName: string
  isActive: boolean
  version: number
  computedAt: string
  roles: { roleId: number; code: string; name: string; sources: { type: string; groupId?: number; groupCode?: string; text: string }[] }[]
  groups: { groupId: number; code: string; name: string; reasons: MembershipReason[] }[]
  permissions: {
    permissionId: number
    code: string
    name: string
    domain?: string
    requiresRuntimeEvaluation: boolean
    sources: PermissionSource[]
  }[]
}

export type DecisionType = 'Permit' | 'Deny' | 'NotApplicable' | 'Indeterminate'
export type TriState = 'True' | 'False' | 'Indeterminate'
export type RuleEffect = 'Permit' | 'Deny'
export type CombiningAlgorithm = 'DenyOverrides' | 'PermitOverrides' | 'FirstApplicable'
export type ConditionKind = 'Predicate' | 'AllOf' | 'AnyOf' | 'Not' | 'Reference'

export interface UsedAttribute {
  attribute: string
  value?: string | null
  source: string
  resolved: boolean
}

export interface ConditionTrace {
  kind: ConditionKind
  conditionType?: string
  expression: string
  value: TriState
  message?: string
  missingAttributes?: string[]
  evidence?: UsedAttribute[]
  children?: ConditionTrace[]
}

export interface RuleEvaluation {
  ruleId: number
  code: string
  name: string
  effect: RuleEffect
  order: number
  isActive: boolean
  conditionValue: TriState
  result: DecisionType
  reasonCode?: string
  message: string
  expression: string
  condition?: ConditionTrace
  missingAttributes: string[]
  evidence: UsedAttribute[]
  isDeciding: boolean
}

export interface PolicyEvaluation {
  policyId: number
  code: string
  name: string
  version: number
  algorithm: CombiningAlgorithm
  result: DecisionType
  decidingRule?: string
  rules: RuleEvaluation[]
  isDeciding: boolean
}

export interface AuthorizationDecision {
  decisionId: string
  decision: DecisionType
  isAllowed: boolean
  reasonCode: string
  humanReadableReason: string
  userName?: string
  permission: string
  action: string
  resource?: string
  decidingPolicy?: string
  decidingRule?: string
  evaluatedAt: string
  isSimulation: boolean
  authorizationVersion: number
  durationMs: number
  permissionSources: PermissionSource[]
  policyCombiningAlgorithm: CombiningAlgorithm
  policies: PolicyEvaluation[]
  failedRules: string[]
  permitRules: string[]
  missingAttributes: string[]
  evidence: UsedAttribute[]
  context: Record<string, string | null>
}

/** Condition ağacı (API gösterimi / taslak) */
export interface ConditionView {
  id?: number
  kind: ConditionKind
  conditionType?: string
  parameters: Record<string, string>
  /** Kind=Reference: children[0] = ortak koşulun çözülmüş tanımı (salt okunur) */
  children: ConditionView[]
  sharedCondition?: string
  sharedConditionVersion?: number
}

export interface SharedConditionInfo {
  id: number
  code: string
  name: string
  description?: string
  scope: 'Global' | 'Domain'
  domain?: string
  isActive: boolean
  version: number
  expression: string
  usageCount: number
  policies: string[]
}

export interface ConditionDraft {
  kind: ConditionKind
  conditionTypeCode?: string
  /** Kind=Reference: ortak koşul kodu */
  sharedConditionCode?: string
  parameters: Record<string, string>
  children: ConditionDraft[]
}

export interface RuleView {
  id: number
  code: string
  name: string
  description?: string
  effect: RuleEffect
  order: number
  reasonCode?: string
  isActive: boolean
  expression: string
  condition?: ConditionView
}

export interface ConditionTypeInfo {
  id: number
  code: string
  name: string
  description?: string
  defaultScope: string
  parameterSchemaJson: string
  requiredAttributes?: string
  isAvailable: boolean
  usageCount: number
}

export interface ParamDef {
  key: string
  label: string
  type: string
  required: boolean
  defaultValue?: string
  description?: string
}

export type GroupChangeKind = 'AudienceUser' | 'AudienceRole' | 'AudienceOrgUnit' | 'GrantPermission' | 'GrantRole'

export interface AuthorizationChangeSet {
  userId?: number
  addUserRoleIds?: number[]
  removeUserRoleIds?: number[]
  addUserPermissionIds?: number[]
  removeUserPermissionIds?: number[]
  addUserOrgUnitIds?: number[]
  removeUserOrgUnitIds?: number[]
  rolePermissionChanges?: { roleId: number; permissionId: number; add: boolean }[]
  groupChanges?: { groupId: number; kind: GroupChangeKind; targetId: number; add: boolean }[]
}

export interface SodConflict {
  sodRuleId: number
  code: string
  name: string
  severity: string
  enforcement: 'Warn' | 'Block'
  matchedMembers: { type: string; id: number; code: string; name: string; paths: string[] }[]
}

export interface ExternalRequirement {
  permissionCode: string
  systemCode: string
  externalPermissionCode: string
  externalPermissionName?: string
}

export interface UserImpact {
  userId: number
  userName: string
  fullName: string
  addedPermissions: { permissionId: number; code: string; name: string; paths: string[] }[]
  removedPermissions: { permissionId: number; code: string; name: string; paths: string[] }[]
  addedRoles: string[]
  removedRoles: string[]
  addedGroups: string[]
  removedGroups: string[]
  newSodConflicts: SodConflict[]
  externalGrants: ExternalRequirement[]
  externalRevokes: ExternalRequirement[]
  /** Kullanıcı yetkiyi korur ama kaynağı değişir (ör. başka rolden/gruptan da sahip) */
  retainedPermissions: { permissionId: number; code: string; name: string; beforePaths: string[]; afterPaths: string[] }[]
}

export interface ChangeImpactResult {
  dryRun: boolean
  applied: boolean
  blocked: boolean
  summary: string
  affectedUserCount: number
  evaluatedUserCount: number
  users: UserImpact[]
  blockingConflicts: { userId: number; userName: string; conflict: SodConflict }[]
  warnings: { userId: number; userName: string; conflict: SodConflict }[]
}

export interface Option {
  id: number
  code: string
  name: string
}

// ---------------- Policy What-If ----------------

export interface RuleDraft {
  policyId: number
  code: string
  name?: string
  effect: RuleEffect
  order: number
  reasonCode?: string
  condition: ConditionDraft
}

export interface PolicyChangeSet {
  permissionPolicyChanges?: { permissionId: number; policyId: number; add: boolean }[]
  policyActivations?: { policyId: number; isActive: boolean }[]
  policyAlgorithmChanges?: { policyId: number; algorithm: CombiningAlgorithm }[]
  ruleOverrides?: { ruleId: number; isActive?: boolean; effect?: RuleEffect; order?: number }[]
  conditionOverrides?: { conditionId: number; parameters: Record<string, string> }[]
  addedRules?: RuleDraft[]
  removedRuleIds?: number[]
  replacedRules?: { ruleId: number; rule: RuleDraft }[]
  sharedConditionReplacements?: { sharedConditionId: number; condition: ConditionDraft }[]
}

export interface ImpactScenario {
  name: string
  context: Record<string, string>
}

export interface DecisionBrief {
  decision: DecisionType
  reasonCode: string
  reason: string
  decidingRule?: string
}

export type DecisionChange = 'UNCHANGED' | 'NEWLY_DENIED' | 'NEWLY_ALLOWED' | 'NEWLY_INDETERMINATE' | 'REASON_CHANGED'

export interface RuleRef {
  policy: string
  code: string
  name: string
  effect: RuleEffect
  expression: string
}

export interface PermissionPolicyDiff {
  permissionId: number
  code: string
  name: string
  holderCount: number
  policiesBefore: string[]
  policiesAfter: string[]
  rulesBefore: RuleRef[]
  rulesAfter: RuleRef[]
  addedRules: string[]
  removedRules: string[]
  changedRules: { policy: string; ruleCode: string; effectBefore?: string; effectAfter?: string; expressionBefore: string; expressionAfter: string }[]
  requiredAttributesBefore: string[]
  requiredAttributesAfter: string[]
  newRequiredAttributes: string[]
  becomesUnconditional: boolean
  becomesConditional: boolean
  hasStructuralChange: boolean
}

export interface PolicyImpactResult {
  summary: string
  permissions: PermissionPolicyDiff[]
  affectedUsers: { userId: number; userName: string; fullName: string; permissions: string[] }[]
  scenarios: ImpactScenario[]
  rows: {
    userId: number
    userName: string
    fullName: string
    permission: string
    scenario: string
    before: DecisionBrief
    after: DecisionBrief
    change: DecisionChange
  }[]
  evaluations: number
  truncated: boolean
  newlyDenied: number
  newlyAllowed: number
  otherChanged: number
  unchanged: number
  durationMs: number
}
