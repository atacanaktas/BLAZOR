import { Button, Card, Col, Descriptions, Flex, Row, Table, Tag, Typography } from 'antd'
import { EditOutlined, ExperimentOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api } from '../api/client'
import type { ChangeImpactResult } from '../api/types'
import { toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { ActiveTag, Code, PageHeader, fmt } from '../components/common'
import { ChangeModal } from '../components/ChangeModal'
import { ConfirmChangeModal } from '../components/ConfirmChangeModal'
import { EntityFormModal, type FieldDef } from '../components/EntityFormModal'

const roleFields: FieldDef[] = [
  { name: 'code', label: 'Kod', required: true, disabledOnEdit: true, placeholder: 'GISEYTK' },
  { name: 'name', label: 'Ad', required: true },
  { name: 'description', label: 'Açıklama', type: 'textarea' },
  { name: 'isActive', label: 'Aktif', type: 'switch' },
]

interface RoleRow {
  id: number
  code: string
  name: string
  description?: string
  isActive: boolean
  permissionCount: number
  userCount: number
  permissions: string[]
}

export function RolesPage() {
  const { data, loading, reload } = useApi<RoleRow[]>('/api/roles')
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  return (
    <>
      <PageHeader
        title="Roller"
        subtitle="Permission'ların iş fonksiyonuna göre paketlenmesi — ana yönetim mekanizması."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setOpen(true)}>Yeni rol</Button>}
      />
      <Table<RoleRow>
        rowKey="id"
        loading={loading}
        dataSource={data ?? []}
        rowClassName="clickable-row"
        onRow={(r) => ({ onClick: () => navigate(`/roles/${r.id}`) })}
        pagination={false}
        columns={[
          { title: 'Kod', dataIndex: 'code', render: (v) => <Code>{v}</Code> },
          { title: 'Ad', dataIndex: 'name' },
          { title: 'Permission\'lar', dataIndex: 'permissions', render: (v: string[]) => <Flex wrap gap={4}>{v.map((p) => <Tag key={p}>{p}</Tag>)}</Flex> },
          { title: 'Doğrudan kullanıcı', dataIndex: 'userCount', width: 140 },
          { title: 'Durum', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} />, width: 90 },
        ]}
      />
      <EntityFormModal open={open} title="Yeni rol" fields={roleFields} createPath="/api/roles" onClose={() => setOpen(false)}
        onSaved={(id) => { reload(); if (id) navigate(`/roles/${id}`) }} />
    </>
  )
}

interface RoleDetail {
  role: {
    id: number; code: string; name: string; description?: string; isActive: boolean; createdAt: string; createdBy: string; updatedAt?: string; updatedBy?: string
    permissions: { permissionId: number; code: string; name: string; domain?: string; assignedAt: string; assignedBy: string }[]
  }
  users: { userId: number; userName: string; fullName: string; assignedAt: string; assignedBy: string }[]
  grantingGroups: { groupId: number; code: string; name: string }[]
  audienceGroups: { groupId: number; code: string; name: string }[]
}

export function RoleDetailPage() {
  const id = Number(useParams().id)
  const navigate = useNavigate()
  const { data, reload } = useApi<RoleDetail>(`/api/roles/${id}`)
  const permissions = useOptions('permissions')
  const [adding, setAdding] = useState(false)
  const [editing, setEditing] = useState(false)
  const [removing, setRemoving] = useState<{ permissionId: number; code: string } | null>(null)
  if (!data) return <Card loading />
  const r = data.role

  return (
    <>
      <PageHeader
        title={r.name}
        subtitle={<><Code>{r.code}</Code> <ActiveTag active={r.isActive} /> {r.description}</>}
        extra={
          <Flex gap={8}>
            <Button icon={<ExperimentOutlined />} onClick={() => navigate(`/what-if?tab=role&roleId=${id}`)}>What-If</Button>
            <Button icon={<EditOutlined />} onClick={() => setEditing(true)}>Düzenle</Button>
          </Flex>
        }
      />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={14}>
          <Card size="small" title="Rolün permission'ları" extra={<Button icon={<PlusOutlined />} onClick={() => setAdding(true)}>Permission ekle</Button>}>
            <Table
              size="small"
              rowKey="permissionId"
              pagination={false}
              dataSource={r.permissions}
              columns={[
                { title: 'Permission', render: (_, p) => <a onClick={() => navigate(`/permissions/${p.permissionId}`)}><Code>{p.code}</Code> {p.name}</a> },
                { title: 'Domain', dataIndex: 'domain', render: (v) => v && <Tag>{v}</Tag> },
                { title: 'Ekleyen', render: (_, p) => <>{p.assignedBy}<br /><Typography.Text type="secondary">{fmt(p.assignedAt)}</Typography.Text></> },
                {
                  title: '',
                  width: 90,
                  render: (_, p) => (
                    <Button size="small" danger onClick={() => setRemoving({ permissionId: p.permissionId, code: p.code })}>Çıkar…</Button>
                  ),
                },
              ]}
            />
          </Card>
        </Col>
        <Col xs={24} xl={10}>
          <Flex vertical gap={16}>
            <Card size="small" title={`Doğrudan sahip kullanıcılar (${data.users.length})`}>
              <Table size="small" rowKey="userId" pagination={{ pageSize: 8 }} dataSource={data.users}
                columns={[{ title: 'Kullanıcı', render: (_, u) => <a onClick={() => navigate(`/users/${u.userId}`)}>{u.userName}</a> }, { title: 'Ad', dataIndex: 'fullName' }]} />
            </Card>
            <Card size="small" title="Grup ilişkileri">
              <Descriptions size="small" column={1}>
                <Descriptions.Item label="Bu rolü veren gruplar">{data.grantingGroups.map((g) => <Tag key={g.groupId} color="purple">{g.code}</Tag>)}</Descriptions.Item>
                <Descriptions.Item label="Kitlesinde bu rol olan gruplar">{data.audienceGroups.map((g) => <Tag key={g.groupId}>{g.code}</Tag>)}</Descriptions.Item>
              </Descriptions>
            </Card>
          </Flex>
        </Col>
      </Row>
      <ChangeModal
        open={adding}
        title={`${r.code} — permission ekle`}
        label="Permission (rolü doğrudan veya grup üzerinden taşıyan herkes etkilenir)"
        options={toSelectOptions(permissions, r.permissions.map((p) => p.permissionId))}
        buildChangeSet={(t) => ({ rolePermissionChanges: [{ roleId: id, permissionId: t, add: true }] })}
        apply={(t) => api.post(`/api/roles/${id}/permissions`, { id: t })}
        onClose={() => setAdding(false)}
        onDone={reload}
      />
      <ConfirmChangeModal
        open={!!removing}
        title={`Etki: ${r.code} rolünden ${removing?.code} çıkarılırsa — kim kaybeder?`}
        changeSet={{ rolePermissionChanges: removing ? [{ roleId: id, permissionId: removing.permissionId, add: false }] : [] }}
        apply={() => api.del<ChangeImpactResult>(`/api/roles/${id}/permissions/${removing!.permissionId}`)}
        onClose={() => setRemoving(null)}
        onDone={reload}
      />
      <EntityFormModal open={editing} title="Rolü düzenle" fields={roleFields} createPath="/api/roles" updatePath={`/api/roles/${id}`}
        initial={{ ...r }} onClose={() => setEditing(false)} onSaved={reload} />
    </>
  )
}
