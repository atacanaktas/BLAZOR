import { Drawer, Flex, Input, Select, Table, Tag, Typography } from 'antd'
import { useState } from 'react'
import { api } from '../api/client'
import { useApi } from '../hooks/useApi'
import { Code, DecisionTag, PageHeader, fmt } from '../components/common'

interface AuditRow {
  id: string
  timestamp: string
  category: string
  actor: string
  action: string
  entityType?: string
  entityId?: string
  subjectUserName?: string
  permissionCode?: string
  decision?: string
  reasonCode?: string
  summary?: string
}

const categoryColor: Record<string, string> = { AuthorizationDecision: 'blue', Management: 'green', Simulation: 'purple', SodScan: 'red' }

export function AuditPage() {
  const [category, setCategory] = useState<string>()
  const [user, setUser] = useState('')
  const [permission, setPermission] = useState('')
  const [decision, setDecision] = useState<string>()
  const q = new URLSearchParams({ take: '300' })
  if (category) q.set('category', category)
  if (user) q.set('user', user)
  if (permission) q.set('permission', permission)
  if (decision) q.set('decision', decision)
  const { data, loading } = useApi<AuditRow[]>(`/api/audit?${q.toString()}`)
  const [detail, setDetail] = useState<{ detailsJson?: string; summary?: string; id: string }>()

  return (
    <>
      <PageHeader title="Audit" subtitle="Kim, neyi, ne zaman, hangi context ile, sonuç ne, hangi rule etkiledi, yetki nereden geldi, değişikliği kim yaptı." />
      <Flex gap={8} wrap style={{ marginBottom: 12 }}>
        <Select allowClear placeholder="Kategori" value={category} onChange={setCategory} style={{ width: 200 }}
          options={['AuthorizationDecision', 'Management', 'Simulation', 'SodScan'].map((c) => ({ value: c, label: c }))} />
        <Input.Search placeholder="Kullanıcı / aktör" allowClear onSearch={setUser} style={{ width: 200 }} />
        <Input.Search placeholder="Permission kodu" allowClear onSearch={setPermission} style={{ width: 200 }} />
        <Select allowClear placeholder="Karar" value={decision} onChange={setDecision} style={{ width: 160 }}
          options={['Permit', 'Deny', 'NotApplicable', 'Indeterminate'].map((c) => ({ value: c, label: c }))} />
      </Flex>
      <Table<AuditRow>
        rowKey="id"
        size="small"
        loading={loading}
        dataSource={data ?? []}
        pagination={{ pageSize: 25 }}
        rowClassName="clickable-row"
        onRow={(r) => ({ onClick: () => api.get<{ detailsJson?: string; summary?: string; id: string }>(`/api/audit/${r.id}`).then(setDetail) })}
        columns={[
          { title: 'Zaman', dataIndex: 'timestamp', render: fmt, width: 150 },
          { title: 'Kategori', dataIndex: 'category', render: (v) => <Tag color={categoryColor[v]}>{v}</Tag> },
          { title: 'Aktör', dataIndex: 'actor' },
          { title: 'Aksiyon', dataIndex: 'action' },
          { title: 'Kullanıcı', dataIndex: 'subjectUserName' },
          { title: 'Permission', dataIndex: 'permissionCode', render: (v) => v && <Code>{v}</Code> },
          { title: 'Karar', dataIndex: 'decision', render: (v) => v && <DecisionTag decision={v} /> },
          { title: 'Özet', dataIndex: 'summary', render: (v) => <Typography.Text style={{ fontSize: 12 }}>{v}</Typography.Text> },
        ]}
      />
      <Drawer open={!!detail} onClose={() => setDetail(undefined)} title="Audit detayı" size="large">
        {detail && (
          <>
            <Typography.Paragraph copyable={{ text: detail.id }}>ID: {detail.id}</Typography.Paragraph>
            <Typography.Paragraph>{detail.summary}</Typography.Paragraph>
            <pre style={{ fontSize: 12, whiteSpace: 'pre-wrap' }}>{detail.detailsJson ? JSON.stringify(JSON.parse(detail.detailsJson), null, 2) : '—'}</pre>
          </>
        )}
      </Drawer>
    </>
  )
}
