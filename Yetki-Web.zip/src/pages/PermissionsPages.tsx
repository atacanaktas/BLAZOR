import { App, Button, Card, Col, Flex, Input, Popconfirm, Row, Select, Table, Tag, Typography } from 'antd'
import { EditOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api } from '../api/client'
import type { PermissionSource } from '../api/types'
import { toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { ActiveTag, Code, PageHeader, SourceList } from '../components/common'
import { EntityFormModal, type FieldDef } from '../components/EntityFormModal'
import { PolicyChangeModal } from '../components/PolicyImpact'
import type { PolicyChangeSet } from '../api/types'

const domains = ['MUSTERI', 'VADELI', 'GISE', 'ODEME', 'KREDI', 'RAPOR', 'YETKI', 'GENEL']
const permissionFields: FieldDef[] = [
  { name: 'code', label: 'Kod', required: true, disabledOnEdit: true, placeholder: 'TERM_DEPOSIT_VIEW' },
  { name: 'name', label: 'Ad', required: true },
  { name: 'domain', label: 'Domain', type: 'select', options: domains.map((d) => ({ value: d, label: d })) },
  { name: 'description', label: 'Açıklama', type: 'textarea' },
  { name: 'isActive', label: 'Aktif', type: 'switch' },
]

interface PermissionRow {
  id: number
  code: string
  name: string
  domain?: string
  isActive: boolean
  roleCount: number
  policies: string[]
  externalCount: number
}

export function PermissionsPage() {
  const [search, setSearch] = useState('')
  const [domain, setDomain] = useState<string>()
  const { data, loading, reload } = useApi<PermissionRow[]>(`/api/permissions?search=${encodeURIComponent(search)}&domain=${domain ?? ''}`)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  return (
    <>
      <PageHeader
        title="Permission'lar"
        subtitle="Atomik yetkiler. Policy bağlı olanlar işlem anında (context ile) değerlendirilir."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setOpen(true)}>Yeni permission</Button>}
      />
      <Flex gap={8} style={{ marginBottom: 12 }}>
        <Input.Search placeholder="Kod veya ad" allowClear onSearch={setSearch} style={{ maxWidth: 320 }} />
        <Select allowClear placeholder="Domain" value={domain} onChange={setDomain} options={domains.map((d) => ({ value: d, label: d }))} style={{ width: 160 }} />
      </Flex>
      <Table<PermissionRow>
        rowKey="id"
        loading={loading}
        dataSource={data ?? []}
        pagination={false}
        rowClassName="clickable-row"
        onRow={(r) => ({ onClick: () => navigate(`/permissions/${r.id}`) })}
        columns={[
          { title: 'Kod', dataIndex: 'code', render: (v) => <Code>{v}</Code> },
          { title: 'Ad', dataIndex: 'name' },
          { title: 'Domain', dataIndex: 'domain', render: (v) => v && <Tag>{v}</Tag> },
          { title: 'Rol sayısı', dataIndex: 'roleCount', width: 100 },
          { title: 'Policy', dataIndex: 'policies', render: (v: string[]) => v.map((p) => <Tag color="purple" key={p}>{p}</Tag>) },
          { title: 'Dış eşleme', dataIndex: 'externalCount', width: 110, render: (v) => (v ? <Tag color="cyan">{v}</Tag> : '—') },
          { title: 'Durum', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} />, width: 90 },
        ]}
      />
      <EntityFormModal open={open} title="Yeni permission" fields={permissionFields} createPath="/api/permissions" onClose={() => setOpen(false)}
        onSaved={() => reload()} />
    </>
  )
}

interface PermissionDetail {
  permission: {
    id: number; code: string; name: string; description?: string; domain?: string; isActive: boolean
    roles: { roleId: number; code: string; name: string }[]
    policies: { policyId: number; code: string; name: string; isActive: boolean }[]
  }
  groups: { groupId: number; code: string; name: string }[]
  external: { externalPermissionId: number; system: string; code: string; name?: string; note?: string; assignedBy: string }[]
}

interface ExternalSystem {
  id: number
  code: string
  permissions: { id: number; code: string; name?: string }[]
}

export function PermissionDetailPage() {
  const id = Number(useParams().id)
  const navigate = useNavigate()
  const { message } = App.useApp()
  const { data, reload } = useApi<PermissionDetail>(`/api/permissions/${id}`)
  const holders = useApi<{ userId: number; userName: string; fullName: string; sources: PermissionSource[] }[]>(`/api/permissions/${id}/holders`)
  const systems = useApi<ExternalSystem[]>('/api/external/systems')
  const policies = useOptions('policies')
  const [policyId, setPolicyId] = useState<number>()
  const [extId, setExtId] = useState<number>()
  const [editing, setEditing] = useState(false)
  const [pending, setPending] = useState<{ title: string; changes: PolicyChangeSet; apply: () => Promise<unknown> } | null>(null)
  if (!data) return <Card loading />
  const p = data.permission

  const run = async (fn: () => Promise<unknown>, ok: string) => {
    try {
      await fn()
      message.success(ok)
      reload()
    } catch (e) {
      message.error((e as Error).message)
    }
  }

  const extOptions = (systems.data ?? []).flatMap((s) =>
    s.permissions.filter((x) => !data.external.some((e) => e.externalPermissionId === x.id)).map((x) => ({ value: x.id, label: `${s.code}: ${x.code} ${x.name ?? ''}` })),
  )

  return (
    <>
      <PageHeader
        title={p.name}
        subtitle={<><Code>{p.code}</Code> {p.domain && <Tag>{p.domain}</Tag>} <ActiveTag active={p.isActive} /> {p.description}</>}
        extra={<Button icon={<EditOutlined />} onClick={() => setEditing(true)}>Düzenle</Button>}
      />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={12}>
          <Card size="small" title="Bağlı policy'ler (işlem anı koşulları)">
            <Table
              size="small"
              rowKey="policyId"
              pagination={false}
              dataSource={p.policies}
              columns={[
                { title: 'Policy', render: (_, x) => <a onClick={() => navigate(`/policies/${x.policyId}`)}><Code>{x.code}</Code> {x.name}</a> },
                { title: '', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} />, width: 80 },
                {
                  title: '',
                  width: 90,
                  render: (_, x) => (
                    <Button size="small" danger onClick={() => setPending({
                      title: `Etki: ${p.code} permission'ından ${x.code} policy'si kaldırılırsa`,
                      changes: { permissionPolicyChanges: [{ permissionId: id, policyId: x.policyId, add: false }] },
                      apply: () => api.del(`/api/permissions/${id}/policies/${x.policyId}`),
                    })}>Kaldır…</Button>
                  ),
                },
              ]}
            />
            <Flex gap={8} style={{ marginTop: 8 }}>
              <Select placeholder="Policy bağla" value={policyId} onChange={setPolicyId} options={toSelectOptions(policies, p.policies.map((x) => x.policyId))} style={{ flex: 1 }} showSearch optionFilterProp="label" />
              <Button disabled={!policyId} icon={<PlusOutlined />} onClick={() => setPending({
                title: `Etki: ${p.code} permission'ına ${policies.find((x) => x.id === policyId)?.code} policy'si bağlanırsa`,
                changes: { permissionPolicyChanges: [{ permissionId: id, policyId: policyId!, add: true }] },
                apply: () => api.post(`/api/permissions/${id}/policies`, { id: policyId }).then(() => setPolicyId(undefined)),
              })}>Bağla…</Button>
            </Flex>
          </Card>
        </Col>
        <Col xs={24} xl={12}>
          <Card size="small" title="Dış sistem gereksinimleri (RACF vb.)">
            <Table
              size="small"
              rowKey="externalPermissionId"
              pagination={false}
              dataSource={data.external}
              columns={[
                { title: 'Sistem', dataIndex: 'system', render: (v) => <Tag color="cyan">{v}</Tag> },
                { title: 'Dış yetki', render: (_, e) => <><Code>{e.code}</Code> {e.name}</> },
                { title: 'Not', dataIndex: 'note' },
                {
                  title: '',
                  width: 90,
                  render: (_, e) => (
                    <Popconfirm title="Eşleme kaldırılsın mı?" onConfirm={() => run(() => api.del(`/api/permissions/${id}/external-mappings/${e.externalPermissionId}`), 'Kaldırıldı')}>
                      <Button size="small" danger>Kaldır</Button>
                    </Popconfirm>
                  ),
                },
              ]}
            />
            <Flex gap={8} style={{ marginTop: 8 }}>
              <Select placeholder="Dış yetki eşle" value={extId} onChange={setExtId} options={extOptions} style={{ flex: 1 }} showSearch optionFilterProp="label" />
              <Button disabled={!extId} icon={<PlusOutlined />} onClick={() => run(() => api.post(`/api/permissions/${id}/external-mappings`, { externalPermissionId: extId, note: 'UI' }), 'Eşlendi').then(() => setExtId(undefined))}>Eşle</Button>
            </Flex>
          </Card>
        </Col>
        <Col xs={24} xl={12}>
          <Card size="small" title="Bu permission'ı içeren roller / gruplar">
            <Flex wrap gap={4}>
              {p.roles.map((r) => <Tag key={r.roleId} color="blue" style={{ cursor: 'pointer' }} onClick={() => navigate(`/roles/${r.roleId}`)}>{r.code}</Tag>)}
              {data.groups.map((g) => <Tag key={g.groupId} color="geekblue" style={{ cursor: 'pointer' }} onClick={() => navigate(`/groups/${g.groupId}`)}>grup: {g.code}</Tag>)}
            </Flex>
          </Card>
        </Col>
        <Col xs={24}>
          <Card size="small" title={<>Kimde var? ({holders.data?.length ?? '…'}) <Typography.Text type="secondary">— effective hesaplama ile, kaynak yollarıyla</Typography.Text></>}>
            <Table
              size="small"
              rowKey="userId"
              loading={holders.loading}
              dataSource={holders.data ?? []}
              pagination={{ pageSize: 10 }}
              columns={[
                { title: 'Kullanıcı', render: (_, h) => <a onClick={() => navigate(`/users/${h.userId}`)}>{h.userName}</a>, width: 180 },
                { title: 'Ad', dataIndex: 'fullName', width: 180 },
                { title: 'Neden?', render: (_, h) => <SourceList sources={h.sources} /> },
              ]}
            />
          </Card>
        </Col>
      </Row>
      <PolicyChangeModal
        open={!!pending}
        title={pending?.title ?? ''}
        changes={pending?.changes ?? {}}
        apply={() => pending!.apply()}
        onClose={() => setPending(null)}
        onDone={reload}
      />
      <EntityFormModal open={editing} title="Permission düzenle" fields={permissionFields} createPath="/api/permissions" updatePath={`/api/permissions/${id}`}
        initial={{ ...p }} onClose={() => setEditing(false)} onSaved={reload} />
    </>
  )
}
