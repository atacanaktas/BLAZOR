import { App, Button, Table, Tabs, Tag, Typography } from 'antd'
import { ReloadOutlined, ThunderboltOutlined } from '@ant-design/icons'
import { api } from '../api/client'
import { useApi } from '../hooks/useApi'
import { Code, PageHeader, fmt } from '../components/common'

interface OutboxEvent {
  id: string
  eventType: string
  aggregateType?: string
  aggregateId?: string
  payloadJson: string
  occurredAt: string
  actor: string
  status: string
  attempts: number
  processedAt?: string
  error?: string
}

interface ProvisioningAction {
  id: number
  userName: string
  permissionCode: string
  externalSystemCode: string
  externalPermissionCode: string
  actionType: string
  status: string
  adapterName?: string
  resultMessage?: string
  createdAt: string
  completedAt?: string
}

export function EventsPage() {
  const { message } = App.useApp()
  const outbox = useApi<OutboxEvent[]>('/api/events/outbox?take=200')
  const prov = useApi<ProvisioningAction[]>('/api/events/provisioning?take=200')
  const reload = () => { outbox.reload(); prov.reload() }

  return (
    <>
      <PageHeader
        title="Event & Provisioning"
        subtitle="Transactional outbox → event handler'lar (log, provisioning) → dış sistem adaptörü. Yetki kararı provisioning'e bağlı değildir."
        extra={
          <>
            <Button icon={<ReloadOutlined />} onClick={reload} style={{ marginRight: 8 }}>Yenile</Button>
            <Button icon={<ThunderboltOutlined />} onClick={async () => { const r = await api.post<{ processed: number }>('/api/events/outbox/process'); message.info(`${r.processed} event işlendi`); reload() }}>Outbox'ı şimdi işlet</Button>
          </>
        }
      />
      <Tabs
        items={[
          {
            key: 'prov',
            label: 'Provisioning aksiyonları',
            children: (
              <Table<ProvisioningAction>
                rowKey="id"
                size="small"
                loading={prov.loading}
                dataSource={prov.data ?? []}
                pagination={{ pageSize: 20 }}
                columns={[
                  { title: 'Zaman', dataIndex: 'createdAt', render: fmt, width: 150 },
                  { title: 'Kullanıcı', dataIndex: 'userName' },
                  { title: 'Sebep permission', dataIndex: 'permissionCode', render: (v) => <Code>{v}</Code> },
                  { title: 'Sistem', dataIndex: 'externalSystemCode', render: (v) => <Tag color="cyan">{v}</Tag> },
                  { title: 'Dış yetki', dataIndex: 'externalPermissionCode' },
                  { title: 'Aksiyon', dataIndex: 'actionType', render: (v) => <Tag color={v === 'Grant' ? 'green' : 'volcano'}>{v}</Tag> },
                  { title: 'Durum', dataIndex: 'status', render: (v) => <Tag color={v === 'Completed' ? 'green' : v === 'Failed' ? 'red' : 'default'}>{v}</Tag> },
                  { title: 'Adaptör sonucu', dataIndex: 'resultMessage', render: (v) => <Typography.Text style={{ fontSize: 12 }}>{v}</Typography.Text> },
                ]}
              />
            ),
          },
          {
            key: 'outbox',
            label: 'Outbox event\'leri',
            children: (
              <Table<OutboxEvent>
                rowKey="id"
                size="small"
                loading={outbox.loading}
                dataSource={outbox.data ?? []}
                pagination={{ pageSize: 20 }}
                expandable={{ expandedRowRender: (e) => <pre style={{ margin: 0, fontSize: 12, whiteSpace: 'pre-wrap' }}>{JSON.stringify(JSON.parse(e.payloadJson), null, 2)}</pre> }}
                columns={[
                  { title: 'Zaman', dataIndex: 'occurredAt', render: fmt, width: 150 },
                  { title: 'Event', dataIndex: 'eventType', render: (v) => <Tag color={v === 'EffectivePermissionsChanged' ? 'purple' : 'blue'}>{v}</Tag> },
                  { title: 'Aggregate', render: (_, e) => `${e.aggregateType ?? ''}:${e.aggregateId ?? ''}` },
                  { title: 'Kim', dataIndex: 'actor' },
                  { title: 'Durum', dataIndex: 'status', render: (v, e) => <><Tag color={v === 'Processed' ? 'green' : v === 'Failed' ? 'red' : 'gold'}>{v}</Tag>{e.error}</> },
                  { title: 'İşlenme', dataIndex: 'processedAt', render: fmt },
                ]}
              />
            ),
          },
        ]}
      />
    </>
  )
}
