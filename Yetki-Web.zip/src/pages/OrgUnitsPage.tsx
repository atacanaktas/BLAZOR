import { Alert, Table, Tag } from 'antd'
import { useApi } from '../hooks/useApi'
import { Code, PageHeader } from '../components/common'

export function OrgUnitsPage() {
  const { data, loading } = useApi<{ id: number; code: string; name: string; type: string; parent?: string; userCount: number }[]>('/api/org-units')
  return (
    <>
      <PageHeader title="Birimler" subtitle="Şube ve genel müdürlük birimleri." />
      <Alert type="warning" showIcon style={{ marginBottom: 12 }}
        message="Birim hiyerarşisi yetki hiyerarşisi DEĞİLDİR. Birimler sadece grup kitlesi ve BRANCH_MATCH gibi rule'larda kullanılır." />
      <Table
        rowKey="id"
        loading={loading}
        dataSource={data ?? []}
        pagination={false}
        columns={[
          { title: 'Kod', dataIndex: 'code', render: (v) => <Code>{v}</Code> },
          { title: 'Ad', dataIndex: 'name' },
          { title: 'Tip', dataIndex: 'type', render: (v) => <Tag>{v}</Tag> },
          { title: 'Üst birim (bilgi)', dataIndex: 'parent' },
          { title: 'Kullanıcı', dataIndex: 'userCount' },
        ]}
      />
    </>
  )
}
