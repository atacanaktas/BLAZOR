import { App, Button, Form, Input, InputNumber, Modal, Switch, Table, Tag } from 'antd'
import { PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../../api/client'
import { useApi } from '../../hooks/useApi'
import { ActiveTag, PageHeader } from '../../components/common'

interface UserRow {
  id: number
  userName: string
  fullName: string
  title?: string
  isActive: boolean
  isOnLeave: boolean
  orgUnits: string[]
  roles: string[]
}

export function UsersPage() {
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const { data, loading, reload } = useApi<{ total: number; items: UserRow[] }>(
    `/api/users?search=${encodeURIComponent(search)}&page=${page}&pageSize=20`,
  )
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)

  return (
    <>
      <PageHeader
        title="Kullanıcılar"
        subtitle="Kullanıcı arama, detay, effective yetkiler ve atamalar."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setOpen(true)}>Yeni kullanıcı</Button>}
      />
      <Input.Search
        placeholder="Kullanıcı adı, ad soyad veya ünvan"
        allowClear
        onSearch={(v) => {
          setPage(1)
          setSearch(v)
        }}
        style={{ maxWidth: 420, marginBottom: 12 }}
      />
      <Table<UserRow>
        rowKey="id"
        size="middle"
        loading={loading}
        dataSource={data?.items ?? []}
        rowClassName="clickable-row"
        onRow={(r) => ({ onClick: () => navigate(`/users/${r.id}`) })}
        pagination={{ current: page, pageSize: 20, total: data?.total ?? 0, onChange: setPage, showSizeChanger: false }}
        columns={[
          { title: 'Kullanıcı adı', dataIndex: 'userName', render: (v) => <b>{v}</b> },
          { title: 'Ad soyad', dataIndex: 'fullName' },
          { title: 'Ünvan', dataIndex: 'title' },
          { title: 'Birim', dataIndex: 'orgUnits', render: (v: string[]) => v.map((o) => <Tag key={o}>{o}</Tag>) },
          { title: 'Doğrudan roller', dataIndex: 'roles', render: (v: string[]) => v.map((o) => <Tag color="blue" key={o}>{o}</Tag>) },
          {
            title: 'Durum',
            render: (_, r) => <><ActiveTag active={r.isActive} />{r.isOnLeave && <Tag color="orange">İzinde</Tag>}</>,
          },
        ]}
      />
      <UserFormModal open={open} onClose={() => setOpen(false)} onSaved={(id) => { reload(); navigate(`/users/${id}`) }} />
    </>
  )
}

export interface UserFormValues {
  userName: string
  fullName: string
  title?: string
  email?: string
  isActive: boolean
  isOnLeave: boolean
  cashWithdrawalLimit: number
  customerNo?: string
}

export function UserFormModal({ open, onClose, onSaved, initial, id }: {
  open: boolean
  onClose: () => void
  onSaved: (id: number) => void
  initial?: UserFormValues
  id?: number
}) {
  const [form] = Form.useForm<UserFormValues>()
  const { message } = App.useApp()
  const [saving, setSaving] = useState(false)

  const submit = async () => {
    const v = await form.validateFields()
    setSaving(true)
    try {
      if (id) {
        await api.put(`/api/users/${id}`, v)
        onSaved(id)
      } else {
        const r = await api.post<{ id: number }>('/api/users', v)
        onSaved(r.id)
      }
      message.success('Kaydedildi')
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <Modal open={open} title={id ? 'Kullanıcıyı düzenle' : 'Yeni kullanıcı'} onCancel={onClose} onOk={submit} confirmLoading={saving} destroyOnHidden>
      <Form form={form} layout="vertical" initialValues={initial ?? { isActive: true, isOnLeave: false, cashWithdrawalLimit: 0 }} preserve={false}>
        <Form.Item name="userName" label="Kullanıcı adı" rules={[{ required: true }]}>
          <Input disabled={!!id} placeholder="ad.soyad" />
        </Form.Item>
        <Form.Item name="fullName" label="Ad soyad" rules={[{ required: true }]}><Input /></Form.Item>
        <Form.Item name="title" label="Ünvan"><Input /></Form.Item>
        <Form.Item name="email" label="E-posta"><Input /></Form.Item>
        <Form.Item
          name="cashWithdrawalLimit"
          label="Nakit çekim limiti (PROTOTİP alanı)"
          tooltip="Gerçekte limit yönetim sisteminden gelecek; rule handler bu değeri ISubjectAttributeProvider üzerinden okur."
        >
          <InputNumber min={0} step={5000} style={{ width: '100%' }} />
        </Form.Item>
        <Form.Item name="customerNo" label="Personelin kendi müşteri no (PROTOTİP)"><Input /></Form.Item>
        <Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item>
        <Form.Item name="isOnLeave" label="İzinde" valuePropName="checked"><Switch /></Form.Item>
      </Form>
    </Modal>
  )
}
