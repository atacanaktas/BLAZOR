import { Button, Card, Descriptions, Flex, Input, Table, Tabs, Tag, Typography } from 'antd'
import { EditOutlined, ExperimentOutlined, PlusOutlined, ThunderboltOutlined } from '@ant-design/icons'
import { useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api } from '../../api/client'
import type { AuthorizationChangeSet, ChangeImpactResult, EffectivePermissionSet } from '../../api/types'
import { toSelectOptions, useApi, useOptions } from '../../hooks/useApi'
import { ActiveTag, Code, PageHeader, SeverityTag, SourceList, fmt } from '../../components/common'
import { ChangeModal } from '../../components/ChangeModal'
import { ConfirmChangeModal } from '../../components/ConfirmChangeModal'
import { UserFormModal } from './UsersPage'

interface UserDetail {
  user: {
    id: number
    userName: string
    fullName: string
    title?: string
    email?: string
    isActive: boolean
    isOnLeave: boolean
    cashWithdrawalLimit: number
    customerNo?: string
    createdAt: string
    createdBy: string
    updatedAt?: string
    updatedBy?: string
    orgUnits: { organizationUnitId: number; code: string; name: string; isPrimary: boolean }[]
    roles: { roleId: number; code: string; name: string; isActive: boolean; assignedAt: string; assignedBy: string; validUntil?: string }[]
    directPermissions: { permissionId: number; code: string; name: string; reason?: string; assignedAt: string; assignedBy: string }[]
  }
  explicitGroups: { groupId: number; code: string; name: string }[]
}

type ModalKind = 'role' | 'permission' | 'orgUnit' | 'group' | null

export function UserDetailPage() {
  const id = Number(useParams().id)
  const navigate = useNavigate()
  const detail = useApi<UserDetail>(`/api/users/${id}`)
  const effective = useApi<EffectivePermissionSet>(`/api/users/${id}/effective`)
  const violations = useApi<{ id: number; rule: string; severity: string; status: string; detectedBy: string; detectedAt: string; details: string }[]>(`/api/users/${id}/violations`)
  const provisioning = useApi<{ id: number; permissionCode: string; externalSystemCode: string; externalPermissionCode: string; actionType: string; status: string; resultMessage: string; createdAt: string }[]>(`/api/users/${id}/provisioning`)
  const roles = useOptions('roles')
  const permissions = useOptions('permissions')
  const orgUnits = useOptions('orgUnits')
  const groups = useOptions('groups')
  const [modal, setModal] = useState<ModalKind>(null)
  const [editing, setEditing] = useState(false)
  const [filter, setFilter] = useState('')

  const reloadAll = () => {
    detail.reload()
    effective.reload()
    violations.reload()
    setTimeout(provisioning.reload, 2500) // outbox işleyicisi ~2 sn'de bir çalışır
  }

  // Kaldırma işlemleri: önce What-If etkisi, onaylanırsa DELETE
  const [pending, setPending] = useState<{ title: string; changeSet: AuthorizationChangeSet; path: string } | null>(null)
  const remove = (title: string, changeSet: AuthorizationChangeSet, path: string) => setPending({ title, changeSet, path })

  const u = detail.data?.user
  const perms = useMemo(
    () => (effective.data?.permissions ?? []).filter((p) => !filter || p.code.includes(filter.toUpperCase()) || p.name.toLowerCase().includes(filter.toLowerCase())),
    [effective.data, filter],
  )
  if (!u) return <Card loading />

  return (
    <>
      <PageHeader
        title={`${u.fullName}`}
        subtitle={<>{u.userName} · {u.title} · <ActiveTag active={u.isActive} />{u.isOnLeave && <Tag color="orange">İzinde</Tag>}</>}
        extra={
          <Flex gap={8}>
            <Button icon={<ExperimentOutlined />} onClick={() => navigate(`/what-if?tab=user&userId=${id}`)}>What-If</Button>
            <Button icon={<ThunderboltOutlined />} onClick={() => navigate(`/evaluate?user=${u.userName}`)}>Yetki testi</Button>
            <Button icon={<EditOutlined />} onClick={() => setEditing(true)}>Düzenle</Button>
          </Flex>
        }
      />

      <Tabs
        items={[
          {
            key: 'effective',
            label: `Effective yetkiler (${effective.data?.permissions.length ?? 0})`,
            children: (
              <Card size="small" extra={<Input.Search placeholder="Filtre" allowClear onChange={(e) => setFilter(e.target.value)} style={{ width: 240 }} />}
                title={<Typography.Text type="secondary">Her permission'ın kaynağı (authorization path) gösterilir · v{effective.data?.version}</Typography.Text>}>
                <Table
                  size="small"
                  rowKey="permissionId"
                  loading={effective.loading}
                  dataSource={perms}
                  pagination={false}
                  columns={[
                    { title: 'Permission', render: (_, p) => <><Code>{p.code}</Code><br /><Typography.Text type="secondary">{p.name}</Typography.Text></>, width: 260 },
                    { title: 'Domain', dataIndex: 'domain', width: 100, render: (v) => v && <Tag>{v}</Tag> },
                    {
                      title: 'Runtime',
                      width: 120,
                      render: (_, p) => (p.requiresRuntimeEvaluation ? <Tag color="purple" title="Bağlı policy var: işlem anında evaluate edilir">Policy'li</Tag> : <Tag>Statik</Tag>),
                    },
                    { title: 'Neden sahip? (kaynak)', render: (_, p) => <SourceList sources={p.sources} /> },
                  ]}
                />
              </Card>
            ),
          },
          {
            key: 'roles',
            label: 'Roller',
            children: (
              <Flex vertical gap={16}>
                <Card size="small" title="Doğrudan atanmış roller" extra={<Button icon={<PlusOutlined />} onClick={() => setModal('role')}>Rol ata</Button>}>
                  <Table
                    size="small"
                    rowKey="roleId"
                    pagination={false}
                    dataSource={u.roles}
                    columns={[
                      { title: 'Rol', render: (_, r) => <a onClick={() => navigate(`/roles/${r.roleId}`)}><Code>{r.code}</Code> {r.name}</a> },
                      { title: 'Atayan', dataIndex: 'assignedBy' },
                      { title: 'Tarih', dataIndex: 'assignedAt', render: fmt },
                      { title: 'Geçerlilik', dataIndex: 'validUntil', render: (v) => (v ? fmt(v) : 'Süresiz') },
                      {
                        title: '',
                        width: 90,
                        render: (_, r) => (
                          <Button size="small" danger onClick={() => remove(`${u.userName} kullanıcısından ${r.code} rolü alınırsa`, { userId: id, removeUserRoleIds: [r.roleId] }, `/api/users/${id}/roles/${r.roleId}`)}>Al…</Button>
                        ),
                      },
                    ]}
                  />
                </Card>
                <Card size="small" title="Effective roller (doğrudan + gruplardan)">
                  <Table
                    size="small"
                    rowKey="roleId"
                    pagination={false}
                    dataSource={effective.data?.roles ?? []}
                    columns={[
                      { title: 'Rol', render: (_, r) => <><Code>{r.code}</Code> {r.name}</> },
                      { title: 'Kaynak', render: (_, r) => r.sources.map((s, i) => <Tag key={i} color={s.type === 'Direct' ? 'blue' : 'purple'}>{s.text}</Tag>) },
                    ]}
                  />
                </Card>
              </Flex>
            ),
          },
          {
            key: 'groups',
            label: `Gruplar (${effective.data?.groups.length ?? 0})`,
            children: (
              <Flex vertical gap={16}>
                <Card size="small" title="Grup üyelikleri ve nedenleri" extra={<Button icon={<PlusOutlined />} onClick={() => setModal('group')}>Gruba doğrudan ekle</Button>}>
                  <Table
                    size="small"
                    rowKey="groupId"
                    pagination={false}
                    dataSource={effective.data?.groups ?? []}
                    columns={[
                      { title: 'Grup', render: (_, g) => <a onClick={() => navigate(`/groups/${g.groupId}`)}><Code>{g.code}</Code> {g.name}</a> },
                      { title: 'Neden üye?', render: (_, g) => g.reasons.map((r, i) => <div key={i}><Tag>{r.type}</Tag>{r.text}</div>) },
                      {
                        title: '',
                        width: 110,
                        render: (_, g) =>
                          detail.data?.explicitGroups.some((x) => x.groupId === g.groupId) && (
                            <Button size="small" danger onClick={() => remove(`${u.userName} ${g.code} grubundan çıkarılırsa`, { groupChanges: [{ groupId: g.groupId, kind: 'AudienceUser', targetId: id, add: false }] }, `/api/groups/${g.groupId}/items/AudienceUser/${id}`)}>Çıkar…</Button>
                          ),
                      },
                    ]}
                  />
                </Card>
              </Flex>
            ),
          },
          {
            key: 'direct',
            label: 'Doğrudan permission',
            children: (
              <Card size="small" title="Doğrudan permission atamaları (legacy / istisna — ana model değil)"
                extra={<Button icon={<PlusOutlined />} onClick={() => setModal('permission')}>Permission ver</Button>}>
                <Table
                  size="small"
                  rowKey="permissionId"
                  pagination={false}
                  dataSource={u.directPermissions}
                  columns={[
                    { title: 'Permission', render: (_, p) => <><Code>{p.code}</Code> {p.name}</> },
                    { title: 'Gerekçe', dataIndex: 'reason' },
                    { title: 'Atayan', dataIndex: 'assignedBy' },
                    { title: 'Tarih', dataIndex: 'assignedAt', render: fmt },
                    {
                      title: '',
                      width: 90,
                      render: (_, p) => (
                        <Button size="small" danger onClick={() => remove(`${u.userName} kullanıcısından doğrudan ${p.code} alınırsa`, { userId: id, removeUserPermissionIds: [p.permissionId] }, `/api/users/${id}/permissions/${p.permissionId}`)}>Al…</Button>
                      ),
                    },
                  ]}
                />
              </Card>
            ),
          },
          {
            key: 'info',
            label: 'Bilgiler & birimler',
            children: (
              <Flex vertical gap={16}>
                <Descriptions bordered size="small" column={{ xs: 1, md: 2 }}>
                  <Descriptions.Item label="Kullanıcı adı">{u.userName}</Descriptions.Item>
                  <Descriptions.Item label="E-posta">{u.email}</Descriptions.Item>
                  <Descriptions.Item label="Nakit çekim limiti (prototip)">{u.cashWithdrawalLimit.toLocaleString('tr-TR')} TL</Descriptions.Item>
                  <Descriptions.Item label="Müşteri no (prototip)">{u.customerNo ?? '—'}</Descriptions.Item>
                  <Descriptions.Item label="Oluşturma">{fmt(u.createdAt)} · {u.createdBy}</Descriptions.Item>
                  <Descriptions.Item label="Güncelleme">{fmt(u.updatedAt)} · {u.updatedBy ?? '—'}</Descriptions.Item>
                </Descriptions>
                <Card size="small" title="Birimler" extra={<Button icon={<PlusOutlined />} onClick={() => setModal('orgUnit')}>Birim ekle</Button>}>
                  <Table
                    size="small"
                    rowKey="organizationUnitId"
                    pagination={false}
                    dataSource={u.orgUnits}
                    columns={[
                      { title: 'Birim', render: (_, o) => <><Code>{o.code}</Code> {o.name}</> },
                      { title: 'Birincil', dataIndex: 'isPrimary', render: (v) => (v ? <Tag color="blue">Birincil</Tag> : '') },
                      {
                        title: '',
                        width: 90,
                        render: (_, o) => (
                          <Button size="small" danger onClick={() => remove(`${u.userName} ${o.code} biriminden çıkarılırsa`, { userId: id, removeUserOrgUnitIds: [o.organizationUnitId] }, `/api/users/${id}/org-units/${o.organizationUnitId}`)}>Çıkar…</Button>
                        ),
                      },
                    ]}
                  />
                </Card>
              </Flex>
            ),
          },
          {
            key: 'sod',
            label: <>SoD ihlalleri {violations.data?.length ? <Tag color="red">{violations.data.length}</Tag> : null}</>,
            children: (
              <Table
                size="small"
                rowKey="id"
                pagination={false}
                dataSource={violations.data ?? []}
                columns={[
                  { title: 'Kural', dataIndex: 'rule', render: (v) => <Code>{v}</Code> },
                  { title: 'Önem', dataIndex: 'severity', render: (v) => <SeverityTag severity={v} /> },
                  { title: 'Durum', dataIndex: 'status', render: (v) => <Tag>{v}</Tag> },
                  { title: 'Tespit', render: (_, v) => <>{v.detectedBy}<br />{fmt(v.detectedAt)}</> },
                  { title: 'Detay', dataIndex: 'details' },
                ]}
              />
            ),
          },
          {
            key: 'prov',
            label: 'Provisioning',
            children: (
              <Table
                size="small"
                rowKey="id"
                pagination={false}
                dataSource={provisioning.data ?? []}
                columns={[
                  { title: 'Zaman', dataIndex: 'createdAt', render: fmt },
                  { title: 'Permission', dataIndex: 'permissionCode', render: (v) => <Code>{v}</Code> },
                  { title: 'Sistem', dataIndex: 'externalSystemCode', render: (v) => <Tag color="cyan">{v}</Tag> },
                  { title: 'Dış yetki', dataIndex: 'externalPermissionCode' },
                  { title: 'Aksiyon', dataIndex: 'actionType', render: (v) => <Tag color={v === 'Grant' ? 'green' : 'volcano'}>{v}</Tag> },
                  { title: 'Durum', dataIndex: 'status' },
                  { title: 'Sonuç', dataIndex: 'resultMessage', render: (v) => <Typography.Text type="secondary" style={{ fontSize: 12 }}>{v}</Typography.Text> },
                ]}
              />
            ),
          },
        ]}
      />

      <ChangeModal
        open={modal === 'role'}
        title={`${u.userName} — rol ata`}
        label="Rol"
        options={toSelectOptions(roles, u.roles.map((r) => r.roleId))}
        buildChangeSet={(t) => ({ userId: id, addUserRoleIds: [t] })}
        apply={(t) => api.post(`/api/users/${id}/roles`, { roleId: t })}
        onClose={() => setModal(null)}
        onDone={reloadAll}
      />
      <ChangeModal
        open={modal === 'permission'}
        title={`${u.userName} — doğrudan permission ver (istisna)`}
        label="Permission"
        options={toSelectOptions(permissions, u.directPermissions.map((p) => p.permissionId))}
        buildChangeSet={(t) => ({ userId: id, addUserPermissionIds: [t] })}
        apply={(t) => api.post(`/api/users/${id}/permissions`, { permissionId: t, reason: 'Yönetim ekranından istisna ataması' })}
        onClose={() => setModal(null)}
        onDone={reloadAll}
      />
      <ChangeModal
        open={modal === 'orgUnit'}
        title={`${u.userName} — birime ekle`}
        label="Birim (grup kitlelerini etkileyebilir)"
        options={toSelectOptions(orgUnits, u.orgUnits.map((o) => o.organizationUnitId))}
        buildChangeSet={(t) => ({ userId: id, addUserOrgUnitIds: [t] })}
        apply={(t) => api.post(`/api/users/${id}/org-units`, { orgUnitId: t, isPrimary: false })}
        onClose={() => setModal(null)}
        onDone={reloadAll}
      />
      <ChangeModal
        open={modal === 'group'}
        title={`${u.userName} — gruba doğrudan ekle`}
        label="Grup"
        options={toSelectOptions(groups, detail.data?.explicitGroups.map((g) => g.groupId))}
        buildChangeSet={(t) => ({ groupChanges: [{ groupId: t, kind: 'AudienceUser', targetId: id, add: true }] })}
        apply={(t) => api.post(`/api/groups/${t}/items`, { kind: 'AudienceUser', targetId: id })}
        onClose={() => setModal(null)}
        onDone={reloadAll}
      />
      <ConfirmChangeModal
        open={!!pending}
        title={pending ? `Etki: ${pending.title}` : ''}
        changeSet={pending?.changeSet ?? {}}
        apply={() => api.del<ChangeImpactResult>(pending!.path)}
        onClose={() => setPending(null)}
        onDone={reloadAll}
      />
      <UserFormModal
        open={editing}
        id={id}
        initial={{ ...u }}
        onClose={() => setEditing(false)}
        onSaved={reloadAll}
      />
    </>
  )
}
