import { Alert, Button, Card, Col, Flex, Input, Row, Select, Tag, Typography } from 'antd'
import { SendOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { SAMPLE_APP_URL, api } from '../api/client'
import { useOptions } from '../hooks/useApi'
import { PageHeader } from '../components/common'
import { channels } from './EvaluatePage'

interface Scenario {
  key: string
  title: string
  method: 'GET' | 'POST'
  path: string
  body: unknown
  code: string
}

const scenarios: Scenario[] = [
  {
    key: 'withdraw',
    title: 'Nakit çekim (policy\'li)',
    method: 'POST',
    path: '/api/cash/withdraw',
    body: { musteriNo: '555', tutar: 20000, dovizKodu: 'TRY', aciklama: 'demo' },
    code: `public sealed class NakitCekimTalebi
{
    [AuthContext(AuthContextType.CustomerId)]
    public string MusteriNo { get; set; }

    [AuthContext(AuthContextType.TransactionAmount)]
    public decimal Tutar { get; set; }
}

[HttpPost("withdraw")]
[RequiresPermission("CASH_WITHDRAW", Action = "withdraw")]
public IActionResult Withdraw([FromBody] NakitCekimTalebi talep) => Ok(...);`,
  },
  {
    key: 'view',
    title: 'Vadeli listesi (statik)',
    method: 'GET',
    path: '/api/term-deposits',
    body: null,
    code: `[HttpGet]
[RequiresPermission("TERM_DEPOSIT_VIEW")]
public IActionResult List() => Ok(...);`,
  },
  {
    key: 'close',
    title: 'Vadeli kapama (şube eşleşmesi)',
    method: 'POST',
    path: '/api/term-deposits/TR120001/close',
    body: { islemSubesi: '101' },
    code: `[HttpPost("{accountNo}/close")]
[RequiresPermission("TERM_DEPOSIT_CLOSE", ResourceType = "account")]
public IActionResult Close(
    [FromRoute, AuthContext(AuthContextType.AccountNo)] string accountNo,
    [FromBody] VadeliKapamaTalebi talep)   // [AuthContext(BranchCode)] IslemSubesi
    => Ok(...);`,
  },
  {
    key: 'credit',
    title: 'Kredi onayı (iç içe DTO)',
    method: 'POST',
    path: '/api/credits/approve',
    body: { applicationNo: 'KRD-2026-001', loan: { principalAmount: 750000, termMonths: 36 } },
    code: `public sealed class CreditApprovalRequest
{
    public string ApplicationNo { get; set; }
    public LoanDetails Loan { get; set; }
    public sealed class LoanDetails
    {
        [AuthContext(AuthContextType.TransactionAmount)]
        public decimal PrincipalAmount { get; set; }
    }
}`,
  },
]

export function SdkDemoPage() {
  const users = useOptions('users')
  const [scenario, setScenario] = useState(scenarios[0])
  const [user, setUser] = useState('ahmet.yilmaz')
  const [channel, setChannel] = useState<string | undefined>('CASH_DESK')
  const [body, setBody] = useState(JSON.stringify(scenarios[0].body, null, 2))
  const [result, setResult] = useState<{ status: number; data: unknown }>()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string>()

  const send = async () => {
    setLoading(true)
    setError(undefined)
    try {
      const headers: Record<string, string> = { 'X-User': user }
      if (channel) headers['X-Channel'] = channel
      setResult(await api.sample(scenario.method, scenario.path, scenario.method === 'GET' ? null : JSON.parse(body || '{}'), headers))
    } catch (e) {
      setError(`Örnek uygulamaya ulaşılamadı (${SAMPLE_APP_URL}). samples/Yetki.Sample.CashDesk çalışıyor mu? ${(e as Error).message}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <PageHeader
        title="SDK Demo"
        subtitle="Örnek iş uygulaması (Yetki.Sample.CashDesk) Yetki SDK'sını kullanır: iş kodunda yetki if'i yok; [RequiresPermission] + DTO'da [AuthContext(AuthContextType.X)]."
      />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={10}>
          <Card size="small" title="İstek">
            <Flex vertical gap={10}>
              <Select value={scenario.key} onChange={(k) => { const s = scenarios.find((x) => x.key === k)!; setScenario(s); setBody(JSON.stringify(s.body, null, 2)); setResult(undefined) }}
                options={scenarios.map((s) => ({ value: s.key, label: s.title }))} />
              <Flex gap={8}>
                <Select showSearch style={{ flex: 1 }} value={user} onChange={setUser} options={users.map((u) => ({ value: u.code, label: `X-User: ${u.code}` }))} />
                <Select allowClear style={{ width: 190 }} value={channel} onChange={setChannel} placeholder="X-Channel" options={channels.map((c) => ({ value: c, label: `X-Channel: ${c}` }))} />
              </Flex>
              <Typography.Text code>{scenario.method} {SAMPLE_APP_URL}{scenario.path}</Typography.Text>
              {scenario.method !== 'GET' && <Input.TextArea rows={7} value={body} onChange={(e) => setBody(e.target.value)} style={{ fontFamily: 'monospace' }} />}
              <Button type="primary" icon={<SendOutlined />} loading={loading} onClick={send}>Gönder</Button>
              <Alert type="info" showIcon message="Kullanıcı, IP, zaman SDK tarafından otomatik toplanır. Kanal, güvenilir gateway header'ından okunur (prototipte X-Channel). Mesai dışında policy'li işlemler DENY döner — bu beklenen davranıştır." />
            </Flex>
          </Card>
          <Card size="small" title="İş uygulamasındaki kod" style={{ marginTop: 16 }}>
            <pre style={{ margin: 0, fontSize: 12, whiteSpace: 'pre-wrap' }}>{scenario.code}</pre>
          </Card>
        </Col>
        <Col xs={24} xl={14}>
          {error && <Alert type="error" showIcon message={error} />}
          {result && (
            <Card size="small" title={<>HTTP <Tag color={result.status < 300 ? 'green' : result.status === 403 ? 'red' : 'orange'}>{result.status}</Tag></>}>
              <pre style={{ margin: 0, fontSize: 12, whiteSpace: 'pre-wrap' }}>{JSON.stringify(result.data, null, 2)}</pre>
            </Card>
          )}
        </Col>
      </Row>
    </>
  )
}
