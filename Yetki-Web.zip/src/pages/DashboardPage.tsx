import { Card, Col, Row, Statistic, Table, Tag, Typography } from 'antd'
import { useNavigate } from 'react-router-dom'
import { useApi } from '../hooks/useApi'
import { Code, DecisionTag, PageHeader, fmt } from '../components/common'

interface Dashboard {
  authorizationVersion: number
  counts: Record<string, number>
  decisionsLast24h: { decision: string; count: number }[]
  recentDecisions: { id: string; timestamp: string; subjectUserName: string; permissionCode: string; decision: string; reasonCode: string; category: string }[]
  recentChanges: { id: string; timestamp: string; actor: string; action: string; summary: string }[]
  recentProvisioning: { id: number; userName: string; permissionCode: string; externalSystemCode: string; externalPermissionCode: string; actionType: string; status: string }[]
}

export function DashboardPage() {
  const { data } = useApi<Dashboard>('/api/dashboard')
  const navigate = useNavigate()
  const c = data?.counts ?? {}
  const stat = (title: string, key: string, to: string, color?: string) => (
    <Col xs={12} md={6} xl={3}>
      <Card size="small" hoverable onClick={() => navigate(to)}>
        <Statistic title={title} value={c[key] ?? 0} valueStyle={color ? { color } : undefined} />
      </Card>
    </Col>
  )

  return (
    <>
      <PageHeader title="Genel Bakış" subtitle="RBAC + Policy/Rule tabanlı hibrit yetki motoru — tüm kararlar API'de, deterministik ve açıklanabilir." />
      <Row gutter={[12, 12]}>
        {stat('Kullanıcı', 'users', '/users')}
        {stat('Rol', 'roles', '/roles')}
        {stat('Permission', 'permissions', '/permissions')}
        {stat('Grup', 'groups', '/groups')}
        {stat('Policy', 'policies', '/policies')}
        {stat('Rule', 'rules', '/rules')}
        {stat('Açık SoD ihlali', 'openViolations', '/sod', (c.openViolations ?? 0) > 0 ? '#cf1322' : undefined)}
        {stat('Provisioning', 'provisioningActions', '/events')}
      </Row>

      <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
        <Col xs={24} xl={12}>
          <Card title="Son yetki kararları" size="small" extra={<a onClick={() => navigate('/audit')}>Tümü</a>}>
            <Table
              size="small"
              rowKey="id"
              pagination={false}
              dataSource={data?.recentDecisions ?? []}
              columns={[
                { title: 'Zaman', dataIndex: 'timestamp', render: fmt, width: 150 },
                { title: 'Kullanıcı', dataIndex: 'subjectUserName' },
                { title: 'Permission', dataIndex: 'permissionCode', render: (v) => <Code>{v}</Code> },
                { title: 'Karar', dataIndex: 'decision', render: (v, r) => <><DecisionTag decision={v} />{r.category === 'Simulation' && <Tag color="purple">sim</Tag>}</> },
                { title: 'Neden', dataIndex: 'reasonCode', render: (v) => <Typography.Text type="secondary">{v}</Typography.Text> },
              ]}
            />
          </Card>
        </Col>
        <Col xs={24} xl={12}>
          <Card title="Son yönetim değişiklikleri" size="small" extra={<a onClick={() => navigate('/audit')}>Tümü</a>}>
            <Table
              size="small"
              rowKey="id"
              pagination={false}
              dataSource={data?.recentChanges ?? []}
              columns={[
                { title: 'Zaman', dataIndex: 'timestamp', render: fmt, width: 150 },
                { title: 'Kim', dataIndex: 'actor', width: 110 },
                { title: 'Özet', dataIndex: 'summary' },
              ]}
            />
          </Card>
        </Col>
        <Col xs={24}>
          <Card title="Son provisioning aksiyonları (dummy adaptör)" size="small" extra={<a onClick={() => navigate('/events')}>Tümü</a>}>
            <Table
              size="small"
              rowKey="id"
              pagination={false}
              dataSource={data?.recentProvisioning ?? []}
              columns={[
                { title: 'Kullanıcı', dataIndex: 'userName' },
                { title: 'Permission', dataIndex: 'permissionCode', render: (v) => <Code>{v}</Code> },
                { title: 'Sistem', dataIndex: 'externalSystemCode', render: (v) => <Tag color="cyan">{v}</Tag> },
                { title: 'Dış yetki', dataIndex: 'externalPermissionCode' },
                { title: 'Aksiyon', dataIndex: 'actionType', render: (v) => <Tag color={v === 'Grant' ? 'green' : 'volcano'}>{v}</Tag> },
                { title: 'Durum', dataIndex: 'status', render: (v) => <Tag color={v === 'Completed' ? 'green' : v === 'Failed' ? 'red' : 'default'}>{v}</Tag> },
              ]}
            />
          </Card>
        </Col>
      </Row>
    </>
  )
}
