import { Alert, App, Button, Card, Col, DatePicker, Flex, Form, Input, InputNumber, Row, Segmented, Select, Typography } from 'antd'
import { ThunderboltOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import dayjs, { type Dayjs } from 'dayjs'
import { api } from '../api/client'
import type { AuthorizationChangeSet, AuthorizationDecision } from '../api/types'
import { toSelectOptions, useOptions } from '../hooks/useApi'
import { DecisionView } from '../components/DecisionView'
import { PageHeader } from '../components/common'

export const channels = ['CASH_DESK', 'BRANCH', 'INTERNET', 'MOBILE', 'CALL_CENTER']

interface EvalForm {
  userName: string
  permission: string
  TransactionAmount?: number
  Channel?: string
  CustomerId?: string
  BranchCode?: string
  IpAddress?: string
  Currency?: string
  Platform?: string
  asOf?: Dayjs
  addRoleIds?: number[]
}

/**
 * Karar test formu. mode=real: /api/authorization/evaluate (motor saati, gerçek audit).
 * mode=simulation: /api/simulation/evaluate (belirli an + opsiyonel atama değişikliği).
 */
export function EvaluateForm({ allowChanges = false, defaultMode = 'real' }: { allowChanges?: boolean; defaultMode?: 'real' | 'simulation' }) {
  const [params] = useSearchParams()
  const [form] = Form.useForm<EvalForm>()
  const { message } = App.useApp()
  const users = useOptions('users')
  const permissions = useOptions('permissions')
  const roles = useOptions('roles')
  const [mode, setMode] = useState<'real' | 'simulation'>(allowChanges ? 'simulation' : defaultMode)
  const [result, setResult] = useState<AuthorizationDecision>()
  const [loading, setLoading] = useState(false)

  const presets: Record<string, Partial<EvalForm>> = {
    'Nakit çekim 20.000 (vezne)': { userName: 'ahmet.yilmaz', permission: 'CASH_WITHDRAW', TransactionAmount: 20000, Channel: 'CASH_DESK', CustomerId: '555', IpAddress: '10.1.2.3' },
    'Limit aşımı 75.000': { userName: 'ahmet.yilmaz', permission: 'CASH_WITHDRAW', TransactionAmount: 75000, Channel: 'CASH_DESK', CustomerId: '555', IpAddress: '10.1.2.3' },
    'Kendi hesabı': { userName: 'ahmet.yilmaz', permission: 'CASH_WITHDRAW', TransactionAmount: 1000, Channel: 'CASH_DESK', CustomerId: '10001', IpAddress: '10.1.2.3' },
    'İzinli kullanıcı': { userName: 'elif.sahin', permission: 'CASH_WITHDRAW', TransactionAmount: 1000, Channel: 'CASH_DESK', CustomerId: '555', IpAddress: '10.1.2.3' },
    'Banka ağı dışı': { userName: 'ahmet.yilmaz', permission: 'CASH_WITHDRAW', TransactionAmount: 1000, Channel: 'CASH_DESK', CustomerId: '555', IpAddress: '85.100.1.1' },
    'Eksik context': { userName: 'ahmet.yilmaz', permission: 'CASH_WITHDRAW', TransactionAmount: undefined, Channel: 'CASH_DESK', CustomerId: '555', IpAddress: '10.1.2.3' },
    'Kredi onayı 2M': { userName: 'zeynep.celik', permission: 'CREDIT_APPROVE', TransactionAmount: 2000000, IpAddress: '10.1.2.3' },
    'Yetkisiz': { userName: 'mehmet.kaya', permission: 'CASH_WITHDRAW', TransactionAmount: 100, Channel: 'CASH_DESK' },
  }

  const submit = async () => {
    const v = await form.validateFields()
    const context: Record<string, string> = {}
    for (const k of ['TransactionAmount', 'Channel', 'Platform', 'CustomerId', 'BranchCode', 'IpAddress', 'Currency'] as const) {
      const val = v[k]
      if (val !== undefined && val !== null && val !== '') context[k] = String(val)
    }
    const request = { subject: { userName: v.userName }, permission: v.permission, context, application: 'yetki-web-tester' }
    setLoading(true)
    try {
      if (mode === 'real') {
        setResult(await api.post<AuthorizationDecision>('/api/authorization/evaluate', request))
      } else {
        const users_ = users.find((u) => u.code === v.userName)
        const changes: AuthorizationChangeSet | undefined =
          allowChanges && v.addRoleIds?.length && users_ ? { userId: users_.id, addUserRoleIds: v.addRoleIds } : undefined
        setResult(await api.post<AuthorizationDecision>('/api/simulation/evaluate', { request, changes, asOfUtc: v.asOf?.toISOString() }))
      }
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Row gutter={[16, 16]}>
      <Col xs={24} xl={9}>
        <Card size="small">
          {!allowChanges && (
            <Segmented
              block
              value={mode}
              onChange={(v) => setMode(v as 'real' | 'simulation')}
              options={[{ value: 'real', label: 'Gerçek karar' }, { value: 'simulation', label: 'Simülasyon (zaman seçilebilir)' }]}
              style={{ marginBottom: 12 }}
            />
          )}
          <Flex wrap gap={4} style={{ marginBottom: 12 }}>
            {Object.entries(presets).map(([label, p]) => (
              <Button key={label} size="small" onClick={() => form.setFieldsValue({ TransactionAmount: undefined, CustomerId: undefined, Channel: undefined, IpAddress: undefined, BranchCode: undefined, Platform: undefined, ...p })}>{label}</Button>
            ))}
          </Flex>
          <Form
            form={form}
            layout="vertical"
            initialValues={{ userName: params.get('user') ?? 'ahmet.yilmaz', permission: 'CASH_WITHDRAW', Channel: 'CASH_DESK', TransactionAmount: 20000, CustomerId: '555', IpAddress: '10.1.2.3', asOf: nextBusinessMorning() }}
          >
            <Form.Item name="userName" label="Kullanıcı" rules={[{ required: true }]}>
              <Select showSearch options={users.map((u) => ({ value: u.code, label: `${u.code} — ${u.name}` }))} optionFilterProp="label" />
            </Form.Item>
            <Form.Item name="permission" label="Permission / aksiyon" rules={[{ required: true }]}>
              <Select showSearch options={permissions.map((p) => ({ value: p.code, label: `${p.code} — ${p.name}` }))} optionFilterProp="label" />
            </Form.Item>
            <Typography.Text strong>Context</Typography.Text>
            <Row gutter={8}>
              <Col span={12}><Form.Item name="TransactionAmount" label="TransactionAmount"><InputNumber style={{ width: '100%' }} min={0} step={1000} /></Form.Item></Col>
              <Col span={12}><Form.Item name="Channel" label="Channel"><Select allowClear options={channels.map((c) => ({ value: c, label: c }))} /></Form.Item></Col>
              <Col span={12}><Form.Item name="CustomerId" label="CustomerId"><Input /></Form.Item></Col>
              <Col span={12}><Form.Item name="BranchCode" label="BranchCode"><Input placeholder="101" /></Form.Item></Col>
              <Col span={12}><Form.Item name="IpAddress" label="IpAddress"><Input placeholder="10.1.2.3" /></Form.Item></Col>
              <Col span={12}><Form.Item name="Platform" label="Platform"><Select allowClear options={['BRANCH_DESKTOP', 'MOBILE', 'INTERNET'].map((c) => ({ value: c, label: c }))} /></Form.Item></Col>
            </Row>
            {mode === 'simulation' && (
              <Form.Item name="asOf" label="Karar anı (simülasyon)" tooltip="Gerçek kararda zaman her zaman motorun saatidir; çağıran değiştiremez.">
                <DatePicker showTime style={{ width: '100%' }} />
              </Form.Item>
            )}
            {allowChanges && (
              <Form.Item name="addRoleIds" label="What-If: kullanıcıya şu roller verilirse" tooltip="Değişiklik kaydedilmez; aynı evaluator change set ile çalışır.">
                <Select mode="multiple" options={toSelectOptions(roles)} optionFilterProp="label" />
              </Form.Item>
            )}
            <Button type="primary" icon={<ThunderboltOutlined />} block loading={loading} onClick={submit}>Değerlendir</Button>
          </Form>
        </Card>
      </Col>
      <Col xs={24} xl={15}>
        {result ? <DecisionView decision={result} /> : <Alert type="info" showIcon message="Kullanıcı, permission ve context girip değerlendirin. Sonuç Permit / Deny / NotApplicable / Indeterminate; kararı veren policy ve rule, condition sonuçları ve kullanılan attribute değerleriyle döner." />}
      </Col>
    </Row>
  )
}

function nextBusinessMorning() {
  let d = dayjs().hour(11).minute(0).second(0)
  while (d.day() === 0 || d.day() === 6) d = d.add(1, 'day')
  return d
}

export function EvaluatePage() {
  return (
    <>
      <PageHeader title="Yetki Testi" subtitle="POST /api/authorization/evaluate — SDK'ların çağırdığı aynı uç. Kararlar audit'e yazılır." />
      <EvaluateForm />
    </>
  )
}
