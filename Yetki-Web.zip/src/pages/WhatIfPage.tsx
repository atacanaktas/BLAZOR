import { Alert, App, Button, Card, Col, Flex, Form, Input, InputNumber, Row, Select, Switch, Table, Tabs, Tag, Typography } from 'antd'
import { ExperimentOutlined } from '@ant-design/icons'
import { useMemo, useState, type ReactNode } from 'react'
import { useSearchParams } from 'react-router-dom'
import type { Dayjs } from 'dayjs'
import { api } from '../api/client'
import type { AuthorizationChangeSet, ChangeImpactResult, CombiningAlgorithm, ConditionDraft, ConditionTypeInfo, ConditionView, GroupChangeKind, ImpactScenario, Option, ParamDef, PolicyChangeSet, RuleEffect, RuleView, SharedConditionInfo } from '../api/types'
import { toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { ImpactView } from '../components/ImpactView'
import { Code, PageHeader, algorithmLabel } from '../components/common'
import { ConditionBuilder, emptyPredicate, renderDraft, toDraft } from '../components/ConditionBuilder'
import { DEFAULT_SCENARIOS, PolicyImpactView, ScenarioSettings, nextBusinessMorning, usePolicyImpact } from '../components/PolicyImpact'
import { EvaluateForm } from './EvaluatePage'

export function WhatIfPage() {
  const [params] = useSearchParams()
  const num = (k: string) => Number(params.get(k)) || undefined
  return (
    <>
      <PageHeader
        title="What-If / Simülasyon"
        subtitle="Değişiklikleri uygulamadan etkisini görün: kim hangi yetkiyi kaybeder/kazanır, hangi kararlar değişir. Simülasyon gerçek hesaplayıcı ve evaluator'ı kullanır."
      />
      <Tabs
        defaultActiveKey={params.get('tab') ?? 'role'}
        destroyOnHidden={false}
        items={[
          { key: 'role', label: 'Rol → yetki ekle/çıkar', children: <RoleSimulation initialRoleId={num('roleId')} /> },
          { key: 'user', label: 'Kullanıcı → rol/yetki ver/al', children: <UserSimulation initialUserId={num('userId')} /> },
          { key: 'group', label: 'Grup değişikliği', children: <GroupSimulation initialGroupId={num('groupId')} /> },
          { key: 'policy', label: 'Policy / Rule değişikliği', children: <PolicySimulation initialPolicyId={num('policyId')} initialPermissionId={num('permissionId')} /> },
          { key: 'evaluate', label: 'Karar simülasyonu', children: <EvaluateForm allowChanges /> },
          { key: 'sod', label: 'SoD kuralı etkisi', children: <SodImpact /> },
        ]}
      />
    </>
  )
}

// ================================================================ ortak yardımcılar

/** Mevcut duruma göre "eklenecek" (mevcut olmayanlar) ve "çıkarılacak" (mevcut olanlar) seçimleri. */
function DiffSelect({ label, all, current, add, remove, onAdd, onRemove }: {
  label: string
  all: Option[]
  current: number[]
  add: number[]
  remove: number[]
  onAdd: (v: number[]) => void
  onRemove: (v: number[]) => void
}) {
  const currentOpts = toSelectOptions(all.filter((o) => current.includes(o.id)))
  const otherOpts = toSelectOptions(all.filter((o) => !current.includes(o.id)))
  return (
    <div style={{ marginBottom: 12 }}>
      <Typography.Text strong>{label}</Typography.Text>
      <Flex wrap gap={4} style={{ margin: '4px 0' }}>
        {current.length === 0 && <Typography.Text type="secondary" style={{ fontSize: 12 }}>Şu an: yok</Typography.Text>}
        {all.filter((o) => current.includes(o.id)).map((o) => (
          <Tag key={o.id} color={remove.includes(o.id) ? 'red' : 'blue'} style={{ cursor: 'pointer', textDecoration: remove.includes(o.id) ? 'line-through' : undefined }}
            title="Tıklayarak çıkarılacaklara ekle/çıkar"
            onClick={() => onRemove(remove.includes(o.id) ? remove.filter((x) => x !== o.id) : [...remove, o.id])}>
            {o.code}
          </Tag>
        ))}
      </Flex>
      <Row gutter={8}>
        <Col span={12}>
          <Select mode="multiple" allowClear placeholder="− Çıkarılacak (mevcut)" value={remove} onChange={onRemove} options={currentOpts} optionFilterProp="label" style={{ width: '100%' }} />
        </Col>
        <Col span={12}>
          <Select mode="multiple" allowClear placeholder="+ Eklenecek" value={add} onChange={onAdd} options={otherOpts} optionFilterProp="label" style={{ width: '100%' }} />
        </Col>
      </Row>
    </div>
  )
}

type Pair = { add: number[]; remove: number[] }
const emptyPair = (): Pair => ({ add: [], remove: [] })

function usePairs<K extends string>(keys: readonly K[]) {
  const init = () => Object.fromEntries(keys.map((k) => [k, emptyPair()])) as Record<K, Pair>
  const [pairs, setPairs] = useState<Record<K, Pair>>(init)
  const bind = (k: K) => ({
    add: pairs[k].add,
    remove: pairs[k].remove,
    onAdd: (v: number[]) => setPairs((p) => ({ ...p, [k]: { ...p[k], add: v } })),
    onRemove: (v: number[]) => setPairs((p) => ({ ...p, [k]: { ...p[k], remove: v } })),
  })
  return { pairs, bind, reset: () => setPairs(init()) }
}

function useChangeImpact() {
  const { message } = App.useApp()
  const [result, setResult] = useState<ChangeImpactResult>()
  const [loading, setLoading] = useState(false)
  const run = async (cs: AuthorizationChangeSet) => {
    setLoading(true)
    try {
      setResult(await api.post<ChangeImpactResult>('/api/simulation/changes', cs))
    } catch (e) {
      message.error((e as Error).message)
      setResult(undefined)
    } finally {
      setLoading(false)
    }
  }
  return { result, loading, run, setResult }
}

function SimLayout({ left, right, hint }: { left: ReactNode; right?: ReactNode; hint: string }) {
  return (
    <Row gutter={[16, 16]}>
      <Col xs={24} xl={9}><Card size="small">{left}</Card></Col>
      <Col xs={24} xl={15}>{right ?? <Alert type="info" showIcon message={hint} />}</Col>
    </Row>
  )
}

// ================================================================ Rol

function RoleSimulation({ initialRoleId }: { initialRoleId?: number }) {
  const roles = useOptions('roles')
  const permissions = useOptions('permissions')
  const [roleId, setRoleId] = useState<number | undefined>(initialRoleId)
  const role = useApi<{ role: { permissions: { permissionId: number }[] }; users: unknown[]; grantingGroups: unknown[] }>(roleId ? `/api/roles/${roleId}` : null)
  const { pairs, bind, reset } = usePairs(['perms'] as const)
  const { result, loading, run, setResult } = useChangeImpact()
  const current = role.data?.role.permissions.map((p) => p.permissionId) ?? []

  const simulate = () =>
    roleId && run({
      rolePermissionChanges: [
        ...pairs.perms.remove.map((p) => ({ roleId, permissionId: p, add: false })),
        ...pairs.perms.add.map((p) => ({ roleId, permissionId: p, add: true })),
      ],
    })

  return (
    <SimLayout
      hint="Rolden yetki çıkarıldığında rolü doğrudan veya grup üzerinden taşıyan HERKES için: kim kaybeder, kim başka kaynaktan korur, RACF/LDAP'ta ne geri alınır. Eklemede: kim kazanır, SoD çakışması oluşur mu."
      left={
        <>
          <Form.Item label="Rol" layout="vertical">
            <Select showSearch value={roleId} onChange={(v) => { setRoleId(v); reset(); setResult(undefined) }} options={toSelectOptions(roles)} optionFilterProp="label" placeholder="Rol seçin" />
          </Form.Item>
          {roleId && role.data && (
            <>
              <Typography.Paragraph type="secondary">
                Rolü doğrudan taşıyan {role.data.users.length} kullanıcı{role.data.grantingGroups.length ? ` + ${role.data.grantingGroups.length} grup üzerinden gelenler` : ''} kapsamdadır.
              </Typography.Paragraph>
              <DiffSelect label="Rolün permission'ları" all={permissions} current={current} {...bind('perms')} />
            </>
          )}
          <Button type="primary" block icon={<ExperimentOutlined />} loading={loading} disabled={!roleId || pairs.perms.add.length + pairs.perms.remove.length === 0} onClick={simulate}>
            Etkiyi hesapla
          </Button>
        </>
      }
      right={result && <ImpactView impact={result} />}
    />
  )
}

// ================================================================ Kullanıcı

interface UserDetail {
  user: { roles: { roleId: number }[]; directPermissions: { permissionId: number }[]; orgUnits: { organizationUnitId: number }[] }
  explicitGroups: { groupId: number }[]
}

function UserSimulation({ initialUserId }: { initialUserId?: number }) {
  const users = useOptions('users')
  const roles = useOptions('roles')
  const permissions = useOptions('permissions')
  const groups = useOptions('groups')
  const orgUnits = useOptions('orgUnits')
  const [userId, setUserId] = useState<number | undefined>(initialUserId)
  const detail = useApi<UserDetail>(userId ? `/api/users/${userId}` : null)
  const { pairs, bind, reset } = usePairs(['roles', 'perms', 'groups', 'ous'] as const)
  const { result, loading, run, setResult } = useChangeImpact()
  const d = detail.data

  const count = Object.values(pairs).reduce((n, p) => n + p.add.length + p.remove.length, 0)
  const simulate = () =>
    userId && run({
      userId,
      addUserRoleIds: pairs.roles.add,
      removeUserRoleIds: pairs.roles.remove,
      addUserPermissionIds: pairs.perms.add,
      removeUserPermissionIds: pairs.perms.remove,
      addUserOrgUnitIds: pairs.ous.add,
      removeUserOrgUnitIds: pairs.ous.remove,
      groupChanges: [
        ...pairs.groups.add.map((g) => ({ groupId: g, kind: 'AudienceUser' as GroupChangeKind, targetId: userId, add: true })),
        ...pairs.groups.remove.map((g) => ({ groupId: g, kind: 'AudienceUser' as GroupChangeKind, targetId: userId, add: false })),
      ],
    })

  return (
    <SimLayout
      hint="Kullanıcıya rol verilirse/alınırsa hangi yetkileri kazanır/kaybeder, grup üyelikleri nasıl değişir (rol ve birim, grup kitlesini etkiler), SoD çakışması ve RACF gereksinimi olur mu?"
      left={
        <>
          <Form.Item label="Kullanıcı" layout="vertical">
            <Select showSearch value={userId} onChange={(v) => { setUserId(v); reset(); setResult(undefined) }} options={toSelectOptions(users)} optionFilterProp="label" placeholder="Kullanıcı seçin" />
          </Form.Item>
          {d && (
            <>
              <DiffSelect label="Doğrudan roller" all={roles} current={d.user.roles.map((r) => r.roleId)} {...bind('roles')} />
              <DiffSelect label="Doğrudan permission'lar (legacy/istisna)" all={permissions} current={d.user.directPermissions.map((p) => p.permissionId)} {...bind('perms')} />
              <DiffSelect label="Doğrudan grup üyelikleri" all={groups} current={d.explicitGroups.map((g) => g.groupId)} {...bind('groups')} />
              <DiffSelect label="Birimler" all={orgUnits} current={d.user.orgUnits.map((o) => o.organizationUnitId)} {...bind('ous')} />
            </>
          )}
          <Button type="primary" block icon={<ExperimentOutlined />} loading={loading} disabled={!userId || count === 0} onClick={simulate}>Etkiyi hesapla</Button>
        </>
      }
      right={result && <ImpactView impact={result} />}
    />
  )
}

// ================================================================ Grup

interface GroupDetail {
  group: Record<'audienceUsers' | 'audienceRoles' | 'audienceOrgUnits' | 'grantedPermissions' | 'grantedRoles', { id: number }[]>
  resolvedMembers: unknown[]
}

const groupKinds = [
  { key: 'grantedPermissions', kind: 'GrantPermission', label: 'Grubun verdiği permission\'lar', source: 'permissions' },
  { key: 'grantedRoles', kind: 'GrantRole', label: 'Grubun verdiği roller', source: 'roles' },
  { key: 'audienceRoles', kind: 'AudienceRole', label: 'Kitle: bu role doğrudan sahip herkes', source: 'roles' },
  { key: 'audienceOrgUnits', kind: 'AudienceOrgUnit', label: 'Kitle: bu birimdeki herkes', source: 'orgUnits' },
  { key: 'audienceUsers', kind: 'AudienceUser', label: 'Kitle: kullanıcılar', source: 'users' },
] as const

function GroupSimulation({ initialGroupId }: { initialGroupId?: number }) {
  const sources: Record<string, Option[]> = {
    permissions: useOptions('permissions'), roles: useOptions('roles'), orgUnits: useOptions('orgUnits'), users: useOptions('users'),
  }
  const groups = useOptions('groups')
  const [groupId, setGroupId] = useState<number | undefined>(initialGroupId)
  const detail = useApi<GroupDetail>(groupId ? `/api/groups/${groupId}` : null)
  const { pairs, bind, reset } = usePairs(groupKinds.map((k) => k.key))
  const { result, loading, run, setResult } = useChangeImpact()
  const count = Object.values(pairs).reduce((n, p) => n + p.add.length + p.remove.length, 0)

  const simulate = () =>
    groupId && run({
      groupChanges: groupKinds.flatMap((k) => [
        ...pairs[k.key].add.map((t) => ({ groupId, kind: k.kind as GroupChangeKind, targetId: t, add: true })),
        ...pairs[k.key].remove.map((t) => ({ groupId, kind: k.kind as GroupChangeKind, targetId: t, add: false })),
      ]),
    })

  return (
    <SimLayout
      hint="Gruba yetki/rol verilirse veya kitlesi değişirse kimler etkilenir? Kitleden çıkan kullanıcılar grubun verdiği her şeyi kaybeder (başka kaynaktan sahip değillerse)."
      left={
        <>
          <Form.Item label="Grup" layout="vertical">
            <Select showSearch value={groupId} onChange={(v) => { setGroupId(v); reset(); setResult(undefined) }} options={toSelectOptions(groups)} optionFilterProp="label" placeholder="Grup seçin" />
          </Form.Item>
          {detail.data && (
            <>
              <Typography.Paragraph type="secondary">Şu an çözümlenmiş {detail.data.resolvedMembers.length} üye.</Typography.Paragraph>
              {groupKinds.map((k) => (
                <DiffSelect key={k.key} label={k.label} all={sources[k.source]} current={detail.data!.group[k.key].map((x) => x.id)} {...bind(k.key)} />
              ))}
            </>
          )}
          <Button type="primary" block icon={<ExperimentOutlined />} loading={loading} disabled={!groupId || count === 0} onClick={simulate}>Etkiyi hesapla</Button>
        </>
      }
      right={result && <ImpactView impact={result} />}
    />
  )
}

// ================================================================ Policy / Rule

interface PolicyDetail {
  policy: { id: number; code: string; isActive: boolean; combiningAlgorithm: CombiningAlgorithm; version: number }
  rules: RuleView[]
}
interface PermissionDetail { permission: { policies: { policyId: number }[] } }

/** Policy'nin tüm predicate düğümleri (parametre override için). */
function predicates(rules: RuleView[]) {
  const out: { conditionId: number; rule: string; type: string; parameters: Record<string, string> }[] = []
  const walk = (rule: string, n?: ConditionView) => {
    if (!n) return
    if (n.kind === 'Predicate' && n.id && n.conditionType) out.push({ conditionId: n.id, rule, type: n.conditionType, parameters: n.parameters })
    // Ortak koşul içindeki düğüm: parametresi değişirse o ortak koşulu kullanan TÜM policy'ler etkilenir
    n.children.forEach((c) => walk(n.kind === 'Reference' ? `${rule} → @${n.sharedCondition} (ORTAK)` : rule, c))
  }
  rules.forEach((r) => walk(r.code, r.condition))
  return out
}

function PolicySimulation({ initialPolicyId, initialPermissionId }: { initialPolicyId?: number; initialPermissionId?: number }) {
  const policies = useApi<{ id: number; code: string; name: string; isActive: boolean }[]>('/api/policies')
  const types = useApi<ConditionTypeInfo[]>('/api/condition-types')
  const shared = useApi<SharedConditionInfo[]>('/api/shared-conditions')
  const permissions = useOptions('permissions')
  const policyOptions: Option[] = (policies.data ?? []).map((p) => ({ id: p.id, code: p.code, name: p.name }))

  // A) Policy: rule çıkar / pasifleştir / effect değiştir + algoritma + aktiflik
  const [policyId, setPolicyId] = useState<number | undefined>(initialPolicyId)
  const detail = useApi<PolicyDetail>(policyId ? `/api/policies/${policyId}` : null)
  const [removed, setRemoved] = useState<number[]>([])
  const [inactive, setInactive] = useState<Record<number, boolean>>({})
  const [effects, setEffects] = useState<Record<number, RuleEffect>>({})
  const [algorithm, setAlgorithm] = useState<CombiningAlgorithm>()
  const [policyActive, setPolicyActive] = useState<boolean>()
  // B) Permission ↔ Policy
  const [permissionId, setPermissionId] = useState<number | undefined>(initialPermissionId)
  const permDetail = useApi<PermissionDetail>(permissionId ? `/api/permissions/${permissionId}` : null)
  const { pairs, bind } = usePairs(['permPolicies'] as const)
  // C) Taslak rule
  const [draftOn, setDraftOn] = useState(false)
  const [draft, setDraft] = useState<{ code: string; effect: RuleEffect; order: number; reasonCode: string }>({ code: 'DRAFT_RULE', effect: 'Deny', order: 55, reasonCode: 'DRAFT_RULE' })
  const [draftCondition, setDraftCondition] = useState<ConditionDraft>(emptyPredicate())
  // E) Ortak koşul tanımını değiştir
  const [sharedId, setSharedId] = useState<number>()
  const sharedDetail = useApi<{ condition?: ConditionView; usages: { policy: string }[] }>(sharedId ? `/api/shared-conditions/${sharedId}` : null)
  const [sharedDraft, setSharedDraft] = useState<ConditionDraft>()
  // D) Condition parametre override
  const [conditionId, setConditionId] = useState<number>()
  const [paramValues, setParamValues] = useState<Record<string, string>>({})

  const [scenarios, setScenarios] = useState<ImpactScenario[]>(DEFAULT_SCENARIOS)
  const [asOf, setAsOf] = useState<Dayjs | undefined>(nextBusinessMorning())
  const { result, loading, run } = usePolicyImpact()

  const rules = useMemo(() => detail.data?.rules ?? [], [detail.data])
  const preds = useMemo(() => predicates(rules), [rules])
  const selectedPred = preds.find((x) => x.conditionId === conditionId)
  const predDefs: ParamDef[] = useMemo(() => {
    const t = types.data?.find((x) => x.code === selectedPred?.type)
    return t ? JSON.parse(t.parameterSchemaJson) : []
  }, [types.data, selectedPred])

  const resetPolicy = (id?: number) => {
    setPolicyId(id); setRemoved([]); setInactive({}); setEffects({}); setAlgorithm(undefined); setPolicyActive(undefined)
    setConditionId(undefined); setParamValues({})
  }

  const changes: PolicyChangeSet = useMemo(() => {
    const cs: PolicyChangeSet = {
      permissionPolicyChanges: [], policyActivations: [], policyAlgorithmChanges: [], ruleOverrides: [],
      conditionOverrides: [], addedRules: [], removedRuleIds: [...removed], sharedConditionReplacements: [],
    }
    if (sharedId && sharedDraft && sharedDetail.data && renderDraft(sharedDraft) !== renderDraft(toDraft(sharedDetail.data.condition)))
      cs.sharedConditionReplacements!.push({ sharedConditionId: sharedId, condition: sharedDraft })
    if (policyId && detail.data) {
      if (algorithm && algorithm !== detail.data.policy.combiningAlgorithm) cs.policyAlgorithmChanges!.push({ policyId, algorithm })
      if (policyActive !== undefined && policyActive !== detail.data.policy.isActive) cs.policyActivations!.push({ policyId, isActive: policyActive })
      for (const r of rules) {
        if (removed.includes(r.id)) continue
        const o: { ruleId: number; isActive?: boolean; effect?: RuleEffect } = { ruleId: r.id }
        if (inactive[r.id] !== undefined && inactive[r.id] === r.isActive) o.isActive = !inactive[r.id]
        if (effects[r.id] && effects[r.id] !== r.effect) o.effect = effects[r.id]
        if (o.isActive !== undefined || o.effect) cs.ruleOverrides!.push(o)
      }
      if (draftOn) cs.addedRules!.push({ policyId, ...draft, name: draft.code, condition: draftCondition })
      if (selectedPred) {
        const cleaned = Object.fromEntries(Object.entries(paramValues).filter(([, v]) => v !== ''))
        if (JSON.stringify(Object.entries(cleaned).sort()) !== JSON.stringify(Object.entries(selectedPred.parameters).sort()))
          cs.conditionOverrides!.push({ conditionId: selectedPred.conditionId, parameters: cleaned })
      }
    }
    if (permissionId) {
      pairs.permPolicies.add.forEach((x) => cs.permissionPolicyChanges!.push({ permissionId, policyId: x, add: true }))
      pairs.permPolicies.remove.forEach((x) => cs.permissionPolicyChanges!.push({ permissionId, policyId: x, add: false }))
    }
    return cs
  }, [policyId, detail.data, rules, removed, inactive, effects, algorithm, policyActive, draftOn, draft, draftCondition, selectedPred, paramValues, permissionId, pairs, sharedId, sharedDraft, sharedDetail.data])

  const name = (list: Option[], id: number) => list.find((o) => o.id === id)?.code ?? `#${id}`
  const ruleCode = (id: number) => rules.find((r) => r.id === id)?.code ?? `#${id}`
  const changeTags = [
    ...changes.removedRuleIds!.map((id) => `− rule ${ruleCode(id)}`),
    ...changes.ruleOverrides!.map((o) => `${ruleCode(o.ruleId)}:${o.isActive !== undefined ? (o.isActive ? ' aktif' : ' pasif') : ''}${o.effect ? ` effect→${o.effect}` : ''}`),
    ...changes.policyAlgorithmChanges!.map((c) => `${name(policyOptions, c.policyId)} algoritma→${algorithmLabel[c.algorithm]}`),
    ...changes.policyActivations!.map((c) => `${name(policyOptions, c.policyId)} → ${c.isActive ? 'aktif' : 'pasif'}`),
    ...changes.addedRules!.map((d) => `+ rule ${d.code} (${d.effect} ⇐ ${renderDraft(d.condition)})`),
    ...changes.conditionOverrides!.map((c) => `${selectedPred?.rule}.${selectedPred?.type}: ${Object.entries(c.parameters).map(([k, v]) => `${k}=${v}`).join(', ')}`),
    ...changes.permissionPolicyChanges!.map((c) => `${name(permissions, c.permissionId)} ${c.add ? '+' : '−'} policy ${name(policyOptions, c.policyId)}`),
    ...changes.sharedConditionReplacements!.map((c) => `@${shared.data?.find((x) => x.id === c.sharedConditionId)?.code} = ${renderDraft(c.condition)} (ORTAK)`),
  ]

  return (
    <Flex vertical gap={16}>
      <Card size="small" title="A) Policy: rule çıkar / pasifleştir / effect değiştir · algoritma · aktiflik">
        <Flex gap={8} wrap style={{ marginBottom: 8 }}>
          <Select showSearch allowClear value={policyId} onChange={resetPolicy} options={toSelectOptions(policyOptions)} optionFilterProp="label" placeholder="Policy seçin" style={{ minWidth: 340 }} />
          {detail.data && (
            <>
              <Select value={algorithm ?? detail.data.policy.combiningAlgorithm} onChange={setAlgorithm} style={{ width: 200 }}
                options={(['DenyOverrides', 'PermitOverrides', 'FirstApplicable'] as CombiningAlgorithm[]).map((a) => ({ value: a, label: algorithmLabel[a] }))} />
              <Flex align="center" gap={6}><Switch checked={policyActive ?? detail.data.policy.isActive} onChange={setPolicyActive} /> Policy aktif</Flex>
            </>
          )}
        </Flex>
        {detail.data && (
          <Table<RuleView>
            size="small"
            rowKey="id"
            pagination={false}
            dataSource={rules}
            rowClassName={(r) => (removed.includes(r.id) ? 'ant-table-row-selected' : '')}
            columns={[
              { title: '#', dataIndex: 'order', width: 55 },
              { title: 'Rule', render: (_, r) => <><Code>{r.code}</Code><br /><Typography.Text type="secondary" style={{ fontSize: 12 }}>{r.expression}</Typography.Text></> },
              {
                title: 'Effect',
                width: 130,
                render: (_, r) => (
                  <Select size="small" value={effects[r.id] ?? r.effect} onChange={(v) => setEffects({ ...effects, [r.id]: v })} disabled={removed.includes(r.id)}
                    options={[{ value: 'Deny', label: 'DENY' }, { value: 'Permit', label: 'PERMIT' }]} style={{ width: 110 }} />
                ),
              },
              {
                title: 'Aktif',
                width: 70,
                render: (_, r) => <Switch size="small" checked={!(inactive[r.id] ?? !r.isActive)} disabled={removed.includes(r.id)} onChange={(v) => setInactive({ ...inactive, [r.id]: !v })} />,
              },
              {
                title: 'Çıkar',
                width: 70,
                render: (_, r) => <Switch size="small" checked={removed.includes(r.id)} onChange={(v) => setRemoved(v ? [...removed, r.id] : removed.filter((x) => x !== r.id))} />,
              },
            ]}
          />
        )}
      </Card>

      <Row gutter={[16, 16]}>
        <Col xs={24} xl={12}>
          <Card size="small" title="B) Permission'a policy bağla / ayır">
            <Select showSearch allowClear value={permissionId} onChange={setPermissionId} options={toSelectOptions(permissions)} optionFilterProp="label" placeholder="Permission seçin" style={{ width: '100%', marginBottom: 8 }} />
            {permissionId && permDetail.data && <DiffSelect label="Permission'ın policy'leri" all={policyOptions} current={permDetail.data.permission.policies.map((x) => x.policyId)} {...bind('permPolicies')} />}
          </Card>
        </Col>
        <Col xs={24} xl={12}>
          <Card size="small" title="D) Condition parametresi değiştir (ör. limit eşiği; ORTAK işaretliler tüm kullanan policy'leri etkiler)">
            {!policyId ? <Typography.Text type="secondary">Önce A'da policy seçin.</Typography.Text> : (
              <>
                <Select allowClear value={conditionId} placeholder="Rule / condition seçin" style={{ width: '100%', marginBottom: 8 }}
                  onChange={(id) => { setConditionId(id); setParamValues({ ...(preds.find((x) => x.conditionId === id)?.parameters ?? {}) }) }}
                  options={preds.map((x) => ({ value: x.conditionId, label: `${x.rule} · ${x.type}` }))} />
                {selectedPred && (
                  <Row gutter={8}>
                    {predDefs.map((d) => (
                      <Col span={12} key={d.key}>
                        <Typography.Text style={{ fontSize: 12 }}>{d.label} ({d.key})</Typography.Text>
                        <Input size="small" value={paramValues[d.key] ?? ''} placeholder={d.defaultValue} onChange={(e) => setParamValues({ ...paramValues, [d.key]: e.target.value })} />
                      </Col>
                    ))}
                    {predDefs.length === 0 && <Col span={24}><Typography.Text type="secondary">Bu condition tipinin parametresi yok.</Typography.Text></Col>}
                  </Row>
                )}
              </>
            )}
          </Card>
        </Col>
      </Row>

      <Card size="small" title={<Flex gap={8} align="center"><Switch checked={draftOn} onChange={setDraftOn} disabled={!policyId} /> C) Policy'ye yeni rule ekle (taslak)</Flex>}>
        {!policyId ? <Typography.Text type="secondary">Önce A'da policy seçin.</Typography.Text> : draftOn && (
          <>
            <Flex gap={8} wrap style={{ marginBottom: 8 }}>
              <Input addonBefore="Kod" value={draft.code} onChange={(e) => setDraft({ ...draft, code: e.target.value.toUpperCase() })} style={{ width: 260 }} />
              <Select value={draft.effect} onChange={(v) => setDraft({ ...draft, effect: v })} options={[{ value: 'Deny', label: 'DENY' }, { value: 'Permit', label: 'PERMIT' }]} style={{ width: 110 }} />
              <InputNumber addonBefore="Sıra" value={draft.order} onChange={(v) => setDraft({ ...draft, order: v ?? 0 })} style={{ width: 140 }} />
              <Input addonBefore="Reason" value={draft.reasonCode} onChange={(e) => setDraft({ ...draft, reasonCode: e.target.value.toUpperCase() })} style={{ width: 280 }} />
            </Flex>
            <ConditionBuilder value={draftCondition} onChange={setDraftCondition} types={types.data ?? []} shared={shared.data ?? []} />
          </>
        )}
      </Card>

      <Card size="small" title="E) Ortak koşul tanımını değiştir (onu kullanan TÜM policy'ler etkilenir)">
        <Select allowClear showSearch value={sharedId} placeholder="Ortak koşul seçin" style={{ width: '100%', marginBottom: 8 }} optionFilterProp="label"
          onChange={(v) => { setSharedId(v); setSharedDraft(undefined) }}
          options={(shared.data ?? []).map((x) => ({ value: x.id, label: `@${x.code} — ${x.name} (${x.usageCount} rule: ${x.policies.join(', ')})` }))} />
        {sharedId && sharedDetail.data && (
          <ConditionBuilder
            value={sharedDraft ?? toDraft(sharedDetail.data.condition)}
            onChange={setSharedDraft}
            types={types.data ?? []}
            shared={shared.data ?? []}
            excludeShared={shared.data?.find((x) => x.id === sharedId)?.code}
          />
        )}
      </Card>

      <Card size="small">
        <Flex vertical gap={10}>
          <Flex wrap gap={4} align="center">
            <Typography.Text strong>Simüle edilecek değişiklikler:</Typography.Text>
            {changeTags.length === 0 ? <Typography.Text type="secondary">henüz yok</Typography.Text> : changeTags.map((t) => <Tag color="purple" key={t}>{t}</Tag>)}
          </Flex>
          <ScenarioSettings scenarios={scenarios} setScenarios={setScenarios} asOf={asOf} setAsOf={setAsOf} />
          <Button type="primary" icon={<ExperimentOutlined />} loading={loading} disabled={changeTags.length === 0} onClick={() => run(changes, scenarios, asOf)}>
            Policy etkisini hesapla
          </Button>
        </Flex>
      </Card>

      {result ? <PolicyImpactView result={result} /> : (
        <Alert type="info" showIcon message="Örnekler: CASH_WITHDRAWAL_POLICY'de CASH_LIMIT_EXCEEDED'i pasifleştir → kim limit kontrolü olmadan çekebilir? D'de mesai bitişini 17:00 yap → hangi kararlar değişir? Algoritmayı Permit-overrides yap → Deny'lar nasıl etkilenir? CASH_WITHDRAW'a TERM_DEPOSIT_CLOSE_POLICY bağla → yeni gerekli attribute (Context.BranchCode)." />
      )}
    </Flex>
  )
}

// ================================================================ SoD

function SodImpact() {
  const { message } = App.useApp()
  const permissions = useOptions('permissions')
  const roles = useOptions('roles')
  const [form] = Form.useForm()
  const [result, setResult] = useState<{ violatingUsers: number; users: { userId: number; userName: string; fullName: string; conflicts: { matchedMembers: { code: string; paths: string[] }[] }[] }[] }>()

  const run = async () => {
    const v = form.getFieldsValue()
    try {
      setResult(await api.post('/api/simulation/sod-rule', { permissionIds: v.permissionIds ?? [], roleIds: v.roleIds ?? [] }))
    } catch (e) {
      message.error((e as Error).message)
    }
  }

  return (
    <SimLayout
      hint="Yeni bir SoD kuralı eklenirse mevcut atamalarda kaç kullanıcı ihlalde olur?"
      left={
        <Form form={form} layout="vertical">
          <Form.Item name="permissionIds" label="Karşılıklı dışlayan permission'lar"><Select mode="multiple" options={toSelectOptions(permissions)} optionFilterProp="label" /></Form.Item>
          <Form.Item name="roleIds" label="Karşılıklı dışlayan roller"><Select mode="multiple" options={toSelectOptions(roles)} optionFilterProp="label" /></Form.Item>
          <Button type="primary" block icon={<ExperimentOutlined />} onClick={run}>Mevcutta kaç ihlal olur?</Button>
        </Form>
      }
      right={
        result && (
          <Card size="small" title={`${result.violatingUsers} kullanıcı ihlalde olurdu`}>
            <Table size="small" rowKey="userId" dataSource={result.users} pagination={{ pageSize: 15 }}
              columns={[
                { title: 'Kullanıcı', dataIndex: 'userName' },
                { title: 'Ad', dataIndex: 'fullName' },
                { title: 'Çakışan üyeler (kaynak)', render: (_, u) => u.conflicts[0]?.matchedMembers.map((m) => <div key={m.code}><Tag>{m.code}</Tag>{m.paths.join(' | ')}</div>) },
              ]} />
          </Card>
        )
      }
    />
  )
}
