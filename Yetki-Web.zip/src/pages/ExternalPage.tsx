import { Alert, Button, Card, Flex, Table, Tag } from 'antd'
import { PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { useApi } from '../hooks/useApi'
import { Code, PageHeader } from '../components/common'
import { EntityFormModal } from '../components/EntityFormModal'

interface ExternalSystem {
  id: number
  code: string
  name: string
  description?: string
  permissions: { id: number; code: string; name?: string; description?: string; mappedFrom: string[] }[]
}

export function ExternalPage() {
  const { data, loading, reload } = useApi<ExternalSystem[]>('/api/external/systems')
  const [newSystem, setNewSystem] = useState(false)
  const [newPermFor, setNewPermFor] = useState<ExternalSystem>()

  return (
    <>
      <PageHeader
        title="Dış Sistemler (RACF / LDAP ...)"
        subtitle="Permission → dış sistem yetkisi eşlemesi. Eşleme, permission detay ekranından yapılır."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setNewSystem(true)}>Yeni dış sistem</Button>}
      />
      <Alert type="info" showIcon style={{ marginBottom: 16 }}
        message="Authorization core RACF/FTP/EGL detaylarını bilmez. Atama sonrası EffectivePermissionsChanged event'i üretilir; provisioning handler eşlemelere göre aksiyon oluşturur ve adaptöre (prototipte dummy) iletir." />
      <Flex vertical gap={16}>
        {(data ?? []).map((s) => (
          <Card key={s.id} size="small" loading={loading}
            title={<><Tag color="cyan">{s.code}</Tag>{s.name}</>}
            extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setNewPermFor(s)}>Dış yetki ekle</Button>}>
            <Table
              size="small"
              rowKey="id"
              pagination={false}
              dataSource={s.permissions}
              columns={[
                { title: 'Dış yetki', dataIndex: 'code', render: (v) => <Code>{v}</Code> },
                { title: 'Ad', dataIndex: 'name' },
                { title: 'Gerektiren permission\'lar', dataIndex: 'mappedFrom', render: (v: string[]) => (v.length ? v.map((p) => <Tag color="purple" key={p}>{p}</Tag>) : <Tag>eşleme yok</Tag>) },
              ]}
            />
          </Card>
        ))}
      </Flex>
      <EntityFormModal open={newSystem} title="Yeni dış sistem" createPath="/api/external/systems" onClose={() => setNewSystem(false)} onSaved={() => reload()}
        fields={[{ name: 'code', label: 'Kod', required: true }, { name: 'name', label: 'Ad', required: true }, { name: 'description', label: 'Açıklama', type: 'textarea' }]} />
      <EntityFormModal open={!!newPermFor} title={`${newPermFor?.code} — yeni dış yetki`} createPath={`/api/external/systems/${newPermFor?.id}/permissions`}
        onClose={() => setNewPermFor(undefined)} onSaved={() => reload()}
        fields={[{ name: 'code', label: 'Kod', required: true, placeholder: 'VADA-B0' }, { name: 'name', label: 'Ad' }, { name: 'description', label: 'Açıklama', type: 'textarea' }]} />
    </>
  )
}
