import { Alert, Button, Card, Col, Flex, Row, Table, Tag } from 'antd'
import { EditOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api } from '../api/client'
import type { ChangeImpactResult, GroupChangeKind, Option } from '../api/types'
import { toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { ActiveTag, Code, PageHeader } from '../components/common'
import { ChangeModal } from '../components/ChangeModal'
import { ConfirmChangeModal } from '../components/ConfirmChangeModal'
import { EntityFormModal, type FieldDef } from '../components/EntityFormModal'

const groupFields: FieldDef[] = [
  { name: 'code', label: 'Kod', required: true, disabledOnEdit: true },
  { name: 'name', label: 'Ad', required: true },
  { name: 'description', label: 'Açıklama', type: 'textarea' },
  { name: 'isActive', label: 'Aktif', type: 'switch' },
]

interface GroupRow {
  id: number
  code: string
  name: string
  description?: string
  isActive: boolean
  audience: { users: number; roles: string[]; orgUnits: string[] }
  grants: { permissions: string[]; roles: string[] }
}

export function GroupsPage() {
  const { data, loading, reload } = useApi<GroupRow[]>('/api/groups')
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  return (
    <>
      <PageHeader
        title="Gruplar"
        subtitle="Esnek kitle tanımı: kullanıcı + rol + organizasyon birimi. Ana model değil; istisnai/esnek senaryolar için. Nested grup yok."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setOpen(true)}>Yeni grup</Button>}
      />
      <Table<GroupRow>
        rowKey="id"
        loading={loading}
        dataSource={data ?? []}
        pagination={false}
        rowClassName="clickable-row"
        onRow={(r) => ({ onClick: () => navigate(`/groups/${r.id}`) })}
        columns={[
          { title: 'Kod', dataIndex: 'code', render: (v) => <Code>{v}</Code> },
          { title: 'Ad', dataIndex: 'name' },
          {
            title: 'Kitle',
            render: (_, g) => (
              <Flex wrap gap={4}>
                {g.audience.users > 0 && <Tag>{g.audience.users} kullanıcı</Tag>}
                {g.audience.roles.map((r) => <Tag color="blue" key={r}>rol: {r}</Tag>)}
                {g.audience.orgUnits.map((o) => <Tag color="gold" key={o}>birim: {o}</Tag>)}
              </Flex>
            ),
          },
          {
            title: 'Verdiği',
            render: (_, g) => (
              <Flex wrap gap={4}>
                {g.grants.roles.map((r) => <Tag color="purple" key={r}>rol: {r}</Tag>)}
                {g.grants.permissions.map((p) => <Tag color="geekblue" key={p}>{p}</Tag>)}
              </Flex>
            ),
          },
          { title: 'Durum', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} />, width: 90 },
        ]}
      />
      <EntityFormModal open={open} title="Yeni grup" fields={groupFields} createPath="/api/groups" onClose={() => setOpen(false)} onSaved={() => reload()} />
    </>
  )
}

interface Item { id: number; code: string; name: string; assignedBy: string }
interface GroupDetail {
  group: {
    id: number; code: string; name: string; description?: string; isActive: boolean
    audienceUsers: Item[]; audienceRoles: Item[]; audienceOrgUnits: Item[]; grantedPermissions: Item[]; grantedRoles: Item[]
  }
  resolvedMembers: { id: number; userName: string; fullName: string; isActive: boolean }[]
}

const kindMeta: Record<GroupChangeKind, { label: string; source: 'users' | 'roles' | 'orgUnits' | 'permissions'; key: keyof GroupDetail['group'] }> = {
  AudienceUser: { label: 'Kitle: kullanıcı', source: 'users', key: 'audienceUsers' },
  AudienceRole: { label: 'Kitle: bu role doğrudan sahip herkes', source: 'roles', key: 'audienceRoles' },
  AudienceOrgUnit: { label: 'Kitle: bu birimdeki herkes', source: 'orgUnits', key: 'audienceOrgUnits' },
  GrantPermission: { label: 'Verilen permission', source: 'permissions', key: 'grantedPermissions' },
  GrantRole: { label: 'Verilen rol', source: 'roles', key: 'grantedRoles' },
}

export function GroupDetailPage() {
  const id = Number(useParams().id)
  const navigate = useNavigate()
  const { data, reload } = useApi<GroupDetail>(`/api/groups/${id}`)
  const sources: Record<string, Option[]> = {
    users: useOptions('users'),
    roles: useOptions('roles'),
    orgUnits: useOptions('orgUnits'),
    permissions: useOptions('permissions'),
  }
  const [kind, setKind] = useState<GroupChangeKind | null>(null)
  const [editing, setEditing] = useState(false)
  const [removing, setRemoving] = useState<{ kind: GroupChangeKind; id: number; code: string } | null>(null)
  if (!data) return <Card loading />
  const g = data.group

  const section = (k: GroupChangeKind, color: string) => {
    const items = g[kindMeta[k].key] as Item[]
    return (
      <Card size="small" title={kindMeta[k].label} extra={<Button size="small" icon={<PlusOutlined />} onClick={() => setKind(k)}>Ekle</Button>}>
        <Flex wrap gap={6}>
          {items.length === 0 && <span style={{ color: '#999' }}>—</span>}
          {items.map((i) => (
            <Tag key={i.id} color={color} closable title={`${i.name} · ekleyen: ${i.assignedBy} · çıkarmak için ×`}
              onClose={(e) => { e.preventDefault(); setRemoving({ kind: k, id: i.id, code: i.code }) }}>{i.code}</Tag>
          ))}
        </Flex>
      </Card>
    )
  }

  return (
    <>
      <PageHeader
        title={g.name}
        subtitle={<><Code>{g.code}</Code> <ActiveTag active={g.isActive} /> {g.description}</>}
        extra={
          <Flex gap={8}>
            <Button onClick={() => navigate(`/what-if?tab=group&groupId=${id}`)}>What-If</Button>
            <Button icon={<EditOutlined />} onClick={() => setEditing(true)}>Düzenle</Button>
          </Flex>
        }
      />
      <Alert type="info" showIcon style={{ marginBottom: 16 }}
        message="Grup = Kitle (kim?) + Verdikleri (ne?). Rol kitlesi yalnızca DOĞRUDAN atanmış rollerle eşleşir; gruptan gelen rol başka grubun kitlesini tetiklemez." />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={12}>
          <Flex vertical gap={12}>
            {section('AudienceUser', 'default')}
            {section('AudienceRole', 'blue')}
            {section('AudienceOrgUnit', 'gold')}
          </Flex>
        </Col>
        <Col xs={24} xl={12}>
          <Flex vertical gap={12}>
            {section('GrantPermission', 'geekblue')}
            {section('GrantRole', 'purple')}
            <Card size="small" title={`Çözümlenmiş üyeler (${data.resolvedMembers.length})`}>
              <Table size="small" rowKey="id" pagination={{ pageSize: 8 }} dataSource={data.resolvedMembers}
                columns={[
                  { title: 'Kullanıcı', render: (_, u) => <a onClick={() => navigate(`/users/${u.id}`)}>{u.userName}</a> },
                  { title: 'Ad', dataIndex: 'fullName' },
                  { title: '', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} /> },
                ]} />
            </Card>
          </Flex>
        </Col>
      </Row>
      {kind && (
        <ChangeModal
          open
          title={`${g.code} — ${kindMeta[kind].label}`}
          label={kindMeta[kind].label}
          options={toSelectOptions(sources[kindMeta[kind].source], (g[kindMeta[kind].key] as Item[]).map((i) => i.id))}
          buildChangeSet={(t) => ({ groupChanges: [{ groupId: id, kind, targetId: t, add: true }] })}
          apply={(t) => api.post(`/api/groups/${id}/items`, { kind, targetId: t })}
          onClose={() => setKind(null)}
          onDone={reload}
        />
      )}
      <ConfirmChangeModal
        open={!!removing}
        title={`Etki: ${g.code} grubundan ${removing?.code} çıkarılırsa`}
        changeSet={{ groupChanges: removing ? [{ groupId: id, kind: removing.kind, targetId: removing.id, add: false }] : [] }}
        apply={() => api.del<ChangeImpactResult>(`/api/groups/${id}/items/${removing!.kind}/${removing!.id}`)}
        onClose={() => setRemoving(null)}
        onDone={reload}
      />
      <EntityFormModal open={editing} title="Grubu düzenle" fields={groupFields} createPath="/api/groups" updatePath={`/api/groups/${id}`}
        initial={{ ...g }} onClose={() => setEditing(false)} onSaved={reload} />
    </>
  )
}
