import { Alert, App, Button, Card, Flex, Form, Input, Modal, Select, Statistic, Switch, Table, Tabs, Tag, Typography } from 'antd'
import { PlusOutlined, ScanOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import { toSelectOptions, useApi, useOptions } from '../hooks/useApi'
import { ActiveTag, Code, EnforcementTag, PageHeader, SeverityTag, fmt } from '../components/common'

interface SodRuleRow {
  id: number
  code: string
  name: string
  description?: string
  severity: string
  enforcement: string
  isActive: boolean
  openViolations: number
  members: { memberType: string; memberId: number; code?: string }[]
}

interface Violation {
  id: number
  userId: number
  userName: string
  fullName: string
  rule: string
  ruleName: string
  severity: string
  enforcement: string
  status: string
  detectedBy: string
  detectedAt: string
  lastSeenAt: string
  closedBy?: string
  note?: string
  details: string
}

interface ScanResult {
  scannedUsers: number
  violatingUsers: number
  newViolations: number
  stillOpen: number
  autoResolved: number
  durationMs: number
}

export function SodPage() {
  const rules = useApi<SodRuleRow[]>('/api/sod/rules')
  const [status, setStatus] = useState<string | undefined>('Open')
  const violations = useApi<Violation[]>(`/api/sod/violations${status ? `?status=${status}` : ''}`)
  const { message, modal } = App.useApp()
  const navigate = useNavigate()
  const [scan, setScan] = useState<ScanResult>()
  const [scanning, setScanning] = useState(false)
  const [editing, setEditing] = useState<SodRuleRow | 'new' | null>(null)

  const runScan = async () => {
    setScanning(true)
    try {
      setScan(await api.post<ScanResult>('/api/sod/scan'))
      violations.reload()
      rules.reload()
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setScanning(false)
    }
  }

  const setViolationStatus = (v: Violation, s: string) =>
    modal.confirm({
      title: `${v.userName} / ${v.rule} → ${s}`,
      content: <Input.TextArea id="violation-note" placeholder="Not (opsiyonel)" />,
      onOk: async () => {
        const note = (document.getElementById('violation-note') as HTMLTextAreaElement | null)?.value
        await api.put(`/api/sod/violations/${v.id}`, { status: s, note })
        violations.reload()
      },
    })

  return (
    <>
      <PageHeader
        title="Separation of Duties"
        subtitle="Birlikte bulunmaması gereken permission/rol kombinasyonları. Atama anında kontrol + geriye dönük tarama. Sistem yetki SİLMEZ."
        extra={
          <Flex gap={8}>
            <Button icon={<ScanOutlined />} loading={scanning} onClick={runScan}>Retrospektif tarama</Button>
            <Button type="primary" icon={<PlusOutlined />} onClick={() => setEditing('new')}>Yeni SoD kuralı</Button>
          </Flex>
        }
      />
      {scan && (
        <Card size="small" style={{ marginBottom: 16 }} title="Son tarama sonucu">
          <Flex gap={32} wrap>
            <Statistic title="Taranan kullanıcı" value={scan.scannedUsers} />
            <Statistic title="İhlalli kullanıcı" value={scan.violatingUsers} valueStyle={{ color: scan.violatingUsers ? '#cf1322' : undefined }} />
            <Statistic title="Yeni ihlal kaydı" value={scan.newViolations} />
            <Statistic title="Hâlâ açık" value={scan.stillOpen} />
            <Statistic title="Otomatik kapanan" value={scan.autoResolved} />
            <Statistic title="Süre (ms)" value={scan.durationMs} />
          </Flex>
        </Card>
      )}
      <Tabs
        items={[
          {
            key: 'violations',
            label: 'İhlaller',
            children: (
              <>
                <Select
                  allowClear
                  value={status}
                  onChange={setStatus}
                  placeholder="Durum"
                  style={{ width: 200, marginBottom: 12 }}
                  options={['Open', 'Acknowledged', 'AcceptedRisk', 'Resolved'].map((s) => ({ value: s, label: s }))}
                />
                <Table<Violation>
                  rowKey="id"
                  size="small"
                  loading={violations.loading}
                  dataSource={violations.data ?? []}
                  pagination={{ pageSize: 15 }}
                  columns={[
                    { title: 'Kullanıcı', render: (_, v) => <a onClick={() => navigate(`/users/${v.userId}`)}>{v.userName}</a> },
                    { title: 'Kural', render: (_, v) => <><Code>{v.rule}</Code> <SeverityTag severity={v.severity} /></> },
                    { title: 'Çakışma (kaynak yollarıyla)', dataIndex: 'details', render: (v) => <Typography.Text style={{ fontSize: 12 }}>{v}</Typography.Text> },
                    { title: 'Tespit', render: (_, v) => <>{v.detectedBy}<br /><Typography.Text type="secondary">{fmt(v.detectedAt)}</Typography.Text></> },
                    { title: 'Durum', render: (_, v) => <><Tag>{v.status}</Tag>{v.note && <div><Typography.Text type="secondary">{v.note}</Typography.Text></div>}</> },
                    {
                      title: '',
                      render: (_, v) =>
                        v.status !== 'Resolved' && (
                          <Flex gap={4} wrap>
                            <Button size="small" onClick={() => setViolationStatus(v, 'Acknowledged')}>Gördüm</Button>
                            <Button size="small" onClick={() => setViolationStatus(v, 'AcceptedRisk')}>Risk kabul</Button>
                            <Button size="small" onClick={() => setViolationStatus(v, 'Resolved')}>Çözüldü</Button>
                          </Flex>
                        ),
                    },
                  ]}
                />
              </>
            ),
          },
          {
            key: 'rules',
            label: 'Kurallar',
            children: (
              <Table<SodRuleRow>
                rowKey="id"
                loading={rules.loading}
                dataSource={rules.data ?? []}
                pagination={false}
                onRow={(r) => ({ onClick: () => setEditing(r) })}
                rowClassName="clickable-row"
                columns={[
                  { title: 'Kod', render: (_, r) => <><Code>{r.code}</Code><br /><Typography.Text type="secondary">{r.name}</Typography.Text></> },
                  { title: 'Karşılıklı dışlayan üyeler', render: (_, r) => <Flex wrap gap={4}>{r.members.map((m) => <Tag key={m.memberType + m.memberId} color={m.memberType === 'Role' ? 'blue' : 'default'}>{m.memberType === 'Role' ? 'rol: ' : ''}{m.code}</Tag>)}</Flex> },
                  { title: 'Önem', dataIndex: 'severity', render: (v) => <SeverityTag severity={v} /> },
                  { title: 'Uygulama', dataIndex: 'enforcement', render: (v) => <EnforcementTag enforcement={v} /> },
                  { title: 'Açık ihlal', dataIndex: 'openViolations', render: (v) => (v ? <Tag color="red">{v}</Tag> : 0) },
                  { title: '', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} /> },
                ]}
              />
            ),
          },
        ]}
      />
      {editing && <SodRuleModal rule={editing === 'new' ? undefined : editing} onClose={() => setEditing(null)} onSaved={() => { rules.reload(); violations.reload() }} />}
    </>
  )
}

function SodRuleModal({ rule, onClose, onSaved }: { rule?: SodRuleRow; onClose: () => void; onSaved: () => void }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const permissions = useOptions('permissions')
  const roles = useOptions('roles')
  const [saving, setSaving] = useState(false)
  const [preview, setPreview] = useState<{ violatingUsers: number; users: { userName: string; conflicts: { matchedMembers: { code: string }[] }[] }[] }>()

  const values = () => {
    const v = form.getFieldsValue()
    return { ...v, permissionIds: v.permissionIds ?? [], roleIds: v.roleIds ?? [] }
  }

  const doPreview = async () => {
    try {
      const v = values()
      setPreview(await api.post('/api/simulation/sod-rule', { code: v.code || 'DRAFT', permissionIds: v.permissionIds, roleIds: v.roleIds, enforcement: v.enforcement }))
    } catch (e) {
      message.error((e as Error).message)
    }
  }

  const submit = async () => {
    await form.validateFields()
    setSaving(true)
    try {
      if (rule) {
        await api.put(`/api/sod/rules/${rule.id}`, values())
        message.success('Güncellendi')
      } else {
        const r = await api.post<{ currentViolatingUsers: number }>('/api/sod/rules', values())
        message.success(`Kural oluşturuldu. Mevcut atamalarda ${r.currentViolatingUsers} kullanıcı bu kuralı ihlal ediyor — retrospektif tarama ile kayda alın.`)
      }
      onSaved()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <Modal open title={rule ? `SoD kuralı: ${rule.code}` : 'Yeni SoD kuralı'} onCancel={onClose} onOk={submit} confirmLoading={saving} width={720} destroyOnHidden>
      <Form
        form={form}
        layout="vertical"
        initialValues={{
          code: rule?.code, name: rule?.name, description: rule?.description, severity: rule?.severity ?? 'High',
          enforcement: rule?.enforcement ?? 'Block', isActive: rule?.isActive ?? true,
          permissionIds: rule?.members.filter((m) => m.memberType === 'Permission').map((m) => m.memberId) ?? [],
          roleIds: rule?.members.filter((m) => m.memberType === 'Role').map((m) => m.memberId) ?? [],
        }}
      >
        <Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input disabled={!!rule} placeholder="SOD_X_Y" /></Form.Item>
        <Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input /></Form.Item>
        <Form.Item name="permissionIds" label="Permission üyeleri"><Select mode="multiple" options={toSelectOptions(permissions)} optionFilterProp="label" /></Form.Item>
        <Form.Item name="roleIds" label="Rol üyeleri"><Select mode="multiple" options={toSelectOptions(roles)} optionFilterProp="label" /></Form.Item>
        <Typography.Paragraph type="secondary">Üyelerden 2 veya daha fazlasına (effective olarak) sahip olan kullanıcı ihlaldedir.</Typography.Paragraph>
        <Flex gap={16}>
          <Form.Item name="severity" label="Önem" style={{ flex: 1 }}>
            <Select options={['Low', 'Medium', 'High', 'Critical'].map((s) => ({ value: s, label: s }))} />
          </Form.Item>
          <Form.Item name="enforcement" label="Atama anında" style={{ flex: 1 }}>
            <Select options={[{ value: 'Block', label: 'Engelle (Block)' }, { value: 'Warn', label: 'Uyar, izin ver (Warn)' }]} />
          </Form.Item>
          <Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item>
        </Flex>
        <Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item>
      </Form>
      <Button onClick={doPreview}>What-If: mevcutta kaç ihlal olur?</Button>
      {preview && (
        <Alert
          style={{ marginTop: 12 }}
          type={preview.violatingUsers ? 'warning' : 'success'}
          message={`${preview.violatingUsers} kullanıcı bu kuralı şu an ihlal ediyor`}
          description={preview.users.map((u) => <div key={u.userName}>{u.userName}: {u.conflicts[0]?.matchedMembers.map((m) => m.code).join(' + ')}</div>)}
        />
      )}
    </Modal>
  )
}
