import { Alert, App, Button, Card, Col, Flex, Form, Input, InputNumber, Modal, Row, Select, Switch, Table, Tag, Tooltip, Typography } from 'antd'
import { DeleteOutlined, EditOutlined, ExperimentOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api } from '../api/client'
import type { CombiningAlgorithm, ConditionDraft, ConditionTypeInfo, PolicyChangeSet, RuleDraft, RuleEffect, RuleView, SharedConditionInfo } from '../api/types'
import { useApi } from '../hooks/useApi'
import { ActiveTag, AlgorithmTag, Code, EffectTag, PageHeader, algorithmHelp, algorithmLabel } from '../components/common'
import { EntityFormModal, type FieldDef } from '../components/EntityFormModal'
import { PolicyChangeModal } from '../components/PolicyImpact'
import { ConditionBuilder, emptyPredicate, renderDraft, toDraft } from '../components/ConditionBuilder'

const algorithms: CombiningAlgorithm[] = ['DenyOverrides', 'PermitOverrides', 'FirstApplicable']
const domains = ['GISE', 'VADELI', 'KREDI', 'ODEME', 'MUSTERI', 'RAPOR', 'YETKI', 'GENEL']

const policyFields: FieldDef[] = [
  { name: 'code', label: 'Kod', required: true, disabledOnEdit: true, placeholder: 'CASH_WITHDRAWAL_POLICY' },
  { name: 'name', label: 'Ad', required: true },
  {
    name: 'combiningAlgorithm', label: 'Combining algoritması', type: 'select', required: true,
    options: algorithms.map((a) => ({ value: a, label: `${algorithmLabel[a]} — ${algorithmHelp[a]}` })),
    tooltip: 'Policy içindeki rule sonuçlarının nasıl birleştirileceği. Varsayılan: Deny-overrides.',
  },
  { name: 'domain', label: 'Domain', type: 'select', options: domains.map((d) => ({ value: d, label: d })) },
  { name: 'description', label: 'Açıklama', type: 'textarea' },
  { name: 'isActive', label: 'Aktif', type: 'switch' },
]

interface PolicyRow {
  id: number
  code: string
  name: string
  description?: string
  domain?: string
  isActive: boolean
  combiningAlgorithm: CombiningAlgorithm
  version: number
  rules: RuleView[]
  permissions: string[]
}

export function PoliciesPage() {
  const { data, loading, reload } = useApi<PolicyRow[]>('/api/policies')
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  return (
    <>
      <PageHeader
        title="Policy'ler"
        subtitle="Permission'ın hangi koşullarda Permit/Deny olacağı. Policy = rule'lar (Effect + Condition) + combining algoritması."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setOpen(true)}>Yeni policy</Button>}
      />
      <Alert type="info" showIcon style={{ marginBottom: 12 }}
        message="Permission → Policy → Rule (Effect) → Condition → Attribute. Condition TRUE ise rule Effect'ini üretir; FALSE ise uygulanmaz. Sonuçları policy'nin combining algoritması birleştirir." />
      <Table<PolicyRow>
        rowKey="id"
        loading={loading}
        dataSource={data ?? []}
        pagination={false}
        rowClassName="clickable-row"
        onRow={(r) => ({ onClick: () => navigate(`/policies/${r.id}`) })}
        columns={[
          { title: 'Kod', render: (_, p) => <><Code>{p.code}</Code><br /><Typography.Text type="secondary">{p.name}</Typography.Text></> },
          { title: 'Algoritma', render: (_, p) => <AlgorithmTag algorithm={p.combiningAlgorithm} /> },
          {
            title: 'Rule\'lar',
            render: (_, p) => (
              <Flex wrap gap={4}>
                {p.rules.map((r) => (
                  <Tooltip key={r.id} title={r.expression}>
                    <Tag color={!r.isActive ? 'default' : r.effect === 'Permit' ? 'green' : 'red'}>{r.effect === 'Permit' ? '✓' : '✗'} {r.code}</Tag>
                  </Tooltip>
                ))}
              </Flex>
            ),
          },
          { title: 'Permission\'lar', dataIndex: 'permissions', render: (v: string[]) => v.map((x) => <Tag color="purple" key={x}>{x}</Tag>) },
          { title: 'Sürüm', dataIndex: 'version', width: 70, render: (v) => `v${v}` },
          { title: 'Durum', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} />, width: 90 },
        ]}
      />
      <EntityFormModal open={open} title="Yeni policy" fields={policyFields} createPath="/api/policies"
        initial={{ isActive: true, combiningAlgorithm: 'DenyOverrides' }} onClose={() => setOpen(false)} onSaved={() => reload()} />
    </>
  )
}

interface PolicyDetail {
  policy: {
    id: number; code: string; name: string; description?: string; domain?: string; isActive: boolean
    combiningAlgorithm: CombiningAlgorithm; version: number
    permissions: { permissionId: number; code: string; name: string }[]
  }
  rules: RuleView[]
}

type Pending = { title: string; changes: PolicyChangeSet; apply: () => Promise<unknown> }

export function PolicyDetailPage() {
  const id = Number(useParams().id)
  const navigate = useNavigate()
  const { data, reload } = useApi<PolicyDetail>(`/api/policies/${id}`)
  const types = useApi<ConditionTypeInfo[]>('/api/condition-types')
  const [editing, setEditing] = useState(false)
  const [ruleEdit, setRuleEdit] = useState<RuleView | 'new' | null>(null)
  const [pending, setPending] = useState<Pending | null>(null)
  if (!data) return <Card loading />
  const p = data.policy

  return (
    <>
      <PageHeader
        title={p.name}
        subtitle={<><Code>{p.code}</Code> <AlgorithmTag algorithm={p.combiningAlgorithm} /> <Tag>v{p.version}</Tag> {p.domain && <Tag>{p.domain}</Tag>} <ActiveTag active={p.isActive} /> {p.description}</>}
        extra={
          <Flex gap={8}>
            <Button icon={<ExperimentOutlined />} onClick={() => navigate(`/what-if?tab=policy&policyId=${id}`)}>Etki analizi</Button>
            <Button icon={<EditOutlined />} onClick={() => setEditing(true)}>Düzenle</Button>
          </Flex>
        }
      />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={17}>
          <Card size="small" title={<>Rule'lar <Typography.Text type="secondary">— {algorithmHelp[p.combiningAlgorithm]}</Typography.Text></>}
            extra={<Button icon={<PlusOutlined />} onClick={() => setRuleEdit('new')}>Rule ekle</Button>}>
            <Table<RuleView>
              size="small"
              rowKey="id"
              pagination={false}
              dataSource={data.rules}
              columns={[
                { title: '#', dataIndex: 'order', width: 60 },
                { title: 'Rule', width: 250, render: (_, r) => <><Code>{r.code}</Code><br /><Typography.Text type="secondary">{r.name}</Typography.Text></> },
                { title: 'Effect', render: (_, r) => <EffectTag effect={r.effect} />, width: 80 },
                { title: 'Condition (TRUE ise Effect)', width: '42%', render: (_, r) => <Typography.Text style={{ fontSize: 12, wordBreak: 'break-word' }}>{r.expression}</Typography.Text> },
                { title: 'Reason', dataIndex: 'reasonCode', render: (v) => v && <Code>{v}</Code> },
                { title: '', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} />, width: 70 },
                {
                  title: '',
                  width: 90,
                  render: (_, r) => (
                    <Flex gap={4}>
                      <Button size="small" icon={<EditOutlined />} onClick={() => setRuleEdit(r)} />
                      <Button size="small" danger icon={<DeleteOutlined />} onClick={() => setPending({
                        title: `Etki: ${p.code} policy'sinden ${r.code} silinirse`,
                        changes: { removedRuleIds: [r.id] },
                        apply: () => api.del(`/api/rules/${r.id}`),
                      })} />
                    </Flex>
                  ),
                },
              ]}
            />
          </Card>
        </Col>
        <Col xs={24} xl={7}>
          <Card size="small" title="Bu policy'ye bağlı permission'lar">
            <Flex wrap gap={4}>
              {p.permissions.map((x) => <Tag key={x.permissionId} color="purple" style={{ cursor: 'pointer' }} onClick={() => navigate(`/permissions/${x.permissionId}`)}>{x.code}</Tag>)}
            </Flex>
            <Typography.Paragraph type="secondary" style={{ marginTop: 8, marginBottom: 0 }}>Permission bağlama permission detay ekranından yapılır.</Typography.Paragraph>
          </Card>
        </Col>
      </Row>

      {ruleEdit && (
        <RuleModal
          policyId={id}
          rule={ruleEdit === 'new' ? undefined : ruleEdit}
          types={types.data ?? []}
          nextOrder={Math.max(0, ...data.rules.filter((r) => r.order < 1000).map((r) => r.order)) + 10}
          onClose={() => setRuleEdit(null)}
          onPreview={(pd) => { setRuleEdit(null); setPending(pd) }}
          onSaved={reload}
        />
      )}
      <PolicyChangeModal
        open={!!pending}
        title={pending?.title ?? ''}
        changes={pending?.changes ?? {}}
        apply={() => pending!.apply()}
        onClose={() => setPending(null)}
        onDone={reload}
      />
      <EntityFormModal open={editing} title="Policy düzenle" fields={policyFields} createPath="/api/policies" updatePath={`/api/policies/${id}`}
        initial={{ ...p }} onClose={() => setEditing(false)} onSaved={reload} />
    </>
  )
}

interface RuleForm {
  code: string
  name: string
  description?: string
  effect: RuleEffect
  order: number
  reasonCode?: string
  isActive: boolean
}

/** Rule (Effect + Condition) oluştur/düzenle. Kaydetmeden önce policy etki analizi gösterilir. */
function RuleModal({ policyId, rule, types, nextOrder, onClose, onPreview, onSaved }: {
  policyId: number
  rule?: RuleView
  types: ConditionTypeInfo[]
  nextOrder: number
  onClose: () => void
  onPreview: (p: Pending) => void
  onSaved: () => void
}) {
  const [form] = Form.useForm<RuleForm>()
  const { message } = App.useApp()
  const [condition, setCondition] = useState<ConditionDraft>(rule?.condition ? toDraft(rule.condition) : emptyPredicate())
  const [saving, setSaving] = useState(false)
  const shared = useApi<SharedConditionInfo[]>('/api/shared-conditions')
  // Yeni rule: başka bir policy'deki rule'u şablon olarak kopyala (bağımsız kopya; kaynak değişirse etkilenmez)
  const allRules = useApi<(RuleView & { policyId: number; policy: string })[]>(rule ? null : '/api/rules')
  const copyFrom = (ruleId: number) => {
    const src = allRules.data?.find((x) => x.id === ruleId)
    if (!src) return
    form.setFieldsValue({ code: src.code, name: src.name, description: src.description, effect: src.effect, reasonCode: src.reasonCode, isActive: true })
    setCondition(toDraft(src.condition))
    message.info(`${src.policy} / ${src.code} kopyalandı — gerekirse düzenleyip kaydedin.`)
  }

  const build = async () => {
    const v = await form.validateFields()
    const body = { ...v, condition }
    const draft: RuleDraft = { policyId, code: v.code, name: v.name, effect: v.effect, order: v.order, reasonCode: v.reasonCode, condition }
    return { v, body, draft }
  }

  const save = async () => {
    const { body } = await build()
    setSaving(true)
    try {
      if (rule) await api.put(`/api/rules/${rule.id}`, body)
      else await api.post(`/api/policies/${policyId}/rules`, body)
      message.success('Kaydedildi')
      onSaved()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setSaving(false)
    }
  }

  const preview = async () => {
    const { body, draft } = await build()
    onPreview(rule
      ? {
          title: `Etki: ${rule.code} rule'u değişirse`,
          changes: { replacedRules: [{ ruleId: rule.id, rule: draft }], ...(body.isActive !== rule.isActive ? { ruleOverrides: [{ ruleId: rule.id, isActive: body.isActive }] } : {}) },
          apply: () => api.put(`/api/rules/${rule.id}`, body),
        }
      : {
          title: `Etki: policy'ye ${draft.code} rule'u eklenirse`,
          changes: { addedRules: [draft] },
          apply: () => api.post(`/api/policies/${policyId}/rules`, body),
        })
  }

  return (
    <Modal
      open
      width={980}
      title={rule ? `Rule düzenle: ${rule.code}` : 'Yeni rule'}
      onCancel={onClose}
      destroyOnHidden
      footer={[
        <Button key="c" onClick={onClose}>Vazgeç</Button>,
        <Button key="s" loading={saving} onClick={save}>Doğrudan kaydet</Button>,
        <Button key="p" type="primary" icon={<ExperimentOutlined />} onClick={preview}>Etkisini gör ve kaydet…</Button>,
      ]}
    >
      {!rule && (
        <Card size="small" style={{ marginBottom: 12, background: '#f6f9ff' }}>
          <Typography.Text strong>Mevcut bir rule'dan kopyala (opsiyonel)</Typography.Text>
          <Select
            showSearch
            allowClear
            placeholder="Policy / rule seçin — kod, effect, reason ve condition forma dolar"
            style={{ width: '100%', marginTop: 6 }}
            loading={allRules.loading}
            onChange={(v?: number) => v && copyFrom(v)}
            optionFilterProp="label"
            options={Object.entries(
              (allRules.data ?? []).reduce<Record<string, { value: number; label: string }[]>>((acc, r) => {
                (acc[r.policy] ??= []).push({ value: r.id, label: `${r.policy} / ${r.code} — ${r.effect.toUpperCase()} ⇐ ${r.expression}` })
                return acc
              }, {}),
            ).map(([policy, options]) => ({ label: policy, options }))}
          />
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>
            Rule'lar policy'ye aittir; kopya bağımsızdır. Aynı policy'de kod benzersiz olmalı.
          </Typography.Text>
        </Card>
      )}
      <Form form={form} layout="vertical" initialValues={rule ? { ...rule } : { effect: 'Deny', order: nextOrder, isActive: true }}>
        <Row gutter={12}>
          <Col span={8}><Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input disabled={!!rule} placeholder="CASH_LIMIT_EXCEEDED" /></Form.Item></Col>
          <Col span={16}><Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input placeholder="İşlem tutarı kullanıcı limitini aşıyorsa reddet" /></Form.Item></Col>
          <Col span={6}>
            <Form.Item name="effect" label="Effect (condition TRUE ise)" rules={[{ required: true }]}>
              <Select options={[{ value: 'Deny', label: 'DENY' }, { value: 'Permit', label: 'PERMIT' }]} />
            </Form.Item>
          </Col>
          <Col span={6}><Form.Item name="order" label="Sıra" tooltip="Deterministik değerlendirme; First-applicable'da önceliği belirler."><InputNumber style={{ width: '100%' }} /></Form.Item></Col>
          <Col span={8}><Form.Item name="reasonCode" label="Reason code"><Input placeholder="AMOUNT_EXCEEDS_USER_LIMIT" /></Form.Item></Col>
          <Col span={4}><Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item></Col>
          <Col span={24}><Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item></Col>
        </Row>
      </Form>
      <Typography.Text strong>Condition</Typography.Text>
      <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginBottom: 6 }}>
        Kullanıcıya özgü değerler (limit vb.) buraya yazılmaz; condition tipi onları attribute olarak çözer. Banka ağı / mesai gibi ortak tanımlar için "Ortak koşul (@referans)" seçin. Önizleme: <Code>{renderDraft(condition)}</Code>
      </Typography.Paragraph>
      <ConditionBuilder value={condition} onChange={setCondition} types={types} shared={shared.data ?? []} />
    </Modal>
  )
}
