import { Alert, Table, Tabs, Tag, Typography } from 'antd'
import { useNavigate } from 'react-router-dom'
import type { ConditionTypeInfo, ParamDef } from '../api/types'
import { useApi } from '../hooks/useApi'
import { ActiveTag, Code, EffectTag, PageHeader } from '../components/common'

interface RuleRow {
  id: number
  code: string
  name: string
  effect: string
  order: number
  reasonCode?: string
  isActive: boolean
  expression: string
  policyId: number
  policy: string
}

/**
 * Rule'lar policy'ye aittir (düzenleme policy detayında). Bu ekran:
 *  - tüm policy'lerdeki rule'ların genel görünümü
 *  - Condition tipleri kataloğu (koddaki IConditionHandler'lar)
 */
export function RulesPage() {
  const rules = useApi<RuleRow[]>('/api/rules')
  const types = useApi<ConditionTypeInfo[]>('/api/condition-types')
  const navigate = useNavigate()

  return (
    <>
      <PageHeader
        title="Rule'lar & Condition Tipleri"
        subtitle="Rule = Effect (Permit/Deny) + Condition; policy'ye aittir. Condition tipi = koşulun NASIL değerlendirileceğini bilen C# handler."
      />
      <Tabs
        items={[
          {
            key: 'rules',
            label: 'Tüm rule\'lar',
            children: (
              <Table<RuleRow>
                rowKey="id"
                size="small"
                loading={rules.loading}
                dataSource={rules.data ?? []}
                pagination={false}
                rowClassName="clickable-row"
                onRow={(r) => ({ onClick: () => navigate(`/policies/${r.policyId}`) })}
                columns={[
                  { title: 'Policy', dataIndex: 'policy', render: (v) => <Tag color="purple">{v}</Tag> },
                  { title: '#', dataIndex: 'order', width: 60 },
                  { title: 'Rule', render: (_, r) => <><Code>{r.code}</Code><br /><Typography.Text type="secondary">{r.name}</Typography.Text></> },
                  { title: 'Effect', render: (_, r) => <EffectTag effect={r.effect} /> },
                  { title: 'Condition', dataIndex: 'expression', render: (v) => <Typography.Text style={{ fontSize: 12 }}>{v}</Typography.Text> },
                  { title: 'Reason', dataIndex: 'reasonCode', render: (v) => v && <Code>{v}</Code> },
                  { title: '', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} /> },
                ]}
              />
            ),
          },
          {
            key: 'types',
            label: 'Condition tipleri (katalog)',
            children: (
              <>
                <Alert type="info" showIcon style={{ marginBottom: 12 }}
                  message="Katalog koddaki IConditionHandler implementasyonlarından açılışta senkronize edilir. DB'de sadece parametre tutulur; davranış C#'tadır. Yeni tip = yeni handler sınıfı. Kodu kaldırılan tip pasifleşir ve o tipteki condition'lar Indeterminate (fail-closed) olur." />
                <Table<ConditionTypeInfo>
                  rowKey="id"
                  size="small"
                  loading={types.loading}
                  dataSource={types.data ?? []}
                  pagination={false}
                  columns={[
                    { title: 'Kod', render: (_, t) => <><Code>{t.code}</Code><br /><b>{t.name}</b></> },
                    { title: 'TRUE ise', dataIndex: 'description' },
                    { title: 'Parametreler', render: (_, t) => (JSON.parse(t.parameterSchemaJson) as ParamDef[]).map((p) => <Tag key={p.key} title={p.description}>{p.key}{p.required ? '*' : ''}</Tag>) },
                    { title: 'Okuduğu attribute\'lar', dataIndex: 'requiredAttributes', render: (v?: string) => v?.split(',').filter(Boolean).map((k) => <Tag color={k.startsWith('Subject') ? 'blue' : k.startsWith('Environment') ? 'cyan' : 'orange'} key={k}>{k}</Tag>) },
                    { title: 'Kapsam', dataIndex: 'defaultScope' },
                    { title: 'Kullanım', dataIndex: 'usageCount' },
                    { title: '', dataIndex: 'isAvailable', render: (v) => (v ? <Tag color="green">Handler var</Tag> : <Tag color="red">Handler yok</Tag>) },
                  ]}
                />
              </>
            ),
          },
        ]}
      />
    </>
  )
}
