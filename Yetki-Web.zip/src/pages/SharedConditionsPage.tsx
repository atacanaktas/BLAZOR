import { Alert, App, Button, Card, Col, Drawer, Flex, Form, Input, Modal, Popconfirm, Row, Select, Switch, Table, Tag, Typography } from 'antd'
import { DeleteOutlined, EditOutlined, ExperimentOutlined, PlusOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import type { ConditionDraft, ConditionTypeInfo, ConditionView, SharedConditionInfo } from '../api/types'
import { useApi } from '../hooks/useApi'
import { ActiveTag, Code, PageHeader } from '../components/common'
import { ConditionBuilder, emptyPredicate, renderDraft, toDraft } from '../components/ConditionBuilder'
import { PolicyChangeModal } from '../components/PolicyImpact'

interface Usage { policyId: number; policy: string; ruleId: number; rule: string; via?: string }
interface Detail {
  sharedCondition: { id: number; code: string; name: string; description?: string; scope: 'Global' | 'Domain'; domain?: string; isActive: boolean; version: number }
  expression: string
  expandedExpression: string
  condition?: ConditionView
  usages: Usage[]
}

const domains = ['GISE', 'VADELI', 'KREDI', 'ODEME', 'MUSTERI', 'RAPOR', 'YETKI', 'GENEL']

/**
 * Ortak (adlandırılmış) koşullar: "Banka ağı", "Mesai saati" gibi tanımlar TEK yerde.
 * Rule'lar @referans ile bağlanır; Effect/Order/Reason policy'deki rule'da kalır.
 * Değişiklik onu kullanan tüm policy'leri etkiler → kaydetmeden önce etki analizi.
 */
export function SharedConditionsPage() {
  const list = useApi<SharedConditionInfo[]>('/api/shared-conditions')
  const types = useApi<ConditionTypeInfo[]>('/api/condition-types')
  const { message } = App.useApp()
  const navigate = useNavigate()
  const [editing, setEditing] = useState<number | 'new' | null>(null)
  const [usagesOf, setUsagesOf] = useState<number | null>(null)
  const usages = useApi<Detail>(usagesOf ? `/api/shared-conditions/${usagesOf}` : null)

  const remove = async (id: number) => {
    try {
      await api.del(`/api/shared-conditions/${id}`)
      message.success('Silindi')
      list.reload()
    } catch (e) {
      message.error((e as Error).message)
    }
  }

  return (
    <>
      <PageHeader
        title="Ortak Koşullar"
        subtitle="Birden çok policy'de kullanılan tanımlar (banka ağı, mesai saati, eşikler) tek yerde; rule'lar @referans ile bağlanır."
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setEditing('new')}>Yeni ortak koşul</Button>}
      />
      <Alert type="info" showIcon style={{ marginBottom: 12 }}
        message="Rule = Effect + Condition policy'ye aittir; paylaşılan şey KARAR değil TANIM'dır. Ortak koşul değişince onu kullanan tüm policy'lerin versiyonu artar. Kullanımdaki ortak koşul pasifleştirilemez/silinemez." />
      <Table<SharedConditionInfo>
        rowKey="id"
        loading={list.loading}
        dataSource={list.data ?? []}
        pagination={false}
        columns={[
          { title: 'Kod', render: (_, s) => <><Code>@{s.code}</Code><br /><Typography.Text type="secondary">{s.name}</Typography.Text></> },
          { title: 'Kapsam', render: (_, s) => <Tag color={s.scope === 'Global' ? 'blue' : 'gold'}>{s.scope}{s.domain ? `: ${s.domain}` : ''}</Tag> },
          { title: 'Tanım', dataIndex: 'expression', render: (v) => <Typography.Text style={{ fontSize: 12, wordBreak: 'break-word' }}>{v}</Typography.Text> },
          {
            title: 'Kullanım',
            render: (_, s) => (
              <a onClick={() => setUsagesOf(s.id)}>
                <Tag color={s.usageCount ? 'purple' : 'default'}>{s.usageCount} rule</Tag>
                {s.policies.map((p) => <Tag key={p}>{p}</Tag>)}
              </a>
            ),
          },
          { title: 'Sürüm', dataIndex: 'version', width: 70, render: (v) => `v${v}` },
          { title: '', dataIndex: 'isActive', render: (v) => <ActiveTag active={v} />, width: 70 },
          {
            title: '',
            width: 90,
            render: (_, s) => (
              <Flex gap={4}>
                <Button size="small" icon={<EditOutlined />} onClick={() => setEditing(s.id)} />
                <Popconfirm title={`@${s.code} silinsin mi?`} disabled={s.usageCount > 0} onConfirm={() => remove(s.id)}>
                  <Button size="small" danger icon={<DeleteOutlined />} disabled={s.usageCount > 0} title={s.usageCount ? 'Kullanımda; silinemez' : undefined} />
                </Popconfirm>
              </Flex>
            ),
          },
        ]}
      />

      <Drawer open={!!usagesOf} onClose={() => setUsagesOf(null)} size="large" title={usages.data ? `@${usages.data.sharedCondition.code} — kullanıldığı yerler` : ''}>
        {usages.data && (
          <Flex vertical gap={12}>
            <Card size="small" title="Tanım (referanslar açılmış)">
              <Typography.Text style={{ fontSize: 12 }}>{usages.data.expandedExpression}</Typography.Text>
            </Card>
            <Table<Usage>
              size="small"
              rowKey="ruleId"
              pagination={false}
              dataSource={usages.data.usages}
              rowClassName="clickable-row"
              onRow={(u) => ({ onClick: () => navigate(`/policies/${u.policyId}`) })}
              columns={[
                { title: 'Policy', dataIndex: 'policy', render: (v) => <Tag color="purple">{v}</Tag> },
                { title: 'Rule', dataIndex: 'rule', render: (v) => <Code>{v}</Code> },
                { title: 'Yol', dataIndex: 'via', render: (v) => (v ? <Typography.Text type="secondary">dolaylı: {v}</Typography.Text> : 'doğrudan') },
              ]}
            />
          </Flex>
        )}
      </Drawer>

      {editing && (
        <SharedConditionModal
          id={editing === 'new' ? undefined : editing}
          types={types.data ?? []}
          shared={list.data ?? []}
          onClose={() => setEditing(null)}
          onSaved={list.reload}
        />
      )}
    </>
  )
}

interface FormValues { code: string; name: string; description?: string; scope: 'Global' | 'Domain'; domain?: string; isActive: boolean }

function SharedConditionModal({ id, types, shared, onClose, onSaved }: {
  id?: number
  types: ConditionTypeInfo[]
  shared: SharedConditionInfo[]
  onClose: () => void
  onSaved: () => void
}) {
  const detail = useApi<Detail>(id ? `/api/shared-conditions/${id}` : null)
  if (id && !detail.data) return <Modal open footer={null} onCancel={onClose} loading />
  return <SharedConditionForm detail={detail.data} types={types} shared={shared} onClose={onClose} onSaved={onSaved} />
}

function SharedConditionForm({ detail, types, shared, onClose, onSaved }: {
  detail?: Detail
  types: ConditionTypeInfo[]
  shared: SharedConditionInfo[]
  onClose: () => void
  onSaved: () => void
}) {
  const [form] = Form.useForm<FormValues>()
  const { message } = App.useApp()
  const sc = detail?.sharedCondition
  const [condition, setCondition] = useState<ConditionDraft>(detail?.condition ? toDraft(detail.condition) : emptyPredicate())
  const [scope, setScope] = useState<'Global' | 'Domain'>(sc?.scope ?? 'Global')
  const [saving, setSaving] = useState(false)
  const [preview, setPreview] = useState<{ body: unknown } | null>(null)
  const usageCount = detail?.usages.length ?? 0

  const body = async () => ({ ...(await form.validateFields()), condition })

  const save = async () => {
    const b = await body()
    setSaving(true)
    try {
      if (sc) await api.put(`/api/shared-conditions/${sc.id}`, b)
      else await api.post('/api/shared-conditions', b)
      message.success('Kaydedildi')
      onSaved()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <>
      <Modal
        open
        width={980}
        title={sc ? `Ortak koşul: @${sc.code} (v${sc.version})` : 'Yeni ortak koşul'}
        onCancel={onClose}
        destroyOnHidden
        footer={[
          <Button key="c" onClick={onClose}>Vazgeç</Button>,
          <Button key="s" loading={saving} onClick={save}>{sc && usageCount ? 'Doğrudan kaydet' : 'Kaydet'}</Button>,
          sc && usageCount > 0 && (
            <Button key="p" type="primary" icon={<ExperimentOutlined />} onClick={async () => setPreview({ body: await body() })}>
              Etkisini gör ve kaydet…
            </Button>
          ),
        ]}
      >
        {sc && usageCount > 0 && (
          <Alert type="warning" showIcon style={{ marginBottom: 12 }}
            message={`Bu ortak koşul ${usageCount} rule tarafından kullanılıyor (${[...new Set(detail!.usages.map((u) => u.policy))].join(', ')}). Değişiklik hepsini etkiler.`} />
        )}
        <Form form={form} layout="vertical" initialValues={sc ? { ...sc } : { scope: 'Global', isActive: true }}>
          <Row gutter={12}>
            <Col span={8}><Form.Item name="code" label="Kod" rules={[{ required: true }]}><Input disabled={!!sc} placeholder="BANK_NETWORK" /></Form.Item></Col>
            <Col span={16}><Form.Item name="name" label="Ad" rules={[{ required: true }]}><Input placeholder="Banka iç ağı" /></Form.Item></Col>
            <Col span={6}>
              <Form.Item name="scope" label="Kapsam" tooltip="Global: yetki/güvenlik ekibi; Domain: ilgili iş ekibi">
                <Select onChange={setScope} options={[{ value: 'Global', label: 'Global' }, { value: 'Domain', label: 'Domain' }]} />
              </Form.Item>
            </Col>
            {scope === 'Domain' && (
              <Col span={6}><Form.Item name="domain" label="Domain" rules={[{ required: true }]}><Select options={domains.map((d) => ({ value: d, label: d }))} /></Form.Item></Col>
            )}
            <Col span={4}>
              <Form.Item name="isActive" label="Aktif" valuePropName="checked" tooltip="Kullanımdaki ortak koşul pasifleştirilemez.">
                <Switch disabled={!!sc && usageCount > 0 && sc.isActive} />
              </Form.Item>
            </Col>
            <Col span={24}><Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item></Col>
          </Row>
        </Form>
        <Typography.Text strong>Tanım</Typography.Text>{' '}
        <Typography.Text type="secondary" style={{ fontSize: 12 }}>önizleme: <Code>{renderDraft(condition)}</Code></Typography.Text>
        <div style={{ marginTop: 6 }}>
          <ConditionBuilder value={condition} onChange={setCondition} types={types} shared={shared} excludeShared={sc?.code} />
        </div>
      </Modal>
      {preview && sc && (
        <PolicyChangeModal
          open
          title={`Etki: @${sc.code} ortak koşulu değişirse (${usageCount} rule)`}
          changes={{ sharedConditionReplacements: [{ sharedConditionId: sc.id, condition }] }}
          apply={() => api.put(`/api/shared-conditions/${sc.id}`, preview.body)}
          onClose={() => setPreview(null)}
          onDone={() => { onSaved(); onClose() }}
        />
      )}
    </>
  )
}
