﻿import { Badge, Flex, Layout, Menu, Select, Tooltip, Typography } from 'antd'
import {
  ApartmentOutlined,
  AuditOutlined,
  BranchesOutlined,
  CloudServerOutlined,
  DashboardOutlined,
  ExperimentOutlined,
  FileProtectOutlined,
  KeyOutlined,
  NodeIndexOutlined,
  NotificationOutlined,
  PlayCircleOutlined,
  SafetyCertificateOutlined,
  ShareAltOutlined,
  StopOutlined,
  TeamOutlined,
  ThunderboltOutlined,
  UserOutlined,
} from '@ant-design/icons'
import { useEffect, useState } from 'react'
import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import { api, getActor, setActor } from '../api/client'

const { Sider, Header, Content } = Layout

const menu = [
  { key: '/', icon: <DashboardOutlined />, label: 'Genel Bakış' },
  {
    type: 'group' as const,
    label: 'Kimlik & RBAC',
    children: [
      { key: '/users', icon: <UserOutlined />, label: 'Kullanıcılar' },
      { key: '/roles', icon: <SafetyCertificateOutlined />, label: 'Roller' },
      { key: '/permissions', icon: <KeyOutlined />, label: 'Permission\'lar' },
      { key: '/groups', icon: <TeamOutlined />, label: 'Gruplar' },
      { key: '/units', icon: <ApartmentOutlined />, label: 'Birimler' },
    ],
  },
  {
    type: 'group' as const,
    label: 'Policy Motoru',
    children: [
      { key: '/policies', icon: <FileProtectOutlined />, label: 'Policy\'ler' },
      { key: '/shared-conditions', icon: <ShareAltOutlined />, label: 'Ortak Koşullar' },
      { key: '/rules', icon: <BranchesOutlined />, label: 'Rule & Condition Tipleri' },
      { key: '/sod', icon: <StopOutlined />, label: 'SoD & İhlaller' },
    ],
  },
  {
    type: 'group' as const,
    label: 'Analiz & Test',
    children: [
      { key: '/evaluate', icon: <ThunderboltOutlined />, label: 'Yetki Testi' },
      { key: '/what-if', icon: <ExperimentOutlined />, label: 'What-If' },
      { key: '/sdk-demo', icon: <PlayCircleOutlined />, label: 'SDK Demo' },
    ],
  },
  {
    type: 'group' as const,
    label: 'Entegrasyon & İzleme',
    children: [
      { key: '/external', icon: <CloudServerOutlined />, label: 'Dış Sistemler (RACF)' },
      { key: '/events', icon: <NodeIndexOutlined />, label: 'Event & Provisioning' },
      { key: '/audit', icon: <AuditOutlined />, label: 'Audit' },
    ],
  },
]

const actors = ['selin.aydin', 'yetki.admin', 'can.ozturk']

export function AppLayout() {
  const navigate = useNavigate()
  const location = useLocation()
  const [actor, setActorState] = useState(getActor())
  const [info, setInfo] = useState<{ version: number; pending: number; provisioning: number }>()

  useEffect(() => {
    const load = () =>
      api
        .get<{ authorizationVersion: number; counts: { pendingOutbox: number; provisioningActions: number } }>('/api/dashboard')
        .then((d) => setInfo({ version: d.authorizationVersion, pending: d.counts.pendingOutbox, provisioning: d.counts.provisioningActions }))
        .catch(() => setInfo(undefined))
    load()
    const t = setInterval(load, 5000)
    return () => clearInterval(t)
  }, [])

  const selected = '/' + (location.pathname.split('/')[1] ?? '')

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider width={236} breakpoint="lg" collapsedWidth={0} theme="dark">
        <div style={{ padding: '18px 20px', color: '#fff' }}>
          <Typography.Title level={4} style={{ color: '#fff', margin: 0 }}>Yetki Motoru</Typography.Title>
          <Typography.Text style={{ color: 'rgba(255,255,255,.55)', fontSize: 12 }}>Authorization Platform · Prototip</Typography.Text>
        </div>
        <Menu theme="dark" mode="inline" selectedKeys={[selected]} items={menu} onClick={(e) => navigate(e.key)} />
      </Sider>
      <Layout>
        <Header style={{ background: '#fff', padding: '0 24px', borderBottom: '1px solid #e8ecf1' }}>
          <Flex justify="flex-end" align="center" gap={20} style={{ height: '100%' }}>
            {info ? (
              <>
                <Tooltip title="Global yetki versiyonu: her RBAC/grup/policy değişikliğinde artar, effective cache'i geçersiz kılar.">
                  <Typography.Text type="secondary">Yetki v{info.version}</Typography.Text>
                </Tooltip>
                <Tooltip title="İşlenmeyi bekleyen outbox event'leri / toplam provisioning aksiyonu">
                  <Badge count={info.pending} size="small">
                    <NotificationOutlined style={{ fontSize: 18, cursor: 'pointer' }} onClick={() => navigate('/events')} />
                  </Badge>
                </Tooltip>
              </>
            ) : (
              <Typography.Text type="danger">API'ye ulaşılamıyor</Typography.Text>
            )}
            <Tooltip title="Yönetim işlemini yapan kişi (audit). Prototipte X-Actor header'ı ile gönderilir.">
              <Select
                value={actor}
                style={{ width: 170 }}
                options={actors.map((a) => ({ value: a, label: a }))}
                onChange={(v) => {
                  setActor(v)
                  setActorState(v)
                }}
              />
            </Tooltip>
          </Flex>
        </Header>
        <Content style={{ padding: 24, maxWidth: 1480, width: '100%' }}>
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  )
}
