import { useCallback, useEffect, useState } from 'react'
import { api } from '../api/client'
import type { Option } from '../api/types'

/** GET isteği + yeniden yükleme. path null ise istek atılmaz. */
export function useApi<T>(path: string | null) {
  const [data, setData] = useState<T | undefined>(undefined)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | undefined>(undefined)
  const [tick, setTick] = useState(0)

  useEffect(() => {
    if (!path) return
    let cancelled = false
    setLoading(true)
    setError(undefined)
    api
      .get<T>(path)
      .then((d) => !cancelled && setData(d))
      .catch((e: Error) => !cancelled && setError(e.message))
      .finally(() => !cancelled && setLoading(false))
    return () => {
      cancelled = true
    }
  }, [path, tick])

  const reload = useCallback(() => setTick((t) => t + 1), [])
  return { data, loading, error, reload, setData }
}

type OptionKind = 'users' | 'roles' | 'permissions' | 'groups' | 'orgUnits' | 'policies' | 'rules'

const loaders: Record<OptionKind, () => Promise<Option[]>> = {
  users: async () =>
    (await api.get<{ items: { id: number; userName: string; fullName: string }[] }>('/api/users?pageSize=200')).items.map((u) => ({
      id: u.id,
      code: u.userName,
      name: u.fullName,
    })),
  roles: async () => (await api.get<Option[]>('/api/roles')).map(({ id, code, name }) => ({ id, code, name })),
  permissions: async () => (await api.get<Option[]>('/api/permissions')).map(({ id, code, name }) => ({ id, code, name })),
  groups: async () => (await api.get<Option[]>('/api/groups')).map(({ id, code, name }) => ({ id, code, name })),
  orgUnits: async () => (await api.get<Option[]>('/api/org-units')).map(({ id, code, name }) => ({ id, code, name })),
  policies: async () => (await api.get<Option[]>('/api/policies')).map(({ id, code, name }) => ({ id, code, name })),
  rules: async () => (await api.get<Option[]>('/api/rules')).map(({ id, code, name }) => ({ id, code, name })),
}

/** Seçim listeleri (Select) için basit liste yükleyici. */
export function useOptions(kind: OptionKind) {
  const [options, setOptions] = useState<Option[]>([])
  useEffect(() => {
    loaders[kind]().then(setOptions).catch(() => setOptions([]))
  }, [kind])
  return options
}

export function toSelectOptions(options: Option[], exclude: number[] = []) {
  return options
    .filter((o) => !exclude.includes(o.id))
    .map((o) => ({ value: o.id, label: `${o.code} — ${o.name}` }))
}
