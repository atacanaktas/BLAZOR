import { Navigate, Route, Routes } from 'react-router-dom'
import { AppLayout } from './layout/AppLayout'
import { DashboardPage } from './pages/DashboardPage'
import { UsersPage } from './pages/users/UsersPage'
import { UserDetailPage } from './pages/users/UserDetailPage'
import { RolesPage, RoleDetailPage } from './pages/RolesPages'
import { PermissionsPage, PermissionDetailPage } from './pages/PermissionsPages'
import { GroupsPage, GroupDetailPage } from './pages/GroupsPages'
import { OrgUnitsPage } from './pages/OrgUnitsPage'
import { PoliciesPage, PolicyDetailPage } from './pages/PoliciesPages'
import { RulesPage } from './pages/RulesPage'
import { SharedConditionsPage } from './pages/SharedConditionsPage'
import { SodPage } from './pages/SodPage'
import { EvaluatePage } from './pages/EvaluatePage'
import { WhatIfPage } from './pages/WhatIfPage'
import { SdkDemoPage } from './pages/SdkDemoPage'
import { ExternalPage } from './pages/ExternalPage'
import { EventsPage } from './pages/EventsPage'
import { AuditPage } from './pages/AuditPage'

export default function App() {
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route index element={<DashboardPage />} />
        <Route path="users" element={<UsersPage />} />
        <Route path="users/:id" element={<UserDetailPage />} />
        <Route path="roles" element={<RolesPage />} />
        <Route path="roles/:id" element={<RoleDetailPage />} />
        <Route path="permissions" element={<PermissionsPage />} />
        <Route path="permissions/:id" element={<PermissionDetailPage />} />
        <Route path="groups" element={<GroupsPage />} />
        <Route path="groups/:id" element={<GroupDetailPage />} />
        <Route path="units" element={<OrgUnitsPage />} />
        <Route path="org-units" element={<Navigate to="/units" replace />} />
        <Route path="policies" element={<PoliciesPage />} />
        <Route path="policies/:id" element={<PolicyDetailPage />} />
        <Route path="rules" element={<RulesPage />} />
        <Route path="shared-conditions" element={<SharedConditionsPage />} />
        <Route path="sod" element={<SodPage />} />
        <Route path="evaluate" element={<EvaluatePage />} />
        <Route path="what-if" element={<WhatIfPage />} />
        <Route path="sdk-demo" element={<SdkDemoPage />} />
        <Route path="external" element={<ExternalPage />} />
        <Route path="events" element={<EventsPage />} />
        <Route path="audit" element={<AuditPage />} />
      </Route>
    </Routes>
  )
}
