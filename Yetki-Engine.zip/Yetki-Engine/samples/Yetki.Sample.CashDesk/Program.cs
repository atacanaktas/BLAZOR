using System.Globalization;
using Yetki.Sdk;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;

var builder = WebApplication.CreateBuilder(args);

// --- Yetki SDK: tek satır kayıt. İş kodunda yetki if'i yok. ---
builder.Services.AddYetkiAuthorization(o =>
{
    o.EngineBaseUrl = builder.Configuration["Yetki:EngineBaseUrl"] ?? "http://localhost:5100";
    o.ApplicationCode = "GISE-DEMO";
    o.AllowUserHeaderForDemo = true; // PROTOTİP: kimlik X-User header'ından. Üretimde false + gerçek authentication.
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c => c.SwaggerDoc("v1", new() { Title = "Örnek İş Uygulaması (Gişe) — Yetki SDK demo", Version = "v1" }));
builder.Services.AddCors(o => o.AddPolicy("web", p => p.WithOrigins("http://localhost:5180", "http://127.0.0.1:5180").AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI();
app.UseCors("web");
app.MapControllers();
app.MapGet("/", () => Results.Redirect("/swagger")).ExcludeFromDescription();
app.Run();
