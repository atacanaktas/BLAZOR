using Microsoft.AspNetCore.Mvc;
using Yetki.Sdk;

namespace Yetki.Sample.CashDesk.Controllers;

// ------------------------------------------------------------------
// İş ekibinin kendi DTO'ları: property adları serbest (Türkçe/İngilizce fark etmez).
// SDK sadece [AuthContext] semantik işaretine bakar.
// ------------------------------------------------------------------

public sealed class NakitCekimTalebi
{
    [AuthContext(AuthContextType.CustomerId)]
    public string MusteriNo { get; set; } = default!;

    [AuthContext(AuthContextType.TransactionAmount)]
    public decimal Tutar { get; set; }

    [AuthContext(AuthContextType.Currency)]
    public string DovizKodu { get; set; } = "TRY";

    public string? Aciklama { get; set; }
}

public sealed class CreditApprovalRequest
{
    public string ApplicationNo { get; set; } = default!;

    public LoanDetails Loan { get; set; } = new();

    public sealed class LoanDetails
    {
        // İç içe DTO'da da çalışır (varsayılan derinlik 3)
        [AuthContext(AuthContextType.TransactionAmount)]
        public decimal PrincipalAmount { get; set; }
        public int TermMonths { get; set; }
    }
}

public sealed class VadeliKapamaTalebi
{
    [AuthContext(AuthContextType.BranchCode)]
    public string IslemSubesi { get; set; } = default!;
}

[ApiController]
[Route("api/cash")]
public class CashController : ControllerBase
{
    /// <summary>
    /// Nakit çekim. Endpoint sadece gereken permission'ı deklare eder.
    /// Mesai / vezne kanalı / kullanıcı limiti / izin / kendi hesabı kontrolleri motordaki policy'dedir.
    /// </summary>
    [HttpPost("withdraw")]
    [RequiresPermission("CASH_WITHDRAW", Action = "withdraw")]
    public IActionResult Withdraw([FromBody] NakitCekimTalebi talep) => Ok(new
    {
        dekontNo = $"DK-{DateTime.UtcNow:yyyyMMddHHmmss}",
        talep.MusteriNo,
        talep.Tutar,
        talep.DovizKodu,
        mesaj = "Nakit çekim işlemi gerçekleştirildi (demo).",
        yetkiKarari = HttpContext.GetAuthorizationDecisions().Select(d => new { d.DecisionId, d.Permission, d.ReasonCode })
    });
}

[ApiController]
[Route("api/term-deposits")]
public class TermDepositController : ControllerBase
{
    /// <summary>Statik permission örneği (policy yok).</summary>
    [HttpGet]
    [RequiresPermission("TERM_DEPOSIT_VIEW")]
    public IActionResult List() => Ok(new[]
    {
        new { hesapNo = "TR120001", bakiye = 150_000m, vade = "2026-12-01" },
        new { hesapNo = "TR120002", bakiye = 42_500m, vade = "2027-03-15" }
    });

    /// <summary>Parametre üzerinde [AuthContext] + body DTO birlikte.</summary>
    [HttpPost("{accountNo}/close")]
    [RequiresPermission("TERM_DEPOSIT_CLOSE", ResourceType = "account")]
    public IActionResult Close([FromRoute, AuthContext(AuthContextType.AccountNo)] string accountNo, [FromBody] VadeliKapamaTalebi talep) =>
        Ok(new { accountNo, talep.IslemSubesi, mesaj = "Vadeli hesap kapatıldı (demo)." });
}

[ApiController]
[Route("api/credits")]
public class CreditController : ControllerBase
{
    [HttpPost("approve")]
    [RequiresPermission("CREDIT_APPROVE")]
    public IActionResult Approve([FromBody] CreditApprovalRequest request) =>
        Ok(new { request.ApplicationNo, request.Loan.PrincipalAmount, status = "APPROVED (demo)" });
}
