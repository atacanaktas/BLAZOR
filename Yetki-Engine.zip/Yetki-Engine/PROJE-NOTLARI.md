# Yetki-Engine — Proje Notları (Backend / Authorization Engine)

> Bu dosya, projeye daha sonra dönüldüğünde (insan veya AI asistan) **genel resmi, detayları, dikkat edilmesi gerekenleri ve TODO'ları** hızlıca hatırlamak içindir.
> Kaynak gereksinim dokümanı: `../authorization-engine-prototype-context.md` (ana doküman + Addendum). Tasarım kararlarının çoğu oradan gelir.
> Frontend notları: `../Yetki-Web/PROJE-NOTLARI.md`

---

## 1. Özet

Kurumsal/banka ölçeğinde **RBAC + Policy/Rule hibrit** yetki motoru prototipi.

- **RBAC** → "Kullanıcı normalde ne yapabilir?" (User → Role → Permission, + esnek Group, + legacy doğrudan permission)
- **Policy/Rule** → "Bu yetki bu işlem bağlamında şu an kullanılabilir mi?" (tutar, saat, kanal, şube, IP, izin durumu…)
- Kararlar **deterministik, açıklanabilir, audit'li**. AI/advisory karar yolunda **yok**.
- What-If, gerçek kararla **aynı kodu** kullanır (ayrı simülasyon mantığı yok).
- Persistence: **EF Core InMemory** (kurulum yok), model **SQL Server'a hazır**.
- Tüketici uygulamalar için **.NET SDK**: `[RequirePermission]` + DTO'da `[AuthContext]` → iş kodunda yetki `if`'i yok.

Teknoloji: .NET 9, ASP.NET Core Web API (controllers), EF Core 9 (InMemory + Relational metadata), Swashbuckle, xUnit.

---

## 2. Çalıştırma

```bash
# Engine API  → http://localhost:5100  (Swagger: /swagger)
dotnet run --project src/Yetki.Api

# Örnek iş uygulaması (SDK demo) → http://localhost:5200 (Swagger: /swagger)
dotnet run --project samples/Yetki.Sample.CashDesk

# Testler (46 test: PolicyEngineTests (saf birim), AuthorizationScenarioTests (10 senaryo), SharedConditionTests, WhatIf, SoD, effective)
dotnet test
```

- Web UI (`../Yetki-Web`) **http://localhost:5180** üzerinde çalışır; API'nin CORS listesi bu porta göre ayarlı (`appsettings.json → Cors:Origins`).
- InMemory olduğu için **her yeniden başlatmada veri sıfırlanır** ve seed tekrar yüklenir.
- Login storm / performans denemesi için: `appsettings.json → Seed:SyntheticUserCount` (ör. `21000`) → `test.user00001…` kullanıcıları üretilir.

| Port | Uygulama |
|---|---|
| 5100 | Yetki.Api (engine) |
| 5200 | Yetki.Sample.CashDesk (SDK kullanan örnek iş uygulaması) |
| 5180 | Yetki-Web (React admin) |

---

## 3. Solution yapısı

```
Yetki.sln
├─ src/
│  ├─ Yetki.Domain          Entity'ler + enum'lar (bağımlılık yok)
│  ├─ Yetki.Application     Tüm iş/authorization mantığı (EF Core soyutlaması üzerinden; provider bilmez)
│  │   ├─ Abstractions/     IYetkiDbContext, IClock, ICurrentActor, IAuthorizationVersion, exception'lar
│  │   ├─ Context/          AuthorizationContext, AuthContextKeys (Environment/Context anahtarları), SubjectAttributes
│  │   ├─ Effective/        AuthorizationGraphLoader → EffectivePermissionCalculator (saf) → EffectivePermissionService (cache)
│  │   │                    AuthorizationChangeSet (What-If/atama değişikliği modeli), PermissionHolderService
│  │   ├─ PolicyEngine/     ★ Policy engine (RBAC bilmez)
│  │   │   ├─ Model.cs          DecisionType, PolicyDefinition/RuleDefinition/ConditionNode, PolicyEvaluation/RuleEvaluation/ConditionTrace
│  │   │   ├─ PolicyEvaluator   Rule değerlendirme + condition ağacı (AND/OR/NOT, üç değerli mantık) + combining
│  │   │   ├─ Combining/        ICombiningAlgorithm: DenyOverrides, PermitOverrides, FirstApplicable + registry
│  │   │   ├─ Conditions/       IConditionHandler, ConditionHandlerRegistry, ConditionTypeCatalogSynchronizer, Handlers/*
│  │   │   └─ Attributes/       AttributeId/Category, IAttributeValueProvider, AttributeResolver, IAttributeRedactor
│  │   ├─ Evaluation/       AuthorizationEvaluator (PDP orkestratörü), AuthorizationRequest/Decision, PolicyDefinitionLoader,
│  │   │                    PolicyChangeSet (policy What-If), AuthorizationEngineOptions
│  │   ├─ Sod/              SodEvaluator (saf), SodService (kontrol, tarama, simülasyon)
│  │   ├─ Changes/          AuthorizationChangeService (analiz+uygula), AssignmentService (tüm atama işlemleri)
│  │   ├─ Definitions/      PolicyManagementService (rule/policy/SoD tanımları + validasyon)
│  │   ├─ Simulation/       SimulationService (What-If uçları; kendi karar mantığı YOK)
│  │   ├─ Events/           OutboxWriter, EventTypes, IOutboxEventHandler, IProvisioningAdapter, ProvisioningEventHandler
│  │   └─ Audit/            AuditWriter
│  ├─ Yetki.Infrastructure  YetkiDbContext (SQL-hazır model), DbSeeder, OutboxProcessor (BackgroundService),
│  │                        UserEntityAttributeProvider (prototip Subject attribute kaynağı), DummyProvisioningAdapter, LoggingEventHandler, DI
│  ├─ Yetki.Api             Controller'lar, ApiExceptionFilter (ProblemDetails), HttpCurrentActor (X-Actor)
│  └─ Yetki.Sdk             Tüketici SDK: [RequiresPermission], [AuthContext(AuthContextType.X)], YetkiAuthorizationFilter, AuthorizationContextBuilder, YetkiEngineClient
├─ samples/Yetki.Sample.CashDesk   SDK kullanım örneği (nakit çekim, vadeli, kredi onayı)
└─ tests/Yetki.Tests               PolicyEngineTests (saf birim), AuthorizationScenarioTests (10 senaryo), WhatIf, SoD, effective, cache
```

Bağımlılık yönü: `Api → Infrastructure → Application → Domain`. `Sdk` engine projelerine **bağlı değildir** (sadece HTTP sözleşmesi).

**Not:** Basit CRUD/sorgu uçları controller içinde doğrudan `IYetkiDbContext` ile yazıldı (bilinçli pragmatizm). Yetki mantığı içeren her şey (atama, SoD, karar, simülasyon, rule validasyonu) Application servislerindedir.

---

## 4. Domain modeli ve modelleme kararları

Tablolar (EF `ToTable` isimleri): Users, OrganizationUnits, UserOrganizationUnits, Roles, Permissions, RolePermissions, UserRoles, **UserPermissions**, Groups, GroupUsers, GroupRoles, GroupOrganizationUnits, GroupPermissions, **GroupGrantedRoles**, Policies, **Rules** (policy'ye ait), **RuleConditions** (ağaç), **ConditionParameters**, **ConditionTypes**, PermissionPolicies, SodRules, SodRuleMembers, SodViolations, ExternalSystems, ExternalPermissions, PermissionExternalMappings, OutboxEvents, ProvisioningActions, AuditLogs.

Önemli kararlar:

| Konu | Karar | Neden |
|---|---|---|
| **Group** | İki parça: **Kitle** (GroupUsers + GroupRoles "bu role *doğrudan* sahip herkes" + GroupOrganizationUnits "bu birimdeki herkes") ve **Grant** (GroupPermissions + GroupGrantedRoles). | Doküman "Grup = User + Role + OU kompozisyonu" diyor ve açıklama örneği "Group Y içindeki Role X üzerinden" → grup rol de verebilmeli. |
| Nested group | **Yok.** Rol kitlesi sadece `UserRoles` (doğrudan) ile eşleşir; gruptan gelen rol başka grubun kitlesini tetiklemez. | Derin zincir/döngü önleme, açıklanabilirlik. |
| **UserPermissions** | Doğrudan kullanıcı→permission (legacy/istisna). Ana model değil. | Smooth migration: mevcut sistemdeki doğrudan atamalar kayıpsız alınabilsin. |
| Org hiyerarşisi | `OrganizationUnit.ParentId` sadece bilgi. Yetki çözümlemesinde **kullanılmaz**. | Doküman prensibi #5. |
| **Policy modeli** | Ayrıntı: §4.1. Rule = Effect + Condition (policy'ye ait, 1:N). ConditionType = koddaki handler kataloğu. | Sektör kavramları (XACML'den esinlenme, XACML implementasyonu değil). |
| Kullanıcı limiti | `User.CashWithdrawalLimit` **PROTOTİP alanı**. Handler bunu doğrudan değil `IAttributeValueProvider` (Subject.CashWithdrawalLimit) ile okur. | İleride limit sistemi/HR provider'ı ile değişecek; policy/handler değişmeyecek. |
| `User.CustomerNo` | PROTOTİP: personelin kendi müşteri no'su (kendi hesabında işlem yasağı rule'u). | Aynı provider mantığı. |
| **SoD semantiği** | Kural üyeleri (permission ve/veya rol) **karşılıklı dışlayan küme**: kullanıcı effective olarak **≥2 üyeye** sahipse ihlal. Enforcement: `Block` (atama reddedilir) / `Warn` (uygulanır + ihlal kaydı). | 2'li kurallar ve N'li kümeler aynı modelle. |
| İhlaller | Sistem **asla yetki silmez**. `SodViolations` (Open/Acknowledged/AcceptedRisk/Resolved). Tarama artık geçerli olmayan açık ihlalleri `Resolved` yapar. | Doküman #7. |
| Audit | Tek tablo `AuditLogs`, `Category`: AuthorizationDecision / Management / Simulation / SodScan. Karar kaydında `Id == DecisionId`. | Basitlik; ileride ayrı store'a ayrılabilir. |
| Silme | RBAC tanımlarında hard delete yok; `IsActive=false`. Rule'lar policy kompozisyonunun parçası olduğu için silinebilir (audit + policy versiyonu artar). Pasif rule → NotApplicable. | Audit/iz kaybı olmasın. |
| Süreli atama | `UserRole.ValidUntil`, `UserPermission.ValidUntil` desteklenir (UI'da henüz girilmiyor). | |

---

### 4.1 Authorization policy modeli

```
Permission ──(M:N PermissionPolicies)── Policy ──(1:N)── Rule ──(kök)── RuleCondition (ağaç: Predicate / AllOf / AnyOf / Not)
                                          │                │                  └─ ConditionParameter (key/value)
                                          │                │                  └─ ConditionType (katalog) ──► C# IConditionHandler
                                          │                └─ Effect (Permit|Deny), Order, ReasonCode, IsActive
                                          └─ CombiningAlgorithm (DenyOverrides|PermitOverrides|FirstApplicable), Version, Domain
```

| Kavram | Soru / anlam |
|---|---|
| **Permission** | "Kullanıcı hangi işlemi yapmaya aday?" — RBAC verir (rol/grup/doğrudan). |
| **Policy** | "Bu permission hangi koşullarda Permit/Deny olur?" — rule'lar + **açıkça modellenmiş** combining algoritması. |
| **Rule** | Karar üreten birim: **Effect** + **Condition**. Condition TRUE → Effect; FALSE → NotApplicable; belirsiz → Indeterminate; pasif → NotApplicable. |
| **Condition** | Boolean ifade ağacı (üç değerli Kleene mantığı: `false AND ? = false`, `true OR ? = true`). Prototip seed'i tek predicate / NOT / AND kullanır; motor tam ağacı destekler (max derinlik 8). |
| **ConditionType** | Condition'ın NASIL değerlendirileceği (TIME_WINDOW, IP_IN_RANGE, AMOUNT_EXCEEDS_SUBJECT_LIMIT...). DB'de sadece katalog + parametre; **davranış C#'ta**. Kullanıcı yaratamaz. |
| **Attribute** | Condition'ın okuduğu değer: `Subject.*` (kullanıcı), `Context.*` (iş değerleri), `Environment.*` (zaman/IP/kanal/platform/cihaz), `Resource.*`, `Action.*`. `IAttributeValueProvider`'lar çözer. |

### 4.2 Ortak koşullar (SharedCondition)

Paylaşılan şey **karar değil tanım**dır. Rule (Effect/Order/ReasonCode) policy'ye aittir; "banka ağı nedir", "mesai nedir" gibi tanımlar **tek yerde** ortak koşul olarak tutulur ve rule'lar **Reference** düğümüyle (kopya değil) bağlanır:

```
SharedCondition BANK_NETWORK = IP_IN_RANGE(10.0.0.0/8, ...)         (Scope: Global | Domain+Domain)
Rule (CASH_WITHDRAWAL_POLICY) : Deny ⇐ NOT @BANK_NETWORK
Rule (EFT_POLICY)             : Deny ⇐ NOT @BANK_NETWORK
```

- Model: `SharedConditions` tablosu; ağaç düğümleri yine `RuleConditions`'ta — düğümün sahibi **ya** `RuleId` **ya** `SharedConditionId` (SQL check constraint); `Kind=Reference` düğümü `ReferencedSharedConditionId` taşır. Ortak koşul başka ortak koşula referans verebilir.
- `PolicyDefinitionLoader` referansları çözer (Reference düğümünün tek çocuğu = ortak koşulun kökü). **Pasif / bulunamayan / döngüsel referans → Indeterminate (fail-closed)**, eksik attribute olarak `SharedCondition.<KOD>` raporlanır.
- `SharedConditionService`: oluştur / güncelle (tanım değişir → ortak koşulun ve onu doğrudan/dolaylı kullanan **tüm policy'lerin Version'ı artar**, PolicyChanged event'i) / sil. **Kullanımdaki ortak koşul pasifleştirilemez ve silinemez** (kısıt sessizce kalkmasın). Döngüsel referans reddedilir. `UsagesAsync` = transitif "kullanıldığı yerler".
- Gösterim: `Render` → `NOT @BANK_NETWORK`; `Render(expand:true)` → `NOT @BANK_NETWORK[IP_IN_RANGE(...)]` (What-If yapısal farkında kullanılır, yoksa ortak koşul değişikliği "değişmedi" görünürdü).
- What-If: `PolicyChangeSet.SharedConditionReplacements` (tanımı değiştir) ve ortak koşul düğümlerinde `ConditionOverrides` → etkilenen policy'ler kullanım yerlerinden bulunur.
- Seed ortak koşulları: `BUSINESS_HOURS`, `EFT_HOURS`, `BANK_NETWORK`, `REMOTE_PLATFORM` (Global), `CREDIT_APPROVAL_LIMIT_EXCEEDED` (Domain: KREDI).
- Tek seferlik farklılaşma gerekiyorsa UI'daki "Mevcut rule'dan kopyala" hâlâ vardır (kopya bağımsızdır; referanslar referans olarak kopyalanır).

**Seed kalıbı:** `DenyOverrides` + kısıtlar **Deny** rule'ları + en sonda temel `PERMIT_WITHIN_CONSTRAINTS` (Permit, `ALWAYS`). Hiçbir Deny uygulanmıyor ve belirsizlik yoksa Permit.

Örnek (CASH_WITHDRAWAL_POLICY):

| # | Rule | Effect | Condition | Reason |
|---|---|---|---|---|
| 10 | DENY_OUTSIDE_BUSINESS_HOURS | Deny | `NOT @BUSINESS_HOURS` (= TIME_WINDOW 09:00-18:00, MON-FRI) | OUTSIDE_BUSINESS_HOURS |
| 20 | DENY_OUTSIDE_BANK_NETWORK | Deny | `NOT @BANK_NETWORK` (= IP_IN_RANGE ...) | OUTSIDE_BANK_NETWORK |
| 30 | DENY_NON_CASH_DESK_CHANNEL | Deny | `NOT CHANNEL_IN(CASH_DESK)` | CHANNEL_NOT_ALLOWED |
| 40 | CASH_LIMIT_EXCEEDED | Deny | `AMOUNT_EXCEEDS_SUBJECT_LIMIT` (Context.TransactionAmount > Subject.CashWithdrawalLimit) | AMOUNT_EXCEEDS_USER_LIMIT |
| 50 | DENY_USER_ON_LEAVE | Deny | `USER_ON_LEAVE` | USER_ON_LEAVE |
| 60 | DENY_OWN_CUSTOMER_TRANSACTION | Deny | `CUSTOMER_IS_SELF` | OWN_CUSTOMER_TRANSACTION |
| 1000 | PERMIT_WITHIN_CONSTRAINTS | Permit | `ALWAYS` | PERMIT |

EFT_POLICY'de AND örneği: `DENY_HIGH_AMOUNT_FROM_REMOTE_PLATFORM = (@REMOTE_PLATFORM AND AMOUNT_GREATER_THAN(50000))`.

**Limit policy'de hard-code edilmez:** 50.000 değeri `User.CashWithdrawalLimit`'ten `UserEntityAttributeProvider` ile gelir. Gerçek limit servisine geçmek = yeni `IAttributeValueProvider` (Subject.CashWithdrawalLimit'i çözen) + DI kaydı; policy/handler/engine değişmez.

---

## 5. Karar motoru (POST /api/authorization/evaluate)

**İstek (standart):**
```json
{ "subject": { "userName": "ahmet.yilmaz" }, "permission": "CASH_WITHDRAW", "action": "withdraw",
  "resource": { "type": "account", "id": "TR12..." },
  "context": { "TransactionAmount": "75000", "CustomerId": "555", "Channel": "CASH_DESK", "IpAddress": "10.1.2.3", "Platform": "BRANCH_DESKTOP" } }
```

**Akış** (`AuthorizationEvaluator` = PDP orkestratörü; gerçek karar ve What-If AYNI metot):
```
Request → Subject çözümü → [RBAC] effective permission kontrolü → Policy çözümü (PolicyDefinitionLoader)
        → [Policy engine] PolicyEvaluator: her rule'un condition'ı → rule sonucu → policy CombiningAlgorithm
        → policy'ler arası birleştirme (AuthorizationEngineOptions.PolicyCombiningAlgorithm, varsayılan DenyOverrides)
        → Decision → Audit (hassas attribute'lar IAttributeRedactor ile maskelenir)
```

**Karar durumları (`DecisionType`):** `Permit` · `Deny` · `NotApplicable` · `Indeterminate`. `IsAllowed` **yalnızca Permit**'te true (PEP deny-biased).

| Durum | Karar | ReasonCode |
|---|---|---|
| Kullanıcı yok / pasif | Deny | USER_NOT_FOUND / USER_INACTIVE |
| RBAC permission yok | Deny | PERMISSION_NOT_GRANTED (tanımsızsa PERMISSION_UNKNOWN) — policy engine'e gidilmez |
| Permission var, aktif policy yok | `AuthorizationEngineOptions.NoPolicyDecision` (varsayılan **Permit**) | PERMIT_NO_POLICY / NO_POLICY |
| Bir Deny rule'u uygulandı | Deny | Kararı veren rule'un `ReasonCode`'u (DenyOverrides: sıradaki ilk Deny) |
| Gerekli attribute eksik / handler yok / hata (ve kesin Deny yok) | Indeterminate | MISSING_ATTRIBUTE / EVALUATION_ERROR |
| Permit rule'u uygulandı, Deny/belirsizlik yok | Permit | PERMIT |
| Hiçbir rule uygulanmadı | NotApplicable (izin yok) | NO_APPLICABLE_RULE |

**Açıklanabilirlik:** `decidingPolicy`, `decidingRule`, `policies[] → {algorithm, result, rules[] → {effect, conditionValue, result, reasonCode, expression, condition(trace ağacı), missingAttributes, evidence}}`, `evidence` (kullanılan tüm attribute değerleri ve kaynağı: `Context.TransactionAmount=75000 (Request)`, `Subject.CashWithdrawalLimit=50000 (UserEntity)`), `failedRules`, `permitRules`, `missingAttributes`, `permissionSources` (RBAC yolu).

**Fail-closed:** eksik attribute, ConditionType kodda yok (`IsAvailable=false` → Indeterminate), handler exception, bozuk ağaç (NOT'un tek çocuğu yok vb.), motor exception → asla Permit değil. SDK motora erişemezse `ENGINE_UNAVAILABLE` (503).

**Zaman otoritesi motordur:** `Environment.CurrentTime` daima motor saati; çağıranın gönderdiği `CurrentTime` → `CallerTime` (sadece audit). Simülasyonda `asOfUtc` ile seçilebilir.

**Condition tipleri** (`Application/PolicyEngine/Conditions/Handlers`) — hepsi PREDICATE (TRUE/FALSE); Permit/Deny'ı rule'un Effect'i verir:

| Kod | TRUE ise | Okuduğu attribute'lar |
|---|---|---|
| ALWAYS | her zaman | — |
| TIME_WINDOW | zaman pencere içinde (Start/End/Days/TimeZone) | Environment.CurrentTime |
| IP_IN_RANGE | IP verilen CIDR'larda | Environment.IpAddress |
| CHANNEL_IN / PLATFORM_IN | kanal/platform listede | Environment.Channel / Environment.Platform |
| AMOUNT_EXCEEDS_SUBJECT_LIMIT | tutar > kullanıcı limiti | Context.TransactionAmount, Subject.CashWithdrawalLimit |
| AMOUNT_GREATER_THAN | tutar > sabit eşik (Threshold) | Context.TransactionAmount |
| BRANCH_IS_USER_UNIT | işlem şubesi kullanıcının birimi | Context.BranchCode, Subject.OrgUnitCodes |
| USER_ON_LEAVE | kullanıcı izinde | Subject.IsOnLeave |
| CUSTOMER_IS_SELF | müşteri = personelin kendisi | Context.CustomerId, Subject.CustomerId |

**Yeni condition tipi:** `ConditionHandlerBase`'ten türet → `Descriptor` (kod, TRUE anlamı, parametreler, okunan attribute'lar) → `EvaluateAsync` (attribute'ları `ctx.Attributes` üzerinden oku; eksikse `ConditionResult.Missing`) → `Application/DependencyInjection.cs`'e `AddSingleton<IConditionHandler, X>()`. Katalog açılışta güncellenir; UI parametre formunu şemadan üretir.

**Yeni combining algoritması:** `ICombiningAlgorithm` implement + enum değeri + DI kaydı.

---

## 6. Effective permission hesaplama

`AuthorizationGraphLoader` (kullanıcı başına sabit sayıda set-based sorgu, N+1 yok) → **change set uygulanır** (bellekte) → `EffectivePermissionCalculator.Calculate` (**saf fonksiyon**, I/O yok) → `EffectivePermissionSet`.

Kaynak tipleri (`PermissionSourceType`): `DirectRole`, `GroupGrantedRole`, `GroupPermission`, `DirectUser`. Her kaynakta okunur `Path` var (ör. `Grup 'VADELI_KAMPANYA_EKIBI' [kitle: rol GISEYTK, kitle: birim 101] → doğrudan permission`). Grup üyelik nedenleri de (`User/Role/OrgUnit`) döner.

`RequiresRuntimeEvaluation = true` → permission'a aktif policy bağlı; login-time statik set ile **yetinilemez**, işlem anında evaluate şart.

**Cache / versiyon:** `IAuthorizationVersion` (global sayaç). `YetkiDbContext.SaveChangesAsync`, audit/outbox/provisioning/violation/external dışındaki herhangi bir değişiklikte versiyonu artırır. Cache anahtarı `eff:{userId}:{version}` (15 dk). Change set ile yapılan hesaplamalar cache'lenmez. **Context-dependent kararlar asla cache'lenmez.**

Login-time uç: `GET /api/authorization/users/{userName}/permissions` → `{version, permissions:[{code, requiresRuntimeEvaluation}]}`.

---

## 7. Değişiklik (atama) akışı ve What-If

Tüm atamalar `AssignmentService` → `AuthorizationChangeService.ApplyAsync(ChangeCommand)`:

1. `AuthorizationChangeSet` oluştur (kullanıcı rol/permission/birim, rol-permission, grup kitle/grant değişiklikleri).
2. **Etkilenen kullanıcıları** bul (rol değişikliği → rolü doğrudan veya grup üzerinden taşıyanlar; grup değişikliği → kitle).
3. Her kullanıcı için **önce/sonra** effective (aynı hesaplayıcı) → diff, **yeni** SoD çakışmaları (önceden var olan çakışma yeni sayılmaz), dış sistem gereksinimleri (external mapping).
4. `Block` çakışma varsa → `ConflictException` (HTTP 409, `details` = etki analizi). Hiçbir şey kaydedilmez.
5. Entity değişiklikleri + `Warn` ihlal kayıtları + outbox event'leri (birincil event + kullanıcı başına `EffectivePermissionsChanged`) + audit → **tek `SaveChanges`**.

**What-If** (`/api/simulation/*`) 1–3'ü `AnalyzeAsync(dryRun:true)` ile aynen kullanır. UI'daki her atama modalı önce bu önizlemeyi gösterir, sonra uygular.

Simülasyon uçları:
- `POST /api/simulation/changes` — **RBAC değişikliği etkisi** (body: `AuthorizationChangeSet`: kullanıcı rol/permission/birim, rol↔permission, grup kitle/grant ekle/çıkar).
  Her kullanıcı için: `addedPermissions` (kazanır), `removedPermissions` (kaybeder), **`retainedPermissions`** (kaynağı değişir ama başka rol/gruptan geldiği için KORUNUR, önce/sonra yollarıyla), rol/grup değişimi, yeni SoD, RACF/LDAP grant/revoke.
  `evaluatedUserCount` = kapsamdaki (önce/sonra hesaplanan) kullanıcı; `affectedUserCount` = yetkisi gerçekten değişen kullanıcı.
- `POST /api/simulation/policy-impact` — **Policy/Rule değişikliği etkisi** (`PolicyImpactService`). Body:
  `{ changes: PolicyChangeSet, scenarios: [{name, context}], asOfUtc?, includeUnchanged?, maxEvaluations? }`
  - `PolicyChangeSet`: `permissionPolicyChanges` (bağla/ayır), `policyActivations`, `policyAlgorithmChanges`, `ruleOverrides` (aktiflik/effect/sıra), `conditionOverrides` (predicate parametreleri, ör. mesai bitişi — ortak koşul düğümündeyse tüm kullananlar etkilenir), `addedRules` (taslak rule + condition ağacı), `removedRuleIds`, `replacedRules` (rule düzenleme önizlemesi), `sharedConditionReplacements` (ortak koşul tanımını değiştir).
  - `PolicyDefinitionLoader` değişikliği bellekte uygular; `AuthorizationEvaluator` `EvaluationOptions.PolicyChanges` ile AYNI kodla karar verir.
  - Çıktı: permission başına **yapısal fark** (policy/rule önce→sonra, eklenen/çıkan/değişen rule + condition ifadesi önce/sonra, **yeni gerekli attribute** — ör. `Context.BranchCode`, `becomesUnconditional`), **etkilenen kullanıcılar**, **senaryolu karar karşılaştırması** (`NEWLY_DENIED`, `NEWLY_INDETERMINATE`, `NEWLY_ALLOWED`, `REASON_CHANGED`).
  - Senaryo değeri `@userBranch` → her kullanıcının kendi birim kodu.
- `POST /api/simulation/evaluate` — `{request, changes?, policyChanges?, asOfUtc?}` ile tek karar
- `POST /api/simulation/sod-rule` — kaydedilmemiş SoD kuralı mevcutta kaç ihlal üretir

Not: Policy değişiklikleri effective permission'ı değiştirmez (kim hangi yetkiye SAHİP aynı kalır); değişen şey işlem anındaki KARARDIR. Bu yüzden policy etkisi "sahiplik diff'i" değil "karar diff'i" + yapısal diff olarak raporlanır.

---

## 8. Event / Provisioning

- **Transactional outbox:** `OutboxEvents` tablosuna değişiklikle aynı SaveChanges'te yazılır.
- `OutboxProcessor` (BackgroundService, 2 sn polling, batch 50, max 5 deneme) → `IOutboxEventHandler`'lar:
  - `LoggingEventHandler` (tüm event'leri loglar)
  - `ProvisioningEventHandler` (`EffectivePermissionsChanged` → permission'ın external mapping'leri → `ProvisioningActions` → `IProvisioningAdapter`)
- `DummyProvisioningAdapter` (SystemCode `*`): gerçek çağrı yapmaz, komut metni üretir (ör. `PERMIT VADA-B0 CLASS(TCICSTRN) ID(GIZEM.TAS) ACCESS(READ)`).
- Event tipleri: RoleAssigned, RoleRevoked, PermissionAssigned, PermissionRevoked, GroupMembershipChanged, GroupGrantChanged, OrgUnitAssignmentChanged, PolicyChanged, RuleChanged, SoDRuleCreated, SoDRuleChanged, (türetilmiş) EffectivePermissionsChanged.
- **Authorization core RACF/LDAP detayını bilmez.** Gerçek adaptör = yeni `IProvisioningAdapter` (SystemCode = "RACF") + DI kaydı.
- Manuel tetik: `POST /api/events/outbox/process`.

---

## 9. SDK (Yetki.Sdk) kullanımı

```csharp
builder.Services.AddYetkiAuthorization(o =>
{
    o.EngineBaseUrl = "http://localhost:5100";
    o.ApplicationCode = "GISE";
    // o.AllowUserHeaderForDemo = true;  // SADECE prototip
});

public sealed class NakitCekimTalebi
{
    [AuthContext(AuthContextType.CustomerId)]        public string MusteriNo { get; set; }
    [AuthContext(AuthContextType.TransactionAmount)] public decimal Tutar { get; set; }
}

[HttpPost("withdraw")]
[RequiresPermission("CASH_WITHDRAW", Action = "withdraw")]
public IActionResult Withdraw([FromBody] NakitCekimTalebi talep) => Ok(...);   // iş kodunda yetki if'i YOK
```

- Global `YetkiAuthorizationFilter`: model binding'den **sonra**, iş kodundan **önce** çalışır; `IsAllowed=false` (Deny/NotApplicable/Indeterminate) → 403, action çalışmaz.
- **Environment otomatik** (iş ekibinden istenmez): kullanıcı (`HttpContext.User`; prototipte `X-User`), IP, zaman, kanal (`X-Channel`), platform (`X-Platform`), cihaz (`X-Device-Id`, `X-Device-Compliant`) — gateway header'ları.
- **İş context'i:** DTO property / action parametresinde `[AuthContext(AuthContextType.X)]` (TransactionAmount, Currency, CustomerId, AccountNo, BranchCode) veya domain'e özel `[AuthContext("CreditScore")]`. **Property adına bakılmaz.** İç içe DTO (derinlik 3), koleksiyonlar taranmaz; çakışan değerler → `AMBIGUOUS_CONTEXT` (deny).
- `[RequiresPermission(..., ResourceType = "account")]` + `[AuthContext(AccountNo)]` → istekte `resource {type,id}`.
- 403 ProblemDetails: `decision`, `reasonCode`, `decidingPolicy`, `decidingRule`, `failedRules`, `missingAttributes`, `decisionId`.
- `[RequirePermission]` (eski isim) `[Obsolete]` alias olarak çalışmaya devam eder.

---

## 10. API uçları (özet)

| Alan | Uçlar |
|---|---|
| Authorization | `POST /api/authorization/evaluate`, `GET /api/authorization/users/{u}/permissions`, `GET /api/authorization/users/{u}/explain/{perm}`, `GET /api/authorization/context-keys` |
| Users | `GET/POST /api/users`, `GET/PUT /api/users/{id}`, `GET …/{id}/effective`, `GET …/violations`, `GET …/provisioning`, `POST/DELETE …/roles`, `POST/DELETE …/permissions`, `POST/DELETE …/org-units` |
| Roles | `GET/POST /api/roles`, `GET/PUT /api/roles/{id}`, `POST/DELETE /api/roles/{id}/permissions` |
| Permissions | `GET/POST /api/permissions`, `GET/PUT …/{id}`, `GET …/{id}/holders`, `POST/DELETE …/{id}/policies`, `POST/DELETE …/{id}/external-mappings` |
| Groups | `GET/POST /api/groups`, `GET/PUT …/{id}`, `POST …/{id}/items {kind,targetId}`, `DELETE …/{id}/items/{kind}/{targetId}` |
| Policies / Rules | `GET/POST /api/policies`, `GET/PUT /api/policies/{id}` (policy + rule'lar + condition ağaçları), `POST /api/policies/{id}/rules` (Effect + Condition), `PUT/DELETE /api/rules/{id}`, `GET /api/rules` (tümü, salt okunur), `GET /api/condition-types` |
| SoD | `GET/POST /api/sod/rules`, `PUT /api/sod/rules/{id}`, `GET /api/sod/violations?status=`, `PUT /api/sod/violations/{id}`, `POST /api/sod/scan` |
| Shared conditions | `GET/POST /api/shared-conditions`, `GET/PUT/DELETE /api/shared-conditions/{id}`, `GET /api/shared-conditions/{id}/usages` |
| Simulation | `POST /api/simulation/changes | evaluate | policy-impact | sod-rule` |
| External | `GET/POST /api/external/systems`, `POST /api/external/systems/{id}/permissions` |
| Events / Audit / Diğer | `GET /api/events/outbox`, `GET /api/events/provisioning`, `POST /api/events/outbox/process`, `GET /api/audit`, `GET /api/audit/{id}`, `GET /api/dashboard`, `GET /api/org-units` |

Yönetim uçları `X-Actor` header'ını "kim yaptı" olarak kullanır (bkz. Dikkat).

---

## 11. Seed verisi ve demo senaryoları

**Organizasyon (5 birim):**

| Kod | Birim | Tip |
|---|---|---|
| 101 | Kadıköy Şubesi | Şube |
| 737 | Ankara Kızılay Şubesi | Şube |
| 1114 | İzmir Alsancak Şubesi | Şube |
| 928 | Genel Müdürlük / Krediler | GM birimi |
| 850 | Genel Müdürlük / Operasyon ve Yetki Yönetimi | GM birimi |

(Şube adları ve 928/850 birim isimleri varsayımdır; kodlar kullanıcı talebinden.)

**Roller:**
- **Şube rolleri — tüm şubelerde ORTAK** (şubeye özel rol kopyası yok; şube bilgisi kullanıcının biriminden gelir, BRANCH_IS_USER_UNIT gibi condition'lar bunu kullanır):

| Rol | Ad | Permission'lar |
|---|---|---|
| GISEAST | Gişe Asistanı | CUSTOMER_VIEW, CASH_DEPOSIT |
| GISEYTK | Gişe Yetkilisi | CUSTOMER_VIEW, CASH_WITHDRAW, CASH_DEPOSIT, CASH_DESK_OPEN |
| BRYSLAST | Bireysel Asistan | CUSTOMER_VIEW, TERM_DEPOSIT_VIEW, TERM_DEPOSIT_OPEN, VADA_MENU |
| BRYSLYTK | Bireysel Yetkili | CUSTOMER_VIEW, CUSTOMER_UPDATE, TERM_DEPOSIT_VIEW/OPEN/UPDATE/CLOSE, VADA_MENU, EFT_SEND |
| TICRIAST | Ticari Asistan | CUSTOMER_VIEW, CREDIT_VIEW, CREDIT_CREATE |
| TICRIYTK | Ticari Yetkili | CUSTOMER_VIEW, CUSTOMER_UPDATE, CREDIT_VIEW, CREDIT_CREATE, EFT_SEND |
| SUBEMDR | Şube Müdürü | CUSTOMER_VIEW, CUSTOMER_UPDATE, TERM_DEPOSIT_VIEW, TERM_DEPOSIT_CLOSE, CASH_WITHDRAW, REPORT_BRANCH_VIEW, CREDIT_VIEW, CREDIT_APPROVE |

- **Genel müdürlük rolleri — birim başına** `GM{BİRİM}UZMYR` (Uzman Yardımcısı) / `GM{BİRİM}UZM` (Uzman) / `GM{BİRİM}UZYTK` (Uzman Yetkili):

| Rol | Permission'lar |
|---|---|
| GM928UZMYR | CUSTOMER_VIEW, CREDIT_VIEW |
| GM928UZM | CUSTOMER_VIEW, CREDIT_VIEW, CREDIT_CREATE, CREDIT_LIMIT_UPDATE |
| GM928UZYTK | CUSTOMER_VIEW, CREDIT_VIEW, CREDIT_APPROVE, CREDIT_LIMIT_UPDATE |
| GM850UZMYR | CUSTOMER_VIEW, REPORT_BRANCH_VIEW |
| GM850UZM | CUSTOMER_VIEW, EFT_SEND, AUTH_ADMIN |
| GM850UZYTK | CUSTOMER_VIEW, EFT_SEND, AUTH_APPROVE |

**Kullanıcılar (küçük harf):**

| Birim | Kullanıcılar |
|---|---|
| 101 | `fatma.aksoy` SUBEMDR (limit 300.000) · `ahmet.yilmaz` GISEYTK (limit 50.000, müşteri no 10001) · `deniz.yildiz` GISEYTK + **legacy doğrudan EFT_SEND** (Warn SoD) · `ayse.demir` BRYSLAST · `hakan.celik` TICRIYTK · `gizem.tas` rolsüz stajyer |
| 737 | `can.ozturk` SUBEMDR (limit 250.000, kampanya grubunda doğrudan üye) · `elif.sahin` GISEYTK **izinde** · `seda.kurt` GISEAST · `burak.arslan` BRYSLYTK + **SUBEMDR_VEKALET** grubu üzerinden SUBEMDR |
| 1114 | `ali.yurt` SUBEMDR · `mehmet.kaya` TICRIAST · `okan.demir` BRYSLYTK · `murat.polat` GISEAST **pasif** |
| 928 | `cem.bulut` GM928UZMYR · `zeynep.celik` GM928UZYTK · `emre.koc` GM928UZM + GM928UZYTK (**legacy SoD ihlali**) |
| 850 | `ece.tan` GM850UZMYR · `selin.aydin` GM850UZM (AUTH_ADMIN) · `baris.oz` GM850UZYTK (AUTH_APPROVE) |

**Gruplar:** `TUM_PERSONEL` (5 birim → ANNOUNCEMENT_VIEW), `VADELI_KAMPANYA_EKIBI` (kitle: GISEYTK rolü + 101 birimi + can.ozturk → TERM_DEPOSIT_VIEW), `SUBE_101_RAPOR` (101 → REPORT_BRANCH_VIEW), `SUBEMDR_VEKALET` (burak.arslan → **SUBEMDR rolü** verir).

Sentetik kullanıcılar (`Seed:SyntheticUserCount`) 3 şubeye ve şube rollerine (SUBEMDR hariç) rastgele dağıtılır.

| Senaryo | Nasıl |
|---|---|
| Doküman başarı hikâyesi 1-4 | Permission oluştur → role ekle → kullanıcıya rol ata → effective (UI: Kullanıcı detay) |
| Allow / limit aşımı / kendi hesabı / izinli / eksik context | `ahmet.yilmaz` CASH_WITHDRAW (UI: Yetki Testi hazır butonları; mesai dışında "Simülasyon" modu kullan) |
| SoD Block | `mehmet.kaya`'ya (TICRIAST: CREDIT_CREATE) `SUBEMDR` (CREDIT_APPROVE) ata → 409 |
| SoD Warn | `ahmet.yilmaz`'a (GISEYTK: CASH_DESK_OPEN) `BRYSLYTK` (EFT_SEND) ata → uygulanır + ihlal kaydı + LDAP & RACF provisioning |
| RACF provisioning | `gizem.tas`'a `BRYSLAST` → VADA_MENU → RACF VADA-B0 & VADA-X aksiyonları |
| Retrospektif tarama | `POST /api/sod/scan` → emre.koc (kredi oluştur/onay), deniz.yildiz (vezne/EFT) bulunur |
| Grup üzerinden rol | `burak.arslan` → `SUBEMDR_VEKALET` grubu → `SUBEMDR` rolü → CREDIT_APPROVE, CASH_WITHDRAW… |
| Rolden yetki çıkarma etkisi | What-If → Rol → `GISEYTK`'dan CASH_WITHDRAW çıkar → ahmet/deniz/elif kaybeder, burak/SUBEMDR'ler etkilenmez |
| Doküman grup örneği | `VADELI_KAMPANYA_EKIBI` = tüm gişe yetkilileri + 101 şube + can.ozturk |

---

## 12. SQL Server'a geçiş

1. `Yetki.Infrastructure`'a `Microsoft.EntityFrameworkCore.SqlServer` (9.0.x) ekle.
2. `Infrastructure/DependencyInjection.cs` içindeki yorumlu `"SqlServer"` dalını aç; `Persistence:Provider=SqlServer`, `ConnectionStrings:Yetki` ayarla.
3. `dotnet ef migrations add Initial -p src/Yetki.Infrastructure -s src/Yetki.Api` (tools paketi + design-time factory gerekebilir).
4. `InitializeYetkiDatabaseAsync` içinde `EnsureCreatedAsync` yerine `MigrateAsync` kullan. Seed'i sadece boş DB'de / dev ortamında çalıştır.
5. `SyntheticUserCount` ile login storm testi; index planlarını kontrol et.

Model zaten SQL'e hazır: composite PK'lar, unique index'ler (Code/UserName, `Rules(PolicyId,Code)`, `ConditionParameters(ConditionId,Key)`), ters yön index'leri, string enum dönüşümleri (Effect, CombiningAlgorithm, ConditionKind...), max length'ler, decimal(18,2).
Policy engine'e özel notlar:
- `RuleConditions` sahiplik check constraint'i (RuleId XOR SharedConditionId); `SharedConditionId` ve `ReferencedSharedConditionId` FK'ları **Restrict** (servis siler, kullanımdaki silinemez).
- `RuleConditions.ParentId` self-FK **Restrict** (SQL Server çoklu cascade yolunu kabul etmez); rule silme/güncellemede condition düğümleri servis tarafından (`PolicyManagementService.RemoveConditionsAsync`) silinir.
- `Policy.Version` concurrency token → SQL Server'da eşzamanlı policy düzenlemede `DbUpdateConcurrencyException` (UI'da "yeniden yükle" akışı eklenmeli).
- Condition ağacı ilişkisel (JSON blob yok); raporlama/sorgulama SQL ile doğrudan yapılabilir.
- Business logic ve policy engine değişmez: sadece provider + migration + DI.

---

## 13. DİKKAT EDİLMESİ GEREKENLER

- **Türkçe kültür tuzağı:** `"i".ToUpper()` → `"İ"`. Kodlar her zaman `ToUpperInvariant` (`Codes.Normalize`), kullanıcı adları `ToLowerInvariant`. `Program.cs`'te default culture **Invariant** yapıldı; sayılar context'te invariant string taşınır (ondalık ayırıcı nokta).
- **InMemory provider** unique index'leri, FK'ları ve transaction'ları **uygulamaz**. Kod tekrar kontrolleri servislerde elle yapılıyor — SQL'e geçince DB de garanti eder. Transaction uyarısı bilerek yok sayılıyor.
- **Veri kalıcı değil:** restart = seed'e dönüş.
- **Güvenlik (prototip):** Engine API'de **kimlik doğrulama yok**; `X-Actor` (yönetim) ve SDK'daki `X-User`, `X-Channel` header'ları güvenilir DEĞİL. Üretimde: OIDC/AD, gateway'in header'ları ezmesi, yönetim uçlarının kendisinin de yetkilendirilmesi (AUTH_ADMIN / AUTH_APPROVE).
- **Tek instance varsayımı:** `InProcessAuthorizationVersion` ve `IMemoryCache` süreç içi. Çok instance'ta versiyon/cache dağıtık olmalı (Redis/DB), yoksa bir node'daki değişiklik diğerinin cache'ini geçersiz kılmaz.
- **Mesai rule'u yerel saate bağlı:** Mesai dışında (ve hafta sonu) policy'li kararlar DENY döner — hata değil. Demo için simülasyon (`asOfUtc`) kullanın.
- **Rol/grup seviyesindeki değişiklikler senkron fan-out** yapar (etkilenen tüm kullanıcılar için önce/sonra hesap). Prototip hacminde sorun değil; 20K+ kullanıcıda asenkron job'a taşınmalı (TODO).
- SoD "yeni çakışma" hesabı **kural bazında**: kullanıcı zaten o kuralı ihlal ediyorsa ek atama yeni ihlal sayılmaz (engellenmez).
- Pasif rule → NotApplicable (hiç yokmuş gibi). Kodu kaldırılmış ConditionType → Indeterminate (izin yok). Bu fark bilinçli.
- **Temel Permit rule'u unutulursa** policy tüm Deny'lar uygulanmadığında `NotApplicable` döner → izin YOK. Yeni policy'lerde "PERMIT_WITHIN_CONSTRAINTS (ALWAYS)" kalıbını kullanın veya bilinçli olarak Permit rule'ları yazın.
- DenyOverrides'ta kesin Deny, belirsizlikten önce gelir (mesai dışı + tutar eksik → Deny/OUTSIDE_BUSINESS_HOURS). Belirsizlik ise Permit'i her zaman bloklar (XACML'in Indeterminate{D,P} ayrımı bilinçli olarak sadeleştirildi).
- Context anahtarları değişti: `CustomerNo` → **`CustomerId`**, `RequestTime` → **`CurrentTime`** (motor üretir). Nakit çekim artık **IpAddress** de ister (banka ağı rule'u); SDK bunu otomatik doldurur, test ekranında girilmeli.
- PowerShell 5.1 `Invoke-RestMethod` Türkçe karakterli JSON gövdesini bozuyor (400); curl veya UTF-8 byte gövde kullanın.
- Grup kitlesi sadece **doğrudan** rollerle eşleşir (nested yok). Kullanıcıya grup üzerinden gelen rol başka grubun kitlesine sokmaz.
- `ProvisioningEventHandler` at-least-once; aynı event iki kez işlenirse aksiyonlar tekrar oluşur (idempotency TODO).
- `ChangeImpactResult.AffectedUserCount` sadece **effective'i gerçekten değişen** kullanıcıları sayar.
- Makinede bellek darlığında `dotnet run` "Out of memory" verebiliyor; o durumda derlenmiş exe'yi doğrudan çalıştırmak işe yaradı (`src/Yetki.Api/bin/Debug/net9.0/Yetki.Api.exe --urls http://localhost:5100`).
- 5173 portu bu makinede başka bir projede kullanılıyor → Web 5180'e alındı. Port değişirse API ve Sample CORS listelerini güncelle.

---

## 14. TODO (öncelik sırasıyla)

**Güvenlik / üretime hazırlık**
- [ ] Engine API authentication (OIDC/AD) + yönetim uçlarının yetkilendirilmesi (dogfooding: kendi motoruyla, AUTH_ADMIN)
- [ ] Servisler arası güven: SDK → Engine çağrısında mTLS / client credentials
- [ ] Gateway header güveni (X-Channel vb.) için imzalı/claim tabanlı çözüm
- [ ] Yönetim değişiklikleri için 4-göz onay akışı (AUTH_APPROVE; SoD zaten ayırıyor)

**Persistence / ölçek**
- [ ] SQL Server provider + migration'lar (bkz. §12)
- [ ] Dağıtık versiyon + cache (Redis) ; policy tanımları için versiyonlu cache (`PolicyDefinitionLoader`)
- [ ] Login storm testi (20–21K kullanıcı / 10 dk): k6/NBomber senaryosu, `SyntheticUserCount` ile
- [ ] Rol/grup fan-out'unu asenkron job'a taşı (senkron sadece set-based SoD Block kontrolü)
- [ ] SoD retrospektif taramayı set-based SQL veya batch/paralel yap; arka plan job + zamanlama
- [ ] Karar audit'ini asenkron/batch yaz (Channel) veya ayrı audit store; saklama politikası
- [ ] Liste uçlarında sunucu tarafı sayfalama (roller/permission'lar/audit)

**Policy engine**
- [ ] Policy set / hedefleme (target): policy'nin hangi action/resource için uygulanacağını ifade etme (şu an permission'a bağlanarak)
- [ ] Obligation/advice (ör. "Permit ama 4-göz onayı gerekir", "müşteriye bilgilendirme SMS'i")
- [ ] Policy tanımları için versiyonlu cache + policy geçmişi (eski versiyonları saklama, kararın hangi versiyonla verildiğini geri oynatma)
- [x] Ortak koşullar (SharedCondition + Reference düğümü) — §4.2
- [ ] Ortak koşul değişikliği için onay akışı (4-göz) ve versiyon geçmişi (eski tanımı saklama)
- [ ] Composite `IAttributeValueProvider`: HR / limit yönetimi / core banking; attribute bazlı cache ve timeout (fail-closed)
- [ ] `IAttributeRedactor` için konfigürasyon (appsettings'ten hassas attribute listesi)
- [ ] UI: Permit-overrides / First-applicable ile örnek policy; condition ağaç editöründe sürükle-bırak

**What-If**
- [ ] Policy impact'te senaryo yerine gerçek geçmiş kararların (audit'teki context'ler) yeniden oynatılması ("replay") — en gerçekçi etki
- [ ] Birden çok değişikliği tek "değişiklik paketi" olarak kaydedip onaya gönderme + toplu uygulama (şu an What-If sadece önizleme; detay ekranlarında tekil değişiklik önizle→uygula)
- [ ] Policy impact için holder × senaryo sayısı büyüdüğünde örnekleme / asenkron job

**Fonksiyonel**
- [ ] Policy içinde kontrollü AND/OR rule grupları (model engel değil; `PolicyCombining` genişletilecek)
- [ ] Resource-based rule'lar (resource tipi/sahibi)
- [ ] Gerçek `IAttributeValueProvider`'lar (HR, limit yönetimi, core banking) — `User.CashWithdrawalLimit`/`CustomerNo` prototip alanlarını kaldır
- [ ] Süreli atama (`ValidUntil`) için UI + süresi dolan atamalar için event
- [ ] ProvisioningAction idempotency key + retry/kompanzasyon; gerçek RACF adaptörü (EGL/CICS/FTP)
- [ ] Provisioning için "desired state" reconciliation (diff yerine)
- [ ] Soft advisory genişletme: rol benzerliği (%90 permission örtüşmesi), duplicate grup/permission analizi (şu an sadece basit isim/kod benzerliği)
- [ ] Periyodik yetki gözden geçirme (access review) kampanyaları
- [ ] AI/MCP hook'ları: salt-okuma sorgu uçları ("neden yetkili?", "policy değişirse kim etkilenir?") zaten var; MCP server sarmalayıcı eklenebilir. **AI asla karar yolunda olmayacak.**
- [ ] Mevcut sistemden toplu import (legacy grup/yetki → Role/Group/UserPermission) + migration raporu

**SDK**
- [ ] Login-time statik permission cache'i (policy'siz permission'lar için motor çağrısını azaltma; versiyon kontrolü ile)
- [ ] Minimal API desteği (endpoint filter), gRPC/queue tüketicileri için API
- [ ] Circuit breaker / retry politikası (fail-closed korunarak)
- [ ] NuGet paketi olarak yayınlama; `AuthContextKey` sözleşmesini paylaşılan küçük bir contracts paketine alma

**Test**
- [ ] API entegrasyon testleri (WebApplicationFactory), SDK filter testleri, handler birim testleri (IP/kanal/şube)
