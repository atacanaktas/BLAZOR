using System.Globalization;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Abstractions;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine;
using Yetki.Application.Simulation;
using Yetki.Domain.Common;

namespace Yetki.Tests;

/// <summary>
/// Uçtan uca yetkilendirme senaryoları (gerçek DI grafiği + seed verisi + InMemory).
/// Seed: CASH_WITHDRAWAL_POLICY (DenyOverrides) = mesai dışı / banka ağı dışı / vezne dışı kanal / limit aşımı / izinde / kendi hesabı → Deny,
///       en sonda PERMIT_WITHIN_CONSTRAINTS (ALWAYS) → Permit.  ahmet.yilmaz: GISEYTK, limit 50.000, müşteri no 10001.
/// FakeClock varsayılanı: Salı 11:00 İstanbul (mesai içi).
/// </summary>
public class AuthorizationScenarioTests
{
    private static AuthorizationRequest Cash(string user, decimal amount, string ip = "10.1.2.3", string channel = "CASH_DESK", string customer = "999") => new()
    {
        Subject = new SubjectInfo { UserName = user },
        Permission = "CASH_WITHDRAW",
        Action = "withdraw",
        Context = new()
        {
            ["TransactionAmount"] = amount.ToString(CultureInfo.InvariantCulture),
            ["IpAddress"] = ip,
            ["Channel"] = channel,
            ["CustomerId"] = customer
        }
    };

    private static async Task<AuthorizationDecision> Evaluate(TestHost host, AuthorizationRequest r, EvaluationOptions? o = null)
    {
        await using var scope = host.Scope();
        return await scope.ServiceProvider.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(r, o);
    }

    // 1) Permission yok → Deny
    [Fact]
    public async Task S01_no_permission_is_deny()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await Evaluate(host, Cash("mehmet.kaya", 100));
        Assert.Equal(DecisionType.Deny, d.Decision);
        Assert.Equal("PERMISSION_NOT_GRANTED", d.ReasonCode);
        Assert.Empty(d.Policies); // RBAC reddetti, policy engine'e hiç gidilmedi
    }

    // 2) Permission var + bütün rule'lar uygun → Permit
    [Fact]
    public async Task S02_all_rules_satisfied_is_permit()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await Evaluate(host, Cash("ahmet.yilmaz", 20_000));

        Assert.Equal(DecisionType.Permit, d.Decision);
        Assert.True(d.IsAllowed);
        Assert.Equal("CASH_WITHDRAWAL_POLICY", d.DecidingPolicy);
        Assert.Equal("PERMIT_WITHIN_CONSTRAINTS", d.DecidingRule);
        Assert.NotEmpty(d.PermissionSources);
        var policy = Assert.Single(d.Policies);
        Assert.Equal(CombiningAlgorithm.DenyOverrides, policy.Algorithm);
        Assert.All(policy.Rules.Where(r => r.Effect == RuleEffect.Deny), r => Assert.Equal(DecisionType.NotApplicable, r.Result));
    }

    // 3) Transaction limit aşılmış → Deny (limit policy'de değil, subject attribute'undan)
    [Fact]
    public async Task S03_transaction_limit_exceeded_is_deny_with_evidence()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await Evaluate(host, Cash("ahmet.yilmaz", 75_000));

        Assert.Equal(DecisionType.Deny, d.Decision);
        Assert.Equal("AMOUNT_EXCEEDS_USER_LIMIT", d.ReasonCode);
        Assert.Equal("CASH_LIMIT_EXCEEDED", d.DecidingRule);
        Assert.Contains(d.Evidence, e => e.Attribute == "Context.TransactionAmount" && e.Value == "75000" && e.Source == "Request");
        Assert.Contains(d.Evidence, e => e.Attribute == "Subject.CashWithdrawalLimit" && decimal.Parse(e.Value!, CultureInfo.InvariantCulture) == 50_000m && e.Source == "UserEntity");
    }

    // 4) Mesai dışı → Deny (motor saati otoritedir; çağıranın gönderdiği zaman yok sayılır)
    [Fact]
    public async Task S04_outside_business_hours_is_deny()
    {
        await using var host = await TestHost.CreateAsync();
        host.Clock.UtcNow = new DateTime(2026, 9, 22, 19, 0, 0, DateTimeKind.Utc); // 22:00 İstanbul
        var r = Cash("ahmet.yilmaz", 1_000);
        r.Context["CurrentTime"] = "2026-09-22T08:00:00Z";
        var d = await Evaluate(host, r);

        Assert.Equal(DecisionType.Deny, d.Decision);
        Assert.Equal("OUTSIDE_BUSINESS_HOURS", d.ReasonCode);
        Assert.Equal("DENY_OUTSIDE_BUSINESS_HOURS", d.DecidingRule);
        Assert.Equal("2026-09-22T08:00:00Z", d.Context["CallerTime"]);
    }

    // 5) IP uygun değil → Deny
    [Fact]
    public async Task S05_ip_outside_bank_network_is_deny()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await Evaluate(host, Cash("ahmet.yilmaz", 1_000, ip: "85.100.1.1"));
        Assert.Equal(DecisionType.Deny, d.Decision);
        Assert.Equal("OUTSIDE_BANK_NETWORK", d.ReasonCode);
    }

    // 6) (entegrasyon) Birden çok Deny + Permit rule'u → DenyOverrides: Deny kazanır, ilk Deny karar verir
    [Fact]
    public async Task S06_deny_overrides_in_real_policy()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await Evaluate(host, Cash("ahmet.yilmaz", 75_000, channel: "INTERNET"));

        var policy = Assert.Single(d.Policies);
        Assert.Equal(DecisionType.Permit, policy.Rules.Single(r => r.Code == "PERMIT_WITHIN_CONSTRAINTS").Result);
        Assert.Equal(2, policy.Rules.Count(r => r.Result == DecisionType.Deny));
        Assert.Equal(DecisionType.Deny, d.Decision);
        Assert.Equal("DENY_NON_CASH_DESK_CHANNEL", d.DecidingRule); // Order 30 < 40
    }

    // 7) Gerekli context eksik → Indeterminate (izin yok)
    [Fact]
    public async Task S07_missing_context_is_indeterminate_and_not_allowed()
    {
        await using var host = await TestHost.CreateAsync();
        var r = Cash("ahmet.yilmaz", 1_000);
        r.Context.Remove("TransactionAmount");
        var d = await Evaluate(host, r);

        Assert.Equal(DecisionType.Indeterminate, d.Decision);
        Assert.False(d.IsAllowed);
        Assert.Equal("MISSING_ATTRIBUTE", d.ReasonCode);
        Assert.Contains("Context.TransactionAmount", d.MissingAttributes);
    }

    [Fact]
    public async Task S07b_missing_context_does_not_hide_a_definite_deny()
    {
        await using var host = await TestHost.CreateAsync();
        var r = Cash("ahmet.yilmaz", 1_000, ip: "85.100.1.1");
        r.Context.Remove("TransactionAmount");
        var d = await Evaluate(host, r);
        Assert.Equal(DecisionType.Deny, d.Decision); // DenyOverrides: kesin Deny, belirsizlikten önce gelir
    }

    // 8) Policy bulunmuyorsa tanımlı varsayılan davranış
    [Fact]
    public async Task S08_no_policy_uses_configured_default()
    {
        await using (var host = await TestHost.CreateAsync())
        {
            var d = await Evaluate(host, new AuthorizationRequest { Subject = new SubjectInfo { UserName = "ayse.demir" }, Permission = "TERM_DEPOSIT_VIEW" });
            Assert.Equal(DecisionType.Permit, d.Decision); // varsayılan: policy'siz permission = statik yetki
            Assert.Equal("PERMIT_NO_POLICY", d.ReasonCode);
        }

        await using (var host = await TestHost.CreateAsync(s => s.Configure<AuthorizationEngineOptions>(o => o.NoPolicyDecision = DecisionType.Deny)))
        {
            var d = await Evaluate(host, new AuthorizationRequest { Subject = new SubjectInfo { UserName = "ayse.demir" }, Permission = "TERM_DEPOSIT_VIEW" });
            Assert.Equal(DecisionType.Deny, d.Decision);
            Assert.Equal("NO_POLICY", d.ReasonCode);
        }
    }

    [Fact]
    public async Task S08b_policy_without_applicable_rule_is_not_applicable_and_not_allowed()
    {
        await using var host = await TestHost.CreateAsync();
        var cashPolicy = await host.IdAsync(db => db.Policies, p => p.Code == "CASH_WITHDRAWAL_POLICY", p => p.Id);
        var permitRule = await host.IdAsync(db => db.Rules, r => r.Code == "PERMIT_WITHIN_CONSTRAINTS" && r.PolicyId == cashPolicy, r => r.Id);
        var d = await Evaluate(host, Cash("ahmet.yilmaz", 1_000), new EvaluationOptions
        {
            IsSimulation = true, WriteAudit = false,
            PolicyChanges = new PolicyChangeSet { RemovedRuleIds = { permitRule } }
        });
        Assert.Equal(DecisionType.NotApplicable, d.Decision);
        Assert.False(d.IsAllowed);
    }

    // 9) What-If gerçek authorization ile aynı engine'i kullanır
    [Fact]
    public async Task S09_what_if_uses_same_engine_as_real_authorization()
    {
        await using var host = await TestHost.CreateAsync();
        var request = Cash("ahmet.yilmaz", 75_000);

        var real = await Evaluate(host, request);
        SimulatedEvaluateRequest Sim(PolicyChangeSet? pc) => new() { Request = request, AsOfUtc = host.Clock.UtcNow, PolicyChanges = pc };

        await using var scope = host.Scope();
        var simulation = scope.ServiceProvider.GetRequiredService<SimulationService>();
        var simulated = await simulation.SimulateEvaluateAsync(Sim(null), default);

        Assert.Equal(real.Decision, simulated.Decision);
        Assert.Equal(real.ReasonCode, simulated.ReasonCode);
        Assert.Equal(real.DecidingRule, simulated.DecidingRule);
        Assert.Equal(
            real.Policies.SelectMany(p => p.Rules).Select(r => (r.Code, r.Result)),
            simulated.Policies.SelectMany(p => p.Rules).Select(r => (r.Code, r.Result)));
        Assert.True(simulated.IsSimulation);

        // Aynı engine + policy değişikliği: limit kuralı pasifse 75.000 izinli olur; gerçek veri değişmez
        var limitRule = await host.IdAsync(db => db.Rules, r => r.Code == "CASH_LIMIT_EXCEEDED", r => r.Id);
        var whatIf = await simulation.SimulateEvaluateAsync(Sim(new PolicyChangeSet { RuleOverrides = { new RuleOverride(limitRule, IsActive: false) } }), default);
        Assert.Equal(DecisionType.Permit, whatIf.Decision);
        Assert.Equal(DecisionType.Deny, (await Evaluate(host, request)).Decision);
    }

    // 10) Aynı request tekrar değerlendirildiğinde deterministik sonuç
    [Fact]
    public async Task S10_same_request_is_deterministic()
    {
        await using var host = await TestHost.CreateAsync();
        var results = new List<AuthorizationDecision>();
        for (var i = 0; i < 3; i++) results.Add(await Evaluate(host, Cash("ahmet.yilmaz", 75_000, channel: "INTERNET")));

        static string Fingerprint(AuthorizationDecision d) => string.Join("|",
            d.Decision, d.ReasonCode, d.DecidingPolicy, d.DecidingRule,
            string.Join(",", d.Policies.SelectMany(p => p.Rules).Select(r => $"{r.Code}:{r.ConditionValue}:{r.Result}")),
            string.Join(",", d.Evidence.Select(e => $"{e.Attribute}={e.Value}")));

        Assert.Single(results.Select(Fingerprint).Distinct());
        Assert.Equal(3, results.Select(r => r.DecisionId).Distinct().Count()); // her karar ayrı audit kaydı
    }

    [Fact]
    public async Task Decision_audit_masks_sensitive_attributes()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await Evaluate(host, Cash("ahmet.yilmaz", 100, customer: "12345678"));
        await using var scope = host.Scope();
        var log = scope.ServiceProvider.GetRequiredService<IYetkiDbContext>().AuditLogs.Single(a => a.Id == d.DecisionId);

        Assert.Equal(AuditCategory.AuthorizationDecision, log.Category);
        Assert.DoesNotContain("12345678", log.DetailsJson);
        Assert.Contains("******78", log.DetailsJson);
        Assert.Equal("12345678", d.Context["CustomerId"]); // karar gerçek değerle verilir
    }

    [Fact]
    public async Task On_leave_and_own_customer_rules_and_inactive_user()
    {
        await using var host = await TestHost.CreateAsync();
        Assert.Equal("USER_ON_LEAVE", (await Evaluate(host, Cash("elif.sahin", 100))).ReasonCode);
        Assert.Equal("OWN_CUSTOMER_TRANSACTION", (await Evaluate(host, Cash("ahmet.yilmaz", 100, customer: "10001"))).ReasonCode);
        Assert.Equal("USER_INACTIVE", (await Evaluate(host, Cash("murat.polat", 100))).ReasonCode);
    }
}
