using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Abstractions;
using Yetki.Application.Changes;
using Yetki.Application.Effective;
using Yetki.Application.Sod;
using Yetki.Domain.Common;

namespace Yetki.Tests;

public class EffectivePermissionTests
{
    [Fact]
    public async Task Direct_role_group_role_and_orgunit_sources_are_explained()
    {
        await using var host = await TestHost.CreateAsync();
        await using var scope = host.Scope();
        var eff = scope.ServiceProvider.GetRequiredService<EffectivePermissionService>();

        var set = (await eff.GetAsync(await host.UserIdAsync("ahmet.yilmaz")))!;

        Assert.Contains(set.Find("CASH_WITHDRAW")!.Sources, s => s.Type == PermissionSourceType.DirectRole && s.RoleCode == "GISEYTK");
        // 101 şube kitlesi -> SUBE_101_RAPOR grubu
        Assert.Contains(set.Find("REPORT_BRANCH_VIEW")!.Sources, s => s.Type == PermissionSourceType.GroupPermission && s.GroupCode == "SUBE_101_RAPOR");
        // Kampanya grubu hem rol hem birim kitlesiyle eşleşir
        var kampanya = set.Groups.Single(g => g.Code == "VADELI_KAMPANYA_EKIBI");
        Assert.Contains(kampanya.Reasons, r => r.Type == "Role");
        Assert.Contains(kampanya.Reasons, r => r.Type == "OrgUnit");
    }

    [Fact]
    public async Task Group_granted_role_gives_permissions_without_direct_assignment()
    {
        await using var host = await TestHost.CreateAsync();
        await using var scope = host.Scope();
        var eff = scope.ServiceProvider.GetRequiredService<EffectivePermissionService>();

        // burak.arslan BRYSLYTK; müdür vekili olarak SUBEMDR rolünü SUBEMDR_VEKALET grubundan alır
        var set = (await eff.GetAsync(await host.UserIdAsync("burak.arslan")))!;

        var p = set.Find("CREDIT_APPROVE");
        Assert.NotNull(p);
        Assert.Equal(PermissionSourceType.GroupGrantedRole, p!.Sources.Single().Type);
        Assert.Equal("SUBEMDR_VEKALET", p.Sources.Single().GroupCode);
        Assert.Equal("SUBEMDR", p.Sources.Single().RoleCode);
    }

    [Fact]
    public async Task Change_set_is_simulated_without_persisting()
    {
        await using var host = await TestHost.CreateAsync();
        await using var scope = host.Scope();
        var eff = scope.ServiceProvider.GetRequiredService<EffectivePermissionService>();
        var gizem = await host.UserIdAsync("gizem.tas");
        var roleId = await host.IdAsync(db => db.Roles, r => r.Code == "BRYSLAST", r => r.Id);

        var changes = AuthorizationChangeSet.ForUser(gizem);
        changes.AddUserRoleIds.Add(roleId);

        Assert.NotNull((await eff.GetAsync(gizem, changes))!.Find("VADA_MENU"));
        Assert.Null((await eff.GetAsync(gizem))!.Find("VADA_MENU"));
    }
}

public class SodAndChangeTests
{
    [Fact]
    public async Task Block_rule_prevents_assignment_and_nothing_is_persisted()
    {
        await using var host = await TestHost.CreateAsync();
        var mehmet = await host.UserIdAsync("mehmet.kaya");
        var mudur = await host.IdAsync(db => db.Roles, r => r.Code == "SUBEMDR", r => r.Id);

        await using (var scope = host.Scope())
        {
            var svc = scope.ServiceProvider.GetRequiredService<AssignmentService>();
            var ex = await Assert.ThrowsAsync<ConflictException>(() => svc.AssignRoleToUserAsync(mehmet, mudur, null, default));
            var impact = Assert.IsType<ChangeImpactResult>(ex.Details);
            Assert.Contains(impact.BlockingConflicts, c => c.Conflict.Code == "SOD_CREDIT_CREATE_APPROVE");
        }
        await using (var scope = host.Scope())
        {
            var db = scope.ServiceProvider.GetRequiredService<IYetkiDbContext>();
            Assert.False(db.UserRoles.Any(x => x.UserId == mehmet && x.RoleId == mudur));
        }
    }

    [Fact]
    public async Task Warn_rule_applies_assignment_records_violation_and_emits_events()
    {
        await using var host = await TestHost.CreateAsync();
        var ahmet = await host.UserIdAsync("ahmet.yilmaz");
        var ops = await host.IdAsync(db => db.Roles, r => r.Code == "BRYSLYTK", r => r.Id);

        await using var scope = host.Scope();
        var result = await scope.ServiceProvider.GetRequiredService<AssignmentService>().AssignRoleToUserAsync(ahmet, ops, null, default);
        Assert.True(result.Applied);
        Assert.Single(result.Warnings);
        Assert.Contains(result.Users.Single().ExternalGrants, e => e.SystemCode == "LDAP");

        var db = scope.ServiceProvider.GetRequiredService<IYetkiDbContext>();
        Assert.True(db.SodViolations.Any(v => v.UserId == ahmet && v.Status == ViolationStatus.Open));
        Assert.True(db.OutboxEvents.Any(e => e.EventType == "EffectivePermissionsChanged" && e.AggregateId == ahmet.ToString()));
    }

    [Fact]
    public async Task Retrospective_scan_finds_legacy_violations_without_removing_permissions()
    {
        await using var host = await TestHost.CreateAsync();
        await using var scope = host.Scope();
        var result = await scope.ServiceProvider.GetRequiredService<SodService>().ScanAsync();

        Assert.Contains(result.Details, d => d.UserName == "emre.koc" && d.Conflicts.Any(c => c.Code == "SOD_CREDIT_CREATE_APPROVE"));
        Assert.Contains(result.Details, d => d.UserName == "deniz.yildiz");

        var eff = scope.ServiceProvider.GetRequiredService<EffectivePermissionService>();
        Assert.NotNull((await eff.GetAsync(await host.UserIdAsync("emre.koc"), useCache: false))!.Find("CREDIT_APPROVE"));
    }

    [Fact]
    public async Task Cache_is_invalidated_after_assignment()
    {
        await using var host = await TestHost.CreateAsync();
        var gizem = await host.UserIdAsync("gizem.tas");
        var roleId = await host.IdAsync(db => db.Roles, r => r.Code == "BRYSLAST", r => r.Id);

        await using (var scope = host.Scope())
            Assert.Null((await scope.ServiceProvider.GetRequiredService<EffectivePermissionService>().GetAsync(gizem))!.Find("VADA_MENU"));
        await using (var scope = host.Scope())
            await scope.ServiceProvider.GetRequiredService<AssignmentService>().AssignRoleToUserAsync(gizem, roleId, null, default);
        await using (var scope = host.Scope())
            Assert.NotNull((await scope.ServiceProvider.GetRequiredService<EffectivePermissionService>().GetAsync(gizem))!.Find("VADA_MENU"));
    }
}
