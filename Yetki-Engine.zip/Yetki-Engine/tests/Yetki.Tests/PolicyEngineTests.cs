using Microsoft.Extensions.Logging.Abstractions;
using Yetki.Application.Context;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.PolicyEngine.Combining;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Application.PolicyEngine.Conditions.Handlers;
using Yetki.Domain.Common;

namespace Yetki.Tests;

/// <summary>Testler için: "Value" parametresine göre True/False/Indeterminate dönen predicate.</summary>
internal sealed class FixedConditionHandler : ConditionHandlerBase
{
    public override ConditionTypeDescriptor Descriptor { get; } = new(
        "FIXED", "Sabit", "Test", ConditionScope.Global, [new("Value", "Değer", "string", true, null, null)], []);

    public override Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct) =>
        Task.FromResult(ctx.Param("Value") switch
        {
            "True" => ConditionResult.True("sabit true"),
            "False" => ConditionResult.False("sabit false"),
            _ => ConditionResult.Missing(AttributeId.Ctx("Something"))
        });
}

/// <summary>DB'siz, saf policy engine birim testleri: combining algoritmaları ve condition ağacı mantığı.</summary>
public class PolicyEngineTests
{
    private static readonly PolicyEvaluator Evaluator = new(
        new ConditionHandlerRegistry([new AlwaysConditionHandler(), new FixedConditionHandler()]),
        CombiningAlgorithmRegistry.Default,
        NullLogger<PolicyEvaluator>.Instance);

    private static AttributeResolver Resolver() => new([new RequestContextAttributeProvider()], new AttributeResolutionScope
    {
        Subject = new SubjectRef(1, "test"), Context = new AuthorizationContext(), Action = "TEST"
    });

    private static ConditionNode Fixed(string value) =>
        new(0, ConditionKind.Predicate, "FIXED", true, new Dictionary<string, string> { ["Value"] = value }, []);

    private static ConditionNode Node(ConditionKind kind, params ConditionNode[] children) =>
        new(0, kind, null, true, new Dictionary<string, string>(), children);

    private static RuleDefinition Rule(string code, RuleEffect effect, ConditionNode condition, int order = 0, bool active = true) =>
        new(0, code, code, null, effect, order, code + "_REASON", active, condition);

    private static Task<PolicyEvaluation> Evaluate(CombiningAlgorithm algorithm, params RuleDefinition[] rules) =>
        Evaluator.EvaluateAsync(new PolicyDefinition(1, "P", "P", 1, algorithm, rules), Resolver(), "TEST", default);

    // Senaryo 6: Bir Rule Deny, diğerleri Permit → DenyOverrides sonucu Deny
    [Fact]
    public async Task DenyOverrides_one_deny_among_permits_results_in_deny()
    {
        var r = await Evaluate(CombiningAlgorithm.DenyOverrides,
            Rule("P1", RuleEffect.Permit, Fixed("True"), 1),
            Rule("P2", RuleEffect.Permit, Fixed("True"), 2),
            Rule("D3", RuleEffect.Deny, Fixed("True"), 3));

        Assert.Equal(DecisionType.Deny, r.Result);
        Assert.Equal("D3", r.DecidingRule);
        Assert.True(r.Rules.Single(x => x.Code == "D3").IsDeciding);
        Assert.All(r.Rules.Where(x => x.Code != "D3"), x => Assert.Equal(DecisionType.Permit, x.Result));
    }

    [Fact]
    public async Task PermitOverrides_and_FirstApplicable_are_explicit_strategies()
    {
        var rules = new[]
        {
            Rule("NA", RuleEffect.Deny, Fixed("False"), 1),
            Rule("D", RuleEffect.Deny, Fixed("True"), 2),
            Rule("P", RuleEffect.Permit, Fixed("True"), 3)
        };
        Assert.Equal(DecisionType.Permit, (await Evaluate(CombiningAlgorithm.PermitOverrides, rules)).Result);

        var first = await Evaluate(CombiningAlgorithm.FirstApplicable, rules);
        Assert.Equal(DecisionType.Deny, first.Result);
        Assert.Equal("D", first.DecidingRule);
    }

    [Fact]
    public async Task Rule_semantics_true_applies_effect_false_is_not_applicable_inactive_is_skipped()
    {
        var r = await Evaluate(CombiningAlgorithm.DenyOverrides,
            Rule("DENY_FALSE", RuleEffect.Deny, Fixed("False"), 1),
            Rule("DENY_INACTIVE", RuleEffect.Deny, Fixed("True"), 2, active: false));

        Assert.Equal(DecisionType.NotApplicable, r.Result);
        Assert.All(r.Rules, x => Assert.Equal(DecisionType.NotApplicable, x.Result));
    }

    [Fact]
    public async Task Indeterminate_deny_rule_blocks_permit_under_deny_overrides()
    {
        var r = await Evaluate(CombiningAlgorithm.DenyOverrides,
            Rule("DENY_UNKNOWN", RuleEffect.Deny, Fixed("Indeterminate"), 1),
            Rule("PERMIT", RuleEffect.Permit, Fixed("True"), 2));

        Assert.Equal(DecisionType.Indeterminate, r.Result);
        Assert.Contains("Context.Something", r.Rules[0].MissingAttributes);
    }

    [Theory]
    [InlineData(ConditionKind.AllOf, "True", "True", TriState.True)]
    [InlineData(ConditionKind.AllOf, "True", "False", TriState.False)]
    [InlineData(ConditionKind.AllOf, "False", "Indeterminate", TriState.False)]      // Kleene: false AND ? = false
    [InlineData(ConditionKind.AllOf, "True", "Indeterminate", TriState.Indeterminate)]
    [InlineData(ConditionKind.AnyOf, "False", "True", TriState.True)]
    [InlineData(ConditionKind.AnyOf, "True", "Indeterminate", TriState.True)]        // Kleene: true OR ? = true
    [InlineData(ConditionKind.AnyOf, "False", "Indeterminate", TriState.Indeterminate)]
    [InlineData(ConditionKind.AnyOf, "False", "False", TriState.False)]
    public async Task Condition_tree_uses_three_valued_logic(ConditionKind kind, string a, string b, TriState expected)
    {
        var r = await Evaluate(CombiningAlgorithm.DenyOverrides, Rule("R", RuleEffect.Deny, Node(kind, Fixed(a), Fixed(b))));
        Assert.Equal(expected, r.Rules[0].ConditionValue);
    }

    [Fact]
    public async Task Not_and_nested_expression_evaluate_and_render()
    {
        // (A AND NOT B) OR C   with A=true, B=false, C=false → true
        var tree = Node(ConditionKind.AnyOf, Node(ConditionKind.AllOf, Fixed("True"), Node(ConditionKind.Not, Fixed("False"))), Fixed("False"));
        var r = await Evaluate(CombiningAlgorithm.DenyOverrides, Rule("R", RuleEffect.Deny, tree));

        Assert.Equal(TriState.True, r.Rules[0].ConditionValue);
        Assert.Equal(DecisionType.Deny, r.Result);
        Assert.Contains("NOT FIXED(Value=False)", r.Rules[0].Expression);
        Assert.Contains(" OR ", r.Rules[0].Expression);
    }

    [Fact]
    public async Task Unknown_condition_type_is_fail_closed()
    {
        var node = new ConditionNode(0, ConditionKind.Predicate, "NOT_REGISTERED", true, new Dictionary<string, string>(), []);
        var r = await Evaluate(CombiningAlgorithm.DenyOverrides, Rule("R", RuleEffect.Deny, node), Rule("P", RuleEffect.Permit, Fixed("True"), 1));
        Assert.Equal(DecisionType.Indeterminate, r.Result);
    }
}
