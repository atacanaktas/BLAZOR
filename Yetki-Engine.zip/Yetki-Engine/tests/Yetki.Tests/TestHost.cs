using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Yetki.Application.Abstractions;
using Yetki.Infrastructure;
using Yetki.Infrastructure.Services;

namespace Yetki.Tests;

public sealed class FakeClock : IClock
{
    /// <summary>Varsayılan: Salı 11:00 İstanbul (08:00 UTC) — mesai içi.</summary>
    public DateTime UtcNow { get; set; } = new(2026, 9, 22, 8, 0, 0, DateTimeKind.Utc);
}

/// <summary>Her test için izole InMemory veritabanı + seed verisi ile gerçek DI grafiği.</summary>
public sealed class TestHost : IAsyncDisposable
{
    public ServiceProvider Services { get; }
    public FakeClock Clock { get; } = new();

    private TestHost(Action<IServiceCollection>? configure)
    {
        var config = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["Persistence:Provider"] = "InMemory",
            ["Persistence:InMemoryDatabaseName"] = "test-" + Guid.NewGuid(),
            ["Seed:Enabled"] = "true"
        }).Build();

        var services = new ServiceCollection();
        services.AddLogging();
        services.AddYetkiInfrastructure(config);
        services.Replace(ServiceDescriptor.Singleton<IClock>(Clock));
        services.AddScoped<ICurrentActor>(_ => new SystemActor("test"));
        configure?.Invoke(services);
        Services = services.BuildServiceProvider();
        Config = config;
    }

    private IConfiguration Config { get; }

    public static async Task<TestHost> CreateAsync(Action<IServiceCollection>? configure = null)
    {
        var host = new TestHost(configure);
        await host.Services.InitializeYetkiDatabaseAsync(host.Config);
        return host;
    }

    public AsyncServiceScope Scope() => Services.CreateAsyncScope();

    public async Task<int> UserIdAsync(string userName)
    {
        await using var scope = Scope();
        var db = scope.ServiceProvider.GetRequiredService<IYetkiDbContext>();
        return db.Users.Single(u => u.UserName == userName).Id;
    }

    public async Task<int> IdAsync<T>(Func<IYetkiDbContext, IQueryable<T>> set, Func<T, bool> predicate, Func<T, int> id)
    {
        await using var scope = Scope();
        var db = scope.ServiceProvider.GetRequiredService<IYetkiDbContext>();
        return id(set(db).AsEnumerable().Single(predicate));
    }

    public ValueTask DisposeAsync() => Services.DisposeAsync();
}
