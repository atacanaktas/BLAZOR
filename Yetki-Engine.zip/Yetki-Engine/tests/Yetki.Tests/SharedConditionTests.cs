using System.Globalization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Abstractions;
using Yetki.Application.Definitions;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine;
using Yetki.Application.Simulation;
using Yetki.Domain.Common;

namespace Yetki.Tests;

/// <summary>
/// Ortak (adlandırılmış) koşullar: tanım tek yerde, rule'lar referans verir.
/// Seed: BUSINESS_HOURS, EFT_HOURS, BANK_NETWORK, REMOTE_PLATFORM, CREDIT_APPROVAL_LIMIT_EXCEEDED.
/// BANK_NETWORK → CASH_WITHDRAWAL_POLICY, CREDIT_APPROVAL_POLICY, EFT_POLICY'de "NOT @BANK_NETWORK" olarak kullanılır.
/// </summary>
public class SharedConditionTests
{
    private static AuthorizationRequest Cash(string ip) => new()
    {
        Subject = new SubjectInfo { UserName = "ahmet.yilmaz" },
        Permission = "CASH_WITHDRAW",
        Context = new() { ["TransactionAmount"] = "1000", ["IpAddress"] = ip, ["Channel"] = "CASH_DESK", ["CustomerId"] = "555" }
    };

    private static async Task<AuthorizationDecision> Evaluate(TestHost host, AuthorizationRequest r)
    {
        await using var scope = host.Scope();
        return await scope.ServiceProvider.GetRequiredService<AuthorizationEvaluator>().EvaluateAsync(r);
    }

    private static SharedConditionUpsert Upsert(string code, ConditionDraft condition, bool active = true) => new()
    {
        Code = code, Name = code, Scope = ConditionScope.Global, IsActive = active, Condition = condition
    };

    private static ConditionDraft Ip(string cidrs) => new() { ConditionTypeCode = "IP_IN_RANGE", Parameters = { ["Cidrs"] = cidrs } };
    private static ConditionDraft Ref(string code) => new() { Kind = ConditionKind.Reference, SharedConditionCode = code };

    [Fact]
    public async Task Reference_is_evaluated_and_explained()
    {
        await using var host = await TestHost.CreateAsync();
        var d = await Evaluate(host, Cash("85.100.1.1"));

        Assert.Equal(DecisionType.Deny, d.Decision);
        Assert.Equal("OUTSIDE_BANK_NETWORK", d.ReasonCode);
        var rule = d.Policies.Single().Rules.Single(r => r.Code == "DENY_OUTSIDE_BANK_NETWORK");
        Assert.Equal("NOT @BANK_NETWORK", rule.Expression);
        var reference = rule.Condition!.Children!.Single();
        Assert.Equal(ConditionKind.Reference, reference.Kind);
        Assert.Contains("@BANK_NETWORK v1", reference.Message);
        Assert.Contains(rule.Evidence, e => e.Attribute == "Environment.IpAddress" && e.Value == "85.100.1.1");
    }

    [Fact]
    public async Task Updating_shared_condition_changes_all_referencing_policies_and_bumps_versions()
    {
        await using var host = await TestHost.CreateAsync();
        var bankNetwork = await host.IdAsync(db => db.SharedConditions, x => x.Code == "BANK_NETWORK", x => x.Id);
        Assert.Equal(DecisionType.Permit, (await Evaluate(host, Cash("172.20.0.5"))).Decision);

        await using (var scope = host.Scope())
        {
            var svc = scope.ServiceProvider.GetRequiredService<SharedConditionService>();
            var usages = await svc.UsagesAsync(bankNetwork, default);
            Assert.Equal(["CASH_WITHDRAWAL_POLICY", "CREDIT_APPROVAL_POLICY", "EFT_POLICY"], usages.Select(u => u.Policy).Distinct().Order().ToArray());

            // 172.16.0.0/12 bloğu banka ağından çıkarılıyor → TEK değişiklik, üç policy
            await svc.UpdateAsync(bankNetwork, Upsert("BANK_NETWORK", Ip("10.0.0.0/8,192.168.0.0/16,127.0.0.1/32,::1/128")), default);
        }

        var d = await Evaluate(host, Cash("172.20.0.5"));
        Assert.Equal(DecisionType.Deny, d.Decision);
        Assert.Equal("OUTSIDE_BANK_NETWORK", d.ReasonCode);

        await using (var scope = host.Scope())
        {
            var db = scope.ServiceProvider.GetRequiredService<IYetkiDbContext>();
            Assert.Equal(2, db.SharedConditions.Single(x => x.Id == bankNetwork).Version);
            Assert.All(db.Policies.Where(p => p.Code != "TERM_DEPOSIT_CLOSE_POLICY").ToList(), p => Assert.Equal(2, p.Version));
            Assert.Equal(1, db.Policies.Single(p => p.Code == "TERM_DEPOSIT_CLOSE_POLICY").Version); // BANK_NETWORK kullanmıyor
        }
    }

    [Fact]
    public async Task What_if_shared_condition_replacement_shows_impact_across_policies()
    {
        await using var host = await TestHost.CreateAsync();
        var bankNetwork = await host.IdAsync(db => db.SharedConditions, x => x.Code == "BANK_NETWORK", x => x.Id);

        await using var scope = host.Scope();
        var result = await scope.ServiceProvider.GetRequiredService<PolicyImpactService>().AnalyzeAsync(new PolicyImpactRequest
        {
            Changes = new PolicyChangeSet { SharedConditionReplacements = { new SharedConditionReplacement(bankNetwork, Ip("192.168.0.0/16")) } },
            Scenarios = { new ImpactScenario { Name = "10.x", Context = new() { ["TransactionAmount"] = "1000", ["Channel"] = "CASH_DESK", ["CustomerId"] = "555", ["IpAddress"] = "10.1.2.3" } } },
            AsOfUtc = host.Clock.UtcNow
        }, default);

        Assert.Equal(["CASH_WITHDRAW", "CREDIT_APPROVE", "EFT_SEND"], result.Permissions.Select(p => p.Code).Order().ToArray());
        Assert.Contains(result.Rows, r => r.UserName == "ahmet.yilmaz" && r.Permission == "CASH_WITHDRAW" && r.Change == "NEWLY_DENIED");
        // Veri değişmedi
        Assert.Equal(DecisionType.Permit, (await Evaluate(host, Cash("10.1.2.3"))).Decision);
    }

    [Fact]
    public async Task Cycles_are_rejected()
    {
        await using var host = await TestHost.CreateAsync();
        await using var scope = host.Scope();
        var svc = scope.ServiceProvider.GetRequiredService<SharedConditionService>();

        var aId = (await svc.CreateAsync(Upsert("COND_A", Ip("10.0.0.0/8")), default)).Id;
        var bId = (await svc.CreateAsync(Upsert("COND_B", Ref("COND_A")), default)).Id;

        // A → B → A
        await Assert.ThrowsAsync<ValidationException>(() => svc.UpdateAsync(aId, Upsert("COND_A", Ref("COND_B")), default));
        // Doğrudan kendine referans
        await Assert.ThrowsAsync<ValidationException>(() => svc.UpdateAsync(bId, Upsert("COND_B", Ref("COND_B")), default));
    }

    [Fact]
    public async Task Used_shared_condition_cannot_be_deactivated_or_deleted()
    {
        await using var host = await TestHost.CreateAsync();
        var bankNetwork = await host.IdAsync(db => db.SharedConditions, x => x.Code == "BANK_NETWORK", x => x.Id);
        await using var scope = host.Scope();
        var svc = scope.ServiceProvider.GetRequiredService<SharedConditionService>();

        await Assert.ThrowsAsync<ConflictException>(() => svc.UpdateAsync(bankNetwork, Upsert("BANK_NETWORK", Ip("10.0.0.0/8"), active: false), default));
        await Assert.ThrowsAsync<ConflictException>(() => svc.DeleteAsync(bankNetwork, default));

        var unused = (await svc.CreateAsync(Upsert("UNUSED_COND", Ip("10.0.0.0/8")), default)).Id;
        await svc.DeleteAsync(unused, default);
    }

    [Fact]
    public async Task Inactive_reference_is_fail_closed()
    {
        await using var host = await TestHost.CreateAsync();
        // Servis bunu engeller; veri doğrudan bozulmuş olsa bile motor izin vermemeli.
        await using (var scope = host.Scope())
        {
            var db = scope.ServiceProvider.GetRequiredService<IYetkiDbContext>();
            (await db.SharedConditions.SingleAsync(x => x.Code == "BANK_NETWORK")).IsActive = false;
            await db.SaveChangesAsync();
        }
        var d = await Evaluate(host, Cash("10.1.2.3"));
        Assert.Equal(DecisionType.Indeterminate, d.Decision);
        Assert.False(d.IsAllowed);
        Assert.Contains("SharedCondition.BANK_NETWORK", d.MissingAttributes);
    }

    [Fact]
    public async Task Rule_can_reference_shared_condition_through_management_api()
    {
        await using var host = await TestHost.CreateAsync();
        await using var scope = host.Scope();
        var defs = scope.ServiceProvider.GetRequiredService<PolicyManagementService>();
        var policy = await defs.CreatePolicyAsync(new PolicyUpsert { Code = "NEW_POLICY", Name = "Yeni" }, default);

        await defs.CreateRuleAsync(policy.Id, new RuleUpsert
        {
            Code = "DENY_OUTSIDE_BANK_NETWORK", Name = "Ağ dışı", Effect = RuleEffect.Deny, Order = 10, ReasonCode = "OUTSIDE_BANK_NETWORK",
            Condition = new ConditionDraft { Kind = ConditionKind.Not, Children = { Ref("bank_network") } }
        }, default);

        var loaded = (await scope.ServiceProvider.GetRequiredService<PolicyDefinitionLoader>().LoadPoliciesAsync([policy.Id], null, false, default)).Single();
        Assert.Equal("NOT @BANK_NETWORK", PolicyEvaluator.Render(loaded.Rules.Single().Condition));
        Assert.StartsWith("NOT @BANK_NETWORK[IP_IN_RANGE(", PolicyEvaluator.Render(loaded.Rules.Single().Condition, expand: true));

        await Assert.ThrowsAsync<ValidationException>(() => defs.CreateRuleAsync(policy.Id, new RuleUpsert
        {
            Code = "BAD", Name = "Bilinmeyen", Condition = Ref("NO_SUCH_CONDITION")
        }, default));
        _ = CultureInfo.InvariantCulture;
    }
}
