using Microsoft.Extensions.DependencyInjection;
using Yetki.Application.Changes;
using Yetki.Application.Effective;
using Yetki.Application.Evaluation;
using Yetki.Application.Simulation;
using Yetki.Domain.Common;

namespace Yetki.Tests;

public class WhatIfTests
{
    private static ImpactScenario CashScenario(string amount) => new()
    {
        Name = amount,
        Context = new() { ["TransactionAmount"] = amount, ["Channel"] = "CASH_DESK", ["CustomerId"] = "555", ["IpAddress"] = "10.1.2.3" }
    };

    [Fact]
    public async Task Removing_permission_from_role_lists_losers_and_users_who_retain_via_other_source()
    {
        await using var host = await TestHost.CreateAsync();
        var gise = await host.IdAsync(db => db.Roles, r => r.Code == "GISEYTK", r => r.Id);
        var customerView = await host.IdAsync(db => db.Permissions, p => p.Code == "CUSTOMER_VIEW", p => p.Id);
        var ahmet = await host.UserIdAsync("ahmet.yilmaz");
        var bireysel = await host.IdAsync(db => db.Roles, r => r.Code == "BRYSLYTK", r => r.Id);

        // ahmet CUSTOMER_VIEW'i BRYSLYTK'dan da alsın -> rolden silinince korunmalı
        await using (var scope = host.Scope())
            await scope.ServiceProvider.GetRequiredService<AssignmentService>().AssignRoleToUserAsync(ahmet, bireysel, null, default);

        var cs = new AuthorizationChangeSet();
        cs.RolePermissionChanges.Add(new RolePermissionChange(gise, customerView, false));
        await using var s = host.Scope();
        var impact = await s.ServiceProvider.GetRequiredService<AuthorizationChangeService>().AnalyzeAsync(cs);

        Assert.Contains(impact.Users, u => u.UserName == "deniz.yildiz" && u.RemovedPermissions.Any(p => p.Code == "CUSTOMER_VIEW"));
        var a = impact.Users.Single(u => u.UserName == "ahmet.yilmaz");
        Assert.Empty(a.RemovedPermissions);
        Assert.Contains(a.RetainedPermissions, p => p.Code == "CUSTOMER_VIEW");
        Assert.True(impact.EvaluatedUserCount >= impact.Users.Count);
    }

    [Fact]
    public async Task Adding_draft_deny_rule_shows_newly_denied_decisions()
    {
        await using var host = await TestHost.CreateAsync();
        var policy = await host.IdAsync(db => db.Policies, p => p.Code == "CASH_WITHDRAWAL_POLICY", p => p.Id);

        var request = new PolicyImpactRequest
        {
            Changes = new PolicyChangeSet
            {
                // Nakit çekime sabit 10.000 üst tutar kuralı eklenirse?
                AddedRules =
                {
                    new RuleDraft
                    {
                        PolicyId = policy, Code = "DRAFT_MAX_10K", Effect = RuleEffect.Deny, Order = 45, ReasonCode = "DRAFT_MAX_10K",
                        Condition = new ConditionDraft { ConditionTypeCode = "AMOUNT_GREATER_THAN", Parameters = { ["Threshold"] = "10000" } }
                    }
                }
            },
            Scenarios = { CashScenario("20000") },
            AsOfUtc = host.Clock.UtcNow
        };

        await using var scope = host.Scope();
        var result = await scope.ServiceProvider.GetRequiredService<PolicyImpactService>().AnalyzeAsync(request, default);

        var diff = result.Permissions.Single(p => p.Code == "CASH_WITHDRAW");
        Assert.Contains("CASH_WITHDRAWAL_POLICY/DRAFT_MAX_10K", diff.AddedRules);
        Assert.Contains(result.Rows, r => r.UserName == "ahmet.yilmaz" && r.Change == "NEWLY_DENIED" && r.After.ReasonCode == "DRAFT_MAX_10K");
        Assert.True(result.NewlyDenied > 0);
    }

    [Fact]
    public async Task Condition_parameter_override_changes_decisions()
    {
        await using var host = await TestHost.CreateAsync();
        // Mesai tanımı artık BUSINESS_HOURS ortak koşulunda; onun TIME_WINDOW düğümünün parametresi değişirse
        // onu kullanan TÜM policy'ler (nakit çekim, kredi onayı, vadeli kapama) etkilenir.
        var businessHours = await host.IdAsync(db => db.SharedConditions, x => x.Code == "BUSINESS_HOURS", x => x.Id);
        var conditionId = await host.IdAsync(db => db.RuleConditions, c => c.Kind == ConditionKind.Predicate && c.SharedConditionId == businessHours, c => c.Id);

        var request = new PolicyImpactRequest
        {
            Changes = new PolicyChangeSet
            {
                ConditionOverrides = { new ConditionParameterOverride(conditionId, new() { ["Start"] = "09:00", ["End"] = "10:30", ["Days"] = "MON,TUE,WED,THU,FRI", ["TimeZone"] = "Europe/Istanbul" }) }
            },
            Scenarios = { CashScenario("1000") },
            AsOfUtc = host.Clock.UtcNow // 11:00 İstanbul
        };
        await using var scope = host.Scope();
        var result = await scope.ServiceProvider.GetRequiredService<PolicyImpactService>().AnalyzeAsync(request, default);

        Assert.Contains(result.Permissions, p => p.Code == "CREDIT_APPROVE");
        Assert.Contains(result.Permissions, p => p.Code == "TERM_DEPOSIT_CLOSE");
        Assert.Contains(result.Permissions.Single(p => p.Code == "CASH_WITHDRAW").ChangedRules,
            c => c.RuleCode == "DENY_OUTSIDE_BUSINESS_HOURS" && c.ExpressionAfter.Contains("@BUSINESS_HOURS[") && c.ExpressionAfter.Contains("End=10:30"));
        Assert.Contains(result.Rows, r => r.UserName == "ahmet.yilmaz" && r.Change == "NEWLY_DENIED" && r.After.ReasonCode == "OUTSIDE_BUSINESS_HOURS");
    }

    [Fact]
    public async Task Detaching_policy_and_new_required_attributes_are_reported()
    {
        await using var host = await TestHost.CreateAsync();
        var perm = await host.IdAsync(db => db.Permissions, p => p.Code == "CASH_WITHDRAW", p => p.Id);
        var cashPolicy = await host.IdAsync(db => db.Policies, p => p.Code == "CASH_WITHDRAWAL_POLICY", p => p.Id);
        var closePolicy = await host.IdAsync(db => db.Policies, p => p.Code == "TERM_DEPOSIT_CLOSE_POLICY", p => p.Id);

        await using var scope = host.Scope();
        var svc = scope.ServiceProvider.GetRequiredService<PolicyImpactService>();

        var detach = await svc.AnalyzeAsync(new PolicyImpactRequest
        {
            Changes = new PolicyChangeSet { PermissionPolicyChanges = { new PermissionPolicyChange(perm, cashPolicy, false) } }
        }, default);
        Assert.True(detach.Permissions.Single().BecomesUnconditional);

        var attach = await svc.AnalyzeAsync(new PolicyImpactRequest
        {
            Changes = new PolicyChangeSet { PermissionPolicyChanges = { new PermissionPolicyChange(perm, closePolicy, true) } }
        }, default);
        Assert.Contains("Context.BranchCode", attach.Permissions.Single().NewRequiredAttributes);
    }
}
