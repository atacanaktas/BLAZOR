using Yetki.Domain.Common;
using Yetki.Domain.Identity;
using Yetki.Domain.Policies;

namespace Yetki.Domain.Rbac;

/// <summary>Atomik yetki (ör. TERM_DEPOSIT_VIEW, CASH_WITHDRAW).</summary>
public class Permission : AuditableEntity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    /// <summary>İş alanı / domain (ör. VADELI, KREDI, GISE). Filtreleme ve ileride AI benzerlik analizi için metadata.</summary>
    public string? Domain { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<RolePermission> Roles { get; set; } = new List<RolePermission>();
    public ICollection<PermissionPolicy> Policies { get; set; } = new List<PermissionPolicy>();
}

/// <summary>Permission'ların iş fonksiyonuna göre paketlenmesi. Ana yönetim mekanizması.</summary>
public class Role : AuditableEntity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<RolePermission> Permissions { get; set; } = new List<RolePermission>();
}

public class RolePermission : IAssignment
{
    public int RoleId { get; set; }
    public Role Role { get; set; } = default!;
    public int PermissionId { get; set; }
    public Permission Permission { get; set; } = default!;
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}

public class UserRole : IAssignment
{
    public int UserId { get; set; }
    public User User { get; set; } = default!;
    public int RoleId { get; set; }
    public Role Role { get; set; } = default!;
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
    /// <summary>Opsiyonel süreli atama. Süresi geçmiş atama effective hesaba katılmaz.</summary>
    public DateTime? ValidUntil { get; set; }
}

/// <summary>
/// Doğrudan kullanıcıya verilen yetki. Ana model değildir; mevcut sistemden taşınan
/// (legacy) veya istisnai atamaları kayıpsız almak için vardır (smooth migration).
/// </summary>
public class UserPermission : IAssignment
{
    public int UserId { get; set; }
    public User User { get; set; } = default!;
    public int PermissionId { get; set; }
    public Permission Permission { get; set; } = default!;
    public string? Reason { get; set; }
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
    public DateTime? ValidUntil { get; set; }
}
