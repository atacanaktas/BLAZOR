using Yetki.Domain.Common;

namespace Yetki.Domain.Audit;

/// <summary>
/// Tek audit tablosu: authorization kararları + yönetim değişiklikleri + simülasyon/scan kayıtları.
/// Karar kayıtlarında Id = DecisionId'dir.
/// </summary>
public class AuditLog
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTime Timestamp { get; set; }
    public AuditCategory Category { get; set; }
    /// <summary>İşlemi yapan (yönetim) veya kararı talep eden uygulama/kullanıcı.</summary>
    public string Actor { get; set; } = "system";
    public string Action { get; set; } = default!;
    public string? EntityType { get; set; }
    public string? EntityId { get; set; }

    // Karar kayıtları için
    public string? SubjectUserName { get; set; }
    public string? PermissionCode { get; set; }
    public string? Resource { get; set; }
    public string? Decision { get; set; }
    public string? ReasonCode { get; set; }

    public string? Summary { get; set; }
    /// <summary>Context, eşleşen/başarısız rule'lar, permission kaynakları vb. (JSON).</summary>
    public string? DetailsJson { get; set; }
    public string? CorrelationId { get; set; }
}
