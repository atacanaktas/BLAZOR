using Yetki.Domain.Common;

namespace Yetki.Domain.Events;

/// <summary>
/// Transactional outbox. Yönetim değişikliği ile aynı iş biriminde yazılır,
/// arka plan işleyicisi (OutboxProcessor) tarafından tüketilir.
/// </summary>
public class OutboxEvent
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string EventType { get; set; } = default!;
    public string? AggregateType { get; set; }
    public string? AggregateId { get; set; }
    public string PayloadJson { get; set; } = "{}";
    public DateTime OccurredAt { get; set; }
    public string Actor { get; set; } = "system";
    public OutboxStatus Status { get; set; } = OutboxStatus.Pending;
    public int Attempts { get; set; }
    public DateTime? ProcessedAt { get; set; }
    public string? Error { get; set; }
}

/// <summary>
/// Dış sistemde yapılması gereken aksiyon ve sonucu (prototipte ProvisioningResult ayrı tablo değil, bu kayıtta).
/// Authorization core bu aksiyonun nasıl yapıldığını (RACF/FTP/EGL) bilmez.
/// </summary>
public class ProvisioningAction : Entity
{
    public Guid OutboxEventId { get; set; }
    public int UserId { get; set; }
    public string UserName { get; set; } = default!;
    public string PermissionCode { get; set; } = default!;
    public string ExternalSystemCode { get; set; } = default!;
    public string ExternalPermissionCode { get; set; } = default!;
    public ProvisioningActionType ActionType { get; set; }
    public ProvisioningStatus Status { get; set; } = ProvisioningStatus.Pending;
    public string? AdapterName { get; set; }
    public string? ResultMessage { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
}
