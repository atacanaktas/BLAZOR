namespace Yetki.Domain.Common;

/// <summary>
/// Tüm kalıcı varlıkların tabanı. Int identity anahtar SQL Server'a birebir taşınır.
/// </summary>
public abstract class Entity
{
    public int Id { get; set; }
}

/// <summary>
/// Yönetim ekranlarından değiştirilen varlıklar için izlenebilirlik alanları.
/// Değerler DbContext tarafından otomatik doldurulur (bkz. YetkiDbContext.ApplyAuditFields).
/// </summary>
public abstract class AuditableEntity : Entity
{
    public DateTime CreatedAt { get; set; }
    public string CreatedBy { get; set; } = "system";
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

/// <summary>Atama (ilişki) tabloları için ortak alanlar.</summary>
public interface IAssignment
{
    DateTime AssignedAt { get; set; }
    string AssignedBy { get; set; }
}
