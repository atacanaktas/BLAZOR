namespace Yetki.Domain.Common;

public enum OrganizationUnitType { Branch = 1, HeadOfficeDepartment = 2, Region = 3 }

/// <summary>Condition tipinin kapsamı: ortak (mesai, IP, kanal) veya iş alanına özel.</summary>
public enum ConditionScope { Global = 1, Domain = 2 }

/// <summary>Rule'un condition'ı TRUE olduğunda üreteceği sonuç.</summary>
public enum RuleEffect { Permit = 1, Deny = 2 }

/// <summary>Policy içindeki rule sonuçlarının birleştirilme algoritması (XACML kavramları).</summary>
public enum CombiningAlgorithm
{
    /// <summary>Herhangi bir Deny → Deny; yoksa belirsizlik → Indeterminate; yoksa Permit → Permit; yoksa NotApplicable.</summary>
    DenyOverrides = 1,
    /// <summary>Herhangi bir Permit → Permit; yoksa belirsizlik → Indeterminate; yoksa Deny → Deny; yoksa NotApplicable.</summary>
    PermitOverrides = 2,
    /// <summary>Sıraya göre NotApplicable olmayan ilk rule'un sonucu.</summary>
    FirstApplicable = 3
}

/// <summary>Condition ağacı düğüm tipi.</summary>
public enum ConditionKind { Predicate = 1, AllOf = 2, AnyOf = 3, Not = 4, Reference = 5 }

public enum SodMemberType { Permission = 1, Role = 2 }

/// <summary>Block: atama engellenir. Warn: atama yapılır, ihlal kaydı açılır ve uyarı döner.</summary>
public enum SodEnforcement { Warn = 1, Block = 2 }

public enum Severity { Low = 1, Medium = 2, High = 3, Critical = 4 }

public enum ViolationStatus { Open = 1, Acknowledged = 2, AcceptedRisk = 3, Resolved = 4 }

public enum ViolationDetectionSource { AssignmentCheck = 1, RetrospectiveScan = 2 }

public enum OutboxStatus { Pending = 1, Processed = 2, Failed = 3 }

public enum ProvisioningActionType { Grant = 1, Revoke = 2 }

public enum ProvisioningStatus { Pending = 1, Completed = 2, Failed = 3 }

public enum AuditCategory { AuthorizationDecision = 1, Management = 2, Simulation = 3, SodScan = 4 }
