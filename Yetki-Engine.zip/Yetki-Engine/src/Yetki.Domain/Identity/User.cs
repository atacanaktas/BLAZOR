using Yetki.Domain.Common;
using Yetki.Domain.Rbac;

namespace Yetki.Domain.Identity;

public class User : AuditableEntity
{
    /// <summary>Kurumsal kullanıcı adı / sicil (ör. ahmet.yilmaz). Benzersiz.</summary>
    public string UserName { get; set; } = default!;
    public string FullName { get; set; } = default!;
    public string? Email { get; set; }
    public string? Title { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsOnLeave { get; set; }

    /// <summary>
    /// PROTOTİP KISAYOLU: Gerçekte limit, limit yönetim/HR sisteminden gelecek.
    /// Rule handler'lar bu alanı doğrudan okumaz; ISubjectAttributeProvider üzerinden erişir.
    /// </summary>
    public decimal CashWithdrawalLimit { get; set; }

    /// <summary>
    /// PROTOTİP KISAYOLU: Personelin bankadaki kendi müşteri numarası (kendi hesabında işlem yasağı rule'u için).
    /// Gerçekte core banking / HR sisteminden bir provider ile çözülmelidir.
    /// </summary>
    public string? CustomerNo { get; set; }

    public ICollection<UserRole> Roles { get; set; } = new List<UserRole>();
    public ICollection<UserPermission> DirectPermissions { get; set; } = new List<UserPermission>();
    public ICollection<UserOrganizationUnit> OrganizationUnits { get; set; } = new List<UserOrganizationUnit>();
}

public class OrganizationUnit : AuditableEntity
{
    /// <summary>Şube/birim kodu (ör. 101, 737, 928).</summary>
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public OrganizationUnitType Type { get; set; }

    /// <summary>
    /// Sadece bilgi amaçlı hiyerarşi. Organizasyon hiyerarşisi yetki hiyerarşisi DEĞİLDİR;
    /// yetki çözümlemesinde kullanılmaz.
    /// </summary>
    public int? ParentId { get; set; }
    public OrganizationUnit? Parent { get; set; }
}

public class UserOrganizationUnit : IAssignment
{
    public int UserId { get; set; }
    public User User { get; set; } = default!;
    public int OrganizationUnitId { get; set; }
    public OrganizationUnit OrganizationUnit { get; set; } = default!;
    public bool IsPrimary { get; set; }
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}
