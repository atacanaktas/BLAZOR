using Yetki.Domain.Common;
using Yetki.Domain.Identity;

namespace Yetki.Domain.Sod;

/// <summary>
/// Separation of Duties kuralı. Üyeler "karşılıklı dışlayan" bir kümedir:
/// bir kullanıcı üyelerden 2 veya daha fazlasına (effective) sahipse ihlal oluşur.
/// </summary>
public class SodRule : AuditableEntity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public Severity Severity { get; set; } = Severity.High;
    public SodEnforcement Enforcement { get; set; } = SodEnforcement.Block;
    public bool IsActive { get; set; } = true;

    public ICollection<SodRuleMember> Members { get; set; } = new List<SodRuleMember>();
}

public class SodRuleMember : Entity
{
    public int SodRuleId { get; set; }
    public SodRule SodRule { get; set; } = default!;
    public SodMemberType MemberType { get; set; }
    /// <summary>MemberType'a göre PermissionId veya RoleId.</summary>
    public int MemberId { get; set; }
}

/// <summary>Tespit edilen ihlal. Sistem yetkiyi otomatik SİLMEZ; ihlali görünür kılar.</summary>
public class SodViolation : Entity
{
    public int SodRuleId { get; set; }
    public SodRule SodRule { get; set; } = default!;
    public int UserId { get; set; }
    public User User { get; set; } = default!;
    public ViolationStatus Status { get; set; } = ViolationStatus.Open;
    public ViolationDetectionSource DetectedBy { get; set; }
    public DateTime DetectedAt { get; set; }
    public DateTime LastSeenAt { get; set; }
    public DateTime? ClosedAt { get; set; }
    public string? ClosedBy { get; set; }
    public string? Note { get; set; }
    /// <summary>Çakışan üyeler ve kaynak yolları (insan okunur özet).</summary>
    public string Details { get; set; } = "";
}
