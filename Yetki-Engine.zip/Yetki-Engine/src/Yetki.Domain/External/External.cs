using Yetki.Domain.Common;
using Yetki.Domain.Rbac;

namespace Yetki.Domain.External;

/// <summary>Dış yetki sistemi (ör. RACF, CICS, LDAP).</summary>
public class ExternalSystem : AuditableEntity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ICollection<ExternalPermission> Permissions { get; set; } = new List<ExternalPermission>();
}

/// <summary>Dış sistemdeki yetki (ör. RACF transaction VADA-B0).</summary>
public class ExternalPermission : AuditableEntity
{
    public int ExternalSystemId { get; set; }
    public ExternalSystem ExternalSystem { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string? Name { get; set; }
    public string? Description { get; set; }
}

/// <summary>Permission -> gerektirdiği dış sistem yetkisi. Domain ekipleriyle zamanla doldurulur.</summary>
public class PermissionExternalMapping : IAssignment
{
    public int PermissionId { get; set; }
    public Permission Permission { get; set; } = default!;
    public int ExternalPermissionId { get; set; }
    public ExternalPermission ExternalPermission { get; set; } = default!;
    public string? Note { get; set; }
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}
