using Yetki.Domain.Common;
using Yetki.Domain.Identity;
using Yetki.Domain.Rbac;

namespace Yetki.Domain.Groups;

/// <summary>
/// Esnek kitle tanımı. İki bölümden oluşur:
///  - Kitle (audience): GroupUsers + GroupRoles (bu role DOĞRUDAN sahip herkes) + GroupOrganizationUnits (bu birimdeki herkes)
///  - Verilen yetkiler (grants): GroupPermissions + GroupGrantedRoles
/// Nested group desteklenmez. Rol-kitle eşleşmesi sadece UserRole (doğrudan) rollerle yapılır;
/// grup üzerinden gelen roller başka grubun kitlesine dahil ETMEZ (döngü/derinlik engeli).
/// </summary>
public class Group : AuditableEntity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<GroupUser> Users { get; set; } = new List<GroupUser>();
    public ICollection<GroupRole> Roles { get; set; } = new List<GroupRole>();
    public ICollection<GroupOrganizationUnit> OrganizationUnits { get; set; } = new List<GroupOrganizationUnit>();
    public ICollection<GroupPermission> GrantedPermissions { get; set; } = new List<GroupPermission>();
    public ICollection<GroupGrantedRole> GrantedRoles { get; set; } = new List<GroupGrantedRole>();
}

public class GroupUser : IAssignment
{
    public int GroupId { get; set; }
    public Group Group { get; set; } = default!;
    public int UserId { get; set; }
    public User User { get; set; } = default!;
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}

/// <summary>Kitle: bu role doğrudan sahip tüm kullanıcılar gruba dahildir.</summary>
public class GroupRole : IAssignment
{
    public int GroupId { get; set; }
    public Group Group { get; set; } = default!;
    public int RoleId { get; set; }
    public Role Role { get; set; } = default!;
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}

/// <summary>Kitle: bu organizasyon biriminde çalışan tüm kullanıcılar gruba dahildir.</summary>
public class GroupOrganizationUnit : IAssignment
{
    public int GroupId { get; set; }
    public Group Group { get; set; } = default!;
    public int OrganizationUnitId { get; set; }
    public OrganizationUnit OrganizationUnit { get; set; } = default!;
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}

/// <summary>Grant: grubun kitlesine doğrudan verilen permission.</summary>
public class GroupPermission : IAssignment
{
    public int GroupId { get; set; }
    public Group Group { get; set; } = default!;
    public int PermissionId { get; set; }
    public Permission Permission { get; set; } = default!;
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}

/// <summary>Grant: grubun kitlesine verilen rol (rolün tüm permission'ları).</summary>
public class GroupGrantedRole : IAssignment
{
    public int GroupId { get; set; }
    public Group Group { get; set; } = default!;
    public int RoleId { get; set; }
    public Role Role { get; set; } = default!;
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}
