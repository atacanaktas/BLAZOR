using Yetki.Domain.Common;
using Yetki.Domain.Rbac;

namespace Yetki.Domain.Policies;

// ============================================================================================
//  Authorization policy modeli (XACML kavramlarından esinlenmiş, XACML implementasyonu DEĞİL)
//
//  Permission  ──(M:N)──  Policy  ──(1:N)──  Rule  ──(1:1 kök)──  RuleCondition (ağaç)
//                                                                    └── ConditionParameter (key/value)
//                                                                    └── ConditionType (katalog → C# IConditionHandler)
//
//  - Permission : "Kullanıcı hangi işlemi yapmaya aday?" (RBAC ile verilir)
//  - Policy     : "Bu permission hangi koşullarda Permit/Deny olur?"  → CombiningAlgorithm ile rule sonuçlarını birleştirir
//  - Rule       : Karar üreten birim. Effect (Permit/Deny) + Condition. Condition TRUE ise Effect uygulanır, FALSE ise NotApplicable.
//  - Condition  : Boolean ifade. Prototipte tek predicate veya NOT(predicate); model AND/OR/NOT ağacını destekler.
//  - ConditionType: Condition'ın NASIL değerlendirileceğini bilen tip (davranış C# handler'da, DB'de sadece parametre).
// ============================================================================================

/// <summary>Bir permission'ın hangi koşullarda Permit/Deny sonucuna ulaşacağını tanımlar.</summary>
public class Policy : AuditableEntity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    /// <summary>Opsiyonel sahip iş alanı (ör. GISE, KREDI). Filtreleme/sahiplik için metadata.</summary>
    public string? Domain { get; set; }
    public CombiningAlgorithm CombiningAlgorithm { get; set; } = CombiningAlgorithm.DenyOverrides;
    public bool IsActive { get; set; } = true;
    /// <summary>Policy veya rule'larında her değişiklikte artar; kararlar hangi versiyonla verildiğini audit'e yazar.</summary>
    public int Version { get; set; } = 1;

    public ICollection<Rule> Rules { get; set; } = new List<Rule>();
    public ICollection<PermissionPolicy> Permissions { get; set; } = new List<PermissionPolicy>();
}

/// <summary>Policy içindeki karar kuralı. Condition TRUE → Effect; FALSE → NotApplicable; belirsiz → Indeterminate.</summary>
public class Rule : AuditableEntity
{
    public int PolicyId { get; set; }
    public Policy Policy { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public RuleEffect Effect { get; set; } = RuleEffect.Deny;
    /// <summary>Deterministik değerlendirme/raporlama sırası (FirstApplicable algoritmasında anlamlıdır).</summary>
    public int Order { get; set; }
    /// <summary>Rule karar verdiğinde döndürülecek makine-okunur neden (ör. AMOUNT_EXCEEDS_USER_LIMIT).</summary>
    public string? ReasonCode { get; set; }
    public bool IsActive { get; set; } = true;

    /// <summary>Rule'a ait tüm condition düğümleri; kök düğüm ParentId == null olandır.</summary>
    public ICollection<RuleCondition> Conditions { get; set; } = new List<RuleCondition>();
}

/// <summary>
/// Condition ifade ağacı düğümü (self-reference). İlişkisel ve SQL-dostu: JSON blob yok.
/// Düğüm ya bir Rule'a (RuleId) ya da bir ortak koşula (SharedConditionId) aittir — tam olarak biri dolu.
///  - Predicate: ConditionType + parametreler (yaprak)
///  - AllOf / AnyOf: çocukların AND / OR'u
///  - Not: tek çocuğun değili
///  - Reference: ReferencedSharedConditionId ile ortak koşula REFERANS (kopya değil; ortak koşul değişince herkes etkilenir)
/// </summary>
public class RuleCondition : Entity
{
    public int? RuleId { get; set; }
    public Rule? Rule { get; set; }
    /// <summary>Bu düğüm bir ortak koşulun ağacına aitse sahibi.</summary>
    public int? SharedConditionId { get; set; }
    public SharedCondition? SharedCondition { get; set; }
    public int? ParentId { get; set; }
    public RuleCondition? Parent { get; set; }
    public ConditionKind Kind { get; set; } = ConditionKind.Predicate;
    /// <summary>Sadece Kind=Predicate için dolu.</summary>
    public int? ConditionTypeId { get; set; }
    public ConditionType? ConditionType { get; set; }
    /// <summary>Sadece Kind=Reference için dolu: referans verilen ortak koşul.</summary>
    public int? ReferencedSharedConditionId { get; set; }
    public SharedCondition? ReferencedSharedCondition { get; set; }
    public int Order { get; set; }

    public ICollection<RuleCondition> Children { get; set; } = new List<RuleCondition>();
    public ICollection<ConditionParameter> Parameters { get; set; } = new List<ConditionParameter>();
}

/// <summary>
/// Ortak (adlandırılmış) koşul: "Banka ağı", "Mesai saati" gibi TANIMLARIN tek yerde yönetilmesi.
/// Rule'lar buna Reference düğümüyle bağlanır; Effect/Order/ReasonCode policy'deki rule'da kalır.
/// Global kapsam: yetki/güvenlik ekibi; Domain kapsam: ilgili iş ekibi (Domain alanı).
/// </summary>
public class SharedCondition : AuditableEntity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ConditionScope Scope { get; set; } = ConditionScope.Global;
    public string? Domain { get; set; }
    public bool IsActive { get; set; } = true;
    /// <summary>Tanım her değiştiğinde artar (ve kullanan policy'lerin versiyonu da artar).</summary>
    public int Version { get; set; } = 1;

    /// <summary>Bu ortak koşulun ağacındaki düğümler; kök ParentId == null olandır.</summary>
    public ICollection<RuleCondition> Nodes { get; set; } = new List<RuleCondition>();
}

/// <summary>Predicate parametresi (key/value). Değerler sabit/konfigürasyon; kullanıcıya özgü değer (ör. limit) BURADA TUTULMAZ.</summary>
public class ConditionParameter : Entity
{
    public int ConditionId { get; set; }
    public RuleCondition Condition { get; set; } = default!;
    public string Key { get; set; } = default!;
    public string Value { get; set; } = default!;
}

/// <summary>
/// Motorun desteklediği condition tipleri kataloğu. Her tip kodda bir IConditionHandler'a karşılık gelir ve
/// açılışta senkronize edilir. Kullanıcı ConditionType yaratamaz. DB'de ASLA çalıştırılabilir kod/SQL/script tutulmaz.
/// </summary>
public class ConditionType : Entity
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ConditionScope DefaultScope { get; set; }
    /// <summary>Parametre tanımları (JSON, sadece dokümantasyon/UI form üretimi için).</summary>
    public string ParameterSchemaJson { get; set; } = "[]";
    /// <summary>Handler'ın okuduğu attribute'lar (bilgi amaçlı, ör. "Context.TransactionAmount,Subject.CashWithdrawalLimit").</summary>
    public string? RequiredAttributes { get; set; }
    /// <summary>Kodda handler'ı kalmayan tip false olur; bu tipteki condition'lar Indeterminate (fail-closed) değerlendirilir.</summary>
    public bool IsAvailable { get; set; } = true;
}

public class PermissionPolicy : IAssignment
{
    public int PermissionId { get; set; }
    public Permission Permission { get; set; } = default!;
    public int PolicyId { get; set; }
    public Policy Policy { get; set; } = default!;
    public DateTime AssignedAt { get; set; }
    public string AssignedBy { get; set; } = "system";
}
