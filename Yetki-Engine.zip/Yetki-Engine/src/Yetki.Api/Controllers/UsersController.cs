using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Changes;
using Yetki.Application.Effective;
using Yetki.Domain.Identity;

namespace Yetki.Api.Controllers;

public sealed record UserUpsert(string UserName, string FullName, string? Title, string? Email, bool IsActive, bool IsOnLeave, decimal CashWithdrawalLimit, string? CustomerNo);
public sealed record AssignRoleRequest(int RoleId, DateTime? ValidUntil);
public sealed record AssignPermissionRequest(int PermissionId, string? Reason, DateTime? ValidUntil);
public sealed record AssignOrgUnitRequest(int OrgUnitId, bool IsPrimary);

[ApiController]
[Route("api/users")]
public class UsersController(
    IYetkiDbContext db,
    EffectivePermissionService effective,
    AssignmentService assignments,
    AuditWriter audit) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] string? search, [FromQuery] int page = 1, [FromQuery] int pageSize = 25, CancellationToken ct = default)
    {
        var q = db.Users.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim().ToLowerInvariant();
            q = q.Where(u => u.UserName.Contains(s) || u.FullName.ToLower().Contains(s) || (u.Title != null && u.Title.ToLower().Contains(s)));
        }
        var total = await q.CountAsync(ct);
        var items = await q.OrderBy(u => u.UserName)
            .Skip((Math.Max(page, 1) - 1) * pageSize).Take(Math.Clamp(pageSize, 1, 200))
            .Select(u => new
            {
                u.Id, u.UserName, u.FullName, u.Title, u.IsActive, u.IsOnLeave,
                orgUnits = u.OrganizationUnits.Select(o => o.OrganizationUnit.Code).ToList(),
                roles = u.Roles.Select(r => r.Role.Code).ToList()
            }).ToListAsync(ct);
        return Ok(new { total, items });
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id, CancellationToken ct)
    {
        var u = await db.Users.AsNoTracking().Where(x => x.Id == id).Select(x => new
        {
            x.Id, x.UserName, x.FullName, x.Title, x.Email, x.IsActive, x.IsOnLeave, x.CashWithdrawalLimit, x.CustomerNo,
            x.CreatedAt, x.CreatedBy, x.UpdatedAt, x.UpdatedBy,
            orgUnits = x.OrganizationUnits.Select(o => new { o.OrganizationUnitId, o.OrganizationUnit.Code, o.OrganizationUnit.Name, o.IsPrimary }).ToList(),
            roles = x.Roles.Select(r => new { r.RoleId, r.Role.Code, r.Role.Name, r.Role.IsActive, r.AssignedAt, r.AssignedBy, r.ValidUntil }).ToList(),
            directPermissions = x.DirectPermissions.Select(p => new { p.PermissionId, p.Permission.Code, p.Permission.Name, p.Reason, p.AssignedAt, p.AssignedBy, p.ValidUntil }).ToList()
        }).FirstOrDefaultAsync(ct) ?? throw new NotFoundException("Kullanıcı", id);

        var explicitGroups = await db.GroupUsers.AsNoTracking().Where(g => g.UserId == id)
            .Select(g => new { g.GroupId, g.Group.Code, g.Group.Name }).ToListAsync(ct);
        return Ok(new { user = u, explicitGroups });
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] UserUpsert dto, CancellationToken ct)
    {
        var userName = dto.UserName.Trim().ToLowerInvariant();
        if (await db.Users.AnyAsync(u => u.UserName == userName, ct)) throw new ConflictException($"Kullanıcı adı zaten var: {userName}");
        var user = new User
        {
            UserName = userName, FullName = dto.FullName, Title = dto.Title, Email = dto.Email, IsActive = dto.IsActive,
            IsOnLeave = dto.IsOnLeave, CashWithdrawalLimit = dto.CashWithdrawalLimit, CustomerNo = dto.CustomerNo
        };
        db.Users.Add(user);
        audit.Management("UserCreated", "User", userName, $"Kullanıcı oluşturuldu: {userName}", dto);
        await db.SaveChangesAsync(ct);
        return Ok(new { user.Id });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] UserUpsert dto, CancellationToken ct)
    {
        var user = await db.Users.FindAsync([id], ct) ?? throw new NotFoundException("Kullanıcı", id);
        user.FullName = dto.FullName; user.Title = dto.Title; user.Email = dto.Email; user.IsActive = dto.IsActive;
        user.IsOnLeave = dto.IsOnLeave; user.CashWithdrawalLimit = dto.CashWithdrawalLimit; user.CustomerNo = dto.CustomerNo;
        audit.Management("UserUpdated", "User", user.UserName, $"Kullanıcı güncellendi: {user.UserName}", dto);
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    /// <summary>Effective permission'lar + her birinin kaynağı (authorization path).</summary>
    [HttpGet("{id:int}/effective")]
    public async Task<EffectivePermissionSet> Effective(int id, CancellationToken ct) =>
        await effective.GetAsync(id, null, useCache: true, ct) ?? throw new NotFoundException("Kullanıcı", id);

    [HttpGet("{id:int}/violations")]
    public async Task<IActionResult> Violations(int id, CancellationToken ct) =>
        Ok(await db.SodViolations.AsNoTracking().Where(v => v.UserId == id).OrderByDescending(v => v.DetectedAt)
            .Select(v => new { v.Id, v.SodRuleId, rule = v.SodRule.Code, v.SodRule.Severity, v.Status, v.DetectedBy, v.DetectedAt, v.LastSeenAt, v.Details })
            .ToListAsync(ct));

    [HttpGet("{id:int}/provisioning")]
    public async Task<IActionResult> Provisioning(int id, CancellationToken ct) =>
        Ok(await db.ProvisioningActions.AsNoTracking().Where(p => p.UserId == id).OrderByDescending(p => p.Id).Take(100).ToListAsync(ct));

    [HttpPost("{id:int}/roles")]
    public Task<ChangeImpactResult> AssignRole(int id, [FromBody] AssignRoleRequest r, CancellationToken ct) =>
        assignments.AssignRoleToUserAsync(id, r.RoleId, r.ValidUntil, ct);

    [HttpDelete("{id:int}/roles/{roleId:int}")]
    public Task<ChangeImpactResult> RevokeRole(int id, int roleId, CancellationToken ct) =>
        assignments.RevokeRoleFromUserAsync(id, roleId, ct);

    [HttpPost("{id:int}/permissions")]
    public Task<ChangeImpactResult> GrantPermission(int id, [FromBody] AssignPermissionRequest r, CancellationToken ct) =>
        assignments.GrantPermissionToUserAsync(id, r.PermissionId, r.Reason, r.ValidUntil, ct);

    [HttpDelete("{id:int}/permissions/{permissionId:int}")]
    public Task<ChangeImpactResult> RevokePermission(int id, int permissionId, CancellationToken ct) =>
        assignments.RevokePermissionFromUserAsync(id, permissionId, ct);

    [HttpPost("{id:int}/org-units")]
    public Task<ChangeImpactResult> AddOrgUnit(int id, [FromBody] AssignOrgUnitRequest r, CancellationToken ct) =>
        assignments.SetUserOrgUnitAsync(id, r.OrgUnitId, add: true, r.IsPrimary, ct);

    [HttpDelete("{id:int}/org-units/{orgUnitId:int}")]
    public Task<ChangeImpactResult> RemoveOrgUnit(int id, int orgUnitId, CancellationToken ct) =>
        assignments.SetUserOrgUnitAsync(id, orgUnitId, add: false, false, ct);
}
