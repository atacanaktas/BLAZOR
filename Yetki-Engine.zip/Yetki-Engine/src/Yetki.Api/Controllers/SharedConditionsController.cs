using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Definitions;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine;

namespace Yetki.Api.Controllers;

/// <summary>Ortak (adlandırılmış) koşullar: tanım tek yerde, rule'lar referans verir.</summary>
[ApiController]
[Route("api/shared-conditions")]
public class SharedConditionsController(IYetkiDbContext db, SharedConditionService service, PolicyDefinitionLoader loader) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct)
    {
        var items = await db.SharedConditions.AsNoTracking().OrderBy(s => s.Code)
            .Select(s => new { s.Id, s.Code, s.Name, s.Description, s.Scope, s.Domain, s.IsActive, s.Version, s.UpdatedAt, s.UpdatedBy })
            .ToListAsync(ct);
        var result = new List<object>();
        foreach (var s in items)
        {
            var root = await loader.LoadSharedConditionAsync(s.Id, ct);
            var usages = await service.UsagesAsync(s.Id, ct);
            result.Add(new
            {
                s.Id, s.Code, s.Name, s.Description, s.Scope, s.Domain, s.IsActive, s.Version, s.UpdatedAt, s.UpdatedBy,
                expression = PolicyEvaluator.Render(root),
                usageCount = usages.Count,
                policies = usages.Select(u => u.Policy).Distinct().ToList()
            });
        }
        return Ok(result);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id, CancellationToken ct)
    {
        var s = await db.SharedConditions.AsNoTracking().Where(x => x.Id == id)
            .Select(x => new { x.Id, x.Code, x.Name, x.Description, x.Scope, x.Domain, x.IsActive, x.Version, x.CreatedAt, x.CreatedBy, x.UpdatedAt, x.UpdatedBy })
            .FirstOrDefaultAsync(ct) ?? throw new NotFoundException("Ortak koşul", id);
        var root = await loader.LoadSharedConditionAsync(id, ct);
        return Ok(new
        {
            sharedCondition = s,
            expression = PolicyEvaluator.Render(root),
            expandedExpression = PolicyEvaluator.Render(root, expand: true),
            condition = ConditionView.From(root),
            usages = await service.UsagesAsync(id, ct)
        });
    }

    [HttpGet("{id:int}/usages")]
    public Task<IReadOnlyList<SharedConditionUsage>> Usages(int id, CancellationToken ct) => service.UsagesAsync(id, ct);

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] SharedConditionUpsert dto, CancellationToken ct) =>
        Ok(new { (await service.CreateAsync(dto, ct)).Id });

    /// <summary>Tanımı değiştirir; kullanan TÜM policy'lerin versiyonu artar. Etkisi önce /api/simulation/policy-impact ile görülebilir.</summary>
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] SharedConditionUpsert dto, CancellationToken ct)
    {
        await service.UpdateAsync(id, dto, ct);
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await service.DeleteAsync(id, ct);
        return NoContent();
    }
}
