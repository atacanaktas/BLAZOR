using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Definitions;
using Yetki.Application.Sod;
using Yetki.Domain.Common;

namespace Yetki.Api.Controllers;

public sealed record ViolationStatusRequest(ViolationStatus Status, string? Note);

[ApiController]
[Route("api/sod")]
public class SodController(IYetkiDbContext db, PolicyManagementService service, SodService sod, AuditWriter audit, IClock clock, ICurrentActor actor)
    : ControllerBase
{
    [HttpGet("rules")]
    public async Task<IActionResult> Rules(CancellationToken ct)
    {
        var rules = await db.SodRules.AsNoTracking().OrderBy(r => r.Code).Select(r => new
        {
            r.Id, r.Code, r.Name, r.Description, r.Severity, r.Enforcement, r.IsActive,
            members = r.Members.Select(m => new { m.MemberType, m.MemberId }).ToList(),
            openViolations = db.SodViolations.Count(v => v.SodRuleId == r.Id && v.Status != ViolationStatus.Resolved)
        }).ToListAsync(ct);

        var permIds = rules.SelectMany(r => r.members).Where(m => m.MemberType == SodMemberType.Permission).Select(m => m.MemberId).ToList();
        var roleIds = rules.SelectMany(r => r.members).Where(m => m.MemberType == SodMemberType.Role).Select(m => m.MemberId).ToList();
        var perms = await db.Permissions.AsNoTracking().Where(p => permIds.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p.Code, ct);
        var roles = await db.Roles.AsNoTracking().Where(p => roleIds.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p.Code, ct);

        return Ok(rules.Select(r => new
        {
            r.Id, r.Code, r.Name, r.Description, r.Severity, r.Enforcement, r.IsActive, r.openViolations,
            members = r.members.Select(m => new
            {
                m.MemberType, m.MemberId,
                code = m.MemberType == SodMemberType.Permission ? perms.GetValueOrDefault(m.MemberId) : roles.GetValueOrDefault(m.MemberId)
            })
        }));
    }

    [HttpPost("rules")]
    public Task<SodRuleCreated> Create([FromBody] SodRuleUpsert dto, CancellationToken ct) => service.CreateSodRuleAsync(dto, ct);

    [HttpPut("rules/{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] SodRuleUpsert dto, CancellationToken ct)
    {
        await service.UpdateSodRuleAsync(id, dto, ct);
        return NoContent();
    }

    [HttpGet("violations")]
    public async Task<IActionResult> Violations([FromQuery] ViolationStatus? status, CancellationToken ct)
    {
        var q = db.SodViolations.AsNoTracking();
        if (status is not null) q = q.Where(v => v.Status == status);
        return Ok(await q.OrderByDescending(v => v.LastSeenAt).Select(v => new
        {
            v.Id, v.UserId, v.User.UserName, v.User.FullName, v.SodRuleId, rule = v.SodRule.Code, ruleName = v.SodRule.Name,
            v.SodRule.Severity, v.SodRule.Enforcement, v.Status, v.DetectedBy, v.DetectedAt, v.LastSeenAt, v.ClosedAt, v.ClosedBy, v.Note, v.Details
        }).ToListAsync(ct));
    }

    /// <summary>Retrospektif tarama: mevcut atamaları tüm aktif SoD kurallarına göre tarar. Yetki silmez.</summary>
    [HttpPost("scan")]
    public Task<SodScanResult> Scan(CancellationToken ct) => sod.ScanAsync(ct);

    [HttpPut("violations/{id:int}")]
    public async Task<IActionResult> UpdateViolation(int id, [FromBody] ViolationStatusRequest r, CancellationToken ct)
    {
        var v = await db.SodViolations.Include(x => x.SodRule).Include(x => x.User).FirstOrDefaultAsync(x => x.Id == id, ct)
                ?? throw new NotFoundException("İhlal", id);
        v.Status = r.Status;
        v.Note = r.Note;
        if (r.Status is ViolationStatus.Resolved or ViolationStatus.AcceptedRisk) { v.ClosedAt = clock.UtcNow; v.ClosedBy = actor.Name; }
        audit.Management("SodViolationUpdated", "SodViolation", id, $"{v.User.UserName} / {v.SodRule.Code} ihlali: {r.Status}", r);
        await db.SaveChangesAsync(ct);
        return NoContent();
    }
}
