using Microsoft.AspNetCore.Mvc;
using Yetki.Application.Abstractions;
using Yetki.Application.Context;
using Yetki.Application.Effective;
using Yetki.Application.Evaluation;

namespace Yetki.Api.Controllers;

/// <summary>
/// Runtime authorization uçları (SDK'lar ve uygulamalar çağırır).
/// </summary>
[ApiController]
[Route("api/authorization")]
public class AuthorizationController(AuthorizationEvaluator evaluator, EffectivePermissionService effective) : ControllerBase
{
    /// <summary>İşlem anı kararı. Context-dependent policy'ler burada değerlendirilir; sonuç açıklanabilir döner.</summary>
    [HttpPost("evaluate")]
    public async Task<AuthorizationDecision> Evaluate([FromBody] AuthorizationRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Permission)) throw new ValidationException("Permission zorunlu.");
        if (string.IsNullOrWhiteSpace(request.Subject?.UserName) && request.Subject?.UserId is null) throw new ValidationException("Subject (userName veya userId) zorunlu.");
        request.CorrelationId ??= HttpContext.TraceIdentifier;
        return await evaluator.EvaluateAsync(request, EvaluationOptions.Default, ct);
    }

    /// <summary>
    /// Login-time statik permission seti (cache'li). Menü/ekran görünürlüğü için kullanılabilir.
    /// requiresRuntimeEvaluation=true olan permission'lar işlem anında MUTLAKA /evaluate ile kontrol edilmelidir.
    /// </summary>
    [HttpGet("users/{userName}/permissions")]
    public async Task<IActionResult> LoginPermissions(string userName, CancellationToken ct)
    {
        var set = await effective.GetByUserNameAsync(userName, useCache: true, ct);
        if (set is null) throw new NotFoundException("Kullanıcı", userName);
        if (!set.IsActive) return Ok(new { set.UserName, set.Version, isActive = false, permissions = Array.Empty<object>() });
        return Ok(new
        {
            set.UserName,
            set.Version,
            isActive = true,
            permissions = set.Permissions.Select(p => new { p.Code, p.RequiresRuntimeEvaluation })
        });
    }

    /// <summary>"Bu kullanıcı bu permission'ı neden aldı?"</summary>
    [HttpGet("users/{userName}/explain/{permission}")]
    public async Task<IActionResult> Explain(string userName, string permission, CancellationToken ct)
    {
        var set = await effective.GetByUserNameAsync(userName, useCache: true, ct) ?? throw new NotFoundException("Kullanıcı", userName);
        var p = set.Find(permission);
        return Ok(new
        {
            set.UserName,
            permission = permission.ToUpperInvariant(),
            granted = p is not null,
            p?.RequiresRuntimeEvaluation,
            sources = p?.Sources ?? []
        });
    }

    /// <summary>Normalize context anahtarları (SDK ve test ekranı için).</summary>
    [HttpGet("context-keys")]
    public IActionResult ContextKeys() => Ok(new
    {
        environment = new[] { AuthContextKeys.CurrentTime, AuthContextKeys.IpAddress, AuthContextKeys.Channel, AuthContextKeys.Platform, AuthContextKeys.DeviceId, AuthContextKeys.DeviceCompliant, AuthContextKeys.Application },
        context = new[] { AuthContextKeys.TransactionAmount, AuthContextKeys.Currency, AuthContextKeys.CustomerId, AuthContextKeys.AccountNo, AuthContextKeys.BranchCode },
        note = "Environment değerleri SDK/motor tarafından üretilir (CurrentTime daima motor saatidir); Context değerleri DTO'da [AuthContext] ile işaretlenir."
    });
}
