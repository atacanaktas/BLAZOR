using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Changes;
using Yetki.Application.Common;
using Yetki.Application.Definitions;
using Yetki.Application.Effective;
using Yetki.Domain.External;
using Yetki.Domain.Rbac;

namespace Yetki.Api.Controllers;

public sealed record RoleUpsert(string Code, string Name, string? Description, bool IsActive = true);
public sealed record PermissionUpsert(string Code, string Name, string? Description, string? Domain, bool IsActive = true);
public sealed record IdRequest(int Id);
public sealed record ExternalMappingRequest(int ExternalPermissionId, string? Note);

[ApiController]
[Route("api/roles")]
public class RolesController(IYetkiDbContext db, AssignmentService assignments, AuditWriter audit) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct) =>
        Ok(await db.Roles.AsNoTracking().OrderBy(r => r.Code).Select(r => new
        {
            r.Id, r.Code, r.Name, r.Description, r.IsActive,
            permissionCount = r.Permissions.Count,
            userCount = db.UserRoles.Count(ur => ur.RoleId == r.Id),
            permissions = r.Permissions.Select(p => p.Permission.Code).ToList()
        }).ToListAsync(ct));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id, CancellationToken ct)
    {
        var role = await db.Roles.AsNoTracking().Where(r => r.Id == id).Select(r => new
        {
            r.Id, r.Code, r.Name, r.Description, r.IsActive, r.CreatedAt, r.CreatedBy, r.UpdatedAt, r.UpdatedBy,
            permissions = r.Permissions.Select(p => new { p.PermissionId, p.Permission.Code, p.Permission.Name, p.Permission.Domain, p.AssignedAt, p.AssignedBy }).ToList()
        }).FirstOrDefaultAsync(ct) ?? throw new NotFoundException("Rol", id);

        var users = await db.UserRoles.AsNoTracking().Where(x => x.RoleId == id)
            .Select(x => new { x.UserId, x.User.UserName, x.User.FullName, x.AssignedAt, x.AssignedBy, x.ValidUntil }).ToListAsync(ct);
        var grantingGroups = await db.GroupGrantedRoles.AsNoTracking().Where(x => x.RoleId == id)
            .Select(x => new { x.GroupId, x.Group.Code, x.Group.Name }).ToListAsync(ct);
        var audienceGroups = await db.GroupRoles.AsNoTracking().Where(x => x.RoleId == id)
            .Select(x => new { x.GroupId, x.Group.Code, x.Group.Name }).ToListAsync(ct);
        return Ok(new { role, users, grantingGroups, audienceGroups });
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] RoleUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Roles.AnyAsync(r => r.Code == code, ct)) throw new ConflictException($"Rol kodu zaten var: {code}");
        var role = new Role { Code = code, Name = dto.Name, Description = dto.Description, IsActive = dto.IsActive };
        db.Roles.Add(role);
        audit.Management("RoleCreated", "Role", code, $"Rol oluşturuldu: {code}", dto);
        await db.SaveChangesAsync(ct);
        return Ok(new { role.Id });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] RoleUpsert dto, CancellationToken ct)
    {
        var role = await db.Roles.FindAsync([id], ct) ?? throw new NotFoundException("Rol", id);
        role.Name = dto.Name; role.Description = dto.Description; role.IsActive = dto.IsActive;
        audit.Management("RoleUpdated", "Role", role.Code, $"Rol güncellendi: {role.Code} (aktif={dto.IsActive})", dto);
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    [HttpPost("{id:int}/permissions")]
    public Task<ChangeImpactResult> AddPermission(int id, [FromBody] IdRequest r, CancellationToken ct) =>
        assignments.SetRolePermissionAsync(id, r.Id, add: true, ct);

    [HttpDelete("{id:int}/permissions/{permissionId:int}")]
    public Task<ChangeImpactResult> RemovePermission(int id, int permissionId, CancellationToken ct) =>
        assignments.SetRolePermissionAsync(id, permissionId, add: false, ct);
}

[ApiController]
[Route("api/permissions")]
public class PermissionsController(
    IYetkiDbContext db, PermissionHolderService holders, PolicyManagementService policies, AuditWriter audit, IClock clock, ICurrentActor actor)
    : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] string? search, [FromQuery] string? domain, CancellationToken ct)
    {
        var q = db.Permissions.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim().ToUpperInvariant();
            q = q.Where(p => p.Code.Contains(s) || p.Name.ToUpper().Contains(s));
        }
        if (!string.IsNullOrWhiteSpace(domain)) q = q.Where(p => p.Domain == domain);
        return Ok(await q.OrderBy(p => p.Code).Select(p => new
        {
            p.Id, p.Code, p.Name, p.Description, p.Domain, p.IsActive,
            roleCount = p.Roles.Count,
            policies = p.Policies.Select(x => x.Policy.Code).ToList(),
            externalCount = db.PermissionExternalMappings.Count(m => m.PermissionId == p.Id)
        }).ToListAsync(ct));
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id, CancellationToken ct)
    {
        var permission = await db.Permissions.AsNoTracking().Where(p => p.Id == id).Select(p => new
        {
            p.Id, p.Code, p.Name, p.Description, p.Domain, p.IsActive, p.CreatedAt, p.CreatedBy, p.UpdatedAt, p.UpdatedBy,
            roles = p.Roles.Select(r => new { r.RoleId, r.Role.Code, r.Role.Name }).ToList(),
            policies = p.Policies.Select(x => new { x.PolicyId, x.Policy.Code, x.Policy.Name, x.Policy.IsActive }).ToList()
        }).FirstOrDefaultAsync(ct) ?? throw new NotFoundException("Permission", id);

        var groups = await db.GroupPermissions.AsNoTracking().Where(g => g.PermissionId == id)
            .Select(g => new { g.GroupId, g.Group.Code, g.Group.Name }).ToListAsync(ct);
        var external = await db.PermissionExternalMappings.AsNoTracking().Where(m => m.PermissionId == id)
            .Select(m => new { m.ExternalPermissionId, system = m.ExternalPermission.ExternalSystem.Code, m.ExternalPermission.Code, m.ExternalPermission.Name, m.Note, m.AssignedBy, m.AssignedAt })
            .ToListAsync(ct);
        return Ok(new { permission, groups, external });
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] PermissionUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Permissions.AnyAsync(p => p.Code == code, ct)) throw new ConflictException($"Permission kodu zaten var: {code}");

        // Soft advisory: benzer kod/isim uyarısı (engellemez). İleride AI/benzerlik servisi bu noktaya bağlanır.
        var similar = await FindSimilarAsync(code, dto.Name, ct);

        var p = new Permission { Code = code, Name = dto.Name, Description = dto.Description, Domain = dto.Domain, IsActive = dto.IsActive };
        db.Permissions.Add(p);
        audit.Management("PermissionCreated", "Permission", code, $"Permission oluşturuldu: {code}", dto);
        await db.SaveChangesAsync(ct);
        return Ok(new { p.Id, advisories = similar });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] PermissionUpsert dto, CancellationToken ct)
    {
        var p = await db.Permissions.FindAsync([id], ct) ?? throw new NotFoundException("Permission", id);
        p.Name = dto.Name; p.Description = dto.Description; p.Domain = dto.Domain; p.IsActive = dto.IsActive;
        audit.Management("PermissionUpdated", "Permission", p.Code, $"Permission güncellendi: {p.Code} (aktif={dto.IsActive})", dto);
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    /// <summary>Bu permission kimde var, hangi yoldan?</summary>
    [HttpGet("{id:int}/holders")]
    public async Task<IReadOnlyList<PermissionHolder>> Holders(int id, CancellationToken ct) => await holders.FindHoldersAsync(id, ct);

    [HttpPost("{id:int}/policies")]
    public async Task<IActionResult> AttachPolicy(int id, [FromBody] IdRequest r, CancellationToken ct)
    {
        await policies.SetPermissionPolicyAsync(id, r.Id, add: true, ct);
        return NoContent();
    }

    [HttpDelete("{id:int}/policies/{policyId:int}")]
    public async Task<IActionResult> DetachPolicy(int id, int policyId, CancellationToken ct)
    {
        await policies.SetPermissionPolicyAsync(id, policyId, add: false, ct);
        return NoContent();
    }

    [HttpPost("{id:int}/external-mappings")]
    public async Task<IActionResult> AddMapping(int id, [FromBody] ExternalMappingRequest r, CancellationToken ct)
    {
        var p = await db.Permissions.FindAsync([id], ct) ?? throw new NotFoundException("Permission", id);
        var ext = await db.ExternalPermissions.Include(e => e.ExternalSystem).FirstOrDefaultAsync(e => e.Id == r.ExternalPermissionId, ct)
                  ?? throw new NotFoundException("Dış yetki", r.ExternalPermissionId);
        if (await db.PermissionExternalMappings.AnyAsync(m => m.PermissionId == id && m.ExternalPermissionId == ext.Id, ct))
            throw new ConflictException("Eşleme zaten var.");
        db.PermissionExternalMappings.Add(new PermissionExternalMapping { PermissionId = id, ExternalPermissionId = ext.Id, Note = r.Note, AssignedAt = clock.UtcNow, AssignedBy = actor.Name });
        audit.Management("ExternalMappingChanged", "Permission", p.Code, $"{p.Code} -> {ext.ExternalSystem.Code}:{ext.Code} eşlemesi eklendi");
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    [HttpDelete("{id:int}/external-mappings/{externalPermissionId:int}")]
    public async Task<IActionResult> RemoveMapping(int id, int externalPermissionId, CancellationToken ct)
    {
        var m = await db.PermissionExternalMappings.Include(x => x.Permission).Include(x => x.ExternalPermission)
                    .FirstOrDefaultAsync(x => x.PermissionId == id && x.ExternalPermissionId == externalPermissionId, ct)
                ?? throw new NotFoundException("Eşleme", $"{id}/{externalPermissionId}");
        db.PermissionExternalMappings.Remove(m);
        audit.Management("ExternalMappingChanged", "Permission", m.Permission.Code, $"{m.Permission.Code} -> {m.ExternalPermission.Code} eşlemesi kaldırıldı");
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    private async Task<List<string>> FindSimilarAsync(string code, string name, CancellationToken ct)
    {
        var all = await db.Permissions.AsNoTracking().Select(p => new { p.Code, p.Name }).ToListAsync(ct);
        var tokens = code.Split('_', StringSplitOptions.RemoveEmptyEntries).ToHashSet();
        return all
            .Where(p => string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase)
                        || (tokens.Count > 1 && p.Code.Split('_').Count(tokens.Contains) >= tokens.Count - 1))
            .Select(p => $"Benzer permission mevcut: {p.Code} ({p.Name})")
            .Take(5).ToList();
    }
}

[ApiController]
[Route("api/org-units")]
public class OrgUnitsController(IYetkiDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct) =>
        Ok(await db.OrganizationUnits.AsNoTracking().OrderBy(o => o.Code).Select(o => new
        {
            o.Id, o.Code, o.Name, o.Type, parent = o.Parent != null ? o.Parent.Code : null,
            userCount = db.UserOrganizationUnits.Count(x => x.OrganizationUnitId == o.Id)
        }).ToListAsync(ct));
}

[ApiController]
[Route("api/external")]
public class ExternalController(IYetkiDbContext db, AuditWriter audit) : ControllerBase
{
    public sealed record SystemUpsert(string Code, string Name, string? Description);
    public sealed record ExternalPermissionUpsert(string Code, string? Name, string? Description);

    [HttpGet("systems")]
    public async Task<IActionResult> Systems(CancellationToken ct) =>
        Ok(await db.ExternalSystems.AsNoTracking().OrderBy(s => s.Code).Select(s => new
        {
            s.Id, s.Code, s.Name, s.Description,
            permissions = s.Permissions.OrderBy(p => p.Code).Select(p => new
            {
                p.Id, p.Code, p.Name, p.Description,
                mappedFrom = db.PermissionExternalMappings.Where(m => m.ExternalPermissionId == p.Id).Select(m => m.Permission.Code).ToList()
            }).ToList()
        }).ToListAsync(ct));

    [HttpPost("systems")]
    public async Task<IActionResult> CreateSystem([FromBody] SystemUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.ExternalSystems.AnyAsync(s => s.Code == code, ct)) throw new ConflictException($"Sistem kodu zaten var: {code}");
        var s = new ExternalSystem { Code = code, Name = dto.Name, Description = dto.Description };
        db.ExternalSystems.Add(s);
        audit.Management("ExternalSystemCreated", "ExternalSystem", code, $"Dış sistem eklendi: {code}");
        await db.SaveChangesAsync(ct);
        return Ok(new { s.Id });
    }

    [HttpPost("systems/{id:int}/permissions")]
    public async Task<IActionResult> CreatePermission(int id, [FromBody] ExternalPermissionUpsert dto, CancellationToken ct)
    {
        var s = await db.ExternalSystems.FindAsync([id], ct) ?? throw new NotFoundException("Dış sistem", id);
        var code = dto.Code.Trim();
        if (await db.ExternalPermissions.AnyAsync(p => p.ExternalSystemId == id && p.Code == code, ct)) throw new ConflictException($"Dış yetki zaten var: {code}");
        var p = new ExternalPermission { ExternalSystemId = id, Code = code, Name = dto.Name, Description = dto.Description };
        db.ExternalPermissions.Add(p);
        audit.Management("ExternalPermissionCreated", "ExternalPermission", code, $"{s.Code} sistemine dış yetki eklendi: {code}");
        await db.SaveChangesAsync(ct);
        return Ok(new { p.Id });
    }
}
