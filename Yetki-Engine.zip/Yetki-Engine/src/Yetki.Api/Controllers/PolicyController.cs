using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Definitions;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine;

namespace Yetki.Api.Controllers;

/// <summary>Condition ağacının API gösterimi (id'ler What-If parametre override'ı için gerekir).</summary>
/// <summary>Kind=Reference ise SharedCondition = ortak koşul kodu ve Children[0] = çözülmüş tanımı (salt okunur gösterim).</summary>
public sealed record ConditionView(int Id, string Kind, string? ConditionType, IReadOnlyDictionary<string, string> Parameters,
    IReadOnlyList<ConditionView> Children, string? SharedCondition = null, int? SharedConditionVersion = null)
{
    public static ConditionView? From(ConditionNode? n) => n is null ? null :
        new(n.Id, n.Kind.ToString(), n.ConditionTypeCode, n.Parameters, n.Children.Select(c => From(c)!).ToList(), n.ReferenceCode, n.ReferenceVersion);
}

public sealed record RuleView(
    int Id, string Code, string Name, string? Description, string Effect, int Order, string? ReasonCode, bool IsActive,
    string Expression, ConditionView? Condition);

[ApiController]
[Route("api/policies")]
public class PoliciesController(IYetkiDbContext db, PolicyManagementService service, PolicyDefinitionLoader loader) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct)
    {
        var policies = await db.Policies.AsNoTracking().OrderBy(p => p.Code).Select(p => new
        {
            p.Id, p.Code, p.Name, p.Description, p.Domain, p.IsActive, p.CombiningAlgorithm, p.Version,
            permissions = p.Permissions.Select(x => x.Permission.Code).ToList()
        }).ToListAsync(ct);
        var defs = (await loader.LoadPoliciesAsync(policies.Select(p => p.Id).ToList(), null, activeOnly: false, ct)).ToDictionary(d => d.PolicyId);
        return Ok(policies.Select(p => new
        {
            p.Id, p.Code, p.Name, p.Description, p.Domain, p.IsActive, p.CombiningAlgorithm, p.Version, p.permissions,
            rules = defs.TryGetValue(p.Id, out var d) ? ToViews(d.Rules) : []
        }));
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id, CancellationToken ct)
    {
        var p = await db.Policies.AsNoTracking().Where(x => x.Id == id).Select(x => new
        {
            x.Id, x.Code, x.Name, x.Description, x.Domain, x.IsActive, x.CombiningAlgorithm, x.Version,
            x.CreatedAt, x.CreatedBy, x.UpdatedAt, x.UpdatedBy,
            permissions = x.Permissions.Select(pp => new { pp.PermissionId, pp.Permission.Code, pp.Permission.Name }).ToList()
        }).FirstOrDefaultAsync(ct) ?? throw new NotFoundException("Policy", id);
        var def = (await loader.LoadPoliciesAsync([id], null, activeOnly: false, ct)).Single();
        return Ok(new { policy = p, rules = ToViews(def.Rules) });
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] PolicyUpsert dto, CancellationToken ct) =>
        Ok(new { (await service.CreatePolicyAsync(dto, ct)).Id });

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] PolicyUpsert dto, CancellationToken ct)
    {
        await service.UpdatePolicyAsync(id, dto, ct);
        return NoContent();
    }

    /// <summary>Policy'ye yeni rule (Effect + Condition) ekler.</summary>
    [HttpPost("{id:int}/rules")]
    public async Task<IActionResult> CreateRule(int id, [FromBody] RuleUpsert dto, CancellationToken ct) =>
        Ok(new { (await service.CreateRuleAsync(id, dto, ct)).Id });

    internal static IReadOnlyList<RuleView> ToViews(IEnumerable<RuleDefinition> rules) => rules
        .OrderBy(r => r.Order).ThenBy(r => r.Code, StringComparer.Ordinal)
        .Select(r => new RuleView(r.RuleId, r.Code, r.Name, r.Description, r.Effect.ToString(), r.Order, r.ReasonCode, r.IsActive,
            PolicyEvaluator.Render(r.Condition), ConditionView.From(r.Condition)))
        .ToList();
}

[ApiController]
[Route("api")]
public class RulesController(IYetkiDbContext db, PolicyManagementService service, PolicyDefinitionLoader loader) : ControllerBase
{
    /// <summary>Condition tipleri kataloğu (koddaki IConditionHandler'lardan senkronize).</summary>
    [HttpGet("condition-types")]
    public async Task<IActionResult> ConditionTypes(CancellationToken ct) =>
        Ok(await db.ConditionTypes.AsNoTracking().OrderBy(t => t.Code).Select(t => new
        {
            t.Id, t.Code, t.Name, t.Description, t.DefaultScope, t.ParameterSchemaJson, t.RequiredAttributes, t.IsAvailable,
            usageCount = db.RuleConditions.Count(c => c.ConditionTypeId == t.Id)
        }).ToListAsync(ct));

    /// <summary>Tüm policy'lerdeki rule'lar (salt okunur genel bakış).</summary>
    [HttpGet("rules")]
    public async Task<IActionResult> List(CancellationToken ct)
    {
        var policies = await db.Policies.AsNoTracking().Select(p => new { p.Id, p.Code }).ToListAsync(ct);
        var defs = await loader.LoadPoliciesAsync(policies.Select(p => p.Id).ToList(), null, activeOnly: false, ct);
        return Ok(defs.SelectMany(d => PoliciesController.ToViews(d.Rules).Select(r => new
        {
            r.Id, r.Code, r.Name, r.Description, r.Effect, r.Order, r.ReasonCode, r.IsActive, r.Expression, r.Condition,
            policyId = d.PolicyId, policy = d.Code
        })).OrderBy(r => r.policy).ThenBy(r => r.Order));
    }

    [HttpPut("rules/{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] RuleUpsert dto, CancellationToken ct)
    {
        await service.UpdateRuleAsync(id, dto, ct);
        return NoContent();
    }

    [HttpDelete("rules/{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await service.DeleteRuleAsync(id, ct);
        return NoContent();
    }
}
