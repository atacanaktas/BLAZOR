using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Changes;
using Yetki.Application.Common;
using Yetki.Application.Effective;
using Yetki.Domain.Groups;

namespace Yetki.Api.Controllers;

public sealed record GroupUpsert(string Code, string Name, string? Description, bool IsActive = true);
public sealed record GroupItemRequest(GroupChangeKind Kind, int TargetId);

[ApiController]
[Route("api/groups")]
public class GroupsController(IYetkiDbContext db, AssignmentService assignments, AuthorizationChangeService changes, AuditWriter audit) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct) =>
        Ok(await db.Groups.AsNoTracking().OrderBy(g => g.Code).Select(g => new
        {
            g.Id, g.Code, g.Name, g.Description, g.IsActive,
            audience = new
            {
                users = g.Users.Count,
                roles = g.Roles.Select(r => r.Role.Code).ToList(),
                orgUnits = g.OrganizationUnits.Select(o => o.OrganizationUnit.Code).ToList()
            },
            grants = new
            {
                permissions = g.GrantedPermissions.Select(p => p.Permission.Code).ToList(),
                roles = g.GrantedRoles.Select(r => r.Role.Code).ToList()
            }
        }).ToListAsync(ct));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id, CancellationToken ct)
    {
        var group = await db.Groups.AsNoTracking().Where(g => g.Id == id).Select(g => new
        {
            g.Id, g.Code, g.Name, g.Description, g.IsActive, g.CreatedAt, g.CreatedBy, g.UpdatedAt, g.UpdatedBy,
            audienceUsers = g.Users.Select(x => new { id = x.UserId, code = x.User.UserName, name = x.User.FullName, x.AssignedBy, x.AssignedAt }).ToList(),
            audienceRoles = g.Roles.Select(x => new { id = x.RoleId, code = x.Role.Code, name = x.Role.Name, x.AssignedBy, x.AssignedAt }).ToList(),
            audienceOrgUnits = g.OrganizationUnits.Select(x => new { id = x.OrganizationUnitId, code = x.OrganizationUnit.Code, name = x.OrganizationUnit.Name, x.AssignedBy, x.AssignedAt }).ToList(),
            grantedPermissions = g.GrantedPermissions.Select(x => new { id = x.PermissionId, code = x.Permission.Code, name = x.Permission.Name, x.AssignedBy, x.AssignedAt }).ToList(),
            grantedRoles = g.GrantedRoles.Select(x => new { id = x.RoleId, code = x.Role.Code, name = x.Role.Name, x.AssignedBy, x.AssignedAt }).ToList()
        }).FirstOrDefaultAsync(ct) ?? throw new NotFoundException("Grup", id);

        // Çözümlenmiş kitle: kurallardan hesaplanan gerçek üyeler
        var memberIds = (await changes.GroupAudienceAsync(id, ct)).ToList();
        var members = await db.Users.AsNoTracking().Where(u => memberIds.Contains(u.Id))
            .OrderBy(u => u.UserName).Select(u => new { u.Id, u.UserName, u.FullName, u.IsActive }).ToListAsync(ct);
        return Ok(new { group, resolvedMembers = members });
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] GroupUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Groups.AnyAsync(g => g.Code == code, ct)) throw new ConflictException($"Grup kodu zaten var: {code}");
        var advisories = await db.Groups.AsNoTracking()
            .Where(g => g.Name.ToLower() == dto.Name.ToLower() || g.Code.StartsWith(code.Substring(0, Math.Min(code.Length, 6))))
            .Select(g => "Benzer grup mevcut: " + g.Code + " (" + g.Name + ")").Take(5).ToListAsync(ct);
        var g = new Group { Code = code, Name = dto.Name, Description = dto.Description, IsActive = dto.IsActive };
        db.Groups.Add(g);
        audit.Management("GroupCreated", "Group", code, $"Grup oluşturuldu: {code}", dto);
        await db.SaveChangesAsync(ct);
        return Ok(new { g.Id, advisories });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] GroupUpsert dto, CancellationToken ct)
    {
        var g = await db.Groups.FindAsync([id], ct) ?? throw new NotFoundException("Grup", id);
        g.Name = dto.Name; g.Description = dto.Description; g.IsActive = dto.IsActive;
        audit.Management("GroupUpdated", "Group", g.Code, $"Grup güncellendi: {g.Code} (aktif={dto.IsActive})", dto);
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    /// <summary>Kitle (AudienceUser/AudienceRole/AudienceOrgUnit) veya grant (GrantPermission/GrantRole) ekle.</summary>
    [HttpPost("{id:int}/items")]
    public Task<ChangeImpactResult> AddItem(int id, [FromBody] GroupItemRequest r, CancellationToken ct) =>
        assignments.SetGroupItemAsync(id, r.Kind, r.TargetId, add: true, ct);

    [HttpDelete("{id:int}/items/{kind}/{targetId:int}")]
    public Task<ChangeImpactResult> RemoveItem(int id, GroupChangeKind kind, int targetId, CancellationToken ct) =>
        assignments.SetGroupItemAsync(id, kind, targetId, add: false, ct);
}
