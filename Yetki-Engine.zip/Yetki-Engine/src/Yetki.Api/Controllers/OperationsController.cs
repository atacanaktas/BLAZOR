using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Changes;
using Yetki.Application.Effective;
using Yetki.Application.Evaluation;
using Yetki.Application.Simulation;
using Yetki.Application.Sod;
using Yetki.Domain.Common;
using Yetki.Infrastructure.Outbox;

namespace Yetki.Api.Controllers;

/// <summary>What-If: değişiklikleri uygulamadan sonucu gösterir. Gerçek evaluator/hesaplayıcı kullanılır.</summary>
[ApiController]
[Route("api/simulation")]
public class SimulationController(SimulationService simulation) : ControllerBase
{
    /// <summary>Atama değişikliği simülasyonu (rol/permission/grup/birim; kullanıcı, rol veya grup seviyesinde).</summary>
    [HttpPost("changes")]
    public Task<ChangeImpactResult> Changes([FromBody] AuthorizationChangeSet changes, CancellationToken ct)
    {
        if (changes.IsEmpty) throw new ValidationException("En az bir değişiklik belirtilmelidir.");
        return simulation.SimulateChangesAsync(changes, ct);
    }

    /// <summary>Karar simülasyonu: opsiyonel atama değişikliği + belirli bir an (AsOfUtc) ile evaluate.</summary>
    [HttpPost("evaluate")]
    public Task<AuthorizationDecision> Evaluate([FromBody] SimulatedEvaluateRequest request, CancellationToken ct) =>
        simulation.SimulateEvaluateAsync(request, ct);

    /// <summary>Policy değişirse kimler etkilenir? (opsiyonel önerilen rule listesi + örnek context ile karar karşılaştırması)</summary>
    [HttpPost("policy-impact")]
    public Task<PolicyImpactResult> PolicyImpact([FromBody] PolicyImpactRequest request, CancellationToken ct) =>
        simulation.PolicyImpactAsync(request, ct);

    /// <summary>Yeni SoD kuralı eklenirse mevcutta kaç ihlal oluşur?</summary>
    [HttpPost("sod-rule")]
    public async Task<IActionResult> SodRule([FromBody] SodRuleImpactRequest request, CancellationToken ct)
    {
        var result = await simulation.SodRuleImpactAsync(request, ct);
        return Ok(new { violatingUsers = result.Count, users = result });
    }
}

[ApiController]
[Route("api/events")]
public class EventsController(IYetkiDbContext db, OutboxProcessor processor) : ControllerBase
{
    [HttpGet("outbox")]
    public async Task<IActionResult> Outbox([FromQuery] string? type, [FromQuery] int take = 100, CancellationToken ct = default)
    {
        var q = db.OutboxEvents.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(type)) q = q.Where(e => e.EventType == type);
        return Ok(await q.OrderByDescending(e => e.OccurredAt).Take(Math.Clamp(take, 1, 500)).ToListAsync(ct));
    }

    [HttpGet("provisioning")]
    public async Task<IActionResult> Provisioning([FromQuery] int take = 100, CancellationToken ct = default) =>
        Ok(await db.ProvisioningActions.AsNoTracking().OrderByDescending(p => p.Id).Take(Math.Clamp(take, 1, 500)).ToListAsync(ct));

    /// <summary>Outbox'ı beklemeden işlet (demo kolaylığı).</summary>
    [HttpPost("outbox/process")]
    public async Task<IActionResult> Process(CancellationToken ct) => Ok(new { processed = await processor.ProcessBatchAsync(ct) });
}

[ApiController]
[Route("api/audit")]
public class AuditController(IYetkiDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List(
        [FromQuery] AuditCategory? category, [FromQuery] string? user, [FromQuery] string? permission,
        [FromQuery] string? decision, [FromQuery] int take = 200, CancellationToken ct = default)
    {
        var q = db.AuditLogs.AsNoTracking();
        if (category is not null) q = q.Where(a => a.Category == category);
        if (!string.IsNullOrWhiteSpace(user)) q = q.Where(a => a.SubjectUserName == user.ToLower() || a.Actor == user.ToLower() || a.EntityId == user);
        if (!string.IsNullOrWhiteSpace(permission)) q = q.Where(a => a.PermissionCode == permission.ToUpper());
        if (!string.IsNullOrWhiteSpace(decision)) q = q.Where(a => a.Decision == decision);
        return Ok(await q.OrderByDescending(a => a.Timestamp).Take(Math.Clamp(take, 1, 1000))
            .Select(a => new
            {
                a.Id, a.Timestamp, a.Category, a.Actor, a.Action, a.EntityType, a.EntityId, a.SubjectUserName,
                a.PermissionCode, a.Resource, a.Decision, a.ReasonCode, a.Summary, a.CorrelationId
            }).ToListAsync(ct));
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct) =>
        Ok(await db.AuditLogs.AsNoTracking().FirstOrDefaultAsync(a => a.Id == id, ct) ?? throw new NotFoundException("Audit kaydı", id));
}

[ApiController]
[Route("api/dashboard")]
public class DashboardController(IYetkiDbContext db, IAuthorizationVersion version) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Summary(CancellationToken ct)
    {
        var since = DateTime.UtcNow.AddHours(-24);
        var decisions = await db.AuditLogs.AsNoTracking()
            .Where(a => a.Category == AuditCategory.AuthorizationDecision && a.Timestamp >= since)
            .GroupBy(a => a.Decision).Select(g => new { decision = g.Key, count = g.Count() }).ToListAsync(ct);

        return Ok(new
        {
            authorizationVersion = version.Current,
            counts = new
            {
                users = await db.Users.CountAsync(ct),
                activeUsers = await db.Users.CountAsync(u => u.IsActive, ct),
                roles = await db.Roles.CountAsync(ct),
                permissions = await db.Permissions.CountAsync(ct),
                groups = await db.Groups.CountAsync(ct),
                policies = await db.Policies.CountAsync(ct),
                rules = await db.Rules.CountAsync(ct),
                sodRules = await db.SodRules.CountAsync(ct),
                openViolations = await db.SodViolations.CountAsync(v => v.Status == ViolationStatus.Open || v.Status == ViolationStatus.Acknowledged, ct),
                pendingOutbox = await db.OutboxEvents.CountAsync(e => e.Status == OutboxStatus.Pending, ct),
                provisioningActions = await db.ProvisioningActions.CountAsync(ct)
            },
            decisionsLast24h = decisions,
            recentDecisions = await db.AuditLogs.AsNoTracking()
                .Where(a => a.Category == AuditCategory.AuthorizationDecision || a.Category == AuditCategory.Simulation)
                .OrderByDescending(a => a.Timestamp).Take(8)
                .Select(a => new { a.Id, a.Timestamp, a.SubjectUserName, a.PermissionCode, a.Decision, a.ReasonCode, a.Category })
                .ToListAsync(ct),
            recentChanges = await db.AuditLogs.AsNoTracking()
                .Where(a => a.Category == AuditCategory.Management)
                .OrderByDescending(a => a.Timestamp).Take(8)
                .Select(a => new { a.Id, a.Timestamp, a.Actor, a.Action, a.Summary })
                .ToListAsync(ct),
            recentProvisioning = await db.ProvisioningActions.AsNoTracking().OrderByDescending(p => p.Id).Take(8).ToListAsync(ct)
        });
    }
}
