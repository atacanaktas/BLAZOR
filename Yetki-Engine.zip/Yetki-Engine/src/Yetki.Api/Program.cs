using System.Globalization;
using System.Text.Json.Serialization;
using Yetki.Api.Infrastructure;
using Yetki.Application.Abstractions;
using Yetki.Infrastructure;

// Türkçe kültürde sayı/tarih/büyük-küçük harf dönüşümü sürprizlerini önlemek için invariant.
CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.InvariantCulture;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddYetkiInfrastructure(builder.Configuration);
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentActor, HttpCurrentActor>();

builder.Services.AddControllers(o => o.Filters.Add<ApiExceptionFilter>())
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        o.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "Yetki Motoru API", Version = "v1", Description = "Authorization Engine prototipi — RBAC + Policy/Rule" });
});
builder.Services.AddCors(o => o.AddPolicy("web", p => p
    .WithOrigins(builder.Configuration.GetSection("Cors:Origins").Get<string[]>() ?? ["http://localhost:5180"])
    .AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();

await app.Services.InitializeYetkiDatabaseAsync(app.Configuration);

app.UseSwagger();
app.UseSwaggerUI();
app.UseCors("web");
app.MapControllers();
app.MapGet("/", () => Results.Redirect("/swagger")).ExcludeFromDescription();

app.Run();

public partial class Program;
