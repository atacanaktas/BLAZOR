using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Yetki.Application.Abstractions;

namespace Yetki.Api.Infrastructure;

/// <summary>
/// Yönetim işlemini yapan kişi. PROTOTİP: X-Actor header'ından okunur (UI üst bardan seçilir).
/// TODO(güvenlik): Kurumsal kimlik doğrulama (OIDC/AD) + yönetim API'lerinin kendisinin de yetkilendirilmesi (AUTH_ADMIN).
/// </summary>
public sealed class HttpCurrentActor(IHttpContextAccessor http) : ICurrentActor
{
    public string Name
    {
        get
        {
            var ctx = http.HttpContext;
            if (ctx is null) return "system";
            if (ctx.User.Identity?.IsAuthenticated == true && ctx.User.Identity.Name is { } n) return n;
            var header = ctx.Request.Headers["X-Actor"].ToString();
            return string.IsNullOrWhiteSpace(header) ? "anonymous" : header.Trim().ToLowerInvariant();
        }
    }
}

/// <summary>Uygulama exception'larını ProblemDetails'e çevirir.</summary>
public sealed class ApiExceptionFilter(ILogger<ApiExceptionFilter> logger) : IExceptionFilter
{
    public void OnException(ExceptionContext context)
    {
        ProblemDetails? problem = context.Exception switch
        {
            NotFoundException e => new ProblemDetails { Status = 404, Title = "Bulunamadı", Detail = e.Message },
            ValidationException e => new ValidationProblemDetails(e.Errors) { Status = 400, Title = "Geçersiz istek", Detail = e.Message },
            ConflictException e => new ProblemDetails { Status = 409, Title = "Çakışma", Detail = e.Message, Extensions = { ["details"] = e.Details } },
            _ => null
        };
        if (problem is null)
        {
            logger.LogError(context.Exception, "Unhandled exception");
            problem = new ProblemDetails { Status = 500, Title = "Sunucu hatası", Detail = context.Exception.Message };
        }
        context.Result = new ObjectResult(problem) { StatusCode = problem.Status };
        context.ExceptionHandled = true;
    }
}
