using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Context;
using Yetki.Application.Definitions;
using Yetki.Application.Effective;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Domain.Audit;
using Yetki.Domain.Common;

namespace Yetki.Application.Simulation;

public sealed class ImpactScenario
{
    public string Name { get; set; } = "Senaryo";
    /// <summary>
    /// Örnek context. Özel değer: "@userBranch" → her kullanıcının kendi (ilk) birim kodu ile değiştirilir
    /// (BRANCH_IS_USER_UNIT gibi kullanıcıya göre değişen koşulları anlamlı test etmek için).
    /// </summary>
    public Dictionary<string, string?> Context { get; set; } = new();
}

public sealed class PolicyImpactRequest
{
    public PolicyChangeSet Changes { get; set; } = new();
    /// <summary>Boşsa sadece yapısal fark + etkilenen kullanıcılar döner (karar karşılaştırması yapılmaz).</summary>
    public List<ImpactScenario> Scenarios { get; set; } = new();
    public DateTime? AsOfUtc { get; set; }
    public bool IncludeUnchanged { get; set; }
    /// <summary>Kullanıcı × permission × senaryo için azami değerlendirme sayısı.</summary>
    public int MaxEvaluations { get; set; } = 3000;
}

public sealed record RuleRef(string Policy, string Code, string Name, RuleEffect Effect, string Expression);

public sealed record RuleChange(string Policy, string RuleCode, string? EffectBefore, string? EffectAfter, string ExpressionBefore, string ExpressionAfter);

/// <summary>Permission seviyesinde yapısal fark (context'ten bağımsız).</summary>
public sealed record PermissionPolicyDiff(
    int PermissionId, string Code, string Name, int HolderCount,
    IReadOnlyList<string> PoliciesBefore, IReadOnlyList<string> PoliciesAfter,
    IReadOnlyList<RuleRef> RulesBefore, IReadOnlyList<RuleRef> RulesAfter,
    IReadOnlyList<string> AddedRules, IReadOnlyList<string> RemovedRules,
    IReadOnlyList<RuleChange> ChangedRules,
    IReadOnlyList<string> RequiredAttributesBefore, IReadOnlyList<string> RequiredAttributesAfter,
    IReadOnlyList<string> NewRequiredAttributes,
    bool BecomesUnconditional, bool BecomesConditional)
{
    public bool HasStructuralChange => AddedRules.Count + RemovedRules.Count + ChangedRules.Count > 0
                                       || !PoliciesBefore.SequenceEqual(PoliciesAfter);
}

public sealed record DecisionBrief(DecisionType Decision, string ReasonCode, string Reason, string? DecidingRule);

public sealed record PolicyImpactRow(
    int UserId, string UserName, string FullName, string Permission, string Scenario,
    DecisionBrief Before, DecisionBrief After, string Change);

public sealed record AffectedUser(int UserId, string UserName, string FullName, IReadOnlyList<string> Permissions);

public sealed class PolicyImpactResult
{
    public string Summary { get; set; } = "";
    public IReadOnlyList<PermissionPolicyDiff> Permissions { get; init; } = [];
    public IReadOnlyList<AffectedUser> AffectedUsers { get; init; } = [];
    public IReadOnlyList<ImpactScenario> Scenarios { get; init; } = [];
    public IReadOnlyList<PolicyImpactRow> Rows { get; init; } = [];
    public int Evaluations { get; init; }
    public bool Truncated { get; init; }
    public int NewlyDenied { get; init; }
    public int NewlyAllowed { get; init; }
    public int OtherChanged { get; init; }
    public int Unchanged { get; init; }
    public double DurationMs { get; init; }
}

/// <summary>
/// Policy What-If: "Bu policy/rule/condition değişirse kimler, hangi yetkide, hangi durumda etkilenir?"
///  1) Yapısal fark: permission başına uygulanan policy/rule seti önce/sonra, değişen effect/condition, YENİ gerekli attribute.
///  2) Etkilenen kullanıcılar: ilgili permission'lara (effective) sahip herkes.
///  3) Senaryolu karşılaştırma: her kullanıcı × permission × senaryo için AYNI AuthorizationEvaluator ile önce/sonra kararı.
/// Kendi karar mantığı yoktur.
/// </summary>
public sealed class PolicyImpactService(
    IYetkiDbContext db,
    PolicyDefinitionLoader loader,
    AuthorizationEvaluator evaluator,
    PermissionHolderService holders,
    ConditionHandlerRegistry handlers,
    PolicyManagementService definitions,
    SharedConditionService sharedConditions,
    IEnumerable<IAttributeValueProvider> attributeProviders,
    AuditWriter audit,
    ICurrentActor actor)
{
    public async Task<PolicyImpactResult> AnalyzeAsync(PolicyImpactRequest request, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        var changes = request.Changes ?? new PolicyChangeSet();
        if (changes.IsEmpty) throw new ValidationException("En az bir policy/rule değişikliği belirtilmelidir.");
        await ValidateAsync(changes, ct);

        // --- Etkilenen permission'lar ---
        var touched = new HashSet<int>(changes.PolicyActivations.Select(a => a.PolicyId));
        touched.UnionWith(changes.PolicyAlgorithmChanges.Select(a => a.PolicyId));
        touched.UnionWith(changes.AddedRules.Select(r => r.PolicyId));
        var ruleIds = changes.RemovedRuleIds.Concat(changes.RuleOverrides.Select(o => o.RuleId)).Concat(changes.ReplacedRules.Select(r => r.RuleId)).Distinct().ToList();
        touched.UnionWith(await db.Rules.AsNoTracking().Where(r => ruleIds.Contains(r.Id)).Select(r => r.PolicyId).ToListAsync(ct));
        var conditionIds = changes.ConditionOverrides.Select(o => o.ConditionId).ToList();
        var overridden = await db.RuleConditions.AsNoTracking().Where(c => conditionIds.Contains(c.Id))
            .Select(c => new { PolicyId = c.Rule != null ? (int?)c.Rule.PolicyId : null, c.SharedConditionId }).ToListAsync(ct);
        touched.UnionWith(overridden.Where(o => o.PolicyId != null).Select(o => o.PolicyId!.Value));
        // Ortak koşul değişikliği (tanım veya parametre) → onu doğrudan/dolaylı kullanan TÜM policy'ler
        var sharedIds = changes.SharedConditionReplacements.Select(r => r.SharedConditionId)
            .Concat(overridden.Where(o => o.SharedConditionId != null).Select(o => o.SharedConditionId!.Value)).Distinct();
        foreach (var sid in sharedIds)
            touched.UnionWith((await sharedConditions.UsagesAsync(sid, ct)).Select(u => u.PolicyId));
        // PermissionPolicyChanges sadece ilgili permission'ı etkiler (policy'nin diğer permission'larını değil).

        var policyList = touched.ToList();
        var permissionIds = new HashSet<int>(await db.PermissionPolicies.AsNoTracking()
            .Where(pp => policyList.Contains(pp.PolicyId)).Select(pp => pp.PermissionId).ToListAsync(ct));
        permissionIds.UnionWith(changes.PermissionPolicyChanges.Select(c => c.PermissionId));

        var permIdList = permissionIds.ToList();
        var permissions = await db.Permissions.AsNoTracking().Where(p => permIdList.Contains(p.Id))
            .Select(p => new { p.Id, p.Code, p.Name }).ToListAsync(ct);

        // --- Yapısal fark + sahipler ---
        var diffs = new List<PermissionPolicyDiff>();
        var holderMap = new Dictionary<int, IReadOnlyList<PermissionHolder>>();
        foreach (var p in permissions.OrderBy(p => p.Code, StringComparer.Ordinal))
        {
            var before = await loader.LoadForPermissionAsync(p.Id, null, ct);
            var after = await loader.LoadForPermissionAsync(p.Id, changes, ct);
            var h = await holders.FindHoldersAsync(p.Id, ct);
            holderMap[p.Id] = h;
            diffs.Add(BuildDiff(p.Id, p.Code, p.Name, h.Count, before, after));
        }

        var affectedUsers = holderMap
            .SelectMany(kv => kv.Value.Select(h => (h, code: permissions.First(p => p.Id == kv.Key).Code)))
            .GroupBy(x => x.h.UserId)
            .Select(g => new AffectedUser(g.Key, g.First().h.UserName, g.First().h.FullName, g.Select(x => x.code).OrderBy(c => c).ToList()))
            .OrderBy(u => u.UserName, StringComparer.Ordinal)
            .ToList();

        // --- Senaryolu karar karşılaştırması (AYNI evaluator) ---
        var rows = new List<PolicyImpactRow>();
        int evaluations = 0, newlyDenied = 0, newlyAllowed = 0, other = 0, unchanged = 0;
        var truncated = false;
        var branchCache = new Dictionary<int, string?>();

        if (request.Scenarios.Count > 0)
        {
            foreach (var diff in diffs)
            foreach (var holder in holderMap[diff.PermissionId])
            foreach (var scenario in request.Scenarios)
            {
                if (evaluations >= Math.Clamp(request.MaxEvaluations, 1, 20000)) { truncated = true; break; }
                evaluations++;

                var context = await ResolveScenarioAsync(scenario, holder, branchCache, ct);
                var req = new AuthorizationRequest { Subject = new SubjectInfo { UserId = holder.UserId }, Permission = diff.Code, Context = context };
                var b = await evaluator.EvaluateAsync(req, new EvaluationOptions { IsSimulation = true, WriteAudit = false, AsOfUtc = request.AsOfUtc }, ct);
                var a = await evaluator.EvaluateAsync(req, new EvaluationOptions { IsSimulation = true, WriteAudit = false, AsOfUtc = request.AsOfUtc, PolicyChanges = changes }, ct);

                var change = Classify(b, a);
                switch (change)
                {
                    case "NEWLY_DENIED" or "NEWLY_INDETERMINATE": newlyDenied++; break;
                    case "NEWLY_ALLOWED": newlyAllowed++; break;
                    case "UNCHANGED": unchanged++; break;
                    default: other++; break;
                }
                if (change != "UNCHANGED" || request.IncludeUnchanged)
                    rows.Add(new PolicyImpactRow(holder.UserId, holder.UserName, holder.FullName, diff.Code, scenario.Name, Brief(b), Brief(a), change));
            }
        }

        sw.Stop();
        var result = new PolicyImpactResult
        {
            Permissions = diffs,
            AffectedUsers = affectedUsers,
            Scenarios = request.Scenarios,
            Rows = rows.OrderBy(r => r.Change == "NEWLY_DENIED" ? 0 : r.Change == "NEWLY_ALLOWED" ? 1 : 2).ThenBy(r => r.UserName).ToList(),
            Evaluations = evaluations,
            Truncated = truncated,
            NewlyDenied = newlyDenied,
            NewlyAllowed = newlyAllowed,
            OtherChanged = other,
            Unchanged = unchanged,
            DurationMs = Math.Round(sw.Elapsed.TotalMilliseconds, 1),
            Summary = BuildSummary(diffs, affectedUsers.Count, request.Scenarios.Count, newlyDenied, newlyAllowed, other)
        };

        audit.Add(new AuditLog
        {
            Category = AuditCategory.Simulation, Actor = actor.Name, Action = "PolicyImpact",
            Summary = result.Summary,
            DetailsJson = JsonDefaults.Serialize(new { changes, scenarios = request.Scenarios, result.NewlyDenied, result.NewlyAllowed, result.Evaluations })
        });
        await db.SaveChangesAsync(ct);
        return result;
    }

    private PermissionPolicyDiff BuildDiff(int id, string code, string name, int holderCount,
        IReadOnlyList<PolicyDefinition> before, IReadOnlyList<PolicyDefinition> after)
    {
        static List<(PolicyDefinition P, RuleDefinition R)> Active(IEnumerable<PolicyDefinition> ps) =>
            ps.SelectMany(p => p.Rules.Where(r => r.IsActive).Select(r => (p, r))).ToList();

        var rb = Active(before);
        var ra = Active(after);
        string Key((PolicyDefinition P, RuleDefinition R) x) => $"{x.P.Code}/{x.R.Code}";

        var added = ra.Where(x => rb.All(y => y.R.RuleId != x.R.RuleId)).Select(Key).ToList();
        var removed = rb.Where(x => ra.All(y => y.R.RuleId != x.R.RuleId)).Select(Key).ToList();
        var changed = ra
            .Select(x => (after: x, before: rb.FirstOrDefault(y => y.R.RuleId == x.R.RuleId)))
            .Where(t => t.before.R is not null)
            .Select(t => (t.after, t.before, eb: PolicyEvaluator.Render(t.before.R.Condition, expand: true), ea: PolicyEvaluator.Render(t.after.R.Condition, expand: true)))
            .Where(t => t.eb != t.ea || t.before.R.Effect != t.after.R.Effect || t.before.P.Algorithm != t.after.P.Algorithm)
            .Select(t => new RuleChange(t.after.P.Code, t.after.R.Code,
                t.before.R.Effect.ToString(), t.after.R.Effect.ToString(), t.eb, t.ea))
            .ToList();

        var attrBefore = RequiredAttributes(rb.Select(x => x.R));
        var attrAfter = RequiredAttributes(ra.Select(x => x.R));

        return new PermissionPolicyDiff(id, code, name, holderCount,
            before.Select(p => $"{p.Code} ({p.Algorithm})").ToList(), after.Select(p => $"{p.Code} ({p.Algorithm})").ToList(),
            rb.Select(x => new RuleRef(x.P.Code, x.R.Code, x.R.Name, x.R.Effect, PolicyEvaluator.Render(x.R.Condition))).ToList(),
            ra.Select(x => new RuleRef(x.P.Code, x.R.Code, x.R.Name, x.R.Effect, PolicyEvaluator.Render(x.R.Condition))).ToList(),
            added, removed, changed,
            attrBefore, attrAfter, attrAfter.Except(attrBefore).ToList(),
            BecomesUnconditional: before.Count > 0 && after.Count == 0,
            BecomesConditional: before.Count == 0 && after.Count > 0);
    }

    /// <summary>Çağıranın (SDK/uygulama) sağlaması gereken attribute'lar: Context.* ve Environment.* (motorun ürettiği CurrentTime hariç).</summary>
    private List<string> RequiredAttributes(IEnumerable<RuleDefinition> rules)
    {
        IEnumerable<ConditionNode> Flatten(ConditionNode? n) => n is null ? [] : new[] { n }.Concat(n.Children.SelectMany(Flatten));
        return rules
            .SelectMany(r => Flatten(r.Condition))
            .Where(n => n.Kind == ConditionKind.Predicate && n.ConditionTypeCode is not null)
            .SelectMany(n =>
            {
                var attrs = handlers.Find(n.ConditionTypeCode!)?.Descriptor.RequiredAttributes ?? [];
                return n.Parameters.TryGetValue("AmountAttribute", out var k) && !string.IsNullOrWhiteSpace(k)
                    ? attrs.Select(a => a == AttributeId.Ctx(AuthContextKeys.TransactionAmount).ToString() ? AttributeId.Ctx(k).ToString() : a)
                    : attrs;
            })
            .Where(a => !a.StartsWith("Subject.", StringComparison.Ordinal) && a != AttributeId.Env(AuthContextKeys.CurrentTime).ToString())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(a => a, StringComparer.Ordinal)
            .ToList();
    }

    private static DecisionBrief Brief(AuthorizationDecision d) => new(d.Decision, d.ReasonCode, d.HumanReadableReason, d.DecidingRule);

    private static string Classify(AuthorizationDecision before, AuthorizationDecision after)
    {
        if (before.Decision == after.Decision) return before.ReasonCode == after.ReasonCode ? "UNCHANGED" : "REASON_CHANGED";
        if (after.IsAllowed) return "NEWLY_ALLOWED";
        if (before.IsAllowed) return after.Decision == DecisionType.Indeterminate ? "NEWLY_INDETERMINATE" : "NEWLY_DENIED";
        return "REASON_CHANGED"; // izin verilmeyen durumlar arası geçiş (Deny ↔ Indeterminate ↔ NotApplicable)
    }

    private async Task<Dictionary<string, string?>> ResolveScenarioAsync(
        ImpactScenario scenario, PermissionHolder holder, Dictionary<int, string?> branchCache, CancellationToken ct)
    {
        var context = new Dictionary<string, string?>(scenario.Context, StringComparer.OrdinalIgnoreCase);
        foreach (var key in context.Keys.ToList())
        {
            if (!string.Equals(context[key], "@userBranch", StringComparison.OrdinalIgnoreCase)) continue;
            if (!branchCache.TryGetValue(holder.UserId, out var branch))
            {
                var resolver = new AttributeResolver(attributeProviders.ToList(), new AttributeResolutionScope
                {
                    Subject = new SubjectRef(holder.UserId, holder.UserName),
                    Context = new AuthorizationContext(),
                    Action = "impact"
                });
                var codes = await resolver.GetStringAsync(AttributeId.Subject(SubjectAttributes.OrgUnitCodes), ct);
                branch = codes?.Split(',', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
                branchCache[holder.UserId] = branch;
            }
            context[key] = branch;
        }
        return context;
    }

    private async Task ValidateAsync(PolicyChangeSet c, CancellationToken ct)
    {
        var errors = new List<string>();
        var policyIds = c.PolicyActivations.Select(x => x.PolicyId).Concat(c.PolicyAlgorithmChanges.Select(x => x.PolicyId))
            .Concat(c.PermissionPolicyChanges.Select(x => x.PolicyId)).Concat(c.AddedRules.Select(x => x.PolicyId)).Distinct().ToList();
        var ruleIds = c.RuleOverrides.Select(x => x.RuleId).Concat(c.RemovedRuleIds).Concat(c.ReplacedRules.Select(x => x.RuleId)).Distinct().ToList();
        var permIds = c.PermissionPolicyChanges.Select(x => x.PermissionId).Distinct().ToList();
        var condIds = c.ConditionOverrides.Select(x => x.ConditionId).Distinct().ToList();

        if (await db.Policies.CountAsync(p => policyIds.Contains(p.Id), ct) != policyIds.Count) errors.Add("Bilinmeyen policy.");
        if (await db.Permissions.CountAsync(p => permIds.Contains(p.Id), ct) != permIds.Count) errors.Add("Bilinmeyen permission.");
        if (await db.Rules.CountAsync(r => ruleIds.Contains(r.Id), ct) != ruleIds.Count) errors.Add("Bilinmeyen rule.");

        var conditions = await db.RuleConditions.AsNoTracking().Where(x => condIds.Contains(x.Id))
            .Select(x => new { x.Id, x.Kind, Type = x.ConditionType != null ? x.ConditionType.Code : null }).ToListAsync(ct);
        if (conditions.Count != condIds.Count) errors.Add("Bilinmeyen condition.");
        foreach (var o in c.ConditionOverrides)
        {
            var cond = conditions.FirstOrDefault(x => x.Id == o.ConditionId);
            var handler = cond?.Type is null ? null : handlers.Find(cond.Type);
            if (cond is not null && cond.Kind != ConditionKind.Predicate) { errors.Add($"Condition #{o.ConditionId} predicate değil; parametresi olmaz."); continue; }
            if (handler is null) continue;
            var ps = o.Parameters.Where(kv => !string.IsNullOrWhiteSpace(kv.Value)).ToDictionary(kv => kv.Key, kv => kv.Value.Trim(), StringComparer.OrdinalIgnoreCase);
            errors.AddRange(handler.ValidateParameters(ps).Select(e => $"{cond!.Type}: {e}"));
        }
        if (errors.Count > 0) throw new ValidationException("Policy değişikliği geçersiz.", new Dictionary<string, string[]> { ["changes"] = errors.ToArray() });

        foreach (var draft in c.AddedRules.Concat(c.ReplacedRules.Select(r => r.Rule))) await definitions.ValidateConditionAsync(draft.Condition, ct);
        foreach (var r in c.SharedConditionReplacements)
        {
            if (!await db.SharedConditions.AnyAsync(x => x.Id == r.SharedConditionId, ct)) throw new NotFoundException("Ortak koşul", r.SharedConditionId);
            await definitions.ValidateConditionAsync(r.Condition, ct, selfSharedId: r.SharedConditionId);
        }
    }

    private static string BuildSummary(List<PermissionPolicyDiff> diffs, int users, int scenarioCount, int denied, int allowed, int other)
    {
        var s = $"{diffs.Count} permission, {users} kullanıcı kapsamda.";
        var newAttrs = diffs.SelectMany(d => d.NewRequiredAttributes).Distinct().ToList();
        if (newAttrs.Count > 0) s += $" YENİ gerekli attribute: {string.Join(", ", newAttrs)} (göndermeyen uygulamalarda karar Indeterminate olur).";
        var unconditional = diffs.Where(d => d.BecomesUnconditional).Select(d => d.Code).ToList();
        if (unconditional.Count > 0) s += $" DİKKAT: {string.Join(", ", unconditional)} policy'siz (koşulsuz) kalır.";
        if (scenarioCount > 0) s += $" Senaryolarda: {denied} karar izin → red, {allowed} karar → izin, {other} diğer değişim.";
        return s;
    }
}
