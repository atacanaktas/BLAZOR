using Yetki.Application.Abstractions;
using Yetki.Application.Changes;
using Yetki.Application.Effective;
using Yetki.Application.Evaluation;
using Yetki.Application.Sod;
using Yetki.Domain.Common;

namespace Yetki.Application.Simulation;

public sealed class SimulatedEvaluateRequest
{
    public AuthorizationRequest Request { get; set; } = new();
    public AuthorizationChangeSet? Changes { get; set; }
    public PolicyChangeSet? PolicyChanges { get; set; }
    /// <summary>Kararın hangi an için simüle edileceği (UTC). Boşsa şimdi.</summary>
    public DateTime? AsOfUtc { get; set; }
}

public sealed class SodRuleImpactRequest
{
    public string Code { get; set; } = "DRAFT";
    public SodEnforcement Enforcement { get; set; } = SodEnforcement.Block;
    public List<int> PermissionIds { get; set; } = new();
    public List<int> RoleIds { get; set; } = new();
}

/// <summary>
/// What-If servisi. KENDİ karar mantığı yoktur: AuthorizationChangeService.AnalyzeAsync, AuthorizationEvaluator,
/// PolicyImpactService ve SodEvaluator'ı simülasyon parametreleriyle çağırır.
/// </summary>
public sealed class SimulationService(
    AuthorizationChangeService changes,
    AuthorizationEvaluator evaluator,
    PolicyImpactService policyImpact,
    SodService sod,
    ICurrentActor actor)
{
    public Task<ChangeImpactResult> SimulateChangesAsync(AuthorizationChangeSet changeSet, CancellationToken ct) =>
        changes.AnalyzeAsync(changeSet, dryRun: true, ct);

    public Task<AuthorizationDecision> SimulateEvaluateAsync(SimulatedEvaluateRequest request, CancellationToken ct) =>
        evaluator.EvaluateAsync(request.Request, new EvaluationOptions
        {
            Changes = request.Changes is { IsEmpty: false } ? request.Changes : null,
            PolicyChanges = request.PolicyChanges is { IsEmpty: false } ? request.PolicyChanges : null,
            AsOfUtc = request.AsOfUtc,
            IsSimulation = true,
            WriteAudit = true,
            Actor = actor.Name
        }, ct);

    public Task<PolicyImpactResult> PolicyImpactAsync(PolicyImpactRequest request, CancellationToken ct) =>
        policyImpact.AnalyzeAsync(request, ct);

    public async Task<IReadOnlyList<SodUserConflicts>> SodRuleImpactAsync(SodRuleImpactRequest request, CancellationToken ct)
    {
        var members = request.PermissionIds.Select(id => (SodMemberType.Permission, id))
            .Concat(request.RoleIds.Select(id => (SodMemberType.Role, id))).ToList();
        if (members.Count < 2) throw new ValidationException("SoD kuralı en az 2 üye içermelidir.");
        var draft = await sod.DraftSnapshotAsync(request.Code, members, request.Enforcement, ct);
        return await sod.SimulateRuleAsync(draft, ct);
    }
}
