namespace Yetki.Application.Abstractions;

public class NotFoundException(string entity, object key)
    : Exception($"{entity} bulunamadı: {key}");

public class ValidationException(string message, IDictionary<string, string[]>? errors = null) : Exception(message)
{
    public IDictionary<string, string[]> Errors { get; } = errors ?? new Dictionary<string, string[]>();
}

/// <summary>İş kuralı çakışması (ör. SoD Block, kod tekrarı). Details istemciye olduğu gibi döner.</summary>
public class ConflictException(string message, object? details = null) : Exception(message)
{
    public object? Details { get; } = details;
}
