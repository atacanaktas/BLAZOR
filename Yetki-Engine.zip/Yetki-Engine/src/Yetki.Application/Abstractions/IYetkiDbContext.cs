using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Yetki.Domain.Audit;
using Yetki.Domain.Events;
using Yetki.Domain.External;
using Yetki.Domain.Groups;
using Yetki.Domain.Identity;
using Yetki.Domain.Policies;
using Yetki.Domain.Rbac;
using Yetki.Domain.Sod;

namespace Yetki.Application.Abstractions;

/// <summary>
/// Kalıcılık sınırı. Application katmanı EF Core soyutlamasını (DbSet/LINQ) kullanır ancak
/// hangi provider'ın (InMemory / SQL Server) kullanıldığını bilmez.
/// Provider değişimi sadece Infrastructure'daki DI kaydını etkiler.
/// </summary>
public interface IYetkiDbContext
{
    DbSet<User> Users { get; }
    DbSet<OrganizationUnit> OrganizationUnits { get; }
    DbSet<UserOrganizationUnit> UserOrganizationUnits { get; }

    DbSet<Permission> Permissions { get; }
    DbSet<Role> Roles { get; }
    DbSet<RolePermission> RolePermissions { get; }
    DbSet<UserRole> UserRoles { get; }
    DbSet<UserPermission> UserPermissions { get; }

    DbSet<Group> Groups { get; }
    DbSet<GroupUser> GroupUsers { get; }
    DbSet<GroupRole> GroupRoles { get; }
    DbSet<GroupOrganizationUnit> GroupOrganizationUnits { get; }
    DbSet<GroupPermission> GroupPermissions { get; }
    DbSet<GroupGrantedRole> GroupGrantedRoles { get; }

    DbSet<Policy> Policies { get; }
    DbSet<ConditionType> ConditionTypes { get; }
    DbSet<Rule> Rules { get; }
    DbSet<RuleCondition> RuleConditions { get; }
    DbSet<ConditionParameter> ConditionParameters { get; }
    DbSet<SharedCondition> SharedConditions { get; }
    DbSet<PermissionPolicy> PermissionPolicies { get; }

    DbSet<SodRule> SodRules { get; }
    DbSet<SodRuleMember> SodRuleMembers { get; }
    DbSet<SodViolation> SodViolations { get; }

    DbSet<ExternalSystem> ExternalSystems { get; }
    DbSet<ExternalPermission> ExternalPermissions { get; }
    DbSet<PermissionExternalMapping> PermissionExternalMappings { get; }

    DbSet<OutboxEvent> OutboxEvents { get; }
    DbSet<ProvisioningAction> ProvisioningActions { get; }
    DbSet<AuditLog> AuditLogs { get; }

    EntityEntry Add(object entity);
    EntityEntry Remove(object entity);

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}

public interface IClock
{
    DateTime UtcNow { get; }
}

/// <summary>Yönetim işlemini yapan kişi (audit "kim yaptı?"). Prototipte X-Actor header'ından gelir.</summary>
public interface ICurrentActor
{
    string Name { get; }
}

/// <summary>
/// Yetki verisinin global versiyonu. RBAC/grup/policy verisinde her değişiklikte artar.
/// Effective permission cache anahtarı bu versiyonu içerir; böylece değişiklik anında cache geçersizleşir.
/// Çok instance'lı kurulumda bu değer dağıtık bir kaynaktan (Redis/DB) okunmalıdır (TODO).
/// </summary>
public interface IAuthorizationVersion
{
    long Current { get; }
    void Bump();
}
