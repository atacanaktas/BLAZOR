using System.Text.Json.Serialization;

namespace Yetki.Application.Effective;

// ---------- Hesaplama girdisi: kullanıcıya ait yetki grafiği dilimi (change set uygulanmış hali) ----------

public sealed class SubjectSlice
{
    public int UserId { get; init; }
    public string UserName { get; init; } = default!;
    public string FullName { get; init; } = default!;
    public bool IsActive { get; init; }
    public HashSet<int> DirectRoleIds { get; init; } = new();
    public HashSet<int> DirectPermissionIds { get; init; } = new();
    public HashSet<int> OrgUnitIds { get; init; } = new();
}

public sealed class GroupSlice
{
    public int Id { get; init; }
    public string Code { get; init; } = default!;
    public string Name { get; init; } = default!;
    public bool SubjectIsExplicitMember { get; set; }
    public HashSet<int> AudienceRoleIds { get; init; } = new();
    public HashSet<int> AudienceOrgUnitIds { get; init; } = new();
    public HashSet<int> GrantedPermissionIds { get; init; } = new();
    public HashSet<int> GrantedRoleIds { get; init; } = new();
}

public sealed class RoleSlice
{
    public int Id { get; init; }
    public string Code { get; init; } = default!;
    public string Name { get; init; } = default!;
    public HashSet<int> PermissionIds { get; init; } = new();
}

public sealed record PermissionInfo(int Id, string Code, string Name, string? Domain, bool HasPolicies);

public sealed record OrgUnitInfo(int Id, string Code, string Name);

public sealed class AuthorizationGraphSlice
{
    public SubjectSlice Subject { get; init; } = default!;
    public List<GroupSlice> Groups { get; init; } = new();
    public Dictionary<int, RoleSlice> Roles { get; init; } = new();
    public Dictionary<int, PermissionInfo> Permissions { get; init; } = new();
    public Dictionary<int, OrgUnitInfo> OrgUnits { get; init; } = new();
}

// ---------- Hesaplama çıktısı: açıklanabilir effective permission seti ----------

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum PermissionSourceType
{
    /// <summary>Kullanıcıya doğrudan atanmış rol.</summary>
    DirectRole = 1,
    /// <summary>Kullanıcının üyesi olduğu grubun verdiği rol.</summary>
    GroupGrantedRole = 2,
    /// <summary>Kullanıcının üyesi olduğu grubun doğrudan verdiği permission.</summary>
    GroupPermission = 3,
    /// <summary>Kullanıcıya doğrudan permission ataması (legacy/istisna).</summary>
    DirectUser = 4
}

public sealed record MembershipReason(string Type, int? RefId, string? RefCode, string Text);

public sealed record GroupMembershipInfo(int GroupId, string Code, string Name, IReadOnlyList<MembershipReason> Reasons);

public sealed record RoleSource(string Type, int? GroupId, string? GroupCode, string Text);

public sealed record EffectiveRole(int RoleId, string Code, string Name, IReadOnlyList<RoleSource> Sources);

public sealed record PermissionSource(
    PermissionSourceType Type,
    int? RoleId, string? RoleCode,
    int? GroupId, string? GroupCode,
    string Path);

public sealed record EffectivePermission(
    int PermissionId, string Code, string Name, string? Domain,
    /// <summary>Permission'a bağlı aktif policy varsa true: login-time statik set ile yetinilemez, işlem anında evaluate gerekir.</summary>
    bool RequiresRuntimeEvaluation,
    IReadOnlyList<PermissionSource> Sources);

public sealed class EffectivePermissionSet
{
    public int UserId { get; init; }
    public string UserName { get; init; } = default!;
    public string FullName { get; init; } = default!;
    public bool IsActive { get; init; }
    public long Version { get; set; }
    public DateTime ComputedAt { get; set; }
    public IReadOnlyList<EffectiveRole> Roles { get; init; } = [];
    public IReadOnlyList<GroupMembershipInfo> Groups { get; init; } = [];
    public IReadOnlyList<EffectivePermission> Permissions { get; init; } = [];

    public EffectivePermission? Find(string permissionCode) =>
        Permissions.FirstOrDefault(p => string.Equals(p.Code, permissionCode, StringComparison.OrdinalIgnoreCase));

    public bool HasRole(int roleId) => Roles.Any(r => r.RoleId == roleId);
}
