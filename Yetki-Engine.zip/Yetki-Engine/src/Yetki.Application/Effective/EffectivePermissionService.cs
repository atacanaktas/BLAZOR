using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Yetki.Application.Abstractions;

namespace Yetki.Application.Effective;

/// <summary>
/// Effective permission'ların tek giriş noktası.
/// - Change set yoksa sonuç, global yetki versiyonu ile anahtarlanmış bellek cache'inden gelir (login storm).
/// - Change set varsa (What-If / atama öncesi kontrol) cache kullanılmaz.
/// Cache sadece "kullanıcı hangi permission'lara sahip" sorusu içindir; context-dependent policy kararları
/// ASLA cache'lenmez, her istekte evaluate edilir.
/// </summary>
public sealed class EffectivePermissionService(
    AuthorizationGraphLoader loader,
    IYetkiDbContext db,
    IMemoryCache cache,
    IAuthorizationVersion version,
    IClock clock)
{
    private static readonly TimeSpan CacheTtl = TimeSpan.FromMinutes(15);

    public async Task<EffectivePermissionSet?> GetAsync(
        int userId, AuthorizationChangeSet? changes = null, bool useCache = true, CancellationToken ct = default)
    {
        // Versiyon hesaplamadan ÖNCE okunur: hesaplama sırasında değişiklik olursa eski versiyon anahtarıyla cache'lenir, yenisi kullanılmaz.
        var v = version.Current;
        if (changes is null && useCache)
        {
            var key = $"eff:{userId}:{v}";
            if (cache.TryGetValue(key, out EffectivePermissionSet? cached)) return cached;
            var computed = await ComputeAsync(userId, null, v, ct);
            if (computed is not null) cache.Set(key, computed, CacheTtl);
            return computed;
        }
        return await ComputeAsync(userId, changes, v, ct);
    }

    public async Task<EffectivePermissionSet?> GetByUserNameAsync(string userName, bool useCache = true, CancellationToken ct = default)
    {
        var id = await ResolveUserIdAsync(userName, ct);
        return id is null ? null : await GetAsync(id.Value, null, useCache, ct);
    }

    public async Task<int?> ResolveUserIdAsync(string userName, CancellationToken ct = default)
    {
        var normalized = userName.Trim().ToLowerInvariant();
        var key = $"uid:{normalized}";
        if (cache.TryGetValue(key, out int id)) return id;
        var found = await db.Users.AsNoTracking().Where(u => u.UserName == normalized).Select(u => (int?)u.Id).FirstOrDefaultAsync(ct);
        if (found is not null) cache.Set(key, found.Value, TimeSpan.FromHours(1));
        return found;
    }

    private async Task<EffectivePermissionSet?> ComputeAsync(int userId, AuthorizationChangeSet? changes, long v, CancellationToken ct)
    {
        var slice = await loader.LoadAsync(userId, changes, ct);
        if (slice is null) return null;
        var set = EffectivePermissionCalculator.Calculate(slice);
        set.Version = v;
        set.ComputedAt = clock.UtcNow;
        return set;
    }
}
