namespace Yetki.Application.Effective;

/// <summary>
/// Saf (I/O yapmayan) effective permission hesaplayıcısı. Girdi: change set uygulanmış grafik dilimi.
/// Aynı fonksiyon gerçek karar, What-If ve SoD taramasında kullanılır.
///
/// Kurallar:
///  1. Doğrudan roller (UserRoles) -> rol permission'ları
///  2. Grup üyeliği = doğrudan üye VEYA kitledeki role DOĞRUDAN sahip VEYA kitledeki birimde çalışıyor
///  3. Üye olunan grubun verdiği roller ve permission'lar
///  4. Doğrudan kullanıcı permission'ları (legacy/istisna)
///  Grup üzerinden gelen rol başka grubun kitlesini tetiklemez (nested/zincir yok).
///  Pasif rol/permission/grup yüklenmez -> hesaba girmez.
/// </summary>
public static class EffectivePermissionCalculator
{
    public static EffectivePermissionSet Calculate(AuthorizationGraphSlice slice)
    {
        var subject = slice.Subject;
        var memberships = new List<(GroupSlice Group, List<MembershipReason> Reasons)>();

        foreach (var g in slice.Groups)
        {
            var reasons = new List<MembershipReason>();
            if (g.SubjectIsExplicitMember)
                reasons.Add(new MembershipReason("User", subject.UserId, subject.UserName, "Kullanıcı gruba doğrudan eklenmiş"));

            // Pasif rol kitle eşleşmesi sağlamaz (slice.Roles sadece aktif rolleri içerir).
            foreach (var roleId in g.AudienceRoleIds.Where(id => subject.DirectRoleIds.Contains(id) && slice.Roles.ContainsKey(id)).Order())
            {
                var code = slice.Roles[roleId].Code;
                reasons.Add(new MembershipReason("Role", roleId, code, $"Kullanıcı '{code}' rolüne doğrudan sahip"));
            }

            foreach (var ouId in g.AudienceOrgUnitIds.Where(subject.OrgUnitIds.Contains).Order())
            {
                var ou = slice.OrgUnits.GetValueOrDefault(ouId);
                var label = ou is null ? ouId.ToString() : ou.Name;
                reasons.Add(new MembershipReason("OrgUnit", ouId, ou?.Code, $"Kullanıcı '{label}' biriminde"));
            }

            if (reasons.Count > 0) memberships.Add((g, reasons));
        }

        // --- Effective roller ---
        var roleSources = new Dictionary<int, List<RoleSource>>();
        void AddRoleSource(int roleId, RoleSource src)
        {
            if (!slice.Roles.ContainsKey(roleId)) return; // pasif/bilinmeyen rol
            if (!roleSources.TryGetValue(roleId, out var list)) roleSources[roleId] = list = new();
            list.Add(src);
        }

        foreach (var roleId in subject.DirectRoleIds)
            AddRoleSource(roleId, new RoleSource("Direct", null, null, "Doğrudan atama"));

        foreach (var (g, reasons) in memberships)
            foreach (var roleId in g.GrantedRoleIds)
                AddRoleSource(roleId, new RoleSource("Group", g.Id, g.Code, $"Grup '{g.Code}' [{ReasonShort(reasons)}]"));

        // --- Effective permission'lar ---
        var permSources = new Dictionary<int, List<PermissionSource>>();
        void AddPerm(int permissionId, PermissionSource src)
        {
            if (!slice.Permissions.ContainsKey(permissionId)) return; // pasif/bilinmeyen permission
            if (!permSources.TryGetValue(permissionId, out var list)) permSources[permissionId] = list = new();
            list.Add(src);
        }

        foreach (var roleId in subject.DirectRoleIds)
        {
            if (!slice.Roles.TryGetValue(roleId, out var role)) continue;
            foreach (var pid in role.PermissionIds)
                AddPerm(pid, new PermissionSource(PermissionSourceType.DirectRole, role.Id, role.Code, null, null,
                    $"Rol '{role.Code}' (doğrudan atama)"));
        }

        foreach (var (g, reasons) in memberships)
        {
            var why = ReasonShort(reasons);
            foreach (var roleId in g.GrantedRoleIds)
            {
                if (!slice.Roles.TryGetValue(roleId, out var role)) continue;
                foreach (var pid in role.PermissionIds)
                    AddPerm(pid, new PermissionSource(PermissionSourceType.GroupGrantedRole, role.Id, role.Code, g.Id, g.Code,
                        $"Grup '{g.Code}' [{why}] → Rol '{role.Code}'"));
            }
            foreach (var pid in g.GrantedPermissionIds)
                AddPerm(pid, new PermissionSource(PermissionSourceType.GroupPermission, null, null, g.Id, g.Code,
                    $"Grup '{g.Code}' [{why}] → doğrudan permission"));
        }

        foreach (var pid in subject.DirectPermissionIds)
            AddPerm(pid, new PermissionSource(PermissionSourceType.DirectUser, null, null, null, null,
                "Kullanıcıya doğrudan permission ataması (legacy/istisna)"));

        return new EffectivePermissionSet
        {
            UserId = subject.UserId,
            UserName = subject.UserName,
            FullName = subject.FullName,
            IsActive = subject.IsActive,
            Groups = memberships
                .Select(m => new GroupMembershipInfo(m.Group.Id, m.Group.Code, m.Group.Name, m.Reasons))
                .OrderBy(g => g.Code, StringComparer.Ordinal).ToList(),
            Roles = roleSources
                .Select(kv => new EffectiveRole(kv.Key, slice.Roles[kv.Key].Code, slice.Roles[kv.Key].Name, kv.Value))
                .OrderBy(r => r.Code, StringComparer.Ordinal).ToList(),
            Permissions = permSources
                .Select(kv =>
                {
                    var p = slice.Permissions[kv.Key];
                    return new EffectivePermission(p.Id, p.Code, p.Name, p.Domain, p.HasPolicies, kv.Value);
                })
                .OrderBy(p => p.Code, StringComparer.Ordinal).ToList()
        };
    }

    private static string ReasonShort(List<MembershipReason> reasons) =>
        string.Join(", ", reasons.Select(r => r.Type switch
        {
            "User" => "doğrudan üye",
            "Role" => $"kitle: rol {r.RefCode}",
            "OrgUnit" => $"kitle: birim {r.RefCode}",
            _ => r.Text
        }));
}
