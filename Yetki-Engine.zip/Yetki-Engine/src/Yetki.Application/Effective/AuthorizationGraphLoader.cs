using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;

namespace Yetki.Application.Effective;

/// <summary>
/// Bir kullanıcı için effective hesaplamaya yetecek kadar veriyi (tüm grafiği değil) set-based sorgularla yükler
/// ve opsiyonel change set'i bellekte uygular. Kullanıcı başına sabit sayıda sorgu (N+1 yok).
/// SQL Server'da ilgili composite index'ler YetkiDbContext model konfigürasyonunda tanımlıdır.
/// </summary>
public sealed class AuthorizationGraphLoader(IYetkiDbContext db, IClock clock)
{
    public async Task<AuthorizationGraphSlice?> LoadAsync(int userId, AuthorizationChangeSet? changes, CancellationToken ct = default)
    {
        var user = await db.Users.AsNoTracking()
            .Where(u => u.Id == userId)
            .Select(u => new { u.Id, u.UserName, u.FullName, u.IsActive })
            .FirstOrDefaultAsync(ct);
        if (user is null) return null;

        var now = clock.UtcNow;

        var directRoles = (await db.UserRoles.AsNoTracking()
            .Where(x => x.UserId == userId && (x.ValidUntil == null || x.ValidUntil > now))
            .Select(x => x.RoleId).ToListAsync(ct)).ToHashSet();

        var directPerms = (await db.UserPermissions.AsNoTracking()
            .Where(x => x.UserId == userId && (x.ValidUntil == null || x.ValidUntil > now))
            .Select(x => x.PermissionId).ToListAsync(ct)).ToHashSet();

        var orgUnits = (await db.UserOrganizationUnits.AsNoTracking()
            .Where(x => x.UserId == userId)
            .Select(x => x.OrganizationUnitId).ToListAsync(ct)).ToHashSet();

        var explicitGroups = (await db.GroupUsers.AsNoTracking()
            .Where(x => x.UserId == userId)
            .Select(x => x.GroupId).ToListAsync(ct)).ToHashSet();

        // --- Subject seviyesindeki değişiklikler ---
        if (changes is not null && changes.UserId == userId)
        {
            Apply(directRoles, changes.AddUserRoleIds, changes.RemoveUserRoleIds);
            Apply(directPerms, changes.AddUserPermissionIds, changes.RemoveUserPermissionIds);
            Apply(orgUnits, changes.AddUserOrgUnitIds, changes.RemoveUserOrgUnitIds);
        }
        if (changes is not null)
        {
            foreach (var gc in changes.GroupChanges.Where(g => g.Kind == GroupChangeKind.AudienceUser && g.TargetId == userId))
                if (gc.Add) explicitGroups.Add(gc.GroupId); else explicitGroups.Remove(gc.GroupId);
        }

        // --- Aday gruplar: kullanıcıyı kitlesine alabilecek her grup ---
        var roleList = directRoles.ToList();
        var ouList = orgUnits.ToList();
        var candidateIds = new HashSet<int>(explicitGroups);
        candidateIds.UnionWith(await db.GroupRoles.AsNoTracking()
            .Where(x => roleList.Contains(x.RoleId)).Select(x => x.GroupId).ToListAsync(ct));
        candidateIds.UnionWith(await db.GroupOrganizationUnits.AsNoTracking()
            .Where(x => ouList.Contains(x.OrganizationUnitId)).Select(x => x.GroupId).ToListAsync(ct));
        if (changes is not null) candidateIds.UnionWith(changes.GroupChanges.Select(g => g.GroupId));

        var candidateList = candidateIds.ToList();
        var groupRows = await db.Groups.AsNoTracking()
            .Where(g => g.IsActive && candidateList.Contains(g.Id))
            .Select(g => new
            {
                g.Id, g.Code, g.Name,
                AudienceRoles = g.Roles.Select(r => r.RoleId).ToList(),
                AudienceOus = g.OrganizationUnits.Select(o => o.OrganizationUnitId).ToList(),
                GrantPerms = g.GrantedPermissions.Select(p => p.PermissionId).ToList(),
                GrantRoles = g.GrantedRoles.Select(r => r.RoleId).ToList()
            }).ToListAsync(ct);

        var groups = groupRows.Select(g => new GroupSlice
        {
            Id = g.Id, Code = g.Code, Name = g.Name,
            SubjectIsExplicitMember = explicitGroups.Contains(g.Id),
            AudienceRoleIds = g.AudienceRoles.ToHashSet(),
            AudienceOrgUnitIds = g.AudienceOus.ToHashSet(),
            GrantedPermissionIds = g.GrantPerms.ToHashSet(),
            GrantedRoleIds = g.GrantRoles.ToHashSet()
        }).ToList();

        if (changes is not null)
        {
            var byId = groups.ToDictionary(g => g.Id);
            foreach (var gc in changes.GroupChanges)
            {
                if (!byId.TryGetValue(gc.GroupId, out var g)) continue;
                var set = gc.Kind switch
                {
                    GroupChangeKind.AudienceRole => g.AudienceRoleIds,
                    GroupChangeKind.AudienceOrgUnit => g.AudienceOrgUnitIds,
                    GroupChangeKind.GrantPermission => g.GrantedPermissionIds,
                    GroupChangeKind.GrantRole => g.GrantedRoleIds,
                    _ => null
                };
                if (set is null) continue;
                if (gc.Add) set.Add(gc.TargetId); else set.Remove(gc.TargetId);
            }
        }

        // --- Roller (doğrudan + grup grant) ---
        var roleIds = new HashSet<int>(directRoles);
        foreach (var g in groups) roleIds.UnionWith(g.GrantedRoleIds);
        var roleIdList = roleIds.ToList();
        var roleRows = await db.Roles.AsNoTracking()
            .Where(r => r.IsActive && roleIdList.Contains(r.Id))
            .Select(r => new { r.Id, r.Code, r.Name, Perms = r.Permissions.Select(p => p.PermissionId).ToList() })
            .ToListAsync(ct);
        var roles = roleRows.ToDictionary(r => r.Id, r => new RoleSlice
        {
            Id = r.Id, Code = r.Code, Name = r.Name, PermissionIds = r.Perms.ToHashSet()
        });

        if (changes is not null)
            foreach (var rc in changes.RolePermissionChanges)
                if (roles.TryGetValue(rc.RoleId, out var role))
                    if (rc.Add) role.PermissionIds.Add(rc.PermissionId); else role.PermissionIds.Remove(rc.PermissionId);

        // --- Permission meta verisi ---
        var permIds = new HashSet<int>(directPerms);
        foreach (var r in roles.Values) permIds.UnionWith(r.PermissionIds);
        foreach (var g in groups) permIds.UnionWith(g.GrantedPermissionIds);
        var permIdList = permIds.ToList();
        var permissions = await db.Permissions.AsNoTracking()
            .Where(p => p.IsActive && permIdList.Contains(p.Id))
            .Select(p => new PermissionInfo(p.Id, p.Code, p.Name, p.Domain, p.Policies.Any(pp => pp.Policy.IsActive)))
            .ToDictionaryAsync(p => p.Id, ct);

        var ouIdList = orgUnits.ToList();
        var ous = await db.OrganizationUnits.AsNoTracking()
            .Where(o => ouIdList.Contains(o.Id))
            .Select(o => new OrgUnitInfo(o.Id, o.Code, o.Name))
            .ToDictionaryAsync(o => o.Id, ct);

        return new AuthorizationGraphSlice
        {
            Subject = new SubjectSlice
            {
                UserId = user.Id, UserName = user.UserName, FullName = user.FullName, IsActive = user.IsActive,
                DirectRoleIds = directRoles, DirectPermissionIds = directPerms, OrgUnitIds = orgUnits
            },
            Groups = groups,
            Roles = roles,
            Permissions = permissions,
            OrgUnits = ous
        };
    }

    private static void Apply(HashSet<int> set, IEnumerable<int> add, IEnumerable<int> remove)
    {
        foreach (var id in remove) set.Remove(id);
        foreach (var id in add) set.Add(id);
    }
}
