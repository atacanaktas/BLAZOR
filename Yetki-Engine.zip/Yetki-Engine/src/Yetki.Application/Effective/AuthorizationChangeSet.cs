namespace Yetki.Application.Effective;

public enum GroupChangeKind
{
    /// <summary>Kitle: kullanıcıyı doğrudan gruba ekle/çıkar.</summary>
    AudienceUser = 1,
    /// <summary>Kitle: bu role doğrudan sahip herkes.</summary>
    AudienceRole = 2,
    /// <summary>Kitle: bu birimdeki herkes.</summary>
    AudienceOrgUnit = 3,
    /// <summary>Grant: gruba permission ver/geri al.</summary>
    GrantPermission = 4,
    /// <summary>Grant: gruba rol ver/geri al.</summary>
    GrantRole = 5
}

public sealed record RolePermissionChange(int RoleId, int PermissionId, bool Add);

public sealed record GroupChange(int GroupId, GroupChangeKind Kind, int TargetId, bool Add);

/// <summary>
/// Henüz uygulanmamış (veya uygulanmak üzere olan) yetki değişikliği.
/// Hem What-If simülasyonu hem de gerçek atama akışı AYNI change set ve AYNI hesaplayıcıyı kullanır;
/// böylece simülasyon ile gerçek karar arasında semantik fark oluşmaz.
/// </summary>
public sealed class AuthorizationChangeSet
{
    /// <summary>Kullanıcı seviyesindeki (subject) değişikliklerin uygulanacağı kullanıcı.</summary>
    public int? UserId { get; set; }

    public List<int> AddUserRoleIds { get; set; } = new();
    public List<int> RemoveUserRoleIds { get; set; } = new();
    public List<int> AddUserPermissionIds { get; set; } = new();
    public List<int> RemoveUserPermissionIds { get; set; } = new();
    public List<int> AddUserOrgUnitIds { get; set; } = new();
    public List<int> RemoveUserOrgUnitIds { get; set; } = new();

    public List<RolePermissionChange> RolePermissionChanges { get; set; } = new();
    public List<GroupChange> GroupChanges { get; set; } = new();

    public bool HasSubjectChanges =>
        AddUserRoleIds.Count + RemoveUserRoleIds.Count + AddUserPermissionIds.Count +
        RemoveUserPermissionIds.Count + AddUserOrgUnitIds.Count + RemoveUserOrgUnitIds.Count > 0;

    public bool IsEmpty => !HasSubjectChanges && RolePermissionChanges.Count == 0 && GroupChanges.Count == 0;

    public static AuthorizationChangeSet ForUser(int userId) => new() { UserId = userId };
}
