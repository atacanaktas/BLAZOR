using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;

namespace Yetki.Application.Effective;

public sealed record PermissionHolder(int UserId, string UserName, string FullName, IReadOnlyList<PermissionSource> Sources);

/// <summary>
/// "Bu permission kimde var?" sorusu. Önce set-based sorgularla aday kullanıcılar bulunur, sonra her aday
/// gerçek hesaplayıcı ile doğrulanır (süreli atama, pasif rol vb. doğru ele alınsın diye).
/// </summary>
public sealed class PermissionHolderService(IYetkiDbContext db, EffectivePermissionService effective)
{
    public async Task<IReadOnlyList<PermissionHolder>> FindHoldersAsync(int permissionId, CancellationToken ct = default)
    {
        var roleIds = await db.RolePermissions.AsNoTracking().Where(x => x.PermissionId == permissionId).Select(x => x.RoleId).ToListAsync(ct);

        var candidates = new HashSet<int>();
        candidates.UnionWith(await db.UserRoles.AsNoTracking().Where(x => roleIds.Contains(x.RoleId)).Select(x => x.UserId).ToListAsync(ct));
        candidates.UnionWith(await db.UserPermissions.AsNoTracking().Where(x => x.PermissionId == permissionId).Select(x => x.UserId).ToListAsync(ct));

        var groupIds = new HashSet<int>(await db.GroupPermissions.AsNoTracking().Where(x => x.PermissionId == permissionId).Select(x => x.GroupId).ToListAsync(ct));
        groupIds.UnionWith(await db.GroupGrantedRoles.AsNoTracking().Where(x => roleIds.Contains(x.RoleId)).Select(x => x.GroupId).ToListAsync(ct));
        var groupList = groupIds.ToList();
        candidates.UnionWith(await db.GroupUsers.AsNoTracking().Where(x => groupList.Contains(x.GroupId)).Select(x => x.UserId).ToListAsync(ct));
        var audRoles = await db.GroupRoles.AsNoTracking().Where(x => groupList.Contains(x.GroupId)).Select(x => x.RoleId).ToListAsync(ct);
        var audOus = await db.GroupOrganizationUnits.AsNoTracking().Where(x => groupList.Contains(x.GroupId)).Select(x => x.OrganizationUnitId).ToListAsync(ct);
        candidates.UnionWith(await db.UserRoles.AsNoTracking().Where(x => audRoles.Contains(x.RoleId)).Select(x => x.UserId).ToListAsync(ct));
        candidates.UnionWith(await db.UserOrganizationUnits.AsNoTracking().Where(x => audOus.Contains(x.OrganizationUnitId)).Select(x => x.UserId).ToListAsync(ct));

        var result = new List<PermissionHolder>();
        foreach (var userId in candidates.Order())
        {
            var set = await effective.GetAsync(userId, null, useCache: true, ct);
            var p = set?.Permissions.FirstOrDefault(x => x.PermissionId == permissionId);
            if (set is not null && p is not null && set.IsActive)
                result.Add(new PermissionHolder(set.UserId, set.UserName, set.FullName, p.Sources));
        }
        return result;
    }
}
