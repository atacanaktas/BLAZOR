using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Yetki.Application.Abstractions;
using Yetki.Application.Common;
using Yetki.Domain.Common;
using Yetki.Domain.Events;

namespace Yetki.Application.Events;

/// <summary>
/// EffectivePermissionsChanged -> permission'ın external mapping'leri -> ProvisioningAction kayıtları -> adaptör.
/// Authorization kararı bu akıştan bağımsızdır; provisioning başarısız olsa bile yetki kararı etkilenmez.
/// İleride ayrı bir Provisioning Service'e taşınabilir (aynı outbox event'ini tüketerek).
/// </summary>
public sealed class ProvisioningEventHandler(
    IYetkiDbContext db,
    IEnumerable<IProvisioningAdapter> adapters,
    IClock clock,
    ILogger<ProvisioningEventHandler> logger) : IOutboxEventHandler
{
    public bool CanHandle(string eventType) => eventType == EventTypes.EffectivePermissionsChanged;

    public async Task HandleAsync(OutboxEvent evt, CancellationToken ct)
    {
        var payload = JsonSerializer.Deserialize<EffectivePermissionsChangedPayload>(evt.PayloadJson, JsonDefaults.Options)
                      ?? throw new InvalidOperationException("Geçersiz payload");

        var actions = new List<ProvisioningAction>();
        actions.AddRange(await BuildAsync(evt, payload, payload.Added, ProvisioningActionType.Grant, ct));
        actions.AddRange(await BuildAsync(evt, payload, payload.Removed, ProvisioningActionType.Revoke, ct));
        if (actions.Count == 0) return;

        db.ProvisioningActions.AddRange(actions);
        await db.SaveChangesAsync(ct);

        foreach (var action in actions)
        {
            var adapter = adapters.FirstOrDefault(a => string.Equals(a.SystemCode, action.ExternalSystemCode, StringComparison.OrdinalIgnoreCase))
                          ?? adapters.FirstOrDefault(a => a.SystemCode == "*");
            if (adapter is null)
            {
                action.Status = ProvisioningStatus.Failed;
                action.ResultMessage = "Bu sistem için adaptör yok.";
                continue;
            }
            try
            {
                var outcome = await adapter.ExecuteAsync(new ProvisioningRequest(action.UserId, action.UserName, action.PermissionCode,
                    action.ExternalSystemCode, action.ExternalPermissionCode, action.ActionType), ct);
                action.AdapterName = adapter.Name;
                action.Status = outcome.Success ? ProvisioningStatus.Completed : ProvisioningStatus.Failed;
                action.ResultMessage = outcome.Message;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Provisioning adapter {Adapter} failed", adapter.Name);
                action.AdapterName = adapter.Name;
                action.Status = ProvisioningStatus.Failed;
                action.ResultMessage = ex.Message;
            }
            action.CompletedAt = clock.UtcNow;
        }
        await db.SaveChangesAsync(ct);
    }

    private async Task<List<ProvisioningAction>> BuildAsync(
        OutboxEvent evt, EffectivePermissionsChangedPayload payload, IReadOnlyList<PermissionRef> perms,
        ProvisioningActionType type, CancellationToken ct)
    {
        if (perms.Count == 0) return [];
        var ids = perms.Select(p => p.PermissionId).ToList();
        var mappings = await db.PermissionExternalMappings.AsNoTracking()
            .Where(m => ids.Contains(m.PermissionId))
            .Select(m => new
            {
                m.PermissionId,
                System = m.ExternalPermission.ExternalSystem.Code,
                Ext = m.ExternalPermission.Code
            }).ToListAsync(ct);

        return mappings.Select(m => new ProvisioningAction
        {
            OutboxEventId = evt.Id,
            UserId = payload.UserId,
            UserName = payload.UserName,
            PermissionCode = perms.First(p => p.PermissionId == m.PermissionId).Code,
            ExternalSystemCode = m.System,
            ExternalPermissionCode = m.Ext,
            ActionType = type,
            Status = ProvisioningStatus.Pending,
            CreatedAt = clock.UtcNow
        }).ToList();
    }
}
