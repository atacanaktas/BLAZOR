using Yetki.Application.Abstractions;
using Yetki.Application.Common;
using Yetki.Domain.Events;

namespace Yetki.Application.Events;

public static class EventTypes
{
    public const string RoleAssigned = "RoleAssigned";
    public const string RoleRevoked = "RoleRevoked";
    /// <summary>Permission bir role / gruba / kullanıcıya bağlandı.</summary>
    public const string PermissionAssigned = "PermissionAssigned";
    public const string PermissionRevoked = "PermissionRevoked";
    public const string GroupMembershipChanged = "GroupMembershipChanged";
    public const string GroupGrantChanged = "GroupGrantChanged";
    public const string OrgUnitAssignmentChanged = "OrgUnitAssignmentChanged";
    public const string PolicyChanged = "PolicyChanged";
    public const string RuleChanged = "RuleChanged";
    public const string SoDRuleCreated = "SoDRuleCreated";
    public const string SoDRuleChanged = "SoDRuleChanged";
    public const string ExternalMappingChanged = "ExternalMappingChanged";

    /// <summary>
    /// Türetilmiş event: bir değişiklik sonucu kullanıcının effective permission seti değişti.
    /// Provisioning bu event'i dinler (RACF vb. gereksinimler buradan çıkar).
    /// </summary>
    public const string EffectivePermissionsChanged = "EffectivePermissionsChanged";
}

public sealed record PermissionRef(int PermissionId, string Code);

public sealed record EffectivePermissionsChangedPayload(
    int UserId, string UserName, string CauseEventType, IReadOnlyList<PermissionRef> Added, IReadOnlyList<PermissionRef> Removed);

/// <summary>Outbox'a event yazar. SaveChanges çağırana aittir (değişiklikle aynı iş birimi).</summary>
public sealed class OutboxWriter(IYetkiDbContext db, IClock clock, ICurrentActor actor)
{
    public OutboxEvent Add(string eventType, string? aggregateType, object? aggregateId, object payload)
    {
        var e = new OutboxEvent
        {
            EventType = eventType,
            AggregateType = aggregateType,
            AggregateId = aggregateId?.ToString(),
            PayloadJson = JsonDefaults.Serialize(payload),
            OccurredAt = clock.UtcNow,
            Actor = actor.Name
        };
        db.OutboxEvents.Add(e);
        return e;
    }
}

/// <summary>Outbox tüketicisi. Yeni entegrasyon = yeni handler (authorization core değişmez).</summary>
public interface IOutboxEventHandler
{
    bool CanHandle(string eventType);
    Task HandleAsync(OutboxEvent evt, CancellationToken ct);
}

public sealed record ProvisioningRequest(
    int UserId, string UserName, string PermissionCode, string ExternalSystemCode, string ExternalPermissionCode,
    Domain.Common.ProvisioningActionType ActionType);

public sealed record ProvisioningOutcome(bool Success, string Message);

/// <summary>
/// Dış sistem adaptörü (RACF, EGL/CICS, FTP/batch, başka API...). Prototipte sadece Dummy adaptör vardır.
/// SystemCode "*" olan adaptör, özel adaptörü olmayan tüm sistemler için fallback'tir.
/// </summary>
public interface IProvisioningAdapter
{
    string SystemCode { get; }
    string Name { get; }
    Task<ProvisioningOutcome> ExecuteAsync(ProvisioningRequest request, CancellationToken ct);
}
