using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Effective;
using Yetki.Domain.Audit;
using Yetki.Domain.Common;
using Yetki.Domain.Sod;

namespace Yetki.Application.Sod;

public sealed record SodMemberSnapshot(SodMemberType Type, int Id, string Code, string Name);

public sealed record SodRuleSnapshot(
    int Id, string Code, string Name, Severity Severity, SodEnforcement Enforcement, IReadOnlyList<SodMemberSnapshot> Members);

public sealed record SodMatchedMember(SodMemberType Type, int Id, string Code, string Name, IReadOnlyList<string> Paths);

public sealed record SodConflict(
    int SodRuleId, string Code, string Name, Severity Severity, SodEnforcement Enforcement,
    IReadOnlyList<SodMatchedMember> MatchedMembers)
{
    public string Describe() =>
        $"{Code}: " + string.Join(" + ", MatchedMembers.Select(m => $"{m.Code} [{string.Join(" | ", m.Paths)}]"));
}

public sealed record SodUserConflicts(int UserId, string UserName, string FullName, IReadOnlyList<SodConflict> Conflicts);

public sealed record SodScanResult(
    int ScannedUsers, int ViolatingUsers, int NewViolations, int StillOpen, int AutoResolved, double DurationMs,
    IReadOnlyList<SodUserConflicts> Details);

/// <summary>Saf SoD değerlendirici: bir effective set ve kural listesi -> çakışmalar.</summary>
public static class SodEvaluator
{
    public static IReadOnlyList<SodConflict> Evaluate(EffectivePermissionSet set, IEnumerable<SodRuleSnapshot> rules)
    {
        var result = new List<SodConflict>();
        foreach (var rule in rules)
        {
            var matched = new List<SodMatchedMember>();
            foreach (var m in rule.Members)
            {
                if (m.Type == SodMemberType.Permission)
                {
                    var p = set.Permissions.FirstOrDefault(x => x.PermissionId == m.Id);
                    if (p is not null) matched.Add(new SodMatchedMember(m.Type, m.Id, m.Code, m.Name, p.Sources.Select(s => s.Path).ToList()));
                }
                else
                {
                    var r = set.Roles.FirstOrDefault(x => x.RoleId == m.Id);
                    if (r is not null) matched.Add(new SodMatchedMember(m.Type, m.Id, m.Code, m.Name, r.Sources.Select(s => s.Text).ToList()));
                }
            }
            // Üyeler karşılıklı dışlayan küme: 2+ üyeye sahip olmak ihlaldir.
            if (matched.Count >= 2)
                result.Add(new SodConflict(rule.Id, rule.Code, rule.Name, rule.Severity, rule.Enforcement, matched));
        }
        return result;
    }
}

/// <summary>
/// SoD: atama anında kontrol + geriye dönük tarama. Sistem hiçbir zaman yetkiyi otomatik silmez;
/// ihlali SodViolations tablosunda görünür kılar.
/// </summary>
public sealed class SodService(
    IYetkiDbContext db,
    EffectivePermissionService effective,
    AuditWriter audit,
    IClock clock,
    ICurrentActor actor)
{
    public async Task<IReadOnlyList<SodRuleSnapshot>> LoadActiveRulesAsync(CancellationToken ct = default)
    {
        var rules = await db.SodRules.AsNoTracking().Where(r => r.IsActive)
            .Select(r => new { r.Id, r.Code, r.Name, r.Severity, r.Enforcement, Members = r.Members.Select(m => new { m.MemberType, m.MemberId }).ToList() })
            .ToListAsync(ct);
        return await ToSnapshotsAsync(rules.Select(r => (r.Id, r.Code, r.Name, r.Severity, r.Enforcement,
            r.Members.Select(m => (m.MemberType, m.MemberId)).ToList())).ToList(), ct);
    }

    /// <summary>Kaydedilmemiş bir kural taslağını snapshot'a çevirir (What-If: "yeni kural eklenirse kaç ihlal?").</summary>
    public async Task<SodRuleSnapshot> DraftSnapshotAsync(string code, IEnumerable<(SodMemberType Type, int Id)> members, SodEnforcement enforcement, CancellationToken ct)
    {
        var list = await ToSnapshotsAsync([(0, code, code, Severity.High, enforcement, members.ToList())], ct);
        return list[0];
    }

    public async Task<IReadOnlyList<SodConflict>> CheckAsync(EffectivePermissionSet set, CancellationToken ct = default) =>
        SodEvaluator.Evaluate(set, await LoadActiveRulesAsync(ct));

    /// <summary>İhlal kaydı açar veya mevcut açık kaydın LastSeenAt'ini günceller. SaveChanges çağırana aittir.</summary>
    public async Task<int> UpsertViolationsAsync(int userId, IEnumerable<SodConflict> conflicts, ViolationDetectionSource source, CancellationToken ct)
    {
        var now = clock.UtcNow;
        var created = 0;
        foreach (var c in conflicts)
        {
            var existing = await db.SodViolations.FirstOrDefaultAsync(v =>
                v.UserId == userId && v.SodRuleId == c.SodRuleId && v.Status != ViolationStatus.Resolved, ct);
            if (existing is not null)
            {
                existing.LastSeenAt = now;
                existing.Details = c.Describe();
                continue;
            }
            db.SodViolations.Add(new SodViolation
            {
                SodRuleId = c.SodRuleId, UserId = userId, DetectedBy = source,
                DetectedAt = now, LastSeenAt = now, Details = c.Describe(), Status = ViolationStatus.Open
            });
            created++;
        }
        return created;
    }

    /// <summary>
    /// Geriye dönük tarama: tüm aktif kullanıcılar için effective hesaplanır, ihlaller kaydedilir,
    /// artık geçerli olmayan açık ihlaller Resolved yapılır.
    /// TODO(perf): 20K+ kullanıcı için set-based SQL (rol/permission join'leri) veya batch/paralel tarama + arka plan job.
    /// </summary>
    public async Task<SodScanResult> ScanAsync(CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        var rules = await LoadActiveRulesAsync(ct);
        var userIds = await db.Users.AsNoTracking().Where(u => u.IsActive).Select(u => u.Id).ToListAsync(ct);
        var details = new List<SodUserConflicts>();
        var created = 0;
        var seen = new HashSet<(int UserId, int RuleId)>();

        foreach (var userId in userIds)
        {
            var set = await effective.GetAsync(userId, null, useCache: true, ct);
            if (set is null) continue;
            var conflicts = SodEvaluator.Evaluate(set, rules);
            if (conflicts.Count == 0) continue;
            details.Add(new SodUserConflicts(set.UserId, set.UserName, set.FullName, conflicts));
            created += await UpsertViolationsAsync(userId, conflicts, ViolationDetectionSource.RetrospectiveScan, ct);
            foreach (var c in conflicts) seen.Add((userId, c.SodRuleId));
        }

        var now = clock.UtcNow;
        var open = await db.SodViolations.Where(v => v.Status != ViolationStatus.Resolved).ToListAsync(ct);
        var autoResolved = 0;
        foreach (var v in open.Where(v => !seen.Contains((v.UserId, v.SodRuleId))))
        {
            // Pending (henüz kaydedilmemiş) yeni kayıtlar "seen" içinde olduğundan buraya düşmez.
            v.Status = ViolationStatus.Resolved;
            v.ClosedAt = now;
            v.ClosedBy = "sod-scan";
            v.Note = "Tarama sırasında çakışma artık mevcut değil; otomatik kapatıldı.";
            autoResolved++;
        }

        sw.Stop();
        var result = new SodScanResult(userIds.Count, details.Count, created, seen.Count - created, autoResolved,
            Math.Round(sw.Elapsed.TotalMilliseconds, 1), details);

        audit.Add(new AuditLog
        {
            Category = AuditCategory.SodScan, Actor = actor.Name, Action = "SodScan",
            Summary = $"{result.ScannedUsers} kullanıcı tarandı, {result.ViolatingUsers} kullanıcıda ihlal, {created} yeni kayıt, {autoResolved} otomatik kapandı.",
            DetailsJson = JsonDefaults.Serialize(new { result.ScannedUsers, result.ViolatingUsers, result.NewViolations, result.StillOpen, result.AutoResolved, result.DurationMs })
        });
        await db.SaveChangesAsync(ct);
        return result;
    }

    /// <summary>What-If: verilen kural (kaydedilmemiş olabilir) şu an kaç kullanıcıda ihlal üretir?</summary>
    public async Task<IReadOnlyList<SodUserConflicts>> SimulateRuleAsync(SodRuleSnapshot draft, CancellationToken ct = default)
    {
        var userIds = await db.Users.AsNoTracking().Where(u => u.IsActive).Select(u => u.Id).ToListAsync(ct);
        var result = new List<SodUserConflicts>();
        foreach (var id in userIds)
        {
            var set = await effective.GetAsync(id, null, useCache: true, ct);
            if (set is null) continue;
            var conflicts = SodEvaluator.Evaluate(set, [draft]);
            if (conflicts.Count > 0) result.Add(new SodUserConflicts(set.UserId, set.UserName, set.FullName, conflicts));
        }
        return result;
    }

    private async Task<IReadOnlyList<SodRuleSnapshot>> ToSnapshotsAsync(
        IReadOnlyList<(int Id, string Code, string Name, Severity Severity, SodEnforcement Enforcement, List<(SodMemberType Type, int Id)> Members)> rules,
        CancellationToken ct)
    {
        var permIds = rules.SelectMany(r => r.Members).Where(m => m.Type == SodMemberType.Permission).Select(m => m.Id).Distinct().ToList();
        var roleIds = rules.SelectMany(r => r.Members).Where(m => m.Type == SodMemberType.Role).Select(m => m.Id).Distinct().ToList();
        var perms = await db.Permissions.AsNoTracking().Where(p => permIds.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => (p.Code, p.Name), ct);
        var roles = await db.Roles.AsNoTracking().Where(r => roleIds.Contains(r.Id)).ToDictionaryAsync(r => r.Id, r => (r.Code, r.Name), ct);

        return rules.Select(r => new SodRuleSnapshot(r.Id, r.Code, r.Name, r.Severity, r.Enforcement,
            r.Members.Select(m =>
            {
                var (code, name) = m.Type == SodMemberType.Permission
                    ? perms.GetValueOrDefault(m.Id, ($"#{m.Id}", "?"))
                    : roles.GetValueOrDefault(m.Id, ($"#{m.Id}", "?"));
                return new SodMemberSnapshot(m.Type, m.Id, code, name);
            }).ToList())).ToList();
    }
}
