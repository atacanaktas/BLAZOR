using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Yetki.Application.Audit;
using Yetki.Application.Changes;
using Yetki.Application.Definitions;
using Yetki.Application.Effective;
using Yetki.Application.Evaluation;
using Yetki.Application.Events;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.PolicyEngine.Combining;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Application.PolicyEngine.Conditions.Handlers;
using Yetki.Application.Simulation;
using Yetki.Application.Sod;

namespace Yetki.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddYetkiApplication(this IServiceCollection services)
    {
        services.AddMemoryCache();
        services.AddOptions<AuthorizationEngineOptions>();

        // ---- Policy engine: condition handler'ları (davranış C#'ta). Yeni ConditionType = yeni sınıf + buraya kayıt ----
        services.AddSingleton<IConditionHandler, AlwaysConditionHandler>();
        services.AddSingleton<IConditionHandler, TimeWindowConditionHandler>();
        services.AddSingleton<IConditionHandler, IpInRangeConditionHandler>();
        services.AddSingleton<IConditionHandler, ChannelInConditionHandler>();
        services.AddSingleton<IConditionHandler, PlatformInConditionHandler>();
        services.AddSingleton<IConditionHandler, AmountExceedsSubjectLimitConditionHandler>();
        services.AddSingleton<IConditionHandler, AmountGreaterThanConditionHandler>();
        services.AddSingleton<IConditionHandler, BranchIsUserUnitConditionHandler>();
        services.AddSingleton<IConditionHandler, UserOnLeaveConditionHandler>();
        services.AddSingleton<IConditionHandler, CustomerIsSelfConditionHandler>();
        services.AddSingleton<ConditionHandlerRegistry>();
        services.AddScoped<ConditionTypeCatalogSynchronizer>();

        // ---- Combining algoritmaları (strateji) ----
        services.AddSingleton<ICombiningAlgorithm, DenyOverridesAlgorithm>();
        services.AddSingleton<ICombiningAlgorithm, PermitOverridesAlgorithm>();
        services.AddSingleton<ICombiningAlgorithm, FirstApplicableAlgorithm>();
        services.AddSingleton<CombiningAlgorithmRegistry>();

        // ---- Attribute kaynakları: kayıt sırası önceliktir. Request context her zaman ilk. ----
        services.AddScoped<IAttributeValueProvider, RequestContextAttributeProvider>();
        services.TryAddSingleton<IAttributeRedactor>(new DefaultAttributeRedactor());

        services.AddScoped<PolicyEvaluator>();
        services.AddScoped<PolicyDefinitionLoader>();
        services.AddScoped<AuthorizationEvaluator>();

        // ---- RBAC ----
        services.AddScoped<AuthorizationGraphLoader>();
        services.AddScoped<EffectivePermissionService>();
        services.AddScoped<PermissionHolderService>();

        services.AddScoped<AuditWriter>();
        services.AddScoped<OutboxWriter>();
        services.AddScoped<SodService>();
        services.AddScoped<AuthorizationChangeService>();
        services.AddScoped<AssignmentService>();
        services.AddScoped<PolicyManagementService>();
        services.AddScoped<SharedConditionService>();
        services.AddScoped<PolicyImpactService>();
        services.AddScoped<SimulationService>();

        services.AddScoped<IOutboxEventHandler, ProvisioningEventHandler>();
        return services;
    }
}
