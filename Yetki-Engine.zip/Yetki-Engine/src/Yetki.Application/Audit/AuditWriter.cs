using Yetki.Application.Abstractions;
using Yetki.Application.Common;
using Yetki.Domain.Audit;
using Yetki.Domain.Common;

namespace Yetki.Application.Audit;

/// <summary>
/// Audit kayıtlarını DbContext'e ekler (SaveChanges çağıranın sorumluluğunda). Böylece yönetim değişikliği,
/// audit kaydı ve outbox event'i aynı iş biriminde kalıcı olur.
/// TODO(perf): Yüksek hacimde karar audit'i için Channel tabanlı asenkron/batch yazıcı veya ayrı audit store.
/// </summary>
public sealed class AuditWriter(IYetkiDbContext db, IClock clock, ICurrentActor actor)
{
    public AuditLog Management(string action, string entityType, object? entityId, string summary, object? details = null)
    {
        var log = new AuditLog
        {
            Timestamp = clock.UtcNow,
            Category = AuditCategory.Management,
            Actor = actor.Name,
            Action = action,
            EntityType = entityType,
            EntityId = entityId?.ToString(),
            Summary = summary,
            DetailsJson = details is null ? null : JsonDefaults.Serialize(details)
        };
        db.AuditLogs.Add(log);
        return log;
    }

    public AuditLog Add(AuditLog log)
    {
        if (log.Timestamp == default) log.Timestamp = clock.UtcNow;
        db.AuditLogs.Add(log);
        return log;
    }
}
