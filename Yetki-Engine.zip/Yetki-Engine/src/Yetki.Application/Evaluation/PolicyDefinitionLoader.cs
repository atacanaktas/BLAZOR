using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.PolicyEngine;
using Yetki.Domain.Common;

namespace Yetki.Application.Evaluation;

/// <summary>
/// Permission'a bağlı policy'leri rule'ları ve condition ağaçlarıyla yükler (set-based, sabit sayıda sorgu);
/// ortak koşul referanslarını çözer ve opsiyonel PolicyChangeSet'i bellekte uygular (What-If).
/// Gerçek karar ve simülasyon aynı yükleyiciyi kullanır.
///  - Pasif policy'ler döndürülmez; pasif rule'lar döner (evaluator NotApplicable sayar, açıklamada görünür).
///  - Pasif / bulunamayan / döngüsel ortak koşul referansı çocuksuz Reference düğümü olur → Indeterminate (fail-closed).
/// TODO(perf): Policy ve ortak koşul tanımları nadiren değişir; IAuthorizationVersion ile anahtarlanmış cache eklenebilir.
/// </summary>
public sealed class PolicyDefinitionLoader(IYetkiDbContext db)
{
    public async Task<IReadOnlyList<PolicyDefinition>> LoadForPermissionAsync(int permissionId, PolicyChangeSet? changes, CancellationToken ct)
    {
        var policyIds = (await db.PermissionPolicies.AsNoTracking()
            .Where(pp => pp.PermissionId == permissionId)
            .Select(pp => pp.PolicyId).ToListAsync(ct)).ToHashSet();

        if (changes is not null)
            foreach (var c in changes.PermissionPolicyChanges.Where(c => c.PermissionId == permissionId))
                if (c.Add) policyIds.Add(c.PolicyId); else policyIds.Remove(c.PolicyId);

        return await LoadPoliciesAsync(policyIds.ToList(), changes, activeOnly: true, ct);
    }

    public async Task<IReadOnlyList<PolicyDefinition>> LoadPoliciesAsync(
        IReadOnlyList<int> policyIds, PolicyChangeSet? changes, bool activeOnly, CancellationToken ct)
    {
        var ids = policyIds.ToList();
        var policies = await db.Policies.AsNoTracking()
            .Where(p => ids.Contains(p.Id))
            .Select(p => new { p.Id, p.Code, p.Name, p.Version, p.IsActive, p.CombiningAlgorithm })
            .ToListAsync(ct);

        var rules = await db.Rules.AsNoTracking()
            .Where(r => ids.Contains(r.PolicyId))
            .Select(r => new { r.Id, r.PolicyId, r.Code, r.Name, r.Description, r.Effect, r.Order, r.ReasonCode, r.IsActive })
            .ToListAsync(ct);

        var resolver = await CreateResolverAsync(rules.Select(r => r.Id).ToList(), changes, ct);
        var removed = changes?.RemovedRuleIds.ToHashSet() ?? [];
        var result = new List<PolicyDefinition>();

        foreach (var p in policies.OrderBy(p => p.Code, StringComparer.Ordinal))
        {
            var active = changes?.PolicyActivations.LastOrDefault(a => a.PolicyId == p.Id)?.IsActive ?? p.IsActive;
            if (activeOnly && !active) continue;
            var algorithm = changes?.PolicyAlgorithmChanges.LastOrDefault(a => a.PolicyId == p.Id)?.Algorithm ?? p.CombiningAlgorithm;

            var defs = rules.Where(r => r.PolicyId == p.Id && !removed.Contains(r.Id))
                .Select(r =>
                {
                    var o = changes?.RuleOverrides.LastOrDefault(x => x.RuleId == r.Id);
                    var rep = changes?.ReplacedRules.LastOrDefault(x => x.RuleId == r.Id);
                    return rep is null
                        ? new RuleDefinition(r.Id, r.Code, r.Name, r.Description, o?.Effect ?? r.Effect, o?.Order ?? r.Order,
                            r.ReasonCode, o?.IsActive ?? r.IsActive, resolver.RuleRoot(r.Id))
                        : new RuleDefinition(r.Id, r.Code, rep.Rule.Name ?? r.Name, r.Description, rep.Rule.Effect, rep.Rule.Order,
                            rep.Rule.ReasonCode, o?.IsActive ?? r.IsActive, resolver.FromDraft(rep.Rule.Condition));
                }).ToList();

            if (changes is not null)
            {
                var draftRuleId = -1;
                foreach (var d in changes.AddedRules.Where(d => d.PolicyId == p.Id))
                    defs.Add(new RuleDefinition(draftRuleId--, d.Code, d.Name ?? d.Code, "What-If taslağı", d.Effect, d.Order, d.ReasonCode, true,
                        resolver.FromDraft(d.Condition)));
            }

            result.Add(new PolicyDefinition(p.Id, p.Code, p.Name, p.Version, algorithm, defs));
        }
        return result;
    }

    /// <summary>Taslak condition'ı ortak koşul referansları çözülmüş halde bellek içi ağaca çevirir (önizleme / yönetim ekranı).</summary>
    public async Task<ConditionNode> ResolveDraftAsync(ConditionDraft draft, PolicyChangeSet? changes, CancellationToken ct) =>
        (await CreateResolverAsync([], changes, ct)).FromDraft(draft);

    /// <summary>Bir ortak koşulun çözülmüş ağacı (kök; referanslar içerikleriyle).</summary>
    public async Task<ConditionNode?> LoadSharedConditionAsync(int sharedConditionId, CancellationToken ct)
    {
        var code = await db.SharedConditions.AsNoTracking().Where(s => s.Id == sharedConditionId).Select(s => s.Code).FirstOrDefaultAsync(ct);
        if (code is null) return null;
        var node = await ResolveDraftAsync(new ConditionDraft { Kind = ConditionKind.Reference, SharedConditionCode = code }, null, ct);
        return node.Children.FirstOrDefault();
    }

    /// <summary>Taslak condition ağacını (ÇÖZÜMSÜZ) bellek içi düğüme çevirir; referanslar sadece kodla gösterilir (audit metni vb.).</summary>
    public static ConditionNode FromDraft(ConditionDraft d, Func<int> nextId)
    {
        var id = nextId();
        return d.Kind == ConditionKind.Reference
            ? new ConditionNode(id, ConditionKind.Reference, null, true, Resolver.Empty, [], d.SharedConditionCode)
            : new ConditionNode(id, d.Kind, d.Kind == ConditionKind.Predicate ? d.ConditionTypeCode : null, true,
                new Dictionary<string, string>(d.Parameters, StringComparer.OrdinalIgnoreCase),
                d.Children.Select(c => FromDraft(c, nextId)).ToList());
    }

    private async Task<Resolver> CreateResolverAsync(IReadOnlyList<int> ruleIds, PolicyChangeSet? changes, CancellationToken ct)
    {
        var rIds = ruleIds.ToList();
        // Rule düğümleri + TÜM ortak koşul düğümleri (ortak koşul tablosu küçüktür; transitif referans çözümü için)
        var rows = (await db.RuleConditions.AsNoTracking()
                .Where(c => (c.RuleId != null && rIds.Contains(c.RuleId.Value)) || c.SharedConditionId != null)
                .Select(c => new
                {
                    c.Id, c.RuleId, c.SharedConditionId, c.ParentId, c.Kind, c.Order, c.ReferencedSharedConditionId,
                    TypeCode = c.ConditionType != null ? c.ConditionType.Code : null,
                    TypeAvailable = c.ConditionType == null || c.ConditionType.IsAvailable,
                    Params = c.Parameters.Select(p => new { p.Key, p.Value }).ToList()
                })
                .ToListAsync(ct))
            .Select(c => new Resolver.Row(c.Id, c.RuleId, c.SharedConditionId, c.ParentId, c.Kind, c.Order, c.TypeCode, c.TypeAvailable,
                c.ReferencedSharedConditionId, c.Params.ToDictionary(p => p.Key, p => p.Value, StringComparer.OrdinalIgnoreCase)))
            .ToList();

        var shared = (await db.SharedConditions.AsNoTracking()
                .Select(s => new { s.Id, s.Code, s.IsActive, s.Version }).ToListAsync(ct))
            .Select(s => new Resolver.SharedMeta(s.Id, s.Code, s.IsActive, s.Version))
            .ToList();

        return new Resolver(rows, shared, changes);
    }

    /// <summary>Condition satırlarını ağaçlara çevirir; ortak koşul referanslarını döngü korumalı çözer; What-If değişikliklerini uygular.</summary>
    private sealed class Resolver
    {
        public sealed record Row(int Id, int? RuleId, int? SharedId, int? ParentId, ConditionKind Kind, int Order,
            string? TypeCode, bool TypeAvailable, int? RefId, Dictionary<string, string> Params);

        public sealed record SharedMeta(int Id, string Code, bool IsActive, int Version);

        public static readonly IReadOnlyDictionary<string, string> Empty = new Dictionary<string, string>();

        private readonly ILookup<(int, int?), Row> _ruleChildren;
        private readonly ILookup<(int, int?), Row> _sharedChildren;
        private readonly Dictionary<int, SharedMeta> _sharedById;
        private readonly Dictionary<string, int> _sharedIdByCode;
        private readonly Dictionary<int, Dictionary<string, string>> _paramOverrides;
        private readonly Dictionary<int, ConditionDraft> _sharedReplacements;
        private int _draftNodeId;

        public Resolver(List<Row> rows, List<SharedMeta> shared, PolicyChangeSet? changes)
        {
            _ruleChildren = rows.Where(r => r.RuleId != null).ToLookup(r => (r.RuleId!.Value, r.ParentId));
            _sharedChildren = rows.Where(r => r.SharedId != null).ToLookup(r => (r.SharedId!.Value, r.ParentId));
            _sharedById = shared.ToDictionary(s => s.Id);
            _sharedIdByCode = shared.ToDictionary(s => s.Code, s => s.Id, StringComparer.OrdinalIgnoreCase);
            _paramOverrides = changes?.ConditionOverrides.GroupBy(o => o.ConditionId).ToDictionary(g => g.Key, g => g.Last().Parameters) ?? [];
            _sharedReplacements = changes?.SharedConditionReplacements.GroupBy(r => r.SharedConditionId).ToDictionary(g => g.Key, g => g.Last().Condition) ?? [];
        }

        public ConditionNode? RuleRoot(int ruleId)
        {
            var root = _ruleChildren[(ruleId, null)].OrderBy(c => c.Order).FirstOrDefault();
            return root is null ? null : Build(root, new HashSet<int>(), id => _ruleChildren[(ruleId, id)]);
        }

        public ConditionNode FromDraft(ConditionDraft d) => FromDraft(d, new HashSet<int>());

        private ConditionNode FromDraft(ConditionDraft d, IReadOnlySet<int> path)
        {
            var id = --_draftNodeId;
            if (d.Kind == ConditionKind.Reference) return Reference(null, d.SharedConditionCode, id, path);
            return new ConditionNode(id, d.Kind, d.Kind == ConditionKind.Predicate ? d.ConditionTypeCode : null, true,
                new Dictionary<string, string>(d.Parameters, StringComparer.OrdinalIgnoreCase),
                d.Children.Select(c => FromDraft(c, path)).ToList());
        }

        private ConditionNode Build(Row row, IReadOnlySet<int> path, Func<int?, IEnumerable<Row>> childrenOf)
        {
            if (row.Kind == ConditionKind.Reference) return Reference(row.RefId, null, row.Id, path);
            return new ConditionNode(row.Id, row.Kind, row.TypeCode, row.TypeAvailable,
                _paramOverrides.TryGetValue(row.Id, out var o) ? new Dictionary<string, string>(o, StringComparer.OrdinalIgnoreCase) : row.Params,
                childrenOf(row.Id).OrderBy(c => c.Order).ThenBy(c => c.Id).Select(c => Build(c, path, childrenOf)).ToList());
        }

        private ConditionNode Reference(int? refId, string? refCode, int nodeId, IReadOnlySet<int> path)
        {
            var sid = refId ?? (refCode is not null && _sharedIdByCode.TryGetValue(refCode, out var byCode) ? byCode : null);
            if (sid is null || !_sharedById.TryGetValue(sid.Value, out var meta))
                return new ConditionNode(nodeId, ConditionKind.Reference, null, true, Empty, [], refCode ?? $"#{refId}");
            // Pasif veya döngüsel referans → çocuksuz düğüm → evaluator Indeterminate (fail-closed)
            if (!meta.IsActive || path.Contains(meta.Id))
                return new ConditionNode(nodeId, ConditionKind.Reference, null, true, Empty, [], meta.Code, meta.Version);

            var inner = new HashSet<int>(path) { meta.Id };
            ConditionNode? root;
            if (_sharedReplacements.TryGetValue(meta.Id, out var replacement))
                root = FromDraft(replacement, inner);
            else
            {
                var r = _sharedChildren[(meta.Id, null)].OrderBy(x => x.Order).FirstOrDefault();
                root = r is null ? null : Build(r, inner, id => _sharedChildren[(meta.Id, id)]);
            }
            return new ConditionNode(nodeId, ConditionKind.Reference, null, true, Empty, root is null ? [] : [root], meta.Code, meta.Version);
        }
    }
}
