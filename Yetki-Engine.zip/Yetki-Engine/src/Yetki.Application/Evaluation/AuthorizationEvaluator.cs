using System.Diagnostics;
using System.Globalization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Context;
using Yetki.Application.Effective;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.PolicyEngine.Combining;
using Yetki.Domain.Audit;
using Yetki.Domain.Common;

namespace Yetki.Application.Evaluation;

/// <summary>
/// Yetkilendirme orkestratörü (PDP). Akış:
///
///   Request → Subject çözümü → [RBAC] Effective permission kontrolü → Policy çözümü
///           → [Policy Engine] Rule değerlendirme → Combining algorithm (rule→policy, policy→permission)
///           → Decision → Audit
///
/// RBAC sorusu ("kullanıcının bu permission'ı var mı?") ile policy sorusu ("bu context'te kullanılabilir mi?")
/// ayrı bileşenlerdedir (EffectivePermissionService / PolicyEvaluator). Gerçek karar ve What-If aynı metodu kullanır.
/// Fail-closed: eksik attribute, handler yok, hata → asla Permit değil.
/// </summary>
public sealed class AuthorizationEvaluator(
    IYetkiDbContext db,
    EffectivePermissionService effective,
    PolicyDefinitionLoader policyLoader,
    PolicyEvaluator policyEvaluator,
    CombiningAlgorithmRegistry algorithms,
    IEnumerable<IAttributeValueProvider> attributeProviders,
    IAttributeRedactor redactor,
    IOptions<AuthorizationEngineOptions> engineOptions,
    AuditWriter audit,
    IClock clock,
    ILogger<AuthorizationEvaluator> logger)
{
    private readonly IReadOnlyList<IAttributeValueProvider> _providers = attributeProviders.ToList();

    public async Task<AuthorizationDecision> EvaluateAsync(
        AuthorizationRequest request, EvaluationOptions? options = null, CancellationToken ct = default)
    {
        options ??= EvaluationOptions.Default;
        var sw = Stopwatch.StartNew();
        var permissionCode = Codes.Normalize(request.Permission ?? "");
        var decision = new AuthorizationDecision
        {
            DecisionId = Guid.NewGuid(),
            Permission = permissionCode,
            Action = string.IsNullOrWhiteSpace(request.Action) ? permissionCode : request.Action.Trim(),
            Resource = request.Resource is null ? null : new ResourceRef(request.Resource.Type, request.Resource.Id).ToString(),
            UserName = request.Subject?.UserName,
            IsSimulation = options.IsSimulation,
            EvaluatedAt = clock.UtcNow,
            PolicyCombiningAlgorithm = engineOptions.Value.PolicyCombiningAlgorithm
        };

        var context = BuildContext(request, options);
        decision.Context = context.Values;

        try
        {
            await EvaluateCoreAsync(request, options, permissionCode, context, decision, ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogError(ex, "Authorization evaluation failed for {User}/{Permission}", request.Subject?.UserName, permissionCode);
            Set(decision, DecisionType.Indeterminate, "ENGINE_ERROR", "Karar motorunda hata oluştu; güvenli tarafta kalınarak izin verilmedi.");
        }

        sw.Stop();
        decision.DurationMs = Math.Round(sw.Elapsed.TotalMilliseconds, 3);

        if (options.WriteAudit)
        {
            WriteAudit(decision, request, options);
            await db.SaveChangesAsync(ct);
        }
        return decision;
    }

    private async Task EvaluateCoreAsync(
        AuthorizationRequest request, EvaluationOptions options, string permissionCode,
        AuthorizationContext context, AuthorizationDecision decision, CancellationToken ct)
    {
        // ---------------- 1) Subject ----------------
        int? userId = request.Subject?.UserId;
        if (userId is null && !string.IsNullOrWhiteSpace(request.Subject?.UserName))
            userId = await effective.ResolveUserIdAsync(request.Subject.UserName, ct);
        var set = userId is null ? null : await effective.GetAsync(userId.Value, options.Changes, useCache: options.Changes is null, ct);
        if (set is null)
        {
            Set(decision, DecisionType.Deny, "USER_NOT_FOUND", "Kullanıcı bulunamadı.");
            return;
        }
        decision.UserName = set.UserName;
        decision.AuthorizationVersion = set.Version;
        if (!set.IsActive)
        {
            Set(decision, DecisionType.Deny, "USER_INACTIVE", $"Kullanıcı '{set.UserName}' pasif.");
            return;
        }

        // ---------------- 2) RBAC: effective permission ----------------
        var held = set.Find(permissionCode);
        if (held is null)
        {
            var exists = await db.Permissions.AsNoTracking().AnyAsync(p => p.Code == permissionCode && p.IsActive, ct);
            if (exists)
                Set(decision, DecisionType.Deny, "PERMISSION_NOT_GRANTED",
                    $"'{set.UserName}' kullanıcısının '{permissionCode}' yetkisi yok (hiçbir rol/grup/doğrudan atama vermiyor).");
            else
                Set(decision, DecisionType.Deny, "PERMISSION_UNKNOWN", $"'{permissionCode}' tanımlı/aktif bir permission değil.");
            return;
        }
        decision.PermissionSources = held.Sources;

        // ---------------- 3) Policy çözümü ----------------
        var policies = await policyLoader.LoadForPermissionAsync(held.PermissionId, options.PolicyChanges, ct);
        if (policies.Count == 0)
        {
            var d = engineOptions.Value.NoPolicyDecision;
            Set(decision, d, d == DecisionType.Permit ? "PERMIT_NO_POLICY" : "NO_POLICY",
                d == DecisionType.Permit
                    ? $"Yetki var ({held.Sources[0].Path}); bağlı aktif policy yok → statik yetki (Permit)."
                    : $"Yetki var ancak bağlı aktif policy yok; motor ayarı gereği {d}.");
            return;
        }

        // ---------------- 4) Policy engine: rule değerlendirme + combining ----------------
        var resolver = new AttributeResolver(_providers, new AttributeResolutionScope
        {
            Subject = new SubjectRef(set.UserId, set.UserName),
            Context = context,
            Action = decision.Action,
            Resource = request.Resource is null ? null : new ResourceRef(request.Resource.Type, request.Resource.Id)
        });

        var evaluations = new List<PolicyEvaluation>();
        foreach (var p in policies)
            evaluations.Add(await policyEvaluator.EvaluateAsync(p, resolver, permissionCode, ct));

        var combined = algorithms.Get(engineOptions.Value.PolicyCombiningAlgorithm).Combine(evaluations.Select(e => e.Result).ToList());
        if (combined.DecidingIndex is { } di) evaluations[di] = evaluations[di] with { IsDeciding = true };

        decision.Policies = evaluations;
        decision.Evidence = resolver.Used.DistinctBy(u => u.Attribute).ToList();
        var rules = evaluations.SelectMany(e => e.Rules).ToList();
        decision.FailedRules = rules.Where(r => r.Result is DecisionType.Deny or DecisionType.Indeterminate).Select(r => r.Code).Distinct().ToList();
        decision.PermitRules = rules.Where(r => r.Result == DecisionType.Permit).Select(r => r.Code).Distinct().ToList();
        decision.MissingAttributes = rules.SelectMany(r => r.MissingAttributes).Distinct().ToList();

        // ---------------- 5) Karar + açıklama ----------------
        var decidingPolicy = combined.DecidingIndex is { } pi ? evaluations[pi] : null;
        var decidingRule = decidingPolicy?.Rules.FirstOrDefault(r => r.IsDeciding);
        decision.DecidingPolicy = decidingPolicy?.Code;
        decision.DecidingRule = decidingRule?.Code;

        switch (combined.Decision)
        {
            case DecisionType.Deny:
                Set(decision, DecisionType.Deny, decidingRule?.ReasonCode ?? decidingRule?.Code ?? "DENIED_BY_POLICY",
                    $"{decidingPolicy!.Code} / {decidingRule?.Code}: {decidingRule?.Name}. {decidingRule?.Condition?.Message}");
                break;
            case DecisionType.Permit:
                Set(decision, DecisionType.Permit, decidingRule?.ReasonCode ?? "PERMIT",
                    $"Yetki var ({held.Sources[0].Path}); {evaluations.Count} policy {engineOptions.Value.PolicyCombiningAlgorithm} ile Permit " +
                    $"(karar veren: {decidingPolicy!.Code} / {decidingRule?.Code}).");
                break;
            case DecisionType.Indeterminate:
                Set(decision, DecisionType.Indeterminate, decision.MissingAttributes.Count > 0 ? "MISSING_ATTRIBUTE" : "EVALUATION_ERROR",
                    decision.MissingAttributes.Count > 0
                        ? $"Karar için gerekli değer eksik: {string.Join(", ", decision.MissingAttributes)} ({decidingRule?.Code}). Güvenli tarafta kalınarak izin verilmedi."
                        : $"{decidingRule?.Code} değerlendirilemedi: {decidingRule?.Condition?.Message}. Güvenli tarafta kalınarak izin verilmedi.");
                break;
            default:
                Set(decision, DecisionType.NotApplicable, "NO_APPLICABLE_RULE",
                    "Hiçbir rule uygulanamadı (Permit rule'u tanımlı değil veya koşulu sağlanmadı). NotApplicable izin vermez.");
                break;
        }
    }

    private AuthorizationContext BuildContext(AuthorizationRequest request, EvaluationOptions options)
    {
        var context = new AuthorizationContext(request.Context);

        // Zaman otoritesi motordur. Çağıranın gönderdiği zaman sadece audit için saklanır.
        if (context.GetString(AuthContextKeys.CurrentTime) is { } callerTime)
            context.Set(AuthContextKeys.CallerTime, callerTime);
        var now = options.IsSimulation && options.AsOfUtc is { } asOf ? asOf.ToUniversalTime() : clock.UtcNow;
        context.Set(AuthContextKeys.CurrentTime, now.ToString("o", CultureInfo.InvariantCulture));

        if (!string.IsNullOrWhiteSpace(request.Application))
            context.Set(AuthContextKeys.Application, request.Application);
        return context;
    }

    private static void Set(AuthorizationDecision d, DecisionType type, string reasonCode, string message)
    {
        d.Decision = type;
        d.ReasonCode = reasonCode;
        d.HumanReadableReason = message.Trim();
    }

    private void WriteAudit(AuthorizationDecision d, AuthorizationRequest request, EvaluationOptions options)
    {
        string? R(string attribute, string? value) => redactor.Redact(attribute, value);
        audit.Add(new AuditLog
        {
            Id = d.DecisionId,
            Timestamp = d.EvaluatedAt,
            Category = options.IsSimulation ? AuditCategory.Simulation : AuditCategory.AuthorizationDecision,
            Actor = options.Actor ?? request.Application ?? "unknown-app",
            Action = options.IsSimulation ? "SimulatedEvaluate" : "Evaluate",
            SubjectUserName = d.UserName,
            PermissionCode = d.Permission,
            Resource = d.Resource,
            Decision = d.Decision.ToString(),
            ReasonCode = d.ReasonCode,
            Summary = d.HumanReadableReason,
            CorrelationId = request.CorrelationId,
            DetailsJson = JsonDefaults.Serialize(new
            {
                Context = d.Context.ToDictionary(kv => kv.Key, kv => R(AttributeId.ForRequestKey(kv.Key).ToString(), kv.Value)),
                Evidence = d.Evidence.Select(e => e with { Value = R(e.Attribute, e.Value) }),
                d.PermissionSources,
                d.DecidingPolicy,
                d.DecidingRule,
                Policies = d.Policies.Select(p => new
                {
                    p.Code, p.Version, p.Algorithm, p.Result, p.DecidingRule,
                    Rules = p.Rules.Select(r => new { r.Code, r.Effect, r.ConditionValue, r.Result, r.ReasonCode, r.Expression })
                }),
                d.FailedRules,
                d.MissingAttributes,
                d.AuthorizationVersion,
                d.DurationMs
            })
        });
    }
}
