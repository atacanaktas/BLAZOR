using Yetki.Application.Effective;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Domain.Common;

namespace Yetki.Application.Evaluation;

public sealed class SubjectInfo
{
    public string? UserName { get; set; }
    public int? UserId { get; set; }
}

public sealed class ResourceInfo
{
    public string? Type { get; set; }
    public string? Id { get; set; }
}

/// <summary>
/// Standart yetkilendirme isteği:  Subject + Permission (+ Action) + Resource + Context.
/// Context'teki hiçbir alan zorunlu değildir; bir rule ihtiyaç duyduğu değeri bulamazsa sonuç Indeterminate olur (asla Permit değil).
/// </summary>
public sealed class AuthorizationRequest
{
    public SubjectInfo Subject { get; set; } = new();
    /// <summary>Permission kodu (ör. CASH_WITHDRAW).</summary>
    public string Permission { get; set; } = default!;
    /// <summary>Opsiyonel işlem adı (ör. "withdraw"). Boşsa Permission kullanılır.</summary>
    public string? Action { get; set; }
    public ResourceInfo? Resource { get; set; }
    /// <summary>Normalize context (AuthContextKeys): TransactionAmount, CustomerId, BranchCode, IpAddress, Channel, Platform, Device...</summary>
    public Dictionary<string, string?> Context { get; set; } = new();
    /// <summary>Çağıran uygulama (SDK doldurur).</summary>
    public string? Application { get; set; }
    public string? CorrelationId { get; set; }
}

/// <summary>Motor davranış ayarları (appsettings: "AuthorizationEngine").</summary>
public sealed class AuthorizationEngineOptions
{
    /// <summary>
    /// RBAC permission var ama bağlı aktif policy yoksa verilecek karar. Varsayılan Permit:
    /// policy'siz permission'lar statik yetkidir (menü/ekran erişimi gibi).
    /// </summary>
    public DecisionType NoPolicyDecision { get; set; } = DecisionType.Permit;

    /// <summary>Bir permission'a birden çok policy bağlıysa policy sonuçlarının birleştirilmesi (policy-set seviyesi).</summary>
    public CombiningAlgorithm PolicyCombiningAlgorithm { get; set; } = CombiningAlgorithm.DenyOverrides;
}

/// <summary>Açıklanabilir karar. Sadece bool değil; karar, neden, kararı veren policy/rule, kullanılan değerler.</summary>
public sealed class AuthorizationDecision
{
    public Guid DecisionId { get; set; }
    public DecisionType Decision { get; set; }
    /// <summary>Enforcement için tek doğru: yalnızca Permit izin verir. Deny/NotApplicable/Indeterminate → reddet.</summary>
    public bool IsAllowed => Decision == DecisionType.Permit;
    public string ReasonCode { get; set; } = default!;
    public string HumanReadableReason { get; set; } = default!;

    public string? UserName { get; set; }
    public string Permission { get; set; } = default!;
    public string Action { get; set; } = default!;
    public string? Resource { get; set; }
    public string? DecidingPolicy { get; set; }
    public string? DecidingRule { get; set; }

    public DateTime EvaluatedAt { get; set; }
    public bool IsSimulation { get; set; }
    public long AuthorizationVersion { get; set; }
    public double DurationMs { get; set; }

    /// <summary>RBAC: permission'ın kullanıcıya nereden geldiği.</summary>
    public IReadOnlyList<PermissionSource> PermissionSources { get; set; } = [];
    public CombiningAlgorithm PolicyCombiningAlgorithm { get; set; }
    public IReadOnlyList<PolicyEvaluation> Policies { get; set; } = [];

    /// <summary>Deny veya Indeterminate üreten rule'lar.</summary>
    public IReadOnlyList<string> FailedRules { get; set; } = [];
    /// <summary>Permit üreten rule'lar.</summary>
    public IReadOnlyList<string> PermitRules { get; set; } = [];
    public IReadOnlyList<string> MissingAttributes { get; set; } = [];
    /// <summary>Değerlendirmede kullanılan attribute değerleri (audit'te IAttributeRedactor ile maskelenir).</summary>
    public IReadOnlyList<UsedAttribute> Evidence { get; set; } = [];
    public IReadOnlyDictionary<string, string?> Context { get; set; } = new Dictionary<string, string?>();
}

/// <summary>Aynı evaluator'ın What-If için parametreleri. Gerçek kararda hepsi boştur.</summary>
public sealed class EvaluationOptions
{
    /// <summary>Uygulanmamış RBAC atama değişiklikleri.</summary>
    public AuthorizationChangeSet? Changes { get; init; }
    /// <summary>Uygulanmamış policy/rule değişiklikleri.</summary>
    public PolicyChangeSet? PolicyChanges { get; init; }
    /// <summary>Sadece simülasyonda: kararın hangi an için verileceği. Gerçek kararda motor saati kullanılır.</summary>
    public DateTime? AsOfUtc { get; init; }
    public bool IsSimulation { get; init; }
    public bool WriteAudit { get; init; } = true;
    public string? Actor { get; init; }

    public static readonly EvaluationOptions Default = new();
}
