using Yetki.Domain.Common;

namespace Yetki.Application.Evaluation;

public sealed record PermissionPolicyChange(int PermissionId, int PolicyId, bool Add);

public sealed record PolicyActivationChange(int PolicyId, bool IsActive);

public sealed record PolicyAlgorithmChange(int PolicyId, CombiningAlgorithm Algorithm);

/// <summary>Mevcut bir rule'un aktifliğini / effect'ini / sırasını simülasyonda değiştirir.</summary>
public sealed record RuleOverride(int RuleId, bool? IsActive = null, RuleEffect? Effect = null, int? Order = null);

/// <summary>Bir predicate düğümünün parametrelerini (tamamen) değiştirir. Ör. mesai bitişi 18:00 → 17:00.</summary>
public sealed record ConditionParameterOverride(int ConditionId, Dictionary<string, string> Parameters);

/// <summary>
/// Condition ifade ağacı taslağı. Hem yönetim API'sinde (rule oluştur/güncelle) hem What-If'te kullanılır.
/// Predicate: ConditionTypeCode + Parameters · AllOf/AnyOf: Children · Not: tek Child.
/// </summary>
public sealed class ConditionDraft
{
    public ConditionKind Kind { get; set; } = ConditionKind.Predicate;
    public string? ConditionTypeCode { get; set; }
    /// <summary>Kind=Reference için: referans verilen ortak koşulun kodu.</summary>
    public string? SharedConditionCode { get; set; }
    public Dictionary<string, string> Parameters { get; set; } = new();
    public List<ConditionDraft> Children { get; set; } = new();
}

/// <summary>Henüz var olmayan bir rule (What-If'te "policy'ye şu rule eklenirse").</summary>
public sealed class RuleDraft
{
    public int PolicyId { get; set; }
    public string Code { get; set; } = "DRAFT_RULE";
    public string? Name { get; set; }
    public RuleEffect Effect { get; set; } = RuleEffect.Deny;
    public int Order { get; set; } = 50;
    public string? ReasonCode { get; set; }
    public ConditionDraft Condition { get; set; } = new();
}

/// <summary>Bir ortak koşulun tanımının (ağacının) değiştirilmesi — onu kullanan TÜM policy'leri etkiler.</summary>
public sealed record SharedConditionReplacement(int SharedConditionId, ConditionDraft Condition);

/// <summary>Mevcut bir rule'un tamamen yeni tanımla (effect + condition) değiştirilmesi (rule düzenleme önizlemesi).</summary>
public sealed record RuleReplacement(int RuleId, RuleDraft Rule);

/// <summary>
/// Uygulanmamış policy/rule değişikliği. AuthorizationChangeSet'in (RBAC) policy tarafındaki karşılığı:
/// PolicyDefinitionLoader bu değişiklikleri bellekte uygular, AYNI evaluator kararı verir.
/// </summary>
public sealed class PolicyChangeSet
{
    public List<PermissionPolicyChange> PermissionPolicyChanges { get; set; } = new();
    public List<PolicyActivationChange> PolicyActivations { get; set; } = new();
    public List<PolicyAlgorithmChange> PolicyAlgorithmChanges { get; set; } = new();
    public List<RuleOverride> RuleOverrides { get; set; } = new();
    public List<ConditionParameterOverride> ConditionOverrides { get; set; } = new();
    public List<RuleDraft> AddedRules { get; set; } = new();
    public List<int> RemovedRuleIds { get; set; } = new();
    public List<RuleReplacement> ReplacedRules { get; set; } = new();
    public List<SharedConditionReplacement> SharedConditionReplacements { get; set; } = new();

    public bool IsEmpty =>
        PermissionPolicyChanges.Count + PolicyActivations.Count + PolicyAlgorithmChanges.Count + RuleOverrides.Count
        + ConditionOverrides.Count + AddedRules.Count + RemovedRuleIds.Count + ReplacedRules.Count + SharedConditionReplacements.Count == 0;
}
