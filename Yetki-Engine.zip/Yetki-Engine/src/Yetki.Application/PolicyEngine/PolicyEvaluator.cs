using Microsoft.Extensions.Logging;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.PolicyEngine.Combining;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Domain.Common;

namespace Yetki.Application.PolicyEngine;

/// <summary>
/// Tek bir policy'yi değerlendirir. RBAC bilmez; sadece "bu permission bu context'te kullanılabilir mi?" sorusunu yanıtlar.
///
///   Rule sonucu:  Condition TRUE → Effect (Permit/Deny) · FALSE → NotApplicable · belirsiz → Indeterminate · pasif → NotApplicable
///   Policy sonucu: Policy.CombiningAlgorithm (açıkça modellenmiş strateji; servis içinde gizli "Any(Deny)" yok)
///
/// Tüm rule'lar (kısa devre yapılmadan) değerlendirilir ki açıklama eksiksiz olsun. Sıra deterministiktir (Order, Code).
/// Condition ağacı üç değerli (Kleene) mantıkla değerlendirilir: AllOf=AND, AnyOf=OR, Not.
/// </summary>
public sealed class PolicyEvaluator(ConditionHandlerRegistry handlers, CombiningAlgorithmRegistry algorithms, ILogger<PolicyEvaluator> logger)
{
    public const int MaxConditionDepth = 8;

    public async Task<PolicyEvaluation> EvaluateAsync(
        PolicyDefinition policy, AttributeResolver attributes, string permissionCode, CancellationToken ct)
    {
        var ordered = policy.Rules.OrderBy(r => r.Order).ThenBy(r => r.Code, StringComparer.Ordinal).ToList();
        var results = new List<RuleEvaluation>(ordered.Count);
        foreach (var rule in ordered)
            results.Add(await EvaluateRuleAsync(rule, attributes, permissionCode, ct));

        var combined = algorithms.Get(policy.Algorithm).Combine(results.Select(r => r.Result).ToList());
        if (combined.DecidingIndex is { } i) results[i] = results[i] with { IsDeciding = true };

        return new PolicyEvaluation(policy.PolicyId, policy.Code, policy.Name, policy.Version, policy.Algorithm,
            combined.Decision, combined.DecidingIndex is { } d ? results[d].Code : null, results);
    }

    private async Task<RuleEvaluation> EvaluateRuleAsync(RuleDefinition rule, AttributeResolver attributes, string permissionCode, CancellationToken ct)
    {
        if (!rule.IsActive)
            return new RuleEvaluation(rule.RuleId, rule.Code, rule.Name, rule.Effect, rule.Order, false, TriState.False,
                DecisionType.NotApplicable, null, "Rule pasif; değerlendirilmedi.", Render(rule.Condition), null, [], []);

        var before = attributes.Used.Count;
        ConditionTrace trace = rule.Condition is null
            ? new ConditionTrace(ConditionKind.Predicate, null, "(condition yok)", TriState.Indeterminate,
                "Rule'un condition'ı tanımlı değil (fail-closed).", null, null, null)
            : await EvaluateNodeAsync(rule.Condition, attributes, permissionCode, 0, ct);

        var result = trace.Value switch
        {
            TriState.True => rule.Effect == RuleEffect.Permit ? DecisionType.Permit : DecisionType.Deny,
            TriState.False => DecisionType.NotApplicable,
            _ => DecisionType.Indeterminate
        };
        var missing = CollectMissing(trace).Distinct().ToList();
        var message = result switch
        {
            DecisionType.Permit or DecisionType.Deny => $"Condition sağlandı → {result}. {trace.Message}",
            DecisionType.NotApplicable => $"Condition sağlanmadı → uygulanmaz. {trace.Message}",
            _ => $"Condition değerlendirilemedi → Indeterminate. {trace.Message}"
        };

        return new RuleEvaluation(rule.RuleId, rule.Code, rule.Name, rule.Effect, rule.Order, true, trace.Value, result,
            rule.ReasonCode, message.Trim(), trace.Expression, trace, missing, attributes.Used.Skip(before).ToList());
    }

    private async Task<ConditionTrace> EvaluateNodeAsync(ConditionNode node, AttributeResolver attributes, string permissionCode, int depth, CancellationToken ct)
    {
        if (depth > MaxConditionDepth)
            return Leaf(node, TriState.Indeterminate, "Condition ağacı çok derin (fail-closed).", null, null);

        switch (node.Kind)
        {
            case ConditionKind.Not:
            {
                if (node.Children.Count != 1)
                    return Leaf(node, TriState.Indeterminate, "NOT tam olarak bir çocuk içermeli.", null, null);
                var child = await EvaluateNodeAsync(node.Children[0], attributes, permissionCode, depth + 1, ct);
                var v = child.Value switch { TriState.True => TriState.False, TriState.False => TriState.True, _ => TriState.Indeterminate };
                return new ConditionTrace(node.Kind, null, $"NOT {child.Expression}", v, child.Message, null, null, [child]);
            }
            case ConditionKind.Reference:
            {
                // Ortak koşul: tanım tek yerde; burada çözülmüş kökü değerlendirilir. Çözülemezse fail-closed.
                if (node.Children.Count != 1)
                    return new ConditionTrace(node.Kind, null, Render(node), TriState.Indeterminate,
                        $"Ortak koşul '{node.ReferenceCode}' bulunamadı, pasif veya döngüsel (fail-closed).",
                        [$"SharedCondition.{node.ReferenceCode}"], null, null);
                var child = await EvaluateNodeAsync(node.Children[0], attributes, permissionCode, depth + 1, ct);
                return new ConditionTrace(node.Kind, null, Render(node), child.Value,
                    $"@{node.ReferenceCode} v{node.ReferenceVersion}: {child.Message}", null, null, [child]);
            }
            case ConditionKind.AllOf:
            case ConditionKind.AnyOf:
            {
                if (node.Children.Count == 0)
                    return Leaf(node, TriState.Indeterminate, "Boş AND/OR grubu.", null, null);
                var children = new List<ConditionTrace>();
                foreach (var c in node.Children) children.Add(await EvaluateNodeAsync(c, attributes, permissionCode, depth + 1, ct));
                var values = children.Select(c => c.Value).ToList();
                var and = node.Kind == ConditionKind.AllOf;
                var v = and
                    ? values.Contains(TriState.False) ? TriState.False : values.Contains(TriState.Indeterminate) ? TriState.Indeterminate : TriState.True
                    : values.Contains(TriState.True) ? TriState.True : values.Contains(TriState.Indeterminate) ? TriState.Indeterminate : TriState.False;
                var expr = "(" + string.Join(and ? " AND " : " OR ", children.Select(c => c.Expression)) + ")";
                return new ConditionTrace(node.Kind, null, expr, v, string.Join(" ", children.Select(c => c.Message)), null, null, children);
            }
            default:
                return await EvaluatePredicateAsync(node, attributes, permissionCode, ct);
        }
    }

    private async Task<ConditionTrace> EvaluatePredicateAsync(ConditionNode node, AttributeResolver attributes, string permissionCode, CancellationToken ct)
    {
        var handler = node.TypeAvailable && node.ConditionTypeCode is not null ? handlers.Find(node.ConditionTypeCode) : null;
        if (handler is null)
            return Leaf(node, TriState.Indeterminate, $"'{node.ConditionTypeCode}' condition tipi için handler yok (fail-closed).", null, null);

        var before = attributes.Used.Count;
        try
        {
            var r = await handler.EvaluateAsync(new ConditionEvaluationContext
            {
                Parameters = node.Parameters,
                Attributes = attributes,
                Subject = attributes.Scope.Subject,
                PermissionCode = permissionCode
            }, ct);
            return Leaf(node, r.Value, r.Message, r.MissingAttributes, attributes.Used.Skip(before).ToList());
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogError(ex, "Condition handler {Type} failed", node.ConditionTypeCode);
            return Leaf(node, TriState.Indeterminate, $"Condition değerlendirilirken hata: {ex.Message}", null, attributes.Used.Skip(before).ToList());
        }
    }

    private static ConditionTrace Leaf(ConditionNode node, TriState v, string message, IReadOnlyList<string>? missing, IReadOnlyList<UsedAttribute>? evidence) =>
        new(node.Kind, node.ConditionTypeCode, Render(node), v, message, missing, evidence, null);

    private static IEnumerable<string> CollectMissing(ConditionTrace t) =>
        (t.MissingAttributes ?? []).Concat((t.Children ?? []).SelectMany(CollectMissing));

    /// <summary>Condition ağacının okunur gösterimi: NOT TIME_WINDOW(Start=09:00, End=18:00) · ortak koşul: @BANK_NETWORK.</summary>
    public static string Render(ConditionNode? node) => Render(node, expand: false);

    /// <summary>
    /// expand=true: ortak koşul referansları içerikleriyle birlikte yazılır (@BANK_NETWORK[IP_IN_RANGE(...)]).
    /// What-If yapısal farkında kullanılır; aksi halde ortak koşul değişikliği "değişmedi" görünürdü.
    /// </summary>
    public static string Render(ConditionNode? node, bool expand) => node is null ? "(condition yok)" : node.Kind switch
    {
        ConditionKind.Reference => expand && node.Children.Count > 0 ? $"@{node.ReferenceCode}[{Render(node.Children[0], true)}]" : $"@{node.ReferenceCode}",
        ConditionKind.Not => $"NOT {(node.Children.Count > 0 ? Render(node.Children[0], expand) : "?")}",
        ConditionKind.AllOf => "(" + string.Join(" AND ", node.Children.Select(c => Render(c, expand))) + ")",
        ConditionKind.AnyOf => "(" + string.Join(" OR ", node.Children.Select(c => Render(c, expand))) + ")",
        _ => node.Parameters.Count == 0
            ? node.ConditionTypeCode ?? "?"
            : $"{node.ConditionTypeCode}({string.Join(", ", node.Parameters.OrderBy(p => p.Key).Select(p => $"{p.Key}={p.Value}"))})"
    };
}
