using Yetki.Domain.Common;

namespace Yetki.Application.PolicyEngine.Combining;

/// <summary>Birleştirme sonucu: karar + kararı belirleyen girdinin indeksi (açıklanabilirlik için).</summary>
public readonly record struct CombiningResult(DecisionType Decision, int? DecidingIndex);

/// <summary>
/// Rule (veya policy) sonuçlarını tek karara indirger. Girdi sırası deterministiktir (Order, sonra Code).
/// Aynı algoritmalar hem rule→policy hem policy→permission seviyesinde kullanılır.
/// </summary>
public interface ICombiningAlgorithm
{
    CombiningAlgorithm Id { get; }
    CombiningResult Combine(IReadOnlyList<DecisionType> results);
}

/// <summary>
/// Deny-overrides: herhangi bir Deny → Deny; yoksa herhangi bir Indeterminate → Indeterminate;
/// yoksa herhangi bir Permit → Permit; yoksa NotApplicable.
/// Not: XACML'in genişletilmiş Indeterminate{D,P} ayrımı sadeleştirildi; belirsizlik Permit'i daima bloklar (güvenli taraf).
/// </summary>
public sealed class DenyOverridesAlgorithm : ICombiningAlgorithm
{
    public CombiningAlgorithm Id => CombiningAlgorithm.DenyOverrides;

    public CombiningResult Combine(IReadOnlyList<DecisionType> r) =>
        First(r, DecisionType.Deny) ?? First(r, DecisionType.Indeterminate) ?? First(r, DecisionType.Permit)
        ?? new CombiningResult(DecisionType.NotApplicable, null);

    internal static CombiningResult? First(IReadOnlyList<DecisionType> r, DecisionType d)
    {
        for (var i = 0; i < r.Count; i++)
            if (r[i] == d) return new CombiningResult(d, i);
        return null;
    }
}

/// <summary>
/// Permit-overrides: herhangi bir Permit → Permit; yoksa Indeterminate → Indeterminate; yoksa Deny → Deny; yoksa NotApplicable.
/// </summary>
public sealed class PermitOverridesAlgorithm : ICombiningAlgorithm
{
    public CombiningAlgorithm Id => CombiningAlgorithm.PermitOverrides;

    public CombiningResult Combine(IReadOnlyList<DecisionType> r) =>
        DenyOverridesAlgorithm.First(r, DecisionType.Permit) ?? DenyOverridesAlgorithm.First(r, DecisionType.Indeterminate)
        ?? DenyOverridesAlgorithm.First(r, DecisionType.Deny) ?? new CombiningResult(DecisionType.NotApplicable, null);
}

/// <summary>First-applicable: sıradaki ilk NotApplicable olmayan sonuç (Indeterminate dahil).</summary>
public sealed class FirstApplicableAlgorithm : ICombiningAlgorithm
{
    public CombiningAlgorithm Id => CombiningAlgorithm.FirstApplicable;

    public CombiningResult Combine(IReadOnlyList<DecisionType> r)
    {
        for (var i = 0; i < r.Count; i++)
            if (r[i] != DecisionType.NotApplicable) return new CombiningResult(r[i], i);
        return new CombiningResult(DecisionType.NotApplicable, null);
    }
}

public sealed class CombiningAlgorithmRegistry
{
    private readonly Dictionary<CombiningAlgorithm, ICombiningAlgorithm> _algorithms;

    public CombiningAlgorithmRegistry(IEnumerable<ICombiningAlgorithm> algorithms) =>
        _algorithms = algorithms.ToDictionary(a => a.Id);

    public static CombiningAlgorithmRegistry Default { get; } =
        new([new DenyOverridesAlgorithm(), new PermitOverridesAlgorithm(), new FirstApplicableAlgorithm()]);

    public ICombiningAlgorithm Get(CombiningAlgorithm id) =>
        _algorithms.TryGetValue(id, out var a) ? a : throw new InvalidOperationException($"Desteklenmeyen combining algoritması: {id}");
}
