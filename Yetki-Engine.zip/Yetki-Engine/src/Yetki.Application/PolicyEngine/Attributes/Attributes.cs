using System.Globalization;
using Yetki.Application.Context;

namespace Yetki.Application.PolicyEngine.Attributes;

/// <summary>Attribute kategorisi (XACML'deki subject / resource / action / environment ayrımına benzer).</summary>
public enum AttributeCategory
{
    /// <summary>Kullanıcıya ait nitelikler (limit, izin durumu, birimler...).</summary>
    Subject = 1,
    /// <summary>Üzerinde işlem yapılan kaynak.</summary>
    Resource = 2,
    /// <summary>İstenen işlem.</summary>
    Action = 3,
    /// <summary>Framework/motor tarafından güvenilir şekilde üretilen ortam bilgisi (zaman, IP, kanal, platform, cihaz).</summary>
    Environment = 4,
    /// <summary>İş (business) context'i — SDK'da DTO attribute'u ile gelen değerler (tutar, müşteri...).</summary>
    Context = 5
}

public readonly record struct AttributeId(AttributeCategory Category, string Name)
{
    public override string ToString() => $"{Category}.{Name}";

    public static AttributeId Subject(string name) => new(AttributeCategory.Subject, name);
    public static AttributeId Env(string name) => new(AttributeCategory.Environment, name);
    public static AttributeId Ctx(string name) => new(AttributeCategory.Context, name);

    /// <summary>Request context anahtarını doğru kategoriye yerleştirir (IpAddress → Environment, TransactionAmount → Context).</summary>
    public static AttributeId ForRequestKey(string key) =>
        AuthContextKeys.IsEnvironment(key) ? Env(key) : Ctx(key);
}

/// <summary>
/// Çözülmüş attribute değeri. Value=null → kaynak "bu değer boş" diyor (ör. personel müşteri değil).
/// Provider hiç çözemediyse AttributeValue'nun kendisi null döner (→ Indeterminate).
/// </summary>
public sealed record AttributeValue(string? Value, string Source);

public sealed record SubjectRef(int UserId, string UserName);

public sealed record ResourceRef(string? Type, string? Id)
{
    public override string ToString() => Type is null ? Id ?? "" : $"{Type}:{Id}";
}

/// <summary>Attribute çözümlemesi için istek kapsamı.</summary>
public sealed class AttributeResolutionScope
{
    public required SubjectRef Subject { get; init; }
    public required AuthorizationContext Context { get; init; }
    public required string Action { get; init; }
    public ResourceRef? Resource { get; init; }
}

/// <summary>
/// Attribute değer kaynağı. Policy engine değerin nereden geldiğini bilmez:
/// bugün User entity / request context, yarın HR, limit yönetimi, core banking servisleri.
/// Yeni kaynak = yeni provider + DI kaydı (kayıt sırası önceliktir).
/// </summary>
public interface IAttributeValueProvider
{
    string Name { get; }
    bool CanResolve(AttributeId id);
    ValueTask<AttributeValue?> ResolveAsync(AttributeId id, AttributeResolutionScope scope, CancellationToken ct);
}

/// <summary>Değerlendirmede kullanılan bir attribute (explainability / audit).</summary>
public sealed record UsedAttribute(string Attribute, string? Value, string Source, bool Resolved);

/// <summary>
/// Hassas attribute değerlerinin audit/log'a nasıl yazılacağına karar verir (ör. müşteri no maskeleme).
/// Kararın kendisi her zaman gerçek değerle verilir; redaksiyon sadece kayıt/görüntüleme içindir.
/// </summary>
public interface IAttributeRedactor
{
    string? Redact(string attribute, string? value);
}

public sealed class DefaultAttributeRedactor(IEnumerable<string>? sensitiveAttributes = null) : IAttributeRedactor
{
    private readonly HashSet<string> _sensitive = new(sensitiveAttributes ??
        ["Context.CustomerId", "Context.AccountNo", "Subject.CustomerId", "Environment.DeviceId"], StringComparer.OrdinalIgnoreCase);

    public string? Redact(string attribute, string? value)
    {
        if (value is null || !_sensitive.Contains(attribute)) return value;
        return value.Length <= 2 ? "**" : new string('*', value.Length - 2) + value[^2..];
    }
}

/// <summary>
/// Tek bir değerlendirme boyunca attribute'ları çözer, önbelleğe alır ve hangi değerin kullanıldığını kaydeder.
/// Aynı attribute bir istek içinde iki kez sorulursa provider tekrar çağrılmaz (deterministik + performans).
/// </summary>
public sealed class AttributeResolver(IReadOnlyList<IAttributeValueProvider> providers, AttributeResolutionScope scope)
{
    private readonly Dictionary<AttributeId, AttributeValue?> _cache = new();
    private readonly List<UsedAttribute> _used = new();

    public AttributeResolutionScope Scope => scope;
    public IReadOnlyList<UsedAttribute> Used => _used;

    public async ValueTask<AttributeValue?> GetAsync(AttributeId id, CancellationToken ct)
    {
        if (!_cache.TryGetValue(id, out var value))
        {
            value = null;
            foreach (var p in providers.Where(p => p.CanResolve(id)))
            {
                value = await p.ResolveAsync(id, scope, ct);
                if (value is not null) break;
            }
            _cache[id] = value;
        }
        _used.Add(new UsedAttribute(id.ToString(), value?.Value, value?.Source ?? "unresolved", value is not null));
        return value;
    }

    /// <summary>Değer yoksa (çözülemedi veya boş) null.</summary>
    public async ValueTask<string?> GetStringAsync(AttributeId id, CancellationToken ct) =>
        (await GetAsync(id, ct)) is { Value: { Length: > 0 } v } ? v : null;

    public async ValueTask<decimal?> GetDecimalAsync(AttributeId id, CancellationToken ct) =>
        AuthorizationContext.TryParseDecimal(await GetStringAsync(id, ct), out var d) ? d : null;

    public async ValueTask<bool?> GetBoolAsync(AttributeId id, CancellationToken ct) =>
        bool.TryParse(await GetStringAsync(id, ct), out var b) ? b : null;

    public async ValueTask<DateTime?> GetDateTimeUtcAsync(AttributeId id, CancellationToken ct)
    {
        var s = await GetStringAsync(id, ct);
        return s is not null && DateTimeOffset.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var dto)
            ? dto.UtcDateTime : null;
    }
}

/// <summary>Request context'i (Environment + Context kategorileri) ve subject kimliğini sağlar.</summary>
public sealed class RequestContextAttributeProvider : IAttributeValueProvider
{
    public string Name => "Request";

    public bool CanResolve(AttributeId id) =>
        id.Category is AttributeCategory.Environment or AttributeCategory.Context or AttributeCategory.Action
        || (id.Category == AttributeCategory.Subject && id.Name == SubjectAttributes.UserName);

    public ValueTask<AttributeValue?> ResolveAsync(AttributeId id, AttributeResolutionScope scope, CancellationToken ct)
    {
        AttributeValue? v = id.Category switch
        {
            AttributeCategory.Subject => new AttributeValue(scope.Subject.UserName, "Engine"),
            AttributeCategory.Action => new AttributeValue(scope.Action, "Request"),
            _ => scope.Context.GetString(id.Name) is { } s
                ? new AttributeValue(s, id.Name == AuthContextKeys.CurrentTime ? "Engine" : "Request")
                : null
        };
        return ValueTask.FromResult(v);
    }
}
