using System.Globalization;
using Yetki.Application.Context;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Domain.Common;

namespace Yetki.Application.PolicyEngine.Conditions.Handlers;

/// <summary>
/// Context.TransactionAmount &gt; Subject.CashWithdrawalLimit
/// Limit policy'de SABİT DEĞİLDİR; kullanıcı attribute'u olarak IAttributeValueProvider'dan çözülür
/// (prototipte User entity, ileride limit yönetim servisi). Eksik değer → Indeterminate (fail-closed).
/// </summary>
public sealed class AmountExceedsSubjectLimitConditionHandler : ConditionHandlerBase
{
    public const string Code = "AMOUNT_EXCEEDS_SUBJECT_LIMIT";

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Tutar kullanıcı limitini aşıyor",
        "Context'teki tutar, kullanıcının limit attribute'undan BÜYÜK.",
        ConditionScope.Global,
        [
            new("AmountAttribute", "Tutar context anahtarı", "string", false, AuthContextKeys.TransactionAmount, null),
            new("LimitAttribute", "Kullanıcı limit attribute'u", "string", false, SubjectAttributes.CashWithdrawalLimit, null)
        ],
        [AttributeId.Ctx(AuthContextKeys.TransactionAmount).ToString(), AttributeId.Subject(SubjectAttributes.CashWithdrawalLimit).ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var amountId = AttributeId.Ctx(ctx.Param("AmountAttribute", AuthContextKeys.TransactionAmount));
        var limitId = AttributeId.Subject(ctx.Param("LimitAttribute", SubjectAttributes.CashWithdrawalLimit));

        var amount = await ctx.Attributes.GetDecimalAsync(amountId, ct);
        var limit = await ctx.Attributes.GetDecimalAsync(limitId, ct);
        if (amount is null || limit is null)
            return ConditionResult.Missing(new[] { (amountId, amount), (limitId, limit) }.Where(x => x.Item2 is null).Select(x => x.Item1).ToArray());

        return ConditionResult.Of(amount > limit,
            $"Tutar {F(amount)} > kullanıcı limiti {F(limit)}.",
            $"Tutar {F(amount)} ≤ kullanıcı limiti {F(limit)}.");
    }

    internal static string F(decimal? d) => d?.ToString("N2", CultureInfo.InvariantCulture) ?? "-";
}

/// <summary>Context tutarı sabit eşikten büyük mü? (domain eşiği, ör. kredi onayında 1.000.000)</summary>
public sealed class AmountGreaterThanConditionHandler : ConditionHandlerBase
{
    public const string Code = "AMOUNT_GREATER_THAN";

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Tutar eşikten büyük",
        "Context'teki tutar, parametredeki sabit eşikten BÜYÜK.",
        ConditionScope.Domain,
        [
            new("Threshold", "Eşik", "decimal", true, null, "Nokta ondalık ayırıcı"),
            new("AmountAttribute", "Tutar context anahtarı", "string", false, AuthContextKeys.TransactionAmount, null)
        ],
        [AttributeId.Ctx(AuthContextKeys.TransactionAmount).ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var amountId = AttributeId.Ctx(ctx.Param("AmountAttribute", AuthContextKeys.TransactionAmount));
        var amount = await ctx.Attributes.GetDecimalAsync(amountId, ct);
        if (amount is null) return ConditionResult.Missing(amountId);
        var threshold = ctx.DecimalParam("Threshold");
        if (threshold is null) return ConditionResult.Error("INVALID_PARAMETER", "Threshold tanımsız.");
        var F = AmountExceedsSubjectLimitConditionHandler.F;
        return ConditionResult.Of(amount > threshold, $"Tutar {F(amount)} > eşik {F(threshold)}.", $"Tutar {F(amount)} ≤ eşik {F(threshold)}.");
    }
}

/// <summary>İşlem şubesi (Context.BranchCode) kullanıcının birimlerinden biri mi?</summary>
public sealed class BranchIsUserUnitConditionHandler : ConditionHandlerBase
{
    public const string Code = "BRANCH_IS_USER_UNIT";
    private static readonly AttributeId Branch = AttributeId.Ctx(AuthContextKeys.BranchCode);
    private static readonly AttributeId Units = AttributeId.Subject(SubjectAttributes.OrgUnitCodes);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "İşlem şubesi kullanıcının birimi",
        "Context.BranchCode, kullanıcının bağlı olduğu birimlerden biri.",
        ConditionScope.Global, [], [Branch.ToString(), Units.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var branch = await ctx.Attributes.GetStringAsync(Branch, ct);
        if (branch is null) return ConditionResult.Missing(Branch);
        var unitsValue = await ctx.Attributes.GetAsync(Units, ct);
        if (unitsValue is null) return ConditionResult.Missing(Units);
        var codes = ConditionEvaluationContext.SplitList(unitsValue.Value);
        return ConditionResult.Of(codes.Contains(branch, StringComparer.OrdinalIgnoreCase),
            $"Kullanıcı {branch} biriminde görevli.",
            $"Kullanıcı {branch} biriminde görevli değil (birimleri: {string.Join(",", codes)}).");
    }
}

/// <summary>Kullanıcı izinde mi?</summary>
public sealed class UserOnLeaveConditionHandler : ConditionHandlerBase
{
    public const string Code = "USER_ON_LEAVE";
    private static readonly AttributeId OnLeave = AttributeId.Subject(SubjectAttributes.IsOnLeave);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Kullanıcı izinde", "Kullanıcı şu an izinde.", ConditionScope.Global, [], [OnLeave.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var onLeave = await ctx.Attributes.GetBoolAsync(OnLeave, ct);
        return onLeave is null
            ? ConditionResult.Missing(OnLeave)
            : ConditionResult.Of(onLeave.Value, "Kullanıcı izinde.", "Kullanıcı aktif görevde.");
    }
}

/// <summary>İşlemdeki müşteri, personelin kendisi mi? (Context.CustomerId == Subject.CustomerId)</summary>
public sealed class CustomerIsSelfConditionHandler : ConditionHandlerBase
{
    public const string Code = "CUSTOMER_IS_SELF";
    private static readonly AttributeId Customer = AttributeId.Ctx(AuthContextKeys.CustomerId);
    private static readonly AttributeId Own = AttributeId.Subject(SubjectAttributes.CustomerId);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Müşteri personelin kendisi", "Context.CustomerId, personelin kendi müşteri numarası.",
        ConditionScope.Global, [], [Customer.ToString(), Own.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var customer = await ctx.Attributes.GetStringAsync(Customer, ct);
        if (customer is null) return ConditionResult.Missing(Customer);
        var own = await ctx.Attributes.GetAsync(Own, ct);
        if (own is null) return ConditionResult.Missing(Own); // kaynak çözemedi → belirsiz
        // own.Value == null → personelin müşteri kaydı yok → "kendisi" olamaz
        return ConditionResult.Of(own.Value is not null && string.Equals(own.Value, customer, StringComparison.OrdinalIgnoreCase),
            "İşlem personelin kendi müşteri hesabında.", "Müşteri personelin kendisi değil.");
    }
}
