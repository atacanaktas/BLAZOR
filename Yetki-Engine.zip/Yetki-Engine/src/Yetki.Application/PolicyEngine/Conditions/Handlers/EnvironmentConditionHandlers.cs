using System.Globalization;
using System.Net;
using Yetki.Application.Context;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Domain.Common;

namespace Yetki.Application.PolicyEngine.Conditions.Handlers;

/// <summary>Her zaman TRUE. Temel Permit rule'u için ("kısıt yoksa izin ver").</summary>
public sealed class AlwaysConditionHandler : ConditionHandlerBase
{
    public const string Code = "ALWAYS";

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Her zaman", "Koşulsuz doğru (temel Permit/Deny kuralları için).", ConditionScope.Global, [], []);

    public override Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct) =>
        Task.FromResult(ConditionResult.True("Koşulsuz."));
}

/// <summary>
/// CurrentTime belirtilen gün/saat penceresi İÇİNDE mi? Mesai dışı kısıtı: Deny + NOT(TIME_WINDOW).
/// Zaman motorun saatidir (Environment.CurrentTime), çağıran değiştiremez.
/// </summary>
public sealed class TimeWindowConditionHandler : ConditionHandlerBase
{
    public const string Code = "TIME_WINDOW";
    private static readonly AttributeId Now = AttributeId.Env(AuthContextKeys.CurrentTime);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "Zaman penceresi (mesai)",
        "İşlem zamanı belirtilen gün ve saat aralığının içinde.",
        ConditionScope.Global,
        [
            new("Start", "Başlangıç", "time", true, "09:00", "HH:mm"),
            new("End", "Bitiş", "time", true, "18:00", "HH:mm"),
            new("Days", "Günler", "list", false, "MON,TUE,WED,THU,FRI", "MON..SUN virgülle"),
            new("TimeZone", "Saat dilimi", "string", false, "Europe/Istanbul", "IANA saat dilimi")
        ],
        [Now.ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var utc = await ctx.Attributes.GetDateTimeUtcAsync(Now, ct);
        if (utc is null) return ConditionResult.Missing(Now);

        var tz = FindTimeZone(ctx.Param("TimeZone", "Europe/Istanbul"));
        if (tz is null) return ConditionResult.Error("INVALID_PARAMETER", "Saat dilimi bulunamadı.");

        var local = TimeZoneInfo.ConvertTimeFromUtc(utc.Value, tz);
        var start = TimeOnly.ParseExact(ctx.Param("Start", "09:00"), "HH:mm", CultureInfo.InvariantCulture);
        var end = TimeOnly.ParseExact(ctx.Param("End", "18:00"), "HH:mm", CultureInfo.InvariantCulture);
        var days = ConditionEvaluationContext.SplitList(ctx.Param("Days", "MON,TUE,WED,THU,FRI")).Select(d => d.ToUpperInvariant()).ToHashSet();
        var today = local.DayOfWeek.ToString()[..3].ToUpperInvariant();
        var time = TimeOnly.FromDateTime(local);
        var window = $"{start:HH\\:mm}-{end:HH\\:mm} {string.Join(',', days)}";
        var at = local.ToString("yyyy-MM-dd HH:mm (ddd)", CultureInfo.InvariantCulture);

        return ConditionResult.Of(days.Contains(today) && time >= start && time <= end,
            $"{at} pencere içinde ({window}).",
            $"{at} pencere dışında ({window}).");
    }

    private static TimeZoneInfo? FindTimeZone(string id)
    {
        try { return TimeZoneInfo.FindSystemTimeZoneById(id); }
        catch (TimeZoneNotFoundException) { }
        if (id != "Europe/Istanbul") return null;
        try { return TimeZoneInfo.FindSystemTimeZoneById("Turkey Standard Time"); } catch { return null; }
    }
}

/// <summary>Environment.IpAddress izinli CIDR aralıklarından birinde mi? Banka ağı dışı kısıtı: Deny + NOT(IP_IN_RANGE).</summary>
public sealed class IpInRangeConditionHandler : ConditionHandlerBase
{
    public const string Code = "IP_IN_RANGE";
    private static readonly AttributeId Ip = AttributeId.Env(AuthContextKeys.IpAddress);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        Code, "IP aralığında",
        "İstek kaynağı IP adresi verilen ağlardan birinde.",
        ConditionScope.Global,
        [new("Cidrs", "Ağlar", "list", true, null, "CIDR listesi, ör. 10.0.0.0/8,127.0.0.1/32")],
        [Ip.ToString()]);

    public override IReadOnlyList<string> ValidateParameters(IReadOnlyDictionary<string, string> parameters)
    {
        var errors = base.ValidateParameters(parameters).ToList();
        if (parameters.TryGetValue("Cidrs", out var csv))
            foreach (var c in ConditionEvaluationContext.SplitList(csv))
                if (!IPNetwork.TryParse(c, out _)) errors.Add($"Geçersiz CIDR: {c}");
        return errors;
    }

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var ipText = await ctx.Attributes.GetStringAsync(Ip, ct);
        if (ipText is null) return ConditionResult.Missing(Ip);
        if (!IPAddress.TryParse(ipText, out var ip)) return ConditionResult.Error("INVALID_IP", $"IP adresi çözümlenemedi: {ipText}");
        if (ip.IsIPv4MappedToIPv6) ip = ip.MapToIPv4();

        var cidrs = ConditionEvaluationContext.SplitList(ctx.Param("Cidrs"));
        var match = cidrs.FirstOrDefault(c => IPNetwork.TryParse(c, out var n) && n.Contains(ip));
        return ConditionResult.Of(match is not null, $"{ip} izinli ağda ({match}).", $"{ip} izinli ağların ({string.Join(",", cidrs)}) dışında.");
    }
}

/// <summary>Environment attribute'u verilen kümede mi? (kanal, platform vb. için ortak taban)</summary>
public abstract class EnvironmentInSetConditionHandler(string code, string name, string key, string paramKey, string paramLabel, string example) : ConditionHandlerBase
{
    private readonly AttributeId _attr = AttributeId.Env(key);

    public override ConditionTypeDescriptor Descriptor { get; } = new(
        code, name, $"{key} değeri verilen listede.", ConditionScope.Global,
        [new(paramKey, paramLabel, "list", true, null, example)],
        [AttributeId.Env(key).ToString()]);

    public override async Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext ctx, CancellationToken ct)
    {
        var value = await ctx.Attributes.GetStringAsync(_attr, ct);
        if (value is null) return ConditionResult.Missing(_attr);
        var allowed = ConditionEvaluationContext.SplitList(ctx.Param(paramKey));
        return ConditionResult.Of(allowed.Contains(value, StringComparer.OrdinalIgnoreCase),
            $"{_attr.Name} '{value}' listede ({string.Join(",", allowed)}).",
            $"{_attr.Name} '{value}' listede değil ({string.Join(",", allowed)}).");
    }
}

public sealed class ChannelInConditionHandler() : EnvironmentInSetConditionHandler(
    "CHANNEL_IN", "Kanal listede", AuthContextKeys.Channel, "Channels", "Kanallar", "ör. CASH_DESK,BRANCH")
{
    public const string Code = "CHANNEL_IN";
}

public sealed class PlatformInConditionHandler() : EnvironmentInSetConditionHandler(
    "PLATFORM_IN", "Platform listede", AuthContextKeys.Platform, "Platforms", "Platformlar", "ör. BRANCH_DESKTOP,MOBILE")
{
    public const string Code = "PLATFORM_IN";
}
