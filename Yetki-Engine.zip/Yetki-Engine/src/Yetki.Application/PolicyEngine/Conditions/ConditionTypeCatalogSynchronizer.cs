using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Common;
using Yetki.Domain.Policies;

namespace Yetki.Application.PolicyEngine.Conditions;

/// <summary>
/// ConditionTypes tablosunu koddaki handler'larla senkronize eder (uygulama açılışında).
/// Kodda karşılığı olmayan tip silinmez, IsAvailable=false yapılır: o tipteki condition'lar Indeterminate (fail-closed).
/// </summary>
public sealed class ConditionTypeCatalogSynchronizer(IYetkiDbContext db, ConditionHandlerRegistry registry)
{
    public async Task SyncAsync(CancellationToken ct = default)
    {
        var existing = await db.ConditionTypes.ToListAsync(ct);
        foreach (var handler in registry.All)
        {
            var d = handler.Descriptor;
            var row = existing.FirstOrDefault(t => string.Equals(t.Code, d.Code, StringComparison.OrdinalIgnoreCase));
            if (row is null)
            {
                row = new ConditionType { Code = d.Code };
                db.ConditionTypes.Add(row);
            }
            row.Name = d.Name;
            row.Description = d.TrueMeaning;
            row.DefaultScope = d.DefaultScope;
            row.ParameterSchemaJson = JsonDefaults.Serialize(d.Parameters);
            row.RequiredAttributes = string.Join(",", d.RequiredAttributes);
            row.IsAvailable = true;
        }
        foreach (var orphan in existing.Where(t => registry.Find(t.Code) is null))
            orphan.IsAvailable = false;
        await db.SaveChangesAsync(ct);
    }
}
