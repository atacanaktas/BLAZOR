using System.Globalization;
using System.Text.Json.Serialization;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Domain.Common;

namespace Yetki.Application.PolicyEngine.Conditions;

/// <summary>Üç değerli mantık: condition doğru / yanlış / belirlenemedi (eksik attribute, hata).</summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum TriState { False = 0, True = 1, Indeterminate = 2 }

public sealed record ConditionParameterDescriptor(
    string Key, string Label, string Type, bool Required, string? DefaultValue, string? Description);

/// <summary>Handler'ın kendini tanıttığı meta veri. ConditionTypes kataloğu bu bilgiden senkronize edilir.</summary>
public sealed record ConditionTypeDescriptor(
    string Code,
    string Name,
    /// <summary>Predicate TRUE olduğunda ne anlama geldiği (ör. "İşlem tutarı kullanıcı limitini aşıyor").</summary>
    string TrueMeaning,
    ConditionScope DefaultScope,
    IReadOnlyList<ConditionParameterDescriptor> Parameters,
    /// <summary>Okunan attribute'lar ("Context.TransactionAmount", "Subject.CashWithdrawalLimit"...).</summary>
    IReadOnlyList<string> RequiredAttributes);

public sealed class ConditionEvaluationContext
{
    public required IReadOnlyDictionary<string, string> Parameters { get; init; }
    public required AttributeResolver Attributes { get; init; }
    public required SubjectRef Subject { get; init; }
    public required string PermissionCode { get; init; }

    public string Param(string key, string fallback) =>
        Parameters.TryGetValue(key, out var v) && !string.IsNullOrWhiteSpace(v) ? v : fallback;

    public string? Param(string key) =>
        Parameters.TryGetValue(key, out var v) && !string.IsNullOrWhiteSpace(v) ? v : null;

    public decimal? DecimalParam(string key) =>
        Param(key) is { } s && decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out var d) ? d : null;

    public static IReadOnlyList<string> SplitList(string? csv) =>
        (csv ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
}

/// <summary>Predicate sonucu. Kullanılan attribute değerleri AttributeResolver tarafından ayrıca kaydedilir.</summary>
public sealed record ConditionResult(TriState Value, string Message, IReadOnlyList<string>? MissingAttributes = null, string? ErrorCode = null)
{
    public static ConditionResult True(string message) => new(TriState.True, message);
    public static ConditionResult False(string message) => new(TriState.False, message);
    public static ConditionResult Of(bool value, string whenTrue, string whenFalse) =>
        value ? True(whenTrue) : False(whenFalse);

    public static ConditionResult Missing(params AttributeId[] ids) =>
        new(TriState.Indeterminate, $"Gerekli attribute eksik: {string.Join(", ", ids)}", ids.Select(i => i.ToString()).ToList(), "MISSING_ATTRIBUTE");

    public static ConditionResult Error(string code, string message) => new(TriState.Indeterminate, message, null, code);
}

/// <summary>
/// Bir ConditionType'ın DAVRANIŞI. Güvenilir, tipli C# kodu; DB sadece parametreleri tutar.
/// Yeni condition tipi = yeni handler sınıfı + DI kaydı (Application/DependencyInjection.cs).
/// Handler bir PREDICATE değerlendirir (TRUE/FALSE); Permit/Deny kararını Rule'un Effect'i verir.
/// </summary>
public interface IConditionHandler
{
    ConditionTypeDescriptor Descriptor { get; }
    IReadOnlyList<string> ValidateParameters(IReadOnlyDictionary<string, string> parameters);
    Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext context, CancellationToken ct);
}

public abstract class ConditionHandlerBase : IConditionHandler
{
    public abstract ConditionTypeDescriptor Descriptor { get; }

    public virtual IReadOnlyList<string> ValidateParameters(IReadOnlyDictionary<string, string> parameters)
    {
        var errors = new List<string>();
        foreach (var p in Descriptor.Parameters)
        {
            parameters.TryGetValue(p.Key, out var value);
            if (string.IsNullOrWhiteSpace(value))
            {
                if (p.Required && p.DefaultValue is null) errors.Add($"'{p.Key}' parametresi zorunlu.");
                continue;
            }
            if (p.Type == "decimal" && !decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out _))
                errors.Add($"'{p.Key}' sayısal olmalı (ondalık ayırıcı nokta).");
            if (p.Type == "time" && !TimeOnly.TryParseExact(value, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out _))
                errors.Add($"'{p.Key}' HH:mm formatında olmalı.");
        }
        foreach (var key in parameters.Keys)
            if (Descriptor.Parameters.All(p => !string.Equals(p.Key, key, StringComparison.OrdinalIgnoreCase)))
                errors.Add($"'{key}' bu condition tipi için tanımlı bir parametre değil.");
        return errors;
    }

    public abstract Task<ConditionResult> EvaluateAsync(ConditionEvaluationContext context, CancellationToken ct);
}

public sealed class ConditionHandlerRegistry
{
    private readonly Dictionary<string, IConditionHandler> _handlers;

    public ConditionHandlerRegistry(IEnumerable<IConditionHandler> handlers)
    {
        _handlers = new Dictionary<string, IConditionHandler>(StringComparer.OrdinalIgnoreCase);
        foreach (var h in handlers)
            if (!_handlers.TryAdd(h.Descriptor.Code, h))
                throw new InvalidOperationException($"ConditionType kodu birden fazla handler'da tanımlı: {h.Descriptor.Code}");
    }

    public IConditionHandler? Find(string code) => _handlers.GetValueOrDefault(code);

    public IReadOnlyCollection<IConditionHandler> All => _handlers.Values;
}
