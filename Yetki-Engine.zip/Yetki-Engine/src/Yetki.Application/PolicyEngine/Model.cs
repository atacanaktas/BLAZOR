using System.Text.Json.Serialization;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Domain.Common;

namespace Yetki.Application.PolicyEngine;

/// <summary>Karar durumu (XACML kavramları).</summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum DecisionType
{
    Permit = 1,
    Deny = 2,
    /// <summary>Hiçbir rule uygulanamadı. Enforcement (PEP) tarafında İZİN VERİLMEZ.</summary>
    NotApplicable = 3,
    /// <summary>Karar verilemedi (eksik attribute, hata). Enforcement tarafında İZİN VERİLMEZ.</summary>
    Indeterminate = 4
}

// ------------------------------ Değerlendirilecek tanımlar (DB'den veya What-If taslağından) ------------------------------

/// <summary>
/// Condition ağacı (bellek içi). Id negatifse What-If taslağıdır.
/// Kind=Reference: ReferenceCode = ortak koşul kodu; Children[0] = çözülmüş ortak koşul kökü (çözülemediyse boş → Indeterminate).
/// </summary>
public sealed record ConditionNode(
    int Id,
    ConditionKind Kind,
    string? ConditionTypeCode,
    bool TypeAvailable,
    IReadOnlyDictionary<string, string> Parameters,
    IReadOnlyList<ConditionNode> Children,
    string? ReferenceCode = null,
    int? ReferenceVersion = null);

public sealed record RuleDefinition(
    int RuleId, string Code, string Name, string? Description, RuleEffect Effect, int Order, string? ReasonCode,
    bool IsActive, ConditionNode? Condition);

public sealed record PolicyDefinition(
    int PolicyId, string Code, string Name, int Version, CombiningAlgorithm Algorithm, IReadOnlyList<RuleDefinition> Rules);

// ------------------------------ Değerlendirme sonuçları (açıklanabilirlik) ------------------------------

/// <summary>Condition düğümünün değerlendirme izi.</summary>
public sealed record ConditionTrace(
    ConditionKind Kind,
    string? ConditionType,
    string Expression,
    TriState Value,
    string? Message,
    IReadOnlyList<string>? MissingAttributes,
    IReadOnlyList<UsedAttribute>? Evidence,
    IReadOnlyList<ConditionTrace>? Children);

public sealed record RuleEvaluation(
    int RuleId,
    string Code,
    string Name,
    RuleEffect Effect,
    int Order,
    bool IsActive,
    /// <summary>Condition sonucu (TRUE → Effect uygulanır).</summary>
    TriState ConditionValue,
    /// <summary>Rule sonucu: Permit / Deny / NotApplicable / Indeterminate.</summary>
    DecisionType Result,
    string? ReasonCode,
    string Message,
    string Expression,
    ConditionTrace? Condition,
    IReadOnlyList<string> MissingAttributes,
    IReadOnlyList<UsedAttribute> Evidence)
{
    /// <summary>Combining algoritması kararı bu rule'a göre verdiyse true.</summary>
    public bool IsDeciding { get; init; }
}

public sealed record PolicyEvaluation(
    int PolicyId,
    string Code,
    string Name,
    int Version,
    CombiningAlgorithm Algorithm,
    DecisionType Result,
    string? DecidingRule,
    IReadOnlyList<RuleEvaluation> Rules)
{
    public bool IsDeciding { get; init; }
}
