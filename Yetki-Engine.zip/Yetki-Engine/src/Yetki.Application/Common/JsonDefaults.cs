using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Yetki.Application.Common;

public static class JsonDefaults
{
    public static readonly JsonSerializerOptions Options = Create();

    public static JsonSerializerOptions Create()
    {
        var o = new JsonSerializerOptions(JsonSerializerDefaults.Web)
        {
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };
        o.Converters.Add(new JsonStringEnumConverter());
        return o;
    }

    public static string Serialize<T>(T value) => JsonSerializer.Serialize(value, Options);
}

public static class Codes
{
    /// <summary>
    /// Kodları normalize eder. Türkçe kültürde "i".ToUpper() = "İ" olduğu için daima Invariant kullanılır.
    /// </summary>
    public static string Normalize(string code) => code.Trim().ToUpperInvariant();
}
