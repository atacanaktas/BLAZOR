using System.Globalization;

namespace Yetki.Application.Context;

/// <summary>
/// Normalize context anahtarları (API sözleşmesi). SDK'daki AuthContextType enum değerleriyle aynı isimleri kullanır.
/// İş ekiplerinin DTO property adları buraya bağlı DEĞİLDİR; SDK semantik attribute ile eşler.
/// </summary>
public static class AuthContextKeys
{
    // ---- Environment: framework/motor tarafından güvenilir şekilde üretilir, iş ekibinden istenmez ----
    /// <summary>Karar anı. Otorite motordur; çağıranın gönderdiği değer yok sayılır (CallerTime olarak audit'e yazılır).</summary>
    public const string CurrentTime = "CurrentTime";
    public const string IpAddress = "IpAddress";
    public const string Channel = "Channel";
    public const string Platform = "Platform";
    public const string DeviceId = "DeviceId";
    public const string DeviceCompliant = "DeviceCompliant";
    public const string Application = "Application";

    // ---- Context: iş (business) değerleri — SDK'da DTO property'si semantik attribute ile işaretlenir ----
    public const string TransactionAmount = "TransactionAmount";
    public const string Currency = "Currency";
    public const string CustomerId = "CustomerId";
    public const string AccountNo = "AccountNo";
    public const string BranchCode = "BranchCode";

    /// <summary>Çağıranın gönderdiği zaman. Sadece audit içindir.</summary>
    public const string CallerTime = "CallerTime";

    private static readonly HashSet<string> EnvironmentKeys = new(StringComparer.OrdinalIgnoreCase)
        { CurrentTime, IpAddress, Channel, Platform, DeviceId, DeviceCompliant, Application, CallerTime };

    public static bool IsEnvironment(string key) => EnvironmentKeys.Contains(key);
}

/// <summary>
/// Değerlendirme sırasında kullanılan normalize request context'i (invariant-culture string değerler).
/// Rule'lar buna doğrudan değil, <see cref="Yetki.Application.PolicyEngine.Attributes.AttributeResolver"/> üzerinden erişir.
/// </summary>
public sealed class AuthorizationContext
{
    private readonly Dictionary<string, string?> _values;

    public AuthorizationContext(IDictionary<string, string?>? values = null)
    {
        _values = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
        if (values is null) return;
        foreach (var (k, v) in values)
            if (!string.IsNullOrWhiteSpace(k)) _values[k.Trim()] = v?.Trim();
    }

    public IReadOnlyDictionary<string, string?> Values => _values;

    public void Set(string key, string? value) => _values[key] = value;

    public void Remove(string key) => _values.Remove(key);

    public string? GetString(string key) => _values.TryGetValue(key, out var v) && !string.IsNullOrWhiteSpace(v) ? v : null;

    public static bool TryParseDecimal(string? s, out decimal value) =>
        decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out value);
}

/// <summary>Subject (kullanıcı) attribute adları. Değerler IAttributeValueProvider'lar ile çözülür.</summary>
public static class SubjectAttributes
{
    public const string UserName = "UserName";
    public const string CashWithdrawalLimit = "CashWithdrawalLimit";
    public const string IsOnLeave = "IsOnLeave";
    /// <summary>Virgülle ayrılmış organizasyon birimi kodları.</summary>
    public const string OrgUnitCodes = "OrgUnitCodes";
    /// <summary>Personelin bankadaki kendi müşteri numarası.</summary>
    public const string CustomerId = "CustomerId";
    public const string Title = "Title";
}
