using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Evaluation;
using Yetki.Application.Events;
using Yetki.Application.PolicyEngine;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Application.Sod;
using Yetki.Domain.Common;
using Yetki.Domain.Policies;
using Yetki.Domain.Sod;

namespace Yetki.Application.Definitions;

public sealed class PolicyUpsert
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public string? Domain { get; set; }
    public CombiningAlgorithm CombiningAlgorithm { get; set; } = CombiningAlgorithm.DenyOverrides;
    public bool IsActive { get; set; } = true;
}

public sealed class RuleUpsert
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public RuleEffect Effect { get; set; } = RuleEffect.Deny;
    public int Order { get; set; }
    public string? ReasonCode { get; set; }
    public bool IsActive { get; set; } = true;
    public ConditionDraft Condition { get; set; } = new();
}

public sealed class SodRuleUpsert
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public Severity Severity { get; set; } = Severity.High;
    public SodEnforcement Enforcement { get; set; } = SodEnforcement.Block;
    public bool IsActive { get; set; } = true;
    public List<int> PermissionIds { get; set; } = new();
    public List<int> RoleIds { get; set; } = new();
}

public sealed record SodRuleCreated(int Id, string Code, int CurrentViolatingUsers, IReadOnlyList<SodUserConflicts> Preview);

/// <summary>
/// Policy / Rule / Condition ve SoD tanım yönetimi.
///  - Condition parametreleri ilgili IConditionHandler'a doğrulatılır (parametreyi en iyi bilen yer handler'dır).
///  - Policy veya rule'larında her değişiklik Policy.Version'ı artırır; kararlar versiyonla audit'lenir.
///  - Değişiklikler PolicyChanged event'i + audit üretir. Etkisi önceden What-If "policy impact" ile görülebilir.
/// </summary>
public sealed class PolicyManagementService(
    IYetkiDbContext db,
    ConditionHandlerRegistry handlers,
    SodService sod,
    OutboxWriter outbox,
    AuditWriter audit,
    IClock clock,
    ICurrentActor actor)
{
    // ============================== Policy ==============================

    public async Task<Policy> CreatePolicyAsync(PolicyUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.Policies.AnyAsync(p => p.Code == code, ct)) throw new ConflictException($"Policy kodu zaten var: {code}");
        var p = new Policy
        {
            Code = code, Name = dto.Name, Description = dto.Description, Domain = dto.Domain,
            CombiningAlgorithm = dto.CombiningAlgorithm, IsActive = dto.IsActive, Version = 1
        };
        db.Policies.Add(p);
        audit.Management("PolicyCreated", "Policy", code, $"Policy oluşturuldu: {code} ({dto.CombiningAlgorithm})", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", code, new { action = "created", code });
        await db.SaveChangesAsync(ct);
        return p;
    }

    public async Task UpdatePolicyAsync(int id, PolicyUpsert dto, CancellationToken ct)
    {
        var p = await db.Policies.FindAsync([id], ct) ?? throw new NotFoundException("Policy", id);
        p.Name = dto.Name; p.Description = dto.Description; p.Domain = dto.Domain;
        p.CombiningAlgorithm = dto.CombiningAlgorithm; p.IsActive = dto.IsActive;
        p.Version++;
        audit.Management("PolicyUpdated", "Policy", p.Code, $"Policy güncellendi: {p.Code} v{p.Version} ({dto.CombiningAlgorithm}, aktif={dto.IsActive})", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", p.Code, new { action = "updated", p.Code, p.Version, dto.CombiningAlgorithm, dto.IsActive });
        await db.SaveChangesAsync(ct);
    }

    // ============================== Rule ==============================

    public async Task<Rule> CreateRuleAsync(int policyId, RuleUpsert dto, CancellationToken ct)
    {
        var policy = await db.Policies.FindAsync([policyId], ct) ?? throw new NotFoundException("Policy", policyId);
        var code = Codes.Normalize(dto.Code);
        if (await db.Rules.AnyAsync(r => r.PolicyId == policyId && r.Code == code, ct))
            throw new ConflictException($"'{policy.Code}' policy'sinde bu rule kodu zaten var: {code}");
        var types = await ValidateConditionAsync(dto.Condition, ct);

        var rule = new Rule
        {
            PolicyId = policyId, Code = code, Name = dto.Name, Description = dto.Description, Effect = dto.Effect,
            Order = dto.Order, ReasonCode = NormalizeReason(dto.ReasonCode), IsActive = dto.IsActive
        };
        db.Rules.Add(rule);
        AddConditionTree(rule, null, null, dto.Condition, 0, types);
        policy.Version++;

        audit.Management("RuleCreated", "Policy", policy.Code, $"'{policy.Code}' v{policy.Version}: rule eklendi {code} ({dto.Effect} ⇐ {Render(dto.Condition)})", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", policy.Code, new { action = "rule-created", policy = policy.Code, rule = code, policy.Version });
        await db.SaveChangesAsync(ct);
        return rule;
    }

    public async Task UpdateRuleAsync(int ruleId, RuleUpsert dto, CancellationToken ct)
    {
        var rule = await db.Rules.Include(r => r.Policy).FirstOrDefaultAsync(r => r.Id == ruleId, ct) ?? throw new NotFoundException("Rule", ruleId);
        var types = await ValidateConditionAsync(dto.Condition, ct);

        rule.Name = dto.Name; rule.Description = dto.Description; rule.Effect = dto.Effect;
        rule.Order = dto.Order; rule.ReasonCode = NormalizeReason(dto.ReasonCode); rule.IsActive = dto.IsActive;
        await RemoveConditionsAsync(ruleId, ct);
        AddConditionTree(rule, null, null, dto.Condition, 0, types);
        rule.Policy.Version++;

        audit.Management("RuleUpdated", "Policy", rule.Policy.Code, $"'{rule.Policy.Code}' v{rule.Policy.Version}: rule güncellendi {rule.Code} ({dto.Effect} ⇐ {Render(dto.Condition)})", dto);
        outbox.Add(EventTypes.PolicyChanged, "Policy", rule.Policy.Code, new { action = "rule-updated", policy = rule.Policy.Code, rule = rule.Code, rule.Policy.Version });
        await db.SaveChangesAsync(ct);
    }

    public async Task DeleteRuleAsync(int ruleId, CancellationToken ct)
    {
        var rule = await db.Rules.Include(r => r.Policy).FirstOrDefaultAsync(r => r.Id == ruleId, ct) ?? throw new NotFoundException("Rule", ruleId);
        await RemoveConditionsAsync(ruleId, ct);
        db.Rules.Remove(rule);
        rule.Policy.Version++;
        audit.Management("RuleDeleted", "Policy", rule.Policy.Code, $"'{rule.Policy.Code}' v{rule.Policy.Version}: rule silindi {rule.Code}");
        outbox.Add(EventTypes.PolicyChanged, "Policy", rule.Policy.Code, new { action = "rule-deleted", policy = rule.Policy.Code, rule = rule.Code, rule.Policy.Version });
        await db.SaveChangesAsync(ct);
    }

    public sealed record ConditionValidation(IReadOnlyDictionary<string, int> Types, IReadOnlyDictionary<string, int> Shared);

    /// <summary>
    /// Condition ağacını doğrular (yapı, derinlik, predicate parametreleri, ortak koşul referansları).
    /// selfSharedId verilirse (ortak koşul düzenlerken) doğrudan/dolaylı kendine referans (döngü) reddedilir.
    /// </summary>
    public async Task<ConditionValidation> ValidateConditionAsync(ConditionDraft root, CancellationToken ct, int? selfSharedId = null)
    {
        var errors = new List<string>();
        var codes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var refs = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        void Walk(ConditionDraft n, int depth, string path)
        {
            if (depth > PolicyEvaluator.MaxConditionDepth) { errors.Add($"{path}: ağaç en fazla {PolicyEvaluator.MaxConditionDepth} seviye olabilir."); return; }
            switch (n.Kind)
            {
                case ConditionKind.Predicate:
                    if (string.IsNullOrWhiteSpace(n.ConditionTypeCode)) { errors.Add($"{path}: condition tipi zorunlu."); return; }
                    if (n.Children.Count > 0) errors.Add($"{path}: predicate çocuk içeremez.");
                    var handler = handlers.Find(n.ConditionTypeCode);
                    if (handler is null) { errors.Add($"{path}: bilinmeyen condition tipi '{n.ConditionTypeCode}'."); return; }
                    codes.Add(handler.Descriptor.Code);
                    var ps = n.Parameters.Where(kv => !string.IsNullOrWhiteSpace(kv.Value))
                        .ToDictionary(kv => kv.Key.Trim(), kv => kv.Value.Trim(), StringComparer.OrdinalIgnoreCase);
                    errors.AddRange(handler.ValidateParameters(ps).Select(e => $"{path} ({handler.Descriptor.Code}): {e}"));
                    n.Parameters = ps;
                    n.ConditionTypeCode = handler.Descriptor.Code;
                    break;
                case ConditionKind.Reference:
                    if (string.IsNullOrWhiteSpace(n.SharedConditionCode)) { errors.Add($"{path}: ortak koşul seçilmeli."); return; }
                    if (n.Children.Count > 0) errors.Add($"{path}: ortak koşul referansı çocuk içeremez.");
                    n.SharedConditionCode = Codes.Normalize(n.SharedConditionCode);
                    refs.Add(n.SharedConditionCode);
                    n.Parameters = new();
                    break;
                case ConditionKind.Not:
                    if (n.Children.Count != 1) errors.Add($"{path}: NOT tam olarak bir alt koşul içermeli.");
                    break;
                default:
                    if (n.Children.Count == 0) errors.Add($"{path}: AND/OR en az bir alt koşul içermeli.");
                    break;
            }
            for (var i = 0; i < n.Children.Count; i++) Walk(n.Children[i], depth + 1, $"{path}.{i + 1}");
        }

        Walk(root, 0, "condition");

        var refList = refs.ToList();
        var shared = await db.SharedConditions.AsNoTracking().Where(x => refList.Contains(x.Code))
            .Select(x => new { x.Id, x.Code, x.IsActive }).ToListAsync(ct);
        foreach (var r in refList)
        {
            var sc = shared.FirstOrDefault(x => x.Code == r);
            if (sc is null) errors.Add($"Ortak koşul bulunamadı: {r}");
            else if (!sc.IsActive) errors.Add($"Ortak koşul pasif: {r}");
        }
        if (selfSharedId is { } self && shared.Count > 0)
        {
            var reachable = await ReachableSharedAsync(shared.Select(x => x.Id), ct);
            if (reachable.Contains(self)) errors.Add("Döngüsel referans: ortak koşul doğrudan veya dolaylı olarak kendine referans veriyor.");
        }

        if (errors.Count > 0) throw new ValidationException("Condition geçersiz.", new Dictionary<string, string[]> { ["condition"] = errors.ToArray() });

        var codeList = codes.ToList();
        var types = await db.ConditionTypes.Where(t => codeList.Contains(t.Code) && t.IsAvailable).ToDictionaryAsync(t => t.Code, t => t.Id, StringComparer.OrdinalIgnoreCase, ct);
        var missing = codeList.Where(c => !types.ContainsKey(c)).ToList();
        if (missing.Count > 0) throw new ValidationException($"Katalogda olmayan condition tipi: {string.Join(", ", missing)}");
        return new ConditionValidation(types, shared.ToDictionary(x => x.Code, x => x.Id, StringComparer.OrdinalIgnoreCase));
    }

    /// <summary>Verilen ortak koşullar ve onların (transitif) referans verdiği ortak koşullar.</summary>
    private async Task<HashSet<int>> ReachableSharedAsync(IEnumerable<int> start, CancellationToken ct)
    {
        var edges = (await db.RuleConditions.AsNoTracking()
                .Where(c => c.SharedConditionId != null && c.ReferencedSharedConditionId != null)
                .Select(c => new { From = c.SharedConditionId!.Value, To = c.ReferencedSharedConditionId!.Value }).ToListAsync(ct))
            .ToLookup(e => e.From, e => e.To);
        var seen = new HashSet<int>();
        var stack = new Stack<int>(start);
        while (stack.Count > 0)
        {
            var id = stack.Pop();
            if (!seen.Add(id)) continue;
            foreach (var next in edges[id]) stack.Push(next);
        }
        return seen;
    }

    /// <summary>Condition ağacını entity olarak ekler. Sahibi ya bir rule ya da bir ortak koşuldur.</summary>
    internal void AddConditionTree(Rule? rule, SharedCondition? owner, RuleCondition? parent, ConditionDraft draft, int order, ConditionValidation v)
    {
        var node = new RuleCondition
        {
            Rule = rule,
            SharedCondition = owner,
            Parent = parent,
            Kind = draft.Kind,
            Order = order,
            ConditionTypeId = draft.Kind == ConditionKind.Predicate ? v.Types[draft.ConditionTypeCode!] : null,
            ReferencedSharedConditionId = draft.Kind == ConditionKind.Reference ? v.Shared[draft.SharedConditionCode!] : null,
            Parameters = draft.Kind == ConditionKind.Predicate
                ? draft.Parameters.Select(kv => new ConditionParameter { Key = kv.Key, Value = kv.Value }).ToList()
                : new List<ConditionParameter>()
        };
        db.RuleConditions.Add(node);
        for (var i = 0; i < draft.Children.Count; i++) AddConditionTree(rule, owner, node, draft.Children[i], i, v);
    }

    private async Task RemoveConditionsAsync(int ruleId, CancellationToken ct) =>
        RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.RuleId == ruleId).ToListAsync(ct));

    internal void RemoveNodes(List<RuleCondition> nodes)
    {
        foreach (var n in nodes)
        {
            foreach (var p in n.Parameters.ToList()) db.ConditionParameters.Remove(p);
            db.RuleConditions.Remove(n);
        }
    }

    private static string? NormalizeReason(string? reason) => string.IsNullOrWhiteSpace(reason) ? null : Codes.Normalize(reason);

    private static string Render(ConditionDraft d) => PolicyEvaluator.Render(PolicyDefinitionLoader.FromDraft(d, () => 0));

    // ============================== Permission <-> Policy ==============================

    public async Task SetPermissionPolicyAsync(int permissionId, int policyId, bool add, CancellationToken ct)
    {
        var perm = await db.Permissions.FindAsync([permissionId], ct) ?? throw new NotFoundException("Permission", permissionId);
        var policy = await db.Policies.FindAsync([policyId], ct) ?? throw new NotFoundException("Policy", policyId);
        var link = await db.PermissionPolicies.FirstOrDefaultAsync(x => x.PermissionId == permissionId && x.PolicyId == policyId, ct);
        if (add)
        {
            if (link is not null) throw new ConflictException("Policy zaten permission'a bağlı.");
            db.PermissionPolicies.Add(new PermissionPolicy { PermissionId = permissionId, PolicyId = policyId, AssignedAt = clock.UtcNow, AssignedBy = actor.Name });
        }
        else
        {
            if (link is null) throw new NotFoundException("Permission policy", $"{permissionId}/{policyId}");
            db.PermissionPolicies.Remove(link);
        }
        audit.Management(EventTypes.PolicyChanged, "Permission", perm.Code, $"'{perm.Code}' permission'ına '{policy.Code}' policy {(add ? "bağlandı" : "kaldırıldı")}");
        outbox.Add(EventTypes.PolicyChanged, "Permission", perm.Code, new { permission = perm.Code, policy = policy.Code, add });
        await db.SaveChangesAsync(ct);
    }

    // ============================== SoD ==============================

    public async Task<SodRuleCreated> CreateSodRuleAsync(SodRuleUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.SodRules.AnyAsync(r => r.Code == code, ct)) throw new ConflictException($"SoD kural kodu zaten var: {code}");
        var members = await ValidateSodMembersAsync(dto, ct);

        var rule = new SodRule
        {
            Code = code, Name = dto.Name, Description = dto.Description, Severity = dto.Severity,
            Enforcement = dto.Enforcement, IsActive = dto.IsActive,
            Members = members.Select(m => new SodRuleMember { MemberType = m.Type, MemberId = m.Id }).ToList()
        };
        db.SodRules.Add(rule);
        audit.Management(EventTypes.SoDRuleCreated, "SodRule", code, $"SoD kuralı oluşturuldu: {code} ({dto.Enforcement})", dto);
        outbox.Add(EventTypes.SoDRuleCreated, "SodRule", code, new { code, dto.Enforcement, members = members.Select(m => $"{m.Type}:{m.Id}") });
        await db.SaveChangesAsync(ct);

        // Yeni kural mevcut atamalarda kaç ihlal yaratıyor? (Kayıt açılmaz; retrospektif tarama ile açılır.)
        var draft = await sod.DraftSnapshotAsync(code, members, dto.Enforcement, ct);
        var preview = await sod.SimulateRuleAsync(draft, ct);
        return new SodRuleCreated(rule.Id, code, preview.Count, preview);
    }

    public async Task UpdateSodRuleAsync(int id, SodRuleUpsert dto, CancellationToken ct)
    {
        var rule = await db.SodRules.Include(r => r.Members).FirstOrDefaultAsync(r => r.Id == id, ct) ?? throw new NotFoundException("SoD kuralı", id);
        var members = await ValidateSodMembersAsync(dto, ct);
        rule.Name = dto.Name; rule.Description = dto.Description; rule.Severity = dto.Severity;
        rule.Enforcement = dto.Enforcement; rule.IsActive = dto.IsActive;
        foreach (var m in rule.Members.ToList()) db.SodRuleMembers.Remove(m);
        foreach (var m in members) db.SodRuleMembers.Add(new SodRuleMember { SodRuleId = rule.Id, MemberType = m.Type, MemberId = m.Id });
        audit.Management(EventTypes.SoDRuleChanged, "SodRule", rule.Code, $"SoD kuralı güncellendi: {rule.Code}", dto);
        outbox.Add(EventTypes.SoDRuleChanged, "SodRule", rule.Code, new { rule.Code, dto.Enforcement, dto.IsActive });
        await db.SaveChangesAsync(ct);
    }

    private async Task<List<(SodMemberType Type, int Id)>> ValidateSodMembersAsync(SodRuleUpsert dto, CancellationToken ct)
    {
        var members = dto.PermissionIds.Distinct().Select(id => (SodMemberType.Permission, id))
            .Concat(dto.RoleIds.Distinct().Select(id => (SodMemberType.Role, id))).ToList();
        if (members.Count < 2) throw new ValidationException("SoD kuralı en az 2 üye (permission/rol) içermelidir.");
        var permCount = await db.Permissions.CountAsync(p => dto.PermissionIds.Contains(p.Id), ct);
        var roleCount = await db.Roles.CountAsync(r => dto.RoleIds.Contains(r.Id), ct);
        if (permCount != dto.PermissionIds.Distinct().Count() || roleCount != dto.RoleIds.Distinct().Count())
            throw new ValidationException("SoD üyelerinden biri bulunamadı.");
        return members;
    }
}
