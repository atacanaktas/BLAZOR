using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Common;
using Yetki.Application.Evaluation;
using Yetki.Application.Events;
using Yetki.Domain.Common;
using Yetki.Domain.Policies;

namespace Yetki.Application.Definitions;

public sealed class SharedConditionUpsert
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? Description { get; set; }
    public ConditionScope Scope { get; set; } = ConditionScope.Global;
    public string? Domain { get; set; }
    public bool IsActive { get; set; } = true;
    public ConditionDraft Condition { get; set; } = new();
}

/// <summary>Ortak koşulun kullanıldığı rule. Via: dolaylı kullanımda aradaki ortak koşul zinciri.</summary>
public sealed record SharedConditionUsage(int PolicyId, string Policy, int RuleId, string Rule, string? Via);

/// <summary>
/// Ortak (adlandırılmış) koşulların yönetimi. Tanım tek yerde; rule'lar Reference düğümüyle bağlanır.
///  - Güncelleme: ortak koşulun ve onu (doğrudan/dolaylı) kullanan TÜM policy'lerin versiyonu artar, PolicyChanged event'i üretilir.
///  - Kullanımdaki ortak koşul pasifleştirilemez ve silinemez (sessizce kısıt kaldırılmasın diye).
///  - Döngüsel referans reddedilir. Değişikliğin etkisi önceden What-If ile (SharedConditionReplacements) görülebilir.
/// </summary>
public sealed class SharedConditionService(
    IYetkiDbContext db,
    PolicyManagementService definitions,
    OutboxWriter outbox,
    AuditWriter audit)
{
    public async Task<SharedCondition> CreateAsync(SharedConditionUpsert dto, CancellationToken ct)
    {
        var code = Codes.Normalize(dto.Code);
        if (await db.SharedConditions.AnyAsync(s => s.Code == code, ct)) throw new ConflictException($"Ortak koşul kodu zaten var: {code}");
        ValidateScope(dto);
        var validation = await definitions.ValidateConditionAsync(dto.Condition, ct);
        if (dto.Condition.Kind == ConditionKind.Reference && dto.Condition.SharedConditionCode == code)
            throw new ValidationException("Ortak koşul kendine referans veremez.");

        var sc = new SharedCondition
        {
            Code = code, Name = dto.Name, Description = dto.Description, Scope = dto.Scope,
            Domain = dto.Scope == ConditionScope.Domain ? dto.Domain : null, IsActive = dto.IsActive, Version = 1
        };
        db.SharedConditions.Add(sc);
        definitions.AddConditionTree(null, sc, null, dto.Condition, 0, validation);
        audit.Management("SharedConditionCreated", "SharedCondition", code, $"Ortak koşul oluşturuldu: {code} = {Render(dto.Condition)}", dto);
        outbox.Add(EventTypes.PolicyChanged, "SharedCondition", code, new { action = "shared-condition-created", code });
        await db.SaveChangesAsync(ct);
        return sc;
    }

    public async Task UpdateAsync(int id, SharedConditionUpsert dto, CancellationToken ct)
    {
        var sc = await db.SharedConditions.FirstOrDefaultAsync(s => s.Id == id, ct) ?? throw new NotFoundException("Ortak koşul", id);
        ValidateScope(dto);
        var usages = await UsagesAsync(id, ct);
        if (!dto.IsActive && sc.IsActive && usages.Count > 0)
            throw new ConflictException($"'{sc.Code}' {usages.Count} rule tarafından kullanılıyor; pasifleştirilemez (kısıt sessizce kalkmasın). Önce referansları kaldırın.", usages);

        var validation = await definitions.ValidateConditionAsync(dto.Condition, ct, selfSharedId: id);

        sc.Name = dto.Name; sc.Description = dto.Description; sc.Scope = dto.Scope;
        sc.Domain = dto.Scope == ConditionScope.Domain ? dto.Domain : null; sc.IsActive = dto.IsActive;
        sc.Version++;
        definitions.RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.SharedConditionId == id).ToListAsync(ct));
        definitions.AddConditionTree(null, sc, null, dto.Condition, 0, validation);

        // Kullanan policy'lerin karar semantiği değişti → versiyonları artar (audit'teki policy versiyonu doğru kalsın)
        var policyIds = usages.Select(u => u.PolicyId).Distinct().ToList();
        var policies = await db.Policies.Where(p => policyIds.Contains(p.Id)).ToListAsync(ct);
        foreach (var p in policies)
        {
            p.Version++;
            outbox.Add(EventTypes.PolicyChanged, "Policy", p.Code, new { action = "shared-condition-updated", policy = p.Code, policyVersion = p.Version, sharedCondition = sc.Code, sharedConditionVersion = sc.Version });
        }

        audit.Management("SharedConditionUpdated", "SharedCondition", sc.Code,
            $"Ortak koşul güncellendi: {sc.Code} v{sc.Version} = {Render(dto.Condition)} — {policies.Count} policy etkilendi ({string.Join(", ", policies.Select(p => p.Code))})",
            new { dto, affectedPolicies = policies.Select(p => new { p.Code, p.Version }) });
        await db.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(int id, CancellationToken ct)
    {
        var sc = await db.SharedConditions.FirstOrDefaultAsync(s => s.Id == id, ct) ?? throw new NotFoundException("Ortak koşul", id);
        var usages = await UsagesAsync(id, ct);
        if (usages.Count > 0) throw new ConflictException($"'{sc.Code}' kullanımda ({usages.Count} rule); silinemez.", usages);
        definitions.RemoveNodes(await db.RuleConditions.Include(c => c.Parameters).Where(c => c.SharedConditionId == id).ToListAsync(ct));
        db.SharedConditions.Remove(sc);
        audit.Management("SharedConditionDeleted", "SharedCondition", sc.Code, $"Ortak koşul silindi: {sc.Code}");
        await db.SaveChangesAsync(ct);
    }

    /// <summary>
    /// Ortak koşulu doğrudan veya başka ortak koşullar üzerinden dolaylı kullanan rule'lar.
    /// (Pasif rule/policy'ler de listelenir: aktifleşirse etkilenirler.)
    /// </summary>
    public async Task<IReadOnlyList<SharedConditionUsage>> UsagesAsync(int sharedConditionId, CancellationToken ct)
    {
        var refs = await db.RuleConditions.AsNoTracking()
            .Where(c => c.ReferencedSharedConditionId != null)
            .Select(c => new { To = c.ReferencedSharedConditionId!.Value, c.RuleId, c.SharedConditionId })
            .ToListAsync(ct);
        var codes = await db.SharedConditions.AsNoTracking().ToDictionaryAsync(s => s.Id, s => s.Code, ct);
        var byTarget = refs.ToLookup(r => r.To);

        var ruleVia = new Dictionary<int, string?>();
        var seen = new HashSet<int>();
        var queue = new Queue<(int Id, string? Via)>([(sharedConditionId, null)]);
        while (queue.Count > 0)
        {
            var (current, via) = queue.Dequeue();
            if (!seen.Add(current)) continue;
            foreach (var r in byTarget[current])
            {
                if (r.RuleId is { } ruleId) ruleVia.TryAdd(ruleId, via);
                else if (r.SharedConditionId is { } owner)
                    queue.Enqueue((owner, via is null ? codes.GetValueOrDefault(owner) : $"{codes.GetValueOrDefault(owner)} → {via}"));
            }
        }

        var ruleIds = ruleVia.Keys.ToList();
        var rules = await db.Rules.AsNoTracking().Where(r => ruleIds.Contains(r.Id))
            .Select(r => new { r.Id, r.Code, r.PolicyId, Policy = r.Policy.Code }).ToListAsync(ct);
        return rules.OrderBy(r => r.Policy).ThenBy(r => r.Code)
            .Select(r => new SharedConditionUsage(r.PolicyId, r.Policy, r.Id, r.Code, ruleVia[r.Id])).ToList();
    }

    private static void ValidateScope(SharedConditionUpsert dto)
    {
        if (dto.Scope == ConditionScope.Domain && string.IsNullOrWhiteSpace(dto.Domain))
            throw new ValidationException("Domain kapsamlı ortak koşul için Domain zorunlu.");
    }

    private static string Render(ConditionDraft d) => PolicyEngine.PolicyEvaluator.Render(PolicyDefinitionLoader.FromDraft(d, () => 0));
}
