using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Audit;
using Yetki.Application.Effective;
using Yetki.Application.Events;
using Yetki.Application.Sod;
using Yetki.Domain.Common;

namespace Yetki.Application.Changes;

public sealed record PermissionDelta(int PermissionId, string Code, string Name, IReadOnlyList<string> Paths);

public sealed record ExternalRequirement(string PermissionCode, string SystemCode, string ExternalPermissionCode, string? ExternalPermissionName);

public sealed record UserImpact(
    int UserId, string UserName, string FullName,
    IReadOnlyList<PermissionDelta> AddedPermissions,
    IReadOnlyList<PermissionDelta> RemovedPermissions,
    IReadOnlyList<string> AddedRoles,
    IReadOnlyList<string> RemovedRoles,
    IReadOnlyList<string> AddedGroups,
    IReadOnlyList<string> RemovedGroups,
    IReadOnlyList<SodConflict> NewSodConflicts,
    IReadOnlyList<ExternalRequirement> ExternalGrants,
    IReadOnlyList<ExternalRequirement> ExternalRevokes,
    IReadOnlyList<PermissionSourceChange> RetainedPermissions)
{
    public bool HasChanges => AddedPermissions.Count + RemovedPermissions.Count + AddedRoles.Count + RemovedRoles.Count
                              + AddedGroups.Count + RemovedGroups.Count + RetainedPermissions.Count > 0;
}

/// <summary>
/// Kullanıcı yetkiyi KORUR ama kaynağı değişir. Tipik örnek: rolden permission çıkarılır ama kullanıcı aynı
/// permission'ı bir gruptan veya başka rolden de aldığı için kaybetmez.
/// </summary>
public sealed record PermissionSourceChange(int PermissionId, string Code, string Name, IReadOnlyList<string> BeforePaths, IReadOnlyList<string> AfterPaths);

public sealed record SodFinding(int UserId, string UserName, SodConflict Conflict);

/// <summary>Bir değişikliğin etki analizi. What-If'te sadece döner, gerçek atamada uygulanır ve döner.</summary>
public sealed class ChangeImpactResult
{
    public bool DryRun { get; init; }
    public bool Applied { get; set; }
    public bool Blocked { get; set; }
    public string Summary { get; set; } = "";
    public int AffectedUserCount { get; init; }
    /// <summary>Değişiklikten etkilenebilecek (kapsamdaki) ve önce/sonra hesaplanan kullanıcı sayısı.</summary>
    public int EvaluatedUserCount { get; init; }
    public IReadOnlyList<UserImpact> Users { get; init; } = [];
    /// <summary>Enforcement=Block olan YENİ SoD çakışmaları. Varsa değişiklik uygulanmaz.</summary>
    public IReadOnlyList<SodFinding> BlockingConflicts { get; init; } = [];
    /// <summary>Enforcement=Warn olan YENİ SoD çakışmaları. Değişiklik uygulanır, ihlal kaydı açılır.</summary>
    public IReadOnlyList<SodFinding> Warnings { get; init; } = [];
}

/// <summary>Gerçek uygulama için komut: change set + entity değişikliklerini yapan callback + event/audit bilgisi.</summary>
public sealed class ChangeCommand
{
    public required AuthorizationChangeSet Changes { get; init; }
    public required Func<Task> ApplyEntities { get; init; }
    public required string EventType { get; init; }
    public required string AggregateType { get; init; }
    public required object AggregateId { get; init; }
    public required object EventPayload { get; init; }
    public required string AuditSummary { get; init; }
}

/// <summary>
/// Tüm yetki atama değişikliklerinin tek kapısı:
///   1. Etkilenen kullanıcıları bul
///   2. Her biri için önce/sonra effective hesapla (AYNI hesaplayıcı, change set ile)
///   3. Yeni SoD çakışmalarını bul (Block -> reddet, Warn -> uygula + ihlal kaydı)
///   4. Entity değişikliklerini uygula + audit + outbox (tek SaveChanges = tek transaction)
/// What-If ekranı 1-3'ü aynen kullanır (AnalyzeAsync), yani simülasyon ile gerçek sonuç arasında fark olamaz.
/// </summary>
public sealed class AuthorizationChangeService(
    IYetkiDbContext db,
    EffectivePermissionService effective,
    SodService sod,
    OutboxWriter outbox,
    AuditWriter audit)
{
    public async Task<ChangeImpactResult> AnalyzeAsync(AuthorizationChangeSet changes, bool dryRun = true, CancellationToken ct = default)
    {
        var userIds = await ResolveAffectedUsersAsync(changes, ct);
        var rules = await sod.LoadActiveRulesAsync(ct);

        var raw = new List<(EffectivePermissionSet Before, EffectivePermissionSet After, IReadOnlyList<SodConflict> NewConflicts)>();
        foreach (var userId in userIds)
        {
            var before = await effective.GetAsync(userId, null, useCache: true, ct);
            var after = await effective.GetAsync(userId, changes, useCache: false, ct);
            if (before is null || after is null) continue;

            var beforeRuleIds = SodEvaluator.Evaluate(before, rules).Select(c => c.SodRuleId).ToHashSet();
            var newConflicts = SodEvaluator.Evaluate(after, rules).Where(c => !beforeRuleIds.Contains(c.SodRuleId)).ToList();
            raw.Add((before, after, newConflicts));
        }

        // External mapping'ler tek sorguda (sadece eklenen/çıkan permission'lar için)
        var changedPermIds = raw.SelectMany(r =>
        {
            var b = r.Before.Permissions.Select(p => p.PermissionId).ToHashSet();
            var a = r.After.Permissions.Select(p => p.PermissionId).ToHashSet();
            b.SymmetricExceptWith(a);
            return b;
        }).Distinct().ToList();
        var mappings = (await db.PermissionExternalMappings.AsNoTracking()
                .Where(m => changedPermIds.Contains(m.PermissionId))
                .Select(m => new { m.PermissionId, System = m.ExternalPermission.ExternalSystem.Code, m.ExternalPermission.Code, m.ExternalPermission.Name })
                .ToListAsync(ct))
            .ToLookup(m => m.PermissionId);

        var impacts = new List<UserImpact>();
        foreach (var (before, after, newConflicts) in raw)
        {
            var beforePerms = before.Permissions.ToDictionary(p => p.PermissionId);
            var afterPerms = after.Permissions.ToDictionary(p => p.PermissionId);
            var added = afterPerms.Values.Where(p => !beforePerms.ContainsKey(p.PermissionId))
                .Select(p => new PermissionDelta(p.PermissionId, p.Code, p.Name, p.Sources.Select(s => s.Path).ToList())).ToList();
            var removed = beforePerms.Values.Where(p => !afterPerms.ContainsKey(p.PermissionId))
                .Select(p => new PermissionDelta(p.PermissionId, p.Code, p.Name, p.Sources.Select(s => s.Path).ToList())).ToList();
            var retained = afterPerms.Values
                .Where(p => beforePerms.TryGetValue(p.PermissionId, out var b)
                            && !b.Sources.Select(s => s.Path).ToHashSet().SetEquals(p.Sources.Select(s => s.Path)))
                .Select(p => new PermissionSourceChange(p.PermissionId, p.Code, p.Name,
                    beforePerms[p.PermissionId].Sources.Select(s => s.Path).ToList(), p.Sources.Select(s => s.Path).ToList()))
                .ToList();

            List<ExternalRequirement> Ext(IEnumerable<PermissionDelta> deltas) => deltas
                .SelectMany(d => mappings[d.PermissionId].Select(m => new ExternalRequirement(d.Code, m.System, m.Code, m.Name)))
                .ToList();

            impacts.Add(new UserImpact(
                after.UserId, after.UserName, after.FullName,
                added, removed,
                after.Roles.Select(r => r.Code).Except(before.Roles.Select(r => r.Code)).ToList(),
                before.Roles.Select(r => r.Code).Except(after.Roles.Select(r => r.Code)).ToList(),
                after.Groups.Select(g => g.Code).Except(before.Groups.Select(g => g.Code)).ToList(),
                before.Groups.Select(g => g.Code).Except(after.Groups.Select(g => g.Code)).ToList(),
                newConflicts, Ext(added), Ext(removed), retained));
        }

        var blocking = impacts.SelectMany(u => u.NewSodConflicts.Where(c => c.Enforcement == SodEnforcement.Block)
            .Select(c => new SodFinding(u.UserId, u.UserName, c))).ToList();
        var warnings = impacts.SelectMany(u => u.NewSodConflicts.Where(c => c.Enforcement == SodEnforcement.Warn)
            .Select(c => new SodFinding(u.UserId, u.UserName, c))).ToList();

        var changedUsers = impacts.Where(i => i.HasChanges).ToList();
        return new ChangeImpactResult
        {
            DryRun = dryRun,
            AffectedUserCount = changedUsers.Count(u => u.AddedPermissions.Count + u.RemovedPermissions.Count > 0),
            EvaluatedUserCount = raw.Count,
            Users = changedUsers,
            BlockingConflicts = blocking,
            Warnings = warnings,
            Blocked = blocking.Count > 0,
            Summary = BuildSummary(changedUsers, blocking, warnings)
        };
    }

    public async Task<ChangeImpactResult> ApplyAsync(ChangeCommand command, CancellationToken ct = default)
    {
        var impact = await AnalyzeAsync(command.Changes, dryRun: false, ct);
        if (impact.Blocked)
            throw new ConflictException("SoD kuralı nedeniyle değişiklik engellendi. " + impact.Summary, impact);

        await command.ApplyEntities();

        foreach (var group in impact.Warnings.GroupBy(w => w.UserId))
            await sod.UpsertViolationsAsync(group.Key, group.Select(g => g.Conflict), ViolationDetectionSource.AssignmentCheck, ct);

        outbox.Add(command.EventType, command.AggregateType, command.AggregateId, command.EventPayload);
        foreach (var u in impact.Users.Where(u => u.AddedPermissions.Count + u.RemovedPermissions.Count > 0))
        {
            outbox.Add(EventTypes.EffectivePermissionsChanged, "User", u.UserId, new EffectivePermissionsChangedPayload(
                u.UserId, u.UserName, command.EventType,
                u.AddedPermissions.Select(p => new PermissionRef(p.PermissionId, p.Code)).ToList(),
                u.RemovedPermissions.Select(p => new PermissionRef(p.PermissionId, p.Code)).ToList()));
        }

        audit.Management(command.EventType, command.AggregateType, command.AggregateId,
            $"{command.AuditSummary} — {impact.Summary}",
            new { command.EventPayload, impact.AffectedUserCount, Warnings = impact.Warnings.Select(w => new { w.UserName, w.Conflict.Code }) });

        await db.SaveChangesAsync(ct);
        impact.Applied = true;
        return impact;
    }

    /// <summary>
    /// Değişiklikten etkilenebilecek kullanıcılar.
    /// TODO(perf): Rol/grup seviyesinde değişiklikler binlerce kullanıcıyı etkileyebilir; prototipte senkron analiz edilir.
    /// Üretimde: senkron sadece SoD Block kontrolü (set-based SQL), diff/provisioning fan-out asenkron job.
    /// </summary>
    public async Task<IReadOnlyList<int>> ResolveAffectedUsersAsync(AuthorizationChangeSet changes, CancellationToken ct)
    {
        var ids = new HashSet<int>();
        if (changes.UserId is { } uid) ids.Add(uid);

        foreach (var rc in changes.RolePermissionChanges)
            ids.UnionWith(await UsersHoldingRoleAsync(rc.RoleId, ct));

        foreach (var gc in changes.GroupChanges)
        {
            switch (gc.Kind)
            {
                case GroupChangeKind.AudienceUser:
                    ids.Add(gc.TargetId);
                    break;
                case GroupChangeKind.AudienceRole:
                    ids.UnionWith(await db.UserRoles.AsNoTracking().Where(x => x.RoleId == gc.TargetId).Select(x => x.UserId).ToListAsync(ct));
                    break;
                case GroupChangeKind.AudienceOrgUnit:
                    ids.UnionWith(await db.UserOrganizationUnits.AsNoTracking().Where(x => x.OrganizationUnitId == gc.TargetId).Select(x => x.UserId).ToListAsync(ct));
                    break;
                default:
                    ids.UnionWith(await GroupAudienceAsync(gc.GroupId, ct));
                    break;
            }
        }
        return ids.Order().ToList();
    }

    public async Task<IReadOnlyCollection<int>> GroupAudienceAsync(int groupId, CancellationToken ct)
    {
        var ids = new HashSet<int>(await db.GroupUsers.AsNoTracking().Where(x => x.GroupId == groupId).Select(x => x.UserId).ToListAsync(ct));
        var roleIds = await db.GroupRoles.AsNoTracking().Where(x => x.GroupId == groupId).Select(x => x.RoleId).ToListAsync(ct);
        var ouIds = await db.GroupOrganizationUnits.AsNoTracking().Where(x => x.GroupId == groupId).Select(x => x.OrganizationUnitId).ToListAsync(ct);
        ids.UnionWith(await db.UserRoles.AsNoTracking().Where(x => roleIds.Contains(x.RoleId)).Select(x => x.UserId).ToListAsync(ct));
        ids.UnionWith(await db.UserOrganizationUnits.AsNoTracking().Where(x => ouIds.Contains(x.OrganizationUnitId)).Select(x => x.UserId).ToListAsync(ct));
        return ids;
    }

    private async Task<IReadOnlyCollection<int>> UsersHoldingRoleAsync(int roleId, CancellationToken ct)
    {
        var ids = new HashSet<int>(await db.UserRoles.AsNoTracking().Where(x => x.RoleId == roleId).Select(x => x.UserId).ToListAsync(ct));
        var groupIds = await db.GroupGrantedRoles.AsNoTracking().Where(x => x.RoleId == roleId).Select(x => x.GroupId).ToListAsync(ct);
        foreach (var g in groupIds) ids.UnionWith(await GroupAudienceAsync(g, ct));
        return ids;
    }

    private static string BuildSummary(List<UserImpact> users, List<SodFinding> blocking, List<SodFinding> warnings)
    {
        var added = users.Sum(u => u.AddedPermissions.Count);
        var removed = users.Sum(u => u.RemovedPermissions.Count);
        var gainers = users.Count(u => u.AddedPermissions.Count > 0);
        var losers = users.Count(u => u.RemovedPermissions.Count > 0);
        var retained = users.Sum(u => u.RetainedPermissions.Count);
        var s = $"{users.Count(u => u.AddedPermissions.Count + u.RemovedPermissions.Count > 0)} kullanıcının yetkisi değişir " +
                $"({gainers} kullanıcı +{added} yetki kazanır, {losers} kullanıcı -{removed} yetki kaybeder).";
        if (retained > 0) s += $" {retained} yetki başka kaynaktan korunur.";
        if (blocking.Count > 0) s += $" {blocking.Count} ENGELLEYİCİ SoD çakışması.";
        if (warnings.Count > 0) s += $" {warnings.Count} SoD uyarısı.";
        return s;
    }
}
