using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Application.Effective;
using Yetki.Application.Events;
using Yetki.Domain.Groups;
using Yetki.Domain.Identity;
using Yetki.Domain.Rbac;

namespace Yetki.Application.Changes;

/// <summary>
/// Yetki atamalarını değiştiren TÜM yönetim işlemleri. Her işlem bir AuthorizationChangeSet'e çevrilir ve
/// AuthorizationChangeService üzerinden (SoD kontrolü + event + audit) uygulanır.
/// Aynı change set'ler What-If ekranında dryRun ile kullanılır.
/// </summary>
public sealed class AssignmentService(IYetkiDbContext db, AuthorizationChangeService changes, IClock clock, ICurrentActor actor)
{
    // ------------------------- Kullanıcı -------------------------

    public async Task<ChangeImpactResult> AssignRoleToUserAsync(int userId, int roleId, DateTime? validUntil, CancellationToken ct)
    {
        var user = await UserAsync(userId, ct);
        var role = await db.Roles.FindAsync([roleId], ct) ?? throw new NotFoundException("Rol", roleId);
        if (await db.UserRoles.AnyAsync(x => x.UserId == userId && x.RoleId == roleId, ct))
            throw new ConflictException($"'{user.UserName}' zaten '{role.Code}' rolüne sahip.");

        var cs = AuthorizationChangeSet.ForUser(userId);
        cs.AddUserRoleIds.Add(roleId);
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () =>
            {
                db.UserRoles.Add(new UserRole { UserId = userId, RoleId = roleId, ValidUntil = validUntil, AssignedAt = clock.UtcNow, AssignedBy = actor.Name });
                return Task.CompletedTask;
            },
            EventType = EventTypes.RoleAssigned, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, roleId, role.Code, validUntil },
            AuditSummary = $"'{user.UserName}' kullanıcısına '{role.Code}' rolü atandı"
        }, ct);
    }

    public async Task<ChangeImpactResult> RevokeRoleFromUserAsync(int userId, int roleId, CancellationToken ct)
    {
        var user = await UserAsync(userId, ct);
        var link = await db.UserRoles.Include(x => x.Role).FirstOrDefaultAsync(x => x.UserId == userId && x.RoleId == roleId, ct)
                   ?? throw new NotFoundException("Kullanıcı rolü", $"{userId}/{roleId}");
        var cs = AuthorizationChangeSet.ForUser(userId);
        cs.RemoveUserRoleIds.Add(roleId);
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () => { db.UserRoles.Remove(link); return Task.CompletedTask; },
            EventType = EventTypes.RoleRevoked, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, roleId, link.Role.Code },
            AuditSummary = $"'{user.UserName}' kullanıcısından '{link.Role.Code}' rolü alındı"
        }, ct);
    }

    public async Task<ChangeImpactResult> GrantPermissionToUserAsync(int userId, int permissionId, string? reason, DateTime? validUntil, CancellationToken ct)
    {
        var user = await UserAsync(userId, ct);
        var perm = await db.Permissions.FindAsync([permissionId], ct) ?? throw new NotFoundException("Permission", permissionId);
        if (await db.UserPermissions.AnyAsync(x => x.UserId == userId && x.PermissionId == permissionId, ct))
            throw new ConflictException($"'{user.UserName}' kullanıcısında '{perm.Code}' doğrudan ataması zaten var.");

        var cs = AuthorizationChangeSet.ForUser(userId);
        cs.AddUserPermissionIds.Add(permissionId);
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () =>
            {
                db.UserPermissions.Add(new UserPermission { UserId = userId, PermissionId = permissionId, Reason = reason, ValidUntil = validUntil, AssignedAt = clock.UtcNow, AssignedBy = actor.Name });
                return Task.CompletedTask;
            },
            EventType = EventTypes.PermissionAssigned, AggregateType = "User", AggregateId = userId,
            EventPayload = new { target = "User", userId, user.UserName, permissionId, perm.Code, reason },
            AuditSummary = $"'{user.UserName}' kullanıcısına doğrudan '{perm.Code}' verildi"
        }, ct);
    }

    public async Task<ChangeImpactResult> RevokePermissionFromUserAsync(int userId, int permissionId, CancellationToken ct)
    {
        var user = await UserAsync(userId, ct);
        var link = await db.UserPermissions.Include(x => x.Permission).FirstOrDefaultAsync(x => x.UserId == userId && x.PermissionId == permissionId, ct)
                   ?? throw new NotFoundException("Kullanıcı permission", $"{userId}/{permissionId}");
        var cs = AuthorizationChangeSet.ForUser(userId);
        cs.RemoveUserPermissionIds.Add(permissionId);
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () => { db.UserPermissions.Remove(link); return Task.CompletedTask; },
            EventType = EventTypes.PermissionRevoked, AggregateType = "User", AggregateId = userId,
            EventPayload = new { target = "User", userId, user.UserName, permissionId, link.Permission.Code },
            AuditSummary = $"'{user.UserName}' kullanıcısından doğrudan '{link.Permission.Code}' alındı"
        }, ct);
    }

    public async Task<ChangeImpactResult> SetUserOrgUnitAsync(int userId, int orgUnitId, bool add, bool isPrimary, CancellationToken ct)
    {
        var user = await UserAsync(userId, ct);
        var ou = await db.OrganizationUnits.FindAsync([orgUnitId], ct) ?? throw new NotFoundException("Birim", orgUnitId);
        var link = await db.UserOrganizationUnits.FirstOrDefaultAsync(x => x.UserId == userId && x.OrganizationUnitId == orgUnitId, ct);
        if (add && link is not null) throw new ConflictException("Kullanıcı zaten bu birimde.");
        if (!add && link is null) throw new NotFoundException("Kullanıcı birimi", $"{userId}/{orgUnitId}");

        var cs = AuthorizationChangeSet.ForUser(userId);
        (add ? cs.AddUserOrgUnitIds : cs.RemoveUserOrgUnitIds).Add(orgUnitId);
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () =>
            {
                if (add) db.UserOrganizationUnits.Add(new UserOrganizationUnit { UserId = userId, OrganizationUnitId = orgUnitId, IsPrimary = isPrimary, AssignedAt = clock.UtcNow, AssignedBy = actor.Name });
                else db.UserOrganizationUnits.Remove(link!);
                return Task.CompletedTask;
            },
            EventType = EventTypes.OrgUnitAssignmentChanged, AggregateType = "User", AggregateId = userId,
            EventPayload = new { userId, user.UserName, orgUnitId, ou.Code, add },
            AuditSummary = $"'{user.UserName}' {(add ? "birime eklendi" : "biriminden çıkarıldı")}: {ou.Code}"
        }, ct);
    }

    // ------------------------- Rol -------------------------

    public async Task<ChangeImpactResult> SetRolePermissionAsync(int roleId, int permissionId, bool add, CancellationToken ct)
    {
        var role = await db.Roles.FindAsync([roleId], ct) ?? throw new NotFoundException("Rol", roleId);
        var perm = await db.Permissions.FindAsync([permissionId], ct) ?? throw new NotFoundException("Permission", permissionId);
        var link = await db.RolePermissions.FirstOrDefaultAsync(x => x.RoleId == roleId && x.PermissionId == permissionId, ct);
        if (add && link is not null) throw new ConflictException($"'{role.Code}' zaten '{perm.Code}' içeriyor.");
        if (!add && link is null) throw new NotFoundException("Rol permission", $"{roleId}/{permissionId}");

        var cs = new AuthorizationChangeSet();
        cs.RolePermissionChanges.Add(new RolePermissionChange(roleId, permissionId, add));
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () =>
            {
                if (add) db.RolePermissions.Add(new RolePermission { RoleId = roleId, PermissionId = permissionId, AssignedAt = clock.UtcNow, AssignedBy = actor.Name });
                else db.RolePermissions.Remove(link!);
                return Task.CompletedTask;
            },
            EventType = add ? EventTypes.PermissionAssigned : EventTypes.PermissionRevoked, AggregateType = "Role", AggregateId = roleId,
            EventPayload = new { target = "Role", roleId, roleCode = role.Code, permissionId, permissionCode = perm.Code },
            AuditSummary = $"'{role.Code}' rolüne '{perm.Code}' {(add ? "eklendi" : "çıkarıldı")}"
        }, ct);
    }

    // ------------------------- Grup -------------------------

    public async Task<ChangeImpactResult> SetGroupItemAsync(int groupId, GroupChangeKind kind, int targetId, bool add, CancellationToken ct)
    {
        var group = await db.Groups.FindAsync([groupId], ct) ?? throw new NotFoundException("Grup", groupId);
        var (exists, label, entity) = await FindGroupItemAsync(groupId, kind, targetId, ct);
        if (add && exists) throw new ConflictException($"'{group.Code}' grubunda bu kayıt zaten var: {label}");
        if (!add && !exists) throw new NotFoundException("Grup kaydı", $"{kind}/{targetId}");

        var cs = new AuthorizationChangeSet();
        cs.GroupChanges.Add(new GroupChange(groupId, kind, targetId, add));
        var isAudience = kind is GroupChangeKind.AudienceUser or GroupChangeKind.AudienceRole or GroupChangeKind.AudienceOrgUnit;
        return await changes.ApplyAsync(new ChangeCommand
        {
            Changes = cs,
            ApplyEntities = () =>
            {
                if (!add) { db.Remove(entity!); return Task.CompletedTask; }
                var now = clock.UtcNow;
                object link = kind switch
                {
                    GroupChangeKind.AudienceUser => new GroupUser { GroupId = groupId, UserId = targetId, AssignedAt = now, AssignedBy = actor.Name },
                    GroupChangeKind.AudienceRole => new GroupRole { GroupId = groupId, RoleId = targetId, AssignedAt = now, AssignedBy = actor.Name },
                    GroupChangeKind.AudienceOrgUnit => new GroupOrganizationUnit { GroupId = groupId, OrganizationUnitId = targetId, AssignedAt = now, AssignedBy = actor.Name },
                    GroupChangeKind.GrantPermission => new GroupPermission { GroupId = groupId, PermissionId = targetId, AssignedAt = now, AssignedBy = actor.Name },
                    GroupChangeKind.GrantRole => new GroupGrantedRole { GroupId = groupId, RoleId = targetId, AssignedAt = now, AssignedBy = actor.Name },
                    _ => throw new ValidationException("Geçersiz grup değişiklik tipi")
                };
                db.Add(link);
                return Task.CompletedTask;
            },
            EventType = isAudience ? EventTypes.GroupMembershipChanged : EventTypes.GroupGrantChanged,
            AggregateType = "Group", AggregateId = groupId,
            EventPayload = new { groupId, group.Code, kind = kind.ToString(), targetId, target = label, add },
            AuditSummary = $"'{group.Code}' grubu: {kind} {label} {(add ? "eklendi" : "çıkarıldı")}"
        }, ct);
    }

    private async Task<(bool Exists, string Label, object? Entity)> FindGroupItemAsync(int groupId, GroupChangeKind kind, int targetId, CancellationToken ct)
    {
        switch (kind)
        {
            case GroupChangeKind.AudienceUser:
            {
                var u = await db.Users.FindAsync([targetId], ct) ?? throw new NotFoundException("Kullanıcı", targetId);
                var e = await db.GroupUsers.FirstOrDefaultAsync(x => x.GroupId == groupId && x.UserId == targetId, ct);
                return (e is not null, $"kullanıcı {u.UserName}", e);
            }
            case GroupChangeKind.AudienceRole:
            {
                var r = await db.Roles.FindAsync([targetId], ct) ?? throw new NotFoundException("Rol", targetId);
                var e = await db.GroupRoles.FirstOrDefaultAsync(x => x.GroupId == groupId && x.RoleId == targetId, ct);
                return (e is not null, $"kitle rolü {r.Code}", e);
            }
            case GroupChangeKind.AudienceOrgUnit:
            {
                var o = await db.OrganizationUnits.FindAsync([targetId], ct) ?? throw new NotFoundException("Birim", targetId);
                var e = await db.GroupOrganizationUnits.FirstOrDefaultAsync(x => x.GroupId == groupId && x.OrganizationUnitId == targetId, ct);
                return (e is not null, $"birim {o.Code}", e);
            }
            case GroupChangeKind.GrantPermission:
            {
                var p = await db.Permissions.FindAsync([targetId], ct) ?? throw new NotFoundException("Permission", targetId);
                var e = await db.GroupPermissions.FirstOrDefaultAsync(x => x.GroupId == groupId && x.PermissionId == targetId, ct);
                return (e is not null, $"permission {p.Code}", e);
            }
            case GroupChangeKind.GrantRole:
            {
                var r = await db.Roles.FindAsync([targetId], ct) ?? throw new NotFoundException("Rol", targetId);
                var e = await db.GroupGrantedRoles.FirstOrDefaultAsync(x => x.GroupId == groupId && x.RoleId == targetId, ct);
                return (e is not null, $"verilen rol {r.Code}", e);
            }
            default:
                throw new ValidationException("Geçersiz grup değişiklik tipi");
        }
    }

    private async Task<User> UserAsync(int userId, CancellationToken ct) =>
        await db.Users.FindAsync([userId], ct) ?? throw new NotFoundException("Kullanıcı", userId);
}
