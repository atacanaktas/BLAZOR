using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Yetki.Sdk;

public interface IYetkiEngineClient
{
    Task<EvaluateResponse> EvaluateAsync(EvaluateRequest request, CancellationToken ct);
}

/// <summary>Motor HTTP istemcisi. Erişilemezse / hata dönerse FAIL CLOSED (Deny).</summary>
public sealed class YetkiEngineClient(HttpClient http, ILogger<YetkiEngineClient> logger) : IYetkiEngineClient
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { Converters = { new JsonStringEnumConverter() } };

    public async Task<EvaluateResponse> EvaluateAsync(EvaluateRequest request, CancellationToken ct)
    {
        try
        {
            using var response = await http.PostAsJsonAsync("api/authorization/evaluate", request, Json, ct);
            if (!response.IsSuccessStatusCode)
            {
                logger.LogWarning("Yetki motoru {Status} döndü ({Permission})", (int)response.StatusCode, request.Permission);
                return EvaluateResponse.LocalDeny(request.Permission, "ENGINE_ERROR", $"Yetki motoru hata döndü: {(int)response.StatusCode}");
            }
            return await response.Content.ReadFromJsonAsync<EvaluateResponse>(Json, ct)
                   ?? EvaluateResponse.LocalDeny(request.Permission, "ENGINE_ERROR", "Yetki motoru boş cevap döndü.");
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or JsonException)
        {
            logger.LogError(ex, "Yetki motoruna erişilemedi ({Permission})", request.Permission);
            return EvaluateResponse.LocalDeny(request.Permission, "ENGINE_UNAVAILABLE", "Yetki motoruna erişilemedi; güvenli tarafta kalınarak reddedildi.");
        }
    }
}

/// <summary>
/// Global action filter: [RequiresPermission] taşıyan endpoint'lerde, model binding'den SONRA ve iş kodundan ÖNCE çalışır.
/// Context'i toplar, motoru çağırır, Deny/Indeterminate ise action'ı hiç çalıştırmaz (403).
/// </summary>
public sealed class YetkiAuthorizationFilter(
    IYetkiEngineClient client,
    AuthorizationContextBuilder contextBuilder,
    IOptions<YetkiAuthorizationOptions> options,
    ILogger<YetkiAuthorizationFilter> logger) : IAsyncActionFilter, IOrderedFilter
{
    public const string DecisionItemKey = "Yetki.AuthorizationDecisions";

    public int Order => -10_000;

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var requirements = context.ActionDescriptor.EndpointMetadata.OfType<RequiresPermissionAttribute>().ToList();
        if (requirements.Count == 0)
        {
            await next();
            return;
        }

        var userName = contextBuilder.ResolveUserName(context.HttpContext);
        if (userName is null)
        {
            context.Result = new UnauthorizedObjectResult(new ProblemDetails { Status = 401, Title = "Kimlik doğrulanmamış", Detail = "Kullanıcı kimliği bulunamadı." });
            return;
        }

        var built = contextBuilder.Build(context);
        var decisions = new List<EvaluateResponse>();

        foreach (var req in requirements)
        {
            EvaluateResponse decision;
            if (built.Conflicts.Count > 0)
            {
                decision = EvaluateResponse.LocalDeny(req.Permission, "AMBIGUOUS_CONTEXT",
                    "Aynı context anahtarı için birden fazla farklı değer bulundu: " + string.Join("; ", built.Conflicts));
            }
            else
            {
                EvaluateResource? resource = null;
                if (req.ResourceType is not null && built.Values.TryGetValue(AuthContextKey.Of(AuthContextType.AccountNo), out var acc) && acc is not null)
                    resource = new EvaluateResource { Type = req.ResourceType, Id = acc };

                decision = await client.EvaluateAsync(new EvaluateRequest
                {
                    Subject = new EvaluateSubject { UserName = userName },
                    Permission = req.Permission,
                    Action = req.Action,
                    Resource = resource,
                    Context = new Dictionary<string, string?>(built.Values),
                    Application = options.Value.ApplicationCode,
                    CorrelationId = context.HttpContext.TraceIdentifier
                }, context.HttpContext.RequestAborted);
            }
            decisions.Add(decision);

            if (!decision.IsAllowed)
            {
                logger.LogInformation("Yetki reddedildi: {User} {Permission} {Reason}", userName, req.Permission, decision.ReasonCode);
                context.Result = Deny(decision);
                context.HttpContext.Items[DecisionItemKey] = decisions;
                return;
            }
        }

        context.HttpContext.Items[DecisionItemKey] = decisions;
        await next();
    }

    private static IActionResult Deny(EvaluateResponse d)
    {
        var status = d.ReasonCode is "ENGINE_UNAVAILABLE" or "ENGINE_ERROR" ? StatusCodes.Status503ServiceUnavailable : StatusCodes.Status403Forbidden;
        var problem = new ProblemDetails
        {
            Status = status,
            Title = status == 403 ? $"Yetki reddedildi ({d.Decision})" : "Yetki kontrolü yapılamadı",
            Detail = d.HumanReadableReason,
            Extensions =
            {
                ["decisionId"] = d.DecisionId,
                ["decision"] = d.Decision,
                ["permission"] = d.Permission,
                ["reasonCode"] = d.ReasonCode,
                ["decidingPolicy"] = d.DecidingPolicy,
                ["decidingRule"] = d.DecidingRule,
                ["failedRules"] = d.FailedRules,
                ["missingAttributes"] = d.MissingAttributes
            }
        };
        return new ObjectResult(problem) { StatusCode = status };
    }
}

public static class YetkiSdkExtensions
{
    /// <summary>
    /// SDK kaydı: <c>builder.Services.AddYetkiAuthorization(o => { o.EngineBaseUrl = "..."; o.ApplicationCode = "GISE"; });</c>
    /// Ardından controller'larda sadece [RequiresPermission] ve DTO'larda [AuthContext] kullanılır.
    /// </summary>
    public static IServiceCollection AddYetkiAuthorization(this IServiceCollection services, Action<YetkiAuthorizationOptions> configure)
    {
        services.Configure(configure);
        services.AddSingleton<AuthorizationContextBuilder>();
        services.AddHttpClient<IYetkiEngineClient, YetkiEngineClient>((sp, http) =>
        {
            var o = sp.GetRequiredService<IOptions<YetkiAuthorizationOptions>>().Value;
            http.BaseAddress = new Uri(o.EngineBaseUrl.TrimEnd('/') + "/");
            http.Timeout = o.Timeout;
        });
        services.AddScoped<YetkiAuthorizationFilter>();
        services.Configure<MvcOptions>(mvc => mvc.Filters.AddService<YetkiAuthorizationFilter>());
        return services;
    }

    /// <summary>İş kodunda (loglama vb. için) bu isteğe ait yetki kararları.</summary>
    public static IReadOnlyList<EvaluateResponse> GetAuthorizationDecisions(this HttpContext http) =>
        http.Items.TryGetValue(YetkiAuthorizationFilter.DecisionItemKey, out var v) && v is List<EvaluateResponse> list ? list : [];
}
