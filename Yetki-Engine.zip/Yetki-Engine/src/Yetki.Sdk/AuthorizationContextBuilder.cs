using System.Collections;
using System.Collections.Concurrent;
using System.Globalization;
using System.Reflection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;

namespace Yetki.Sdk;

public sealed class ContextBuildResult
{
    public Dictionary<string, string?> Values { get; } = new(StringComparer.OrdinalIgnoreCase);
    public List<string> Conflicts { get; } = new();
}

/// <summary>
/// Normalize AuthorizationContext'i üretir:
///  - Teknik context (kullanıcı, IP, zaman, kanal, platform) framework'ten OTOMATİK toplanır.
///  - İş context'i, action argümanlarında [AuthContext] ile işaretlenmiş property/parametrelerden toplanır.
///    Property adına bakılmaz (naming convention YOK).
///  - Aynı anahtar farklı değerlerle birden fazla yerde bulunursa çakışma raporlanır (fail closed).
/// Reflection meta verisi tip başına cache'lenir.
/// </summary>
public sealed class AuthorizationContextBuilder(IOptions<YetkiAuthorizationOptions> options)
{
    private static readonly ConcurrentDictionary<Type, (PropertyInfo Prop, string? Key)[]> PropertyCache = new();
    private readonly YetkiAuthorizationOptions _options = options.Value;

    public string? ResolveUserName(HttpContext http)
    {
        if (http.User.Identity?.IsAuthenticated == true && !string.IsNullOrWhiteSpace(http.User.Identity.Name))
            return http.User.Identity.Name;
        if (_options.AllowUserHeaderForDemo)
        {
            var h = http.Request.Headers[_options.DemoUserHeader].ToString();
            if (!string.IsNullOrWhiteSpace(h)) return h.Trim();
        }
        return null;
    }

    public ContextBuildResult Build(ActionExecutingContext context)
    {
        var result = new ContextBuildResult();
        var http = context.HttpContext;

        // ---- Teknik context (otomatik) ----
        // Bilgi amaçlı; motor kararında kendi saatini kullanır.
        result.Values[AuthContextKey.CurrentTime] = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture);
        var ip = http.Connection.RemoteIpAddress;
        if (ip is not null) result.Values[AuthContextKey.IpAddress] = (ip.IsIPv4MappedToIPv6 ? ip.MapToIPv4() : ip).ToString();
        var channel = http.Request.Headers[_options.ChannelHeader].ToString();
        if (!string.IsNullOrWhiteSpace(channel)) result.Values[AuthContextKey.Channel] = channel.Trim();
        void Header(string header, string key)
        {
            var v = http.Request.Headers[header].ToString();
            if (!string.IsNullOrWhiteSpace(v)) result.Values[key] = v.Trim();
        }
        Header(_options.PlatformHeader, AuthContextKey.Platform);
        Header(_options.DeviceIdHeader, AuthContextKey.DeviceId);
        Header(_options.DeviceCompliantHeader, AuthContextKey.DeviceCompliant);

        // ---- İş context'i (semantik attribute) ----
        if (context.ActionDescriptor is ControllerActionDescriptor action)
        {
            foreach (var p in action.MethodInfo.GetParameters())
            {
                if (p.Name is null || !context.ActionArguments.TryGetValue(p.Name, out var arg) || arg is null) continue;
                var paramAttr = p.GetCustomAttribute<AuthContextAttribute>();
                if (paramAttr is not null) Add(result, paramAttr.Key, arg, $"param:{p.Name}");
                else Scan(arg, result, 0, p.Name, new HashSet<object>(ReferenceEqualityComparer.Instance));
            }
        }
        return result;
    }

    private void Scan(object obj, ContextBuildResult result, int depth, string path, HashSet<object> visited)
    {
        if (depth >= _options.MaxContextScanDepth || IsSimple(obj.GetType()) || !visited.Add(obj)) return;

        if (obj is IEnumerable enumerable and not string)
        {
            // Koleksiyonlarda context aranmaz: hangi elemanın değeri kullanılacağı belirsizdir.
            return;
        }

        foreach (var (prop, key) in GetProperties(obj.GetType()))
        {
            object? value;
            try { value = prop.GetValue(obj); } catch { continue; }
            if (value is null) continue;
            if (key is not null) Add(result, key, value, $"{path}.{prop.Name}");
            else if (!IsSimple(prop.PropertyType)) Scan(value, result, depth + 1, $"{path}.{prop.Name}", visited);
        }
    }

    private static void Add(ContextBuildResult result, string key, object value, string source)
    {
        var text = Format(value);
        if (text is null) return;
        if (result.Values.TryGetValue(key, out var existing) && existing is not null && !IsTechnical(key) && existing != text)
        {
            result.Conflicts.Add($"{key}: '{existing}' ve '{text}' ({source})");
            return;
        }
        result.Values[key] = text;
    }

    private static bool IsTechnical(string key) =>
        key is AuthContextKey.CurrentTime or AuthContextKey.IpAddress or AuthContextKey.Channel or AuthContextKey.Platform
            or AuthContextKey.DeviceId or AuthContextKey.DeviceCompliant;

    private static string? Format(object value) => value switch
    {
        string s => string.IsNullOrWhiteSpace(s) ? null : s.Trim(),
        DateTime d => d.ToUniversalTime().ToString("o", CultureInfo.InvariantCulture),
        DateTimeOffset d => d.UtcDateTime.ToString("o", CultureInfo.InvariantCulture),
        IFormattable f => f.ToString(null, CultureInfo.InvariantCulture),
        _ => value.ToString()
    };

    private static (PropertyInfo, string?)[] GetProperties(Type type) => PropertyCache.GetOrAdd(type, t =>
        t.GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(p => p.CanRead && p.GetIndexParameters().Length == 0)
            .Select(p => (p, p.GetCustomAttribute<AuthContextAttribute>()?.Key))
            .ToArray());

    private static bool IsSimple(Type t)
    {
        t = Nullable.GetUnderlyingType(t) ?? t;
        return t.IsPrimitive || t.IsEnum || t == typeof(string) || t == typeof(decimal) || t == typeof(DateTime)
               || t == typeof(DateTimeOffset) || t == typeof(Guid) || t == typeof(TimeSpan);
    }
}
