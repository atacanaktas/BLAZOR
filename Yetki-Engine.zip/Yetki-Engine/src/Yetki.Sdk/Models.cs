using System.Text.Json.Serialization;

namespace Yetki.Sdk;

public sealed class EvaluateSubject
{
    public string? UserName { get; set; }
}

public sealed class EvaluateResource
{
    public string? Type { get; set; }
    public string? Id { get; set; }
}

/// <summary>Motorun standart isteği: Subject + Permission (+Action) + Resource + Context.</summary>
public sealed class EvaluateRequest
{
    public EvaluateSubject Subject { get; set; } = new();
    public string Permission { get; set; } = default!;
    public string? Action { get; set; }
    public EvaluateResource? Resource { get; set; }
    public Dictionary<string, string?> Context { get; set; } = new();
    public string? Application { get; set; }
    public string? CorrelationId { get; set; }
}

/// <summary>Motorun karar cevabının SDK'nın ihtiyaç duyduğu kısmı.</summary>
public sealed class EvaluateResponse
{
    public Guid DecisionId { get; set; }
    /// <summary>Permit / Deny / NotApplicable / Indeterminate</summary>
    public string Decision { get; set; } = "Deny";
    /// <summary>Sadece Permit'te true. Enforcement bu alana göre yapılır.</summary>
    public bool IsAllowed { get; set; }
    public string ReasonCode { get; set; } = default!;
    public string HumanReadableReason { get; set; } = default!;
    public string? UserName { get; set; }
    public string Permission { get; set; } = default!;
    public string? DecidingPolicy { get; set; }
    public string? DecidingRule { get; set; }
    public List<string> FailedRules { get; set; } = new();
    public List<string> PermitRules { get; set; } = new();
    public List<string> MissingAttributes { get; set; } = new();

    [JsonIgnore]
    public bool IsSdkGenerated { get; init; }

    public static EvaluateResponse LocalDeny(string permission, string reasonCode, string reason) => new()
    {
        DecisionId = Guid.Empty, Decision = "Deny", IsAllowed = false, Permission = permission,
        ReasonCode = reasonCode, HumanReadableReason = reason, IsSdkGenerated = true
    };
}

public sealed class YetkiAuthorizationOptions
{
    /// <summary>Yetki Motoru adresi (ör. http://localhost:5100).</summary>
    public string EngineBaseUrl { get; set; } = "http://localhost:5100";

    /// <summary>Çağıran uygulama kodu (audit'te "kim sordu").</summary>
    public string ApplicationCode { get; set; } = "unknown-app";

    public TimeSpan Timeout { get; set; } = TimeSpan.FromSeconds(3);

    /// <summary>
    /// Kanal/platform/cihaz bilgisini taşıyan header'lar. Bu header'lara SADECE güvenilir gateway/platform değer yazmalıdır
    /// (istemciden geleni gateway ezmelidir). Prototipte doğrudan okunur.
    /// </summary>
    public string ChannelHeader { get; set; } = "X-Channel";
    public string PlatformHeader { get; set; } = "X-Platform";
    public string DeviceIdHeader { get; set; } = "X-Device-Id";
    public string DeviceCompliantHeader { get; set; } = "X-Device-Compliant";

    /// <summary>
    /// PROTOTİP: Kimlik doğrulama yoksa kullanıcı adı bu header'dan okunur. Üretimde MUTLAKA false olmalı;
    /// kullanıcı doğrulanmış token'dan (HttpContext.User) gelir.
    /// </summary>
    public bool AllowUserHeaderForDemo { get; set; }
    public string DemoUserHeader { get; set; } = "X-User";

    /// <summary>İş DTO'larında [AuthContext] aranacak maksimum iç içe derinlik.</summary>
    public int MaxContextScanDepth { get; set; } = 3;
}
