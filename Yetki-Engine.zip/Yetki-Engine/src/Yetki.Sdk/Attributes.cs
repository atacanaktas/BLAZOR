namespace Yetki.Sdk;

/// <summary>
/// İş (business) context türleri. Framework'ün kendisinin bilemediği değerler için DTO property'si bu türlerle işaretlenir.
/// Property adı önemsizdir (Amount / Tutar / TransactionAmount...). Enum adı motorun context anahtarıdır.
/// IP, CurrentTime, Channel, Platform, Device gibi değerler SDK tarafından otomatik toplanır; iş ekibinden İSTENMEZ.
/// </summary>
public enum AuthContextType
{
    TransactionAmount,
    Currency,
    CustomerId,
    AccountNo,
    BranchCode
}

/// <summary>Motorun tanıdığı environment anahtarları (SDK otomatik toplar). Motordaki AuthContextKeys ile aynı değerler.</summary>
public static class AuthContextKey
{
    public const string CurrentTime = "CurrentTime";
    public const string IpAddress = "IpAddress";
    public const string Channel = "Channel";
    public const string Platform = "Platform";
    public const string DeviceId = "DeviceId";
    public const string DeviceCompliant = "DeviceCompliant";

    public static string Of(AuthContextType type) => type.ToString();
}

/// <summary>
/// Endpoint'in gerektirdiği permission. Deklaratif: iş kodunda yetki if'i yazılmaz.
/// Birden fazla kullanılırsa HEPSİ Permit olmalıdır.
/// <code>[RequiresPermission("CASH_WITHDRAW")]</code>
/// </summary>
[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
public class RequiresPermissionAttribute(string permission) : Attribute
{
    public string Permission { get; } = permission;
    /// <summary>Opsiyonel işlem adı (audit / ileride action-bazlı policy). Boşsa permission kodu.</summary>
    public string? Action { get; init; }
    /// <summary>Opsiyonel kaynak tipi (ör. "account"); değer [AuthContext(AccountNo)] ile gelirse Resource = {account, TR12...}.</summary>
    public string? ResourceType { get; init; }
}

/// <summary>Geriye uyumluluk: eski isim. Yeni kodda <see cref="RequiresPermissionAttribute"/> kullanın.</summary>
[Obsolete("RequiresPermission kullanın.")]
[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
public sealed class RequirePermissionAttribute(string permission) : RequiresPermissionAttribute(permission);

/// <summary>
/// DTO property'sinin (veya action parametresinin) authorization context'teki SEMANTİK anlamı.
/// <code>[AuthContext(AuthContextType.TransactionAmount)] public decimal Tutar { get; set; }</code>
/// Domain'e özgü bir değer için özel anahtar da verilebilir: <c>[AuthContext("CreditScore")]</c>
/// </summary>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter, AllowMultiple = false)]
public sealed class AuthContextAttribute : Attribute
{
    public AuthContextAttribute(AuthContextType type) => Key = AuthContextKey.Of(type);
    public AuthContextAttribute(string customKey) => Key = customKey;

    public string Key { get; }
}
