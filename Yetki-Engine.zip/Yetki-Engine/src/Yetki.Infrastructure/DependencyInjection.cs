using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Yetki.Application;
using Yetki.Application.Abstractions;
using Yetki.Application.Events;
using Yetki.Application.Evaluation;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.PolicyEngine.Conditions;
using Yetki.Infrastructure.Outbox;
using Yetki.Infrastructure.Persistence;
using Yetki.Infrastructure.Services;

namespace Yetki.Infrastructure;

public static class DependencyInjection
{
    /// <summary>
    /// Persistence:Provider = "InMemory" (varsayılan, kurulum gerektirmez).
    /// SQL Server'a geçiş: Microsoft.EntityFrameworkCore.SqlServer paketi ekle, aşağıdaki "SqlServer" dalını aç,
    /// ConnectionStrings:Yetki tanımla, migration üret (dotnet ef migrations add Initial). Domain/servisler değişmez.
    /// </summary>
    public static IServiceCollection AddYetkiInfrastructure(this IServiceCollection services, IConfiguration config)
    {
        services.AddYetkiApplication();

        var provider = config["Persistence:Provider"] ?? "InMemory";
        services.AddDbContext<YetkiDbContext>(options =>
        {
            switch (provider)
            {
                case "InMemory":
                    options.UseInMemoryDatabase(config["Persistence:InMemoryDatabaseName"] ?? "YetkiDb")
                           .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning));
                    break;
                // case "SqlServer":
                //     options.UseSqlServer(config.GetConnectionString("Yetki"), sql => sql.EnableRetryOnFailure());
                //     break;
                default:
                    throw new InvalidOperationException($"Desteklenmeyen persistence provider: {provider}");
            }
        });
        services.AddScoped<IYetkiDbContext>(sp => sp.GetRequiredService<YetkiDbContext>());

        services.AddSingleton<IClock, SystemClock>();
        services.AddSingleton<IAuthorizationVersion, InProcessAuthorizationVersion>();
        // Request context provider Application katmanında ilk sırada kayıtlı; User entity ikinci kaynak.
        services.AddScoped<IAttributeValueProvider, UserEntityAttributeProvider>();
        services.Configure<AuthorizationEngineOptions>(o => config.GetSection("AuthorizationEngine").Bind(o));
        services.AddScoped<IProvisioningAdapter, DummyProvisioningAdapter>();
        services.AddScoped<IOutboxEventHandler, LoggingEventHandler>();
        services.AddScoped<DbSeeder>();

        services.AddSingleton<OutboxProcessor>();
        services.AddHostedService(sp => sp.GetRequiredService<OutboxProcessor>());
        return services;
    }

    /// <summary>RuleType kataloğunu senkronize eder ve demo verisini yükler.</summary>
    public static async Task InitializeYetkiDatabaseAsync(this IServiceProvider services, IConfiguration config)
    {
        using var scope = services.CreateScope();
        var sp = scope.ServiceProvider;
        var db = sp.GetRequiredService<YetkiDbContext>();
        await db.Database.EnsureCreatedAsync(); // SQL Server'da migration kullanılmalı (db.Database.MigrateAsync)

        await sp.GetRequiredService<ConditionTypeCatalogSynchronizer>().SyncAsync();

        if (config.GetValue("Seed:Enabled", true))
            await sp.GetRequiredService<DbSeeder>().SeedAsync(config.GetValue("Seed:SyntheticUserCount", 0));

        sp.GetRequiredService<ILoggerFactory>().CreateLogger("Yetki").LogInformation("Yetki veritabanı hazır ({Provider}).",
            config["Persistence:Provider"] ?? "InMemory");
    }
}
