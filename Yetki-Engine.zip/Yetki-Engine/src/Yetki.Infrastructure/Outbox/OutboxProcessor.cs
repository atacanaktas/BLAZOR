using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Yetki.Application.Abstractions;
using Yetki.Application.Events;
using Yetki.Domain.Common;

namespace Yetki.Infrastructure.Outbox;

/// <summary>
/// Outbox tüketicisi (polling). Prototipte API süreci içinde çalışır; ileride ayrı Provisioning Service'e
/// taşınabilir veya bir message broker'a (Kafka/RabbitMQ/Service Bus) publish eden relay'e dönüştürülebilir.
/// At-least-once: handler'lar idempotent yazılmalıdır (TODO: ProvisioningAction için idempotency key).
/// </summary>
public sealed class OutboxProcessor(IServiceScopeFactory scopes, ILogger<OutboxProcessor> logger) : BackgroundService
{
    private const int BatchSize = 50;
    private const int MaxAttempts = 5;
    private static readonly TimeSpan Interval = TimeSpan.FromSeconds(2);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await ProcessBatchAsync(stoppingToken);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogError(ex, "Outbox batch failed");
            }
            await Task.Delay(Interval, stoppingToken);
        }
    }

    public async Task<int> ProcessBatchAsync(CancellationToken ct)
    {
        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<IYetkiDbContext>();
        var handlers = scope.ServiceProvider.GetServices<IOutboxEventHandler>().ToList();
        var clock = scope.ServiceProvider.GetRequiredService<IClock>();

        var batch = await db.OutboxEvents
            .Where(e => e.Status == OutboxStatus.Pending)
            .OrderBy(e => e.OccurredAt)
            .Take(BatchSize)
            .ToListAsync(ct);

        foreach (var evt in batch)
        {
            evt.Attempts++;
            try
            {
                foreach (var h in handlers.Where(h => h.CanHandle(evt.EventType)))
                    await h.HandleAsync(evt, ct);
                evt.Status = OutboxStatus.Processed;
                evt.ProcessedAt = clock.UtcNow;
                evt.Error = null;
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogWarning(ex, "Outbox event {Id} ({Type}) failed, attempt {Attempt}", evt.Id, evt.EventType, evt.Attempts);
                evt.Error = ex.Message;
                if (evt.Attempts >= MaxAttempts) evt.Status = OutboxStatus.Failed;
            }
            await db.SaveChangesAsync(ct);
        }
        return batch.Count;
    }
}
