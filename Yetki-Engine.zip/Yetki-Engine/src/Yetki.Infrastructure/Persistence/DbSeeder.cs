using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Yetki.Domain.Common;
using Yetki.Domain.External;
using Yetki.Domain.Groups;
using Yetki.Domain.Identity;
using Yetki.Domain.Policies;
using Yetki.Domain.Rbac;
using Yetki.Domain.Sod;

namespace Yetki.Infrastructure.Persistence;

/// <summary>
/// Başlangıç demo verisi. Seed, iş kurallarını (SoD kontrolü vb.) BİLİNÇLİ OLARAK bypass eder:
/// mevcut sistemden "olduğu gibi" taşınan veriyi temsil eder. Bu sayede retrospektif SoD taraması
/// gerçekçi ihlaller bulur (emre.koc, deniz.yildiz).
/// </summary>
public sealed class DbSeeder(YetkiDbContext db, ILogger<DbSeeder> logger)
{
    private const string By = "seed";

    public async Task SeedAsync(int syntheticUserCount, CancellationToken ct = default)
    {
        if (await db.Users.AnyAsync(ct)) return;

        // ---------------- Organizasyon: 3 şube + 2 genel müdürlük birimi ----------------
        var s101 = Ou("101", "101 Kadıköy Şubesi", OrganizationUnitType.Branch);
        var s737 = Ou("737", "737 Ankara Kızılay Şubesi", OrganizationUnitType.Branch);
        var s1114 = Ou("1114", "1114 İzmir Alsancak Şubesi", OrganizationUnitType.Branch);
        var gm928 = Ou("928", "928 Genel Müdürlük / Krediler", OrganizationUnitType.HeadOfficeDepartment);
        var gm850 = Ou("850", "850 Genel Müdürlük / Operasyon ve Yetki Yönetimi", OrganizationUnitType.HeadOfficeDepartment);
        var branches = new[] { s101, s737, s1114 };
        db.OrganizationUnits.AddRange(s101, s737, s1114, gm928, gm850);

        // ---------------- Permission'lar ----------------
        var p = new Dictionary<string, Permission>();
        void P(string code, string name, string domain, string? desc = null) =>
            p[code] = new Permission { Code = code, Name = name, Domain = domain, Description = desc, CreatedBy = By };

        P("CUSTOMER_VIEW", "Müşteri görüntüleme", "MUSTERI");
        P("CUSTOMER_UPDATE", "Müşteri bilgisi güncelleme", "MUSTERI");
        P("TERM_DEPOSIT_VIEW", "Vadeli hesap görüntüleme", "VADELI");
        P("TERM_DEPOSIT_OPEN", "Vadeli hesap açma", "VADELI");
        P("TERM_DEPOSIT_UPDATE", "Vadeli hesap güncelleme", "VADELI");
        P("TERM_DEPOSIT_CLOSE", "Vadeli hesap kapatma", "VADELI", "Şube eşleşmesi ve mesai saati policy'si ile korunur.");
        P("VADA_MENU", "Vadeli hesap ana menüsü (mainframe)", "VADELI", "RACF tarafında VADA-* transaction yetkilerini gerektirir.");
        P("CASH_WITHDRAW", "Nakit çekme", "GISE", "Mesai, vezne kanalı, kullanıcı limiti policy'si ile korunur.");
        P("CASH_DEPOSIT", "Nakit yatırma", "GISE");
        P("CASH_DESK_OPEN", "Vezne açma/kapama", "GISE");
        P("EFT_SEND", "EFT gönderme", "ODEME");
        P("CREDIT_VIEW", "Kredi görüntüleme", "KREDI");
        P("CREDIT_CREATE", "Kredi başvurusu oluşturma", "KREDI");
        P("CREDIT_APPROVE", "Kredi onaylama", "KREDI", "CREDIT_CREATE ile aynı kişide bulunamaz (SoD).");
        P("CREDIT_LIMIT_UPDATE", "Kredi limiti güncelleme", "KREDI");
        P("REPORT_BRANCH_VIEW", "Şube raporları", "RAPOR");
        P("AUTH_ADMIN", "Yetki yönetimi", "YETKI");
        P("AUTH_APPROVE", "Yetki talebi onaylama", "YETKI");
        P("ANNOUNCEMENT_VIEW", "Duyurular", "GENEL");
        db.Permissions.AddRange(p.Values);

        // ---------------- Roller ----------------
        var r = new Dictionary<string, Role>();
        void R(string code, string name, string desc, params string[] perms)
        {
            var role = new Role { Code = code, Name = name, Description = desc, CreatedBy = By };
            foreach (var pc in perms) role.Permissions.Add(new RolePermission { Permission = p[pc], AssignedBy = By });
            r[code] = role;
        }
        // Şube rolleri: tüm şubelerde ORTAK (şubeye özel rol kopyası yok; şube bilgisi kullanıcının biriminden gelir)
        R("GISEAST", "Gişe Asistanı", "Şube ortak rolü — vezne destek", "CUSTOMER_VIEW", "CASH_DEPOSIT");
        R("GISEYTK", "Gişe Yetkilisi", "Şube ortak rolü — vezne işlemleri", "CUSTOMER_VIEW", "CASH_WITHDRAW", "CASH_DEPOSIT", "CASH_DESK_OPEN");
        R("BRYSLAST", "Bireysel Asistan", "Şube ortak rolü — bireysel bankacılık destek", "CUSTOMER_VIEW", "TERM_DEPOSIT_VIEW", "TERM_DEPOSIT_OPEN", "VADA_MENU");
        R("BRYSLYTK", "Bireysel Yetkili", "Şube ortak rolü — bireysel bankacılık", "CUSTOMER_VIEW", "CUSTOMER_UPDATE", "TERM_DEPOSIT_VIEW", "TERM_DEPOSIT_OPEN", "TERM_DEPOSIT_UPDATE", "TERM_DEPOSIT_CLOSE", "VADA_MENU", "EFT_SEND");
        R("TICRIAST", "Ticari Asistan", "Şube ortak rolü — ticari bankacılık destek", "CUSTOMER_VIEW", "CREDIT_VIEW", "CREDIT_CREATE");
        R("TICRIYTK", "Ticari Yetkili", "Şube ortak rolü — ticari bankacılık", "CUSTOMER_VIEW", "CUSTOMER_UPDATE", "CREDIT_VIEW", "CREDIT_CREATE", "EFT_SEND");
        R("SUBEMDR", "Şube Müdürü", "Şube ortak rolü — şube yönetimi ve kredi onayı", "CUSTOMER_VIEW", "CUSTOMER_UPDATE", "TERM_DEPOSIT_VIEW", "TERM_DEPOSIT_CLOSE", "CASH_WITHDRAW", "REPORT_BRANCH_VIEW", "CREDIT_VIEW", "CREDIT_APPROVE");

        // Genel müdürlük rolleri: birim başına GM{BİRİM}UZMYR / GM{BİRİM}UZM / GM{BİRİM}UZYTK
        R("GM928UZMYR", "GM 928 Krediler — Uzman Yardımcısı", "Kredi izleme", "CUSTOMER_VIEW", "CREDIT_VIEW");
        R("GM928UZM", "GM 928 Krediler — Uzman", "Kredi tahsis hazırlığı", "CUSTOMER_VIEW", "CREDIT_VIEW", "CREDIT_CREATE", "CREDIT_LIMIT_UPDATE");
        R("GM928UZYTK", "GM 928 Krediler — Uzman Yetkili", "Kredi onayı", "CUSTOMER_VIEW", "CREDIT_VIEW", "CREDIT_APPROVE", "CREDIT_LIMIT_UPDATE");
        R("GM850UZMYR", "GM 850 Operasyon — Uzman Yardımcısı", "Operasyon izleme", "CUSTOMER_VIEW", "REPORT_BRANCH_VIEW");
        R("GM850UZM", "GM 850 Operasyon — Uzman", "Ödeme operasyonu + yetki tanımlama", "CUSTOMER_VIEW", "EFT_SEND", "AUTH_ADMIN");
        R("GM850UZYTK", "GM 850 Operasyon — Uzman Yetkili", "Ödeme operasyonu + yetki onayı", "CUSTOMER_VIEW", "EFT_SEND", "AUTH_APPROVE");
        db.Roles.AddRange(r.Values);

        // ---------------- Kullanıcılar ----------------
        var u = new Dictionary<string, User>();
        void U(string userName, string fullName, string title, OrganizationUnit ou, decimal limit, string[] roles,
            bool onLeave = false, bool active = true, string? customerNo = null)
        {
            var user = new User
            {
                UserName = userName, FullName = fullName, Title = title, Email = $"{userName}@banka.local",
                CashWithdrawalLimit = limit, IsOnLeave = onLeave, IsActive = active, CustomerNo = customerNo, CreatedBy = By
            };
            user.OrganizationUnits.Add(new UserOrganizationUnit { OrganizationUnit = ou, IsPrimary = true, AssignedBy = By });
            foreach (var rc in roles) user.Roles.Add(new UserRole { Role = r[rc], AssignedBy = By });
            u[userName] = user;
        }
        // 101 Kadıköy
        U("fatma.aksoy", "Fatma Aksoy", "Şube Müdürü", s101, 300_000m, ["SUBEMDR"]);
        U("ahmet.yilmaz", "Ahmet Yılmaz", "Gişe Yetkilisi", s101, 50_000m, ["GISEYTK"], customerNo: "10001");
        U("deniz.yildiz", "Deniz Yıldız", "Gişe Yetkilisi", s101, 40_000m, ["GISEYTK"]);
        U("ayse.demir", "Ayşe Demir", "Bireysel Asistan", s101, 0m, ["BRYSLAST"]);
        U("hakan.celik", "Hakan Çelik", "Ticari Yetkili", s101, 0m, ["TICRIYTK"]);
        U("gizem.tas", "Gizem Taş", "Stajyer", s101, 0m, []);
        // 737 Kızılay
        U("can.ozturk", "Can Öztürk", "Şube Müdürü", s737, 250_000m, ["SUBEMDR"]);
        U("elif.sahin", "Elif Şahin", "Gişe Yetkilisi", s737, 30_000m, ["GISEYTK"], onLeave: true);
        U("seda.kurt", "Seda Kurt", "Gişe Asistanı", s737, 10_000m, ["GISEAST"]);
        U("burak.arslan", "Burak Arslan", "Bireysel Yetkili (Müdür Vekili)", s737, 0m, ["BRYSLYTK"]);
        // 1114 Alsancak
        U("ali.yurt", "Ali Yurt", "Şube Müdürü", s1114, 250_000m, ["SUBEMDR"]);
        U("mehmet.kaya", "Mehmet Kaya", "Ticari Asistan", s1114, 0m, ["TICRIAST"]);
        U("okan.demir", "Okan Demir", "Bireysel Yetkili", s1114, 0m, ["BRYSLYTK"]);
        U("murat.polat", "Murat Polat", "Eski Personel", s1114, 0m, ["GISEAST"], active: false);
        // 928 GM Krediler
        U("cem.bulut", "Cem Bulut", "Uzman Yardımcısı", gm928, 0m, ["GM928UZMYR"]);
        U("zeynep.celik", "Zeynep Çelik", "Uzman Yetkili", gm928, 0m, ["GM928UZYTK"]);
        // Legacy: SoD kuralından önce iki rol birlikte verilmiş -> tarama ihlal bulur
        U("emre.koc", "Emre Koç", "Kıdemli Uzman", gm928, 0m, ["GM928UZM", "GM928UZYTK"]);
        // 850 GM Operasyon ve Yetki Yönetimi
        U("ece.tan", "Ece Tan", "Uzman Yardımcısı", gm850, 0m, ["GM850UZMYR"]);
        U("selin.aydin", "Selin Aydın", "Uzman", gm850, 0m, ["GM850UZM"]);
        U("baris.oz", "Barış Öz", "Uzman Yetkili", gm850, 0m, ["GM850UZYTK"]);
        db.Users.AddRange(u.Values);

        // Legacy doğrudan permission (migration'dan gelen istisna)
        db.UserPermissions.Add(new UserPermission { User = u["deniz.yildiz"], Permission = p["EFT_SEND"], Reason = "Eski sistemden taşındı (LEGACY-4411)", AssignedBy = "migration" });

        // ---------------- Gruplar ----------------
        var tumPersonel = new Group { Code = "TUM_PERSONEL", Name = "Tüm Personel", Description = "Tüm birimlerdeki personel (birim kitlesi)", CreatedBy = By };
        foreach (var ou in new[] { s101, s737, s1114, gm928, gm850 })
            tumPersonel.OrganizationUnits.Add(new GroupOrganizationUnit { OrganizationUnit = ou, AssignedBy = By });
        tumPersonel.GrantedPermissions.Add(new GroupPermission { Permission = p["ANNOUNCEMENT_VIEW"], AssignedBy = By });

        // Doküman örneği: "Bütün Gişe Yetkilileri + 101 Şubede çalışan herkes + Can Öztürk"
        var kampanya = new Group { Code = "VADELI_KAMPANYA_EKIBI", Name = "Vadeli Kampanya Ekibi", Description = "Tüm gişe yetkilileri + 101 şube personeli + can.ozturk", CreatedBy = By };
        kampanya.Roles.Add(new GroupRole { Role = r["GISEYTK"], AssignedBy = By });
        kampanya.OrganizationUnits.Add(new GroupOrganizationUnit { OrganizationUnit = s101, AssignedBy = By });
        kampanya.Users.Add(new GroupUser { User = u["can.ozturk"], AssignedBy = By });
        kampanya.GrantedPermissions.Add(new GroupPermission { Permission = p["TERM_DEPOSIT_VIEW"], AssignedBy = By });

        var subeRapor = new Group { Code = "SUBE_101_RAPOR", Name = "101 Şube Rapor Erişimi", Description = "101 şubedeki herkese şube raporları", CreatedBy = By };
        subeRapor.OrganizationUnits.Add(new GroupOrganizationUnit { OrganizationUnit = s101, AssignedBy = By });
        subeRapor.GrantedPermissions.Add(new GroupPermission { Permission = p["REPORT_BRANCH_VIEW"], AssignedBy = By });

        // Rol grant eden grup: müdür vekilleri SUBEMDR rolünü grup üzerinden alır
        var vekalet = new Group { Code = "SUBEMDR_VEKALET", Name = "Şube Müdürü Vekilleri", Description = "Müdür izindeyken vekalet edenler (SUBEMDR rolünü grup üzerinden verir)", CreatedBy = By };
        vekalet.Users.Add(new GroupUser { User = u["burak.arslan"], AssignedBy = By });
        vekalet.GrantedRoles.Add(new GroupGrantedRole { Role = r["SUBEMDR"], AssignedBy = By });
        db.Groups.AddRange(tumPersonel, kampanya, subeRapor, vekalet);

        // ---------------- Policy'ler, Rule'lar, Condition'lar ----------------
        // Kalıp: DenyOverrides + kısıtlar Deny rule'ları olarak + en sonda temel Permit rule'u (ALWAYS).
        // Hiçbir Deny uygulanmazsa ve eksik değer yoksa → Permit. Kullanıcıya özgü değerler (limit) policy'de YOK; attribute'tan gelir.
        var ctypes = await db.ConditionTypes.ToDictionaryAsync(t => t.Code, ct);
        const string BusinessDays = "MON,TUE,WED,THU,FRI";
        const string BankNetwork = "10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,127.0.0.1/32,::1/128";

        RuleCondition Pred(string type, params (string K, string V)[] ps) => new()
        {
            Kind = ConditionKind.Predicate,
            ConditionTypeId = ctypes[type].Id,
            Parameters = ps.Select(x => new ConditionParameter { Key = x.K, Value = x.V }).ToList()
        };
        RuleCondition Group(ConditionKind kind, params RuleCondition[] children)
        {
            var n = new RuleCondition { Kind = kind };
            for (var i = 0; i < children.Length; i++) { children[i].Order = i; n.Children.Add(children[i]); }
            return n;
        }
        RuleCondition Not(RuleCondition child) => Group(ConditionKind.Not, child);
        RuleCondition Ref(SharedCondition sc) => new() { Kind = ConditionKind.Reference, ReferencedSharedCondition = sc };

        // ---- Ortak koşullar: tanımlar TEK yerde; rule'lar referans verir (kopya yok) ----
        SharedCondition Shared(string code, string name, string desc, ConditionScope scope, string? domain, RuleCondition condition)
        {
            var sc = new SharedCondition { Code = code, Name = name, Description = desc, Scope = scope, Domain = domain, CreatedBy = By };
            void Attach(RuleCondition c)
            {
                c.SharedCondition = sc;
                sc.Nodes.Add(c);
                foreach (var child in c.Children) Attach(child);
            }
            Attach(condition);
            db.SharedConditions.Add(sc);
            return sc;
        }
        var businessHours = Shared("BUSINESS_HOURS", "Mesai saati (09:00-18:00, hafta içi)", "Banka genel mesai saati", ConditionScope.Global, null,
            Pred("TIME_WINDOW", ("Start", "09:00"), ("End", "18:00"), ("Days", BusinessDays), ("TimeZone", "Europe/Istanbul")));
        var eftHours = Shared("EFT_HOURS", "EFT saatleri (08:30-20:00, Pzt-Cmt)", "EFT/ödeme sistemleri çalışma saatleri", ConditionScope.Global, null,
            Pred("TIME_WINDOW", ("Start", "08:30"), ("End", "20:00"), ("Days", "MON,TUE,WED,THU,FRI,SAT"), ("TimeZone", "Europe/Istanbul")));
        var bankNetwork = Shared("BANK_NETWORK", "Banka iç ağı", "Kurum içi IP blokları (tek yerden yönetilir)", ConditionScope.Global, null,
            Pred("IP_IN_RANGE", ("Cidrs", BankNetwork)));
        var remotePlatform = Shared("REMOTE_PLATFORM", "Uzak platform (mobil/internet)", "Şube dışı dijital kanallar", ConditionScope.Global, null,
            Pred("PLATFORM_IN", ("Platforms", "MOBILE,INTERNET")));
        var creditApprovalLimit = Shared("CREDIT_APPROVAL_LIMIT_EXCEEDED", "Kredi onay yetki limiti aşıldı", "Tek imza kredi onay üst tutarı (1.000.000)",
            ConditionScope.Domain, "KREDI", Pred("AMOUNT_GREATER_THAN", ("Threshold", "1000000")));

        RuleCondition OutsideHours(SharedCondition hours) => Not(Ref(hours));

        Rule Ru(int order, string code, string name, RuleEffect effect, string? reason, RuleCondition condition)
        {
            var rule = new Rule { Code = code, Name = name, Effect = effect, Order = order, ReasonCode = reason, CreatedBy = By };
            void Attach(RuleCondition c)
            {
                c.Rule = rule;
                rule.Conditions.Add(c);
                foreach (var child in c.Children) Attach(child);
            }
            Attach(condition);
            return rule;
        }
        Rule PermitBase() => Ru(1000, "PERMIT_WITHIN_CONSTRAINTS", "Kısıtlar sağlanıyorsa izin ver", RuleEffect.Permit, "PERMIT", Pred("ALWAYS"));
        Rule DenyOutsideNetwork(int order) => Ru(order, "DENY_OUTSIDE_BANK_NETWORK", "Banka ağı dışındaysa reddet", RuleEffect.Deny,
            "OUTSIDE_BANK_NETWORK", Not(Ref(bankNetwork)));
        Rule DenyOnLeave(int order) => Ru(order, "DENY_USER_ON_LEAVE", "Kullanıcı izindeyse reddet", RuleEffect.Deny, "USER_ON_LEAVE", Pred("USER_ON_LEAVE"));

        Policy Pol(string code, string name, string domain, string desc, Rule[] policyRules, params string[] permCodes)
        {
            var pol = new Policy { Code = code, Name = name, Domain = domain, Description = desc, CombiningAlgorithm = CombiningAlgorithm.DenyOverrides, CreatedBy = By };
            foreach (var r in policyRules) pol.Rules.Add(r);
            foreach (var pc in permCodes) pol.Permissions.Add(new PermissionPolicy { Permission = p[pc], AssignedBy = By });
            return pol;
        }

        db.Policies.AddRange(
            Pol("CASH_WITHDRAWAL_POLICY", "Nakit Çekim Policy", "GISE", "Mesai, banka ağı, vezne kanalı, kullanıcı limiti, izin, kendi hesabı",
            [
                Ru(10, "DENY_OUTSIDE_BUSINESS_HOURS", "Mesai dışındaysa reddet", RuleEffect.Deny, "OUTSIDE_BUSINESS_HOURS", OutsideHours(businessHours)),
                DenyOutsideNetwork(20),
                Ru(30, "DENY_NON_CASH_DESK_CHANNEL", "Vezne kanalı dışındaysa reddet", RuleEffect.Deny, "CHANNEL_NOT_ALLOWED",
                    Not(Pred("CHANNEL_IN", ("Channels", "CASH_DESK")))),
                Ru(40, "CASH_LIMIT_EXCEEDED", "İşlem tutarı kullanıcı limitini aşıyorsa reddet", RuleEffect.Deny, "AMOUNT_EXCEEDS_USER_LIMIT",
                    Pred("AMOUNT_EXCEEDS_SUBJECT_LIMIT", ("AmountAttribute", "TransactionAmount"), ("LimitAttribute", "CashWithdrawalLimit"))),
                DenyOnLeave(50),
                Ru(60, "DENY_OWN_CUSTOMER_TRANSACTION", "Personel kendi hesabında işlem yapamaz", RuleEffect.Deny, "OWN_CUSTOMER_TRANSACTION",
                    Pred("CUSTOMER_IS_SELF")),
                PermitBase()
            ], "CASH_WITHDRAW"),
            Pol("CREDIT_APPROVAL_POLICY", "Kredi Onay Policy", "KREDI", "Mesai, banka ağı, onay üst tutarı",
            [
                Ru(10, "DENY_OUTSIDE_BUSINESS_HOURS", "Mesai dışındaysa reddet", RuleEffect.Deny, "OUTSIDE_BUSINESS_HOURS", OutsideHours(businessHours)),
                DenyOutsideNetwork(20),
                Ru(30, "CREDIT_AMOUNT_ABOVE_APPROVAL_LIMIT", "Tutar 1.000.000 üzerindeyse reddet (komite onayı gerekir)", RuleEffect.Deny,
                    "AMOUNT_ABOVE_APPROVAL_LIMIT", Ref(creditApprovalLimit)),
                PermitBase()
            ], "CREDIT_APPROVE"),
            Pol("EFT_POLICY", "EFT Policy", "ODEME", "Uzatılmış saat, banka ağı, izin; mobil/internetten yüksek tutar yasağı (AND örneği)",
            [
                Ru(10, "DENY_OUTSIDE_EFT_HOURS", "EFT saatleri (08:30-20:00, Pzt-Cmt) dışındaysa reddet", RuleEffect.Deny, "OUTSIDE_EFT_HOURS",
                    OutsideHours(eftHours)),
                DenyOutsideNetwork(20),
                DenyOnLeave(30),
                Ru(40, "DENY_HIGH_AMOUNT_FROM_REMOTE_PLATFORM", "Mobil/internetten 50.000 üzeri EFT'yi reddet", RuleEffect.Deny, "REMOTE_PLATFORM_AMOUNT_LIMIT",
                    Group(ConditionKind.AllOf,
                        Ref(remotePlatform),
                        Pred("AMOUNT_GREATER_THAN", ("Threshold", "50000")))),
                PermitBase()
            ], "EFT_SEND"),
            Pol("TERM_DEPOSIT_CLOSE_POLICY", "Vadeli Kapatma Policy", "VADELI", "Kendi şubesi + mesai",
            [
                Ru(10, "DENY_OTHER_BRANCH", "İşlem şubesi kullanıcının birimi değilse reddet", RuleEffect.Deny, "BRANCH_MISMATCH",
                    Not(Pred("BRANCH_IS_USER_UNIT"))),
                Ru(20, "DENY_OUTSIDE_BUSINESS_HOURS", "Mesai dışındaysa reddet", RuleEffect.Deny, "OUTSIDE_BUSINESS_HOURS", OutsideHours(businessHours)),
                PermitBase()
            ], "TERM_DEPOSIT_CLOSE"));

        // SoD üyeleri id ile referans verir -> önce permission id'leri oluşsun
        await db.SaveChangesAsync(ct);

        // ---------------- SoD ----------------
        db.SodRules.AddRange(
            Sod("SOD_CREDIT_CREATE_APPROVE", "Kredi oluşturma / onaylama ayrımı", "Aynı kişi krediyi hem oluşturup hem onaylayamaz.",
                Severity.Critical, SodEnforcement.Block, (SodMemberType.Permission, p["CREDIT_CREATE"]), (SodMemberType.Permission, p["CREDIT_APPROVE"])),
            Sod("SOD_AUTH_ADMIN_APPROVE", "Yetki tanımlama / onaylama ayrımı", "Yetkiyi tanımlayan onaylayamaz.",
                Severity.High, SodEnforcement.Block, (SodMemberType.Permission, p["AUTH_ADMIN"]), (SodMemberType.Permission, p["AUTH_APPROVE"])),
            Sod("SOD_CASHDESK_EFT", "Vezne / EFT ayrımı", "Vezne sorumlusu EFT göndermemeli (uyarı seviyesinde).",
                Severity.Medium, SodEnforcement.Warn, (SodMemberType.Permission, p["CASH_DESK_OPEN"]), (SodMemberType.Permission, p["EFT_SEND"])));

        // ---------------- External systems ----------------
        var racf = new ExternalSystem { Code = "RACF", Name = "Mainframe RACF", Description = "z/OS RACF - CICS transaction yetkileri", CreatedBy = By };
        var ldap = new ExternalSystem { Code = "LDAP", Name = "Kurumsal LDAP", Description = "Ödeme sistemleri erişim grupları", CreatedBy = By };
        ExternalPermission Ext(ExternalSystem s, string code, string name)
        {
            var e = new ExternalPermission { ExternalSystem = s, Code = code, Name = name, CreatedBy = By };
            db.ExternalPermissions.Add(e);
            return e;
        }
        var vadaB0 = Ext(racf, "VADA-B0", "Vadeli hesap sorgu transaction");
        var vadaX = Ext(racf, "VADA-X", "Vadeli hesap işlem transaction");
        var vadaK1 = Ext(racf, "VADA-K1", "Vadeli hesap kapama transaction");
        var krdGir = Ext(racf, "KRD-GIR", "Kredi giriş transaction");
        var krdOny = Ext(racf, "KRD-ONY", "Kredi onay transaction");
        var gsNkt = Ext(racf, "GSE-NKT", "Gişe nakit transaction");
        var eftGrp = Ext(ldap, "CN=EFT_USERS,OU=Payments", "EFT kullanıcıları grubu");
        db.ExternalSystems.AddRange(racf, ldap);

        void Map(string perm, ExternalPermission ext, string? note = null) =>
            db.PermissionExternalMappings.Add(new PermissionExternalMapping { Permission = p[perm], ExternalPermission = ext, Note = note, AssignedBy = By });
        Map("VADA_MENU", vadaB0, "Vadeli ekip ile doğrulandı");
        Map("VADA_MENU", vadaX, "Vadeli ekip ile doğrulandı");
        Map("TERM_DEPOSIT_CLOSE", vadaK1);
        Map("CREDIT_CREATE", krdGir);
        Map("CREDIT_APPROVE", krdOny);
        Map("CASH_WITHDRAW", gsNkt);
        Map("EFT_SEND", eftGrp);

        await db.SaveChangesAsync(ct);

        if (syntheticUserCount > 0)
            await SeedSyntheticUsersAsync(syntheticUserCount, branches, [r["GISEAST"], r["GISEYTK"], r["BRYSLAST"], r["BRYSLYTK"], r["TICRIAST"], r["TICRIYTK"]], ct);

        logger.LogInformation("Seed tamamlandı: {Users} kullanıcı, {Perms} permission, {Roles} rol.",
            await db.Users.CountAsync(ct), p.Count, r.Count);
    }

    /// <summary>Login storm / performans testleri için sentetik kullanıcılar (appsettings: Seed:SyntheticUserCount).</summary>
    private async Task SeedSyntheticUsersAsync(int count, OrganizationUnit[] ous, Role[] roles, CancellationToken ct)
    {
        var rnd = new Random(42);
        for (var i = 1; i <= count; i++)
        {
            var user = new User
            {
                UserName = $"test.user{i:00000}", FullName = $"Test Kullanıcı {i}", Title = "Sentetik",
                CashWithdrawalLimit = rnd.Next(1, 20) * 5_000m, CreatedBy = By
            };
            user.OrganizationUnits.Add(new UserOrganizationUnit { OrganizationUnitId = ous[rnd.Next(ous.Length)].Id, IsPrimary = true, AssignedBy = By });
            user.Roles.Add(new UserRole { RoleId = roles[rnd.Next(roles.Length)].Id, AssignedBy = By });
            db.Users.Add(user);
            if (i % 2000 == 0) { await db.SaveChangesAsync(ct); db.ChangeTracker.Clear(); }
        }
        await db.SaveChangesAsync(ct);
        db.ChangeTracker.Clear();
    }

    private static OrganizationUnit Ou(string code, string name, OrganizationUnitType type, OrganizationUnit? parent = null) =>
        new() { Code = code, Name = name, Type = type, Parent = parent, CreatedBy = By };

    private static SodRule Sod(string code, string name, string desc, Severity sev, SodEnforcement enf, params (SodMemberType Type, Entity Target)[] members)
    {
        var rule = new SodRule { Code = code, Name = name, Description = desc, Severity = sev, Enforcement = enf, CreatedBy = By };
        foreach (var (type, target) in members)
            rule.Members.Add(new SodRuleMember { MemberType = type, MemberId = target.Id });
        return rule;
    }
}
