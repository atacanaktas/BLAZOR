using Microsoft.EntityFrameworkCore;
using Yetki.Application.Abstractions;
using Yetki.Domain.Audit;
using Yetki.Domain.Common;
using Yetki.Domain.Events;
using Yetki.Domain.External;
using Yetki.Domain.Groups;
using Yetki.Domain.Identity;
using Yetki.Domain.Policies;
using Yetki.Domain.Rbac;
using Yetki.Domain.Sod;

namespace Yetki.Infrastructure.Persistence;

/// <summary>
/// Tek DbContext. Model konfigürasyonu SQL Server hedeflenerek yazılmıştır (anahtarlar, unique index'ler,
/// composite index'ler, uzunluklar, decimal precision, delete davranışları). InMemory provider bunların
/// çoğunu yok sayar ama SQL Server'a geçişte migration doğrudan bu modelden üretilir.
/// </summary>
public class YetkiDbContext(DbContextOptions<YetkiDbContext> options, IClock clock, ICurrentActor actor, IAuthorizationVersion version)
    : DbContext(options), IYetkiDbContext
{
    public DbSet<User> Users => Set<User>();
    public DbSet<OrganizationUnit> OrganizationUnits => Set<OrganizationUnit>();
    public DbSet<UserOrganizationUnit> UserOrganizationUnits => Set<UserOrganizationUnit>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<UserPermission> UserPermissions => Set<UserPermission>();
    public DbSet<Group> Groups => Set<Group>();
    public DbSet<GroupUser> GroupUsers => Set<GroupUser>();
    public DbSet<GroupRole> GroupRoles => Set<GroupRole>();
    public DbSet<GroupOrganizationUnit> GroupOrganizationUnits => Set<GroupOrganizationUnit>();
    public DbSet<GroupPermission> GroupPermissions => Set<GroupPermission>();
    public DbSet<GroupGrantedRole> GroupGrantedRoles => Set<GroupGrantedRole>();
    public DbSet<Policy> Policies => Set<Policy>();
    public DbSet<ConditionType> ConditionTypes => Set<ConditionType>();
    public DbSet<Rule> Rules => Set<Rule>();
    public DbSet<RuleCondition> RuleConditions => Set<RuleCondition>();
    public DbSet<ConditionParameter> ConditionParameters => Set<ConditionParameter>();
    public DbSet<SharedCondition> SharedConditions => Set<SharedCondition>();
    public DbSet<PermissionPolicy> PermissionPolicies => Set<PermissionPolicy>();
    public DbSet<SodRule> SodRules => Set<SodRule>();
    public DbSet<SodRuleMember> SodRuleMembers => Set<SodRuleMember>();
    public DbSet<SodViolation> SodViolations => Set<SodViolation>();
    public DbSet<ExternalSystem> ExternalSystems => Set<ExternalSystem>();
    public DbSet<ExternalPermission> ExternalPermissions => Set<ExternalPermission>();
    public DbSet<PermissionExternalMapping> PermissionExternalMappings => Set<PermissionExternalMapping>();
    public DbSet<OutboxEvent> OutboxEvents => Set<OutboxEvent>();
    public DbSet<ProvisioningAction> ProvisioningActions => Set<ProvisioningAction>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    /// <summary>Bu tiplerdeki değişiklikler effective permission / karar sonucunu etkilemez; versiyon artırmaz.</summary>
    private static readonly HashSet<Type> NonAuthorizationTypes =
    [
        typeof(AuditLog), typeof(OutboxEvent), typeof(ProvisioningAction), typeof(SodViolation),
        typeof(ExternalSystem), typeof(ExternalPermission), typeof(PermissionExternalMapping)
    ];

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        ApplyAuditFields();
        var bump = ChangeTracker.Entries().Any(e =>
            e.State is EntityState.Added or EntityState.Modified or EntityState.Deleted &&
            !NonAuthorizationTypes.Contains(e.Entity.GetType()));
        var result = await base.SaveChangesAsync(cancellationToken);
        if (bump) version.Bump();
        return result;
    }

    private void ApplyAuditFields()
    {
        var now = clock.UtcNow;
        foreach (var e in ChangeTracker.Entries())
        {
            if (e.Entity is AuditableEntity a)
            {
                if (e.State == EntityState.Added)
                {
                    if (a.CreatedAt == default) a.CreatedAt = now;
                    if (string.IsNullOrEmpty(a.CreatedBy) || a.CreatedBy == "system") a.CreatedBy = actor.Name;
                }
                else if (e.State == EntityState.Modified)
                {
                    a.UpdatedAt = now;
                    a.UpdatedBy = actor.Name;
                }
            }
            if (e.Entity is IAssignment asg && e.State == EntityState.Added)
            {
                if (asg.AssignedAt == default) asg.AssignedAt = now;
                if (string.IsNullOrEmpty(asg.AssignedBy) || asg.AssignedBy == "system") asg.AssignedBy = actor.Name;
            }
        }
    }

    protected override void OnModelCreating(ModelBuilder b)
    {
        // ---------------- Identity ----------------
        b.Entity<User>(e =>
        {
            e.ToTable("Users");
            e.Property(x => x.UserName).HasMaxLength(64).IsRequired();
            e.HasIndex(x => x.UserName).IsUnique();
            e.Property(x => x.FullName).HasMaxLength(128).IsRequired();
            e.Property(x => x.Email).HasMaxLength(128);
            e.Property(x => x.Title).HasMaxLength(128);
            e.Property(x => x.CustomerNo).HasMaxLength(32);
            e.Property(x => x.CashWithdrawalLimit).HasPrecision(18, 2);
            AuditCols(e);
        });
        b.Entity<OrganizationUnit>(e =>
        {
            e.ToTable("OrganizationUnits");
            e.Property(x => x.Code).HasMaxLength(32).IsRequired();
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.HasOne(x => x.Parent).WithMany().HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            AuditCols(e);
        });
        b.Entity<UserOrganizationUnit>(e =>
        {
            e.ToTable("UserOrganizationUnits");
            e.HasKey(x => new { x.UserId, x.OrganizationUnitId });
            e.HasIndex(x => x.OrganizationUnitId); // "bu birimdeki herkes" (grup kitlesi)
            e.HasOne(x => x.User).WithMany(u => u.OrganizationUnits).HasForeignKey(x => x.UserId);
            e.HasOne(x => x.OrganizationUnit).WithMany().HasForeignKey(x => x.OrganizationUnitId);
            AssignCols(e);
        });

        // ---------------- RBAC ----------------
        b.Entity<Permission>(e =>
        {
            e.ToTable("Permissions");
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.Property(x => x.Domain).HasMaxLength(32);
            AuditCols(e);
        });
        b.Entity<Role>(e =>
        {
            e.ToTable("Roles");
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            AuditCols(e);
        });
        b.Entity<RolePermission>(e =>
        {
            e.ToTable("RolePermissions");
            e.HasKey(x => new { x.RoleId, x.PermissionId });
            e.HasIndex(x => x.PermissionId); // "bu permission hangi rollerde?"
            e.HasOne(x => x.Role).WithMany(r => r.Permissions).HasForeignKey(x => x.RoleId);
            e.HasOne(x => x.Permission).WithMany(p => p.Roles).HasForeignKey(x => x.PermissionId);
            AssignCols(e);
        });
        b.Entity<UserRole>(e =>
        {
            e.ToTable("UserRoles");
            e.HasKey(x => new { x.UserId, x.RoleId });
            e.HasIndex(x => x.RoleId); // "bu role sahip herkes"
            e.HasOne(x => x.User).WithMany(u => u.Roles).HasForeignKey(x => x.UserId);
            e.HasOne(x => x.Role).WithMany().HasForeignKey(x => x.RoleId);
            AssignCols(e);
        });
        b.Entity<UserPermission>(e =>
        {
            e.ToTable("UserPermissions");
            e.HasKey(x => new { x.UserId, x.PermissionId });
            e.HasIndex(x => x.PermissionId);
            e.Property(x => x.Reason).HasMaxLength(256);
            e.HasOne(x => x.User).WithMany(u => u.DirectPermissions).HasForeignKey(x => x.UserId);
            e.HasOne(x => x.Permission).WithMany().HasForeignKey(x => x.PermissionId);
            AssignCols(e);
        });

        // ---------------- Groups ----------------
        b.Entity<Group>(e =>
        {
            e.ToTable("Groups");
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            AuditCols(e);
        });
        b.Entity<GroupUser>(e =>
        {
            e.ToTable("GroupUsers");
            e.HasKey(x => new { x.GroupId, x.UserId });
            e.HasIndex(x => x.UserId);
            e.HasOne(x => x.Group).WithMany(g => g.Users).HasForeignKey(x => x.GroupId);
            e.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId);
            AssignCols(e);
        });
        b.Entity<GroupRole>(e =>
        {
            e.ToTable("GroupRoles");
            e.HasKey(x => new { x.GroupId, x.RoleId });
            e.HasIndex(x => x.RoleId);
            e.HasOne(x => x.Group).WithMany(g => g.Roles).HasForeignKey(x => x.GroupId);
            e.HasOne(x => x.Role).WithMany().HasForeignKey(x => x.RoleId);
            AssignCols(e);
        });
        b.Entity<GroupOrganizationUnit>(e =>
        {
            e.ToTable("GroupOrganizationUnits");
            e.HasKey(x => new { x.GroupId, x.OrganizationUnitId });
            e.HasIndex(x => x.OrganizationUnitId);
            e.HasOne(x => x.Group).WithMany(g => g.OrganizationUnits).HasForeignKey(x => x.GroupId);
            e.HasOne(x => x.OrganizationUnit).WithMany().HasForeignKey(x => x.OrganizationUnitId);
            AssignCols(e);
        });
        b.Entity<GroupPermission>(e =>
        {
            e.ToTable("GroupPermissions");
            e.HasKey(x => new { x.GroupId, x.PermissionId });
            e.HasIndex(x => x.PermissionId);
            e.HasOne(x => x.Group).WithMany(g => g.GrantedPermissions).HasForeignKey(x => x.GroupId);
            e.HasOne(x => x.Permission).WithMany().HasForeignKey(x => x.PermissionId);
            AssignCols(e);
        });
        b.Entity<GroupGrantedRole>(e =>
        {
            e.ToTable("GroupGrantedRoles");
            e.HasKey(x => new { x.GroupId, x.RoleId });
            e.HasIndex(x => x.RoleId);
            e.HasOne(x => x.Group).WithMany(g => g.GrantedRoles).HasForeignKey(x => x.GroupId);
            e.HasOne(x => x.Role).WithMany().HasForeignKey(x => x.RoleId);
            AssignCols(e);
        });

        // ---------------- Policy engine ----------------
        b.Entity<Policy>(e =>
        {
            e.ToTable("Policies");
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.Property(x => x.Domain).HasMaxLength(32);
            e.Property(x => x.CombiningAlgorithm).HasConversion<string>().HasMaxLength(32);
            e.Property(x => x.Version).IsConcurrencyToken(); // SQL Server'da iyimser eşzamanlılık
            AuditCols(e);
        });
        b.Entity<Rule>(e =>
        {
            e.ToTable("Rules");
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.HasIndex(x => new { x.PolicyId, x.Code }).IsUnique();
            e.HasIndex(x => new { x.PolicyId, x.Order });
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.Property(x => x.Description).HasMaxLength(512);
            e.Property(x => x.Effect).HasConversion<string>().HasMaxLength(16);
            e.Property(x => x.ReasonCode).HasMaxLength(64);
            e.HasOne(x => x.Policy).WithMany(p => p.Rules).HasForeignKey(x => x.PolicyId).OnDelete(DeleteBehavior.Cascade);
            AuditCols(e);
        });
        b.Entity<RuleCondition>(e =>
        {
            e.ToTable("RuleConditions", t => t.HasCheckConstraint("CK_RuleConditions_Owner",
                "([RuleId] IS NOT NULL AND [SharedConditionId] IS NULL) OR ([RuleId] IS NULL AND [SharedConditionId] IS NOT NULL)"));
            e.Property(x => x.Kind).HasConversion<string>().HasMaxLength(16);
            e.HasIndex(x => new { x.RuleId, x.ParentId, x.Order });
            e.HasIndex(x => new { x.SharedConditionId, x.ParentId, x.Order });
            e.HasIndex(x => x.ReferencedSharedConditionId); // "bu ortak koşul nerede kullanılıyor?"
            e.HasOne(x => x.Rule).WithMany(r => r.Conditions).HasForeignKey(x => x.RuleId).OnDelete(DeleteBehavior.Cascade);
            // Ortak koşul sahipliği ve referansı: Restrict (silme servis tarafında; kullanımdaki ortak koşul silinemez)
            e.HasOne(x => x.SharedCondition).WithMany(s => s.Nodes).HasForeignKey(x => x.SharedConditionId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ReferencedSharedCondition).WithMany().HasForeignKey(x => x.ReferencedSharedConditionId).OnDelete(DeleteBehavior.Restrict);
            // Self-reference: SQL Server çoklu cascade yolunu kabul etmez → Restrict; silme servis tarafında yapılır.
            e.HasOne(x => x.Parent).WithMany(x => x.Children).HasForeignKey(x => x.ParentId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ConditionType).WithMany().HasForeignKey(x => x.ConditionTypeId).OnDelete(DeleteBehavior.Restrict);
        });
        b.Entity<SharedCondition>(e =>
        {
            e.ToTable("SharedConditions");
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.Property(x => x.Description).HasMaxLength(512);
            e.Property(x => x.Scope).HasConversion<string>().HasMaxLength(16);
            e.Property(x => x.Domain).HasMaxLength(32);
            e.Property(x => x.Version).IsConcurrencyToken();
            AuditCols(e);
        });
        b.Entity<ConditionParameter>(e =>
        {
            e.ToTable("ConditionParameters");
            e.Property(x => x.Key).HasMaxLength(64).IsRequired();
            e.Property(x => x.Value).HasMaxLength(1024).IsRequired();
            e.HasIndex(x => new { x.ConditionId, x.Key }).IsUnique();
            e.HasOne(x => x.Condition).WithMany(c => c.Parameters).HasForeignKey(x => x.ConditionId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<ConditionType>(e =>
        {
            e.ToTable("ConditionTypes");
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.Property(x => x.Description).HasMaxLength(512);
            e.Property(x => x.DefaultScope).HasConversion<string>().HasMaxLength(16);
            e.Property(x => x.RequiredAttributes).HasMaxLength(512);
        });
        b.Entity<PermissionPolicy>(e =>
        {
            e.ToTable("PermissionPolicies");
            e.HasKey(x => new { x.PermissionId, x.PolicyId });
            e.HasIndex(x => x.PolicyId);
            e.HasOne(x => x.Permission).WithMany(p => p.Policies).HasForeignKey(x => x.PermissionId);
            e.HasOne(x => x.Policy).WithMany(p => p.Permissions).HasForeignKey(x => x.PolicyId);
            AssignCols(e);
        });

        // ---------------- SoD ----------------
        b.Entity<SodRule>(e =>
        {
            e.ToTable("SodRules");
            e.Property(x => x.Code).HasMaxLength(64).IsRequired();
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            e.Property(x => x.Severity).HasConversion<string>().HasMaxLength(16);
            e.Property(x => x.Enforcement).HasConversion<string>().HasMaxLength(16);
            AuditCols(e);
        });
        b.Entity<SodRuleMember>(e =>
        {
            e.ToTable("SodRuleMembers");
            e.Property(x => x.MemberType).HasConversion<string>().HasMaxLength(16);
            e.HasIndex(x => new { x.SodRuleId, x.MemberType, x.MemberId }).IsUnique();
            e.HasOne(x => x.SodRule).WithMany(r => r.Members).HasForeignKey(x => x.SodRuleId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<SodViolation>(e =>
        {
            e.ToTable("SodViolations");
            e.Property(x => x.Status).HasConversion<string>().HasMaxLength(16);
            e.Property(x => x.DetectedBy).HasConversion<string>().HasMaxLength(32);
            e.Property(x => x.Details).HasMaxLength(4000);
            e.Property(x => x.ClosedBy).HasMaxLength(64);
            e.Property(x => x.Note).HasMaxLength(1024);
            e.HasIndex(x => new { x.UserId, x.SodRuleId, x.Status });
            e.HasOne(x => x.SodRule).WithMany().HasForeignKey(x => x.SodRuleId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Restrict);
        });

        // ---------------- External ----------------
        b.Entity<ExternalSystem>(e =>
        {
            e.ToTable("ExternalSystems");
            e.Property(x => x.Code).HasMaxLength(32).IsRequired();
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128).IsRequired();
            AuditCols(e);
        });
        b.Entity<ExternalPermission>(e =>
        {
            e.ToTable("ExternalPermissions");
            e.Property(x => x.Code).HasMaxLength(128).IsRequired();
            e.HasIndex(x => new { x.ExternalSystemId, x.Code }).IsUnique();
            e.Property(x => x.Name).HasMaxLength(128);
            e.HasOne(x => x.ExternalSystem).WithMany(s => s.Permissions).HasForeignKey(x => x.ExternalSystemId).OnDelete(DeleteBehavior.Restrict);
            AuditCols(e);
        });
        b.Entity<PermissionExternalMapping>(e =>
        {
            e.ToTable("PermissionExternalMappings");
            e.HasKey(x => new { x.PermissionId, x.ExternalPermissionId });
            e.HasIndex(x => x.ExternalPermissionId);
            e.Property(x => x.Note).HasMaxLength(256);
            e.HasOne(x => x.Permission).WithMany().HasForeignKey(x => x.PermissionId);
            e.HasOne(x => x.ExternalPermission).WithMany().HasForeignKey(x => x.ExternalPermissionId);
            AssignCols(e);
        });

        // ---------------- Events / Audit ----------------
        b.Entity<OutboxEvent>(e =>
        {
            e.ToTable("OutboxEvents");
            e.HasKey(x => x.Id);
            e.Property(x => x.EventType).HasMaxLength(64).IsRequired();
            e.Property(x => x.AggregateType).HasMaxLength(64);
            e.Property(x => x.AggregateId).HasMaxLength(64);
            e.Property(x => x.Actor).HasMaxLength(64);
            e.Property(x => x.Status).HasConversion<string>().HasMaxLength(16);
            e.HasIndex(x => new { x.Status, x.OccurredAt }); // outbox polling
        });
        b.Entity<ProvisioningAction>(e =>
        {
            e.ToTable("ProvisioningActions");
            e.Property(x => x.UserName).HasMaxLength(64);
            e.Property(x => x.PermissionCode).HasMaxLength(64);
            e.Property(x => x.ExternalSystemCode).HasMaxLength(32);
            e.Property(x => x.ExternalPermissionCode).HasMaxLength(128);
            e.Property(x => x.ActionType).HasConversion<string>().HasMaxLength(16);
            e.Property(x => x.Status).HasConversion<string>().HasMaxLength(16);
            e.Property(x => x.AdapterName).HasMaxLength(64);
            e.Property(x => x.ResultMessage).HasMaxLength(1024);
            e.HasIndex(x => new { x.Status, x.CreatedAt });
            e.HasIndex(x => x.UserId);
        });
        b.Entity<AuditLog>(e =>
        {
            e.ToTable("AuditLogs");
            e.HasKey(x => x.Id);
            e.Property(x => x.Category).HasConversion<string>().HasMaxLength(32);
            e.Property(x => x.Actor).HasMaxLength(64);
            e.Property(x => x.Action).HasMaxLength(64).IsRequired();
            e.Property(x => x.EntityType).HasMaxLength(64);
            e.Property(x => x.EntityId).HasMaxLength(64);
            e.Property(x => x.SubjectUserName).HasMaxLength(64);
            e.Property(x => x.PermissionCode).HasMaxLength(64);
            e.Property(x => x.Resource).HasMaxLength(256);
            e.Property(x => x.Decision).HasMaxLength(16);
            e.Property(x => x.ReasonCode).HasMaxLength(64);
            e.Property(x => x.Summary).HasMaxLength(1024);
            e.Property(x => x.CorrelationId).HasMaxLength(64);
            e.HasIndex(x => x.Timestamp);
            e.HasIndex(x => new { x.SubjectUserName, x.Timestamp });
            e.HasIndex(x => new { x.Category, x.Timestamp });
        });
    }

    private static void AuditCols<T>(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<T> e) where T : AuditableEntity
    {
        e.Property(x => x.CreatedBy).HasMaxLength(64);
        e.Property(x => x.UpdatedBy).HasMaxLength(64);
    }

    private static void AssignCols<T>(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<T> e) where T : class, IAssignment
    {
        e.Property(x => x.AssignedBy).HasMaxLength(64);
    }
}
