using System.Globalization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Yetki.Application.Abstractions;
using Yetki.Application.Context;
using Yetki.Application.PolicyEngine.Attributes;
using Yetki.Application.Events;
using Yetki.Domain.Common;
using Yetki.Domain.Events;

namespace Yetki.Infrastructure.Services;

public sealed class SystemClock : IClock
{
    public DateTime UtcNow => DateTime.UtcNow;
}

/// <summary>Tek instance için süreç içi versiyon sayacı. Çok instance'ta Redis/DB tabanlı olmalı (TODO).</summary>
public sealed class InProcessAuthorizationVersion : IAuthorizationVersion
{
    private long _value = 1;
    public long Current => Interlocked.Read(ref _value);
    public void Bump() => Interlocked.Increment(ref _value);
}

/// <summary>Arka plan işleri ve seed için sabit aktör.</summary>
public sealed class SystemActor(string name = "system") : ICurrentActor
{
    public string Name { get; } = name;
}

/// <summary>
/// PROTOTİP subject attribute kaynağı: değerleri User entity'sinden okur (Subject.CashWithdrawalLimit, IsOnLeave, ...).
/// Üretimde bu provider'ın önüne/yerine HR, limit yönetimi, core banking provider'ları eklenir
/// (IAttributeValueProvider). Policy engine ve condition handler'lar değişmez.
/// Değer "bilinen boş" ise AttributeValue(null) döner; kullanıcı yoksa veya attribute bilinmiyorsa null (→ Indeterminate).
/// </summary>
public sealed class UserEntityAttributeProvider(IYetkiDbContext db) : IAttributeValueProvider
{
    private static readonly HashSet<string> Supported = new(StringComparer.OrdinalIgnoreCase)
    {
        SubjectAttributes.CashWithdrawalLimit, SubjectAttributes.IsOnLeave, SubjectAttributes.CustomerId,
        SubjectAttributes.Title, SubjectAttributes.OrgUnitCodes
    };

    public string Name => "UserEntity";

    public bool CanResolve(AttributeId id) => id.Category == AttributeCategory.Subject && Supported.Contains(id.Name);

    public async ValueTask<AttributeValue?> ResolveAsync(AttributeId id, AttributeResolutionScope scope, CancellationToken ct)
    {
        var userId = scope.Subject.UserId;
        if (id.Name.Equals(SubjectAttributes.OrgUnitCodes, StringComparison.OrdinalIgnoreCase))
        {
            var codes = await db.UserOrganizationUnits.AsNoTracking().Where(x => x.UserId == userId)
                .OrderByDescending(x => x.IsPrimary).Select(x => x.OrganizationUnit.Code).ToListAsync(ct);
            return new AttributeValue(string.Join(",", codes), Name);
        }

        var u = await db.Users.AsNoTracking().Where(x => x.Id == userId)
            .Select(x => new { x.CashWithdrawalLimit, x.IsOnLeave, x.CustomerNo, x.Title }).FirstOrDefaultAsync(ct);
        if (u is null) return null;

        string? value = id.Name switch
        {
            SubjectAttributes.CashWithdrawalLimit => u.CashWithdrawalLimit.ToString(CultureInfo.InvariantCulture),
            SubjectAttributes.IsOnLeave => u.IsOnLeave.ToString(),
            SubjectAttributes.CustomerId => u.CustomerNo,
            _ => u.Title
        };
        return new AttributeValue(value, Name);
    }
}

/// <summary>
/// Dummy provisioning adaptörü: gerçek RACF/LDAP çağrısı yapmaz, yapılacak komutu mesaj olarak üretir.
/// SystemCode "*" = özel adaptörü olmayan tüm sistemler için fallback.
/// </summary>
public sealed class DummyProvisioningAdapter(ILogger<DummyProvisioningAdapter> logger) : IProvisioningAdapter
{
    public string SystemCode => "*";
    public string Name => "DummyProvisioningAdapter";

    public Task<ProvisioningOutcome> ExecuteAsync(ProvisioningRequest r, CancellationToken ct)
    {
        var command = r.ExternalSystemCode.ToUpperInvariant() switch
        {
            "RACF" => r.ActionType == ProvisioningActionType.Grant
                ? $"PERMIT {r.ExternalPermissionCode} CLASS(TCICSTRN) ID({r.UserName.ToUpperInvariant()}) ACCESS(READ)"
                : $"PERMIT {r.ExternalPermissionCode} CLASS(TCICSTRN) ID({r.UserName.ToUpperInvariant()}) DELETE",
            "LDAP" => r.ActionType == ProvisioningActionType.Grant
                ? $"ADD member uid={r.UserName} TO {r.ExternalPermissionCode}"
                : $"REMOVE member uid={r.UserName} FROM {r.ExternalPermissionCode}",
            _ => $"{r.ActionType} {r.ExternalPermissionCode} -> {r.UserName}"
        };
        logger.LogInformation("[DUMMY PROVISIONING] {System}: {Command} (sebep: {Permission})", r.ExternalSystemCode, command, r.PermissionCode);
        return Task.FromResult(new ProvisioningOutcome(true, $"SİMÜLE EDİLDİ: {command}"));
    }
}

/// <summary>Tüm event'leri loglar (ilk aşama consumer örneği). E-posta/bildirim handler'ları aynı arayüzle eklenebilir.</summary>
public sealed class LoggingEventHandler(ILogger<LoggingEventHandler> logger) : IOutboxEventHandler
{
    public bool CanHandle(string eventType) => true;

    public Task HandleAsync(OutboxEvent evt, CancellationToken ct)
    {
        logger.LogInformation("[EVENT] {Type} {AggregateType}:{AggregateId} by {Actor} payload={Payload}",
            evt.EventType, evt.AggregateType, evt.AggregateId, evt.Actor, evt.PayloadJson);
        return Task.CompletedTask;
    }
}
