namespace BankingDemo.WinForms.Models;

public class AppUser
{
    public string Id { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public List<string> RoleIds { get; set; } = new();
    public string CompanyScope { get; set; } = string.Empty;

    public string PrimaryRoleId => RoleIds.FirstOrDefault() ?? string.Empty;
}
