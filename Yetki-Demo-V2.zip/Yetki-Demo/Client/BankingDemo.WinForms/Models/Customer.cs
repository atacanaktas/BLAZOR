namespace BankingDemo.WinForms.Models;

public class Customer
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Segment { get; set; } = string.Empty;
    public string RiskLevel { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public bool PhoneMasked { get; set; }
    public string? NationalId { get; set; }
    public bool IdentityMasked { get; set; }

    public string PhoneDisplay => PhoneMasked ? "********" : Phone ?? string.Empty;
    public string NationalIdDisplay => IdentityMasked ? "********" : NationalId ?? string.Empty;
}
