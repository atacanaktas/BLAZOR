namespace BankingDemo.WinForms.Authorization;

/// <summary>
/// The WinForms app's only gateway to authorization decisions. No code outside this interface
/// (and its HTTP implementation) is allowed to reason about roles or permissions - screens only
/// ever ask "what can I show?" and render whatever comes back.
/// </summary>
public interface IAuthorizationClient
{
    Task<AuthorizationResponse> CheckAsync(AuthorizationRequest request, CancellationToken cancellationToken = default);

    Task<BatchAuthorizationResponse> CheckBatchAsync(BatchAuthorizationRequest request, CancellationToken cancellationToken = default);

    Task<ScreenCapabilitiesResponse?> GetCapabilitiesAsync(string screen, string userId, string? resourceId, CancellationToken cancellationToken = default);

    Task<List<AuditLogEntry>> GetAuditLogAsync(CancellationToken cancellationToken = default);
}
