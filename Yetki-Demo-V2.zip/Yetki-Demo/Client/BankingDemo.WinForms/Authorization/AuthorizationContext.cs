using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Authorization;

/// <summary>
/// Holds the logged-in mock user for the lifetime of the WinForms session. There is no real
/// authentication: LoginForm sets CurrentUser from the user the operator picked in the combo
/// box, and every subsequent screen reads it to know whose capabilities to ask for.
/// </summary>
public interface ICurrentUserContext
{
    AppUser? CurrentUser { get; }
    void SignIn(AppUser user);
    void SignOut();
}

public class CurrentUserContext : ICurrentUserContext
{
    public AppUser? CurrentUser { get; private set; }

    public void SignIn(AppUser user) => CurrentUser = user;

    public void SignOut() => CurrentUser = null;
}

public static class RoleDisplayNames
{
    private static readonly Dictionary<string, string> Map = new()
    {
        ["role-sube-muduru"] = "Şube Müdürü",
        ["role-gise-yetkilisi"] = "Gişe Yetkilisi",
        ["role-gise-asistani"] = "Gişe Asistanı",
        ["role-bms-yetkilisi"] = "Bireysel Müşteri Yetkilisi",
        ["role-bms-asistani"] = "Bireysel Müşteri Asistanı"
    };

    public static string For(string roleId) => Map.TryGetValue(roleId, out var name) ? name : roleId;
}
