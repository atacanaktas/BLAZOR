namespace BankingDemo.WinForms.Authorization;

/// <summary>
/// Mirrors the Authorization Service's JSON contracts. Kept intentionally separate from the
/// service's own models: the two projects are independent and only agree on the wire format.
/// </summary>
public class AuthorizationRequest
{
    public string UserId { get; set; } = string.Empty;
    public string Permission { get; set; } = string.Empty;
    public string? ResourceType { get; set; }
    public string? ResourceId { get; set; }
    public Dictionary<string, object>? Context { get; set; }
}

public class AuthorizationStepResult
{
    public string Step { get; set; } = string.Empty;
    public string Result { get; set; } = string.Empty;
    public string? Detail { get; set; }
}

public class AuthorizationResponse
{
    public bool Allowed { get; set; }
    public string Decision { get; set; } = string.Empty;
    public string Permission { get; set; } = string.Empty;
    public string? Resource { get; set; }
    public List<string> Reasons { get; set; } = new();
    public string? RoleUsed { get; set; }
    public string? PolicyName { get; set; }
    public List<AuthorizationStepResult> Steps { get; set; } = new();
}

public class AuthorizationCheckItem
{
    public string Permission { get; set; } = string.Empty;
    public string? ResourceType { get; set; }
    public string? ResourceId { get; set; }
}

public class BatchAuthorizationRequest
{
    public string UserId { get; set; } = string.Empty;
    public List<AuthorizationCheckItem> Checks { get; set; } = new();
}

public class BatchAuthorizationResultItem
{
    public string Permission { get; set; } = string.Empty;
    public string? ResourceId { get; set; }
    public bool Allowed { get; set; }
    public string Decision { get; set; } = string.Empty;
}

public class BatchAuthorizationResponse
{
    public List<BatchAuthorizationResultItem> Results { get; set; } = new();
}

public class ScreenCapabilitiesResponse
{
    public string Screen { get; set; } = string.Empty;
    public Dictionary<string, bool> Capabilities { get; set; } = new();
}

public class AuditLogEntry
{
    public DateTime Timestamp { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Permission { get; set; } = string.Empty;
    public string? Resource { get; set; }
    public string Decision { get; set; } = string.Empty;
    public string? PolicyName { get; set; }
    public List<string> Reasons { get; set; } = new();
}
