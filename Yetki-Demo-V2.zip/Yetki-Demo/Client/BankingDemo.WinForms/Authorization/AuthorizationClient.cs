using System.Net.Http.Json;
using System.Web;
using BankingDemo.WinForms.Common;
using Microsoft.Extensions.Logging;

namespace BankingDemo.WinForms.Authorization;

public class AuthorizationClient : IAuthorizationClient
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<AuthorizationClient> _logger;

    public AuthorizationClient(HttpClient httpClient, ILogger<AuthorizationClient> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
    }

    public async Task<AuthorizationResponse> CheckAsync(AuthorizationRequest request, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Checking authorization: {Permission} on {ResourceId}", request.Permission, request.ResourceId);

        using var response = await _httpClient.PostAsJsonAsync("api/authorization/check", request, JsonOptions.Default, cancellationToken);
        response.EnsureSuccessStatusCode();

        var result = await response.Content.ReadFromJsonAsync<AuthorizationResponse>(JsonOptions.Default, cancellationToken);
        return result ?? new AuthorizationResponse { Allowed = false, Decision = "DENY", Reasons = { "Empty response from authorization service" } };
    }

    public async Task<BatchAuthorizationResponse> CheckBatchAsync(BatchAuthorizationRequest request, CancellationToken cancellationToken = default)
    {
        using var response = await _httpClient.PostAsJsonAsync("api/authorization/check-batch", request, JsonOptions.Default, cancellationToken);
        response.EnsureSuccessStatusCode();

        var result = await response.Content.ReadFromJsonAsync<BatchAuthorizationResponse>(JsonOptions.Default, cancellationToken);
        return result ?? new BatchAuthorizationResponse();
    }

    public async Task<ScreenCapabilitiesResponse?> GetCapabilitiesAsync(string screen, string userId, string? resourceId, CancellationToken cancellationToken = default)
    {
        var query = HttpUtility.ParseQueryString(string.Empty);
        query["userId"] = userId;
        if (!string.IsNullOrEmpty(resourceId))
        {
            query["resourceId"] = resourceId;
        }

        using var response = await _httpClient.GetAsync($"api/screens/{screen}/capabilities?{query}", cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        return await response.Content.ReadFromJsonAsync<ScreenCapabilitiesResponse>(JsonOptions.Default, cancellationToken);
    }

    public async Task<List<AuditLogEntry>> GetAuditLogAsync(CancellationToken cancellationToken = default)
    {
        var result = await _httpClient.GetFromJsonAsync<List<AuditLogEntry>>("api/authorization/audit", JsonOptions.Default, cancellationToken);
        return result ?? new List<AuditLogEntry>();
    }
}
