namespace BankingDemo.WinForms.Authorization;

public interface ICapabilityService
{
    Task<Dictionary<string, bool>> GetCapabilitiesAsync(string screen, string? resourceId = null, CancellationToken cancellationToken = default);
}

/// <summary>
/// Thin convenience wrapper over IAuthorizationClient for the common "give me this screen's
/// capability map for the current user" call, so forms don't have to know the current user's id.
/// </summary>
public class CapabilityService : ICapabilityService
{
    private readonly IAuthorizationClient _client;
    private readonly ICurrentUserContext _currentUser;

    public CapabilityService(IAuthorizationClient client, ICurrentUserContext currentUser)
    {
        _client = client;
        _currentUser = currentUser;
    }

    public async Task<Dictionary<string, bool>> GetCapabilitiesAsync(string screen, string? resourceId = null, CancellationToken cancellationToken = default)
    {
        if (_currentUser.CurrentUser is null)
        {
            return new Dictionary<string, bool>();
        }

        var response = await _client.GetCapabilitiesAsync(screen, _currentUser.CurrentUser.Id, resourceId, cancellationToken);
        return response?.Capabilities ?? new Dictionary<string, bool>();
    }
}
