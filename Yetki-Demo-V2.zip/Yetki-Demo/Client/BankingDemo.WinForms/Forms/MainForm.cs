using BankingDemo.WinForms.Authorization;
using BankingDemo.WinForms.Forms.Panels;

namespace BankingDemo.WinForms.Forms;

/// <summary>
/// Hosts the left navigation and swaps a single content area between screens. Navigation items
/// are shown or hidden based on capabilities returned by the Authorization Service - MainForm
/// never checks "if role == X"; it only asks "can this user see this screen?".
/// </summary>
public class MainForm : Form
{
    private readonly IServiceProvider _services;
    private readonly ICurrentUserContext _currentUser;
    private readonly ICapabilityService _capabilityService;

    private readonly FlowLayoutPanel _navPanel = new();
    private readonly Panel _contentPanel = new();
    private readonly Label _userLabel = new();

    /// <summary>ViewCapability null means the item is always shown - reserved for meta/testing
    /// screens (Test Senaryoları) that are not themselves a business capability.</summary>
    private record NavItem(string Key, string Label, string Screen, string? ViewCapability, Type PanelType);

    private readonly List<NavItem> _navItems = new()
    {
        new("dashboard", "Dashboard", "dashboard", "view_dashboard", typeof(DashboardPanel)),
        new("customers", "Müşteriler", "customers", "view_customer_list", typeof(CustomerPanel)),
        new("accounts", "Vadesiz Hesaplar", "accounts", "view_account_list", typeof(AccountPanel)),
        new("deposit-accounts", "Vadeli Hesaplar", "deposit-accounts", "view_deposit_accounts", typeof(DepositAccountPanel)),
        new("payments", "Ödemeler", "payments", "view_payments", typeof(PaymentPanel)),
        new("transfers", "Transferler", "transfers", "view_transfers", typeof(TransferPanel)),
        new("reports", "Raporlar", "reports", "view_reports", typeof(ReportsPanel)),
        new("audit", "Denetim", "audit", "view_audit_log", typeof(AuditPanel)),
        new("administration", "Yönetim", "administration", "view_roles", typeof(AdministrationPanel)),
        new("test-scenarios", "Test Senaryoları", "", null, typeof(TestScenariosPanel))
    };

    public MainForm(IServiceProvider services, ICurrentUserContext currentUser, ICapabilityService capabilityService)
    {
        _services = services;
        _currentUser = currentUser;
        _capabilityService = capabilityService;

        BuildUi();
        Shown += async (_, _) => await BuildNavigationAsync();
    }

    private void BuildUi()
    {
        Text = "Banking Authorization Demo";
        ClientSize = new Size(1100, 720);
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(900, 600);

        var user = _currentUser.CurrentUser;

        var header = new Panel { Dock = DockStyle.Top, Height = 56, BackColor = Color.FromArgb(24, 46, 78) };
        _userLabel.Text = user is null
            ? string.Empty
            : $"{user.DisplayName}   |   Role: {RoleDisplayNames.For(user.PrimaryRoleId)}   |   Company Scope: {user.CompanyScope}";
        _userLabel.ForeColor = Color.White;
        _userLabel.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        _userLabel.Dock = DockStyle.Fill;
        _userLabel.TextAlign = ContentAlignment.MiddleLeft;
        _userLabel.Padding = new Padding(16, 0, 0, 0);

        var titleLabel = new Label
        {
            Text = "Banking Authorization Demo",
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 12, FontStyle.Bold),
            Dock = DockStyle.Left,
            Width = 320,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(16, 0, 0, 0)
        };
        header.Controls.Add(_userLabel);
        header.Controls.Add(titleLabel);

        _navPanel.Dock = DockStyle.Left;
        _navPanel.Width = 200;
        _navPanel.FlowDirection = FlowDirection.TopDown;
        _navPanel.WrapContents = false;
        _navPanel.BackColor = Color.FromArgb(240, 242, 245);
        _navPanel.Padding = new Padding(8);

        _contentPanel.Dock = DockStyle.Fill;
        _contentPanel.BackColor = Color.White;
        _contentPanel.Padding = new Padding(16);

        Controls.Add(_contentPanel);
        Controls.Add(_navPanel);
        Controls.Add(header);
    }

    private async Task BuildNavigationAsync()
    {
        _navPanel.Controls.Clear();
        var userId = _currentUser.CurrentUser?.Id;
        if (userId is null)
        {
            return;
        }

        foreach (var item in _navItems)
        {
            bool visible;
            if (item.ViewCapability is null)
            {
                visible = true; // meta/testing screen - not gated by a business capability
            }
            else
            {
                var capabilities = await _capabilityService.GetCapabilitiesAsync(item.Screen);
                visible = capabilities.TryGetValue(item.ViewCapability, out var allowed) && allowed;
            }

            if (!visible)
            {
                continue;
            }

            var button = new Button
            {
                Text = item.Label,
                Width = 176,
                Height = 40,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(12, 0, 0, 0),
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(0, 2, 0, 2)
            };
            button.FlatAppearance.BorderSize = 0;
            button.Click += async (_, _) => await NavigateToAsync(item);
            _navPanel.Controls.Add(button);
        }

        if (_navItems.Count > 0)
        {
            await NavigateToAsync(_navItems[0]);
        }
    }

    private async Task NavigateToAsync(NavItem item)
    {
        _contentPanel.Controls.Clear();

        if (_services.GetService(item.PanelType) is not Control panel)
        {
            return;
        }

        panel.Dock = DockStyle.Fill;
        _contentPanel.Controls.Add(panel);

        if (panel is IScreenPanel screenPanel)
        {
            await screenPanel.ActivateAsync();
        }
    }
}
