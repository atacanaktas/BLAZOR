namespace BankingDemo.WinForms.Forms.Panels;

public class NewPaymentDialog : Form
{
    private readonly TextBox _companyBox = new();
    private readonly NumericUpDown _amountBox = new();
    private readonly ComboBox _currencyBox = new();

    public string CompanyId => _companyBox.Text.Trim();
    public decimal Amount => _amountBox.Value;
    public string Currency => _currencyBox.Text;

    public NewPaymentDialog(string defaultCompanyId)
    {
        Text = "New Payment";
        ClientSize = new Size(340, 220);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;

        var companyLabel = new Label { Text = "Company:", Location = new Point(16, 16), AutoSize = true };
        _companyBox.Location = new Point(16, 36);
        _companyBox.Width = 300;
        _companyBox.Text = defaultCompanyId;

        var amountLabel = new Label { Text = "Amount:", Location = new Point(16, 66), AutoSize = true };
        _amountBox.Location = new Point(16, 86);
        _amountBox.Width = 300;
        _amountBox.Maximum = 100_000_000;
        _amountBox.DecimalPlaces = 2;
        _amountBox.Value = 100000;

        var currencyLabel = new Label { Text = "Currency:", Location = new Point(16, 116), AutoSize = true };
        _currencyBox.Location = new Point(16, 136);
        _currencyBox.Width = 300;
        _currencyBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _currencyBox.Items.AddRange(new object[] { "TRY", "USD", "EUR" });
        _currencyBox.SelectedIndex = 0;

        var okButton = new Button { Text = "Create", DialogResult = DialogResult.OK, Location = new Point(16, 170), Width = 300 };

        Controls.AddRange(new Control[] { companyLabel, _companyBox, amountLabel, _amountBox, currencyLabel, _currencyBox, okButton });
        AcceptButton = okButton;
    }
}
