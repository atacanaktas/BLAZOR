using BankingDemo.WinForms.Authorization;
using BankingDemo.WinForms.Models;
using BankingDemo.WinForms.Services;

namespace BankingDemo.WinForms.Forms.Panels;

/// <summary>
/// Account list + detail in one screen. The detail buttons (transactions / transfer /
/// statement) are enabled purely from the "account-detail" screen's capability map for the
/// selected account - this is the VIP-masking and scope demo surface from the spec.
/// </summary>
public class AccountPanel : UserControl, IScreenPanel
{
    private readonly ICurrentUserContext _currentUser;
    private readonly IAccountService _accountService;
    private readonly ITransferService _transferService;
    private readonly IAuthorizationClient _authorizationClient;
    private readonly ICapabilityService _capabilityService;

    private readonly DataGridView _accountGrid = new();
    private readonly DataGridView _transactionGrid = new();
    private readonly Label _detailLabel = new();
    private readonly Button _openAccountButton = new() { Text = "Hesap Aç" };
    private readonly Button _viewTransactionsButton = new() { Text = "View Transactions" };
    private readonly Button _newTransferButton = new() { Text = "New Transfer" };
    private readonly Button _downloadStatementButton = new() { Text = "Download Statement" };
    private readonly Button _closeAccountButton = new() { Text = "Hesap Kapat" };
    private readonly Label _statusLabel = new();

    private List<Account> _accounts = new();

    public AccountPanel(
        ICurrentUserContext currentUser,
        IAccountService accountService,
        ITransferService transferService,
        IAuthorizationClient authorizationClient,
        ICapabilityService capabilityService)
    {
        _currentUser = currentUser;
        _accountService = accountService;
        _transferService = transferService;
        _authorizationClient = authorizationClient;
        _capabilityService = capabilityService;
        BuildUi();
    }

    private void BuildUi()
    {
        var title = new Label { Text = "Accounts", Font = new Font("Segoe UI", 16, FontStyle.Bold), Dock = DockStyle.Top, Height = 40 };
        _statusLabel.Dock = DockStyle.Top;
        _statusLabel.Height = 22;
        _statusLabel.ForeColor = Color.DimGray;

        var topButtonPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40 };
        _openAccountButton.Width = 120;
        _openAccountButton.Height = 30;
        _openAccountButton.Enabled = false;
        _openAccountButton.Click += async (_, _) => await OnOpenAccountAsync();
        topButtonPanel.Controls.Add(_openAccountButton);

        _accountGrid.Dock = DockStyle.Top;
        _accountGrid.Height = 260;
        _accountGrid.ReadOnly = true;
        _accountGrid.AllowUserToAddRows = false;
        _accountGrid.AllowUserToDeleteRows = false;
        _accountGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _accountGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _accountGrid.MultiSelect = false;
        _accountGrid.Columns.Add("Id", "Account No");
        _accountGrid.Columns.Add("CustomerName", "Customer");
        _accountGrid.Columns.Add("Currency", "Currency");
        _accountGrid.Columns.Add("Balance", "Balance");
        _accountGrid.Columns.Add("Status", "Status");
        _accountGrid.SelectionChanged += async (_, _) => await OnAccountSelectedAsync();

        var detailPanel = new Panel { Dock = DockStyle.Top, Height = 44 };
        _detailLabel.Text = "Select an account to see detail actions.";
        _detailLabel.AutoSize = true;
        _detailLabel.Location = new Point(0, 4);
        _detailLabel.Font = new Font("Segoe UI", 9, FontStyle.Italic);

        var buttonPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 44, FlowDirection = FlowDirection.LeftToRight };
        _viewTransactionsButton.Click += async (_, _) => await OnViewTransactionsAsync();
        _newTransferButton.Click += async (_, _) => await OnNewTransferAsync();
        _downloadStatementButton.Click += async (_, _) => await OnDownloadStatementAsync();
        _closeAccountButton.Click += async (_, _) => await OnCloseAccountAsync();
        foreach (var b in new[] { _viewTransactionsButton, _newTransferButton, _downloadStatementButton, _closeAccountButton })
        {
            b.Width = 150;
            b.Height = 32;
            b.Enabled = false;
        }
        buttonPanel.Controls.AddRange(new Control[] { _viewTransactionsButton, _newTransferButton, _downloadStatementButton, _closeAccountButton });

        _transactionGrid.Dock = DockStyle.Fill;
        _transactionGrid.ReadOnly = true;
        _transactionGrid.AllowUserToAddRows = false;
        _transactionGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _transactionGrid.Columns.Add("Id", "Transaction");
        _transactionGrid.Columns.Add("Direction", "Direction");
        _transactionGrid.Columns.Add("Amount", "Amount");
        _transactionGrid.Columns.Add("Currency", "Currency");
        _transactionGrid.Columns.Add("Date", "Date");

        Controls.Add(_transactionGrid);
        Controls.Add(detailPanel);
        detailPanel.Controls.Add(_detailLabel);
        Controls.Add(buttonPanel);
        Controls.Add(_accountGrid);
        Controls.Add(topButtonPanel);
        Controls.Add(_statusLabel);
        Controls.Add(title);
    }

    public async Task ActivateAsync()
    {
        var user = _currentUser.CurrentUser;
        if (user is null)
        {
            return;
        }

        _statusLabel.Text = "Loading accounts...";
        _accountGrid.Rows.Clear();
        _transactionGrid.Rows.Clear();

        try
        {
            _accounts = await _accountService.GetAllAsync(user.Id);
        }
        catch (Exception ex)
        {
            _statusLabel.Text = $"Failed to load accounts: {ex.Message}";
            return;
        }

        foreach (var account in _accounts)
        {
            _accountGrid.Rows.Add(account.Id, account.CustomerName, account.Currency, account.BalanceDisplay, account.Status);
        }

        _statusLabel.Text = $"{_accounts.Count} account(s) within your company scope.";
        if (_accountGrid.Rows.Count > 0)
        {
            _accountGrid.Rows[0].Selected = true;
        }

        var listCapabilities = await _capabilityService.GetCapabilitiesAsync("accounts");
        _openAccountButton.Enabled = listCapabilities.GetValueOrDefault("open_account");
    }

    private Account? SelectedAccount()
    {
        if (_accountGrid.SelectedRows.Count == 0)
        {
            return null;
        }
        var id = _accountGrid.SelectedRows[0].Cells["Id"].Value?.ToString();
        return _accounts.FirstOrDefault(a => a.Id == id);
    }

    private async Task OnAccountSelectedAsync()
    {
        var account = SelectedAccount();
        _transactionGrid.Rows.Clear();
        if (account is null)
        {
            _detailLabel.Text = "Select an account to see detail actions.";
            SetButtonsEnabled(false, false, false, false);
            return;
        }

        var capabilities = await _capabilityService.GetCapabilitiesAsync("account-detail", account.Id);
        _detailLabel.Text = $"Account {account.Id} — Balance: {account.BalanceDisplay}";
        SetButtonsEnabled(
            capabilities.GetValueOrDefault("view_transactions"),
            capabilities.GetValueOrDefault("create_transfer"),
            capabilities.GetValueOrDefault("download_statement"),
            capabilities.GetValueOrDefault("close_account"));
    }

    private void SetButtonsEnabled(bool viewTransactions, bool newTransfer, bool downloadStatement, bool closeAccount)
    {
        _viewTransactionsButton.Enabled = viewTransactions;
        _newTransferButton.Enabled = newTransfer;
        _downloadStatementButton.Enabled = downloadStatement;
        _closeAccountButton.Enabled = closeAccount;
    }

    private async Task OnViewTransactionsAsync()
    {
        var account = SelectedAccount();
        var user = _currentUser.CurrentUser;
        if (account is null || user is null)
        {
            return;
        }

        var response = await _authorizationClient.CheckAsync(new AuthorizationRequest
        {
            UserId = user.Id,
            Permission = "transaction.read",
            ResourceType = "account",
            ResourceId = account.Id
        });
        AuthorizationDebugForm.ShowDecision(this.FindForm()!, "View Transactions", user.DisplayName, response);

        if (!response.Allowed)
        {
            return;
        }

        _transactionGrid.Rows.Clear();
        var transactions = await _accountService.GetTransactionsAsync(user.Id, account.Id);
        foreach (var t in transactions)
        {
            _transactionGrid.Rows.Add(t.Id, t.Direction, t.Amount.ToString("N0"), t.Currency, t.Date);
        }
    }

    private async Task OnNewTransferAsync()
    {
        var account = SelectedAccount();
        var user = _currentUser.CurrentUser;
        if (account is null || user is null)
        {
            return;
        }

        var response = await _authorizationClient.CheckAsync(new AuthorizationRequest
        {
            UserId = user.Id,
            Permission = "transfer.create",
            ResourceType = "account",
            ResourceId = account.Id
        });
        AuthorizationDebugForm.ShowDecision(this.FindForm()!, "New Transfer", user.DisplayName, response);

        if (!response.Allowed)
        {
            return;
        }

        using var dialog = new NewTransferDialog(account.Id);
        if (dialog.ShowDialog(this.FindForm()) != DialogResult.OK)
        {
            return;
        }

        var result = await _transferService.CreateAsync(user.Id, new CreateTransferRequest
        {
            FromAccountId = account.Id,
            ToAccountId = dialog.ToAccountId,
            Amount = dialog.Amount,
            Currency = account.Currency
        });

        if (result.Transfer is not null)
        {
            MessageBox.Show(this.FindForm(), $"Transfer {result.Transfer.Id} created.", "Transfer", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        else
        {
            MessageBox.Show(this.FindForm(), result.Error ?? string.Join('\n', result.Authorization.Reasons), "Transfer failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private async Task OnOpenAccountAsync()
    {
        var user = _currentUser.CurrentUser;
        if (user is null)
        {
            return;
        }

        using var dialog = new OpenAccountDialog(user.CompanyScope == "*" ? "company:10" : user.CompanyScope);
        if (dialog.ShowDialog(this.FindForm()) != DialogResult.OK)
        {
            return;
        }

        var response = await _authorizationClient.CheckAsync(new AuthorizationRequest
        {
            UserId = user.Id,
            Permission = "account.open",
            ResourceType = "account",
            Context = new Dictionary<string, object> { ["companyId"] = dialog.CompanyId }
        });
        AuthorizationDebugForm.ShowDecision(this.FindForm()!, "Hesap Aç", user.DisplayName, response);

        if (!response.Allowed)
        {
            return;
        }

        var result = await _accountService.OpenAsync(user.Id, new OpenAccountRequest
        {
            CustomerId = dialog.CustomerId,
            CompanyId = dialog.CompanyId,
            Currency = dialog.Currency
        });

        if (result.Account is not null)
        {
            MessageBox.Show(this.FindForm(), $"Hesap {result.Account.Id} açıldı.", "Hesap Aç", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        await ActivateAsync();
    }

    private async Task OnCloseAccountAsync()
    {
        var account = SelectedAccount();
        var user = _currentUser.CurrentUser;
        if (account is null || user is null)
        {
            return;
        }

        var response = await _authorizationClient.CheckAsync(new AuthorizationRequest
        {
            UserId = user.Id,
            Permission = "account.close",
            ResourceType = "account",
            ResourceId = account.Id
        });
        AuthorizationDebugForm.ShowDecision(this.FindForm()!, "Hesap Kapat", user.DisplayName, response);

        if (!response.Allowed)
        {
            return;
        }

        var result = await _accountService.CloseAsync(user.Id, account.Id);
        if (result.Account is null)
        {
            MessageBox.Show(this.FindForm(), result.Error ?? string.Join('\n', result.Authorization.Reasons), "Hesap kapatılamadı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        await ActivateAsync();
    }

    private async Task OnDownloadStatementAsync()
    {
        var account = SelectedAccount();
        var user = _currentUser.CurrentUser;
        if (account is null || user is null)
        {
            return;
        }

        var response = await _authorizationClient.CheckAsync(new AuthorizationRequest
        {
            UserId = user.Id,
            Permission = "statement.download",
            ResourceType = "account",
            ResourceId = account.Id
        });
        AuthorizationDebugForm.ShowDecision(this.FindForm()!, "Download Statement", user.DisplayName, response);

        if (response.Allowed)
        {
            MessageBox.Show(this.FindForm(), $"Statement for {account.Id} downloaded (mock).", "Statement", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
