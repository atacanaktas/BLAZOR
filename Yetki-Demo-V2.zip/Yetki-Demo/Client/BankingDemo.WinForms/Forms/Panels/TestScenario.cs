namespace BankingDemo.WinForms.Forms.Panels;

/// <summary>
/// A single named authorization test case: which user, doing what, on which resource, and what
/// the pipeline is expected to decide. This is the same matrix as
/// BankingAuthorizationService.Tests/AuthorizationEngineTests.cs, kept in sync deliberately so
/// the automated xUnit suite and this interactive screen tell the same story.
/// </summary>
public class TestScenario
{
    public required string Id { get; init; }
    public required string Description { get; init; }
    public required string UserId { get; init; }
    public required string UserDisplayName { get; init; }
    public required string Permission { get; init; }
    public string? ResourceType { get; init; }
    public string? ResourceId { get; init; }
    public Dictionary<string, object>? Context { get; init; }
    public required string ExpectedDecision { get; init; }
}

public static class TestScenarios
{
    // Mock user ids mirror BankingAuthorizationService.Common.UserIds - fixed for this demo directory.
    private const string GiseAsistani = "user-1"; // Elif Yıldız
    private const string GiseYetkilisi = "user-2"; // Mert Kaya
    private const string BmsYetkilisi = "user-3"; // Zeynep Arslan
    private const string SubeMuduru = "user-4"; // Burak Şahin
    private const string BmsAsistani = "user-5"; // Deniz Koç

    public static readonly IReadOnlyList<TestScenario> All = new List<TestScenario>
    {
        new()
        {
            Id = "S01",
            Description = "Gişe Asistanı vadesiz hesabı görüntüleyebilir",
            UserId = GiseAsistani, UserDisplayName = "Elif Yıldız (Gişe Asistanı)",
            Permission = "account.read", ResourceType = "account", ResourceId = "account:2001",
            ExpectedDecision = "ALLOW"
        },
        new()
        {
            Id = "S02",
            Description = "Gişe Asistanı yeni hesap açamaz",
            UserId = GiseAsistani, UserDisplayName = "Elif Yıldız (Gişe Asistanı)",
            Permission = "account.open", ResourceType = "account",
            Context = new Dictionary<string, object> { ["companyId"] = "company:10" },
            ExpectedDecision = "DENY"
        },
        new()
        {
            Id = "S03",
            Description = "Gişe Yetkilisi yeni hesap açabilir",
            UserId = GiseYetkilisi, UserDisplayName = "Mert Kaya (Gişe Yetkilisi)",
            Permission = "account.open", ResourceType = "account",
            Context = new Dictionary<string, object> { ["companyId"] = "company:10" },
            ExpectedDecision = "ALLOW"
        },
        new()
        {
            Id = "S04",
            Description = "Gişe Asistanı ödeme onaylayamaz (yetkisi yok)",
            UserId = GiseAsistani, UserDisplayName = "Elif Yıldız (Gişe Asistanı)",
            Permission = "payment.approve", ResourceType = "payment", ResourceId = "payment:3001",
            ExpectedDecision = "DENY"
        },
        new()
        {
            Id = "S05",
            Description = "Gişe Yetkilisi limitin içindeki ödemeyi onaylayabilir (200.000 TL)",
            UserId = GiseYetkilisi, UserDisplayName = "Mert Kaya (Gişe Yetkilisi)",
            Permission = "payment.approve", ResourceType = "payment", ResourceId = "payment:3001",
            ExpectedDecision = "ALLOW"
        },
        new()
        {
            Id = "S06",
            Description = "Gişe Yetkilisi limiti aşan ödemeyi onaylayamaz (500.000 TL > 300.000 limit)",
            UserId = GiseYetkilisi, UserDisplayName = "Mert Kaya (Gişe Yetkilisi)",
            Permission = "payment.approve", ResourceType = "payment", ResourceId = "payment:3002",
            ExpectedDecision = "DENY"
        },
        new()
        {
            Id = "S07",
            Description = "Maker kendi oluşturduğu ödemeyi onaylayamaz (maker/checker)",
            UserId = GiseYetkilisi, UserDisplayName = "Mert Kaya (Gişe Yetkilisi)",
            Permission = "payment.approve", ResourceType = "payment", ResourceId = "payment:3004",
            ExpectedDecision = "DENY"
        },
        new()
        {
            Id = "S08",
            Description = "Şube dışı (company:20) ödeme onayı reddedilir - kapsam dışı",
            UserId = GiseYetkilisi, UserDisplayName = "Mert Kaya (Gişe Yetkilisi)",
            Permission = "payment.approve", ResourceType = "payment", ResourceId = "payment:3003",
            ExpectedDecision = "DENY"
        },
        new()
        {
            Id = "S09",
            Description = "Şube Müdürü '*' yetkisine sahip olsa da başka şubeyi onaylayamaz",
            UserId = SubeMuduru, UserDisplayName = "Burak Şahin (Şube Müdürü)",
            Permission = "payment.approve", ResourceType = "payment", ResourceId = "payment:3003",
            ExpectedDecision = "DENY"
        },
        new()
        {
            Id = "S10",
            Description = "Bireysel Müşteri Asistanı vadeli hesap açabilir",
            UserId = BmsAsistani, UserDisplayName = "Deniz Koç (BMS Asistanı)",
            Permission = "deposit_account.open", ResourceType = "deposit_account",
            Context = new Dictionary<string, object> { ["companyId"] = "company:10" },
            ExpectedDecision = "ALLOW"
        },
        new()
        {
            Id = "S11",
            Description = "Bireysel Müşteri Asistanı kapama talebini onaylayamaz",
            UserId = BmsAsistani, UserDisplayName = "Deniz Koç (BMS Asistanı)",
            Permission = "deposit_account.approve", ResourceType = "deposit_account", ResourceId = "depositaccount:6004",
            ExpectedDecision = "DENY"
        },
        new()
        {
            Id = "S12",
            Description = "Bireysel Müşteri Yetkilisi limitin içindeki kapama talebini onaylayabilir (400.000 TL)",
            UserId = BmsYetkilisi, UserDisplayName = "Zeynep Arslan (BMS Yetkilisi)",
            Permission = "deposit_account.approve", ResourceType = "deposit_account", ResourceId = "depositaccount:6004",
            ExpectedDecision = "ALLOW"
        },
        new()
        {
            Id = "S13",
            Description = "Bireysel Müşteri Yetkilisi limiti aşan kapama talebini onaylayamaz (900.000 TL > 750.000 limit)",
            UserId = BmsYetkilisi, UserDisplayName = "Zeynep Arslan (BMS Yetkilisi)",
            Permission = "deposit_account.approve", ResourceType = "deposit_account", ResourceId = "depositaccount:6002",
            ExpectedDecision = "DENY"
        },
        new()
        {
            Id = "S14",
            Description = "Maker (BMS Yetkilisi) kendi kapama talebini onaylayamaz",
            UserId = BmsYetkilisi, UserDisplayName = "Zeynep Arslan (BMS Yetkilisi)",
            Permission = "deposit_account.approve", ResourceType = "deposit_account", ResourceId = "depositaccount:6005",
            ExpectedDecision = "DENY"
        },
        new()
        {
            Id = "S15",
            Description = "Şube dışı vadeli hesap kapaması reddedilir - kapsam dışı",
            UserId = BmsYetkilisi, UserDisplayName = "Zeynep Arslan (BMS Yetkilisi)",
            Permission = "deposit_account.approve", ResourceType = "deposit_account", ResourceId = "depositaccount:6003",
            ExpectedDecision = "DENY"
        },
        new()
        {
            Id = "S16",
            Description = "VIP müşteri bakiyesi ayrıcalıksız kullanıcıya maskelenir",
            UserId = GiseAsistani, UserDisplayName = "Elif Yıldız (Gişe Asistanı)",
            Permission = "account.balance.view", ResourceType = "account", ResourceId = "account:2002",
            ExpectedDecision = "MASK"
        },
        new()
        {
            Id = "S17",
            Description = "VIP müşteri bakiyesi Bireysel Müşteri Yetkilisi'ne görünür",
            UserId = BmsYetkilisi, UserDisplayName = "Zeynep Arslan (BMS Yetkilisi)",
            Permission = "account.balance.view", ResourceType = "account", ResourceId = "account:2002",
            ExpectedDecision = "ALLOW"
        },
        new()
        {
            Id = "S18",
            Description = "TC kimlik görüntüleme yetkisi olmayan kullanıcı reddedilir",
            UserId = GiseAsistani, UserDisplayName = "Elif Yıldız (Gişe Asistanı)",
            Permission = "customer.identity.view", ResourceType = "customer", ResourceId = "customer:1001",
            ExpectedDecision = "DENY"
        }
    };
}
