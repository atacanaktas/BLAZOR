namespace BankingDemo.WinForms.Forms.Panels;

/// <summary>Implemented by every screen hosted in MainForm's content area so navigation can
/// (re)load the screen's data and capabilities each time it becomes active.</summary>
public interface IScreenPanel
{
    Task ActivateAsync();
}
