using BankingDemo.WinForms.Authorization;
using BankingDemo.WinForms.Models;
using BankingDemo.WinForms.Services;

namespace BankingDemo.WinForms.Forms.Panels;

/// <summary>
/// Vadeli Hesaplar (time deposit accounts). Mirrors PaymentPanel's maker/checker shape but in
/// the retail relationship domain: Bireysel Müşteri Asistanı opens accounts and requests
/// closure (maker); Bireysel Müşteri Yetkilisi approves/rejects the closure (checker, with a
/// 750.000 TRY limit). Şube Müdürü can do everything via the wildcard role.
/// </summary>
public class DepositAccountPanel : UserControl, IScreenPanel
{
    private readonly ICurrentUserContext _currentUser;
    private readonly IDepositAccountService _depositAccountService;
    private readonly IAuthorizationClient _authorizationClient;
    private readonly ICapabilityService _capabilityService;

    private readonly DataGridView _grid = new();
    private readonly Label _statusLabel = new();
    private readonly Button _openButton = new() { Text = "Vadeli Hesap Aç" };
    private readonly Button _requestClosureButton = new() { Text = "Kapama Talebi" };
    private readonly Button _approveButton = new() { Text = "Onayla" };
    private readonly Button _rejectButton = new() { Text = "Reddet" };

    private List<DepositAccount> _depositAccounts = new();

    public DepositAccountPanel(
        ICurrentUserContext currentUser,
        IDepositAccountService depositAccountService,
        IAuthorizationClient authorizationClient,
        ICapabilityService capabilityService)
    {
        _currentUser = currentUser;
        _depositAccountService = depositAccountService;
        _authorizationClient = authorizationClient;
        _capabilityService = capabilityService;
        BuildUi();
    }

    private void BuildUi()
    {
        var title = new Label { Text = "Vadeli Hesaplar", Font = new Font("Segoe UI", 16, FontStyle.Bold), Dock = DockStyle.Top, Height = 40 };
        _statusLabel.Dock = DockStyle.Top;
        _statusLabel.Height = 22;
        _statusLabel.ForeColor = Color.DimGray;

        var buttonPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 44 };
        _openButton.Click += async (_, _) => await OnOpenAsync();
        _requestClosureButton.Click += async (_, _) => await OnActionAsync("deposit_account.close", "Kapama Talebi", (u, id) => _depositAccountService.RequestClosureAsync(u, id));
        _approveButton.Click += async (_, _) => await OnActionAsync("deposit_account.approve", "Onayla", (u, id) => _depositAccountService.ApproveAsync(u, id));
        _rejectButton.Click += async (_, _) => await OnActionAsync("deposit_account.reject", "Reddet", (u, id) => _depositAccountService.RejectAsync(u, id));
        foreach (var b in new[] { _openButton, _requestClosureButton, _approveButton, _rejectButton })
        {
            b.Width = 130;
            b.Height = 32;
            b.Enabled = false;
        }
        buttonPanel.Controls.AddRange(new Control[] { _openButton, _requestClosureButton, _approveButton, _rejectButton });

        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.AllowUserToDeleteRows = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.MultiSelect = false;
        _grid.Columns.Add("Id", "Hesap No");
        _grid.Columns.Add("CustomerName", "Müşteri");
        _grid.Columns.Add("Principal", "Ana Para");
        _grid.Columns.Add("Currency", "Para Birimi");
        _grid.Columns.Add("TermMonths", "Vade (Ay)");
        _grid.Columns.Add("Status", "Durum");
        _grid.Columns.Add("CreatedByDisplayName", "Oluşturan");
        _grid.SelectionChanged += async (_, _) => await OnSelectionChangedAsync();

        Controls.Add(_grid);
        Controls.Add(buttonPanel);
        Controls.Add(_statusLabel);
        Controls.Add(title);
    }

    public async Task ActivateAsync()
    {
        var user = _currentUser.CurrentUser;
        if (user is null)
        {
            return;
        }

        await ReloadGridAsync();

        var createCapabilities = await _capabilityService.GetCapabilitiesAsync("deposit-accounts");
        _openButton.Enabled = createCapabilities.GetValueOrDefault("open_deposit_account");
    }

    private async Task ReloadGridAsync()
    {
        var user = _currentUser.CurrentUser!;
        _statusLabel.Text = "Vadeli hesaplar yükleniyor...";
        _grid.Rows.Clear();

        try
        {
            _depositAccounts = await _depositAccountService.GetAllAsync(user.Id);
        }
        catch (Exception ex)
        {
            _statusLabel.Text = $"Yükleme hatası: {ex.Message}";
            return;
        }

        foreach (var d in _depositAccounts)
        {
            _grid.Rows.Add(d.Id, d.CustomerName, d.Principal.ToString("N0"), d.Currency, d.TermMonths, d.Status, d.CreatedByDisplayName);
        }

        _statusLabel.Text = $"{_depositAccounts.Count} vadeli hesap şube kapsamınızda.";
    }

    private DepositAccount? SelectedDepositAccount()
    {
        if (_grid.SelectedRows.Count == 0)
        {
            return null;
        }
        var id = _grid.SelectedRows[0].Cells["Id"].Value?.ToString();
        return _depositAccounts.FirstOrDefault(d => d.Id == id);
    }

    private async Task OnSelectionChangedAsync()
    {
        var depositAccount = SelectedDepositAccount();
        if (depositAccount is null)
        {
            SetActionButtonsEnabled(false, false, false);
            return;
        }

        var capabilities = await _capabilityService.GetCapabilitiesAsync("deposit-accounts", depositAccount.Id);
        SetActionButtonsEnabled(
            capabilities.GetValueOrDefault("request_closure"),
            capabilities.GetValueOrDefault("approve_closure"),
            capabilities.GetValueOrDefault("reject_closure"));
    }

    private void SetActionButtonsEnabled(bool requestClosure, bool approve, bool reject)
    {
        _requestClosureButton.Enabled = requestClosure;
        _approveButton.Enabled = approve;
        _rejectButton.Enabled = reject;
    }

    private async Task OnActionAsync(string permission, string label, Func<string, string, Task<DepositAccountActionResult>> action)
    {
        var depositAccount = SelectedDepositAccount();
        var user = _currentUser.CurrentUser;
        if (depositAccount is null || user is null)
        {
            return;
        }

        var response = await _authorizationClient.CheckAsync(new AuthorizationRequest
        {
            UserId = user.Id,
            Permission = permission,
            ResourceType = "deposit_account",
            ResourceId = depositAccount.Id
        });
        AuthorizationDebugForm.ShowDecision(this.FindForm()!, $"{label} - {depositAccount.Id}", user.DisplayName, response);

        if (!response.Allowed)
        {
            return;
        }

        var result = await action(user.Id, depositAccount.Id);
        if (result.DepositAccount is null && result.Error is not null)
        {
            MessageBox.Show(this.FindForm(), result.Error, "İşlem başarısız", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        await ReloadGridAsync();
        await OnSelectionChangedAsync();
    }

    private async Task OnOpenAsync()
    {
        var user = _currentUser.CurrentUser;
        if (user is null)
        {
            return;
        }

        using var dialog = new OpenDepositAccountDialog(user.CompanyScope == "*" ? "company:10" : user.CompanyScope);
        if (dialog.ShowDialog(this.FindForm()) != DialogResult.OK)
        {
            return;
        }

        var response = await _authorizationClient.CheckAsync(new AuthorizationRequest
        {
            UserId = user.Id,
            Permission = "deposit_account.open",
            ResourceType = "deposit_account",
            Context = new Dictionary<string, object> { ["companyId"] = dialog.CompanyId }
        });
        AuthorizationDebugForm.ShowDecision(this.FindForm()!, "Vadeli Hesap Aç", user.DisplayName, response);

        if (!response.Allowed)
        {
            return;
        }

        var result = await _depositAccountService.OpenAsync(user.Id, new OpenDepositAccountRequest
        {
            CustomerId = dialog.CustomerId,
            CompanyId = dialog.CompanyId,
            Principal = dialog.Principal,
            Currency = dialog.Currency,
            TermMonths = dialog.TermMonths
        });

        if (result.DepositAccount is not null)
        {
            MessageBox.Show(this.FindForm(), $"Vadeli hesap {result.DepositAccount.Id} açıldı.", "Vadeli Hesap", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        await ReloadGridAsync();
    }
}
