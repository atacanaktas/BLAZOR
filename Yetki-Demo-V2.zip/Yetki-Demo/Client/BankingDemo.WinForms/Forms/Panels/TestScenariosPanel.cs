using BankingDemo.WinForms.Authorization;

namespace BankingDemo.WinForms.Forms.Panels;

/// <summary>
/// Interactive test runner: fires every TestScenario at the live Authorization Service (as
/// whichever mock user the scenario names, independent of who is actually logged in), compares
/// the actual decision against the expected one, and colors PASS/FAIL. Double-clicking a row
/// after a run opens the same Authorization Debug dialog the business screens use, so the full
/// RBAC/Scope/Policy step trace for that scenario can be inspected.
/// </summary>
public class TestScenariosPanel : UserControl, IScreenPanel
{
    private readonly IAuthorizationClient _authorizationClient;
    private readonly DataGridView _grid = new();
    private readonly Label _statusLabel = new();
    private readonly Button _runAllButton = new() { Text = "Tümünü Çalıştır" };
    private readonly Dictionary<string, AuthorizationResponse> _lastResponses = new();

    public TestScenariosPanel(IAuthorizationClient authorizationClient)
    {
        _authorizationClient = authorizationClient;
        BuildUi();
    }

    private void BuildUi()
    {
        var title = new Label { Text = "Test Senaryoları", Font = new Font("Segoe UI", 16, FontStyle.Bold), Dock = DockStyle.Top, Height = 40 };
        var info = new Label
        {
            Text = "Her senaryo, ilgili mock kullanıcı adına canlı olarak Authorization Service'e sorulur. " +
                   "Bir satıra çift tıklayarak karar adımlarını (RBAC/Scope/Policy) görebilirsiniz.",
            Dock = DockStyle.Top,
            Height = 40,
            ForeColor = Color.DimGray
        };

        var buttonPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40 };
        _runAllButton.Width = 150;
        _runAllButton.Height = 30;
        _runAllButton.Click += async (_, _) => await RunAllAsync();
        buttonPanel.Controls.Add(_runAllButton);

        _statusLabel.Dock = DockStyle.Top;
        _statusLabel.Height = 22;
        _statusLabel.ForeColor = Color.DimGray;

        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.RowHeadersVisible = false;
        _grid.Columns.Add("Id", "No");
        _grid.Columns.Add("Description", "Senaryo");
        _grid.Columns.Add("User", "Kullanıcı");
        _grid.Columns.Add("Permission", "İşlem");
        _grid.Columns.Add("Resource", "Kaynak");
        _grid.Columns.Add("Expected", "Beklenen");
        _grid.Columns.Add("Actual", "Sonuç");
        _grid.Columns.Add("Result", "Durum");
        _grid.Columns["Id"].FillWeight = 40;
        _grid.Columns["Description"].FillWeight = 220;
        _grid.Columns["User"].FillWeight = 140;
        _grid.Columns["Permission"].FillWeight = 130;
        _grid.Columns["Resource"].FillWeight = 100;
        _grid.Columns["Expected"].FillWeight = 70;
        _grid.Columns["Actual"].FillWeight = 70;
        _grid.Columns["Result"].FillWeight = 60;
        _grid.CellDoubleClick += OnCellDoubleClick;

        foreach (var scenario in TestScenarios.All)
        {
            _grid.Rows.Add(scenario.Id, scenario.Description, scenario.UserDisplayName, scenario.Permission,
                scenario.ResourceId ?? "-", scenario.ExpectedDecision, "-", "-");
        }

        Controls.Add(_grid);
        Controls.Add(_statusLabel);
        Controls.Add(buttonPanel);
        Controls.Add(info);
        Controls.Add(title);
    }

    public Task ActivateAsync() => Task.CompletedTask;

    private async Task RunAllAsync()
    {
        _runAllButton.Enabled = false;
        int passed = 0, failed = 0;

        foreach (var scenario in TestScenarios.All)
        {
            var response = await _authorizationClient.CheckAsync(new AuthorizationRequest
            {
                UserId = scenario.UserId,
                Permission = scenario.Permission,
                ResourceType = scenario.ResourceType,
                ResourceId = scenario.ResourceId,
                Context = scenario.Context
            });

            _lastResponses[scenario.Id] = response;

            var row = _grid.Rows.Cast<DataGridViewRow>().First(r => (string)r.Cells["Id"].Value == scenario.Id);
            var isPass = response.Decision == scenario.ExpectedDecision;
            row.Cells["Actual"].Value = response.Decision;
            row.Cells["Result"].Value = isPass ? "PASS" : "FAIL";
            row.DefaultCellStyle.ForeColor = isPass ? Color.SeaGreen : Color.Firebrick;

            if (isPass) passed++; else failed++;
        }

        _statusLabel.Text = $"{passed} PASS, {failed} FAIL (toplam {TestScenarios.All.Count} senaryo).";
        _statusLabel.ForeColor = failed == 0 ? Color.SeaGreen : Color.Firebrick;
        _runAllButton.Enabled = true;
    }

    private void OnCellDoubleClick(object? sender, DataGridViewCellEventArgs e)
    {
        if (e.RowIndex < 0)
        {
            return;
        }

        var row = _grid.Rows[e.RowIndex];
        var id = (string)row.Cells["Id"].Value!;
        if (!_lastResponses.TryGetValue(id, out var response))
        {
            MessageBox.Show(this.FindForm(), "Önce \"Tümünü Çalıştır\" ile bu senaryoyu çalıştırın.", "Sonuç yok", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var scenario = TestScenarios.All.First(s => s.Id == id);
        AuthorizationDebugForm.ShowDecision(this.FindForm()!, $"{scenario.Id} - {scenario.Description}", scenario.UserDisplayName, response);
    }
}
