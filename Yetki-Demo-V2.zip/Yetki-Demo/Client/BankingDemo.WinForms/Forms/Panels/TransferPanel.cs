using BankingDemo.WinForms.Authorization;
using BankingDemo.WinForms.Services;

namespace BankingDemo.WinForms.Forms.Panels;

/// <summary>Read-only ledger of transfers created from the Account screen. Transfer creation
/// lives on Account Detail since a transfer always originates from a specific account.</summary>
public class TransferPanel : UserControl, IScreenPanel
{
    private readonly ICurrentUserContext _currentUser;
    private readonly ITransferService _transferService;
    private readonly DataGridView _grid = new();
    private readonly Label _statusLabel = new();

    public TransferPanel(ICurrentUserContext currentUser, ITransferService transferService)
    {
        _currentUser = currentUser;
        _transferService = transferService;
        BuildUi();
    }

    private void BuildUi()
    {
        var title = new Label { Text = "Transfers", Font = new Font("Segoe UI", 16, FontStyle.Bold), Dock = DockStyle.Top, Height = 40 };
        _statusLabel.Dock = DockStyle.Top;
        _statusLabel.Height = 22;
        _statusLabel.ForeColor = Color.DimGray;

        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.Columns.Add("Id", "Transfer ID");
        _grid.Columns.Add("FromAccountId", "From Account");
        _grid.Columns.Add("ToAccountId", "To Account");
        _grid.Columns.Add("Amount", "Amount");
        _grid.Columns.Add("Currency", "Currency");
        _grid.Columns.Add("Status", "Status");

        Controls.Add(_grid);
        Controls.Add(_statusLabel);
        Controls.Add(title);
    }

    public async Task ActivateAsync()
    {
        var user = _currentUser.CurrentUser;
        if (user is null)
        {
            return;
        }

        _statusLabel.Text = "Loading transfers...";
        _grid.Rows.Clear();

        var transfers = await _transferService.GetAllAsync(user.Id);
        foreach (var t in transfers)
        {
            _grid.Rows.Add(t.Id, t.FromAccountId, t.ToAccountId, t.Amount.ToString("N0"), t.Currency, t.Status);
        }

        _statusLabel.Text = transfers.Count == 0
            ? "No transfers yet. Create one from an account's detail actions."
            : $"{transfers.Count} transfer(s).";
    }
}
