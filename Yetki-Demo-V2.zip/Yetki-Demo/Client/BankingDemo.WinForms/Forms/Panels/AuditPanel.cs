using BankingDemo.WinForms.Authorization;

namespace BankingDemo.WinForms.Forms.Panels;

/// <summary>Shows every authorization decision the server has made this session, newest first -
/// the same in-memory log every check/action call writes to.</summary>
public class AuditPanel : UserControl, IScreenPanel
{
    private readonly IAuthorizationClient _authorizationClient;
    private readonly DataGridView _grid = new();
    private readonly Label _statusLabel = new();
    private readonly Button _refreshButton = new() { Text = "Refresh" };

    public AuditPanel(IAuthorizationClient authorizationClient)
    {
        _authorizationClient = authorizationClient;
        BuildUi();
    }

    private void BuildUi()
    {
        var title = new Label { Text = "Authorization Audit Log", Font = new Font("Segoe UI", 16, FontStyle.Bold), Dock = DockStyle.Top, Height = 40 };

        var topPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40 };
        _refreshButton.Click += async (_, _) => await ActivateAsync();
        _refreshButton.Width = 100;
        _refreshButton.Height = 30;
        topPanel.Controls.Add(_refreshButton);

        _statusLabel.Dock = DockStyle.Top;
        _statusLabel.Height = 22;
        _statusLabel.ForeColor = Color.DimGray;

        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.Columns.Add("Timestamp", "Time");
        _grid.Columns.Add("Username", "User");
        _grid.Columns.Add("Permission", "Permission");
        _grid.Columns.Add("Resource", "Resource");
        _grid.Columns.Add("Decision", "Decision");
        _grid.Columns.Add("PolicyName", "Policy");

        Controls.Add(_grid);
        Controls.Add(_statusLabel);
        Controls.Add(topPanel);
        Controls.Add(title);
    }

    public async Task ActivateAsync()
    {
        _statusLabel.Text = "Loading audit log...";
        _grid.Rows.Clear();

        var entries = await _authorizationClient.GetAuditLogAsync();
        foreach (var e in entries)
        {
            var rowIndex = _grid.Rows.Add(e.Timestamp.ToString("HH:mm:ss"), e.Username, e.Permission, e.Resource, e.Decision, e.PolicyName);
            _grid.Rows[rowIndex].DefaultCellStyle.ForeColor = e.Decision switch
            {
                "ALLOW" => Color.SeaGreen,
                "MASK" => Color.DarkOrange,
                _ => Color.Firebrick
            };
        }

        _statusLabel.Text = $"{entries.Count} decision(s) recorded this session.";
    }
}
