using BankingDemo.WinForms.Authorization;

namespace BankingDemo.WinForms.Forms.Panels;

/// <summary>
/// Landing screen: shows who is signed in and a plain-language summary of their effective
/// access, driven entirely by a batch authorization check against the permission catalog's
/// most representative permissions - not by inspecting the role name.
/// </summary>
public class DashboardPanel : UserControl, IScreenPanel
{
    private readonly ICurrentUserContext _currentUser;
    private readonly IAuthorizationClient _authorizationClient;
    private readonly ListView _summaryList = new();

    private static readonly (string Permission, string Label)[] SamplePermissions =
    {
        ("customer.read", "View customers"),
        ("account.balance.view", "View account balances"),
        ("payment.create", "Create payments"),
        ("payment.approve", "Approve payments"),
        ("payment.execute", "Execute payments"),
        ("transfer.create", "Create transfers"),
        ("audit_log.read", "View audit log"),
        ("role.read", "Administration access")
    };

    public DashboardPanel(ICurrentUserContext currentUser, IAuthorizationClient authorizationClient)
    {
        _currentUser = currentUser;
        _authorizationClient = authorizationClient;
        BuildUi();
    }

    private void BuildUi()
    {
        var title = new Label
        {
            Text = "Dashboard",
            Font = new Font("Segoe UI", 16, FontStyle.Bold),
            Dock = DockStyle.Top,
            Height = 40
        };

        var user = _currentUser.CurrentUser;
        var welcome = new Label
        {
            Text = user is null ? string.Empty : $"Welcome, {user.DisplayName}. This panel shows your effective permission summary, computed live by the Authorization Service.",
            Dock = DockStyle.Top,
            Height = 40,
            ForeColor = Color.DimGray
        };

        _summaryList.Dock = DockStyle.Fill;
        _summaryList.View = View.Details;
        _summaryList.FullRowSelect = true;
        _summaryList.GridLines = true;
        _summaryList.Columns.Add("Capability", 260);
        _summaryList.Columns.Add("Permission", 200);
        _summaryList.Columns.Add("Allowed", 100);

        Controls.Add(_summaryList);
        Controls.Add(welcome);
        Controls.Add(title);
    }

    public async Task ActivateAsync()
    {
        _summaryList.Items.Clear();
        var user = _currentUser.CurrentUser;
        if (user is null)
        {
            return;
        }

        var batchResponse = await _authorizationClient.CheckBatchAsync(new BatchAuthorizationRequest
        {
            UserId = user.Id,
            Checks = SamplePermissions.Select(p => new AuthorizationCheckItem { Permission = p.Permission }).ToList()
        });

        var byPermission = batchResponse.Results.ToDictionary(r => r.Permission, r => r.Allowed);

        foreach (var (permission, label) in SamplePermissions)
        {
            var allowed = byPermission.TryGetValue(permission, out var value) && value;
            var item = new ListViewItem(label);
            item.SubItems.Add(permission);
            item.SubItems.Add(allowed ? "Yes" : "No");
            item.ForeColor = allowed ? Color.SeaGreen : Color.Gray;
            _summaryList.Items.Add(item);
        }
    }
}
