using BankingDemo.WinForms.Authorization;
using BankingDemo.WinForms.Models;
using BankingDemo.WinForms.Services;

namespace BankingDemo.WinForms.Forms.Panels;

/// <summary>
/// The maker/checker and approval-limit showcase. Every button re-checks authorization for the
/// SELECTED payment (not just a generic screen-level check) because approve/reject/execute
/// depend on that payment's status, creator and amount - exactly the pipeline the server runs.
/// </summary>
public class PaymentPanel : UserControl, IScreenPanel
{
    private readonly ICurrentUserContext _currentUser;
    private readonly IPaymentService _paymentService;
    private readonly IAuthorizationClient _authorizationClient;
    private readonly ICapabilityService _capabilityService;

    private readonly DataGridView _grid = new();
    private readonly Label _statusLabel = new();
    private readonly Button _newButton = new() { Text = "New Payment" };
    private readonly Button _submitButton = new() { Text = "Submit" };
    private readonly Button _approveButton = new() { Text = "Approve" };
    private readonly Button _rejectButton = new() { Text = "Reject" };
    private readonly Button _executeButton = new() { Text = "Execute" };
    private readonly Button _cancelButton = new() { Text = "Cancel" };

    private List<Payment> _payments = new();

    public PaymentPanel(
        ICurrentUserContext currentUser,
        IPaymentService paymentService,
        IAuthorizationClient authorizationClient,
        ICapabilityService capabilityService)
    {
        _currentUser = currentUser;
        _paymentService = paymentService;
        _authorizationClient = authorizationClient;
        _capabilityService = capabilityService;
        BuildUi();
    }

    private void BuildUi()
    {
        var title = new Label { Text = "Payments", Font = new Font("Segoe UI", 16, FontStyle.Bold), Dock = DockStyle.Top, Height = 40 };
        _statusLabel.Dock = DockStyle.Top;
        _statusLabel.Height = 22;
        _statusLabel.ForeColor = Color.DimGray;

        var buttonPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 44 };
        _newButton.Click += async (_, _) => await OnNewPaymentAsync();
        _submitButton.Click += async (_, _) => await OnActionAsync("payment.submit", "Submit", (u, id) => _paymentService.SubmitAsync(u, id));
        _approveButton.Click += async (_, _) => await OnActionAsync("payment.approve", "Approve", (u, id) => _paymentService.ApproveAsync(u, id));
        _rejectButton.Click += async (_, _) => await OnActionAsync("payment.reject", "Reject", (u, id) => _paymentService.RejectAsync(u, id));
        _executeButton.Click += async (_, _) => await OnActionAsync("payment.execute", "Execute", (u, id) => _paymentService.ExecuteAsync(u, id));
        _cancelButton.Click += async (_, _) => await OnActionAsync("payment.cancel", "Cancel", (u, id) => _paymentService.CancelAsync(u, id));
        foreach (var b in new[] { _newButton, _submitButton, _approveButton, _rejectButton, _executeButton, _cancelButton })
        {
            b.Width = 110;
            b.Height = 32;
            b.Enabled = false;
        }
        buttonPanel.Controls.AddRange(new Control[] { _newButton, _submitButton, _approveButton, _rejectButton, _executeButton, _cancelButton });

        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.AllowUserToDeleteRows = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.MultiSelect = false;
        _grid.Columns.Add("Id", "Payment ID");
        _grid.Columns.Add("CompanyId", "Company");
        _grid.Columns.Add("Amount", "Amount");
        _grid.Columns.Add("Currency", "Currency");
        _grid.Columns.Add("Status", "Status");
        _grid.Columns.Add("CreatedByDisplayName", "Created By");
        _grid.SelectionChanged += async (_, _) => await OnSelectionChangedAsync();

        Controls.Add(_grid);
        Controls.Add(buttonPanel);
        Controls.Add(_statusLabel);
        Controls.Add(title);
    }

    public async Task ActivateAsync()
    {
        var user = _currentUser.CurrentUser;
        if (user is null)
        {
            return;
        }

        await ReloadGridAsync();

        var createCapabilities = await _capabilityService.GetCapabilitiesAsync("payments");
        _newButton.Enabled = createCapabilities.GetValueOrDefault("create_payment");
    }

    private async Task ReloadGridAsync()
    {
        var user = _currentUser.CurrentUser!;
        _statusLabel.Text = "Loading payments...";
        _grid.Rows.Clear();

        try
        {
            _payments = await _paymentService.GetAllAsync(user.Id);
        }
        catch (Exception ex)
        {
            _statusLabel.Text = $"Failed to load payments: {ex.Message}";
            return;
        }

        foreach (var p in _payments)
        {
            _grid.Rows.Add(p.Id, p.CompanyId, p.Amount.ToString("N0"), p.Currency, p.Status, p.CreatedByDisplayName);
        }

        _statusLabel.Text = $"{_payments.Count} payment(s) within your company scope.";
    }

    private Payment? SelectedPayment()
    {
        if (_grid.SelectedRows.Count == 0)
        {
            return null;
        }
        var id = _grid.SelectedRows[0].Cells["Id"].Value?.ToString();
        return _payments.FirstOrDefault(p => p.Id == id);
    }

    private async Task OnSelectionChangedAsync()
    {
        var payment = SelectedPayment();
        if (payment is null)
        {
            SetActionButtonsEnabled(false, false, false, false, false);
            return;
        }

        var capabilities = await _capabilityService.GetCapabilitiesAsync("payments", payment.Id);
        SetActionButtonsEnabled(
            capabilities.GetValueOrDefault("submit_payment"),
            capabilities.GetValueOrDefault("approve_payment"),
            capabilities.GetValueOrDefault("reject_payment"),
            capabilities.GetValueOrDefault("execute_payment"),
            capabilities.GetValueOrDefault("cancel_payment"));
    }

    private void SetActionButtonsEnabled(bool submit, bool approve, bool reject, bool execute, bool cancel)
    {
        _submitButton.Enabled = submit;
        _approveButton.Enabled = approve;
        _rejectButton.Enabled = reject;
        _executeButton.Enabled = execute;
        _cancelButton.Enabled = cancel;
    }

    private async Task OnActionAsync(string permission, string label, Func<string, string, Task<PaymentActionResult>> action)
    {
        var payment = SelectedPayment();
        var user = _currentUser.CurrentUser;
        if (payment is null || user is null)
        {
            return;
        }

        var response = await _authorizationClient.CheckAsync(new AuthorizationRequest
        {
            UserId = user.Id,
            Permission = permission,
            ResourceType = "payment",
            ResourceId = payment.Id
        });
        AuthorizationDebugForm.ShowDecision(this.FindForm()!, $"{label} Payment {payment.Id}", user.DisplayName, response);

        if (!response.Allowed)
        {
            return;
        }

        var result = await action(user.Id, payment.Id);
        if (result.Payment is null && result.Error is not null)
        {
            MessageBox.Show(this.FindForm(), result.Error, "Action failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        await ReloadGridAsync();
        await OnSelectionChangedAsync();
    }

    private async Task OnNewPaymentAsync()
    {
        var user = _currentUser.CurrentUser;
        if (user is null)
        {
            return;
        }

        using var dialog = new NewPaymentDialog(user.CompanyScope == "*" ? "company:10" : user.CompanyScope);
        if (dialog.ShowDialog(this.FindForm()) != DialogResult.OK)
        {
            return;
        }

        var response = await _authorizationClient.CheckAsync(new AuthorizationRequest
        {
            UserId = user.Id,
            Permission = "payment.create",
            ResourceType = "payment",
            Context = new Dictionary<string, object> { ["companyId"] = dialog.CompanyId }
        });
        AuthorizationDebugForm.ShowDecision(this.FindForm()!, "New Payment", user.DisplayName, response);

        if (!response.Allowed)
        {
            return;
        }

        var result = await _paymentService.CreateAsync(user.Id, new CreatePaymentRequest
        {
            CompanyId = dialog.CompanyId,
            Amount = dialog.Amount,
            Currency = dialog.Currency
        });

        if (result.Payment is not null)
        {
            MessageBox.Show(this.FindForm(), $"Payment {result.Payment.Id} created as DRAFT.", "Payment", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        await ReloadGridAsync();
    }
}
