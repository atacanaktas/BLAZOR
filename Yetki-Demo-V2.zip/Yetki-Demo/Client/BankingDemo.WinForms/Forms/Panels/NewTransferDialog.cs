namespace BankingDemo.WinForms.Forms.Panels;

public class NewTransferDialog : Form
{
    private readonly TextBox _toAccountBox = new();
    private readonly NumericUpDown _amountBox = new();

    public string ToAccountId => _toAccountBox.Text.Trim();
    public decimal Amount => _amountBox.Value;

    public NewTransferDialog(string fromAccountId)
    {
        Text = "New Transfer";
        ClientSize = new Size(340, 190);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;

        var fromLabel = new Label { Text = $"From account: {fromAccountId}", Location = new Point(16, 16), AutoSize = true };
        var toLabel = new Label { Text = "To account:", Location = new Point(16, 50), AutoSize = true };
        _toAccountBox.Location = new Point(16, 70);
        _toAccountBox.Width = 300;
        _toAccountBox.PlaceholderText = "e.g. account:2003";

        var amountLabel = new Label { Text = "Amount:", Location = new Point(16, 100), AutoSize = true };
        _amountBox.Location = new Point(16, 120);
        _amountBox.Width = 300;
        _amountBox.Maximum = 100_000_000;
        _amountBox.DecimalPlaces = 2;
        _amountBox.Value = 1000;

        var okButton = new Button { Text = "Create Transfer", DialogResult = DialogResult.OK, Location = new Point(16, 150), Width = 300 };
        okButton.Click += (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(_toAccountBox.Text))
            {
                MessageBox.Show(this, "Please enter a destination account.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DialogResult = DialogResult.None;
            }
        };

        Controls.AddRange(new Control[] { fromLabel, toLabel, _toAccountBox, amountLabel, _amountBox, okButton });
        AcceptButton = okButton;
    }
}
