using BankingDemo.WinForms.Authorization;
using BankingDemo.WinForms.Services;

namespace BankingDemo.WinForms.Forms.Panels;

/// <summary>BankAdmin-only screen listing roles and users straight from the catalog endpoints,
/// gated by role.read / user.read.</summary>
public class AdministrationPanel : UserControl, IScreenPanel
{
    private readonly ICapabilityService _capabilityService;
    private readonly IUserDirectoryService _userDirectory;
    private readonly DataGridView _grid = new();
    private readonly Label _statusLabel = new();

    public AdministrationPanel(ICapabilityService capabilityService, IUserDirectoryService userDirectory)
    {
        _capabilityService = capabilityService;
        _userDirectory = userDirectory;
        BuildUi();
    }

    private void BuildUi()
    {
        var title = new Label { Text = "Administration", Font = new Font("Segoe UI", 16, FontStyle.Bold), Dock = DockStyle.Top, Height = 40 };
        _statusLabel.Dock = DockStyle.Top;
        _statusLabel.Height = 22;
        _statusLabel.ForeColor = Color.DimGray;

        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.Columns.Add("Id", "User Id");
        _grid.Columns.Add("Username", "Username");
        _grid.Columns.Add("DisplayName", "Display Name");
        _grid.Columns.Add("Role", "Role");
        _grid.Columns.Add("CompanyScope", "Company Scope");

        Controls.Add(_grid);
        Controls.Add(_statusLabel);
        Controls.Add(title);
    }

    public async Task ActivateAsync()
    {
        var capabilities = await _capabilityService.GetCapabilitiesAsync("administration");
        if (!capabilities.GetValueOrDefault("view_users"))
        {
            _statusLabel.Text = "You do not have user.read permission.";
            return;
        }

        var users = await _userDirectory.GetAllAsync();
        _grid.Rows.Clear();
        foreach (var u in users)
        {
            _grid.Rows.Add(u.Id, u.Username, u.DisplayName, RoleDisplayNames.For(u.PrimaryRoleId), u.CompanyScope);
        }

        _statusLabel.Text = $"{users.Count} user(s) in the mock directory.";
    }
}
