using BankingDemo.WinForms.Authorization;

namespace BankingDemo.WinForms.Forms.Panels;

/// <summary>Minimal placeholder screen: it exists mainly to demonstrate report.read /
/// report.export gating the "Export" button, not to render real reports.</summary>
public class ReportsPanel : UserControl, IScreenPanel
{
    private readonly ICurrentUserContext _currentUser;
    private readonly ICapabilityService _capabilityService;
    private readonly IAuthorizationClient _authorizationClient;
    private readonly Button _exportButton = new() { Text = "Export Report" };
    private readonly Label _statusLabel = new();

    public ReportsPanel(ICurrentUserContext currentUser, ICapabilityService capabilityService, IAuthorizationClient authorizationClient)
    {
        _currentUser = currentUser;
        _capabilityService = capabilityService;
        _authorizationClient = authorizationClient;
        BuildUi();
    }

    private void BuildUi()
    {
        var title = new Label { Text = "Reports", Font = new Font("Segoe UI", 16, FontStyle.Bold), Dock = DockStyle.Top, Height = 40 };
        var info = new Label
        {
            Text = "This demo focuses on authorization, not reporting content. Export is gated by report.export.",
            Dock = DockStyle.Top,
            Height = 40,
            ForeColor = Color.DimGray
        };

        _exportButton.Width = 150;
        _exportButton.Height = 32;
        _exportButton.Dock = DockStyle.Top;
        _exportButton.Enabled = false;
        _exportButton.Click += async (_, _) => await OnExportAsync();

        _statusLabel.Dock = DockStyle.Top;
        _statusLabel.Height = 22;
        _statusLabel.ForeColor = Color.DimGray;

        Controls.Add(_statusLabel);
        Controls.Add(_exportButton);
        Controls.Add(info);
        Controls.Add(title);
    }

    public async Task ActivateAsync()
    {
        var capabilities = await _capabilityService.GetCapabilitiesAsync("reports");
        _exportButton.Enabled = capabilities.GetValueOrDefault("export_reports");
        _statusLabel.Text = capabilities.GetValueOrDefault("view_reports") ? "You can view reports." : string.Empty;
    }

    private async Task OnExportAsync()
    {
        var user = _currentUser.CurrentUser;
        if (user is null)
        {
            return;
        }

        var response = await _authorizationClient.CheckAsync(new AuthorizationRequest
        {
            UserId = user.Id,
            Permission = "report.export"
        });
        AuthorizationDebugForm.ShowDecision(this.FindForm()!, "Export Report", user.DisplayName, response);

        if (response.Allowed)
        {
            MessageBox.Show(this.FindForm(), "Report exported (mock).", "Reports", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
