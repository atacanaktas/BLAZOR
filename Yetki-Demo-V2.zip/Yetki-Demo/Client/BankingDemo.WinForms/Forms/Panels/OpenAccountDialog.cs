namespace BankingDemo.WinForms.Forms.Panels;

public class OpenAccountDialog : Form
{
    private readonly TextBox _customerBox = new();
    private readonly TextBox _companyBox = new();
    private readonly ComboBox _currencyBox = new();

    public string CustomerId => _customerBox.Text.Trim();
    public string CompanyId => _companyBox.Text.Trim();
    public string Currency => _currencyBox.Text;

    public OpenAccountDialog(string defaultCompanyId)
    {
        Text = "Hesap Aç";
        ClientSize = new Size(340, 220);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;

        var customerLabel = new Label { Text = "Müşteri No:", Location = new Point(16, 16), AutoSize = true };
        _customerBox.Location = new Point(16, 36);
        _customerBox.Width = 300;
        _customerBox.PlaceholderText = "e.g. customer:1001";

        var companyLabel = new Label { Text = "Şube (Company):", Location = new Point(16, 66), AutoSize = true };
        _companyBox.Location = new Point(16, 86);
        _companyBox.Width = 300;
        _companyBox.Text = defaultCompanyId;

        var currencyLabel = new Label { Text = "Para Birimi:", Location = new Point(16, 116), AutoSize = true };
        _currencyBox.Location = new Point(16, 136);
        _currencyBox.Width = 300;
        _currencyBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _currencyBox.Items.AddRange(new object[] { "TRY", "USD", "EUR" });
        _currencyBox.SelectedIndex = 0;

        var okButton = new Button { Text = "Hesap Aç", DialogResult = DialogResult.OK, Location = new Point(16, 170), Width = 300 };
        okButton.Click += (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(_customerBox.Text))
            {
                MessageBox.Show(this, "Lütfen müşteri numarasını girin.", "Doğrulama", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DialogResult = DialogResult.None;
            }
        };

        Controls.AddRange(new Control[] { customerLabel, _customerBox, companyLabel, _companyBox, currencyLabel, _currencyBox, okButton });
        AcceptButton = okButton;
    }
}
