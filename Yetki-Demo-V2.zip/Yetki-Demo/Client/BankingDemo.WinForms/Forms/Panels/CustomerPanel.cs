using BankingDemo.WinForms.Authorization;
using BankingDemo.WinForms.Models;
using BankingDemo.WinForms.Services;

namespace BankingDemo.WinForms.Forms.Panels;

/// <summary>
/// Field-level authorization in action: the grid's Phone/National ID columns show whatever the
/// server sent (real value or masked placeholder) - the client performs no masking decisions
/// of its own, it only renders CustomerDto.PhoneMasked / IdentityMasked as returned.
/// </summary>
public class CustomerPanel : UserControl, IScreenPanel
{
    private readonly ICurrentUserContext _currentUser;
    private readonly ICustomerService _customerService;
    private readonly DataGridView _grid = new();
    private readonly Label _statusLabel = new();

    public CustomerPanel(ICurrentUserContext currentUser, ICustomerService customerService)
    {
        _currentUser = currentUser;
        _customerService = customerService;
        BuildUi();
    }

    private void BuildUi()
    {
        var title = new Label { Text = "Customers", Font = new Font("Segoe UI", 16, FontStyle.Bold), Dock = DockStyle.Top, Height = 40 };
        _statusLabel.Dock = DockStyle.Top;
        _statusLabel.Height = 24;
        _statusLabel.ForeColor = Color.DimGray;

        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.AllowUserToDeleteRows = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.Columns.Add("Id", "Customer No");
        _grid.Columns.Add("Name", "Name");
        _grid.Columns.Add("Segment", "Segment");
        _grid.Columns.Add("RiskLevel", "Risk");
        _grid.Columns.Add("Phone", "Phone");
        _grid.Columns.Add("Email", "Email");
        _grid.Columns.Add("NationalId", "National ID");

        Controls.Add(_grid);
        Controls.Add(_statusLabel);
        Controls.Add(title);
    }

    public async Task ActivateAsync()
    {
        var user = _currentUser.CurrentUser;
        if (user is null)
        {
            return;
        }

        _statusLabel.Text = "Loading customers...";
        _grid.Rows.Clear();

        List<Customer> customers;
        try
        {
            customers = await _customerService.GetAllAsync(user.Id);
        }
        catch (Exception ex)
        {
            _statusLabel.Text = $"Failed to load customers: {ex.Message}";
            return;
        }

        foreach (var customer in customers)
        {
            var rowIndex = _grid.Rows.Add(customer.Id, customer.Name, customer.Segment, customer.RiskLevel,
                customer.PhoneDisplay, customer.Email, customer.NationalIdDisplay);

            if (customer.PhoneMasked)
            {
                _grid.Rows[rowIndex].Cells["Phone"].Style.ForeColor = Color.Gray;
            }
            if (customer.IdentityMasked)
            {
                _grid.Rows[rowIndex].Cells["NationalId"].Style.ForeColor = Color.Gray;
            }
        }

        _statusLabel.Text = $"{customers.Count} customer(s). Masked fields (gray) require customer.phone.view / customer.identity.view.";
    }
}
