namespace BankingDemo.WinForms.Forms.Panels;

public class OpenDepositAccountDialog : Form
{
    private readonly TextBox _customerBox = new();
    private readonly TextBox _companyBox = new();
    private readonly NumericUpDown _principalBox = new();
    private readonly ComboBox _currencyBox = new();
    private readonly NumericUpDown _termBox = new();

    public string CustomerId => _customerBox.Text.Trim();
    public string CompanyId => _companyBox.Text.Trim();
    public decimal Principal => _principalBox.Value;
    public string Currency => _currencyBox.Text;
    public int TermMonths => (int)_termBox.Value;

    public OpenDepositAccountDialog(string defaultCompanyId)
    {
        Text = "Vadeli Hesap Aç";
        ClientSize = new Size(340, 300);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;

        var customerLabel = new Label { Text = "Müşteri No:", Location = new Point(16, 16), AutoSize = true };
        _customerBox.Location = new Point(16, 36);
        _customerBox.Width = 300;
        _customerBox.PlaceholderText = "e.g. customer:1001";

        var companyLabel = new Label { Text = "Şube (Company):", Location = new Point(16, 66), AutoSize = true };
        _companyBox.Location = new Point(16, 86);
        _companyBox.Width = 300;
        _companyBox.Text = defaultCompanyId;

        var principalLabel = new Label { Text = "Ana Para:", Location = new Point(16, 116), AutoSize = true };
        _principalBox.Location = new Point(16, 136);
        _principalBox.Width = 300;
        _principalBox.Maximum = 100_000_000;
        _principalBox.DecimalPlaces = 2;
        _principalBox.Value = 100000;

        var currencyLabel = new Label { Text = "Para Birimi:", Location = new Point(16, 166), AutoSize = true };
        _currencyBox.Location = new Point(16, 186);
        _currencyBox.Width = 300;
        _currencyBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _currencyBox.Items.AddRange(new object[] { "TRY", "USD", "EUR" });
        _currencyBox.SelectedIndex = 0;

        var termLabel = new Label { Text = "Vade (Ay):", Location = new Point(16, 216), AutoSize = true };
        _termBox.Location = new Point(16, 236);
        _termBox.Width = 300;
        _termBox.Minimum = 1;
        _termBox.Maximum = 36;
        _termBox.Value = 6;

        var okButton = new Button { Text = "Vadeli Hesap Aç", DialogResult = DialogResult.OK, Location = new Point(16, 266), Width = 300 };
        okButton.Click += (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(_customerBox.Text))
            {
                MessageBox.Show(this, "Lütfen müşteri numarasını girin.", "Doğrulama", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DialogResult = DialogResult.None;
            }
        };

        Controls.AddRange(new Control[]
        {
            customerLabel, _customerBox, companyLabel, _companyBox, principalLabel, _principalBox,
            currencyLabel, _currencyBox, termLabel, _termBox, okButton
        });
        AcceptButton = okButton;
    }
}
