using BankingDemo.WinForms.Authorization;

namespace BankingDemo.WinForms.Forms;

/// <summary>
/// Renders one AuthorizationResponse exactly as the architecture doc's debug panel example:
/// every pipeline step with its PASS/FAIL/MASK result, the deciding policy, and the final
/// ALLOW/DENY/MASK. This is read-only: it never re-evaluates anything, it only explains the
/// decision the server already made.
/// </summary>
public class AuthorizationDebugForm : Form
{
    public AuthorizationDebugForm(string actionLabel, string userDisplayName, AuthorizationResponse response)
    {
        Text = "Authorization Decision";
        ClientSize = new Size(520, 480);
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;

        var decisionColor = response.Decision switch
        {
            "ALLOW" => Color.SeaGreen,
            "MASK" => Color.DarkOrange,
            _ => Color.Firebrick
        };

        var header = new Label
        {
            Text = $"Authorization Decision — {actionLabel}",
            Font = new Font("Segoe UI", 12, FontStyle.Bold),
            Dock = DockStyle.Fill,
            Padding = new Padding(12, 8, 0, 0)
        };

        var summary = new Label
        {
            Text = $"User: {userDisplayName}\nPermission: {response.Permission}\nResource: {response.Resource ?? "-"}\nRole: {response.RoleUsed ?? "-"}",
            Dock = DockStyle.Fill,
            Padding = new Padding(12, 0, 0, 0)
        };

        var stepsList = new ListView
        {
            Dock = DockStyle.Fill,
            View = View.Details,
            FullRowSelect = true,
            GridLines = true
        };
        stepsList.Columns.Add("Step", 180);
        stepsList.Columns.Add("Result", 90);
        stepsList.Columns.Add("Detail", 230);

        foreach (var step in response.Steps)
        {
            var item = new ListViewItem(step.Step);
            item.SubItems.Add(step.Result);
            item.SubItems.Add(step.Detail ?? string.Empty);
            item.ForeColor = step.Result switch
            {
                "PASS" => Color.SeaGreen,
                "FAIL" => Color.Firebrick,
                "MASK" => Color.DarkOrange,
                _ => Color.Black
            };
            stepsList.Items.Add(item);
        }

        var reasonsBox = new TextBox
        {
            Dock = DockStyle.Fill,
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Vertical,
            Text = string.Join(Environment.NewLine, response.Reasons.Select(r => "• " + r))
        };

        var decisionLabel = new Label
        {
            Text = $"Policy: {response.PolicyName ?? "None"}    Decision: {response.Decision}",
            Font = new Font("Segoe UI", 11, FontStyle.Bold),
            ForeColor = decisionColor,
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(12, 0, 0, 0)
        };

        var closeButton = new Button { Text = "Close", Dock = DockStyle.Fill };
        closeButton.Click += (_, _) => Close();

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 6
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 36));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 90));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
        layout.Controls.Add(header, 0, 0);
        layout.Controls.Add(summary, 0, 1);
        layout.Controls.Add(stepsList, 0, 2);
        layout.Controls.Add(reasonsBox, 0, 3);
        layout.Controls.Add(decisionLabel, 0, 4);
        layout.Controls.Add(closeButton, 0, 5);

        Controls.Add(layout);
    }

    public static void ShowDecision(IWin32Window owner, string actionLabel, string userDisplayName, AuthorizationResponse response)
    {
        using var form = new AuthorizationDebugForm(actionLabel, userDisplayName, response);
        form.ShowDialog(owner);
    }
}
