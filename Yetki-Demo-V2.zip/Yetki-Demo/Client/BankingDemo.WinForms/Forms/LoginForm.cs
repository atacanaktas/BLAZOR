using BankingDemo.WinForms.Authorization;
using BankingDemo.WinForms.Models;
using BankingDemo.WinForms.Services;

namespace BankingDemo.WinForms.Forms;

/// <summary>
/// No real authentication: the operator simply picks one of the mock users seeded in the
/// Authorization Service. The chosen user's id becomes CurrentUser for the whole session.
/// </summary>
public class LoginForm : Form
{
    private readonly IUserDirectoryService _userDirectory;
    private readonly ICurrentUserContext _currentUser;

    private readonly ComboBox _userCombo = new();
    private readonly Button _loginButton = new();
    private readonly Label _statusLabel = new();
    private List<AppUser> _users = new();

    public LoginForm(IUserDirectoryService userDirectory, ICurrentUserContext currentUser)
    {
        _userDirectory = userDirectory;
        _currentUser = currentUser;

        BuildUi();
        Shown += async (_, _) => await LoadUsersAsync();
    }

    private void BuildUi()
    {
        Text = "Banking Authorization Demo - Login";
        ClientSize = new Size(420, 220);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterScreen;
        MaximizeBox = false;
        MinimizeBox = false;

        var title = new Label
        {
            Text = "Banking Authorization Demo",
            Font = new Font("Segoe UI", 14, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(24, 24)
        };

        var subtitle = new Label
        {
            Text = "Select a mock user to sign in",
            AutoSize = true,
            Location = new Point(24, 58),
            ForeColor = Color.DimGray
        };

        _userCombo.Location = new Point(24, 90);
        _userCombo.Width = 372;
        _userCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        _userCombo.DisplayMember = nameof(UserListItem.Label);

        _loginButton.Text = "Login";
        _loginButton.Location = new Point(24, 130);
        _loginButton.Size = new Size(372, 36);
        _loginButton.Enabled = false;
        _loginButton.Click += OnLoginClicked;

        _statusLabel.Location = new Point(24, 175);
        _statusLabel.AutoSize = true;
        _statusLabel.ForeColor = Color.Firebrick;

        Controls.AddRange(new Control[] { title, subtitle, _userCombo, _loginButton, _statusLabel });
        AcceptButton = _loginButton;
    }

    private async Task LoadUsersAsync()
    {
        try
        {
            _statusLabel.Text = "Loading users...";
            _statusLabel.ForeColor = Color.DimGray;
            _users = await _userDirectory.GetAllAsync();

            _userCombo.Items.Clear();
            foreach (var user in _users)
            {
                _userCombo.Items.Add(new UserListItem(user));
            }

            if (_userCombo.Items.Count > 0)
            {
                _userCombo.SelectedIndex = 0;
            }

            _loginButton.Enabled = _userCombo.Items.Count > 0;
            _statusLabel.Text = string.Empty;
        }
        catch (Exception ex)
        {
            _statusLabel.Text = $"Could not reach the Authorization Service. Is it running?\n{ex.Message}";
        }
    }

    private void OnLoginClicked(object? sender, EventArgs e)
    {
        if (_userCombo.SelectedItem is not UserListItem item)
        {
            return;
        }

        _currentUser.SignIn(item.User);
        DialogResult = DialogResult.OK;
        Close();
    }

    private sealed record UserListItem(AppUser User)
    {
        public string Label => $"{User.DisplayName} - {RoleDisplayNames.For(User.PrimaryRoleId)}";
        public override string ToString() => Label;
    }
}
