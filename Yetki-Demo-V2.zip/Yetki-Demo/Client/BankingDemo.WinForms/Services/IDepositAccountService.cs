using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

public interface IDepositAccountService
{
    Task<List<DepositAccount>> GetAllAsync(string userId, CancellationToken cancellationToken = default);
    Task<DepositAccountActionResult> OpenAsync(string userId, OpenDepositAccountRequest request, CancellationToken cancellationToken = default);
    Task<DepositAccountActionResult> RequestClosureAsync(string userId, string id, CancellationToken cancellationToken = default);
    Task<DepositAccountActionResult> ApproveAsync(string userId, string id, CancellationToken cancellationToken = default);
    Task<DepositAccountActionResult> RejectAsync(string userId, string id, CancellationToken cancellationToken = default);
}
