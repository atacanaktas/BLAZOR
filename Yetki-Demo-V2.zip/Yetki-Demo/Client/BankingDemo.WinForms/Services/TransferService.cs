using System.Net.Http.Json;
using BankingDemo.WinForms.Common;
using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

public class TransferService : ITransferService
{
    private readonly HttpClient _httpClient;

    public TransferService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<Transfer>> GetAllAsync(string userId, CancellationToken cancellationToken = default)
    {
        var result = await _httpClient.GetFromJsonAsync<List<Transfer>>($"api/transfers?userId={userId}", JsonOptions.Default, cancellationToken);
        return result ?? new List<Transfer>();
    }

    public async Task<TransferActionResult> CreateAsync(string userId, CreateTransferRequest request, CancellationToken cancellationToken = default)
    {
        using var response = await _httpClient.PostAsJsonAsync($"api/transfers?userId={userId}", request, JsonOptions.Default, cancellationToken);
        var result = await response.Content.ReadFromJsonAsync<TransferActionResult>(JsonOptions.Default, cancellationToken);
        return result ?? new TransferActionResult { Error = "Empty response from server" };
    }
}
