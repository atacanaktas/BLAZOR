using System.Net.Http.Json;
using BankingDemo.WinForms.Common;
using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

public class UserDirectoryService : IUserDirectoryService
{
    private readonly HttpClient _httpClient;

    public UserDirectoryService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<AppUser>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        var result = await _httpClient.GetFromJsonAsync<List<AppUser>>("api/users", JsonOptions.Default, cancellationToken);
        return result ?? new List<AppUser>();
    }
}
