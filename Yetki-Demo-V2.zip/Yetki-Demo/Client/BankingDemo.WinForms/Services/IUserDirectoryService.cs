using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

/// <summary>Reads the mock user directory for the login screen's user picker.</summary>
public interface IUserDirectoryService
{
    Task<List<AppUser>> GetAllAsync(CancellationToken cancellationToken = default);
}
