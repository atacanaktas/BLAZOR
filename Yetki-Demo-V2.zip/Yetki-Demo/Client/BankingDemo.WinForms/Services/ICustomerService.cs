using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

public interface ICustomerService
{
    Task<List<Customer>> GetAllAsync(string userId, CancellationToken cancellationToken = default);
}
