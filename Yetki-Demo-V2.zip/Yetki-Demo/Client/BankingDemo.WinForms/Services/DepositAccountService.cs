using System.Net.Http.Json;
using BankingDemo.WinForms.Common;
using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

public class DepositAccountService : IDepositAccountService
{
    private readonly HttpClient _httpClient;

    public DepositAccountService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<DepositAccount>> GetAllAsync(string userId, CancellationToken cancellationToken = default)
    {
        var result = await _httpClient.GetFromJsonAsync<List<DepositAccount>>($"api/deposit-accounts?userId={userId}", JsonOptions.Default, cancellationToken);
        return result ?? new List<DepositAccount>();
    }

    public async Task<DepositAccountActionResult> OpenAsync(string userId, OpenDepositAccountRequest request, CancellationToken cancellationToken = default) =>
        await PostAsync($"api/deposit-accounts?userId={userId}", request, cancellationToken);

    public async Task<DepositAccountActionResult> RequestClosureAsync(string userId, string id, CancellationToken cancellationToken = default) =>
        await PostAsync($"api/deposit-accounts/{id}/request-closure?userId={userId}", new { }, cancellationToken);

    public async Task<DepositAccountActionResult> ApproveAsync(string userId, string id, CancellationToken cancellationToken = default) =>
        await PostAsync($"api/deposit-accounts/{id}/approve?userId={userId}", new { }, cancellationToken);

    public async Task<DepositAccountActionResult> RejectAsync(string userId, string id, CancellationToken cancellationToken = default) =>
        await PostAsync($"api/deposit-accounts/{id}/reject?userId={userId}", new { }, cancellationToken);

    private async Task<DepositAccountActionResult> PostAsync<T>(string url, T body, CancellationToken cancellationToken)
    {
        using var response = await _httpClient.PostAsJsonAsync(url, body, JsonOptions.Default, cancellationToken);
        var result = await response.Content.ReadFromJsonAsync<DepositAccountActionResult>(JsonOptions.Default, cancellationToken);
        return result ?? new DepositAccountActionResult { Error = "Empty response from server" };
    }
}
