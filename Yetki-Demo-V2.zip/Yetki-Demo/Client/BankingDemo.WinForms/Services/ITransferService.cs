using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

public interface ITransferService
{
    Task<List<Transfer>> GetAllAsync(string userId, CancellationToken cancellationToken = default);
    Task<TransferActionResult> CreateAsync(string userId, CreateTransferRequest request, CancellationToken cancellationToken = default);
}
