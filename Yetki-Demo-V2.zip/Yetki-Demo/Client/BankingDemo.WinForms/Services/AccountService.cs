using System.Net.Http.Json;
using BankingDemo.WinForms.Common;
using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

public class AccountService : IAccountService
{
    private readonly HttpClient _httpClient;

    public AccountService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<Account>> GetAllAsync(string userId, CancellationToken cancellationToken = default)
    {
        var result = await _httpClient.GetFromJsonAsync<List<Account>>($"api/accounts?userId={userId}", JsonOptions.Default, cancellationToken);
        return result ?? new List<Account>();
    }

    public async Task<List<Transaction>> GetTransactionsAsync(string userId, string accountId, CancellationToken cancellationToken = default)
    {
        var result = await _httpClient.GetFromJsonAsync<List<Transaction>>($"api/accounts/{accountId}/transactions?userId={userId}", JsonOptions.Default, cancellationToken);
        return result ?? new List<Transaction>();
    }

    public async Task<AccountActionResult> OpenAsync(string userId, OpenAccountRequest request, CancellationToken cancellationToken = default)
    {
        using var response = await _httpClient.PostAsJsonAsync($"api/accounts?userId={userId}", request, JsonOptions.Default, cancellationToken);
        var result = await response.Content.ReadFromJsonAsync<AccountActionResult>(JsonOptions.Default, cancellationToken);
        return result ?? new AccountActionResult { Error = "Empty response from server" };
    }

    public async Task<AccountActionResult> CloseAsync(string userId, string id, CancellationToken cancellationToken = default)
    {
        using var response = await _httpClient.PostAsJsonAsync($"api/accounts/{id}/close?userId={userId}", new { }, JsonOptions.Default, cancellationToken);
        var result = await response.Content.ReadFromJsonAsync<AccountActionResult>(JsonOptions.Default, cancellationToken);
        return result ?? new AccountActionResult { Error = "Empty response from server" };
    }
}
