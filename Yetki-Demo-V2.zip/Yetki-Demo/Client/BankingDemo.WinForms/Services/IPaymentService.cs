using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

public interface IPaymentService
{
    Task<List<Payment>> GetAllAsync(string userId, CancellationToken cancellationToken = default);
    Task<PaymentActionResult> CreateAsync(string userId, CreatePaymentRequest request, CancellationToken cancellationToken = default);
    Task<PaymentActionResult> SubmitAsync(string userId, string id, CancellationToken cancellationToken = default);
    Task<PaymentActionResult> ApproveAsync(string userId, string id, CancellationToken cancellationToken = default);
    Task<PaymentActionResult> RejectAsync(string userId, string id, CancellationToken cancellationToken = default);
    Task<PaymentActionResult> ExecuteAsync(string userId, string id, CancellationToken cancellationToken = default);
    Task<PaymentActionResult> CancelAsync(string userId, string id, CancellationToken cancellationToken = default);
}
