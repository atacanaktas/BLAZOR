using System.Net.Http.Json;
using BankingDemo.WinForms.Common;
using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

public class PaymentService : IPaymentService
{
    private readonly HttpClient _httpClient;

    public PaymentService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<Payment>> GetAllAsync(string userId, CancellationToken cancellationToken = default)
    {
        var result = await _httpClient.GetFromJsonAsync<List<Payment>>($"api/payments?userId={userId}", JsonOptions.Default, cancellationToken);
        return result ?? new List<Payment>();
    }

    public async Task<PaymentActionResult> CreateAsync(string userId, CreatePaymentRequest request, CancellationToken cancellationToken = default) =>
        await PostAsync($"api/payments?userId={userId}", request, cancellationToken);

    public async Task<PaymentActionResult> SubmitAsync(string userId, string id, CancellationToken cancellationToken = default) =>
        await PostActionAsync(id, "submit", userId, cancellationToken);

    public async Task<PaymentActionResult> ApproveAsync(string userId, string id, CancellationToken cancellationToken = default) =>
        await PostActionAsync(id, "approve", userId, cancellationToken);

    public async Task<PaymentActionResult> RejectAsync(string userId, string id, CancellationToken cancellationToken = default) =>
        await PostActionAsync(id, "reject", userId, cancellationToken);

    public async Task<PaymentActionResult> ExecuteAsync(string userId, string id, CancellationToken cancellationToken = default) =>
        await PostActionAsync(id, "execute", userId, cancellationToken);

    public async Task<PaymentActionResult> CancelAsync(string userId, string id, CancellationToken cancellationToken = default) =>
        await PostActionAsync(id, "cancel", userId, cancellationToken);

    private async Task<PaymentActionResult> PostActionAsync(string id, string action, string userId, CancellationToken cancellationToken) =>
        await PostAsync($"api/payments/{id}/{action}?userId={userId}", new { }, cancellationToken);

    private async Task<PaymentActionResult> PostAsync<T>(string url, T body, CancellationToken cancellationToken)
    {
        using var response = await _httpClient.PostAsJsonAsync(url, body, JsonOptions.Default, cancellationToken);
        var result = await response.Content.ReadFromJsonAsync<PaymentActionResult>(JsonOptions.Default, cancellationToken);
        return result ?? new PaymentActionResult { Error = "Empty response from server" };
    }
}
