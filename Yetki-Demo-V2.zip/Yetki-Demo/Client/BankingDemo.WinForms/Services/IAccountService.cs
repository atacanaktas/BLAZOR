using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

public interface IAccountService
{
    Task<List<Account>> GetAllAsync(string userId, CancellationToken cancellationToken = default);
    Task<List<Transaction>> GetTransactionsAsync(string userId, string accountId, CancellationToken cancellationToken = default);
    Task<AccountActionResult> OpenAsync(string userId, OpenAccountRequest request, CancellationToken cancellationToken = default);
    Task<AccountActionResult> CloseAsync(string userId, string id, CancellationToken cancellationToken = default);
}
