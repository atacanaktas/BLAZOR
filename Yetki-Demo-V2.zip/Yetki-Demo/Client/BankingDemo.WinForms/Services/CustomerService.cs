using System.Net.Http.Json;
using BankingDemo.WinForms.Common;
using BankingDemo.WinForms.Models;

namespace BankingDemo.WinForms.Services;

public class CustomerService : ICustomerService
{
    private readonly HttpClient _httpClient;

    public CustomerService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<Customer>> GetAllAsync(string userId, CancellationToken cancellationToken = default)
    {
        var result = await _httpClient.GetFromJsonAsync<List<Customer>>($"api/customers?userId={userId}", JsonOptions.Default, cancellationToken);
        return result ?? new List<Customer>();
    }
}
