using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Tests;

/// <summary>
/// Test matrix mirrors the demo's two maker/checker pairs:
///   Payments:        Gişe Asistanı (maker) -> Gişe Yetkilisi (checker, 300.000 TRY limit)
///   Deposit accounts: Bireysel Müşteri Asistanı (maker) -> Bireysel Müşteri Yetkilisi
///                      (checker, 750.000 TRY limit)
/// Şube Müdürü holds every permission via "*" but is still scoped to company:10.
/// </summary>
public class AuthorizationEngineTests
{
    [Fact]
    public void GiseAsistani_CanReadAccount()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.GiseAsistani,
            Permission = PermissionNames.AccountRead,
            ResourceType = ResourceTypes.Account,
            ResourceId = "account:2001"
        });

        Assert.True(response.Allowed);
        Assert.Equal(DecisionNames.Allow, response.Decision);
    }

    [Fact]
    public void GiseAsistani_CannotOpenAccount()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.GiseAsistani,
            Permission = PermissionNames.AccountOpen,
            ResourceType = ResourceTypes.Account,
            Context = new Dictionary<string, object> { ["companyId"] = "company:10" }
        });

        Assert.False(response.Allowed);
        Assert.Contains(response.Steps, s => s.Step == "RBAC" && s.Result == StepResultNames.Fail);
    }

    [Fact]
    public void GiseYetkilisi_CanOpenAccount()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.GiseYetkilisi,
            Permission = PermissionNames.AccountOpen,
            ResourceType = ResourceTypes.Account,
            Context = new Dictionary<string, object> { ["companyId"] = "company:10" }
        });

        Assert.True(response.Allowed);
    }

    [Fact]
    public void GiseAsistani_CannotApprovePayment()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.GiseAsistani,
            Permission = PermissionNames.PaymentApprove,
            ResourceType = ResourceTypes.Payment,
            ResourceId = "payment:3001"
        });

        Assert.False(response.Allowed);
        Assert.Contains(response.Steps, s => s.Step == "RBAC" && s.Result == StepResultNames.Fail);
    }

    [Fact]
    public void GiseYetkilisi_CanApprovePayment()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        // payment:3001 = 200.000 TRY, created by Gişe Asistanı, within Gişe Yetkilisi's 300.000 limit.
        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.GiseYetkilisi,
            Permission = PermissionNames.PaymentApprove,
            ResourceType = ResourceTypes.Payment,
            ResourceId = "payment:3001"
        });

        Assert.True(response.Allowed);
        Assert.Equal("PaymentApprovePolicy", response.PolicyName);
    }

    [Fact]
    public void PaymentAboveApprovalLimit_IsDenied()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        // payment:3002 = 500.000 TRY, above Gişe Yetkilisi's 300.000 limit.
        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.GiseYetkilisi,
            Permission = PermissionNames.PaymentApprove,
            ResourceType = ResourceTypes.Payment,
            ResourceId = "payment:3002"
        });

        Assert.False(response.Allowed);
        Assert.Contains(response.Reasons, r => r.Contains("exceeds approval limit"));
    }

    [Fact]
    public void MakerCannotApproveOwnPayment()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        // payment:3004 was seeded with createdBy = Gişe Yetkilisi himself.
        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.GiseYetkilisi,
            Permission = PermissionNames.PaymentApprove,
            ResourceType = ResourceTypes.Payment,
            ResourceId = "payment:3004"
        });

        Assert.False(response.Allowed);
        Assert.Equal("MakerCheckerPolicy", response.PolicyName);
        Assert.Contains(response.Reasons, r => r.Contains("Maker cannot approve own payment"));
    }

    [Fact]
    public void UserOutsideCompanyScope_IsDenied()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        // payment:3003 belongs to company:20; Gişe Yetkilisi's scope is company:10.
        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.GiseYetkilisi,
            Permission = PermissionNames.PaymentApprove,
            ResourceType = ResourceTypes.Payment,
            ResourceId = "payment:3003"
        });

        Assert.False(response.Allowed);
        Assert.Equal("CompanyScopePolicy", response.PolicyName);
    }

    [Fact]
    public void SubeMuduru_WildcardStillRespectsScope()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        // Şube Müdürü has "*" but is scoped to company:10 - company:20's payment must stay DENY.
        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.SubeMuduru,
            Permission = PermissionNames.PaymentApprove,
            ResourceType = ResourceTypes.Payment,
            ResourceId = "payment:3003"
        });

        Assert.False(response.Allowed);
        Assert.Equal("CompanyScopePolicy", response.PolicyName);
    }

    [Fact]
    public void BmsAsistani_CanOpenDepositAccount()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.BmsAsistani,
            Permission = PermissionNames.DepositAccountOpen,
            ResourceType = ResourceTypes.DepositAccount,
            Context = new Dictionary<string, object> { ["companyId"] = "company:10" }
        });

        Assert.True(response.Allowed);
    }

    [Fact]
    public void BmsAsistani_CannotApproveDepositAccountClosure()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.BmsAsistani,
            Permission = PermissionNames.DepositAccountApprove,
            ResourceType = ResourceTypes.DepositAccount,
            ResourceId = "depositaccount:6004"
        });

        Assert.False(response.Allowed);
        Assert.Contains(response.Steps, s => s.Step == "RBAC" && s.Result == StepResultNames.Fail);
    }

    [Fact]
    public void BmsYetkilisi_CanApproveDepositAccountClosure()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        // depositaccount:6004 = 400.000 TRY, created by BMS Asistanı, within the 750.000 limit.
        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.BmsYetkilisi,
            Permission = PermissionNames.DepositAccountApprove,
            ResourceType = ResourceTypes.DepositAccount,
            ResourceId = "depositaccount:6004"
        });

        Assert.True(response.Allowed);
        Assert.Equal("DepositAccountApprovePolicy", response.PolicyName);
    }

    [Fact]
    public void MakerCannotApproveOwnDepositAccountClosure()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        // depositaccount:6005 was seeded with createdBy = Bireysel Müşteri Yetkilisi herself.
        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.BmsYetkilisi,
            Permission = PermissionNames.DepositAccountApprove,
            ResourceType = ResourceTypes.DepositAccount,
            ResourceId = "depositaccount:6005"
        });

        Assert.False(response.Allowed);
        Assert.Equal("MakerCheckerPolicy", response.PolicyName);
        Assert.Contains(response.Reasons, r => r.Contains("Maker cannot approve own deposit account closure"));
    }

    [Fact]
    public void DepositAccountAboveApprovalLimit_IsDenied()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        // depositaccount:6002 = 900.000 TRY, above BMS Yetkilisi's 750.000 limit.
        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.BmsYetkilisi,
            Permission = PermissionNames.DepositAccountApprove,
            ResourceType = ResourceTypes.DepositAccount,
            ResourceId = "depositaccount:6002"
        });

        Assert.False(response.Allowed);
        Assert.Contains(response.Reasons, r => r.Contains("exceeds approval limit"));
    }

    [Fact]
    public void DepositAccountOutsideBranchScope_IsDenied()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        // depositaccount:6003 belongs to company:20 (another branch).
        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.BmsYetkilisi,
            Permission = PermissionNames.DepositAccountApprove,
            ResourceType = ResourceTypes.DepositAccount,
            ResourceId = "depositaccount:6003"
        });

        Assert.False(response.Allowed);
        Assert.Equal("CompanyScopePolicy", response.PolicyName);
    }

    [Fact]
    public void VipBalance_IsMaskedForGiseAsistani()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.GiseAsistani, // no account.balance.view.vip
            Permission = PermissionNames.AccountBalanceView,
            ResourceType = ResourceTypes.Account,
            ResourceId = "account:2002" // VIP customer's account
        });

        Assert.False(response.Allowed);
        Assert.Equal(DecisionNames.Mask, response.Decision);
        Assert.Equal("VIPBalancePolicy", response.PolicyName);
    }

    [Fact]
    public void VipBalance_IsVisibleForBmsYetkilisi()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.BmsYetkilisi, // has account.balance.view.vip
            Permission = PermissionNames.AccountBalanceView,
            ResourceType = ResourceTypes.Account,
            ResourceId = "account:2002"
        });

        Assert.True(response.Allowed);
        Assert.Equal(DecisionNames.Allow, response.Decision);
    }

    [Fact]
    public void UserWithoutIdentityPermission_CannotSeeNationalId()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.Check(new AuthorizationRequest
        {
            UserId = UserIds.GiseAsistani, // no customer.identity.view
            Permission = PermissionNames.CustomerIdentityView,
            ResourceType = ResourceTypes.Customer,
            ResourceId = "customer:1001"
        });

        Assert.False(response.Allowed);
    }

    [Fact]
    public void BatchAuthorization_ReturnsCorrectResults()
    {
        var (engine, _, _) = TestEngineFactory.Create();

        var response = engine.CheckBatch(new BatchAuthorizationRequest
        {
            UserId = UserIds.GiseAsistani,
            Checks = new List<AuthorizationCheckItem>
            {
                new() { Permission = PermissionNames.AccountRead, ResourceType = ResourceTypes.Account, ResourceId = "account:2001" },
                new() { Permission = PermissionNames.AccountBalanceView, ResourceType = ResourceTypes.Account, ResourceId = "account:2001" },
                new() { Permission = PermissionNames.TransactionRead, ResourceType = ResourceTypes.Account, ResourceId = "account:2001" },
                new() { Permission = PermissionNames.AccountOpen, ResourceType = ResourceTypes.Account }
            }
        });

        Assert.Equal(4, response.Results.Count);
        Assert.True(response.Results[0].Allowed);
        Assert.True(response.Results[1].Allowed);
        Assert.True(response.Results[2].Allowed);
        Assert.False(response.Results[3].Allowed); // Gişe Asistanı cannot open accounts
    }
}
