using BankingAuthorizationService.Abac;
using BankingAuthorizationService.Audit;
using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.MockData;
using BankingAuthorizationService.Policies;
using BankingAuthorizationService.Rbac;
using BankingAuthorizationService.Resources;
using BankingAuthorizationService.Services;
using Microsoft.Extensions.Logging.Abstractions;

namespace BankingAuthorizationService.Tests;

/// <summary>
/// Wires up the real authorization pipeline against fresh mock data for each test, without a
/// DI container - the object graph is small enough to construct by hand and this keeps every
/// test's dependencies explicit.
/// </summary>
public static class TestEngineFactory
{
    public static (IAuthorizationEngine Engine, IResourceService Resources, IUserService Users) Create()
    {
        var resourceStore = new MockResourceStore();
        var resources = new ResourceService(resourceStore);
        var users = new UserService();
        var roles = new RoleService();
        var permissions = new PermissionService();
        var abac = new AbacEvaluator();
        var rbac = new RbacService(users, roles);
        var auditLog = new AuditLogService();

        var scopePolicy = new CompanyScopePolicy(abac);
        var makerChecker = new MakerCheckerPolicy();
        var vipBalancePolicy = new VipBalancePolicy(resources, rbac);

        var registry = new PolicyRegistry(
            new AccountReadPolicy(),
            new AccountOpenPolicy(abac),
            new AccountBalancePolicy(vipBalancePolicy),
            new TransactionReadPolicy(),
            new DepositAccountOpenPolicy(abac),
            new DepositAccountApprovePolicy(makerChecker, rbac),
            new DepositAccountRejectPolicy(makerChecker),
            new PaymentCreatePolicy(abac),
            new PaymentApprovePolicy(makerChecker, rbac),
            new PaymentRejectPolicy(makerChecker),
            new PaymentExecutePolicy(),
            new TransferCreatePolicy());

        var engine = new AuthorizationEngine(
            users, permissions, rbac, resources, scopePolicy, registry, auditLog,
            NullLogger<AuthorizationEngine>.Instance);

        return (engine, resources, users);
    }
}
