namespace BankingAuthorizationService.Rbac;

public interface IRbacService
{
    bool HasPermission(string userId, string permission);

    IReadOnlyList<string> GetEffectivePermissions(string userId);

    /// <summary>Returns the highest-priority role name assigned to the user that grants the
    /// given permission, for display in the authorization debug panel and audit log.</summary>
    string? GetGrantingRoleName(string userId, string permission);

    /// <summary>Highest approval limit across the user's roles that grant the given approval
    /// permission (e.g. payment.approve, deposit_account.approve). Null means unlimited.</summary>
    decimal? GetApprovalLimit(string userId, string approvalPermission);
}
