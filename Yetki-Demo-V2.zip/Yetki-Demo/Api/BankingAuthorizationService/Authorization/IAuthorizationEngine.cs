namespace BankingAuthorizationService.Authorization;

public interface IAuthorizationEngine
{
    AuthorizationResponse Check(AuthorizationRequest request);

    BatchAuthorizationResponse CheckBatch(BatchAuthorizationRequest request);
}
