using BankingAuthorizationService.Audit;
using BankingAuthorizationService.Common;
using BankingAuthorizationService.Policies;
using BankingAuthorizationService.Rbac;
using BankingAuthorizationService.Resources;
using BankingAuthorizationService.Services;

namespace BankingAuthorizationService.Authorization;

/// <summary>
/// Central decision point. Runs the fixed pipeline described in the architecture doc:
/// user exists -> permission exists -> RBAC -> resource exists -> scope -> policy (which
/// itself may layer ABAC / SoD / limit checks) -> final ALLOW / DENY / MASK. Every step is
/// recorded so callers can render a full explanation (used by the WinForms debug panel).
/// </summary>
public class AuthorizationEngine : IAuthorizationEngine
{
    private readonly IUserService _userService;
    private readonly IPermissionService _permissionService;
    private readonly IRbacService _rbac;
    private readonly IResourceService _resourceService;
    private readonly CompanyScopePolicy _scopePolicy;
    private readonly IPolicyRegistry _policyRegistry;
    private readonly IAuditLogService _auditLog;
    private readonly ILogger<AuthorizationEngine> _logger;

    public AuthorizationEngine(
        IUserService userService,
        IPermissionService permissionService,
        IRbacService rbac,
        IResourceService resourceService,
        CompanyScopePolicy scopePolicy,
        IPolicyRegistry policyRegistry,
        IAuditLogService auditLog,
        ILogger<AuthorizationEngine> logger)
    {
        _userService = userService;
        _permissionService = permissionService;
        _rbac = rbac;
        _resourceService = resourceService;
        _scopePolicy = scopePolicy;
        _policyRegistry = policyRegistry;
        _auditLog = auditLog;
        _logger = logger;
    }

    public AuthorizationResponse Check(AuthorizationRequest request)
    {
        var steps = new List<AuthorizationStepResult>();
        var reasons = new List<string>();

        // Step 1: user exists
        var user = _userService.GetById(request.UserId);
        if (user is null)
        {
            steps.Add(new AuthorizationStepResult("User Exists", StepResultNames.Fail));
            reasons.Add($"User '{request.UserId}' does not exist");
            return Finalize(request, DecisionNames.Deny, reasons, steps, null, null);
        }
        steps.Add(new AuthorizationStepResult("User Exists", StepResultNames.Pass, user.DisplayName));

        // Step 2: permission exists
        if (!_permissionService.Exists(request.Permission))
        {
            steps.Add(new AuthorizationStepResult("Permission Exists", StepResultNames.Fail));
            reasons.Add($"Permission '{request.Permission}' is not a known permission");
            return Finalize(request, DecisionNames.Deny, reasons, steps, null, null);
        }
        steps.Add(new AuthorizationStepResult("Permission Exists", StepResultNames.Pass));

        // Step 3: RBAC
        var hasPermission = _rbac.HasPermission(user.Id, request.Permission);
        var roleUsed = _rbac.GetGrantingRoleName(user.Id, request.Permission);
        steps.Add(new AuthorizationStepResult("RBAC", hasPermission ? StepResultNames.Pass : StepResultNames.Fail,
            hasPermission ? $"Role {roleUsed} has {request.Permission}" : $"No role grants {request.Permission}"));
        if (!hasPermission)
        {
            reasons.Add($"User does not have {request.Permission}");
            return Finalize(request, DecisionNames.Deny, reasons, steps, null, roleUsed);
        }
        reasons.Add($"Role {roleUsed} has {request.Permission}");

        // Step 4: resource exists (only when a specific resource instance was requested)
        Models.Resource? resource = null;
        if (!string.IsNullOrEmpty(request.ResourceId))
        {
            resource = _resourceService.GetById(request.ResourceId);
            steps.Add(new AuthorizationStepResult("Resource Exists", resource is not null ? StepResultNames.Pass : StepResultNames.Fail));
            if (resource is null)
            {
                reasons.Add($"Resource '{request.ResourceId}' does not exist");
                return Finalize(request, DecisionNames.Deny, reasons, steps, null, roleUsed);
            }
        }
        else
        {
            steps.Add(new AuthorizationStepResult("Resource Exists", StepResultNames.NotApplicable, "No specific resource instance requested"));
        }

        // Step 5: scope
        var scopeContext = new AuthorizationContext { User = user, Permission = request.Permission, Resource = resource, RequestContext = request.Context ?? new() };
        var scopeResult = _scopePolicy.Evaluate(scopeContext);
        steps.Add(new AuthorizationStepResult("Scope",
            scopeResult.Decision == PolicyDecision.Allow ? StepResultNames.Pass : StepResultNames.Fail,
            scopeResult.Reason));
        if (scopeResult.Decision != PolicyDecision.Allow)
        {
            reasons.Add(scopeResult.Reason);
            return Finalize(request, DecisionNames.Deny, reasons, steps, _scopePolicy.Name, roleUsed);
        }

        // Steps 6-9: policy evaluation (ABAC / resource relationship / SoD / limit rules live inside the policy)
        var policy = _policyRegistry.GetPolicy(request.Permission);
        var policyContext = new AuthorizationContext { User = user, Permission = request.Permission, Resource = resource, RequestContext = request.Context ?? new() };
        PolicyDecision finalDecision = PolicyDecision.Allow;
        string? policyName = policy?.Name;

        if (policy is not null)
        {
            var result = policy.Evaluate(policyContext);
            steps.AddRange(policyContext.Steps);
            finalDecision = result.Decision;
            policyName = result.PolicyName ?? policy.Name;
            reasons.Add(result.Reason);
        }
        else
        {
            reasons.Add("No additional policy required; RBAC and scope checks are sufficient");
        }
        steps.Add(new AuthorizationStepResult("Policy", policyName ?? "None"));

        // Step 10: final decision
        var decisionName = finalDecision switch
        {
            PolicyDecision.Deny => DecisionNames.Deny,
            PolicyDecision.Mask => DecisionNames.Mask,
            _ => DecisionNames.Allow
        };

        return Finalize(request, decisionName, reasons, steps, policyName, roleUsed);
    }

    public BatchAuthorizationResponse CheckBatch(BatchAuthorizationRequest request)
    {
        var response = new BatchAuthorizationResponse();
        foreach (var check in request.Checks)
        {
            var single = new AuthorizationRequest
            {
                UserId = request.UserId,
                Permission = check.Permission,
                ResourceType = check.ResourceType,
                ResourceId = check.ResourceId,
                Context = request.Context
            };

            var result = Check(single);
            response.Results.Add(new BatchAuthorizationResultItem
            {
                Permission = check.Permission,
                ResourceId = check.ResourceId,
                Allowed = result.Allowed,
                Decision = result.Decision
            });
        }

        return response;
    }

    private AuthorizationResponse Finalize(
        AuthorizationRequest request,
        string decision,
        List<string> reasons,
        List<AuthorizationStepResult> steps,
        string? policyName,
        string? roleUsed)
    {
        var response = new AuthorizationResponse
        {
            Allowed = decision == DecisionNames.Allow,
            Decision = decision,
            Permission = request.Permission,
            Resource = request.ResourceId,
            Reasons = reasons,
            PolicyName = policyName,
            RoleUsed = roleUsed,
            Steps = steps
        };

        var user = _userService.GetById(request.UserId);
        _auditLog.Record(new AuditLogEntry
        {
            Timestamp = DateTime.Now,
            Username = user?.Username ?? request.UserId,
            Permission = request.Permission,
            Resource = request.ResourceId,
            Decision = decision,
            PolicyName = policyName,
            Reasons = reasons
        });

        _logger.LogInformation(
            "Authorization decision: user={User} permission={Permission} resource={Resource} decision={Decision}",
            user?.Username ?? request.UserId, request.Permission, request.ResourceId, decision);

        return response;
    }
}
