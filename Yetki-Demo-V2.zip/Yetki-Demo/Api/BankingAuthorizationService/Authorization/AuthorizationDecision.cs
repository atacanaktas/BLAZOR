namespace BankingAuthorizationService.Authorization;

public enum PolicyDecision
{
    Allow,
    Deny,
    Mask
}

/// <summary>
/// A single named step in the authorization pipeline (e.g. "RBAC", "Scope", "Amount Limit"),
/// recorded so the WinForms Authorization Debug panel can show exactly why a decision was made.
/// </summary>
public class AuthorizationStepResult
{
    public AuthorizationStepResult() { }

    public AuthorizationStepResult(string step, string result, string? detail = null)
    {
        Step = step;
        Result = result;
        Detail = detail;
    }

    public string Step { get; set; } = string.Empty;
    public string Result { get; set; } = string.Empty;
    public string? Detail { get; set; }
}

/// <summary>
/// Result returned by an IPolicy. PolicyName may be overridden by a policy to attribute a
/// specific sub-rule (e.g. MakerCheckerPolicy, VIPBalancePolicy) instead of the policy's own name.
/// </summary>
public class PolicyEvaluationResult
{
    public PolicyDecision Decision { get; set; }
    public string Reason { get; set; } = string.Empty;
    public string? PolicyName { get; set; }

    public static PolicyEvaluationResult Allow(string reason) =>
        new() { Decision = PolicyDecision.Allow, Reason = reason };

    public static PolicyEvaluationResult Deny(string reason, string? policyName = null) =>
        new() { Decision = PolicyDecision.Deny, Reason = reason, PolicyName = policyName };

    public static PolicyEvaluationResult Mask(string reason, string? policyName = null) =>
        new() { Decision = PolicyDecision.Mask, Reason = reason, PolicyName = policyName };
}
