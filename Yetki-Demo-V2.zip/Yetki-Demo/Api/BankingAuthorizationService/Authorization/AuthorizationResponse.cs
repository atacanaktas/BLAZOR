namespace BankingAuthorizationService.Authorization;

public class AuthorizationResponse
{
    /// <summary>True only for an ALLOW decision. A MASK decision returns false: the caller must
    /// not receive the real value, only that a masked placeholder may be shown.</summary>
    public bool Allowed { get; set; }
    public string Decision { get; set; } = string.Empty;
    public string Permission { get; set; } = string.Empty;
    public string? Resource { get; set; }
    public List<string> Reasons { get; set; } = new();

    // Debug / explainability fields consumed by the WinForms Authorization Debug panel.
    public string? RoleUsed { get; set; }
    public string? PolicyName { get; set; }
    public List<AuthorizationStepResult> Steps { get; set; } = new();
}

public class BatchAuthorizationResultItem
{
    public string Permission { get; set; } = string.Empty;
    public string? ResourceId { get; set; }
    public bool Allowed { get; set; }
    public string Decision { get; set; } = string.Empty;
}

public class BatchAuthorizationResponse
{
    public List<BatchAuthorizationResultItem> Results { get; set; } = new();
}
