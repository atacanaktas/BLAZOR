namespace BankingAuthorizationService.Authorization;

public class AuthorizationRequest
{
    public string UserId { get; set; } = string.Empty;
    public string Permission { get; set; } = string.Empty;
    public string? ResourceType { get; set; }
    public string? ResourceId { get; set; }
    public Dictionary<string, object>? Context { get; set; }
}

public class AuthorizationCheckItem
{
    public string Permission { get; set; } = string.Empty;
    public string? ResourceType { get; set; }
    public string? ResourceId { get; set; }
}

public class BatchAuthorizationRequest
{
    public string UserId { get; set; } = string.Empty;
    public List<AuthorizationCheckItem> Checks { get; set; } = new();
    public Dictionary<string, object>? Context { get; set; }
}
