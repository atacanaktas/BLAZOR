using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Authorization;

/// <summary>
/// Everything a policy needs to evaluate a decision: the subject (User), the requested
/// permission, the target Resource (may be null for screen/list-level checks), free-form
/// request context (ipAddress, deviceId, ...), and an accumulating list of pipeline steps.
/// </summary>
public class AuthorizationContext
{
    public required User User { get; init; }
    public required string Permission { get; init; }
    public Resource? Resource { get; init; }
    public Dictionary<string, object> RequestContext { get; init; } = new();
    public List<AuthorizationStepResult> Steps { get; } = new();

    public void AddStep(string step, string result, string? detail = null)
    {
        Steps.Add(new AuthorizationStepResult(step, result, detail));
    }
}
