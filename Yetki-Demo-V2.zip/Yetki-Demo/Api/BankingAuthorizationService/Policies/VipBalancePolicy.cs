using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;
using BankingAuthorizationService.Rbac;
using BankingAuthorizationService.Resources;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// IF customer.segment == VIP AND user does not have privileged balance access THEN MASK,
/// ELSE ALLOW. Consumed by AccountBalancePolicy as a sub-check so account.balance.view keeps
/// a single registered policy while still surfacing "VIPBalancePolicy" as the deciding rule
/// in the debug panel and audit log.
/// </summary>
public class VipBalancePolicy
{
    private readonly IResourceService _resources;
    private readonly IRbacService _rbac;

    public string Name => "VIPBalancePolicy";

    public VipBalancePolicy(IResourceService resources, IRbacService rbac)
    {
        _resources = resources;
        _rbac = rbac;
    }

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        var account = context.Resource;
        if (account is null || account.Type != ResourceTypes.Account)
        {
            return PolicyEvaluationResult.Allow("No account instance to evaluate");
        }

        var customerId = account.GetAttribute<string>("customerId");
        var customer = customerId is null ? null : _resources.GetById(customerId);
        var isVip = customer is not null &&
                    string.Equals(customer.GetAttribute<string>("segment"), "VIP", StringComparison.OrdinalIgnoreCase);

        if (!isVip)
        {
            context.AddStep("VIP Balance Check", StepResultNames.NotApplicable, "Customer segment is not VIP");
            return PolicyEvaluationResult.Allow("Customer segment is not VIP");
        }

        var hasPrivilegedAccess = _rbac.HasPermission(context.User.Id, PermissionNames.AccountBalanceViewVip);
        context.AddStep(
            "VIP Balance Check",
            hasPrivilegedAccess ? StepResultNames.Pass : StepResultNames.Mask,
            hasPrivilegedAccess
                ? "User has privileged VIP balance access"
                : "User lacks privileged VIP balance access");

        return hasPrivilegedAccess
            ? PolicyEvaluationResult.Allow("User has privileged access to VIP customer balances")
            : PolicyEvaluationResult.Mask("Balance is masked because customer segment is VIP", Name);
    }
}
