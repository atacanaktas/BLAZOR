using BankingAuthorizationService.Authorization;

namespace BankingAuthorizationService.Policies;

public class TransactionReadPolicy : IPolicy
{
    public string Name => "TransactionReadPolicy";

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        return PolicyEvaluationResult.Allow("Role has transaction.read and transaction is within scope");
    }
}
