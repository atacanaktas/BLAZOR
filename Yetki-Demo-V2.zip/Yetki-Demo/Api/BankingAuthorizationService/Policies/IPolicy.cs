using BankingAuthorizationService.Authorization;

namespace BankingAuthorizationService.Policies;

public interface IPolicy
{
    string Name { get; }

    PolicyEvaluationResult Evaluate(AuthorizationContext context);
}
