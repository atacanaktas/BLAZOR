using BankingAuthorizationService.Common;

namespace BankingAuthorizationService.Policies;

public interface IPolicyRegistry
{
    IPolicy? GetPolicy(string permission);
}

/// <summary>
/// Maps a permission to the specific policy that governs it. Permissions with no entry here
/// are still gated by RBAC + company scope (steps 3 and 5 of the pipeline); the registry only
/// adds instance-level ABAC/SoD/limit rules on top for permissions that need them.
/// </summary>
public class PolicyRegistry : IPolicyRegistry
{
    private readonly Dictionary<string, IPolicy> _map;

    public PolicyRegistry(
        AccountReadPolicy accountReadPolicy,
        AccountOpenPolicy accountOpenPolicy,
        AccountBalancePolicy accountBalancePolicy,
        TransactionReadPolicy transactionReadPolicy,
        DepositAccountOpenPolicy depositAccountOpenPolicy,
        DepositAccountApprovePolicy depositAccountApprovePolicy,
        DepositAccountRejectPolicy depositAccountRejectPolicy,
        PaymentCreatePolicy paymentCreatePolicy,
        PaymentApprovePolicy paymentApprovePolicy,
        PaymentRejectPolicy paymentRejectPolicy,
        PaymentExecutePolicy paymentExecutePolicy,
        TransferCreatePolicy transferCreatePolicy)
    {
        _map = new Dictionary<string, IPolicy>
        {
            [PermissionNames.AccountRead] = accountReadPolicy,
            [PermissionNames.AccountOpen] = accountOpenPolicy,
            [PermissionNames.AccountBalanceView] = accountBalancePolicy,
            [PermissionNames.TransactionRead] = transactionReadPolicy,
            [PermissionNames.DepositAccountOpen] = depositAccountOpenPolicy,
            [PermissionNames.DepositAccountApprove] = depositAccountApprovePolicy,
            [PermissionNames.DepositAccountReject] = depositAccountRejectPolicy,
            [PermissionNames.PaymentCreate] = paymentCreatePolicy,
            [PermissionNames.PaymentApprove] = paymentApprovePolicy,
            [PermissionNames.PaymentReject] = paymentRejectPolicy,
            [PermissionNames.PaymentExecute] = paymentExecutePolicy,
            [PermissionNames.TransferCreate] = transferCreatePolicy
        };
    }

    public IPolicy? GetPolicy(string permission) => _map.GetValueOrDefault(permission);
}
