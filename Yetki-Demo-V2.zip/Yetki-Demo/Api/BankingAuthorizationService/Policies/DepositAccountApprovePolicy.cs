using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;
using BankingAuthorizationService.Rbac;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Rule: user has deposit_account.approve AND the deposit account is within scope (checked
/// generically by the engine) AND status == PENDING_CLOSURE AND createdBy != user.id
/// (maker/checker) AND principal &lt;= user's deposit_account.approve limit.
/// Mirrors PaymentApprovePolicy exactly, but for the time-deposit closure workflow - proof
/// that the same MakerCheckerPolicy and pipeline shape apply across unrelated resource types.
/// </summary>
public class DepositAccountApprovePolicy : IPolicy
{
    private readonly MakerCheckerPolicy _makerChecker;
    private readonly IRbacService _rbac;

    public string Name => "DepositAccountApprovePolicy";

    public DepositAccountApprovePolicy(MakerCheckerPolicy makerChecker, IRbacService rbac)
    {
        _makerChecker = makerChecker;
        _rbac = rbac;
    }

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        var depositAccount = context.Resource;
        if (depositAccount is null)
        {
            return PolicyEvaluationResult.Deny("No deposit account specified to approve");
        }

        var status = depositAccount.GetAttribute<string>("status");
        var statusOk = string.Equals(status, DepositAccountStatus.PendingClosure, StringComparison.OrdinalIgnoreCase);
        context.AddStep("Deposit Account Status", statusOk ? StepResultNames.Pass : StepResultNames.Fail, $"Status is {status}");
        if (!statusOk)
        {
            return PolicyEvaluationResult.Deny($"Deposit account is not pending closure (status: {status})", Name);
        }

        var isMaker = _makerChecker.IsMaker(context);
        context.AddStep("Maker/Checker", isMaker ? StepResultNames.Fail : StepResultNames.Pass);
        if (isMaker)
        {
            return PolicyEvaluationResult.Deny("Maker cannot approve own deposit account closure", "MakerCheckerPolicy");
        }

        var principal = depositAccount.GetAttribute<decimal>("principal");
        var limit = _rbac.GetApprovalLimit(context.User.Id, PermissionNames.DepositAccountApprove);
        var withinLimit = limit is null || principal <= limit;
        context.AddStep(
            "Amount Limit",
            withinLimit ? StepResultNames.Pass : StepResultNames.Fail,
            limit is null ? "Approval limit is unlimited" : $"Limit is {limit:N0}, principal is {principal:N0}");
        if (!withinLimit)
        {
            return PolicyEvaluationResult.Deny("Deposit account principal exceeds approval limit", Name);
        }

        return PolicyEvaluationResult.Allow("Deposit account is pending closure, not self-requested, and within approval limit");
    }
}
