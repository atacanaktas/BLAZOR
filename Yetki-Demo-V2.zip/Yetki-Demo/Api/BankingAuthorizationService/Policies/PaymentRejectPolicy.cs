using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Rejecting is a checker action too: rule mirrors PaymentApprovePolicy minus the amount limit -
/// payment must be PENDING_APPROVAL and the rejecter must not be the maker.
/// </summary>
public class PaymentRejectPolicy : IPolicy
{
    private readonly MakerCheckerPolicy _makerChecker;

    public string Name => "PaymentRejectPolicy";

    public PaymentRejectPolicy(MakerCheckerPolicy makerChecker)
    {
        _makerChecker = makerChecker;
    }

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        var payment = context.Resource;
        if (payment is null)
        {
            return PolicyEvaluationResult.Deny("No payment specified to reject");
        }

        var status = payment.GetAttribute<string>("status");
        var statusOk = string.Equals(status, PaymentStatus.PendingApproval, StringComparison.OrdinalIgnoreCase);
        context.AddStep("Payment Status", statusOk ? StepResultNames.Pass : StepResultNames.Fail, $"Status is {status}");
        if (!statusOk)
        {
            return PolicyEvaluationResult.Deny($"Payment is not pending approval (status: {status})", Name);
        }

        var isMaker = _makerChecker.IsMaker(context);
        context.AddStep("Maker/Checker", isMaker ? StepResultNames.Fail : StepResultNames.Pass);
        if (isMaker)
        {
            return PolicyEvaluationResult.Deny("Maker cannot reject own payment", MakerCheckerPolicyName);
        }

        return PolicyEvaluationResult.Allow("Payment is pending approval and rejecter is different from the maker");
    }

    private const string MakerCheckerPolicyName = "MakerCheckerPolicy";
}
