using BankingAuthorizationService.Abac;
using BankingAuthorizationService.Authorization;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Rule: user has account.open AND the new account's company is within user's scope.
/// Opening happens before the account resource exists, so the target company comes from
/// request context (falls back to allow when none is given, e.g. a screen-level capability
/// probe with no specific company chosen yet).
/// </summary>
public class AccountOpenPolicy : IPolicy
{
    private readonly IAbacEvaluator _abac;

    public string Name => "AccountOpenPolicy";

    public AccountOpenPolicy(IAbacEvaluator abac)
    {
        _abac = abac;
    }

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        if (context.Resource is not null)
        {
            return _abac.IsWithinScope(context.User, context.Resource)
                ? PolicyEvaluationResult.Allow("Account company is within user's scope")
                : PolicyEvaluationResult.Deny("Account company is outside user's scope");
        }

        if (context.User.CompanyScope == "*")
        {
            return PolicyEvaluationResult.Allow("User has global scope");
        }

        if (context.RequestContext.TryGetValue("companyId", out var companyId) && companyId is not null)
        {
            var matches = string.Equals(companyId.ToString(), context.User.CompanyScope, StringComparison.OrdinalIgnoreCase);
            return matches
                ? PolicyEvaluationResult.Allow("Target company is within user's scope")
                : PolicyEvaluationResult.Deny("Target company is outside user's scope");
        }

        return PolicyEvaluationResult.Allow("No target company specified; defaulting to user's own scope");
    }
}
