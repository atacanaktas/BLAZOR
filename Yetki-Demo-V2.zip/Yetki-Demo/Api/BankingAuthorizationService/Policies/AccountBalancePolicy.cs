using BankingAuthorizationService.Authorization;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Registered for account.balance.view. Delegates the VIP-masking sub-rule to VipBalancePolicy.
/// </summary>
public class AccountBalancePolicy : IPolicy
{
    private readonly VipBalancePolicy _vipBalancePolicy;

    public string Name => "AccountBalanceViewPolicy";

    public AccountBalancePolicy(VipBalancePolicy vipBalancePolicy)
    {
        _vipBalancePolicy = vipBalancePolicy;
    }

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        return _vipBalancePolicy.Evaluate(context);
    }
}
