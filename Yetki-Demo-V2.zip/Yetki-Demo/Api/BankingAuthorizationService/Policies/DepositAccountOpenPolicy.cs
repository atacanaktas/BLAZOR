using BankingAuthorizationService.Abac;
using BankingAuthorizationService.Authorization;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Rule: user has deposit_account.open AND the new deposit account's company is within scope.
/// Same shape as AccountOpenPolicy/PaymentCreatePolicy - opening precedes the resource existing.
/// </summary>
public class DepositAccountOpenPolicy : IPolicy
{
    private readonly IAbacEvaluator _abac;

    public string Name => "DepositAccountOpenPolicy";

    public DepositAccountOpenPolicy(IAbacEvaluator abac)
    {
        _abac = abac;
    }

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        if (context.Resource is not null)
        {
            return _abac.IsWithinScope(context.User, context.Resource)
                ? PolicyEvaluationResult.Allow("Deposit account company is within user's scope")
                : PolicyEvaluationResult.Deny("Deposit account company is outside user's scope");
        }

        if (context.User.CompanyScope == "*")
        {
            return PolicyEvaluationResult.Allow("User has global scope");
        }

        if (context.RequestContext.TryGetValue("companyId", out var companyId) && companyId is not null)
        {
            var matches = string.Equals(companyId.ToString(), context.User.CompanyScope, StringComparison.OrdinalIgnoreCase);
            return matches
                ? PolicyEvaluationResult.Allow("Target company is within user's scope")
                : PolicyEvaluationResult.Deny("Target company is outside user's scope");
        }

        return PolicyEvaluationResult.Allow("No target company specified; defaulting to user's own scope");
    }
}
