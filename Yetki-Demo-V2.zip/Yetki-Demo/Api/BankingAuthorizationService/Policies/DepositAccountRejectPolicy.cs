using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Rejecting a closure request is a checker action too: status must be PENDING_CLOSURE and the
/// rejecter must not be the maker. No amount limit applies to a rejection.
/// </summary>
public class DepositAccountRejectPolicy : IPolicy
{
    private readonly MakerCheckerPolicy _makerChecker;

    public string Name => "DepositAccountRejectPolicy";

    public DepositAccountRejectPolicy(MakerCheckerPolicy makerChecker)
    {
        _makerChecker = makerChecker;
    }

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        var depositAccount = context.Resource;
        if (depositAccount is null)
        {
            return PolicyEvaluationResult.Deny("No deposit account specified to reject");
        }

        var status = depositAccount.GetAttribute<string>("status");
        var statusOk = string.Equals(status, DepositAccountStatus.PendingClosure, StringComparison.OrdinalIgnoreCase);
        context.AddStep("Deposit Account Status", statusOk ? StepResultNames.Pass : StepResultNames.Fail, $"Status is {status}");
        if (!statusOk)
        {
            return PolicyEvaluationResult.Deny($"Deposit account is not pending closure (status: {status})", Name);
        }

        var isMaker = _makerChecker.IsMaker(context);
        context.AddStep("Maker/Checker", isMaker ? StepResultNames.Fail : StepResultNames.Pass);
        if (isMaker)
        {
            return PolicyEvaluationResult.Deny("Maker cannot reject own deposit account closure request", "MakerCheckerPolicy");
        }

        return PolicyEvaluationResult.Allow("Deposit account is pending closure and rejecter is different from the maker");
    }
}
