using BankingAuthorizationService.Authorization;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Rule: user has account.read AND account belongs to user's company scope.
/// The scope half is already enforced generically by the engine (CompanyScopePolicy) before
/// this policy runs, so this simply confirms the instance-level allow.
/// </summary>
public class AccountReadPolicy : IPolicy
{
    public string Name => "AccountReadPolicy";

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        return PolicyEvaluationResult.Allow("Role has account.read and account is within scope");
    }
}
