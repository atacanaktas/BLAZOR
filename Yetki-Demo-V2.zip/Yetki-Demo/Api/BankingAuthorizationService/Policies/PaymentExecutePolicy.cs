using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Rule: user has payment.execute AND payment is within scope (checked generically by the
/// engine) AND payment.status == APPROVED (a payment must clear approval before execution).
/// </summary>
public class PaymentExecutePolicy : IPolicy
{
    public string Name => "PaymentExecutePolicy";

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        var payment = context.Resource;
        if (payment is null)
        {
            return PolicyEvaluationResult.Deny("No payment specified to execute");
        }

        var status = payment.GetAttribute<string>("status");
        var statusOk = string.Equals(status, PaymentStatus.Approved, StringComparison.OrdinalIgnoreCase);
        context.AddStep("Payment Status", statusOk ? StepResultNames.Pass : StepResultNames.Fail, $"Status is {status}");

        return statusOk
            ? PolicyEvaluationResult.Allow("Payment is approved and ready for execution")
            : PolicyEvaluationResult.Deny($"Payment must be APPROVED before execution (status: {status})", Name);
    }
}
