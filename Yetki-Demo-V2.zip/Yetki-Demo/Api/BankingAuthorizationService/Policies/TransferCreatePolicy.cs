using BankingAuthorizationService.Authorization;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Rule: user has transfer.create AND the source account is within user's scope.
/// The scope half is already enforced generically by the engine before this policy runs.
/// </summary>
public class TransferCreatePolicy : IPolicy
{
    public string Name => "TransferCreatePolicy";

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        return PolicyEvaluationResult.Allow("Role has transfer.create and source account is within scope");
    }
}
