using BankingAuthorizationService.Abac;
using BankingAuthorizationService.Authorization;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Rule: user has payment.create AND payment company is within user's scope.
/// Creation happens before a payment resource exists, so when no resource is supplied the
/// target company comes from request context (falls back to the user's own scope in the demo).
/// </summary>
public class PaymentCreatePolicy : IPolicy
{
    private readonly IAbacEvaluator _abac;

    public string Name => "PaymentCreatePolicy";

    public PaymentCreatePolicy(IAbacEvaluator abac)
    {
        _abac = abac;
    }

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        if (context.Resource is not null)
        {
            return _abac.IsWithinScope(context.User, context.Resource)
                ? PolicyEvaluationResult.Allow("Payment company is within user's scope")
                : PolicyEvaluationResult.Deny("Payment company is outside user's scope");
        }

        if (context.User.CompanyScope == "*")
        {
            return PolicyEvaluationResult.Allow("User has global scope");
        }

        if (context.RequestContext.TryGetValue("companyId", out var companyId) && companyId is not null)
        {
            var matches = string.Equals(companyId.ToString(), context.User.CompanyScope, StringComparison.OrdinalIgnoreCase);
            return matches
                ? PolicyEvaluationResult.Allow("Target company is within user's scope")
                : PolicyEvaluationResult.Deny("Target company is outside user's scope");
        }

        return PolicyEvaluationResult.Allow("No target company specified; defaulting to user's own scope");
    }
}
