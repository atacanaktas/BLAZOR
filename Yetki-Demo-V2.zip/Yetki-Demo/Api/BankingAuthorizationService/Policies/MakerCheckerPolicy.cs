using BankingAuthorizationService.Authorization;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Separation-of-duties sub-check reused by PaymentApprovePolicy (and any future approve-style
/// policy): the user who created ("made") a resource may not also approve ("check") it.
/// </summary>
public class MakerCheckerPolicy
{
    public string Name => "MakerCheckerPolicy";

    /// <summary>True when the current subject is also the resource's recorded maker.</summary>
    public bool IsMaker(AuthorizationContext context)
    {
        var createdBy = context.Resource?.GetAttribute<string>("createdBy");
        return createdBy is not null && string.Equals(createdBy, context.User.Id, StringComparison.OrdinalIgnoreCase);
    }

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        if (context.Resource?.GetAttribute<string>("createdBy") is null)
        {
            return PolicyEvaluationResult.Allow("Resource has no maker recorded");
        }

        return IsMaker(context)
            ? PolicyEvaluationResult.Deny("Maker cannot approve own payment", Name)
            : PolicyEvaluationResult.Allow("Approver is different from the maker");
    }
}
