using BankingAuthorizationService.Abac;
using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;

namespace BankingAuthorizationService.Policies;

/// <summary>
/// Cross-cutting scope check applied by the engine to every resource-bound permission,
/// before any permission-specific policy runs. Compares resource.companyId to user.scope.
/// </summary>
public class CompanyScopePolicy : IPolicy
{
    private readonly IAbacEvaluator _abac;

    public string Name => "CompanyScopePolicy";

    public CompanyScopePolicy(IAbacEvaluator abac)
    {
        _abac = abac;
    }

    public PolicyEvaluationResult Evaluate(AuthorizationContext context)
    {
        if (context.Resource is null)
        {
            return PolicyEvaluationResult.Allow("No resource instance to scope-check");
        }

        var inScope = _abac.IsWithinScope(context.User, context.Resource);
        return inScope
            ? PolicyEvaluationResult.Allow("Resource belongs to user's company scope")
            : PolicyEvaluationResult.Deny("Resource is outside user's company scope", Name);
    }
}
