namespace BankingAuthorizationService.Screens;

public interface IScreenCapabilityService
{
    ScreenCapabilitiesResponse? GetCapabilities(string screen, string userId, string? resourceId);
}
