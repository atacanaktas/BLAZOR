using BankingAuthorizationService.Common;

namespace BankingAuthorizationService.Screens;

public class ScreenDefinition
{
    public string ResourceType { get; init; } = string.Empty;
    public Dictionary<string, string> Capabilities { get; init; } = new();
}

/// <summary>
/// Screen -> Capability -> Permission map. WinForms never talks about permissions directly;
/// it asks "can I show this screen's capabilities for this resource?" and the server answers.
/// A single screen can, and typically does, depend on more than one permission.
/// </summary>
public static class ScreenCapabilityRegistry
{
    public static readonly IReadOnlyDictionary<string, ScreenDefinition> Screens = new Dictionary<string, ScreenDefinition>
    {
        ["dashboard"] = new ScreenDefinition
        {
            ResourceType = string.Empty,
            Capabilities = new Dictionary<string, string>
            {
                ["view_dashboard"] = PermissionNames.CustomerRead // any authenticated finance user can see the dashboard
            }
        },
        ["customers"] = new ScreenDefinition
        {
            ResourceType = ResourceTypes.Customer,
            Capabilities = new Dictionary<string, string>
            {
                ["view_customer_list"] = PermissionNames.CustomerRead,
                ["view_phone"] = PermissionNames.CustomerPhoneView,
                ["view_identity"] = PermissionNames.CustomerIdentityView,
                ["create_customer"] = PermissionNames.CustomerCreate,
                ["update_customer"] = PermissionNames.CustomerUpdate
            }
        },
        ["accounts"] = new ScreenDefinition
        {
            ResourceType = ResourceTypes.Account,
            Capabilities = new Dictionary<string, string>
            {
                ["view_account_list"] = PermissionNames.AccountRead,
                ["open_account"] = PermissionNames.AccountOpen
            }
        },
        ["account-detail"] = new ScreenDefinition
        {
            ResourceType = ResourceTypes.Account,
            Capabilities = new Dictionary<string, string>
            {
                ["view_account"] = PermissionNames.AccountRead,
                ["view_balance"] = PermissionNames.AccountBalanceView,
                ["view_transactions"] = PermissionNames.TransactionRead,
                ["create_transfer"] = PermissionNames.TransferCreate,
                ["download_statement"] = PermissionNames.StatementDownload,
                ["close_account"] = PermissionNames.AccountClose
            }
        },
        ["deposit-accounts"] = new ScreenDefinition
        {
            ResourceType = ResourceTypes.DepositAccount,
            Capabilities = new Dictionary<string, string>
            {
                ["view_deposit_accounts"] = PermissionNames.DepositAccountRead,
                ["open_deposit_account"] = PermissionNames.DepositAccountOpen,
                ["request_closure"] = PermissionNames.DepositAccountClose,
                ["approve_closure"] = PermissionNames.DepositAccountApprove,
                ["reject_closure"] = PermissionNames.DepositAccountReject
            }
        },
        ["payments"] = new ScreenDefinition
        {
            ResourceType = ResourceTypes.Payment,
            Capabilities = new Dictionary<string, string>
            {
                ["view_payments"] = PermissionNames.PaymentRead,
                ["create_payment"] = PermissionNames.PaymentCreate,
                ["submit_payment"] = PermissionNames.PaymentSubmit,
                ["approve_payment"] = PermissionNames.PaymentApprove,
                ["reject_payment"] = PermissionNames.PaymentReject,
                ["execute_payment"] = PermissionNames.PaymentExecute,
                ["cancel_payment"] = PermissionNames.PaymentCancel
            }
        },
        ["transfers"] = new ScreenDefinition
        {
            ResourceType = ResourceTypes.Transfer,
            Capabilities = new Dictionary<string, string>
            {
                ["view_transfers"] = PermissionNames.TransferRead,
                ["create_transfer"] = PermissionNames.TransferCreate,
                ["approve_transfer"] = PermissionNames.TransferApprove,
                ["execute_transfer"] = PermissionNames.TransferExecute
            }
        },
        ["reports"] = new ScreenDefinition
        {
            ResourceType = string.Empty,
            Capabilities = new Dictionary<string, string>
            {
                ["view_reports"] = PermissionNames.ReportRead,
                ["export_reports"] = PermissionNames.ReportExport
            }
        },
        ["audit"] = new ScreenDefinition
        {
            ResourceType = string.Empty,
            Capabilities = new Dictionary<string, string>
            {
                ["view_audit_log"] = PermissionNames.AuditLogRead
            }
        },
        ["administration"] = new ScreenDefinition
        {
            ResourceType = string.Empty,
            Capabilities = new Dictionary<string, string>
            {
                ["view_roles"] = PermissionNames.RoleRead,
                ["view_users"] = PermissionNames.UserRead
            }
        }
    };
}
