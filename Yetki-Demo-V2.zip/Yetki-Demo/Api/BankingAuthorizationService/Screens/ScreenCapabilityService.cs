using BankingAuthorizationService.Authorization;

namespace BankingAuthorizationService.Screens;

public class ScreenCapabilityService : IScreenCapabilityService
{
    private readonly IAuthorizationEngine _engine;

    public ScreenCapabilityService(IAuthorizationEngine engine)
    {
        _engine = engine;
    }

    public ScreenCapabilitiesResponse? GetCapabilities(string screen, string userId, string? resourceId)
    {
        if (!ScreenCapabilityRegistry.Screens.TryGetValue(screen, out var definition))
        {
            return null;
        }

        var response = new ScreenCapabilitiesResponse { Screen = screen };

        foreach (var (capability, permission) in definition.Capabilities)
        {
            var result = _engine.Check(new AuthorizationRequest
            {
                UserId = userId,
                Permission = permission,
                ResourceType = definition.ResourceType,
                ResourceId = resourceId
            });

            response.Capabilities[capability] = result.Allowed;
        }

        return response;
    }
}
