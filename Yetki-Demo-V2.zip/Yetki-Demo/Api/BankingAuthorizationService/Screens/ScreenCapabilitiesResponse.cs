namespace BankingAuthorizationService.Screens;

public class ScreenCapabilitiesResponse
{
    public string Screen { get; set; } = string.Empty;
    public Dictionary<string, bool> Capabilities { get; set; } = new();
}
