using BankingAuthorizationService.Common;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.MockData;

public static class MockUsers
{
    public static List<User> GetAll() => new()
    {
        new User
        {
            Id = UserIds.GiseAsistani,
            Username = "elif.yildiz",
            DisplayName = "Elif Yıldız",
            RoleIds = new List<string> { RoleIds.GiseAsistani },
            CompanyScope = "company:10"
        },
        new User
        {
            Id = UserIds.GiseYetkilisi,
            Username = "mert.kaya",
            DisplayName = "Mert Kaya",
            RoleIds = new List<string> { RoleIds.GiseYetkilisi },
            CompanyScope = "company:10"
        },
        new User
        {
            Id = UserIds.BmsYetkilisi,
            Username = "zeynep.arslan",
            DisplayName = "Zeynep Arslan",
            RoleIds = new List<string> { RoleIds.BirmeyselMusteriYetkilisi },
            CompanyScope = "company:10"
        },
        new User
        {
            Id = UserIds.SubeMuduru,
            Username = "burak.sahin",
            DisplayName = "Burak Şahin",
            RoleIds = new List<string> { RoleIds.SubeMuduru },
            CompanyScope = "company:10"
        },
        new User
        {
            Id = UserIds.BmsAsistani,
            Username = "deniz.koc",
            DisplayName = "Deniz Koç",
            RoleIds = new List<string> { RoleIds.BirmeyselMusteriAsistani },
            CompanyScope = "company:10"
        }
    };
}
