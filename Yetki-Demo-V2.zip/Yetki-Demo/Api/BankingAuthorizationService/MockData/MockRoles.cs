using BankingAuthorizationService.Common;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.MockData;

public static class MockRoles
{
    public static List<Role> GetAll() => new()
    {
        // Gişe Asistanı: junior teller - prepares/creates payments and transfers (maker),
        // read-only elsewhere. Cannot approve anything.
        new Role
        {
            Id = RoleIds.GiseAsistani,
            Name = "GiseAsistani",
            PermissionIds = new List<string>
            {
                PermissionNames.CustomerRead,
                PermissionNames.AccountRead,
                PermissionNames.AccountBalanceView,
                PermissionNames.TransactionRead,
                PermissionNames.PaymentRead,
                PermissionNames.PaymentCreate,
                PermissionNames.PaymentSubmit,
                PermissionNames.PaymentCancel,
                PermissionNames.TransferRead,
                PermissionNames.TransferCreate,
                PermissionNames.StatementRead
            }
        },

        // Gişe Yetkilisi: senior teller - opens/closes current accounts, approves/rejects/
        // executes payments and transfers created by a Gişe Asistanı (checker), up to a
        // teller-level approval limit.
        new Role
        {
            Id = RoleIds.GiseYetkilisi,
            Name = "GiseYetkilisi",
            ApprovalLimit = 300_000m,
            PermissionIds = new List<string>
            {
                PermissionNames.CustomerRead,
                PermissionNames.AccountRead,
                PermissionNames.AccountOpen,
                PermissionNames.AccountClose,
                PermissionNames.AccountBalanceView,
                PermissionNames.TransactionRead,
                PermissionNames.PaymentRead,
                PermissionNames.PaymentApprove,
                PermissionNames.PaymentReject,
                PermissionNames.PaymentExecute,
                PermissionNames.TransferRead,
                PermissionNames.TransferApprove,
                PermissionNames.TransferExecute,
                PermissionNames.StatementRead,
                PermissionNames.StatementDownload
            }
        },

        // Bireysel Müşteri Asistanı: supports the retail relationship - opens time deposit
        // accounts and requests their closure (maker). Cannot approve a closure or see
        // identity/VIP-privileged data.
        new Role
        {
            Id = RoleIds.BirmeyselMusteriAsistani,
            Name = "BireyselMusteriAsistani",
            PermissionIds = new List<string>
            {
                PermissionNames.CustomerRead,
                PermissionNames.CustomerPhoneView,
                PermissionNames.AccountRead,
                PermissionNames.AccountBalanceView,
                PermissionNames.DepositAccountRead,
                PermissionNames.DepositAccountOpen,
                PermissionNames.DepositAccountClose,
                PermissionNames.TransactionRead,
                PermissionNames.ReportRead
            }
        },

        // Bireysel Müşteri Yetkilisi: senior retail relationship officer - approves/rejects
        // time deposit closures (checker) up to a higher approval limit, sees VIP balances
        // and customer identity.
        new Role
        {
            Id = RoleIds.BirmeyselMusteriYetkilisi,
            Name = "BireyselMusteriYetkilisi",
            ApprovalLimit = 750_000m,
            PermissionIds = new List<string>
            {
                PermissionNames.CustomerRead,
                PermissionNames.CustomerPhoneView,
                PermissionNames.CustomerIdentityView,
                PermissionNames.CustomerUpdate,
                PermissionNames.AccountRead,
                PermissionNames.AccountBalanceView,
                PermissionNames.AccountBalanceViewVip,
                PermissionNames.DepositAccountRead,
                PermissionNames.DepositAccountApprove,
                PermissionNames.DepositAccountReject,
                PermissionNames.TransactionRead,
                PermissionNames.ReportRead,
                PermissionNames.ReportExport
            }
        },

        // Şube Müdürü: full branch authority. Unlimited approval, every operational
        // permission - but still scoped to their own branch (company:10). The wildcard
        // shows the RBAC "*" mechanic; scope still applies independently of it.
        new Role
        {
            Id = RoleIds.SubeMuduru,
            Name = "SubeMuduru",
            ApprovalLimit = null,
            PermissionIds = new List<string> { PermissionNames.Wildcard }
        }
    };
}
