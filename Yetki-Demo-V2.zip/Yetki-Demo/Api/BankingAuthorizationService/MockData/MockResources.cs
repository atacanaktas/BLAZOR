using BankingAuthorizationService.Common;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.MockData;

/// <summary>
/// In-memory, mutable store of all mock resources (customers, accounts, deposit accounts,
/// payments, transactions). A single shared list keeps the demo consistent with the spec's
/// unified Resource model: every business object is a Resource with a Type and an Attributes
/// bag, so lifecycle actions (approve/reject/close/...) simply mutate the "status" attribute
/// in place.
///
/// Two independent maker/checker pairs are seeded on purpose:
///   Payments:        Gişe Asistanı (maker: create/submit) -> Gişe Yetkilisi (checker: approve/
///                     reject/execute, 300.000 TRY limit)
///   Deposit accounts: Bireysel Müşteri Asistanı (maker: open/request closure) -> Bireysel
///                     Müşteri Yetkilisi (checker: approve/reject closure, 750.000 TRY limit)
/// Şube Müdürü (wildcard permission, company:10 scope, unlimited) can resolve anything within
/// their own branch but is still denied on company:20 resources - proving scope applies even
/// to a wildcard role.
/// </summary>
public class MockResourceStore
{
    private readonly List<Resource> _resources;
    private readonly object _lock = new();

    public MockResourceStore()
    {
        _resources = BuildSeedData();
    }

    public IReadOnlyList<Resource> All
    {
        get { lock (_lock) { return _resources.ToList(); } }
    }

    public Resource? GetById(string id)
    {
        lock (_lock)
        {
            return _resources.FirstOrDefault(r => r.Id == id);
        }
    }

    public IReadOnlyList<Resource> GetByType(string type)
    {
        lock (_lock)
        {
            return _resources.Where(r => r.Type == type).ToList();
        }
    }

    public void Add(Resource resource)
    {
        lock (_lock)
        {
            _resources.Add(resource);
        }
    }

    private static List<Resource> BuildSeedData()
    {
        var list = new List<Resource>();

        // --- Customers (company:10 = own branch, company:20 = another branch) ---
        list.Add(new Resource
        {
            Id = "customer:1001",
            Type = ResourceTypes.Customer,
            Attributes = new Dictionary<string, object>
            {
                ["name"] = "Ali Veli",
                ["phone"] = "+90 555 111 22 33",
                ["email"] = "ali.veli@example.com",
                ["nationalId"] = "12345678901",
                ["segment"] = "NORMAL",
                ["riskLevel"] = "LOW",
                ["companyId"] = "company:10"
            }
        });
        list.Add(new Resource
        {
            Id = "customer:1002",
            Type = ResourceTypes.Customer,
            Attributes = new Dictionary<string, object>
            {
                ["name"] = "Zeynep Kaya",
                ["phone"] = "+90 555 222 33 44",
                ["email"] = "zeynep.kaya@example.com",
                ["nationalId"] = "22345678901",
                ["segment"] = "VIP",
                ["riskLevel"] = "HIGH",
                ["companyId"] = "company:10"
            }
        });
        list.Add(new Resource
        {
            Id = "customer:1003",
            Type = ResourceTypes.Customer,
            Attributes = new Dictionary<string, object>
            {
                ["name"] = "Can Demir",
                ["phone"] = "+90 555 333 44 55",
                ["email"] = "can.demir@example.com",
                ["nationalId"] = "32345678901",
                ["segment"] = "NORMAL",
                ["riskLevel"] = "LOW",
                ["companyId"] = "company:10"
            }
        });
        list.Add(new Resource
        {
            Id = "customer:1004",
            Type = ResourceTypes.Customer,
            Attributes = new Dictionary<string, object>
            {
                ["name"] = "Selin Aydın",
                ["phone"] = "+90 555 444 55 66",
                ["email"] = "selin.aydin@example.com",
                ["nationalId"] = "42345678901",
                ["segment"] = "NORMAL",
                ["riskLevel"] = "LOW",
                ["companyId"] = "company:20" // another branch - scope demo
            }
        });

        // --- Current (vadesiz) accounts ---
        list.Add(new Resource
        {
            Id = "account:2001",
            Type = ResourceTypes.Account,
            ParentId = "customer:1001",
            Attributes = new Dictionary<string, object>
            {
                ["customerId"] = "customer:1001",
                ["companyId"] = "company:10",
                ["currency"] = "TRY",
                ["balance"] = 150000m,
                ["status"] = AccountStatus.Active
            }
        });
        list.Add(new Resource
        {
            Id = "account:2002",
            Type = ResourceTypes.Account,
            ParentId = "customer:1002",
            Attributes = new Dictionary<string, object>
            {
                ["customerId"] = "customer:1002",
                ["companyId"] = "company:10",
                ["currency"] = "TRY",
                ["balance"] = 8500000m,
                ["status"] = AccountStatus.Active
            }
        });
        list.Add(new Resource
        {
            Id = "account:2003",
            Type = ResourceTypes.Account,
            ParentId = "customer:1003",
            Attributes = new Dictionary<string, object>
            {
                ["customerId"] = "customer:1003",
                ["companyId"] = "company:10",
                ["currency"] = "TRY",
                ["balance"] = 300000m,
                ["status"] = AccountStatus.Active
            }
        });
        list.Add(new Resource
        {
            Id = "account:2004",
            Type = ResourceTypes.Account,
            ParentId = "customer:1004",
            Attributes = new Dictionary<string, object>
            {
                ["customerId"] = "customer:1004",
                ["companyId"] = "company:20", // another branch - scope demo
                ["currency"] = "TRY",
                ["balance"] = 75000m,
                ["status"] = AccountStatus.Active
            }
        });

        // --- Time deposit (vadeli) accounts ---
        list.Add(new Resource
        {
            Id = "depositaccount:6001",
            Type = ResourceTypes.DepositAccount,
            ParentId = "customer:1001",
            Attributes = new Dictionary<string, object>
            {
                ["customerId"] = "customer:1001",
                ["companyId"] = "company:10",
                ["principal"] = 200000m,
                ["currency"] = "TRY",
                ["termMonths"] = 6,
                ["status"] = DepositAccountStatus.Active,
                ["createdBy"] = UserIds.BmsAsistani
            }
        });
        list.Add(new Resource
        {
            Id = "depositaccount:6002",
            Type = ResourceTypes.DepositAccount,
            ParentId = "customer:1002",
            Attributes = new Dictionary<string, object>
            {
                ["customerId"] = "customer:1002", // VIP customer
                ["companyId"] = "company:10",
                ["principal"] = 900000m, // above BMS Yetkilisi's 750.000 limit
                ["currency"] = "TRY",
                ["termMonths"] = 12,
                ["status"] = DepositAccountStatus.PendingClosure,
                ["createdBy"] = UserIds.BmsAsistani
            }
        });
        list.Add(new Resource
        {
            Id = "depositaccount:6003",
            Type = ResourceTypes.DepositAccount,
            ParentId = "customer:1004",
            Attributes = new Dictionary<string, object>
            {
                ["customerId"] = "customer:1004",
                ["companyId"] = "company:20", // another branch - scope demo
                ["principal"] = 300000m,
                ["currency"] = "TRY",
                ["termMonths"] = 3,
                ["status"] = DepositAccountStatus.PendingClosure,
                ["createdBy"] = "user-x"
            }
        });
        list.Add(new Resource
        {
            Id = "depositaccount:6004",
            Type = ResourceTypes.DepositAccount,
            ParentId = "customer:1003",
            Attributes = new Dictionary<string, object>
            {
                ["customerId"] = "customer:1003",
                ["companyId"] = "company:10",
                ["principal"] = 400000m, // within BMS Yetkilisi's limit
                ["currency"] = "TRY",
                ["termMonths"] = 6,
                ["status"] = DepositAccountStatus.PendingClosure,
                ["createdBy"] = UserIds.BmsAsistani
            }
        });
        list.Add(new Resource
        {
            Id = "depositaccount:6005",
            Type = ResourceTypes.DepositAccount,
            ParentId = "customer:1001",
            Attributes = new Dictionary<string, object>
            {
                ["customerId"] = "customer:1001",
                ["companyId"] = "company:10",
                ["principal"] = 250000m,
                ["currency"] = "TRY",
                ["termMonths"] = 3,
                ["status"] = DepositAccountStatus.PendingClosure,
                ["createdBy"] = UserIds.BmsYetkilisi // checker created her own request - self-approval test
            }
        });

        // --- Payments ---
        list.Add(new Resource
        {
            Id = "payment:3001",
            Type = ResourceTypes.Payment,
            Attributes = new Dictionary<string, object>
            {
                ["companyId"] = "company:10",
                ["amount"] = 200000m, // within Gişe Yetkilisi's 300.000 limit
                ["currency"] = "TRY",
                ["status"] = PaymentStatus.PendingApproval,
                ["createdBy"] = UserIds.GiseAsistani
            }
        });
        list.Add(new Resource
        {
            Id = "payment:3002",
            Type = ResourceTypes.Payment,
            Attributes = new Dictionary<string, object>
            {
                ["companyId"] = "company:10",
                ["amount"] = 500000m, // above Gişe Yetkilisi's 300.000 limit
                ["currency"] = "TRY",
                ["status"] = PaymentStatus.PendingApproval,
                ["createdBy"] = UserIds.GiseAsistani
            }
        });
        list.Add(new Resource
        {
            Id = "payment:3003",
            Type = ResourceTypes.Payment,
            Attributes = new Dictionary<string, object>
            {
                ["companyId"] = "company:20", // another branch - scope demo
                ["amount"] = 150000m,
                ["currency"] = "TRY",
                ["status"] = PaymentStatus.PendingApproval,
                ["createdBy"] = "user-x"
            }
        });
        list.Add(new Resource
        {
            Id = "payment:3004",
            Type = ResourceTypes.Payment,
            Attributes = new Dictionary<string, object>
            {
                ["companyId"] = "company:10",
                ["amount"] = 100000m,
                ["currency"] = "TRY",
                ["status"] = PaymentStatus.PendingApproval,
                ["createdBy"] = UserIds.GiseYetkilisi // checker created his own payment - self-approval test
            }
        });

        // --- Transactions ---
        list.Add(new Resource
        {
            Id = "transaction:4001",
            Type = ResourceTypes.Transaction,
            ParentId = "account:2001",
            Attributes = new Dictionary<string, object>
            {
                ["accountId"] = "account:2001",
                ["companyId"] = "company:10",
                ["amount"] = 5000m,
                ["currency"] = "TRY",
                ["direction"] = "CREDIT",
                ["date"] = "2026-09-10"
            }
        });
        list.Add(new Resource
        {
            Id = "transaction:4002",
            Type = ResourceTypes.Transaction,
            ParentId = "account:2002",
            Attributes = new Dictionary<string, object>
            {
                ["accountId"] = "account:2002",
                ["companyId"] = "company:10",
                ["amount"] = 120000m,
                ["currency"] = "TRY",
                ["direction"] = "DEBIT",
                ["date"] = "2026-09-12"
            }
        });
        list.Add(new Resource
        {
            Id = "transaction:4003",
            Type = ResourceTypes.Transaction,
            ParentId = "account:2003",
            Attributes = new Dictionary<string, object>
            {
                ["accountId"] = "account:2003",
                ["companyId"] = "company:10",
                ["amount"] = 2500m,
                ["currency"] = "TRY",
                ["direction"] = "CREDIT",
                ["date"] = "2026-09-15"
            }
        });

        return list;
    }
}
