using BankingAuthorizationService.Common;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.MockData;

public static class MockPermissions
{
    public static List<Permission> GetAll()
    {
        var descriptions = new Dictionary<string, string>
        {
            [PermissionNames.CustomerRead] = "Müşteri kaydını görüntüleme",
            [PermissionNames.CustomerCreate] = "Yeni müşteri oluşturma",
            [PermissionNames.CustomerUpdate] = "Müşteri bilgilerini güncelleme",
            [PermissionNames.CustomerIdentityView] = "Müşteri TC kimlik numarasını görüntüleme",
            [PermissionNames.CustomerPhoneView] = "Müşteri telefon numarasını görüntüleme",
            [PermissionNames.AccountRead] = "Vadesiz hesap görüntüleme",
            [PermissionNames.AccountOpen] = "Vadesiz hesap açma",
            [PermissionNames.AccountClose] = "Vadesiz hesap kapama",
            [PermissionNames.AccountBalanceView] = "Hesap bakiyesini görüntüleme",
            [PermissionNames.AccountBalanceViewVip] = "VIP müşteri bakiyesini maskesiz görüntüleme",
            [PermissionNames.AccountUpdate] = "Hesap bilgilerini güncelleme",
            [PermissionNames.DepositAccountRead] = "Vadeli hesap görüntüleme",
            [PermissionNames.DepositAccountOpen] = "Vadeli hesap açma",
            [PermissionNames.DepositAccountClose] = "Vadeli hesap kapama talebi oluşturma",
            [PermissionNames.DepositAccountApprove] = "Vadeli hesap kapama talebini onaylama",
            [PermissionNames.DepositAccountReject] = "Vadeli hesap kapama talebini reddetme",
            [PermissionNames.TransactionRead] = "Hesap hareketlerini görüntüleme",
            [PermissionNames.PaymentRead] = "Ödeme kayıtlarını görüntüleme",
            [PermissionNames.PaymentCreate] = "Yeni ödeme oluşturma",
            [PermissionNames.PaymentUpdate] = "Ödeme bilgilerini güncelleme",
            [PermissionNames.PaymentSubmit] = "Ödemeyi onaya gönderme",
            [PermissionNames.PaymentApprove] = "Bekleyen ödemeyi onaylama",
            [PermissionNames.PaymentReject] = "Bekleyen ödemeyi reddetme",
            [PermissionNames.PaymentExecute] = "Onaylanmış ödemeyi gerçekleştirme",
            [PermissionNames.PaymentCancel] = "Ödemeyi iptal etme",
            [PermissionNames.TransferRead] = "Transfer kayıtlarını görüntüleme",
            [PermissionNames.TransferCreate] = "Yeni transfer oluşturma",
            [PermissionNames.TransferApprove] = "Bekleyen transferi onaylama",
            [PermissionNames.TransferExecute] = "Onaylanmış transferi gerçekleştirme",
            [PermissionNames.StatementRead] = "Hesap ekstresini görüntüleme",
            [PermissionNames.StatementDownload] = "Hesap ekstresini indirme",
            [PermissionNames.ReportRead] = "Raporları görüntüleme",
            [PermissionNames.ReportExport] = "Raporları dışa aktarma",
            [PermissionNames.RoleRead] = "Rolleri görüntüleme",
            [PermissionNames.UserRead] = "Kullanıcıları görüntüleme",
            [PermissionNames.AuditLogRead] = "Yetkilendirme denetim kaydını görüntüleme"
        };

        return PermissionNames.All.Select(id =>
        {
            var parts = id.Split('.', 2);
            return new Permission
            {
                Id = id,
                Resource = parts[0],
                Action = parts.Length > 1 ? parts[1] : string.Empty,
                Description = descriptions.TryGetValue(id, out var d) ? d : id
            };
        }).ToList();
    }
}
