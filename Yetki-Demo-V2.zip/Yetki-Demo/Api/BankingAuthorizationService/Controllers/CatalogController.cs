using BankingAuthorizationService.Models;
using BankingAuthorizationService.Resources;
using BankingAuthorizationService.Services;
using Microsoft.AspNetCore.Mvc;

namespace BankingAuthorizationService.Controllers;

[ApiController]
[Route("api")]
public class CatalogController : ControllerBase
{
    private readonly IUserService _users;
    private readonly IRoleService _roles;
    private readonly IPermissionService _permissions;
    private readonly IResourceService _resources;

    public CatalogController(IUserService users, IRoleService roles, IPermissionService permissions, IResourceService resources)
    {
        _users = users;
        _roles = roles;
        _permissions = permissions;
        _resources = resources;
    }

    [HttpGet("users")]
    public ActionResult<IReadOnlyList<User>> GetUsers() => Ok(_users.GetAll());

    [HttpGet("roles")]
    public ActionResult<IReadOnlyList<Role>> GetRoles() => Ok(_roles.GetAll());

    [HttpGet("permissions")]
    public ActionResult<IReadOnlyList<Permission>> GetPermissions() => Ok(_permissions.GetAll());

    [HttpGet("resources/{type}/{id}")]
    public ActionResult<Resource> GetResource(string type, string id)
    {
        var resource = _resources.GetById(id);
        if (resource is null || resource.Type != type)
        {
            return NotFound();
        }

        return Ok(resource);
    }
}
