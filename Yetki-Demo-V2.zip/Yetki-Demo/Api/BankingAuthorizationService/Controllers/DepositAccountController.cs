using BankingAuthorizationService.Dtos;
using BankingAuthorizationService.Services;
using Microsoft.AspNetCore.Mvc;

namespace BankingAuthorizationService.Controllers;

[ApiController]
[Route("api/deposit-accounts")]
public class DepositAccountController : ControllerBase
{
    private readonly IDepositAccountService _depositAccountService;

    public DepositAccountController(IDepositAccountService depositAccountService)
    {
        _depositAccountService = depositAccountService;
    }

    [HttpGet]
    public ActionResult<List<DepositAccountDto>> GetAll([FromQuery] string userId) =>
        Ok(_depositAccountService.GetAll(userId));

    [HttpPost]
    public ActionResult<DepositAccountActionResult> Open([FromQuery] string userId, [FromBody] OpenDepositAccountRequest request) =>
        Ok(_depositAccountService.Open(userId, request));

    [HttpPost("{id}/request-closure")]
    public ActionResult<DepositAccountActionResult> RequestClosure(string id, [FromQuery] string userId) =>
        Ok(_depositAccountService.RequestClosure(userId, id));

    [HttpPost("{id}/approve")]
    public ActionResult<DepositAccountActionResult> Approve(string id, [FromQuery] string userId) =>
        Ok(_depositAccountService.Approve(userId, id));

    [HttpPost("{id}/reject")]
    public ActionResult<DepositAccountActionResult> Reject(string id, [FromQuery] string userId) =>
        Ok(_depositAccountService.Reject(userId, id));
}
