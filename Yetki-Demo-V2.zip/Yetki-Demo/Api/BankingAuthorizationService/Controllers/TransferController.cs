using BankingAuthorizationService.Dtos;
using BankingAuthorizationService.Services;
using Microsoft.AspNetCore.Mvc;

namespace BankingAuthorizationService.Controllers;

[ApiController]
[Route("api/transfers")]
public class TransferController : ControllerBase
{
    private readonly ITransferService _transferService;

    public TransferController(ITransferService transferService)
    {
        _transferService = transferService;
    }

    [HttpGet]
    public ActionResult<List<TransferDto>> GetAll([FromQuery] string userId)
    {
        return Ok(_transferService.GetAll(userId));
    }

    [HttpPost]
    public ActionResult<TransferActionResult> Create([FromQuery] string userId, [FromBody] CreateTransferRequest request)
    {
        return Ok(_transferService.Create(userId, request));
    }
}
