using BankingAuthorizationService.Screens;
using Microsoft.AspNetCore.Mvc;

namespace BankingAuthorizationService.Controllers;

[ApiController]
[Route("api/screens")]
public class ScreenController : ControllerBase
{
    private readonly IScreenCapabilityService _capabilityService;

    public ScreenController(IScreenCapabilityService capabilityService)
    {
        _capabilityService = capabilityService;
    }

    [HttpGet("{screen}/capabilities")]
    public ActionResult<ScreenCapabilitiesResponse> GetCapabilities(
        string screen,
        [FromQuery] string userId,
        [FromQuery] string? resourceId)
    {
        var result = _capabilityService.GetCapabilities(screen, userId, resourceId);
        return result is null ? NotFound() : Ok(result);
    }
}
