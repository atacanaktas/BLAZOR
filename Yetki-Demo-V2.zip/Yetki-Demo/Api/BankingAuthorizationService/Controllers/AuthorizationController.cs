using BankingAuthorizationService.Audit;
using BankingAuthorizationService.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BankingAuthorizationService.Controllers;

[ApiController]
[Route("api/authorization")]
public class AuthorizationController : ControllerBase
{
    private readonly IAuthorizationEngine _engine;
    private readonly IAuditLogService _auditLog;

    public AuthorizationController(IAuthorizationEngine engine, IAuditLogService auditLog)
    {
        _engine = engine;
        _auditLog = auditLog;
    }

    [HttpPost("check")]
    public ActionResult<AuthorizationResponse> Check([FromBody] AuthorizationRequest request)
    {
        return Ok(_engine.Check(request));
    }

    [HttpPost("check-batch")]
    public ActionResult<BatchAuthorizationResponse> CheckBatch([FromBody] BatchAuthorizationRequest request)
    {
        return Ok(_engine.CheckBatch(request));
    }

    [HttpGet("audit")]
    public ActionResult<IReadOnlyList<AuditLogEntry>> GetAudit()
    {
        return Ok(_auditLog.GetAll());
    }
}
