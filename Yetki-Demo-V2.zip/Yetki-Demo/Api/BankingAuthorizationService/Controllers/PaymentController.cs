using BankingAuthorizationService.Dtos;
using BankingAuthorizationService.Services;
using Microsoft.AspNetCore.Mvc;

namespace BankingAuthorizationService.Controllers;

[ApiController]
[Route("api/payments")]
public class PaymentController : ControllerBase
{
    private readonly IPaymentService _paymentService;

    public PaymentController(IPaymentService paymentService)
    {
        _paymentService = paymentService;
    }

    [HttpGet]
    public ActionResult<List<PaymentDto>> GetAll([FromQuery] string userId)
    {
        return Ok(_paymentService.GetAll(userId));
    }

    [HttpGet("{id}")]
    public ActionResult<PaymentDto> GetById(string id, [FromQuery] string userId)
    {
        var (payment, auth) = _paymentService.GetById(userId, id);
        return payment is null ? StatusCode(403, auth) : Ok(payment);
    }

    [HttpPost]
    public ActionResult<PaymentActionResult> Create([FromQuery] string userId, [FromBody] CreatePaymentRequest request)
    {
        return Ok(_paymentService.Create(userId, request));
    }

    [HttpPost("{id}/submit")]
    public ActionResult<PaymentActionResult> Submit(string id, [FromQuery] string userId) =>
        Ok(_paymentService.Submit(userId, id));

    [HttpPost("{id}/approve")]
    public ActionResult<PaymentActionResult> Approve(string id, [FromQuery] string userId) =>
        Ok(_paymentService.Approve(userId, id));

    [HttpPost("{id}/reject")]
    public ActionResult<PaymentActionResult> Reject(string id, [FromQuery] string userId) =>
        Ok(_paymentService.Reject(userId, id));

    [HttpPost("{id}/execute")]
    public ActionResult<PaymentActionResult> Execute(string id, [FromQuery] string userId) =>
        Ok(_paymentService.Execute(userId, id));

    [HttpPost("{id}/cancel")]
    public ActionResult<PaymentActionResult> Cancel(string id, [FromQuery] string userId) =>
        Ok(_paymentService.Cancel(userId, id));
}
