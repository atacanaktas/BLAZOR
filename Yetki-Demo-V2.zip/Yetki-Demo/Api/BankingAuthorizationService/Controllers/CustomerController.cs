using BankingAuthorizationService.Dtos;
using BankingAuthorizationService.Services;
using Microsoft.AspNetCore.Mvc;

namespace BankingAuthorizationService.Controllers;

[ApiController]
[Route("api/customers")]
public class CustomerController : ControllerBase
{
    private readonly ICustomerService _customerService;

    public CustomerController(ICustomerService customerService)
    {
        _customerService = customerService;
    }

    [HttpGet]
    public ActionResult<List<CustomerDto>> GetAll([FromQuery] string userId)
    {
        return Ok(_customerService.GetAll(userId));
    }

    [HttpGet("{id}")]
    public ActionResult<CustomerDto> GetById(string id, [FromQuery] string userId)
    {
        var (customer, auth) = _customerService.GetById(userId, id);
        return customer is null ? StatusCode(403, auth) : Ok(customer);
    }
}
