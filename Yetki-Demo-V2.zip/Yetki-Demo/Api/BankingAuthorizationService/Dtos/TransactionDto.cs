namespace BankingAuthorizationService.Dtos;

public class TransactionDto
{
    public string Id { get; set; } = string.Empty;
    public string AccountId { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = string.Empty;
    public string Direction { get; set; } = string.Empty;
    public string Date { get; set; } = string.Empty;
}

public class TransferDto
{
    public string Id { get; set; } = string.Empty;
    public string FromAccountId { get; set; } = string.Empty;
    public string ToAccountId { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string CreatedBy { get; set; } = string.Empty;
}

public class CreateTransferRequest
{
    public string FromAccountId { get; set; } = string.Empty;
    public string ToAccountId { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "TRY";
}

public class TransferActionResult
{
    public Authorization.AuthorizationResponse Authorization { get; set; } = new();
    public TransferDto? Transfer { get; set; }
    public string? Error { get; set; }
}
