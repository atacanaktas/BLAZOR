namespace BankingAuthorizationService.Dtos;

public class DepositAccountDto
{
    public string Id { get; set; } = string.Empty;
    public string CustomerId { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string CompanyId { get; set; } = string.Empty;
    public decimal Principal { get; set; }
    public string Currency { get; set; } = string.Empty;
    public int TermMonths { get; set; }
    public string Status { get; set; } = string.Empty;
    public string CreatedBy { get; set; } = string.Empty;
    public string CreatedByDisplayName { get; set; } = string.Empty;
}

public class OpenDepositAccountRequest
{
    public string CustomerId { get; set; } = string.Empty;
    public string CompanyId { get; set; } = string.Empty;
    public decimal Principal { get; set; }
    public string Currency { get; set; } = "TRY";
    public int TermMonths { get; set; } = 6;
}

public class DepositAccountActionResult
{
    public Authorization.AuthorizationResponse Authorization { get; set; } = new();
    public DepositAccountDto? DepositAccount { get; set; }
    public string? Error { get; set; }
}

public class OpenAccountRequest
{
    public string CustomerId { get; set; } = string.Empty;
    public string CompanyId { get; set; } = string.Empty;
    public string Currency { get; set; } = "TRY";
}

public class AccountActionResult
{
    public Authorization.AuthorizationResponse Authorization { get; set; } = new();
    public AccountDto? Account { get; set; }
    public string? Error { get; set; }
}
