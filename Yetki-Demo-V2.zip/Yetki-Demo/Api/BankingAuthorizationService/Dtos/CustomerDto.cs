namespace BankingAuthorizationService.Dtos;

/// <summary>
/// Field-level authorization is enforced server-side: sensitive fields the caller may not view
/// come back as null with the corresponding *Masked flag set, never as a real value hidden by
/// a client-side mask.
/// </summary>
public class CustomerDto
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Segment { get; set; } = string.Empty;
    public string RiskLevel { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public bool PhoneMasked { get; set; }
    public string? NationalId { get; set; }
    public bool IdentityMasked { get; set; }
}
