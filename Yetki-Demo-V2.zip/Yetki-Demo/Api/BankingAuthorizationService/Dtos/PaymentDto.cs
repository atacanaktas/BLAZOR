namespace BankingAuthorizationService.Dtos;

public class PaymentDto
{
    public string Id { get; set; } = string.Empty;
    public string CompanyId { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string CreatedBy { get; set; } = string.Empty;
    public string CreatedByDisplayName { get; set; } = string.Empty;
}

public class CreatePaymentRequest
{
    public string CompanyId { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "TRY";
}

public class PaymentActionResult
{
    public Authorization.AuthorizationResponse Authorization { get; set; } = new();
    public PaymentDto? Payment { get; set; }
    public string? Error { get; set; }
}
