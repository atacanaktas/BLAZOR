namespace BankingAuthorizationService.Dtos;

public class AccountDto
{
    public string Id { get; set; } = string.Empty;
    public string CustomerId { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string Currency { get; set; } = string.Empty;
    public decimal? Balance { get; set; }
    public bool BalanceMasked { get; set; }
    public string Status { get; set; } = string.Empty;
    public string CompanyId { get; set; } = string.Empty;
}
