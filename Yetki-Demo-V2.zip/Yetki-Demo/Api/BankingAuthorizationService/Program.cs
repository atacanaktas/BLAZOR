using BankingAuthorizationService.Abac;
using BankingAuthorizationService.Audit;
using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.MockData;
using BankingAuthorizationService.Policies;
using BankingAuthorizationService.Rbac;
using BankingAuthorizationService.Resources;
using BankingAuthorizationService.Screens;
using BankingAuthorizationService.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Mock data stores (singletons so mutations, e.g. approving a payment, persist for the process lifetime).
builder.Services.AddSingleton<MockResourceStore>();
builder.Services.AddSingleton<IResourceService, ResourceService>();
builder.Services.AddSingleton<IUserService, UserService>();
builder.Services.AddSingleton<IRoleService, RoleService>();
builder.Services.AddSingleton<IPermissionService, PermissionService>();
builder.Services.AddSingleton<IAuditLogService, AuditLogService>();

// RBAC / ABAC
builder.Services.AddSingleton<IRbacService, RbacService>();
builder.Services.AddSingleton<IAbacEvaluator, AbacEvaluator>();

// Policies
builder.Services.AddSingleton<CompanyScopePolicy>();
builder.Services.AddSingleton<MakerCheckerPolicy>();
builder.Services.AddSingleton<VipBalancePolicy>();
builder.Services.AddSingleton<AccountReadPolicy>();
builder.Services.AddSingleton<AccountOpenPolicy>();
builder.Services.AddSingleton<AccountBalancePolicy>();
builder.Services.AddSingleton<TransactionReadPolicy>();
builder.Services.AddSingleton<DepositAccountOpenPolicy>();
builder.Services.AddSingleton<DepositAccountApprovePolicy>();
builder.Services.AddSingleton<DepositAccountRejectPolicy>();
builder.Services.AddSingleton<PaymentCreatePolicy>();
builder.Services.AddSingleton<PaymentApprovePolicy>();
builder.Services.AddSingleton<PaymentRejectPolicy>();
builder.Services.AddSingleton<PaymentExecutePolicy>();
builder.Services.AddSingleton<TransferCreatePolicy>();
builder.Services.AddSingleton<IPolicyRegistry, PolicyRegistry>();

// Authorization engine
builder.Services.AddSingleton<IAuthorizationEngine, AuthorizationEngine>();

// Screens
builder.Services.AddSingleton<IScreenCapabilityService, ScreenCapabilityService>();

// Banking domain services
builder.Services.AddSingleton<ICustomerService, CustomerService>();
builder.Services.AddSingleton<IAccountService, AccountService>();
builder.Services.AddSingleton<ITransactionService, TransactionService>();
builder.Services.AddSingleton<IPaymentService, PaymentService>();
builder.Services.AddSingleton<ITransferService, TransferService>();
builder.Services.AddSingleton<IDepositAccountService, DepositAccountService>();

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy => policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseCors();

app.MapControllers();

app.Run();

// Exposed for WebApplicationFactory-based integration tests.
public partial class Program { }
