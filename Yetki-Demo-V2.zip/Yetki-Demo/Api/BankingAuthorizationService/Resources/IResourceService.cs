using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Resources;

public interface IResourceService
{
    Resource? GetById(string id);
    IReadOnlyList<Resource> GetByType(string type);
    void Add(Resource resource);
}
