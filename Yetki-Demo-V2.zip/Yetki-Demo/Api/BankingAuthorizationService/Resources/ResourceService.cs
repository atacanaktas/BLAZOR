using BankingAuthorizationService.MockData;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Resources;

public class ResourceService : IResourceService
{
    private readonly MockResourceStore _store;

    public ResourceService(MockResourceStore store)
    {
        _store = store;
    }

    public Resource? GetById(string id) => _store.GetById(id);

    public IReadOnlyList<Resource> GetByType(string type) => _store.GetByType(type);

    public void Add(Resource resource) => _store.Add(resource);
}
