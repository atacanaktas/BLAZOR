namespace BankingAuthorizationService.Models;

public class User
{
    public string Id { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public List<string> RoleIds { get; set; } = new();

    /// <summary>
    /// Company scope assigned to this user. "*" means global (unrestricted) scope.
    /// Compared against a resource's "companyId" attribute during authorization.
    /// </summary>
    public string CompanyScope { get; set; } = string.Empty;
}
