namespace BankingAuthorizationService.Models;

public class Role
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public List<string> PermissionIds { get; set; } = new();

    /// <summary>
    /// Maximum payment/transfer amount this role may approve. Null means unlimited.
    /// Used by PaymentApprovePolicy for the approval-limit rule.
    /// </summary>
    public decimal? ApprovalLimit { get; set; }
}
