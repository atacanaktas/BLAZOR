namespace BankingAuthorizationService.Models;

/// <summary>
/// Metadata describing a registered policy. This is a descriptive record used for documentation
/// and registry display; the actual evaluation logic lives in the IPolicy implementations under
/// the Policies folder.
/// </summary>
public class AuthorizationPolicy
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Permission { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
}
