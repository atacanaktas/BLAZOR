namespace BankingAuthorizationService.Models;

/// <summary>
/// Generic resource model. Customers, accounts, payments and transactions are all represented
/// uniformly as Resources with a Type discriminator and a bag of Attributes, so ABAC and scope
/// checks can operate against any resource type without type-specific code in the engine.
/// </summary>
public class Resource
{
    public string Id { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public string? ParentId { get; set; }
    public Dictionary<string, object> Attributes { get; set; } = new();

    public T? GetAttribute<T>(string key)
    {
        if (!Attributes.TryGetValue(key, out var value) || value is null)
        {
            return default;
        }

        if (value is T typed)
        {
            return typed;
        }

        try
        {
            return (T)Convert.ChangeType(value, typeof(T));
        }
        catch
        {
            return default;
        }
    }
}
