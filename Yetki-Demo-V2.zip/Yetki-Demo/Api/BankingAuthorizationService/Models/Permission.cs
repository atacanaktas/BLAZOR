namespace BankingAuthorizationService.Models;

/// <summary>
/// Describes a permission in "resource.action" form. Permissions are not limited to CRUD;
/// business actions like approve/reject/execute/cancel are first-class permissions too.
/// </summary>
public class Permission
{
    public string Id { get; set; } = string.Empty;
    public string Resource { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
}
