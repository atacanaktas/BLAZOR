namespace BankingAuthorizationService.Audit;

public class AuditLogEntry
{
    public DateTime Timestamp { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Permission { get; set; } = string.Empty;
    public string? Resource { get; set; }
    public string Decision { get; set; } = string.Empty;
    public string? PolicyName { get; set; }
    public List<string> Reasons { get; set; } = new();
}
