namespace BankingAuthorizationService.Audit;

public interface IAuditLogService
{
    void Record(AuditLogEntry entry);
    IReadOnlyList<AuditLogEntry> GetAll();
}
