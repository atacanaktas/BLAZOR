namespace BankingAuthorizationService.Audit;

/// <summary>Thread-safe in-memory audit log. Registered as a singleton so entries persist for
/// the lifetime of the running service (no database, per the demo's constraints).</summary>
public class AuditLogService : IAuditLogService
{
    private readonly List<AuditLogEntry> _entries = new();
    private readonly object _lock = new();
    private const int MaxEntries = 500;

    public void Record(AuditLogEntry entry)
    {
        lock (_lock)
        {
            _entries.Insert(0, entry);
            if (_entries.Count > MaxEntries)
            {
                _entries.RemoveAt(_entries.Count - 1);
            }
        }
    }

    public IReadOnlyList<AuditLogEntry> GetAll()
    {
        lock (_lock)
        {
            return _entries.ToList();
        }
    }
}
