namespace BankingAuthorizationService.Common;

public static class RoleIds
{
    public const string SubeMuduru = "role-sube-muduru";
    public const string GiseYetkilisi = "role-gise-yetkilisi";
    public const string GiseAsistani = "role-gise-asistani";
    public const string BirmeyselMusteriYetkilisi = "role-bms-yetkilisi";
    public const string BirmeyselMusteriAsistani = "role-bms-asistani";
}

public static class UserIds
{
    public const string GiseAsistani = "user-1"; // Elif Yıldız
    public const string GiseYetkilisi = "user-2"; // Mert Kaya
    public const string BmsYetkilisi = "user-3"; // Zeynep Arslan
    public const string SubeMuduru = "user-4"; // Burak Şahin
    public const string BmsAsistani = "user-5"; // Deniz Koç
}

public static class ResourceTypes
{
    public const string Customer = "customer";
    public const string Account = "account";
    public const string DepositAccount = "deposit_account";
    public const string Payment = "payment";
    public const string Transaction = "transaction";
    public const string Transfer = "transfer";
}

public static class AccountStatus
{
    public const string Active = "ACTIVE";
    public const string Closed = "CLOSED";
}

public static class DepositAccountStatus
{
    public const string Active = "ACTIVE";
    public const string PendingClosure = "PENDING_CLOSURE";
    public const string Closed = "CLOSED";
}

public static class PaymentStatus
{
    public const string Draft = "DRAFT";
    public const string PendingApproval = "PENDING_APPROVAL";
    public const string Approved = "APPROVED";
    public const string Rejected = "REJECTED";
    public const string Executed = "EXECUTED";
    public const string Cancelled = "CANCELLED";
}

public static class DecisionNames
{
    public const string Allow = "ALLOW";
    public const string Deny = "DENY";
    public const string Mask = "MASK";
}

public static class StepResultNames
{
    public const string Pass = "PASS";
    public const string Fail = "FAIL";
    public const string Mask = "MASK";
    public const string NotApplicable = "N/A";
}
