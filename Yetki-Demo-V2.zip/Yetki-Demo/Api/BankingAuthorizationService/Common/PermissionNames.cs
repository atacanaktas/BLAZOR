namespace BankingAuthorizationService.Common;

/// <summary>
/// Central catalog of permission identifiers in "resource.action" form.
/// Keeping these as constants avoids magic strings scattered across policies and mock data.
/// </summary>
public static class PermissionNames
{
    public const string Wildcard = "*";

    public const string CustomerRead = "customer.read";
    public const string CustomerCreate = "customer.create";
    public const string CustomerUpdate = "customer.update";
    public const string CustomerIdentityView = "customer.identity.view";
    public const string CustomerPhoneView = "customer.phone.view";

    // Current (vadesiz) account operations
    public const string AccountRead = "account.read";
    public const string AccountOpen = "account.open";
    public const string AccountClose = "account.close";
    public const string AccountBalanceView = "account.balance.view";
    public const string AccountBalanceViewVip = "account.balance.view.vip";
    public const string AccountUpdate = "account.update";

    // Time deposit (vadeli hesap) operations
    public const string DepositAccountRead = "deposit_account.read";
    public const string DepositAccountOpen = "deposit_account.open";
    public const string DepositAccountClose = "deposit_account.close"; // request closure (maker)
    public const string DepositAccountApprove = "deposit_account.approve"; // approve closure (checker)
    public const string DepositAccountReject = "deposit_account.reject"; // reject closure (checker)

    public const string TransactionRead = "transaction.read";

    public const string PaymentRead = "payment.read";
    public const string PaymentCreate = "payment.create";
    public const string PaymentUpdate = "payment.update";
    public const string PaymentSubmit = "payment.submit";
    public const string PaymentApprove = "payment.approve";
    public const string PaymentReject = "payment.reject";
    public const string PaymentExecute = "payment.execute";
    public const string PaymentCancel = "payment.cancel";

    public const string TransferRead = "transfer.read";
    public const string TransferCreate = "transfer.create";
    public const string TransferApprove = "transfer.approve";
    public const string TransferExecute = "transfer.execute";

    public const string StatementRead = "statement.read";
    public const string StatementDownload = "statement.download";

    public const string ReportRead = "report.read";
    public const string ReportExport = "report.export";

    public const string RoleRead = "role.read";
    public const string UserRead = "user.read";

    public const string AuditLogRead = "audit_log.read";

    public static readonly IReadOnlyList<string> All = new[]
    {
        CustomerRead, CustomerCreate, CustomerUpdate, CustomerIdentityView, CustomerPhoneView,
        AccountRead, AccountOpen, AccountClose, AccountBalanceView, AccountBalanceViewVip, AccountUpdate,
        DepositAccountRead, DepositAccountOpen, DepositAccountClose, DepositAccountApprove, DepositAccountReject,
        TransactionRead,
        PaymentRead, PaymentCreate, PaymentUpdate, PaymentSubmit, PaymentApprove, PaymentReject, PaymentExecute, PaymentCancel,
        TransferRead, TransferCreate, TransferApprove, TransferExecute,
        StatementRead, StatementDownload,
        ReportRead, ReportExport,
        RoleRead, UserRead,
        AuditLogRead
    };
}
