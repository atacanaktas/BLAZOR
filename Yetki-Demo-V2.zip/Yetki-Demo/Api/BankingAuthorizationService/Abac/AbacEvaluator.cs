using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Abac;

public class AbacEvaluator : IAbacEvaluator
{
    public bool IsWithinScope(User user, Resource resource)
    {
        if (user.CompanyScope == "*")
        {
            return true;
        }

        if (!resource.Attributes.TryGetValue("companyId", out var companyId) || companyId is null)
        {
            return true;
        }

        return string.Equals(companyId.ToString(), user.CompanyScope, StringComparison.OrdinalIgnoreCase);
    }

    public bool AttributeEquals(Resource resource, string key, object expectedValue)
    {
        if (!resource.Attributes.TryGetValue(key, out var value) || value is null)
        {
            return false;
        }

        return string.Equals(value.ToString(), expectedValue.ToString(), StringComparison.OrdinalIgnoreCase);
    }
}
