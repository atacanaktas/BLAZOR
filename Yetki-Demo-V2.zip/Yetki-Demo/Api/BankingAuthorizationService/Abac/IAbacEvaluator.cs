using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Abac;

public interface IAbacEvaluator
{
    /// <summary>Compares a resource's "companyId" attribute against the user's CompanyScope.
    /// A CompanyScope of "*" (BankAdmin) always matches. A resource with no companyId
    /// attribute is treated as unscoped and always matches.</summary>
    bool IsWithinScope(User user, Resource resource);

    bool AttributeEquals(Resource resource, string key, object expectedValue);
}
