using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Services;

public interface IPermissionService
{
    bool Exists(string id);
    IReadOnlyList<Permission> GetAll();
}
