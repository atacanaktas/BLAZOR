using BankingAuthorizationService.MockData;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Services;

public class UserService : IUserService
{
    private readonly List<User> _users = MockUsers.GetAll();

    public User? GetById(string id) => _users.FirstOrDefault(u => u.Id == id);

    public IReadOnlyList<User> GetAll() => _users;
}
