using BankingAuthorizationService.Dtos;

namespace BankingAuthorizationService.Services;

public interface ITransactionService
{
    List<TransactionDto> GetByAccount(string userId, string accountId);
}
