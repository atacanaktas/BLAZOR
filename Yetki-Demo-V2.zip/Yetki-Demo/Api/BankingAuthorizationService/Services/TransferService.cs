using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;
using BankingAuthorizationService.Dtos;
using BankingAuthorizationService.Models;
using BankingAuthorizationService.Resources;

namespace BankingAuthorizationService.Services;

public class TransferService : ITransferService
{
    private readonly IResourceService _resources;
    private readonly IAuthorizationEngine _engine;
    private int _nextId = 5001;

    public TransferService(IResourceService resources, IAuthorizationEngine engine)
    {
        _resources = resources;
        _engine = engine;
    }

    public List<TransferDto> GetAll(string userId)
    {
        var result = new List<TransferDto>();
        foreach (var resource in _resources.GetByType(ResourceTypes.Transfer))
        {
            var auth = _engine.Check(new AuthorizationRequest
            {
                UserId = userId,
                Permission = PermissionNames.TransferRead,
                ResourceType = ResourceTypes.Transfer,
                ResourceId = resource.Id
            });

            if (auth.Allowed)
            {
                result.Add(MapToDto(resource));
            }
        }

        return result;
    }

    public TransferActionResult Create(string userId, CreateTransferRequest request)
    {
        var fromAccount = _resources.GetById(request.FromAccountId);
        if (fromAccount is null || fromAccount.Type != ResourceTypes.Account)
        {
            return new TransferActionResult
            {
                Authorization = new AuthorizationResponse
                {
                    Allowed = false,
                    Decision = DecisionNames.Deny,
                    Permission = PermissionNames.TransferCreate,
                    Reasons = new List<string> { "Source account not found" }
                }
            };
        }

        // transfer.create is checked against the source account, which already carries the
        // companyId needed for the generic scope check in the pipeline.
        var auth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = PermissionNames.TransferCreate,
            ResourceType = ResourceTypes.Account,
            ResourceId = request.FromAccountId
        });

        if (!auth.Allowed)
        {
            return new TransferActionResult { Authorization = auth };
        }

        var companyId = fromAccount.GetAttribute<string>("companyId") ?? string.Empty;
        var resource = new Resource
        {
            Id = $"transfer:{_nextId++}",
            Type = ResourceTypes.Transfer,
            Attributes = new Dictionary<string, object>
            {
                ["companyId"] = companyId,
                ["fromAccountId"] = request.FromAccountId,
                ["toAccountId"] = request.ToAccountId,
                ["amount"] = request.Amount,
                ["currency"] = request.Currency,
                ["status"] = "CREATED",
                ["createdBy"] = userId
            }
        };
        _resources.Add(resource);

        return new TransferActionResult { Authorization = auth, Transfer = MapToDto(resource) };
    }

    private static TransferDto MapToDto(Resource resource) => new()
    {
        Id = resource.Id,
        FromAccountId = resource.GetAttribute<string>("fromAccountId") ?? string.Empty,
        ToAccountId = resource.GetAttribute<string>("toAccountId") ?? string.Empty,
        Amount = resource.GetAttribute<decimal>("amount"),
        Currency = resource.GetAttribute<string>("currency") ?? string.Empty,
        Status = resource.GetAttribute<string>("status") ?? string.Empty,
        CreatedBy = resource.GetAttribute<string>("createdBy") ?? string.Empty
    };
}
