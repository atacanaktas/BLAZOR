using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Dtos;

namespace BankingAuthorizationService.Services;

public interface IAccountService
{
    List<AccountDto> GetAll(string userId);
    (AccountDto? Account, AuthorizationResponse Authorization) GetById(string userId, string id);
    AccountActionResult Open(string userId, OpenAccountRequest request);
    AccountActionResult Close(string userId, string id);
}
