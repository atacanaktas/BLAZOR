using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Dtos;

namespace BankingAuthorizationService.Services;

public interface ITransferService
{
    List<TransferDto> GetAll(string userId);
    TransferActionResult Create(string userId, CreateTransferRequest request);
}
