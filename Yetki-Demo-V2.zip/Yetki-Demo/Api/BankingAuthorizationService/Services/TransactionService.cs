using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;
using BankingAuthorizationService.Dtos;
using BankingAuthorizationService.Resources;

namespace BankingAuthorizationService.Services;

public class TransactionService : ITransactionService
{
    private readonly IResourceService _resources;
    private readonly IAuthorizationEngine _engine;

    public TransactionService(IResourceService resources, IAuthorizationEngine engine)
    {
        _resources = resources;
        _engine = engine;
    }

    public List<TransactionDto> GetByAccount(string userId, string accountId)
    {
        var result = new List<TransactionDto>();
        foreach (var resource in _resources.GetByType(ResourceTypes.Transaction))
        {
            if (resource.GetAttribute<string>("accountId") != accountId)
            {
                continue;
            }

            var auth = _engine.Check(new AuthorizationRequest
            {
                UserId = userId,
                Permission = PermissionNames.TransactionRead,
                ResourceType = ResourceTypes.Transaction,
                ResourceId = resource.Id
            });

            if (!auth.Allowed)
            {
                continue;
            }

            result.Add(new TransactionDto
            {
                Id = resource.Id,
                AccountId = accountId,
                Amount = resource.GetAttribute<decimal>("amount"),
                Currency = resource.GetAttribute<string>("currency") ?? string.Empty,
                Direction = resource.GetAttribute<string>("direction") ?? string.Empty,
                Date = resource.GetAttribute<string>("date") ?? string.Empty
            });
        }

        return result;
    }
}
