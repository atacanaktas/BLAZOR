using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Services;

public interface IRoleService
{
    Role? GetById(string id);
    IReadOnlyList<Role> GetAll();
}
