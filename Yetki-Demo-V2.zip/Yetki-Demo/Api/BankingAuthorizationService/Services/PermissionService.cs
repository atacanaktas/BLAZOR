using BankingAuthorizationService.MockData;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Services;

public class PermissionService : IPermissionService
{
    private readonly List<Permission> _permissions = MockPermissions.GetAll();
    private readonly HashSet<string> _ids;

    public PermissionService()
    {
        _ids = _permissions.Select(p => p.Id).ToHashSet();
    }

    public bool Exists(string id) => _ids.Contains(id);

    public IReadOnlyList<Permission> GetAll() => _permissions;
}
