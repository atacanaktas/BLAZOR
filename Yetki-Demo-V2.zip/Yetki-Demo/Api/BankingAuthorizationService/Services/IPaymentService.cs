using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Dtos;

namespace BankingAuthorizationService.Services;

public interface IPaymentService
{
    List<PaymentDto> GetAll(string userId);
    (PaymentDto? Payment, AuthorizationResponse Authorization) GetById(string userId, string id);
    PaymentActionResult Create(string userId, CreatePaymentRequest request);
    PaymentActionResult Submit(string userId, string id);
    PaymentActionResult Approve(string userId, string id);
    PaymentActionResult Reject(string userId, string id);
    PaymentActionResult Execute(string userId, string id);
    PaymentActionResult Cancel(string userId, string id);
}
