using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;
using BankingAuthorizationService.Dtos;
using BankingAuthorizationService.Models;
using BankingAuthorizationService.Resources;

namespace BankingAuthorizationService.Services;

/// <summary>
/// Applies both resource-level (customer.read + scope) and field-level (phone/national ID)
/// authorization before returning data. A masked field is never sent to the caller as a real
/// value hidden behind asterisks - it comes back as null with the *Masked flag set.
/// </summary>
public class CustomerService : ICustomerService
{
    private readonly IResourceService _resources;
    private readonly IAuthorizationEngine _engine;

    public CustomerService(IResourceService resources, IAuthorizationEngine engine)
    {
        _resources = resources;
        _engine = engine;
    }

    public List<CustomerDto> GetAll(string userId)
    {
        var result = new List<CustomerDto>();
        foreach (var resource in _resources.GetByType(ResourceTypes.Customer))
        {
            var auth = _engine.Check(new AuthorizationRequest
            {
                UserId = userId,
                Permission = PermissionNames.CustomerRead,
                ResourceType = ResourceTypes.Customer,
                ResourceId = resource.Id
            });

            if (auth.Allowed)
            {
                result.Add(MapToDto(userId, resource));
            }
        }

        return result;
    }

    public (CustomerDto?, AuthorizationResponse) GetById(string userId, string id)
    {
        var resource = _resources.GetById(id);
        if (resource is null || resource.Type != ResourceTypes.Customer)
        {
            return (null, new AuthorizationResponse
            {
                Allowed = false,
                Decision = DecisionNames.Deny,
                Permission = PermissionNames.CustomerRead,
                Reasons = new List<string> { "Customer not found" }
            });
        }

        var auth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = PermissionNames.CustomerRead,
            ResourceType = ResourceTypes.Customer,
            ResourceId = id
        });

        return auth.Allowed ? (MapToDto(userId, resource), auth) : (null, auth);
    }

    private CustomerDto MapToDto(string userId, Resource resource)
    {
        var phoneAuth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = PermissionNames.CustomerPhoneView,
            ResourceType = ResourceTypes.Customer,
            ResourceId = resource.Id
        });
        var identityAuth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = PermissionNames.CustomerIdentityView,
            ResourceType = ResourceTypes.Customer,
            ResourceId = resource.Id
        });

        return new CustomerDto
        {
            Id = resource.Id,
            Name = resource.GetAttribute<string>("name") ?? string.Empty,
            Segment = resource.GetAttribute<string>("segment") ?? string.Empty,
            RiskLevel = resource.GetAttribute<string>("riskLevel") ?? string.Empty,
            Email = resource.GetAttribute<string>("email"),
            Phone = phoneAuth.Allowed ? resource.GetAttribute<string>("phone") : null,
            PhoneMasked = !phoneAuth.Allowed,
            NationalId = identityAuth.Allowed ? resource.GetAttribute<string>("nationalId") : null,
            IdentityMasked = !identityAuth.Allowed
        };
    }
}
