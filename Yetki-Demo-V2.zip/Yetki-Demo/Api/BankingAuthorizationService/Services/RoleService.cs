using BankingAuthorizationService.MockData;
using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Services;

public class RoleService : IRoleService
{
    private readonly List<Role> _roles = MockRoles.GetAll();

    public Role? GetById(string id) => _roles.FirstOrDefault(r => r.Id == id);

    public IReadOnlyList<Role> GetAll() => _roles;
}
