using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;
using BankingAuthorizationService.Dtos;
using BankingAuthorizationService.Models;
using BankingAuthorizationService.Resources;

namespace BankingAuthorizationService.Services;

/// <summary>
/// Every mutating action re-runs the authorization engine for its specific permission before
/// touching data (defense in depth: the WinForms client already checked, but the server never
/// trusts that). Status-transition validity (e.g. "already executed") is a separate domain
/// concern from authorization and is reported via PaymentActionResult.Error rather than a
/// DENY, since it isn't about who the user is - it's about the payment's current state.
/// </summary>
public class PaymentService : IPaymentService
{
    private readonly IResourceService _resources;
    private readonly IAuthorizationEngine _engine;
    private readonly IUserService _users;
    private int _nextId = 3004;

    public PaymentService(IResourceService resources, IAuthorizationEngine engine, IUserService users)
    {
        _resources = resources;
        _engine = engine;
        _users = users;
    }

    public List<PaymentDto> GetAll(string userId)
    {
        var result = new List<PaymentDto>();
        foreach (var resource in _resources.GetByType(ResourceTypes.Payment))
        {
            var auth = _engine.Check(new AuthorizationRequest
            {
                UserId = userId,
                Permission = PermissionNames.PaymentRead,
                ResourceType = ResourceTypes.Payment,
                ResourceId = resource.Id
            });

            if (auth.Allowed)
            {
                result.Add(MapToDto(resource));
            }
        }

        return result;
    }

    public (PaymentDto?, AuthorizationResponse) GetById(string userId, string id)
    {
        var resource = _resources.GetById(id);
        if (resource is null || resource.Type != ResourceTypes.Payment)
        {
            return (null, new AuthorizationResponse
            {
                Allowed = false,
                Decision = DecisionNames.Deny,
                Permission = PermissionNames.PaymentRead,
                Reasons = new List<string> { "Payment not found" }
            });
        }

        var auth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = PermissionNames.PaymentRead,
            ResourceType = ResourceTypes.Payment,
            ResourceId = id
        });

        return auth.Allowed ? (MapToDto(resource), auth) : (null, auth);
    }

    public PaymentActionResult Create(string userId, CreatePaymentRequest request)
    {
        var auth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = PermissionNames.PaymentCreate,
            ResourceType = ResourceTypes.Payment,
            Context = new Dictionary<string, object> { ["companyId"] = request.CompanyId }
        });

        if (!auth.Allowed)
        {
            return new PaymentActionResult { Authorization = auth };
        }

        var resource = new Resource
        {
            Id = $"payment:{_nextId++}",
            Type = ResourceTypes.Payment,
            Attributes = new Dictionary<string, object>
            {
                ["companyId"] = request.CompanyId,
                ["amount"] = request.Amount,
                ["currency"] = request.Currency,
                ["status"] = PaymentStatus.Draft,
                ["createdBy"] = userId
            }
        };
        _resources.Add(resource);

        return new PaymentActionResult { Authorization = auth, Payment = MapToDto(resource) };
    }

    public PaymentActionResult Submit(string userId, string id) =>
        ExecuteAction(userId, id, PermissionNames.PaymentSubmit, PaymentStatus.Draft, PaymentStatus.PendingApproval,
            "Payment must be in DRAFT status to submit");

    public PaymentActionResult Approve(string userId, string id) =>
        ExecuteAction(userId, id, PermissionNames.PaymentApprove, null, PaymentStatus.Approved, null);

    public PaymentActionResult Reject(string userId, string id) =>
        ExecuteAction(userId, id, PermissionNames.PaymentReject, null, PaymentStatus.Rejected, null);

    public PaymentActionResult Execute(string userId, string id) =>
        ExecuteAction(userId, id, PermissionNames.PaymentExecute, null, PaymentStatus.Executed, null);

    public PaymentActionResult Cancel(string userId, string id)
    {
        var resource = _resources.GetById(id);
        if (resource is null || resource.Type != ResourceTypes.Payment)
        {
            return NotFoundResult(PermissionNames.PaymentCancel);
        }

        var status = resource.GetAttribute<string>("status");
        if (status is PaymentStatus.Executed or PaymentStatus.Cancelled)
        {
            return new PaymentActionResult
            {
                Authorization = new AuthorizationResponse
                {
                    Allowed = false,
                    Decision = DecisionNames.Deny,
                    Permission = PermissionNames.PaymentCancel,
                    Resource = id
                },
                Error = $"Payment cannot be cancelled from status {status}"
            };
        }

        var auth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = PermissionNames.PaymentCancel,
            ResourceType = ResourceTypes.Payment,
            ResourceId = id
        });

        if (!auth.Allowed)
        {
            return new PaymentActionResult { Authorization = auth };
        }

        resource.Attributes["status"] = PaymentStatus.Cancelled;
        return new PaymentActionResult { Authorization = auth, Payment = MapToDto(resource) };
    }

    private PaymentActionResult ExecuteAction(
        string userId,
        string id,
        string permission,
        string? requiredStatus,
        string newStatus,
        string? requiredStatusError)
    {
        var resource = _resources.GetById(id);
        if (resource is null || resource.Type != ResourceTypes.Payment)
        {
            return NotFoundResult(permission);
        }

        if (requiredStatus is not null)
        {
            var currentStatus = resource.GetAttribute<string>("status");
            if (!string.Equals(currentStatus, requiredStatus, StringComparison.OrdinalIgnoreCase))
            {
                return new PaymentActionResult
                {
                    Authorization = new AuthorizationResponse
                    {
                        Allowed = false,
                        Decision = DecisionNames.Deny,
                        Permission = permission,
                        Resource = id
                    },
                    Error = requiredStatusError ?? $"Payment must be in {requiredStatus} status"
                };
            }
        }

        var auth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = permission,
            ResourceType = ResourceTypes.Payment,
            ResourceId = id
        });

        if (!auth.Allowed)
        {
            return new PaymentActionResult { Authorization = auth };
        }

        resource.Attributes["status"] = newStatus;
        return new PaymentActionResult { Authorization = auth, Payment = MapToDto(resource) };
    }

    private PaymentActionResult NotFoundResult(string permission) => new()
    {
        Authorization = new AuthorizationResponse
        {
            Allowed = false,
            Decision = DecisionNames.Deny,
            Permission = permission,
            Reasons = new List<string> { "Payment not found" }
        }
    };

    private PaymentDto MapToDto(Resource resource)
    {
        var createdBy = resource.GetAttribute<string>("createdBy") ?? string.Empty;
        var creator = _users.GetById(createdBy);

        return new PaymentDto
        {
            Id = resource.Id,
            CompanyId = resource.GetAttribute<string>("companyId") ?? string.Empty,
            Amount = resource.GetAttribute<decimal>("amount"),
            Currency = resource.GetAttribute<string>("currency") ?? string.Empty,
            Status = resource.GetAttribute<string>("status") ?? string.Empty,
            CreatedBy = createdBy,
            CreatedByDisplayName = creator?.DisplayName ?? createdBy
        };
    }
}
