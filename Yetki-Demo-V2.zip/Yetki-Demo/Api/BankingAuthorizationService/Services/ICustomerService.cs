using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Dtos;

namespace BankingAuthorizationService.Services;

public interface ICustomerService
{
    List<CustomerDto> GetAll(string userId);
    (CustomerDto? Customer, AuthorizationResponse Authorization) GetById(string userId, string id);
}
