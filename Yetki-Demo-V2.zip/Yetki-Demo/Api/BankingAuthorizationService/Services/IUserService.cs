using BankingAuthorizationService.Models;

namespace BankingAuthorizationService.Services;

public interface IUserService
{
    User? GetById(string id);
    IReadOnlyList<User> GetAll();
}
