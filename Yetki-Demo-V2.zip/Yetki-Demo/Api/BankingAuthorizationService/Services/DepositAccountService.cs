using BankingAuthorizationService.Authorization;
using BankingAuthorizationService.Common;
using BankingAuthorizationService.Dtos;
using BankingAuthorizationService.Models;
using BankingAuthorizationService.Resources;

namespace BankingAuthorizationService.Services;

/// <summary>
/// Time deposit (vadeli hesap) lifecycle: open (Bireysel Müşteri Asistanı) -> request closure
/// (same maker) -> approve/reject (Bireysel Müşteri Yetkilisi, checker). Every mutating action
/// re-runs the authorization engine before touching data, exactly like PaymentService.
/// </summary>
public class DepositAccountService : IDepositAccountService
{
    private readonly IResourceService _resources;
    private readonly IAuthorizationEngine _engine;
    private readonly IUserService _users;
    private int _nextId = 6006;

    public DepositAccountService(IResourceService resources, IAuthorizationEngine engine, IUserService users)
    {
        _resources = resources;
        _engine = engine;
        _users = users;
    }

    public List<DepositAccountDto> GetAll(string userId)
    {
        var result = new List<DepositAccountDto>();
        foreach (var resource in _resources.GetByType(ResourceTypes.DepositAccount))
        {
            var auth = _engine.Check(new AuthorizationRequest
            {
                UserId = userId,
                Permission = PermissionNames.DepositAccountRead,
                ResourceType = ResourceTypes.DepositAccount,
                ResourceId = resource.Id
            });

            if (auth.Allowed)
            {
                result.Add(MapToDto(resource));
            }
        }

        return result;
    }

    public DepositAccountActionResult Open(string userId, OpenDepositAccountRequest request)
    {
        var auth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = PermissionNames.DepositAccountOpen,
            ResourceType = ResourceTypes.DepositAccount,
            Context = new Dictionary<string, object> { ["companyId"] = request.CompanyId }
        });

        if (!auth.Allowed)
        {
            return new DepositAccountActionResult { Authorization = auth };
        }

        var resource = new Resource
        {
            Id = $"depositaccount:{_nextId++}",
            Type = ResourceTypes.DepositAccount,
            ParentId = request.CustomerId,
            Attributes = new Dictionary<string, object>
            {
                ["customerId"] = request.CustomerId,
                ["companyId"] = request.CompanyId,
                ["principal"] = request.Principal,
                ["currency"] = request.Currency,
                ["termMonths"] = request.TermMonths,
                ["status"] = DepositAccountStatus.Active,
                ["createdBy"] = userId
            }
        };
        _resources.Add(resource);

        return new DepositAccountActionResult { Authorization = auth, DepositAccount = MapToDto(resource) };
    }

    public DepositAccountActionResult RequestClosure(string userId, string id)
    {
        var resource = _resources.GetById(id);
        if (resource is null || resource.Type != ResourceTypes.DepositAccount)
        {
            return NotFoundResult(PermissionNames.DepositAccountClose);
        }

        var status = resource.GetAttribute<string>("status");
        if (!string.Equals(status, DepositAccountStatus.Active, StringComparison.OrdinalIgnoreCase))
        {
            return new DepositAccountActionResult
            {
                Authorization = new AuthorizationResponse
                {
                    Allowed = false,
                    Decision = DecisionNames.Deny,
                    Permission = PermissionNames.DepositAccountClose,
                    Resource = id
                },
                Error = $"Deposit account must be ACTIVE to request closure (status: {status})"
            };
        }

        var auth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = PermissionNames.DepositAccountClose,
            ResourceType = ResourceTypes.DepositAccount,
            ResourceId = id
        });

        if (!auth.Allowed)
        {
            return new DepositAccountActionResult { Authorization = auth };
        }

        resource.Attributes["status"] = DepositAccountStatus.PendingClosure;
        return new DepositAccountActionResult { Authorization = auth, DepositAccount = MapToDto(resource) };
    }

    public DepositAccountActionResult Approve(string userId, string id) =>
        ExecuteAction(userId, id, PermissionNames.DepositAccountApprove, DepositAccountStatus.Closed);

    public DepositAccountActionResult Reject(string userId, string id) =>
        ExecuteAction(userId, id, PermissionNames.DepositAccountReject, DepositAccountStatus.Active);

    private DepositAccountActionResult ExecuteAction(string userId, string id, string permission, string newStatus)
    {
        var resource = _resources.GetById(id);
        if (resource is null || resource.Type != ResourceTypes.DepositAccount)
        {
            return NotFoundResult(permission);
        }

        var auth = _engine.Check(new AuthorizationRequest
        {
            UserId = userId,
            Permission = permission,
            ResourceType = ResourceTypes.DepositAccount,
            ResourceId = id
        });

        if (!auth.Allowed)
        {
            return new DepositAccountActionResult { Authorization = auth };
        }

        resource.Attributes["status"] = newStatus;
        return new DepositAccountActionResult { Authorization = auth, DepositAccount = MapToDto(resource) };
    }

    private DepositAccountActionResult NotFoundResult(string permission) => new()
    {
        Authorization = new AuthorizationResponse
        {
            Allowed = false,
            Decision = DecisionNames.Deny,
            Permission = permission,
            Reasons = new List<string> { "Deposit account not found" }
        }
    };

    private DepositAccountDto MapToDto(Resource resource)
    {
        var createdBy = resource.GetAttribute<string>("createdBy") ?? string.Empty;
        var creator = _users.GetById(createdBy);
        var customerId = resource.GetAttribute<string>("customerId") ?? string.Empty;
        var customer = _resources.GetById(customerId);

        return new DepositAccountDto
        {
            Id = resource.Id,
            CustomerId = customerId,
            CustomerName = customer?.GetAttribute<string>("name") ?? string.Empty,
            CompanyId = resource.GetAttribute<string>("companyId") ?? string.Empty,
            Principal = resource.GetAttribute<decimal>("principal"),
            Currency = resource.GetAttribute<string>("currency") ?? string.Empty,
            TermMonths = resource.GetAttribute<int>("termMonths"),
            Status = resource.GetAttribute<string>("status") ?? string.Empty,
            CreatedBy = createdBy,
            CreatedByDisplayName = creator?.DisplayName ?? createdBy
        };
    }
}
