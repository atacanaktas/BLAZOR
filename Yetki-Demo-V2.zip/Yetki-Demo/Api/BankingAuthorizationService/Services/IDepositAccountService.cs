using BankingAuthorizationService.Dtos;

namespace BankingAuthorizationService.Services;

public interface IDepositAccountService
{
    List<DepositAccountDto> GetAll(string userId);
    DepositAccountActionResult Open(string userId, OpenDepositAccountRequest request);
    DepositAccountActionResult RequestClosure(string userId, string id);
    DepositAccountActionResult Approve(string userId, string id);
    DepositAccountActionResult Reject(string userId, string id);
}
