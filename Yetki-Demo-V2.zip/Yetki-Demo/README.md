# Banking Authorization Architecture Demo

A working, fully local .NET 8 demo of how a modern banking application can structure
**authorization** as a first-class, centralized concern — separate from authentication,
separate from business logic, and separate from the UI.

Roles and permissions are modeled after a real bank branch: **Şube Müdürü**, **Gişe
Yetkilisi**, **Gişe Asistanı**, **Bireysel Müşteri Yetkilisi**, **Bireysel Müşteri Asistanı**.
Operations are real banking actions — hesap açma/kapama, vadeli hesap açma/izleme/kapama onayı,
ödeme/transfer onayı — not generic CRUD. It shows RBAC, ABAC, policy-based authorization,
resource-based authorization, scope, permissions, capabilities, field-level authorization,
screen-level authorization, and maker/checker (separation of duties) all working together
behind one decision point: the **Authorization Service**.

No real database, no real identity provider, no real banking API. Everything is in-memory
mock data inside the service process.

## Architecture

```
                ┌──────────────┐
                │   WinForms   │
                └──────┬───────┘
                       │
                 HTTP / JSON
                       │
                       ▼
          ┌────────────────────────┐
          │ Authorization Service  │
          ├────────────────────────┤
          │ RBAC                   │
          │ ABAC                   │
          │ Scope                  │
          │ Policy Engine          │
          │ Resource Authorization │
          │ Field Authorization    │
          └────────────┬───────────┘
                       │
                 ALLOW / DENY / MASK
                       │
                       ▼
                  WinForms UI
```

The API and the client are independent .NET solutions that only agree on the JSON wire format
- neither references the other, and either can be opened, built and run on its own:

```
Yetki-Demo/
├── Api/
│   ├── BankingAuthorizationService.sln
│   ├── BankingAuthorizationService         ASP.NET Core Web API — the authorization decision point
│   └── BankingAuthorizationService.Tests   xUnit tests for the policy pipeline
│
└── Client/
    ├── BankingDemo.WinForms.sln
    └── BankingDemo.WinForms                .NET 8 WinForms client — renders whatever the API decides
```

**The golden rule enforced throughout the codebase:** WinForms never contains authorization
logic. There is no `if (user.Role == "ŞubeMüdürü")` and no
`if (user.Permissions.Contains(...))` anywhere in the client. Every screen asks the
Authorization Service "what can I show?" and renders the answer. The server re-checks
authorization on every mutating endpoint too — the client's own check is only used to shape
the UI, never trusted as the real gate. And there's a dedicated **Test Senaryoları** screen in
the client that fires named test cases at the live service and shows PASS/FAIL, so the whole
matrix can be inspected without touching code.

## Project structure

```
Api/BankingAuthorizationService/
├── Authorization/     AuthorizationEngine, AuthorizationContext, Request/Response DTOs
├── Policies/          IPolicy + one class per policy (see below)
├── Rbac/               RbacService — role → permission resolution, incl. "*" wildcard
├── Abac/               AbacEvaluator — attribute comparisons, company-scope matching
├── Resources/          ResourceService — in-memory resource lookup
├── Screens/            Screen → Capability → Permission registry + calculation
├── Services/           User/Role/Permission catalogs + Customer/Account/DepositAccount/
│                       Payment/Transfer banking services (apply authorization + masking)
├── MockData/           MockUsers, MockRoles, MockPermissions, MockResources (in-memory store)
├── Audit/               In-memory authorization decision log
├── Controllers/        AuthorizationController, ScreenController, Customer/Account/
│                       DepositAccount/Payment/Transfer controllers, CatalogController
│                       (users/roles/permissions/resources)
└── Common/              Permission/Role/Resource-type/Status/Decision string constants

Client/BankingDemo.WinForms/
├── Authorization/       AuthorizationClient (HTTP), CapabilityService, CurrentUserContext
├── Models/               Client-side DTOs mirroring the service's JSON contracts
├── Services/             HTTP wrappers for the mock banking endpoints
└── Forms/                LoginForm, MainForm (nav shell), AuthorizationDebugForm, and one
    └── Panels/           UserControl per screen (Dashboard, Customers, Vadesiz Hesaplar,
                           Vadeli Hesaplar, Ödemeler, Transferler, Denetim, Raporlar, Yönetim,
                           Test Senaryoları)
```

## RBAC — banking roles

`RbacService` resolves a user's roles to a permission set. A role holding the permission `"*"`
is granted everything. Permissions are not limited to CRUD — business actions (`open`,
`close`, `approve`, `reject`, `execute`, `submit`, `cancel`) are first-class permissions in
`resource.action` form (see `Common/PermissionNames.cs`).

| Role | Domain | Representative permissions | Approval limit |
|---|---|---|---|
| **Gişe Asistanı** | Vezne (junior) | `customer.read`, `account.read`, `account.balance.view`, `payment.create/submit/cancel` (maker), `transfer.create` | — |
| **Gişe Yetkilisi** | Vezne (senior) | + `account.open`, `account.close`, `payment.approve/reject/execute` (checker), `transfer.approve/execute`, `statement.download` | 300.000 TRY |
| **Bireysel Müşteri Asistanı** | Retail ilişki (junior) | `customer.read/phone.view`, `deposit_account.open`, `deposit_account.close` (maker: kapama talebi) | — |
| **Bireysel Müşteri Yetkilisi** | Retail ilişki (senior) | + `customer.identity.view/update`, `account.balance.view.vip`, `deposit_account.approve/reject` (checker) | 750.000 TRY |
| **Şube Müdürü** | Şube üst yönetimi | `*` (tüm işlemler) | unlimited |

Two independent maker/checker pairs are demonstrated on purpose, to show the pattern isn't
tied to one resource type:

- **Ödemeler**: Gişe Asistanı (maker: create/submit) → Gişe Yetkilisi (checker: approve/
  reject/execute, 300.000 TRY limit)
- **Vadeli Hesaplar**: Bireysel Müşteri Asistanı (maker: open/request closure) → Bireysel
  Müşteri Yetkilisi (checker: approve/reject closure, 750.000 TRY limit)

Şube Müdürü's role has `PermissionIds = ["*"]` **but** `CompanyScope = "company:10"` (their own
branch, not global) — this deliberately shows that the RBAC wildcard only satisfies the RBAC
step of the pipeline; the scope check still runs independently and still denies access to
another branch's resources (`company:20`) even for a wildcard role. See scenario **S09** below.

## ABAC & Scope

Every resource (customer, account, deposit account, payment, transaction, transfer) is
modeled uniformly:

```csharp
public class Resource
{
    public string Id { get; set; }
    public string Type { get; set; }
    public string? ParentId { get; set; }
    public Dictionary<string, object> Attributes { get; set; }
}
```

`CompanyScopePolicy` compares `resource.Attributes["companyId"]` against `user.CompanyScope`.
A resource with no `companyId` is treated as unscoped. This single generic check runs for
every resource-bound permission, before any permission-specific policy.

## Policy engine

```csharp
public interface IPolicy
{
    string Name { get; }
    PolicyEvaluationResult Evaluate(AuthorizationContext context);
}
```

`PolicyRegistry` maps a permission to the policy that governs its instance-level rules:

| Permission | Policy | Rule |
|---|---|---|
| `account.read` | AccountReadPolicy | scope (generic) |
| `account.open` | AccountOpenPolicy | target company within scope |
| `account.balance.view` | AccountBalanceViewPolicy | delegates to VIPBalancePolicy |
| `transaction.read` | TransactionReadPolicy | scope (generic) |
| `deposit_account.open` | DepositAccountOpenPolicy | target company within scope |
| `deposit_account.approve` | DepositAccountApprovePolicy | status PENDING_CLOSURE + maker/checker + approval limit |
| `deposit_account.reject` | DepositAccountRejectPolicy | status PENDING_CLOSURE + maker/checker |
| `payment.create` | PaymentCreatePolicy | target company within scope |
| `payment.approve` | PaymentApprovePolicy | status PENDING_APPROVAL + maker/checker + approval limit |
| `payment.reject` | PaymentRejectPolicy | status PENDING_APPROVAL + maker/checker |
| `payment.execute` | PaymentExecutePolicy | status APPROVED |
| `transfer.create` | TransferCreatePolicy | scope (generic) |

Permissions with no entry still go through RBAC + scope; the registry only adds extra
ABAC/SoD/limit rules where a permission needs them. `MakerCheckerPolicy` is a single reusable
class consumed by both the payment and deposit-account approve/reject policies — proof the
pattern generalizes across unrelated resource types.

## Field-level authorization

Sensitive customer fields are gated by dedicated permissions (`customer.phone.view`,
`customer.identity.view`). The server **never sends the real value** to a caller who lacks
the permission — it returns `null` plus a boolean flag:

```json
{ "phone": null, "phoneMasked": true }
```

This is enforced in `CustomerService.MapToDto`, which runs an authorization check per field
before deciding what to put in the DTO. Masking is not a UI-side decision.

## VIP balance masking

`VIPBalancePolicy`: if the account's customer has `segment == "VIP"` and the caller lacks
`account.balance.view.vip`, the decision is **MASK**, not ALLOW or DENY — the caller has
`account.balance.view` (so the account itself is visible) but the balance value is withheld.
Gişe Asistanı/Yetkilisi see `********` for account `2002` (customer `1002`, VIP); Bireysel
Müşteri Yetkilisi and Şube Müdürü see the real balance (8,500,000 TRY).

## Decision types: ALLOW / DENY / MASK

```csharp
public enum PolicyDecision { Allow, Deny, Mask }
```

`AuthorizationResponse.Allowed` is `true` only for ALLOW. MASK still comes back as
`Allowed: false` — the client is not handed the real value, only permission to render a
masked placeholder.

## Example request / response

```json
POST /api/authorization/check
{
  "userId": "user-3",
  "permission": "deposit_account.approve",
  "resourceType": "deposit_account",
  "resourceId": "depositaccount:6004"
}
```

```json
{
  "allowed": true,
  "decision": "ALLOW",
  "permission": "deposit_account.approve",
  "resource": "depositaccount:6004",
  "reasons": [
    "Role BireyselMusteriYetkilisi has deposit_account.approve",
    "Deposit account is pending closure, not self-requested, and within approval limit"
  ],
  "roleUsed": "BireyselMusteriYetkilisi",
  "policyName": "DepositAccountApprovePolicy",
  "steps": [
    { "step": "User Exists", "result": "PASS" },
    { "step": "RBAC", "result": "PASS" },
    { "step": "Scope", "result": "PASS" },
    { "step": "Deposit Account Status", "result": "PASS" },
    { "step": "Maker/Checker", "result": "PASS" },
    { "step": "Amount Limit", "result": "PASS" },
    { "step": "Policy", "result": "DepositAccountApprovePolicy" }
  ]
}
```

Every step of the pipeline is recorded, which is exactly what the WinForms **Authorization
Debug** dialog renders after every button click.

## Screen → Capability → Permission

WinForms never asks "do I have `deposit_account.approve`?" — it asks "what can I show on the
Vadeli Hesaplar screen for this account?":

```
GET /api/screens/deposit-accounts/capabilities?userId=user-3&resourceId=depositaccount:6004
```

```json
{
  "screen": "deposit-accounts",
  "capabilities": {
    "view_deposit_accounts": true,
    "open_deposit_account": true,
    "request_closure": true,
    "approve_closure": true,
    "reject_closure": true
  }
}
```

A screen can (and typically does) depend on more than one permission; a single permission can
back capabilities on more than one screen. `transfer.create` appears both under
`account-detail` and `transfers` but always resolves to the same check.

## Demo users

| User | Username | Role | Company scope | Approval limit |
|---|---|---|---|---|
| Elif Yıldız | elif.yildiz | Gişe Asistanı | company:10 | — |
| Mert Kaya | mert.kaya | Gişe Yetkilisi | company:10 | 300.000 TRY |
| Zeynep Arslan | zeynep.arslan | Bireysel Müşteri Yetkilisi | company:10 | 750.000 TRY |
| Burak Şahin | burak.sahin | Şube Müdürü | company:10 | unlimited |
| Deniz Koç | deniz.koc | Bireysel Müşteri Asistanı | company:10 | — |

## Running the demo

Requirements: .NET 8 SDK (or newer, with the net8.0 runtime installed), Windows (WinForms).

1. **Start the Authorization Service** (from the repo root):
   ```
   dotnet run --project Api/BankingAuthorizationService
   ```
   It listens on `http://localhost:5080` and serves Swagger at `/swagger` for exploring the
   API directly. (Or open `Api/BankingAuthorizationService.sln` and run from there.)

2. **Start the WinForms client** (in a second terminal):
   ```
   dotnet run --project Client/BankingDemo.WinForms
   ```
   The base URL is read from `Client/BankingDemo.WinForms/appsettings.json`
   (`AuthorizationService:BaseUrl`, defaults to `http://localhost:5080/`). (Or open
   `Client/BankingDemo.WinForms.sln` and run from there.)

3. Pick a user from the login combo box and click **Login**. The left navigation, every grid
   column, and every action button are shaped entirely by what the Authorization Service
   returns for that user.

4. Run the unit tests:
   ```
   dotnet test Api/BankingAuthorizationService.Tests
   ```

5. Or open the **Test Senaryoları** screen in the client (always visible in the nav, regardless
   of who is logged in) and click **Tümünü Çalıştır** — it fires 18 named scenarios at the live
   service as their respective mock users and shows PASS/FAIL. Double-click any row to open the
   Authorization Debug dialog for that scenario's full step trace.

## Test Senaryoları screen

This is the interactive counterpart to the xUnit suite (`AuthorizationEngineTests.cs`) — same
matrix, run live against the running service instead of in-process. Each row picks its own
mock user (independent of who is actually logged into the app), so you can see, side by side,
how the same permission resolves differently for different roles/resources. Highlights:

| # | Senaryo | Beklenen |
|---|---|---|
| S03 | Gişe Yetkilisi hesap açabilir | ALLOW |
| S06 | Gişe Yetkilisi limiti aşan ödemeyi (500.000 > 300.000) onaylayamaz | DENY |
| S07 | Maker kendi ödemesini onaylayamaz | DENY |
| S09 | Şube Müdürü `*` yetkisine sahip olsa da başka şubeyi onaylayamaz | DENY |
| S12 | Bireysel Müşteri Yetkilisi limit içindeki vadeli hesap kapamasını onaylar | ALLOW |
| S13 | Bireysel Müşteri Yetkilisi limiti aşan kapamayı (900.000 > 750.000) onaylayamaz | DENY |
| S16 / S17 | VIP bakiye normal kullanıcıya maskeli, yetkiliye açık | MASK / ALLOW |

## Example scenarios to try in the UI

- **Login as Elif (Gişe Asistanı)** → Vadesiz Hesaplar → account `2001`: balance visible;
  "Hesap Aç" and transfer/statement actions disabled. Select account `2002` (VIP): balance
  shows `********`.
- **Login as Mert (Gişe Yetkilisi)** → Ödemeler: select `payment:3001` (200.000 TRY, created by
  Elif) → Approve → debug dialog shows every step passing → ALLOW.
- Still as Mert, select `payment:3002` (500.000 TRY) → Approve → DENY, *"Payment amount exceeds
  approval limit"*.
- Still as Mert, select `payment:3004` (created by Mert himself) → Approve → DENY, *"Maker
  cannot approve own payment"*.
- **Login as Deniz (Bireysel Müşteri Asistanı)** → Vadeli Hesaplar: open a new deposit account,
  request closure on `depositaccount:6001` — Approve/Reject are disabled (no permission).
- **Login as Zeynep (Bireysel Müşteri Yetkilisi)** → Vadeli Hesaplar: approve
  `depositaccount:6004` (400.000 TRY) → ALLOW; try `depositaccount:6002` (900.000 TRY) → DENY,
  limit exceeded; try `depositaccount:6005` (her own request) → DENY, maker/checker.
- **Login as Burak (Şube Müdürü)** → every nav item and action is visible, but company:20
  resources (`payment:3003`, `depositaccount:6003`) still DENY — scope applies even to the
  wildcard role.
- **Denetim** screen (any user with `audit_log.read`, e.g. Şube Müdürü) shows every decision
  made this session, newest first, including all the denials above.

## Answering the design questions this demo targets

- **Can a screen use more than one permission?** Yes — `account-detail` alone depends on six.
- **Screen vs. permission?** A screen exposes capabilities; each capability maps to exactly
  one permission (`Screens/ScreenCapabilityRegistry.cs`), but the mapping is many-to-one in
  both directions across screens.
- **How does an endpoint decide its permission?** Each controller action passes a fixed
  permission string to `AuthorizationEngine.Check` — never derived from the caller's role.
- **Resource authorization?** Every resource-bound check loads the concrete `Resource` and
  runs scope + policy evaluation against its attributes, not just the permission name.
- **User scope?** `CompanyScopePolicy` compares `resource.companyId` to `user.CompanyScope` -
  independently of RBAC, even for a wildcard role (see Şube Müdürü above).
- **VIP balance masking?** `VIPBalancePolicy`, returning `MASK` instead of `ALLOW`/`DENY`.
- **Maker/checker?** `MakerCheckerPolicy`, reused by `PaymentApprovePolicy`,
  `PaymentRejectPolicy`, `DepositAccountApprovePolicy` and `DepositAccountRejectPolicy` - one
  reusable rule, two unrelated resource domains.
- **Approval limit?** `RbacService.GetApprovalLimit(userId, approvalPermission)`, consumed by
  both payment and deposit-account approve policies with their own limits (300k vs 750k).
- **ABAC?** `AbacEvaluator` + `Resource.Attributes`, used throughout the policies.
- **Same permission, different outcome per resource?** `payment.approve` on `payment:3001`
  (ALLOW), `payment:3002` (DENY — limit), `payment:3003` (DENY — scope) and `payment:3004`
  (DENY — maker/checker), all for the same user and permission.
- **UI vs. backend authorization?** The UI's checks only decide what to render; every mutating
  controller action re-runs `AuthorizationEngine.Check` before touching data.
- **How do I debug a decision?** The `steps` array in `AuthorizationResponse`, rendered by
  `AuthorizationDebugForm` after every authorization-checked button click, and by the
  **Test Senaryoları** screen for any scenario run.
