import {
  ApiOutlined, ArrowRightOutlined, BankOutlined, CheckCircleFilled, ClockCircleOutlined,
  CloseCircleFilled, ControlOutlined, DeploymentUnitOutlined, GlobalOutlined,
  KeyOutlined, LockOutlined, PlusOutlined, SearchOutlined, ThunderboltOutlined, UserOutlined,
} from '@ant-design/icons'
import { App, Button, Card, DatePicker, Drawer, Empty, Input, InputNumber, Modal, Skeleton, Switch, Tag } from 'antd'
import { useMemo, useRef, useState, type CSSProperties, type ReactNode } from 'react'
import { useSearchParams } from 'react-router-dom'
import type { Dayjs } from 'dayjs'
import type { AuthorizationDecision, AuthorizationRequest, CatalogTreeTenant, Option, PagedResult, PermissionListItem, PolicyEvaluation, ResourceDetail } from '../api/types'
import { api } from '../api/client'
import { useApi, useOptions } from '../hooks/useApi'
import { DecisionTag, PageHeader } from '../components/common'
import './EvaluatePage.css'

interface RequestState {
  tenant?: string; user?: string; client?: string; caller?: string; via: string[]
  application?: string; method: string; path: string; resourceId?: number
  ipAddress?: string; amount?: number; branchCode?: string; customerId?: string
}
interface FinderState { kind: 'user' | 'client' | 'via' | 'caller'; title: string; options: Option[] }
interface PermissionPreview { permission: { id: number; code: string; name: string; decisionStrategy: string }; policies: { id: number; code: string; name: string; logic: string; mode: string; isActive: boolean; decisionStrategy: string; rules: { code: string; name: string; expression: string }[] }[] }
type NodeState = 'idle' | 'pass' | 'fail' | 'info'

function nodeState(outcome?: string): NodeState {
  if (outcome === 'Pass' || outcome === 'Permit') return 'pass'
  if (outcome === 'Fail' || outcome === 'Deny' || outcome === 'Indeterminate') return 'fail'
  if (outcome === 'Info') return 'info'
  return 'idle'
}

function FlowNode({ kind, icon, eyebrow, title, detail, state = 'idle', delay = 0, onClick, children }: {
  kind: string; icon: ReactNode; eyebrow: string; title: string; detail: string; state?: NodeState; delay?: number; onClick?: () => void; children?: ReactNode
}) {
  return <div className={`v3-node v3-node-${kind} state-${state}`} style={{ '--node-delay': `${delay}ms` } as CSSProperties}>
    <button type="button" onClick={onClick} disabled={!onClick} className="v3-node-main">
      <span className="v3-node-icon">{icon}</span><span className="v3-node-copy"><small>{eyebrow}</small><strong>{title}</strong><em>{detail}</em></span>
      <span className="v3-node-status">{state === 'pass' ? <CheckCircleFilled /> : state === 'fail' ? <CloseCircleFilled /> : <ArrowRightOutlined />}</span>
    </button>{children}
  </div>
}

function EntityFinder({ finder, onClose, onSelect }: { finder?: FinderState; onClose: () => void; onSelect: (item: Option) => void }) {
  const [query, setQuery] = useState('')
  const items = (finder?.options ?? []).filter((item) => `${item.code} ${item.label} ${item.group ?? ''}`.toLocaleLowerCase('tr-TR').includes(query.toLocaleLowerCase('tr-TR')))
  return <Modal className="v3-finder" open={!!finder} footer={null} width={700} title={finder?.title} onCancel={() => { setQuery(''); onClose() }}>
    <Input autoFocus allowClear prefix={<SearchOutlined />} placeholder="Kod, ad veya tenant ara…" value={query} onChange={(event) => setQuery(event.target.value)} />
    <div className="v3-finder-list">{items.map((item) => <button type="button" key={item.value} onClick={() => { onSelect(item); setQuery('') }}><span><b>{item.code}</b><strong>{item.label}</strong><small>{item.group}</small></span><ArrowRightOutlined /></button>)}</div>
    {!items.length && <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />}
  </Modal>
}

function PolicyBranch({ policy }: { policy: PolicyEvaluation }) {
  const failed = policy.result !== 'Permit'
  return <div className={`v3-policy-branch ${failed ? 'is-failed' : 'is-passed'}`}>
    <div className="v3-policy-head"><span className="v3-policy-dot" /><div><small>{policy.logic} · {policy.mode}</small><strong>{policy.code}</strong><em>{policy.name}</em></div><DecisionTag decision={policy.result} /></div>
    <div className="v3-rule-grid">{policy.rules.map((rule) => <div className={`v3-rule state-${nodeState(rule.result)}`} key={`${rule.ruleId}-${rule.code}`}>
      <span>{rule.conditionValue === 'True' ? <CheckCircleFilled /> : <CloseCircleFilled />}</span><div><strong>{rule.code}</strong><small>{rule.expression}</small>
        {(rule.evidence.length > 0 || rule.missingAttributes.length > 0) && <em>{rule.evidence.map((evidence) => `${evidence.attribute}=${evidence.resolved ? (evidence.value ?? '∅') : '?'}`).join(' · ')}{rule.missingAttributes.length ? ` · missing: ${rule.missingAttributes.join(', ')}` : ''}</em>}
      </div></div>)}</div>
    {policy.children.map((child) => <PolicyBranch policy={child} key={child.policyId} />)}
  </div>
}

export function EvaluatePage() {
  const { message } = App.useApp()
  const [params] = useSearchParams()
  const users = useOptions('users'), clients = useOptions('clients'), apps = useOptions('applications')
  const { data: catalog, loading: catalogLoading } = useApi<CatalogTreeTenant[]>('/api/resources/tree')
  const { data: permissionPage } = useApi<PagedResult<PermissionListItem>>('/api/permissions?page=1&pageSize=1000')
  const [state, setState] = useState<RequestState>({ tenant: 'ABANK', user: params.get('user') ?? 'ahmet.kaya', client: 'nextral-api', via: [], application: 'ANKA', method: 'POST', path: '/v1/cash-withdrawals', ipAddress: '10.1.2.3', amount: 20000, customerId: 'C-555' })
  const [finder, setFinder] = useState<FinderState>(), [endpointOpen, setEndpointOpen] = useState(false), [contextOpen, setContextOpen] = useState(false)
  const [selectedPermission, setSelectedPermission] = useState<string>(), [result, setResult] = useState<AuthorizationDecision>(), [loading, setLoading] = useState(false)
  const [analysisTime, setAnalysisTime] = useState<Dayjs | null>(null)
  const [animationEnabled, setAnimationEnabled] = useState(true)
  const [detailsVisible, setDetailsVisible] = useState(false)
  const resultRef = useRef<HTMLDivElement>(null)
  const detailTimerRef = useRef<number | undefined>(undefined)
  const selectedUser = users.find((item) => item.code === state.user), selectedClient = clients.find((item) => item.code === state.client)
  const allRoutes = useMemo(() => (catalog ?? []).flatMap((tenant) => tenant.applications.flatMap((app) => app.resources.flatMap((resource) => resource.uris.map((uri) => ({ tenant: tenant.code, application: app.code, applicationName: app.name, resource, ...uri }))))), [catalog])
  const selectedRoute = allRoutes.find((route) => route.application === state.application && route.method === state.method && route.pattern === state.path)
  const resourceId = state.resourceId ?? selectedRoute?.resource.id
  const { data: resourceDetail } = useApi<ResourceDetail>(resourceId ? `/api/resources/${resourceId}` : null)
  const matchedUri = resourceDetail?.uris.find((uri) => uri.method === state.method && uri.pattern === state.path)
  const selectedScope = resourceDetail?.scopes.find((scope) => scope.scopeId === matchedUri?.scopeId)
  const catalogPermissions = selectedScope?.permissions.map((item) => item.code) ?? []
  const displayedPermissions = result?.permissions.map((item) => item.code) ?? catalogPermissions
  const activePermission = selectedPermission ?? displayedPermissions[0]
  const selectedEvaluation = result?.permissions.find((item) => item.code === activePermission)
  const selectedDefinition = permissionPage?.items.find((item) => item.code === activePermission)
  const { data: permissionPreview } = useApi<PermissionPreview>(selectedDefinition?.id && !selectedEvaluation ? `/api/permissions/${selectedDefinition.id}` : null)
  const step = (name: string) => result?.steps.find((item) => item.step === name)
  const openFinder = (kind: FinderState['kind']) => {
    const definitions: Record<FinderState['kind'], Omit<FinderState, 'kind'>> = {
      user: { title: 'Who · Subject seçin', options: users }, client: { title: 'Through · Origin client seçin', options: clients },
      via: { title: 'Through · Intermediary ekleyin', options: clients.filter((item) => !state.via.includes(item.code)) }, caller: { title: 'PDP caller seçin', options: clients },
    }; setFinder({ kind, ...definitions[kind] })
  }
  const chooseEntity = (item: Option) => {
    if (!finder) return
    if (finder.kind === 'user') setState((s) => ({ ...s, user: item.code, tenant: item.group || s.tenant }))
    if (finder.kind === 'client') setState((s) => ({ ...s, client: item.code }))
    if (finder.kind === 'via') setState((s) => ({ ...s, via: [...s.via, item.code] }))
    if (finder.kind === 'caller') setState((s) => ({ ...s, caller: item.code }))
    setFinder(undefined); setResult(undefined)
  }
  const chooseRoute = (route: typeof allRoutes[number]) => {
    setState((s) => ({ ...s, tenant: route.tenant, application: route.application, method: route.method, path: route.pattern, resourceId: route.resource.id })); setEndpointOpen(false); setResult(undefined); setSelectedPermission(undefined)
  }
  const analyze = async () => {
    if (!state.user || !state.client || !state.path) return message.warning('Subject, client ve endpoint seçimi tamamlanmalı.')
    const request: AuthorizationRequest = {
      tenant: state.tenant, client: state.client, caller: state.caller, via: state.via.length ? state.via : undefined, subject: { id: state.user },
      http: { application: state.application, method: state.method, path: state.path },
      resource: state.branchCode || state.customerId ? { properties: { ...(state.branchCode ? { BranchCode: state.branchCode } : {}), ...(state.customerId ? { CustomerId: state.customerId } : {}) } } : undefined,
      context: { ...(state.ipAddress ? { IpAddress: state.ipAddress } : {}), ...(state.amount !== undefined ? { TransactionAmount: String(state.amount) } : {}) },
    }
    if (detailTimerRef.current) window.clearTimeout(detailTimerRef.current)
    setLoading(true); setResult(undefined); setDetailsVisible(false)
    try {
      const [decision] = await Promise.all([
        analysisTime
          ? api.post<AuthorizationDecision>('/api/simulation/evaluate', { request, asOfUtc: analysisTime.toISOString() })
          : api.post<AuthorizationDecision>('/api/console/authorize', request),
        new Promise<void>((resolve) => window.setTimeout(resolve, animationEnabled ? 1800 : 0)),
      ])
      setResult(decision); setSelectedPermission(decision.decidingPermission ?? decision.permissions[0]?.code); setLoading(false)
      detailTimerRef.current = window.setTimeout(() => {
        setDetailsVisible(true)
        resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
      }, animationEnabled ? 1500 : 50)
    } catch (error) { message.error((error as Error).message); setLoading(false) }
  }
  const permissionState = (code: string) => nodeState(result?.permissions.find((item) => item.code === code)?.result)
  const hasIntermediary = state.via.length > 0
  const routePath = hasIntermediary
    ? 'M77 133 C180 133 186 277 289 277 C392 277 399 133 502 133 C610 133 624 277 732 277 C837 277 851 133 956 133 C1045 133 1044 277 1133 277'
    : 'M77 133 C185 133 193 277 301 277 C420 277 453 133 572 133 C690 133 743 277 861 277 C970 277 994 133 1103 133'
  return <div className={`decision-v3 ${loading && animationEnabled ? 'is-running' : ''} ${result ? 'has-decision' : ''}`}>
    <PageHeader title="Decision Analysis" subtitle="Authorization request’i canlı bir karar topolojisi üzerinde kurun; isteğin geçtiği node’ları, permission kilitlerini ve policy sonuçlarını izleyin."
      extra={<div className="v3-header-tools"><div className="v3-analysis-time"><span><ClockCircleOutlined /><small>ANALİZ ZAMANI</small></span><DatePicker showTime={{ format: 'HH:mm' }} format="DD.MM.YYYY HH:mm" value={analysisTime} allowClear placeholder="Şimdi" onChange={(value) => { setAnalysisTime(value); setResult(undefined); setDetailsVisible(false) }} /><em>{analysisTime ? 'Seçilen anda simülasyon' : 'Güncel zaman'}</em></div><div className="v3-animation-toggle"><span><small>ANİMASYON</small><em>{animationEnabled ? 'Açık' : 'Kapalı'}</em></span><Switch checked={animationEnabled} onChange={setAnimationEnabled} /></div></div>} />
    <Card className="v3-canvas" bordered={false}>
      <div className="v3-canvas-head"><div><span>LIVE AUTHORIZATION TOPOLOGY</span><strong>{state.tenant} · {state.application}</strong></div><div className="v3-legend"><span><i className="idle" /> Hazır</span><span><i className="pass" /> Geçti</span><span><i className="fail" /> Reddetti</span></div></div>
      <div className="v3-topology-scroll"><div className={`v3-topology ${hasIntermediary ? 'has-intermediary' : 'is-direct'}`}>
        <svg className="v3-zigzag-route" viewBox="0 0 1180 410" preserveAspectRatio="none" aria-hidden="true">
          <path d={routePath} />
        </svg>
        {loading && animationEnabled && <svg key="travelling-request" className="v3-envelope-route" viewBox="0 0 1180 410" preserveAspectRatio="none" aria-label="Request ilerliyor">
          <g className="v3-svg-envelope">
            <rect x="-19" y="-13" width="38" height="26" rx="5" />
            <path d="M-16 -9 L0 3 L16 -9" />
            <circle cx="17" cy="-12" r="8" />
            <text x="17" y="-9">{[state.ipAddress, state.amount, state.branchCode, state.customerId].filter(Boolean).length}</text>
            <animateMotion dur="1.8s" fill="freeze" rotate="0" path={routePath} />
          </g>
        </svg>}
        <div className="v3-column who"><div className="v3-column-label">WHO</div><FlowNode kind="subject" icon={<UserOutlined />} eyebrow="SUBJECT" title={selectedUser?.code ?? 'Subject seçin'} detail={selectedUser ? `${selectedUser.label} · ${state.tenant}` : 'Kim karar istiyor?'} state={nodeState(step('Subject')?.outcome)} delay={150} onClick={() => openFinder('user')} /></div>
        <div className="v3-connector request"><button type="button" className="v3-envelope" onClick={() => setContextOpen(true)} title="Request attribute’larını düzenle"><span className="v3-envelope-flap" /><span className="v3-envelope-count">{[state.ipAddress, state.amount, state.branchCode, state.customerId].filter(Boolean).length}</span></button><small>REQUEST</small><ArrowRightOutlined /></div>
        <div className="v3-column through"><div className="v3-column-label">ORIGIN</div><FlowNode kind="client" icon={<DeploymentUnitOutlined />} eyebrow="CLIENT" title={selectedClient?.code ?? 'Client seçin'} detail={selectedClient?.label ?? 'İsteği başlatan kanal'} state={nodeState(step('Client')?.outcome)} delay={500} onClick={() => openFinder('client')}>
          <button type="button" className="v3-caller" onClick={() => openFinder('caller')}>caller · {state.caller ?? 'management console'}</button>
        </FlowNode></div>
        <div className={`v3-connector ${hasIntermediary ? '' : 'add-via'}`}>{!hasIntermediary && <button type="button" onClick={() => openFinder('via')} title="Intermediary ekle"><PlusOutlined /><small>VIA</small></button>}<ArrowRightOutlined /></div>
        {hasIntermediary && <><div className="v3-column intermediary"><div className="v3-column-label">INTERMEDIARY</div><FlowNode kind="intermediary" icon={<ApiOutlined />} eyebrow="VIA CHAIN" title={state.via[0]} detail={state.via.length > 1 ? `+${state.via.length - 1} intermediary` : 'İstek subject adına taşınır'} state={nodeState(step('Client')?.outcome)} delay={750} onClick={() => openFinder('via')}>
          <div className="v3-intermediary-meta"><button type="button" className="clear" onClick={() => { setState((s) => ({ ...s, via: [] })); setResult(undefined) }}><CloseCircleFilled /> intermediary zincirini kaldır</button></div>
        </FlowNode></div><div className="v3-connector"><ArrowRightOutlined /></div></>}
        <div className="v3-column target"><div className="v3-column-label">TARGET RESOURCE</div><FlowNode kind="resource" icon={<GlobalOutlined />} eyebrow={`${state.method} · ${state.application}`} title={state.path} detail={selectedRoute ? `${selectedRoute.resource.code} · ${selectedRoute.resource.name}` : 'Endpoint kataloğundan seçin'} state={nodeState(step('Resource')?.outcome)} delay={1000} onClick={() => setEndpointOpen(true)} /></div>
        <div className="v3-connector guarded"><span><LockOutlined /></span></div>
        <div className="v3-column controls"><div className="v3-column-label">GUARDED BY</div><div className="v3-permission-stack">
          {displayedPermissions.map((code, index) => <button type="button" className={`v3-permission-lock state-${permissionState(code)} ${activePermission === code ? 'is-selected' : ''}`} style={{ '--lock-delay': `${1300 + index * 180}ms` } as CSSProperties} key={code} onClick={() => setSelectedPermission(code)}><span><LockOutlined /></span><div><small>PERMISSION</small><strong>{code}</strong><em>{result?.permissions.find((item) => item.code === code)?.policies.length ?? permissionPage?.items.find((item) => item.code === code)?.policies.length ?? 0} policies</em></div>{permissionState(code) === 'pass' ? <CheckCircleFilled /> : permissionState(code) === 'fail' ? <CloseCircleFilled /> : <ArrowRightOutlined />}</button>)}
          {!displayedPermissions.length && <div className="v3-no-lock"><LockOutlined /><strong>Permission bekleniyor</strong><small>Endpoint bir resource:scope ile eşleştiğinde kilitler burada görünür.</small></div>}
        </div></div>
        <div className="v3-connector"><ArrowRightOutlined /></div>
        <div className="v3-column verdict"><div className="v3-column-label">DECISION</div><div className={`v3-verdict state-${nodeState(result?.decision)}`}><span>{result ? (result.isAllowed ? <CheckCircleFilled /> : <CloseCircleFilled />) : <ThunderboltOutlined />}</span><small>PDP RESULT</small><strong>{result?.decision?.toUpperCase() ?? 'READY'}</strong><em>{result?.reasonCode ?? 'Request’i çalıştırın'}</em></div></div>
      </div></div>
      <div className="v3-attribute-ribbon"><button type="button" onClick={() => setContextOpen(true)}><ControlOutlined /><span><small>REQUEST ENVELOPE</small><strong>Attribute’ları düzenle</strong></span></button><div>{state.ipAddress && <span><b>ip</b>{state.ipAddress}</span>}{state.amount !== undefined && <span><b>amount</b>{state.amount.toLocaleString('tr-TR')}</span>}{state.customerId && <span><b>customer</b>{state.customerId}</span>}{state.branchCode && <span><b>branch</b>{state.branchCode}</span>}</div></div>
      <div className="v3-runbar"><div><span className="v3-live-dot" /><p><small>REQUEST PATH</small><strong>{state.user} → {state.client}{state.via.length ? ` → ${state.via.join(' → ')}` : ' → direct'} → {state.method} {state.path}</strong></p></div><Button type="primary" size="large" icon={<ThunderboltOutlined />} loading={loading} onClick={analyze}>Animate decision</Button></div>
    </Card>

    <div ref={resultRef} className={`v3-inspector ${activePermission ? 'is-open' : ''} ${result && !detailsVisible ? 'is-waiting' : ''}`}>
      {result && !detailsVisible && <div className="v3-detail-countdown"><ThunderboltOutlined /><span><strong>{result.decision === 'Permit' ? 'ALLOW' : 'DENY'} kararı alındı</strong><small>Policy ve rule detayları hazırlanıyor…</small></span></div>}
      {(!result || detailsVisible) && <>
      <div className="v3-inspector-head"><div><span>CONTROL INSPECTOR</span><strong><LockOutlined /> {activePermission ?? 'Permission seçin'}</strong></div>{selectedEvaluation && <DecisionTag decision={selectedEvaluation.result} />}</div>
      {!activePermission && <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="Diyagramdaki bir permission kilidine tıklayın" />}
      {activePermission && !selectedEvaluation && !permissionPreview && <Skeleton active />}
      {activePermission && !selectedEvaluation && permissionPreview && <div className="v3-definition-preview"><p>Henüz karar çalışmadı. Tanımlı policy ve rule topolojisi gösteriliyor.</p>{permissionPreview.policies.map((policy) => <div className="v3-definition-policy" key={policy.id}><div><KeyOutlined /><span><strong>{policy.code}</strong><small>{policy.logic} · {policy.mode} · {policy.decisionStrategy}</small></span></div>{policy.rules.map((rule) => <div className="v3-definition-rule" key={rule.code}><span /> <b>{rule.code}</b><code>{rule.expression}</code></div>)}</div>)}</div>}
      {selectedEvaluation && <div className="v3-policy-topology">{selectedEvaluation.policies.map((policy) => <PolicyBranch policy={policy} key={policy.policyId} />)}{!selectedEvaluation.policies.length && <Empty description="Permission üzerinde policy yok" />}</div>}
      {result && <div className="v3-decision-evidence"><div><small>DECIDING PATH</small><strong>{result.decidingPermission ?? '—'} → {result.decidingPolicy ?? '—'} → {result.decidingRule ?? '—'}</strong></div><div><small>ENGINE</small><strong>Model v{result.modelVersion} · {result.durationMs.toFixed(1)} ms</strong></div><div><small>DECISION ID</small><strong>{result.decisionId}</strong></div></div>}
      </>}
    </div>

    <EntityFinder finder={finder} onClose={() => setFinder(undefined)} onSelect={chooseEntity} />
    <Modal className="v3-endpoint-modal" open={endpointOpen} width={900} footer={null} title="Protected endpoint seçin" onCancel={() => setEndpointOpen(false)}>
      <div className="v3-app-strip">{apps.map((app) => <button type="button" className={state.application === app.code ? 'active' : ''} key={app.value} onClick={() => setState((s) => ({ ...s, application: app.code }))}><BankOutlined /><span><strong>{app.code}</strong><small>{app.label}</small></span></button>)}</div>
      {catalogLoading ? <Skeleton active /> : <div className="v3-endpoint-list">{allRoutes.filter((route) => route.application === state.application).map((route) => <button type="button" key={`${route.resource.id}-${route.method}-${route.pattern}`} onClick={() => chooseRoute(route)}><Tag>{route.method}</Tag><span><strong>{route.pattern}</strong><small>{route.resource.code} · {route.resource.name}</small></span><span className="endpoint-locks"><LockOutlined /> {route.resource.scopes.length}</span><ArrowRightOutlined /></button>)}</div>}
    </Modal>
    <Drawer title="Runtime attributes" width={460} open={contextOpen} onClose={() => setContextOpen(false)} extra={<Button type="primary" onClick={() => { setContextOpen(false); setResult(undefined) }}>Uygula</Button>}>
      <div className="v3-attribute-group"><span>PIP / REQUEST CONTEXT</span><p>Policy koşullarının değerlendirilmesinde kullanılacak değerler.</p></div>
      <label className="v3-field">IP address<Input value={state.ipAddress} onChange={(event) => setState((s) => ({ ...s, ipAddress: event.target.value }))} /></label>
      <label className="v3-field">Transaction amount<InputNumber min={0} step={1000} value={state.amount} onChange={(value) => setState((s) => ({ ...s, amount: value ?? undefined }))} /></label>
      <div className="v3-attribute-group"><span>RESOURCE ATTRIBUTES</span><p>Kararın verildiği kayda ait attribute’lar.</p></div>
      <label className="v3-field">Branch code<Input value={state.branchCode} onChange={(event) => setState((s) => ({ ...s, branchCode: event.target.value }))} placeholder="101" /></label>
      <label className="v3-field">Customer ID<Input value={state.customerId} onChange={(event) => setState((s) => ({ ...s, customerId: event.target.value }))} placeholder="C-555" /></label>
    </Drawer>
  </div>
}
