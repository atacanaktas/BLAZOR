import { Alert, App, Button, Card, Checkbox, Col, Flex, Form, Input, InputNumber, Modal, Row, Select, Space, Switch, Tag, Tooltip, Typography } from 'antd'
import { DeleteOutlined, EditOutlined, PlusOutlined, TeamOutlined } from '@ant-design/icons'
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import type { ChangeImpactResult, ConditionDraft, ConditionQuestion, ConditionTypeInfo, GroupFilterDraft, ParamDef, RuleDraft, RuleView } from '../api/types'
import { invalidateOptions, useOptions } from '../hooks/useApi'
import { PolicyRefLink, PolicyRefPicker, renderDraft, toDraft } from './ConditionBuilder'
import { GroupFilterEditor } from './GroupFilterEditor'
import { Code } from './common'

// ============================================================================================
//  SORU KARTLARI: koşul policy'si yönetim ekibinin diliyle yazılır. Kart = kural.
//  Kartlar sadece EKRANDIR: kaydedilen şey sıradan bir kural + koşul ağacıdır (motor kart bilmez).
//  KİM kartı = KİTLE = grup kuralıyla aynı biçim: satır içi VE, satırlar arası VEYA, hariç satırı.
//    Aynı kitle başka bir KİM kartında da varsa "grup yapalım mı?", aynı tanımda grup varsa "bu grubu kullan" sorulur.
//  Diğer kartlarda seçeneklerden biri yeterli (VEYA). Karta sığmayan kural gelişmiş düzenleyicide kalır.
// ============================================================================================

/** Kart türü: koşul tiplerinin sorusu veya sadece hazır policy kullanan kart. */
export type CardKind = ConditionQuestion | 'Policy'

export const cardMeta: Record<CardKind, { label: string; help: string; code: string; reason: string; color: string; order: number }> = {
  Who: { label: 'KİM', help: 'Rol, birim, unvan, kurum, kullanıcı, grup… Satır içi VE (ör. rol GISEAST VE birim 101), satırlar arası VEYA; hariç satırı çıkarır.', code: 'KIM', reason: 'NOT_ELIGIBLE', color: 'blue', order: 10 },
  From: { label: 'NEREDEN', help: 'Ağ (IP), kanal ve client.', code: 'NEREDEN', reason: 'SOURCE_NOT_ALLOWED', color: 'cyan', order: 20 },
  Target: { label: 'NEREYE / KİME', help: 'İşlemin şubesi, müşterisi (VIP, personel müşterisi, kendi hesabı).', code: 'HEDEF', reason: 'TARGET_NOT_ALLOWED', color: 'purple', order: 30 },
  HowMuch: { label: 'NE KADAR', help: 'Tutar, işlem başı / günlük limit.', code: 'TUTAR', reason: 'AMOUNT_NOT_ALLOWED', color: 'orange', order: 40 },
  Time: { label: 'HANGİ SAAT', help: 'Saat aralığı ve günler.', code: 'SAAT', reason: 'OUTSIDE_ALLOWED_HOURS', color: 'gold', order: 50 },
  When: { label: 'NE ZAMAN', help: 'İş günü, tatil, kullanıcının izin durumu.', code: 'GUN', reason: 'NOT_ALLOWED_DAY', color: 'lime', order: 60 },
  Policy: { label: 'HAZIR POLICY', help: 'Başka bir policy\'yi (banka ağı, mesai...) olduğu gibi kullan; o policy değişirse burası da değişir.', code: 'POLICY', reason: 'POLICY_NOT_SATISFIED', color: 'magenta', order: 70 },
}

export const cardKinds: CardKind[] = ['Who', 'From', 'Target', 'HowMuch', 'Time', 'When', 'Policy']

/** Kart içindeki tek seçenek (KİM dışı kartlar): koşul tipi (opsiyonel DEĞİL) veya hazır policy. */
export interface CardItem {
  negate: boolean
  kind: 'Predicate' | 'Reference'
  typeCode?: string
  parameters: Record<string, string>
  policyCode?: string
}

const cardColor: Record<string, string> = { blue: '#1677ff', cyan: '#13c2c2', purple: '#722ed1', orange: '#fa8c16', gold: '#faad14', lime: '#a0d911', magenta: '#eb2f96' }
const splitList = (v?: string) => (v ?? '').split(',').map((x) => x.trim()).filter(Boolean)

// ------------------------------ Kitle (KİM kartı ↔ grup kuralı) — PDP Audience ile aynı eşleme ------------------------------

const audienceMap = [
  { crit: 'ROLE', type: 'SUBJECT_HAS_ROLE', param: 'Roles', label: 'rol', subtree: false },
  { crit: 'ORG_UNIT', type: 'SUBJECT_IN_UNIT', param: 'Units', label: 'birim', subtree: false },
  { crit: 'ORG_UNIT_TREE', type: 'SUBJECT_IN_UNIT', param: 'Units', label: 'birim (alt birimler dahil)', subtree: true },
  { crit: 'ORG_UNIT_TYPE', type: 'SUBJECT_UNIT_TYPE', param: 'Types', label: 'birim tipi', subtree: false },
  { crit: 'TITLE', type: 'SUBJECT_HAS_TITLE', param: 'Titles', label: 'unvan', subtree: false },
  { crit: 'TENANT', type: 'SUBJECT_IN_TENANT', param: 'Tenants', label: 'kurum', subtree: false },
  { crit: 'USER', type: 'SUBJECT_IS_USER', param: 'Users', label: 'kullanıcı', subtree: false },
  { crit: 'USER_KIND', type: 'SUBJECT_KIND', param: 'Kinds', label: 'kimlik türü', subtree: false },
  { crit: 'GROUP', type: 'SUBJECT_IN_GROUP', param: 'Groups', label: 'grup', subtree: false },
]

function criterionOf(d: ConditionDraft) {
  if (d.kind !== 'Predicate' || !d.conditionTypeCode) return null
  const subtree = (d.parameters.IncludeSubtree ?? '').toLowerCase() === 'true'
  const m = audienceMap.find((x) => x.type === d.conditionTypeCode && x.subtree === subtree)
  if (!m || Object.keys(d.parameters).some((k) => k !== m.param && k !== 'IncludeSubtree')) return null
  const values = splitList(d.parameters[m.param])
  return values.length ? { attribute: m.crit, values } : null
}

function rowsOf(d: ConditionDraft, mode: GroupFilterDraft['mode']): GroupFilterDraft[] | null {
  const out: GroupFilterDraft[] = []
  for (const r of d.kind === 'AnyOf' ? d.children : [d]) {
    const criteria = (r.kind === 'AllOf' ? r.children : [r]).map(criterionOf)
    if (criteria.length === 0 || criteria.some((c) => c === null)) return null
    out.push({ mode, criteria: criteria as GroupFilterDraft['criteria'] })
  }
  return out.length ? out : null
}

/** Koşul ağacı bir kitle mi? Biçim: Dahil kısmı [VE DEĞİL (Hariç kısmı)]; kısım = satır veya satırların VEYA'sı. */
export function parseAudience(d?: ConditionDraft): GroupFilterDraft[] | null {
  if (!d) return null
  if (d.kind === 'AllOf' && d.children.length === 2 && d.children[1].kind === 'Not' && d.children[1].children.length === 1) {
    const inc = rowsOf(d.children[0], 'Include')
    const exc = rowsOf(d.children[1].children[0], 'Exclude')
    return inc && exc ? [...inc, ...exc] : null
  }
  return rowsOf(d, 'Include')
}

/** Kitle satırlarından KİM kartının koşul ağacı (PDP Audience.ToCondition ile aynı). */
export function buildAudience(rows: GroupFilterDraft[]): ConditionDraft {
  const part = (mode: GroupFilterDraft['mode']) => {
    const rs = rows.filter((r) => r.mode === mode).map<ConditionDraft>((r) => {
      const preds = r.criteria.map<ConditionDraft>((c) => {
        const m = audienceMap.find((x) => x.crit === c.attribute)!
        return { kind: 'Predicate', conditionTypeCode: m.type, parameters: { [m.param]: c.values.join(','), ...(m.subtree ? { IncludeSubtree: 'true' } : {}) }, children: [] }
      })
      return preds.length === 1 ? preds[0] : { kind: 'AllOf', parameters: {}, children: preds }
    })
    return rs.length === 0 ? undefined : rs.length === 1 ? rs[0] : { kind: 'AnyOf', parameters: {}, children: rs } as ConditionDraft
  }
  const inc = part('Include')!
  const exc = part('Exclude')
  return exc ? { kind: 'AllOf', parameters: {}, children: [inc, { kind: 'Not', parameters: {}, children: [exc] }] } : inc
}

const rowsValid = (rows: GroupFilterDraft[]) =>
  rows.some((r) => r.mode === 'Include') && rows.every((r) => r.criteria.length > 0 && r.criteria.every((c) => c.values.length > 0))

/** Kart sadece tek bir gruptan mı oluşuyor? (karta geri alma adayı) */
const singleGroup = (rows: GroupFilterDraft[] | null) =>
  rows?.length === 1 && rows[0].mode === 'Include' && rows[0].criteria.length === 1 && rows[0].criteria[0].attribute === 'GROUP' && rows[0].criteria[0].values.length === 1
    ? rows[0].criteria[0].values[0] : undefined

// ------------------------------ Kartın kural ↔ ekran çevirisi ------------------------------

/**
 * Kuralın koşulu karta sığıyor mu? KİM kartı: kitle biçimi. Diğerleri: tek seçenek veya seçeneklerin VEYA'sı
 * (seçenek = koşul / DEĞİL koşul / policy referansı, hepsi aynı sorunun tipleri). Sığmıyorsa null → gelişmiş düzenleyici.
 */
export function parseCard(condition: ConditionDraft | undefined, types: ConditionTypeInfo[]): { kind: CardKind; items: CardItem[]; rows?: GroupFilterDraft[] } | null {
  if (!condition) return null
  const rows = parseAudience(condition)
  if (rows) return { kind: 'Who', items: [], rows }
  const nodes = condition.kind === 'AnyOf' ? condition.children : [condition]
  const items: CardItem[] = []
  for (const n of nodes) {
    const negate = n.kind === 'Not'
    const x = negate ? n.children[0] : n
    if (!x || (negate && n.children.length !== 1)) return null
    if (x.kind === 'Predicate' && x.conditionTypeCode) items.push({ negate, kind: 'Predicate', typeCode: x.conditionTypeCode, parameters: { ...x.parameters } })
    else if (x.kind === 'Reference' && x.policyCode) items.push({ negate, kind: 'Reference', policyCode: x.policyCode, parameters: {} })
    else return null
  }
  if (items.length === 0) return null
  const questions = new Set(items.filter((i) => i.kind === 'Predicate').map((i) => types.find((t) => t.code === i.typeCode)?.question ?? null))
  if (questions.has(null) || questions.size > 1 || questions.has('Who')) return null   // kimlik içeren karma ifade → gelişmiş
  const [question] = [...questions]
  return { kind: (question as ConditionQuestion | undefined) ?? 'Policy', items }
}

/** Kart seçeneklerinden koşul ağacı: tek seçenek → kendisi, birden çok → VEYA. */
export function buildCondition(items: CardItem[]): ConditionDraft {
  const nodes = items.map<ConditionDraft>((i) => {
    const x: ConditionDraft = i.kind === 'Reference'
      ? { kind: 'Reference', policyCode: i.policyCode, parameters: {}, children: [] }
      : { kind: 'Predicate', conditionTypeCode: i.typeCode, parameters: Object.fromEntries(Object.entries(i.parameters).filter(([, v]) => v !== '')), children: [] }
    return i.negate ? { kind: 'Not', parameters: {}, children: [x] } : x
  })
  return nodes.length === 1 ? nodes[0] : { kind: 'AnyOf', parameters: {}, children: nodes }
}

// ------------------------------ Görüntüleme ------------------------------

function GroupLink({ code }: { code: string }) {
  const groups = useOptions('groups')
  const g = groups.find((x) => x.code === code)
  return g ? <Link to={`/groups/${g.value}`}><TeamOutlined /> {code}</Link> : <>{code}</>
}

/** Kitle satırı: "rol GISEAST VE birim 101" */
export function AudienceRowText({ row }: { row: GroupFilterDraft }) {
  return (
    <span>
      {row.mode === 'Exclude' && <Tag color="volcano">HARİÇ</Tag>}
      {row.criteria.map((c, i) => {
        const m = audienceMap.find((x) => x.crit === c.attribute)
        return (
          <span key={i}>
            {i > 0 && <Typography.Text type="secondary" style={{ fontSize: 11 }}> VE </Typography.Text>}
            {m?.label ?? c.attribute}: {c.attribute === 'GROUP' ? c.values.map((v, j) => <span key={v}>{j > 0 && ', '}<GroupLink code={v} /></span>) : <b>{c.values.join(', ')}</b>}
          </span>
        )
      })}
    </span>
  )
}

/** Seçeneğin okunur hali (KİM dışı kartlar). */
function ItemText({ item, types }: { item: CardItem; types: ConditionTypeInfo[] }) {
  const not = item.negate ? <Tag color="red">DEĞİL</Tag> : null
  if (item.kind === 'Reference') return <>{not}<PolicyRefLink code={item.policyCode} /></>
  const type = types.find((t) => t.code === item.typeCode)
  const ps = Object.entries(item.parameters).filter(([, v]) => v !== '')
  return <>{not}<Tooltip title={type?.description}>{type?.name ?? item.typeCode}</Tooltip>{ps.length > 0 && <Typography.Text type="secondary"> ({ps.map(([k, v]) => `${k}=${v}`).join(', ')})</Typography.Text>}</>
}

/** Kural kartı (görüntüleme). Karta sığmayan kural "gelişmiş" olarak ifadesiyle gösterilir. */
export function RuleCard({ rule, types, onEdit, onDelete }: { rule: RuleView; types: ConditionTypeInfo[]; onEdit: () => void; onDelete: () => void }) {
  const card = parseCard(rule.condition ? toDraft(rule.condition) : undefined, types)
  const meta = card ? cardMeta[card.kind] : undefined
  const lines = card?.rows
    ? [...card.rows.filter((r) => r.mode === 'Include'), ...card.rows.filter((r) => r.mode === 'Exclude')].map((r, i, all) => (
      <div key={i} style={{ fontSize: 13 }}>{i > 0 && r.mode === 'Include' && all[i - 1].mode === 'Include' && <Typography.Text type="secondary" style={{ fontSize: 11 }}>VEYA </Typography.Text>}<AudienceRowText row={r} /></div>))
    : card?.items.map((it, i) => (
      <div key={i} style={{ fontSize: 13 }}>{i > 0 && <Typography.Text type="secondary" style={{ fontSize: 11 }}>VEYA </Typography.Text>}<ItemText item={it} types={types} /></div>))
  return (
    <Card size="small" style={{ opacity: rule.isActive ? 1 : 0.55, borderLeft: `3px solid ${meta ? cardColor[meta.color] : '#bfbfbf'}` }}
      title={<Flex gap={6} align="center" wrap>{meta ? <Tag color={meta.color}>{meta.label}</Tag> : <Tag>GELİŞMİŞ</Tag>}<span>{rule.name}</span>{!rule.isActive && <Tag>pasif</Tag>}</Flex>}
      extra={<Flex gap={2}><Button size="small" type="text" icon={<EditOutlined />} onClick={onEdit} /><Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={onDelete} /></Flex>}>
      {card ? <Flex vertical gap={4}>{lines}</Flex> : <Typography.Text style={{ fontSize: 12, wordBreak: 'break-word' }}>{rule.expression}</Typography.Text>}
      <Flex justify="space-between" style={{ marginTop: 6 }}>
        <Typography.Text type="secondary" style={{ fontSize: 11 }}><Code>{rule.code}</Code> · #{rule.order}</Typography.Text>
        {rule.reasonCode && <Typography.Text type="secondary" style={{ fontSize: 11 }}>sağlanmazsa <Code>{rule.reasonCode}</Code></Typography.Text>}
      </Flex>
    </Card>
  )
}

/** Tek seçenek düzenleyici (KİM dışı kartlar: koşul tipi parametreleri veya policy seçimi). */
function ItemEditor({ item, onChange, onRemove, kind, types, selfPolicy }: {
  item: CardItem; onChange: (i: CardItem) => void; onRemove: () => void; kind: CardKind; types: ConditionTypeInfo[]; selfPolicy: string
}) {
  const choices = types.filter((t) => t.isAvailable && (kind === 'Policy' ? false : t.question === kind))
  const type = types.find((t) => t.code === item.typeCode)
  const params: ParamDef[] = type ? JSON.parse(type.parameterSchemaJson) : []
  return (
    <Card size="small" style={{ marginBottom: 6, background: '#fafbfc' }} styles={{ body: { padding: 8 } }}>
      <Flex gap={8} wrap align="center">
        <Tooltip title="Koşulun tersi (ör. personel müşterisi DEĞİLSE)"><Checkbox checked={item.negate} onChange={(e) => onChange({ ...item, negate: e.target.checked })}>DEĞİL</Checkbox></Tooltip>
        <Select size="small" style={{ width: 300 }} value={item.kind === 'Reference' ? '@policy' : item.typeCode} placeholder="Seçenek"
          onChange={(v) => {
            if (v === '@policy') return onChange({ negate: item.negate, kind: 'Reference', parameters: {} })
            const t = types.find((x) => x.code === v)
            const defs: ParamDef[] = t ? JSON.parse(t.parameterSchemaJson) : []
            onChange({ negate: item.negate, kind: 'Predicate', typeCode: v, parameters: Object.fromEntries(defs.map((p) => [p.key, p.defaultValue ?? ''])) })
          }}
          options={[...choices.map((t) => ({ value: t.code, label: t.name })), { value: '@policy', label: 'Hazır policy kullan…' }]} />
        {item.kind === 'Reference' && <PolicyRefPicker value={item.policyCode} onChange={(code) => onChange({ ...item, policyCode: code })} exclude={selfPolicy} />}
        <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={onRemove} />
      </Flex>
      {item.kind === 'Predicate' && type && (
        <>
          <Typography.Paragraph type="secondary" style={{ fontSize: 12, margin: '4px 0' }}>{type.description}</Typography.Paragraph>
          <Flex gap={8} wrap>
            {params.map((p) => (
              <Tooltip key={p.key} title={p.description}>
                <Input size="small" addonBefore={p.label + (p.required ? '*' : '')} placeholder={p.defaultValue} value={item.parameters[p.key] ?? ''}
                  onChange={(e) => onChange({ ...item, parameters: { ...item.parameters, [p.key]: e.target.value } })} style={{ width: p.type === 'list' ? 380 : 230 }} />
              </Tooltip>
            ))}
          </Flex>
        </>
      )}
    </Card>
  )
}

// ------------------------------ Örtüşme: "grup yapalım mı?" ------------------------------

interface AudienceRuleRef { policyId: number; policy: string; policyName: string; ruleId: number; rule: string; ruleName: string; memberCount: number }
interface AudienceGroupRef { groupId: number; code: string; name: string; memberCount: number; sameMembers: boolean; hasExplicitMembers: boolean; roles: string[] }
interface AudienceOverlap {
  key: string; expression: string; canBecomeGroup: boolean; members: string[]
  sameDefinition: AudienceRuleRef[]; sameDefinitionGroups: AudienceGroupRef[]
  sameMembersRules: AudienceRuleRef[]; sameMembersGroups: AudienceGroupRef[]
}
interface AudienceChangeResult { groupId?: number; groupCode?: string; groupDeleted: boolean; impact: ChangeImpactResult }

/** Kitle değişince (yarım saniye bekleyip) PDP'ye örtüşmeyi sorar. */
function useOverlap(rows: GroupFilterDraft[], policyId: number, ruleId?: number) {
  const [result, setResult] = useState<AudienceOverlap>()
  const valid = rowsValid(rows)
  const json = JSON.stringify(rows)
  useEffect(() => {
    if (!valid) return
    let cancelled = false
    const t = window.setTimeout(() => {
      api.post<AudienceOverlap>('/api/audiences/overlap', { policyId, ruleId, filters: JSON.parse(json) })
        .then((r) => !cancelled && setResult(r)).catch(() => !cancelled && setResult(undefined))
    }, 500)
    return () => { cancelled = true; window.clearTimeout(t) }
  }, [json, valid, policyId, ruleId])
  return valid ? result : undefined
}

const ruleRefText = (r: AudienceRuleRef) => `${r.policy} / ${r.ruleName}`

/** Tanım aynı → öneri (grup yap / bu grubu kullan); sadece bugünkü üyeler aynı → bilgi. */
function OverlapPanel({ overlap, onUseGroup, onPromote }: { overlap?: AudienceOverlap; onUseGroup: (code: string) => void; onPromote: () => void }) {
  if (!overlap) return null
  const groups = overlap.sameDefinitionGroups.filter((g) => g.sameMembers)
  const info = [...overlap.sameMembersGroups.map((g) => `grup ${g.code}`), ...overlap.sameMembersRules.map(ruleRefText)]
  return (
    <Flex vertical gap={6} style={{ marginTop: 8 }}>
      <Typography.Text type="secondary" style={{ fontSize: 12 }}>
        Bugün <b>{overlap.members.length}</b> kişi: {overlap.members.slice(0, 8).join(', ')}{overlap.members.length > 8 ? ` … (+${overlap.members.length - 8})` : ''}
      </Typography.Text>
      {groups.map((g) => (
        <Alert key={g.groupId} type="success" showIcon message={<>Bu kitle zaten <Link to={`/groups/${g.groupId}`}>{g.code}</Link> grubu ({g.name}) — aynı tanım, aynı {g.memberCount} kişi.</>}
          action={<Button size="small" type="primary" onClick={() => onUseGroup(g.code)}>Bu grubu kullan</Button>} />
      ))}
      {overlap.sameDefinition.length > 0 && groups.length === 0 && (
        <Alert type="warning" showIcon
          message={<>Bu kitle başka KİM kartlarında da birebir aynı: {overlap.sameDefinition.map((r) => <Tag key={r.ruleId}><Link to={`/policies/${r.policyId}`}>{ruleRefText(r)}</Link></Tag>)}</>}
          description={overlap.canBecomeGroup ? 'Adlı bir grup yaparsak tanım tek yerde durur; değişince hepsi birlikte değişir.' : 'İçinde grup satırı olduğu için gruba çevrilemez (grup içinde grup yok).'}
          action={overlap.canBecomeGroup ? <Button size="small" type="primary" onClick={onPromote}>Grup yap</Button> : undefined} />
      )}
      {info.length > 0 && (
        <Typography.Text type="secondary" style={{ fontSize: 12 }}>
          Bilgi: tanımı farklı ama bugün aynı kişileri veren {info.join(', ')} var (tesadüf olabilir; grup önerilmez).
        </Typography.Text>
      )}
    </Flex>
  )
}

/** KİM kartını adlı gruba çevirir: önce etki (kimsenin erişimi değişmemeli), sonra grup + eşleşen kartlar "grup X" olur. */
function PromoteModal({ tenantId, rows, refs, onClose, onDone }: {
  tenantId: number; rows: GroupFilterDraft[]; refs: AudienceRuleRef[]; onClose: () => void; onDone: (code: string) => void
}) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const [checked, setChecked] = useState<AudienceChangeResult>()
  const [busy, setBusy] = useState(false)
  const run = async (dryRun: boolean) => {
    const v = await form.validateFields()
    setBusy(true)
    try {
      const r = await api.post<AudienceChangeResult>(`/api/audiences/promote?dryRun=${dryRun}`, { tenantId, ...v, filters: rows, ruleIds: refs.map((x) => x.ruleId) })
      if (dryRun) setChecked(r)
      else { message.success(`${r.groupCode} grubu oluşturuldu; ${refs.length} kart artık bu grubu kullanıyor`); invalidateOptions('groups'); onDone(r.groupCode!) }
    } catch (e) { setChecked(undefined); message.error((e as Error).message) } finally { setBusy(false) }
  }
  return (
    <Modal open title="KİM kartını gruba çevir" onCancel={onClose} destroyOnHidden
      footer={<Space><Button onClick={onClose}>Vazgeç</Button><Button loading={busy} onClick={() => run(true)}>Etkiyi kontrol et</Button>
        <Button type="primary" loading={busy} disabled={!checked} onClick={() => run(false)}>Grup yap</Button></Space>}>
      <Typography.Paragraph type="secondary" style={{ fontSize: 12 }}>
        Grup bu satırlarla oluşturulur; şu kartlar "grup …" satırına çevrilir: {refs.map((r) => <Tag key={r.ruleId}>{ruleRefText(r)}</Tag>)} ve bu kart da grubu kullanır.
        Kimsenin erişimi değişmemeli; değişiyorsa işlem yapılmaz.
      </Typography.Paragraph>
      <Form form={form} layout="vertical" onValuesChange={() => setChecked(undefined)}>
        <Form.Item name="code" label="Grup kodu" rules={[{ required: true }]}><Input placeholder="GISE_101" /></Form.Item>
        <Form.Item name="name" label="Grup adı" rules={[{ required: true }]}><Input placeholder="101 Şube gişe asistanları" /></Form.Item>
        <Form.Item name="description" label="Açıklama"><Input.TextArea rows={2} /></Form.Item>
      </Form>
      {checked && <Alert type="success" showIcon message={`Kontrol edildi: ${checked.impact.summary}`} />}
    </Modal>
  )
}

/** Tek kullanımlık grubu karta geri alır (açık üyesi / rolü olmayan; başka yerde kullanılmıyorsa grup silinir). */
function DemoteButton({ groupCode, ruleId, onDone }: { groupCode: string; ruleId: number; onDone: () => void }) {
  const groups = useOptions('groups')
  const { message, modal } = App.useApp()
  const group = groups.find((g) => g.code === groupCode)
  if (!group) return null
  const start = async () => {
    try {
      const preview = await api.post<AudienceChangeResult>('/api/audiences/demote?dryRun=true', { groupId: group.value, ruleIds: [ruleId] })
      modal.confirm({
        title: `${groupCode} grubunu karta aç`,
        content: <>Grubun kuralı bu kartın içine satır olarak yazılır{preview.groupDeleted ? ' ve başka yerde kullanılmadığı için grup silinir' : '; grup başka yerde kullanıldığı için durur'}.
          <br />Kontrol: {preview.impact.summary}</>,
        okText: 'Karta aç',
        onOk: async () => {
          await api.post('/api/audiences/demote?dryRun=false', { groupId: group.value, ruleIds: [ruleId] })
          message.success('Grup karta alındı'); invalidateOptions('groups'); onDone()
        },
      })
    } catch (e) { message.error((e as Error).message) }
  }
  return <Button size="small" onClick={start}>Grubu karta aç (satırlara dönüştür)</Button>
}

// ------------------------------ Kart düzenleyici ------------------------------

export interface CardSubmit {
  draft: RuleDraft
  body: object
}

const emptyRows = (): GroupFilterDraft[] => [{ mode: 'Include', criteria: [{ attribute: 'ROLE', values: [] }] }]

/**
 * Kart düzenleyici: yeni kart (soru seçilir) veya karta sığan mevcut kural. Kaydedilen şey sıradan kuraldır;
 * "Etkiyi gör" ile kim kazanır / kaybeder senaryosu (PolicyChangeModal) açılır.
 */
export function CardRuleModal({ policyId, policyCode, tenantId, kind: initialKind, rule, existingCodes, types, onClose, onSubmit, onAdvanced, onChanged }: {
  policyId: number
  policyCode: string
  tenantId: number
  kind?: CardKind
  rule?: RuleView
  existingCodes: string[]
  types: ConditionTypeInfo[]
  onClose: () => void
  onSubmit: (s: CardSubmit) => void
  onAdvanced?: () => void
  /** Kart dışında kayıt yapıldı (grup yap / karta aç): sayfa yenilenmeli. */
  onChanged: () => void
}) {
  const parsed = rule ? parseCard(rule.condition ? toDraft(rule.condition) : undefined, types) : null
  const [kind, setKind] = useState<CardKind>(parsed?.kind ?? initialKind ?? 'Who')
  const [items, setItems] = useState<CardItem[]>(parsed?.items ?? [])
  const [rows, setRows] = useState<GroupFilterDraft[]>(parsed?.rows ?? emptyRows())
  const [promoting, setPromoting] = useState(false)
  const [form] = Form.useForm()
  const meta = cardMeta[kind]
  const uniqueCode = (base: string) => { let c = base; for (let n = 2; existingCodes.includes(c); n++) c = `${base}_${n}`; return c }
  const overlap = useOverlap(kind === 'Who' ? rows : [], policyId, rule?.id)
  const savedGroup = rule ? singleGroup(parsed?.rows ?? null) : undefined

  const condition = kind === 'Who' ? (rowsValid(rows) ? buildAudience(rows) : undefined) : items.length ? buildCondition(items) : undefined
  const incomplete = kind !== 'Who' && items.some((i) => (i.kind === 'Reference' ? !i.policyCode : !i.typeCode))
  const applyGroup = (code: string) => setRows([{ mode: 'Include', criteria: [{ attribute: 'GROUP', values: [code] }] }])

  const submit = async () => {
    const v = await form.validateFields()
    if (!condition || incomplete) return
    onSubmit({ draft: { policyId, code: v.code, name: v.name, order: v.order, reasonCode: v.reasonCode, isActive: v.isActive, condition }, body: { ...v, condition } })
  }
  return (
    <Modal open width={940} onCancel={onClose} onOk={submit} okText="Etkiyi gör" okButtonProps={{ disabled: !condition || incomplete }} destroyOnHidden
      title={<Flex gap={8} align="center"><Tag color={meta.color}>{meta.label}</Tag>{rule ? `kartı: ${rule.name}` : 'kartı ekle'}</Flex>}
      footer={(_, { OkBtn, CancelBtn }) => <Flex justify="space-between">{onAdvanced ? <Button onClick={onAdvanced}>Gelişmiş düzenleyicide aç</Button> : <span />}<Flex gap={8}><CancelBtn /><OkBtn /></Flex></Flex>}>
      {!rule && (
        <Flex gap={6} wrap style={{ marginBottom: 10 }}>
          {cardKinds.map((k) => (
            <Tag.CheckableTag key={k} checked={k === kind} onChange={() => {
              setKind(k); setItems([]); setRows(emptyRows())
              form.setFieldsValue({ code: uniqueCode(cardMeta[k].code), name: cardMeta[k].label, reasonCode: cardMeta[k].reason, order: cardMeta[k].order })
            }}>{cardMeta[k].label}</Tag.CheckableTag>
          ))}
        </Flex>
      )}
      <Typography.Paragraph type="secondary" style={{ fontSize: 12 }}>
        {meta.help}{kind !== 'Who' && <> Kart içindeki seçeneklerden <b>biri</b> sağlanırsa kart sağlanır (VEYA).</>}
      </Typography.Paragraph>

      {kind === 'Who' ? (
        <>
          <GroupFilterEditor value={rows} onChange={setRows} forCard />
          <OverlapPanel overlap={overlap} onUseGroup={applyGroup} onPromote={() => setPromoting(true)} />
          {savedGroup && rule && singleGroup(rows) === savedGroup && (
            <Flex align="center" gap={8} style={{ marginTop: 8 }}>
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>Bu kart sadece <GroupLink code={savedGroup} /> grubundan oluşuyor; grup tek kullanımlıksa satırlara açılabilir.</Typography.Text>
              <DemoteButton groupCode={savedGroup} ruleId={rule.id} onDone={() => { onChanged(); onClose() }} />
            </Flex>
          )}
          <Alert type="info" showIcon style={{ marginTop: 8 }} message="Kimlik bu policy'nin içinde: “kimde var?”, SoD ve RACF/LDAP mutabakatı bu kartı istek beklemeden çözer. Grup kuralıyla aynı biçimdir; birden fazla yerde gerekiyorsa adlı grup yapın." />
        </>
      ) : (
        <>
          {items.map((it, i) => (
            <ItemEditor key={i} item={it} kind={kind} types={types} selfPolicy={policyCode}
              onChange={(x) => setItems(items.map((y, j) => (j === i ? x : y)))} onRemove={() => setItems(items.filter((_, j) => j !== i))} />
          ))}
          <Button size="small" icon={<PlusOutlined />} onClick={() => setItems([...items, kind === 'Policy'
            ? { negate: false, kind: 'Reference', parameters: {} }
            : { negate: false, kind: 'Predicate', parameters: {} }])}>
            {kind === 'Policy' ? 'Policy ekle' : 'Seçenek ekle'}
          </Button>
        </>
      )}

      {condition && <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 10 }}>Kaydedilecek koşul: <Code>{renderDraft(condition)}</Code></Typography.Paragraph>}

      <Form form={form} layout="vertical" style={{ marginTop: 12 }}
        initialValues={rule ? { code: rule.code, name: rule.name, order: rule.order, reasonCode: rule.reasonCode, isActive: rule.isActive }
          : { code: uniqueCode(meta.code), name: meta.label, reasonCode: meta.reason, order: meta.order, isActive: true }}>
        <Row gutter={12}>
          <Col span={6}><Form.Item name="code" label="Kural kodu" rules={[{ required: true }]}><Input disabled={!!rule} /></Form.Item></Col>
          <Col span={10}><Form.Item name="name" label="Kart adı" rules={[{ required: true }]}><Input /></Form.Item></Col>
          <Col span={4}><Form.Item name="order" label="Sıra"><InputNumber style={{ width: '100%' }} /></Form.Item></Col>
          <Col span={4}><Form.Item name="isActive" label="Aktif" valuePropName="checked"><Switch /></Form.Item></Col>
          <Col span={12}><Form.Item name="reasonCode" label="Sağlanmazsa neden kodu"><Input /></Form.Item></Col>
        </Row>
      </Form>

      {promoting && overlap && (
        <PromoteModal tenantId={tenantId} rows={rows} refs={overlap.sameDefinition} onClose={() => setPromoting(false)}
          onDone={(code) => { setPromoting(false); applyGroup(code); onChanged() }} />
      )}
    </Modal>
  )
}
