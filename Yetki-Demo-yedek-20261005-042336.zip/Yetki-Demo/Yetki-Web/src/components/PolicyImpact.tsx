import { Alert, App, Button, Card, Col, Collapse, DatePicker, Empty, Flex, Input, Modal, Row, Spin, Statistic, Tabs, Tag, Tooltip, Typography } from 'antd'
import { DataTable as Table } from './DataTable'
import { DeleteOutlined, DownloadOutlined, PlusOutlined } from '@ant-design/icons'
import { useCallback, useEffect, useState } from 'react'
import dayjs, { type Dayjs } from 'dayjs'
import { api } from '../api/client'
import type { DecisionChange, ImpactScenario, AccessPolicyDiff, PolicyChangeSet, PolicyImpactResult } from '../api/types'
import { AccessKey, Code, DecisionTag } from './common'
import { downloadCsv } from './csv'
import { useManagedResultScroll, useReportDownload } from './ReportDownloadContext'

// ---------------------------------------------------------------- Senaryolar

export const SCENARIO_KEYS = ['IpAddress', 'TransactionAmount', 'BranchCode', 'CustomerId'] as const

export const DEFAULT_SCENARIOS: ImpactScenario[] = [
  { name: 'Şubeden tipik işlem', client: 'nextral-api', context: { IpAddress: '10.1.2.3', TransactionAmount: '20000', BranchCode: '@userBranch', CustomerId: 'C-555' } },
  { name: 'Yüksek tutar', client: 'nextral-api', context: { IpAddress: '10.1.2.3', TransactionAmount: '1500000', BranchCode: '@userBranch', CustomerId: 'C-555' } },
  { name: 'Saha tableti / dış IP', client: 'mobil-sube-tablet', context: { IpAddress: '85.100.1.1', TransactionAmount: '20000', BranchCode: '@userBranch', CustomerId: 'C-555' } },
]

export function nextBusinessMorning(): Dayjs {
  let d = dayjs().hour(11).minute(0).second(0)
  if (dayjs().hour() >= 18) d = d.add(1, 'day')
  while (d.day() === 0 || d.day() === 6) d = d.add(1, 'day')
  return d
}

/** Karar karşılaştırmasında kullanılacak örnek context'ler. "@userBranch" = her kullanıcının kendi birimi. */
export function ScenarioEditor({ value, onChange }: { value: ImpactScenario[]; onChange: (v: ImpactScenario[]) => void }) {
  const set = (i: number, key: string, v: string) =>
    onChange(value.map((s, j) => (j !== i ? s : key === '__name' ? { ...s, name: v } : key === '__client' ? { ...s, client: v || undefined } : { ...s, context: { ...s.context, [key]: v } })))
  return (
    <Flex vertical gap={6}>
      <Table
        size="small"
        pagination={false}
        rowKey={(_, i) => String(i)}
        dataSource={value}
        scroll={{ x: 980 }}
        columns={[
          { title: 'Senaryo', width: 170, render: (_, s, i) => <Input size="small" value={s.name} onChange={(e) => set(i, '__name', e.target.value)} /> },
          { title: 'Client', width: 170, render: (_, s, i) => <Input size="small" value={s.client ?? ''} placeholder="(yok)" onChange={(e) => set(i, '__client', e.target.value)} /> },
          ...SCENARIO_KEYS.map((k) => ({
            title: k,
            render: (_: unknown, s: ImpactScenario, i: number) => <Input size="small" value={s.context[k] ?? ''} onChange={(e) => set(i, k, e.target.value)} />,
          })),
          { width: 40, render: (_, __, i) => <Button size="small" type="text" icon={<DeleteOutlined />} onClick={() => onChange(value.filter((_, j) => j !== i))} /> },
        ]}
      />
      <Flex justify="space-between" align="center">
        <Button size="small" icon={<PlusOutlined />} onClick={() => onChange([...value, { name: `Senaryo ${value.length + 1}`, context: {} }])}>Senaryo ekle</Button>
        <Typography.Text type="secondary" style={{ fontSize: 12 }}>
          <Code>@userBranch</Code> = her kullanıcının kendi birim kodu. Boş alan context'e gönderilmez.
        </Typography.Text>
      </Flex>
    </Flex>
  )
}

export const cleanScenarios = (s: ImpactScenario[]) =>
  s.map((x) => ({ name: x.name, client: x.client, context: Object.fromEntries(Object.entries(x.context).filter(([, v]) => v !== undefined && v !== '')) }))

// ---------------------------------------------------------------- Sonuç görünümü

const changeMeta: Record<DecisionChange, { color: string; label: string }> = {
  NEWLY_DENIED: { color: 'red', label: 'İzin → Red' },
  NEWLY_INDETERMINATE: { color: 'orange', label: 'İzin → Indeterminate' },
  NEWLY_ALLOWED: { color: 'green', label: '→ İzin (Permit)' },
  REASON_CHANGED: { color: 'gold', label: 'Red nedeni değişir' },
  UNCHANGED: { color: 'default', label: 'Değişmez' },
}

function RuleTags({ diff }: { diff: AccessPolicyDiff }) {
  const key = (r: { policy: string; code: string }) => `${r.policy}/${r.code}`
  const all = new Map([...diff.rulesBefore, ...diff.rulesAfter].map((r) => [key(r), r]))
  return (
    <Flex wrap gap={4}>
      {[...all.entries()].map(([k, r]) => {
        const added = diff.addedRules.includes(k)
        const removed = diff.removedRules.includes(k)
        const changed = diff.changedRules.some((x) => `${x.policy}/${x.ruleCode}` === k)
        return (
          <Tooltip key={k} title={r.expression}>
            <Tag color={added ? 'green' : removed ? 'red' : changed ? 'gold' : 'default'} style={removed ? { textDecoration: 'line-through' } : undefined}>
              {added ? '+ ' : removed ? '− ' : changed ? '~ ' : ''}{r.code}
            </Tag>
          </Tooltip>
        )
      })}
      {all.size === 0 && <Typography.Text type="secondary">policy yok (koşulsuz)</Typography.Text>}
    </Flex>
  )
}

/** Policy What-If sonucu: yapısal fark, yeni gerekli context, senaryolarda karar değişimleri, etkilenen kullanıcılar. */
export function PolicyImpactView({ result }: { result: PolicyImpactResult }) {
  const newCtx = [...new Set(result.accesses.flatMap((p) => p.newRequiredAttributes))]
  const withoutEnforcedRules = result.accesses.filter((p) => p.hasNoEnforcedRulesAfter)

  const exportCsv = useCallback(() =>
    downloadCsv('policy-etki-analizi.csv', [
      ['Kullanıcı', 'Ad Soyad', 'Permission', 'Senaryo', 'Mevcut karar', 'Mevcut neden', 'Yeni karar', 'Yeni neden', 'Değişim'],
      ...result.rows.map((r) => [r.userName, r.fullName, r.permission, r.scenario, r.before.decision, r.before.reasonCode, r.after.decision, r.after.reasonCode, changeMeta[r.change].label]),
    ]), [result])
  const { isManaged } = useReportDownload(exportCsv)
  useManagedResultScroll(isManaged, result)

  return (
    <Flex vertical gap={12}>
      {!isManaged && <Alert type={result.newlyDenied ? 'warning' : 'info'} showIcon message="Policy etki özeti" description={result.summary} />}
      {!isManaged && <Flex justify="flex-end">
        <Button icon={<DownloadOutlined />} onClick={exportCsv}>Raporu indir (CSV)</Button>
      </Flex>}
      {result.truncated && <Alert type="error" showIcon message="Etki analizi tamamlanmadı"
        description="Değerlendirme sınırına ulaşıldı. Eksik analizle değişiklik uygulanamaz; kapsamı daraltın veya analiz limitini artırın." />}
      {newCtx.length > 0 && (
        <Alert type="warning" showIcon message={<>Yeni gerekli attribute: {newCtx.map((k) => <Tag key={k} color="orange">{k}</Tag>)}</>}
          description="Bu yetkileri çağıran uygulamalar / gateway bu değerleri göndermiyorsa kararlar Indeterminate olur ve işlem REDDEDİLİR." />
      )}
      {withoutEnforcedRules.length > 0 && (
        <Alert type="warning" showIcon message={`${withoutEnforcedRules.length} yetkide aktif Enforce kuralı kalmıyor`}
          description={<>Bu durum otomatik olarak koşulsuz izin anlamına gelmez; policy belirsiz sonuç üretip erişimi kapatabilir. Senaryo sonuçlarını doğrulayın: {[...new Set(withoutEnforcedRules.map((p) => p.key))].slice(0, 12).map((c) => <Tag key={c}>{c}</Tag>)}</>} />
      )}
      <Card size="small" className="what-if-impact-metrics">
        <div className="what-if-impact-metrics-head"><span>IMPACT SNAPSHOT</span>{isManaged ? <Button type="primary" icon={<DownloadOutlined />} onClick={exportCsv}>Raporu indir</Button> : <strong>Etki özeti</strong>}</div>
        <div className="what-if-impact-metrics-grid">
          <Statistic className="is-scope" title="Etkilenen permission" value={result.accesses.length} />
          <Statistic className="is-retained" title="Etkilenen kullanıcı" value={result.affectedUsers.length} />
          <Statistic className="is-loss" title="İzin → Red" value={result.newlyDenied} />
          <Statistic className="is-gain" title="Red → İzin" value={result.newlyAllowed} />
          <Statistic className="is-sod" title="Diğer değişim" value={result.otherChanged} />
          <Statistic className="is-external" title="Değişmeyen" value={result.unchanged} />
          <Statistic className="is-scope" title="Değerlendirme" value={result.evaluations} suffix={result.truncated ? '(kesildi)' : undefined} />
        </div>
      </Card>

      <Tabs
        items={[
          {
            key: 'rows',
            label: `Karar değişimleri (${result.rows.length})`,
            children:
              result.scenarios.length === 0 ? (
                <Alert type="info" message="Senaryo verilmediği için karar karşılaştırması yapılmadı; yapısal fark ve etkilenen kullanıcılar sekmelerine bakın." />
              ) : result.rows.length === 0 ? (
                <Empty description="Senaryolarda hiçbir kararda değişiklik yok" />
              ) : (
                <>
                  <Table
                    size="small"
                    rowKey={(r) => `${r.userId}-${r.permission}-${r.scenario}`}
                    dataSource={result.rows}
                    pagination={{}}
                    columns={[
                      { title: 'Kullanıcı', render: (_, r) => <><b>{r.userName}</b><br /><Typography.Text type="secondary">{r.fullName}</Typography.Text></>, sorter: (a, b) => a.userName.localeCompare(b.userName) },
                      { title: 'Yetki', dataIndex: 'permission', render: (v) => <Code>{v}</Code>, filters: [...new Set(result.rows.map((r) => r.permission))].map((p) => ({ text: p, value: p })), onFilter: (v, r) => r.permission === v },
                      { title: 'Senaryo', dataIndex: 'scenario', filters: result.scenarios.map((s) => ({ text: s.name, value: s.name })), onFilter: (v, r) => r.scenario === v },
                      { title: 'Şu an', render: (_, r) => <Tooltip title={r.before.reason}><DecisionTag decision={r.before.decision} /> <Typography.Text style={{ fontSize: 12 }}>{r.before.reasonCode}</Typography.Text></Tooltip> },
                      { title: 'Değişiklik sonrası', render: (_, r) => <Tooltip title={r.after.reason}><DecisionTag decision={r.after.decision} /> <Typography.Text style={{ fontSize: 12 }}>{r.after.reasonCode}</Typography.Text></Tooltip> },
                      {
                        title: 'Etki',
                        render: (_, r) => <Tag color={changeMeta[r.change].color}>{changeMeta[r.change].label}</Tag>,
                        filters: (Object.keys(changeMeta) as DecisionChange[]).map((k) => ({ text: changeMeta[k].label, value: k })),
                        onFilter: (v, r) => r.change === v,
                      },
                    ]}
                  />
                </>
              ),
          },
          {
            key: 'diff',
            label: 'Yapısal fark (yetki bazlı)',
            children: (
              <Table<AccessPolicyDiff>
                size="small"
                rowKey="resourceScopeId"
                dataSource={result.accesses}
                pagination={result.accesses.length > 10 ? {} : false}
                expandable={{
                  rowExpandable: (d) => d.changedRules.length > 0,
                  expandedRowRender: (d) =>
                    d.changedRules.map((c) => (
                      <div key={c.policy + c.ruleCode} style={{ marginBottom: 8 }}>
                        <Code>{c.policy} / {c.ruleCode}</Code>
                        <div style={{ fontSize: 12 }}><Typography.Text type="secondary">önce:</Typography.Text> {c.expressionBefore}</div>
                        <div style={{ fontSize: 12 }}><Typography.Text type="secondary">sonra:</Typography.Text> <b>{c.expressionAfter}</b></div>
                      </div>
                    )),
                }}
                columns={[
                  { title: 'Yetki', render: (_, d) => <><AccessKey value={d.key} /><br /><Typography.Text type="secondary">{d.name}</Typography.Text></> },
                  { title: 'Sahip', dataIndex: 'holderCount', width: 70 },
                  {
                    title: 'Policy (önce → sonra)',
                    render: (_, d) => (
                      <>
                        <Flex vertical gap={2}>
                          <div><Typography.Text type="secondary" style={{ fontSize: 12 }}>önce: </Typography.Text>{d.policiesBefore.length ? d.policiesBefore.map((p) => <Tag key={'b' + p}>{p}</Tag>) : <Tag>yok</Tag>}</div>
                          <div><Typography.Text type="secondary" style={{ fontSize: 12 }}>sonra: </Typography.Text>{d.policiesAfter.length ? d.policiesAfter.map((p) => <Tag key={'a' + p} color="purple">{p}</Tag>) : <Tag color="red">yok</Tag>}</div>
                        </Flex>
                      </>
                    ),
                  },
                  { title: 'Uygulanan rule\'lar', render: (_, d) => <RuleTags diff={d} /> },
                  {
                    title: 'Çağıranın sağlaması gereken (sonra)',
                    render: (_, d) => d.requiredAttributesAfter.map((k) => <Tag key={k} color={d.newRequiredAttributes.includes(k) ? 'orange' : 'default'}>{d.newRequiredAttributes.includes(k) ? 'YENİ ' : ''}{k}</Tag>),
                  },
                ]}
              />
            ),
          },
          {
            key: 'users',
            label: `Etkilenen kullanıcılar (${result.affectedUsers.length})`,
            children: (
              <Table
                size="small"
                rowKey="userId"
                dataSource={result.affectedUsers}
                pagination={{}}
                columns={[
                  { title: 'Kullanıcı', dataIndex: 'userName' },
                  { title: 'Ad', dataIndex: 'fullName' },
                  { title: 'Tenant', dataIndex: 'tenant', render: (v) => <Tag>{v}</Tag> },
                  { title: 'İlgili permission\'lar', dataIndex: 'permissions', render: (v: string[]) => v.map((p) => <Tag key={p}>{p}</Tag>) },
                ]}
              />
            ),
          },
        ]}
      />
    </Flex>
  )
}

// ---------------------------------------------------------------- Çalıştırıcı + onay modalı

/** Policy değişiklik seti + senaryolar + an → /api/simulation/policy-impact */
export function usePolicyImpact() {
  const { message } = App.useApp()
  const [result, setResult] = useState<PolicyImpactResult>()
  const [loading, setLoading] = useState(false)
  const run = async (changes: PolicyChangeSet, scenarios: ImpactScenario[], asOf?: Dayjs) => {
    setLoading(true)
    try {
      setResult(await api.post<PolicyImpactResult>('/api/simulation/policy-impact', {
        changes, scenarios: cleanScenarios(scenarios), asOfUtc: asOf?.toISOString(),
      }))
    } catch (e) {
      message.error((e as Error).message)
      setResult(undefined)
    } finally {
      setLoading(false)
    }
  }
  return { result, loading, run, setResult }
}

export function ScenarioSettings({ scenarios, setScenarios, asOf, setAsOf }: {
  scenarios: ImpactScenario[]; setScenarios: (s: ImpactScenario[]) => void; asOf?: Dayjs; setAsOf: (d?: Dayjs) => void
}) {
  return (
    <Collapse
      size="small"
      items={[{
        key: 's',
        label: `Karar senaryoları (${scenarios.length}) ve karar anı: ${asOf ? asOf.format('DD.MM.YYYY HH:mm') : 'şimdi'}`,
        children: (
          <Row gutter={[12, 12]}>
            <Col span={24}><ScenarioEditor value={scenarios} onChange={setScenarios} /></Col>
            <Col span={24}>
              <Flex gap={8} align="center">
                <Typography.Text>Karar anı:</Typography.Text>
                <DatePicker showTime value={asOf} onChange={(d) => setAsOf(d ?? undefined)} />
                <Typography.Text type="secondary" style={{ fontSize: 12 }}>Mesai saati kuralları bu ana göre değerlendirilir.</Typography.Text>
              </Flex>
            </Col>
          </Row>
        ),
      }]}
    />
  )
}

/** Tek bir policy/rule değişikliğini uygulamadan önce etkisini gösterir, onaylanırsa uygular. */
export function PolicyChangeModal({ open, title, changes, apply, onClose, onDone }: {
  open: boolean
  title: string
  changes: PolicyChangeSet
  apply: (expectedModelVersion: number) => Promise<unknown>
  onClose: () => void
  onDone: () => void
}) {
  const { message } = App.useApp()
  const [scenarios, setScenarios] = useState<ImpactScenario[]>(DEFAULT_SCENARIOS)
  const [asOf, setAsOf] = useState<Dayjs | undefined>(nextBusinessMorning())
  const { result, loading, run, setResult } = usePolicyImpact()
  const [applying, setApplying] = useState(false)

  useEffect(() => {
    if (open) run(changes, scenarios, asOf)
    else setResult(undefined)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const doApply = async () => {
    setApplying(true)
    try {
      if (!result || result.truncated) return
      await apply(result.modelVersion)
      message.success('Uygulandı')
      onDone()
      onClose()
    } catch (e) {
      message.error((e as Error).message)
    } finally {
      setApplying(false)
    }
  }

  return (
    <Modal
      open={open}
      title={title}
      onCancel={onClose}
      width={1150}
      destroyOnHidden
      footer={
        <Flex justify="space-between">
          <Button onClick={() => run(changes, scenarios, asOf)} loading={loading}>Senaryolarla yeniden hesapla</Button>
          <Flex gap={8}>
            <Button onClick={onClose}>Vazgeç</Button>
            <Button type="primary" danger={!!result?.newlyDenied} disabled={!result || result.truncated} loading={applying} onClick={doApply}>Onayla ve uygula</Button>
          </Flex>
        </Flex>
      }
    >
      <Flex vertical gap={12}>
        <ScenarioSettings scenarios={scenarios} setScenarios={setScenarios} asOf={asOf} setAsOf={setAsOf} />
        {loading && <Spin />}
        {result && <PolicyImpactView result={result} />}
      </Flex>
    </Modal>
  )
}
