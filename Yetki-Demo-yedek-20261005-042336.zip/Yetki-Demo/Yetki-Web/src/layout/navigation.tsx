﻿import {
  AppstoreOutlined, AuditOutlined, BranchesOutlined, CloudServerOutlined, ClusterOutlined,
  ExperimentOutlined, FileProtectOutlined, FileSearchOutlined, GlobalOutlined, KeyOutlined,
  MobileOutlined, SafetyCertificateOutlined, TeamOutlined, ThunderboltOutlined, UserOutlined,
  ProfileOutlined,
} from '@ant-design/icons'
import type { ReactNode } from 'react'

export interface PageDefinition {
  key: string
  label: string
  icon: ReactNode
  task: string
  hint: string
}

interface NavigationSection {
  key: string
  label: string
  children: readonly PageDefinition[]
}

interface WorkspaceSection extends NavigationSection {
  icon: ReactNode
  description: string
  owner: string
}

/** Sayfa bilgisi tek yerde tutulur; navbar sırası ile dashboard sahipliği bağımsız kurulur. */
export const pageRegistry = {
  tenants: { key: '/tenants', label: 'Tenants & Organization', icon: <GlobalOutlined />, task: 'Tenants & Organization', hint: 'Tenant, organizasyon birimleri ve hiyerarşi bilgileri.' },
  users: { key: '/users', label: 'Users & Assignments', icon: <UserOutlined />, task: 'Users & Assignments', hint: 'User profili, iş rolü, şube ve organizasyon atamaları.' },
  roles: { key: '/roles', label: 'Role Directory', icon: <SafetyCertificateOutlined />, task: 'Role Directory', hint: 'İş rolü tanımları ve sahipleri. Rolün eriştiği yetkiler Role policy ve permission bağlantılarından gelir.' },
  groups: { key: '/groups', label: 'Access Groups', icon: <TeamOutlined />, task: 'Access Groups', hint: 'Erişim amaçlı grup, üyelik kriterleri ve rolleri.' },

  resources: { key: '/resources', label: 'Resources', icon: <ClusterOutlined />, task: 'Resources', hint: 'Application → resource → scope ve METHOD + URI eşlemeleri.' },
  permissions: { key: '/permissions', label: 'Permissions', icon: <KeyOutlined />, task: 'Permissions', hint: 'Hangi resource / scope, hangi policy’lerle korunur?' },
  policies: { key: '/policies', label: 'Policies & Rules', icon: <FileProtectOutlined />, task: 'Policies & Rules', hint: 'Kim, nereden, ne zaman ve hangi koşullarda erişebilir?' },

  resourceTypes: { key: '/resource-types', label: 'Resource Types', icon: <AppstoreOutlined />, task: 'Resource Types', hint: 'Endpoint, menü, ekran ve buton gibi resource sınıfları.' },
  conditionTypes: { key: '/condition-types', label: 'Condition Types', icon: <BranchesOutlined />, task: 'Condition Types', hint: 'Rule oluştururken kullanılabilen condition tipleri ve parametre sözleşmeleri.' },
  clients: { key: '/clients', label: 'Clients', icon: <MobileOutlined />, task: 'Clients', hint: 'İsteği başlatan uygulamalar, aracılar ve servis hesapları.' },
  ownershipTeams: { key: '/ownership-teams', label: 'Ownership Teams', icon: <TeamOutlined />, task: 'Ownership Teams', hint: 'Application ve resource sahiplik ekipleri.' },

  sod: { key: '/sod', label: 'SoD Controls', icon: <SafetyCertificateOutlined />, task: 'SoD Controls', hint: 'Birlikte bulunamayan rol/yetkiler, ihlaller, severity ve enforcement.' },
  external: { key: '/external', label: 'External Dependencies', icon: <CloudServerOutlined />, task: 'External Dependencies', hint: 'Dış sistem yetkileri, bağımlılıklar, mutabakat ve provisioning.' },

  evaluate: { key: '/evaluate', label: 'Decision Analysis', icon: <ThunderboltOutlined />, task: 'Decision Analysis', hint: 'Authorization isteğini canlı akış diyagramında oluştur, permission ve policy karar yolunu izle.' },
  whatIf: { key: '/what-if', label: 'Change Simulation', icon: <ExperimentOutlined />, task: 'Change Simulation', hint: 'Senaryo odaklı çalışma alanında değişiklik etkisini incele ve raporla.' },
  inventory: { key: '/inventory', label: 'Inventory & Coverage', icon: <FileSearchOutlined />, task: 'Inventory & Coverage', hint: 'Gerçek envanter ile yetki tanımlarını karşılaştır: tanımsız, atıl ve korunmayan.' },
  audit: { key: '/audit', label: 'Audit & Decision History', icon: <AuditOutlined />, task: 'Audit & Decision History', hint: 'Geçmiş kararların gerekçeleri ve yönetim değişiklikleri.' },
  platformBrief: { key: '/platform-brief', label: 'Platform Brief', icon: <ProfileOutlined />, task: 'Platform Brief', hint: 'Platform kabiliyetleri, hedef mimari, Keycloak karşılaştırması ve yol haritası.' },
} as const satisfies Record<string, PageDefinition>

/** Navbar: ilişkili işler alt alta; başlıklar sabittir ve açılıp kapanmaz. */
export const navigationSections: readonly NavigationSection[] = [
  { key: 'identity-nav', label: 'IDENTITY & ASSIGNMENTS', children: [pageRegistry.tenants, pageRegistry.roles, pageRegistry.groups, pageRegistry.users] },
  { key: 'authorization-nav', label: 'AUTHORIZATION MODEL', children: [pageRegistry.resources, pageRegistry.permissions, pageRegistry.policies] },
  { key: 'definitions-nav', label: 'SUPPORTING DEFINITIONS', children: [pageRegistry.resourceTypes, pageRegistry.conditionTypes, pageRegistry.clients, pageRegistry.ownershipTeams] },
  { key: 'controls-nav', label: 'CONTROLS & INTEGRATIONS', children: [pageRegistry.sod, pageRegistry.external] },
  { key: 'analysis-nav', label: 'ANALYSIS & MONITORING', children: [pageRegistry.evaluate, pageRegistry.whatIf, pageRegistry.inventory, pageRegistry.audit, pageRegistry.platformBrief] },
] as const

/** Workspace: dashboard üzerinde veri ve işlem sahibine göre mevcut ayrım korunur. */
export const workspaces: readonly WorkspaceSection[] = [
  {
    key: 'identity', label: 'Identity & Organization', icon: <UserOutlined />,
    description: 'Yetki kararında kullanılan HR / Identity kaynaklı kullanıcı, rol, tenant ve organizasyon bilgileri.',
    owner: 'Veri sahibi: HR / Identity ekipleri · Yetki yönetimi burada karar vermez',
    children: [pageRegistry.tenants, pageRegistry.users, pageRegistry.roles],
  },
  {
    key: 'catalogs', label: 'Catalogs & Controls', icon: <ClusterOutlined />,
    description: 'Uygulama, entegrasyon ve risk ekiplerince sağlanan resource, envanter, client, sahiplik, SoD ve dış sistem tanımları.',
    owner: 'Veri sahibi: Uygulama / Entegrasyon / Risk ekipleri · Yetki yönetimi tanımları uygular',
    children: [pageRegistry.resources, pageRegistry.inventory, pageRegistry.resourceTypes, pageRegistry.clients,
      pageRegistry.conditionTypes, pageRegistry.ownershipTeams, pageRegistry.sod, pageRegistry.external],
  },
  {
    key: 'management', label: 'Access Management', icon: <KeyOutlined />,
    description: 'Permission ile resource/scope koruması; policy ile kim ve hangi koşulda sorusunun yönetimi.',
    owner: 'İşlem sahibi: Yetki yönetimi ekibi',
    children: [pageRegistry.permissions, pageRegistry.policies, pageRegistry.groups, pageRegistry.whatIf],
  },
  {
    key: 'reporting', label: 'Monitoring & Reports', icon: <AuditOutlined />,
    description: 'Mevcut erişimi, karar gerekçesini, kontrol ihlallerini ve değişiklik kayıtlarını inceleyin.',
    owner: 'Görünürlük: HR + Catalogs + Access Management',
    children: [pageRegistry.audit, pageRegistry.evaluate],
  },
] as const


